/**
 * Frozen SETTINGS snapshot (see DEFAULT_SETTINGS_FROZEN_AT) and `default` restore.
 *
 * Restores apps/api-server/.bot-config.json from
 * checkpoints/default/default-settings-snapshot.json (legacy: data/) AND copies
 * the committed code checkpoint (checkpoints/default/code) over src. Never writes paper-ledger.json or .env.
 * paperMode is always forced true (cannot restore live).
 * Never ENABLE LATE / SETTLEMENT_PREDICTION / OTM.
 * Code restore does not bounce; tsx will not reload — bounce after Chat default.
 */
import fs from "node:fs";
import path from "node:path";
import { resolveConfigPath, savePersistedConfig } from "./config-persist.js";
import type { BotConfig } from "./trading-bot-types.js";

export const DEFAULT_SETTINGS_FROZEN_AT = "Sat 2026-09-26 4:00 AM ET PR #17 advisory heave terms (OV-SKIP/coversBoth/calibration tagged, hard terms block) + PR #16 ops (checkpoint refresh)";

export const DEFAULT_SNAPSHOT_FILENAME = "default-settings-snapshot.json";

export const DEFAULT_CODE_CHECKPOINT_DIRNAME = "default-code-checkpoint";

/**
 * Committed, versioned checkpoint (ships in git AND the Docker image).
 * data/ is gitignored, dockerignored and is the Fly volume mount, so a
 * checkpoint under data/ never reached production. Layout:
 *   checkpoints/default/default-settings-snapshot.json
 *   checkpoints/default/code/<src/...>
 *   checkpoints/default/MANIFEST.json  (frozenAt, files, sha256 per file, aggregate hash)
 */
export const COMMITTED_CHECKPOINT_DIR = path.join("checkpoints", "default");

/** Freeze set: PATH p + Mind organs (captain/PhD/KXBTC15M/heartbeat) + FROZEN_CC + 15m. EV 3¢ / Kelly 0.60. */
export const DEFAULT_CODE_CHECKPOINT_FILES = [
  "src/lib/strategy-learner.ts",
  "src/lib/trading-bot.ts",
  "src/lib/quote-value-guard.ts",
  "src/lib/organs/director.ts",
  "src/lib/admission.ts",
  "src/lib/default-settings.ts",
  "src/lib/trade-story.ts",
  "src/lib/aligned-take-gate.ts",
  "src/lib/fees/kalshi-fee.ts",
  "src/lib/organs/exit-policy.ts",
  "src/lib/organs/filled-side.ts",
  "src/lib/organs/side-lock.ts",
  "src/lib/organs/lockside-fill-gate.ts",
  "src/lib/organs/lock-side-context.ts",
  "src/lib/settlement-side.ts",
  "src/lib/oracle-desk-chat.ts",
  "src/lib/chat-free-llm.ts",
  "src/lib/money-gate-card.ts",
  "src/lib/automode-adapter.ts",
  "src/lib/basis-tracker.ts",
  "src/lib/timing-clock.ts",
  "src/lib/chat-code-edit.ts",
  "src/lib/organs/brain-center.ts",
  "src/lib/organs/captain-bridge.ts",
  "src/lib/organs/self-drive.ts",
  "src/lib/organs/oracle-v2-doctrine.ts",
  "src/lib/organs/phd-trading-education.ts",
  "src/lib/organs/kxbtc15m-specialist.ts",
  "src/lib/organs/mind-heartbeat.ts",
  "src/lib/organs/settle-side-score.ts",
  "src/lib/organs/mind-calibration.ts",
  "src/lib/organs/mind-uncertainty.ts",
  "src/lib/organs/mind-causal.ts",
  "src/lib/organs/scar-echo-learning.ts",
  "src/lib/organs/index.ts",
  "src/lib/organs/brain-stamps.ts",
  "src/lib/frozen-cc.ts",
  "src/lib/15m-product.ts",
  // Chat agent + trade narrative (2026-09-25 polish batch)
  "src/lib/chat-agent.ts",
  "src/lib/chat-desk-tools.ts",
  "src/lib/chat-router.ts",
  "src/lib/trade-narrative.ts",
  "src/lib/bot-trades-display.ts",
  // Settlement audit + full sweep (2026-09-25 PM, PR #11)
  "src/lib/exit-quote-guard.ts",
  "src/lib/settle-persist-retry.ts",
  "src/lib/desk-knowledge.ts",
  "src/lib/kxbtc15m-ticker.ts",
  "src/lib/paper-ledger.ts",
  "src/lib/config-persist.ts",
  // PR #14 (2026-09-26): fill-price EV/band re-check + early-exit calibration
  "src/lib/paper-fill-price-gate.ts",
  "src/lib/organs/shadow-calibration.ts",
  // PR #17 (2026-09-26): advisory heave classifier at placeOrder + agent entry gate
  "src/lib/organs/mind-place-bind.ts",
  "src/lib/agent-control.ts",
] as const;

export function resolveDefaultSnapshotPath(): string {
  if (process.env.DEFAULT_SETTINGS_SNAPSHOT_PATH) {
    return process.env.DEFAULT_SETTINGS_SNAPSHOT_PATH;
  }
  const committed = path.resolve(process.cwd(), COMMITTED_CHECKPOINT_DIR, DEFAULT_SNAPSHOT_FILENAME);
  if (fs.existsSync(committed)) return committed;
  return path.resolve(process.cwd(), "data", DEFAULT_SNAPSHOT_FILENAME);
}

export function resolveDefaultCodeCheckpointPath(): string {
  if (process.env.DEFAULT_CODE_CHECKPOINT_PATH) {
    return process.env.DEFAULT_CODE_CHECKPOINT_PATH;
  }
  const committed = path.resolve(process.cwd(), COMMITTED_CHECKPOINT_DIR, "code");
  if (fs.existsSync(committed)) return committed;
  return path.resolve(process.cwd(), "data", DEFAULT_CODE_CHECKPOINT_DIRNAME);
}

export type DefaultCheckpointManifest = {
  frozenAt: string;
  gitBase: string | null;
  fileCount: number;
  files: Record<string, string>;
  /** sha256 over "rel\0sha256\n" lines (sorted) + snapshot sha256. */
  hash: string;
  snapshotSha256: string;
};

let manifestCache: { at: number; value: DefaultCheckpointManifest | null } | null = null;

/** Read-only summary for /healthz (frozenAt, file count, aggregate hash). Cached 60 s. */
export function readDefaultCheckpointManifest(): DefaultCheckpointManifest | null {
  if (manifestCache && Date.now() - manifestCache.at < 60_000) return manifestCache.value;
  let value: DefaultCheckpointManifest | null = null;
  try {
    const raw = fs.readFileSync(path.resolve(process.cwd(), COMMITTED_CHECKPOINT_DIR, "MANIFEST.json"), "utf8");
    const m = JSON.parse(raw) as DefaultCheckpointManifest;
    if (m && typeof m.hash === "string" && typeof m.frozenAt === "string") value = m;
  } catch { value = null; }
  manifestCache = { at: Date.now(), value };
  return value;
}

/** Exact word `default` after trim; case-insensitive. */
export function isDefaultChatCommand(text: string): boolean {
  return String(text ?? "").trim().toLowerCase() === "default";
}

export type DefaultSettingsConfig = Record<string, unknown> & { paperMode: true };

export type RestoreDefaultResult =
  | {
      ok: true;
      config: DefaultSettingsConfig;
      confirmation: string;
      configPath: string;
      snapshotPath: string;
      codeFilesRestored: string[];
      bounceRequired: boolean;
    }
  | {
      ok: false;
      reason: string;
      confirmation: string;
      configPath: string;
      snapshotPath: string;
      codeFilesRestored: string[];
      bounceRequired: boolean;
    };

export function forcePaperModeTrue<T extends Record<string, unknown>>(cfg: T): T & { paperMode: true } {
  return { ...cfg, paperMode: true };
}

/** Desk money-machine lock: default restore always arms FROZEN_CC (ask 20–55). */
export function forceFrozenCcModeTrue<T extends Record<string, unknown>>(cfg: T): T & { frozenCcMode: true } {
  return { ...cfg, frozenCcMode: true };
}

export function formatDefaultRestoreConfirmation(
  cfg: { paperMode?: unknown; frozenCcMode?: unknown },
  extras?: { codeFilesRestored?: string[]; bounceRequired?: boolean },
): string {
  const paper = cfg.paperMode === true ? "true" : "true (forced)";
  const files = extras?.codeFilesRestored ?? [];
  const codeLine = files.length
    ? `Mind+PATH-p code checkpoint copied (${files.length} files incl. organs).${extras?.bounceRequired ? " Bounce required for TypeScript to load." : ""}`
    : "Mind+PATH-p code checkpoint (strategy-learner / trading-bot / director / Mind organs: brain-center, captain-bridge, PhD, KXBTC15M, heartbeat, frozen-cc).";
  const frozenCc = cfg && (cfg as { frozenCcMode?: unknown }).frozenCcMode === true ? "true" : "true (forced)";
  return [
    `Restored SETTINGS frozen at ${DEFAULT_SETTINGS_FROZEN_AT}.`,
    `paperMode ${paper}.`,
    `frozenCcMode ${frozenCc}.`,
    "EV 3¢ / Kelly 0.60 unchanged. Ask door 20–55.",
    "LATE dead. FROZEN_CC armed. paper≡live (no paperTierA OR-unlock).",
    codeLine,
    "Never ENABLE LATE/SP/OTM. Paper ledger not touched.",
  ].join(" ");
}

function failClean(
  reason: string,
  snapshotPath: string,
  configPath: string,
): RestoreDefaultResult {
  return {
    ok: false,
    reason,
    confirmation: `Could not restore default settings (${reason}). Config and ledger left as-is. paperMode stays paper.`,
    snapshotPath,
    configPath,
    codeFilesRestored: [],
    bounceRequired: false,
  };
}

function readJsonObject(filePath: string): Record<string, unknown> | null {
  try {
    const raw = fs.readFileSync(filePath, "utf8");
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
    return parsed as Record<string, unknown>;
  } catch {
    return null;
  }
}

function isForbiddenWritePath(filePath: string): boolean {
  const base = path.basename(filePath);
  if (base === "paper-ledger.json" || base === ".env") return true;
  if (base.endsWith(".env")) return true;
  return false;
}

function isSafeSrcRel(rel: string): boolean {
  if (typeof rel !== "string" || !rel.startsWith("src/")) return false;
  if (rel.includes("..") || path.isAbsolute(rel)) return false;
  if (!rel.endsWith(".ts") && !rel.endsWith(".json")) return false;
  return true;
}

export function shouldRestoreCodeCheckpoint(opts: RestoreDefaultOpts): boolean {
  return opts.restoreCode === true;
}

export type RestoreCodeCheckpointResult =
  | { ok: true; restored: string[] }
  | { ok: false; reason: string; restored: string[] };

export function restoreCodeCheckpointFiles(opts: {
  checkpointDir: string;
  srcRoot: string;
  files?: readonly string[];
}): RestoreCodeCheckpointResult {
  const files = opts.files ?? DEFAULT_CODE_CHECKPOINT_FILES;
  const restored: string[] = [];
  const checkpointRoot = path.resolve(opts.checkpointDir);
  const srcRoot = path.resolve(opts.srcRoot);
  const srcOnly = path.resolve(srcRoot, "src");
  const dests: { from: string; to: string; rel: string }[] = [];
  for (const rel of files) {
    if (!isSafeSrcRel(rel)) {
      return { ok: false, reason: `refused unsafe checkpoint path ${rel}`, restored };
    }
    const from = path.resolve(checkpointRoot, rel);
    const to = path.resolve(srcRoot, rel);
    if (!from.startsWith(checkpointRoot + path.sep) && from !== checkpointRoot) {
      return { ok: false, reason: "checkpoint path escape", restored };
    }
    if (!to.startsWith(srcOnly + path.sep) && to !== srcOnly) {
      return { ok: false, reason: "refused dest outside src", restored };
    }
    if (isForbiddenWritePath(to)) {
      return { ok: false, reason: "refused to write ledger or .env", restored };
    }
    dests.push({ from, to, rel });
  }
  for (const d of dests) {
    if (!fs.existsSync(d.from) || !fs.statSync(d.from).isFile()) {
      return { ok: false, reason: `checkpoint file missing: ${d.rel}`, restored };
    }
  }
  for (const d of dests) {
    fs.mkdirSync(path.dirname(d.to), { recursive: true });
    const tmp = `${d.to}.ckpt-tmp.${process.pid}`;
    fs.copyFileSync(d.from, tmp);
    fs.renameSync(tmp, d.to);
    restored.push(d.rel);
  }
  return { ok: true, restored };
}

export type RestoreDefaultOpts = {
  snapshotPath?: string;
  configPath?: string;
  checkpointDir?: string;
  srcRoot?: string;
  /** Default true in production; false when tests override snapshotPath only. */
  restoreCode?: boolean;
  /** Hot-reload in-memory bot config. Must not reset the paper ledger. */
  applyConfig?: (cfg: DefaultSettingsConfig) => void;
};

/**
 * Copy frozen snapshot onto .bot-config.json. Force paperMode true.
 * Copy PATH-p-freeze checkpoint files over src (no bounce).
 * Never writes paper-ledger.json / .env. Fail-clean: no throw.
 */
export function restoreDefaultSettings(opts: RestoreDefaultOpts = {}): RestoreDefaultResult {
  const snapshotPath = opts.snapshotPath ?? resolveDefaultSnapshotPath();
  const configPath = opts.configPath ?? resolveConfigPath();
  const checkpointDir = opts.checkpointDir ?? resolveDefaultCodeCheckpointPath();
  const srcRoot = opts.srcRoot ?? process.cwd();
  const restoreCode = shouldRestoreCodeCheckpoint(opts);
  try {
    if (isForbiddenWritePath(configPath) || path.basename(configPath) === "paper-ledger.json" || configPath.endsWith(".env")) {
      return failClean("refused to write ledger or .env", snapshotPath, configPath);
    }
    if (restoreCode) {
      for (const rel of DEFAULT_CODE_CHECKPOINT_FILES) {
        const from = path.resolve(checkpointDir, rel);
        if (!fs.existsSync(from)) {
          return failClean(`code checkpoint missing: ${rel}`, snapshotPath, configPath);
        }
      }
    }
    const loaded = readJsonObject(snapshotPath);
    if (!loaded) {
      return failClean("snapshot missing or invalid", snapshotPath, configPath);
    }
    const config = forceFrozenCcModeTrue(forcePaperModeTrue(loaded));
    if (config.paperMode !== true) {
      return failClean("paperMode could not be forced true", snapshotPath, configPath);
    }
    if (config.frozenCcMode !== true) {
      return failClean("frozenCcMode could not be forced true", snapshotPath, configPath);
    }
    savePersistedConfig(config as unknown as BotConfig, configPath);
    const written = readJsonObject(configPath);
    if (!written) {
      return failClean("config write did not persist", snapshotPath, configPath);
    }
    if (written.paperMode !== true || written.frozenCcMode !== true) {
      const fixed = forceFrozenCcModeTrue(forcePaperModeTrue(written));
      savePersistedConfig(fixed as unknown as BotConfig, configPath);
    }
    let codeFilesRestored: string[] = [];
    let bounceRequired = false;
    if (restoreCode) {
      const code = restoreCodeCheckpointFiles({ checkpointDir, srcRoot });
      if (!code.ok) {
        return failClean(code.reason, snapshotPath, configPath);
      }
      codeFilesRestored = code.restored;
      bounceRequired = codeFilesRestored.length > 0;
    }
    try {
      opts.applyConfig?.(config);
    } catch {
      // Disk already restored. In-memory hot-reload failed — fail-clean.
    }
    const finalCfg = forceFrozenCcModeTrue(forcePaperModeTrue(readJsonObject(configPath) ?? config));
    if (finalCfg.paperMode !== true) {
      return failClean("refused paperMode false", snapshotPath, configPath);
    }
    if (finalCfg.frozenCcMode !== true) {
      return failClean("refused frozenCcMode false", snapshotPath, configPath);
    }
    return {
      ok: true,
      config: finalCfg,
      confirmation: formatDefaultRestoreConfirmation(finalCfg, { codeFilesRestored, bounceRequired }),
      snapshotPath,
      configPath,
      codeFilesRestored,
      bounceRequired,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "restore failed";
    return failClean(msg, snapshotPath, configPath);
  }
}
