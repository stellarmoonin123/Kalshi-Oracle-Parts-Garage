/**
 * kalshi-1h-poll.ts
 *
 * Lightweight REST poller for the active Kalshi hourly BTC contract.
 * No WebSocket is needed — hourly contract prices move slowly and
 * a 30-second poll interval is more than sufficient for signal evaluation.
 *
 * Product (verified live 2026-08-01): series KXBTCD — threshold markets
 * ("$62,700 or above"), one event per hour, ~188 strike markets per event,
 * floor-strike only, settles on the CF Real Time Index. The old KXBTC1H /
 * KXBTCH series no longer exist and return empty market lists.
 *
 * Strike selection: among the current hour's active markets (earliest future
 * close), pick the strike nearest the live BTC reference price — that market
 * carries the most liquidity and its mid sits nearest 50¢, which is where the
 * strategy library's probability edges are meaningful. Without a reference
 * price, fall back to the market whose YES mid is nearest 50¢.
 *
 * Exports a singleton `hourlyPoller` used by trading-bot.ts.
 */

import { KALSHI_REST_BASE, KALSHI_SERIES_1H } from "./constants.js";
import { bookMidCents } from "./kalshi-book-mid.js";

export interface Hourly1HTick {
  ticker:      string;
  floorStrike: number;
  closeTime:   string;
  yesAsk:      number;   // cents
  yesBid:      number;   // cents
  noAsk:       number;   // cents
  noBid:       number;   // cents
  yesPrice:    number;   // mid, cents
  noPrice:     number;   // mid, cents
  secsRemaining: number;
  ts:          number;
  /** Number of tradable strikes seen in the current hour's event. */
  strikeCount: number;
}

const REST_BASE = KALSHI_REST_BASE;
const POLL_MS   = 30_000;   // every 30 seconds

interface RawMarket {
  ticker:              string;
  status:              string;
  close_time:          string;
  floor_strike?:       number;
  cap_strike?:         number;
  yes_bid_dollars?:    string;
  yes_ask_dollars?:    string;
  no_bid_dollars?:     string;
  no_ask_dollars?:     string;
}

const toCents = (d?: string) => (d != null ? Math.round(parseFloat(d) * 100) : 0);

/**
 * Pure strike/market selection — exported for tests.
 * Filters to active, floor-strike markets in the earliest future close bucket
 * with a sane (non-crossed, non-empty) YES book, then picks the strike nearest
 * `refPrice` (or mid nearest 50¢ when refPrice is unknown).
 */
export function selectHourlyMarket(
  markets: RawMarket[],
  refPrice: number | null,
  nowMs: number,
): { market: RawMarket | null; reason: string; candidates: number } {
  const active = markets.filter(m =>
    m.status === "active" &&
    m.floor_strike != null &&
    m.close_time && new Date(m.close_time).getTime() > nowMs
  );
  if (active.length === 0) return { market: null, reason: "no active hourly markets", candidates: 0 };

  // Current hour = earliest future close bucket.
  const earliestClose = Math.min(...active.map(m => new Date(m.close_time).getTime()));
  const currentHour = active.filter(m => new Date(m.close_time).getTime() === earliestClose);

  // Book sanity: need at least one quoted side, and bid < ask when both exist.
  const tradable = currentHour.filter(m => {
    const bid = toCents(m.yes_bid_dollars);
    const ask = toCents(m.yes_ask_dollars);
    if (bid <= 0 && ask <= 0) return false;               // empty book
    if (bid > 0 && ask > 0 && bid >= ask) return false;   // crossed book
    return true;
  });
  if (tradable.length === 0) {
    return { market: null, reason: `no tradable book among ${currentHour.length} strikes`, candidates: currentHour.length };
  }

  let best: RawMarket | null = null;
  if (refPrice != null && refPrice > 0) {
    let bestDist = Infinity;
    for (const m of tradable) {
      const d = Math.abs((m.floor_strike as number) - refPrice);
      if (d < bestDist) { bestDist = d; best = m; }
    }
  } else {
    let bestDist = Infinity;
    for (const m of tradable) {
      const bid = toCents(m.yes_bid_dollars), ask = toCents(m.yes_ask_dollars);
      const mid = bookMidCents(bid, ask);
      const d = Math.abs(mid - 50);
      if (d < bestDist) { bestDist = d; best = m; }
    }
  }
  return { market: best, reason: "ok", candidates: tradable.length };
}

class Kalshi1HPoll {
  private latest:   Hourly1HTick | null = null;
  private timer:    NodeJS.Timeout | null = null;
  private _polling  = false;
  private _refPrice: number | null = null;
  private _skipReason: string | null = null;

  /** Live BTC price used to pick the closest strike. Set by the bot each tick. */
  setReferencePrice(price: number) {
    if (Number.isFinite(price) && price > 0) this._refPrice = price;
  }

  /** Why the last poll produced no market (null when healthy). */
  getSkipReason(): string | null { return this._skipReason; }

  /** Start polling. Safe to call multiple times. */
  start() {
    if (this.timer) return;
    this.poll();
    this.timer = setInterval(() => this.poll(), POLL_MS);
    console.log(`[1h-poll] started — series ${KALSHI_SERIES_1H}, polling every 30 s`);
  }

  stop() {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
  }

  getLatest(): Hourly1HTick | null {
    return this.latest;
  }

  /**
   * Returns the latest 1H tick only if it is fresh (within `thresholdMs`, default 90 s).
   * Returns null when data is absent or stale so callers don't act on stale prices.
   */
  getFreshLatest(thresholdMs = 90_000): Hourly1HTick | null {
    if (!this.latest) return null;
    if (Date.now() - this.latest.ts > thresholdMs) return null;
    // Rollover guard: never serve a contract whose market has already closed —
    // a slow/failed poll near the top of the hour must not expose the expired
    // hour's strike as current.
    const closeMs = this.latest.closeTime ? new Date(this.latest.closeTime).getTime() : 0;
    if (closeMs > 0 && Date.now() >= closeMs) return null;
    return this.latest;
  }

  private async poll() {
    if (this._polling) return;
    this._polling = true;
    try {
      const tick = await this.fetchMarket();
      if (tick) {
        this.latest = tick;
        console.log(`[1h-poll] ${tick.ticker} · strike $${tick.floorStrike} · yes ${tick.yesBid}/${tick.yesAsk}¢ · ${Math.round(tick.secsRemaining / 60)}m left · ${tick.strikeCount} strikes`);
      }
    } catch (err) {
      this._skipReason = `poll error: ${(err as Error).message}`;
      console.debug("[1h-poll] poll error:", (err as Error).message);
    } finally {
      this._polling = false;
    }
  }

  private async fetchMarket(): Promise<Hourly1HTick | null> {
    const url = `${REST_BASE}/markets?series_ticker=${KALSHI_SERIES_1H}&status=open&limit=1000`;
    const r   = await fetch(url, {
      headers: { Accept: "application/json" },
      signal:  AbortSignal.timeout(10_000),
    });
    if (!r.ok) { this._skipReason = `HTTP ${r.status} from Kalshi`; return null; }

    const data = (await r.json()) as { markets?: RawMarket[] };
    const { market: m, reason, candidates } = selectHourlyMarket(data.markets ?? [], this._refPrice, Date.now());
    if (!m) { this._skipReason = reason; return null; }
    this._skipReason = null;

    const yesBid  = toCents(m.yes_bid_dollars);
    const yesAsk  = toCents(m.yes_ask_dollars);
    const noBid   = toCents(m.no_bid_dollars);
    const noAsk   = toCents(m.no_ask_dollars);
    const yesPrice = bookMidCents(yesBid, yesAsk);
    const noPrice  = bookMidCents(noBid, noAsk);

    const closeMs      = m.close_time ? new Date(m.close_time).getTime() : 0;
    const secsRemaining = closeMs > 0 ? Math.max(0, (closeMs - Date.now()) / 1000) : 0;

    return {
      ticker:      m.ticker,
      floorStrike: m.floor_strike as number,
      closeTime:   m.close_time ?? "",
      yesBid, yesAsk, noBid, noAsk, yesPrice, noPrice,
      secsRemaining,
      ts: Date.now(),
      strikeCount: candidates,
    };
  }
}

export const hourlyPoller = new Kalshi1HPoll();
