/**
 * market-state.test.ts — P3: MARKETSTATE + FAMILY POLICY (ADAPTIVE TACTICS).
 *
 * Pure-function tests for market-state.ts. No DB, no live bot, no network —
 * every function here takes plain inputs and returns a plain value.
 */
import test from "node:test";
import assert from "node:assert/strict";
import {
  computeVelScale, updateVelocityEma, computeZVel, computeRangeScale, computeTau,
  VEL_SCALE_FLOOR_DOL_PER_MIN, VEL_SCALE_CAP_DOL_PER_MIN, RANGE_SCALE_FLOOR_DOL,
  type VelocitySample,
} from "./market-state.js";

test("computeVelScale: floors to VEL_SCALE_FLOOR on a dead-quiet tape", () => {
  const now = 1_000_000_000;
  const history: VelocitySample[] = Array.from({ length: 60 }, (_, i) => ({ t: now - i * 10_000, v: 1 }));
  const { velScale, stale } = computeVelScale(history, now);
  assert.equal(velScale, VEL_SCALE_FLOOR_DOL_PER_MIN);
  assert.equal(stale, false);
});

test("computeVelScale: caps to VEL_SCALE_CAP on a violently fast tape", () => {
  const now = 1_000_000_000;
  const history: VelocitySample[] = Array.from({ length: 60 }, (_, i) => ({ t: now - i * 10_000, v: 500 }));
  const { velScale } = computeVelScale(history, now);
  assert.equal(velScale, VEL_SCALE_CAP_DOL_PER_MIN);
});

test("computeVelScale: stale=true with too few 30m samples (fail-closed, no synthetic calm value)", () => {
  const now = 1_000_000_000;
  const history: VelocitySample[] = [{ t: now, v: 40 }, { t: now - 10_000, v: 42 }];
  const { stale } = computeVelScale(history, now);
  assert.equal(stale, true);
});

test("computeVelScale: mid-range tape lands strictly between floor and cap", () => {
  const now = 1_000_000_000;
  const history: VelocitySample[] = Array.from({ length: 60 }, (_, i) => ({ t: now - i * 10_000, v: 45 }));
  const { velScale } = computeVelScale(history, now);
  assert.ok(velScale > VEL_SCALE_FLOOR_DOL_PER_MIN && velScale < VEL_SCALE_CAP_DOL_PER_MIN);
});

test("updateVelocityEma: first sample with null prevEma returns the raw value", () => {
  assert.equal(updateVelocityEma(null, 37), 37);
});

test("updateVelocityEma: blends toward new sample by alpha", () => {
  const next = updateVelocityEma(10, 20, 0.3);
  assert.equal(next, 0.3 * 20 + 0.7 * 10);
});

test("computeZVel: sign follows velocityEma, magnitude scales inversely with velScale", () => {
  assert.ok(computeZVel(60, 60) > 0);
  assert.ok(computeZVel(-60, 60) < 0);
  assert.ok(computeZVel(60, 12) > computeZVel(60, 120)); // same EMA, smaller scale → bigger z
});

test("computeRangeScale: floors to RANGE_SCALE_FLOOR_DOL when atrPct is tiny", () => {
  assert.equal(computeRangeScale(0.001, 80000), RANGE_SCALE_FLOOR_DOL);
});

test("computeRangeScale: scales with price when atrPct is meaningful", () => {
  const rs = computeRangeScale(0.5, 80000); // 0.5% of 80000 = 400
  assert.equal(rs, 400);
});

test("computeRangeScale: falls back to a conservative 0.15% default when atrPct is undefined", () => {
  const rs = computeRangeScale(undefined, 80000);
  assert.equal(rs, Math.max((0.15 / 100) * 80000, RANGE_SCALE_FLOOR_DOL));
});

test("computeTau: 1 at full period, 0 at settlement, clamped to [0,1]", () => {
  assert.equal(computeTau(900, 900), 1);
  assert.equal(computeTau(0, 900), 0);
  assert.equal(computeTau(-30, 900), 0);
  assert.equal(computeTau(1800, 900), 1);
});

test("computeTau: degenerate periodSecs=0 returns 0, never divides by zero", () => {
  assert.equal(computeTau(300, 0), 0);
});
