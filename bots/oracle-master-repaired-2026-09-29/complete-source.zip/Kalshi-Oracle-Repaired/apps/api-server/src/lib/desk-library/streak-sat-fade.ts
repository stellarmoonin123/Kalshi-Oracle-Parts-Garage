/**
 * desk-library/streak-sat-fade.ts — catalog row only (OBSERVE).
 *
 * LIVE_APPLY false. Not wired into evaluateDeskLibrary take-chain.
 * Strategy evaluator lives in ../streak-sat-fade.ts (STREAK_SAT_FADE
 * dual-gate, ENABLE default false). Saturation-based, NOT blind 3-streak.
 */
export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;
