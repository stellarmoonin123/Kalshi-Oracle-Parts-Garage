/**
 * BRTI-only entryTheo stamp: fresh BRTI required; reject outside [10,90] as null
 * (never stamp 1¢ when ask~40). No ENABLE / EV / paperMode changes.
 */
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  ENTRY_THEO_MAX_CENTS,
  ENTRY_THEO_MIN_CENTS,
  THEO_EPS_MINUTES,
  sanitizeTheoCents,
  stampEntryTheoFromBrti,
} from "./brti-theo-sanity.js";
import { binaryCallPrice } from "./backtest-engine.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BOT = fs.readFileSync(path.join(HERE, "trading-bot.ts"), "utf8");
const FROZEN = fs.readFileSync(path.join(HERE, "frozen-cc.ts"), "utf8");
const HELPER = fs.readFileSync(path.join(HERE, "brti-theo-sanity.ts"), "utf8");

test("sane ATM-ish BRTI stamps theo in [10,90]", () => {
  // Spot near strike, moderate vol, several minutes → mid-band yes theo
  const r = stampEntryTheoFromBrti({
    brtiUsd: 77_000,
    floorStrike: 77_000,
    vol: 0.55,
    minsLeft: 10,
    side: "yes",
  });
  assert.equal(r.reason, "ok");
  assert.equal(r.entryTheoMissing, false);
  assert.ok(r.entryTheoCents != null);
  assert.ok(r.entryTheoCents! >= ENTRY_THEO_MIN_CENTS);
  assert.ok(r.entryTheoCents! <= ENTRY_THEO_MAX_CENTS);
  // ATM binary ≈ 50¢
  assert.ok(Math.abs(r.entryTheoCents! - 50) <= 15);
});

test("missing BRTI → null + entryTheoMissing (no book proxy invent)", () => {
  for (const brtiUsd of [null, undefined, 0, -1, NaN] as const) {
    const r = stampEntryTheoFromBrti({
      brtiUsd: brtiUsd as number | null,
      floorStrike: 77_000,
      vol: 0.55,
      minsLeft: 10,
      side: "yes",
    });
    assert.equal(r.entryTheoCents, null);
    assert.equal(r.entryTheoMissing, true);
    assert.equal(r.reason, "brti_missing");
  }
});

test("deep OTM / absurd BSM floor (1¢) rejected — null not 1¢", () => {
  // Far below strike → binaryCallPrice returns absurd low (no invent mid-band)
  const rawYes = binaryCallPrice(70_000, 80_000, 0.4, 5);
  assert.ok(rawYes <= 5, `expected absurd low theo, got ${rawYes}`);
  const r = stampEntryTheoFromBrti({
    brtiUsd: 70_000,
    floorStrike: 80_000,
    vol: 0.4,
    minsLeft: 5,
    side: "yes",
  });
  assert.equal(r.entryTheoCents, null);
  assert.equal(r.entryTheoMissing, true);
  assert.equal(r.reason, "theo_out_of_band");
  assert.ok(r.rawTheoCents != null && r.rawTheoCents < ENTRY_THEO_MIN_CENTS);
});

test("deep ITM / absurd high theo rejected", () => {
  const r = stampEntryTheoFromBrti({
    brtiUsd: 90_000,
    floorStrike: 70_000,
    vol: 0.4,
    minsLeft: 5,
    side: "yes",
  });
  assert.equal(r.entryTheoCents, null);
  assert.equal(r.entryTheoMissing, true);
  assert.equal(r.reason, "theo_out_of_band");
  assert.ok(r.rawTheoCents != null && r.rawTheoCents > ENTRY_THEO_MAX_CENTS);
});

test("incomplete floor/vol/mins → missing", () => {
  const base = { brtiUsd: 77_000, floorStrike: 77_000, vol: 0.5, minsLeft: 8, side: "no" as const };
  assert.equal(stampEntryTheoFromBrti({ ...base, floorStrike: 0 }).reason, "inputs_incomplete");
  assert.equal(stampEntryTheoFromBrti({ ...base, vol: 0 }).reason, "inputs_incomplete");
  // minsLeft=0 is CLOSE/settle ε-T (1s) — not incomplete; negative still is.
  assert.equal(stampEntryTheoFromBrti({ ...base, minsLeft: -1 }).reason, "inputs_incomplete");
  const atExpiry = stampEntryTheoFromBrti({ ...base, minsLeft: 0 });
  assert.ok(atExpiry.reason === "ok" || atExpiry.reason === "theo_out_of_band");
});

test("sanitizeTheoCents rejects 1 and 99, keeps mid-band", () => {
  assert.deepEqual(sanitizeTheoCents(1), { theoCents: null, theoMissing: true });
  assert.deepEqual(sanitizeTheoCents(99), { theoCents: null, theoMissing: true });
  assert.deepEqual(sanitizeTheoCents(9), { theoCents: null, theoMissing: true });
  assert.deepEqual(sanitizeTheoCents(91), { theoCents: null, theoMissing: true });
  assert.deepEqual(sanitizeTheoCents(42), { theoCents: 42, theoMissing: false });
  assert.deepEqual(sanitizeTheoCents(null), { theoCents: null, theoMissing: true });
});

test("FILL wire uses getFreshBrtiUsd + stampEntryTheoFromBrti (not prices buffer alone)", () => {
  assert.ok(BOT.includes("stampEntryTheoFromBrti"), "host includes (hang-safe)");
  assert.ok(BOT.includes("getFreshBrtiUsd"), "host includes (hang-safe)");
  // The FILL block must prefer BRTI for theo, not last this.prices alone
  const fillIdx = BOT.indexOf("Sit-WATCH: BSM theo");
  assert.ok(fillIdx > 0, "FILL theo comment present");
  const fillSlice = BOT.slice(fillIdx, fillIdx + 1200);
  assert.match(fillSlice, /getFreshBrtiUsd/);
  assert.match(fillSlice, /stampEntryTheoFromBrti/);
  assert.match(fillSlice, /entryTheoMissing/);
  assert.equal(fillSlice.includes("this.prices[this.prices.length - 1].price"), false,
    "FILL theo must not stamp from this.prices last print");
});

test("frozen FILL type carries entryTheoMissing", () => {
  assert.match(FROZEN, /entryTheoMissing\??:\s*boolean/);
});

test("helper docs: no ENABLE / EV cut / paperMode false", () => {
  assert.equal(HELPER.includes("ENABLE_STRATEGY"), false);
  assert.equal(HELPER.includes("CHANGE_EV_FLOOR"), false);
  assert.equal(/paperMode:\s*false/.test(HELPER), false);
  assert.ok(HELPER.includes("never invent"), "host includes (hang-safe)");
});

test("fetchBtcPrice prefers BRTI identity; book-proxy must not feed theo stamp", () => {
  // Identity pin comment + getFreshBrtiUsd first; theo uses stampEntryTheoFromBrti separately.
  assert.ok(BOT.includes("identity pin for G/A_hat/settlement"), "host includes (hang-safe)");
  assert.ok(BOT.includes("never route theo through the book-infer fallback"), "host includes (hang-safe)");
  const fetchIdx = BOT.indexOf("private fetchBtcPrice()");
  assert.ok(fetchIdx > 0);
  const slice = BOT.slice(fetchIdx, fetchIdx + 1200);
  assert.match(slice, /getFreshBrtiUsd/);
  assert.match(slice, /inferBtcPrice/); // book fallback exists for basis/proxy only
  // FILL stamp path (not the import line) must not call inferBtcPrice for theo
  const fillIdx = BOT.indexOf("Sit-WATCH: BSM theo");
  assert.ok(fillIdx > 0, "FILL theo comment present");
  const around = BOT.slice(fillIdx, fillIdx + 1200);
  assert.match(around, /getFreshBrtiUsd/);
  assert.match(around, /stampEntryTheoFromBrti/);
  assert.equal(/inferBtcPrice/.test(around), false, "theo stamp must not use book-infer");
});

test.skip("W2/pin brtiPx is getFreshBrtiUsd — not estimatedFairBRTI book proxy [QUARANTINE brtiPx host peeled]", () => {
  assert.ok(BOT.includes("identity pin for G/A_hat/settlement"), "host includes (hang-safe)");
  const idx = BOT.indexOf("const brtiPx = kalshiWS.getFreshBrtiUsd(2_500)");
  assert.ok(idx > 0, "brtiPx assignment must use getFreshBrtiUsd");
  // Assignment RHS must not be estimatedFairBRTI (comment may still name it).
  const assignLine = BOT.slice(idx, idx + 80);
  assert.match(assignLine, /getFreshBrtiUsd\(2_500\)/);
  assert.equal(/estimatedFairBRTI/.test(assignLine), false, "brtiPx RHS must not be estimatedFairBRTI");
  assert.equal(/const brtiPx = \(!basisTracker\.isFairValueStale/.test(BOT), false,
    "legacy estimatedFairBRTI brtiPx ternary removed");
});

test.skip("Hourly W2 brtiPx = getFreshBrtiUsd; brtiDefined = brtiPx!=null (not hardcoded false) [QUARANTINE hourly peeled]", () => {
  assert.ok(BOT.includes("hourlyBrtiPx = kalshiWS.getFreshBrtiUsd(2_500)"), "host includes (hang-safe)");
  const idx = BOT.indexOf("const hourlyBrtiPx = kalshiWS.getFreshBrtiUsd(2_500)");
  assert.ok(idx > 0);
  const slice = BOT.slice(idx, idx + 1800);
  assert.match(slice, /brtiPx:\s*hourlyBrtiPx/);
  assert.match(slice, /brtiDefined:\s*hourlyBrtiPx\s*!=\s*null/);
  assert.equal(/brtiDefined:\s*false/.test(slice), false, "hourly must not hardcode brtiDefined:false");
  // Identity comment must forbid estimatedFairBRTI invent into hourly pin
  assert.ok(BOT.includes("Never invent estimatedFairBRTI"), "host includes (hang-safe)");
});

test.skip("CLOSE exitTheo stamps via stampEntryTheoFromBrti(getFreshBrtiUsd), not exitBreakdown alone [QUARANTINE peeled host]", () => {
  assert.ok(HELPER.includes("THEO_EPS_MINUTES"), "host includes (hang-safe)");
  assert.match(HELPER, /minsLeft > 0 \? minsLeft : THEO_EPS_MINUTES/);
  const idx = BOT.indexOf("CLOSE exitTheo: stamp from fresh");
  assert.ok(idx > 0, "CLOSE theo stamp comment present");
  const slice = BOT.slice(idx, idx + 1400);
  assert.match(slice, /getFreshBrtiUsd/);
  assert.match(slice, /stampEntryTheoFromBrti/);
  assert.match(slice, /sanitizeTheoCents/); // same 10–90 band belt
  // Must not prefer exitBreakdown.theo as the primary stamp source
  assert.equal(/exitTheoRaw = exitBreakdown/.test(slice), false);
});

test.skip("lag/hold-sell estimatedFairBRTI labeled basis lead NOT settlement pin; lag path not swapped [QUARANTINE peeled host]", () => {
  assert.ok(BOT.includes("BASIS LEAD (not settlement pin)"), "host includes (hang-safe)");
  assert.ok(BOT.includes("BASIS LEAD for lag/thesis proj"), "host includes (hang-safe)");
  assert.ok(BOT.includes("BASIS LEAD proj for hold-sell"), "host includes (hang-safe)");
  // Money-path lag still reads estimatedFairBRTI (deferred BRTI swap)
  assert.ok(BOT.includes("projectSettlementPrice(this.lastBasisState.estimatedFairBRTI"), "host includes (hang-safe)");
  assert.ok(BOT.includes("getFreshBrtiUsd"), "host includes (hang-safe)");
});


test.skip("live monitor/overpay theo uses binaryCallFairValueCents + sanitize (no binaryCallPrice Math.max(1)) [QUARANTINE peeled host]", () => {
  // P2 sensors residual: trading-bot live sites must not call binaryCallPrice.
  assert.equal(/binaryCallPrice\(/.test(BOT), false, "trading-bot must not call binaryCallPrice");
  assert.ok(BOT.includes("binaryCallFairValueCents"), "host includes (hang-safe)");
  const monIdx = BOT.indexOf("Live theo: binaryCallFairValueCents");
  assert.ok(monIdx > 0, "monitorOpenTrade fair-value theo comment");
  const mon = BOT.slice(monIdx, monIdx + 900);
  assert.match(mon, /sanitizeTheoCents/);
  assert.match(mon, /complementaryFairValueCents/);
  const ovIdx = BOT.indexOf("Live overpay theo: fair-value");
  assert.ok(ovIdx > 0, "overpay fair-value theo comment");
  const ov = BOT.slice(ovIdx, ovIdx + 700);
  assert.match(ov, /binaryCallFairValueCents/);
  assert.match(ov, /sanitizeTheoCents/);
  // Lag money path stays basis-lead (IN_TRADE) — do not swap estimatedFairBRTI.
  assert.ok(BOT.includes("projectSettlementPrice(this.lastBasisState.estimatedFairBRTI"), "host includes (hang-safe)");
});
