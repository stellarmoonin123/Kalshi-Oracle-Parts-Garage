/**
 * trade-story.ts — deterministic trade postmortem (no OpenRouter).
 *
 * Builds a teaching TradeStory from a settled/closed BOT fill plus an
 * optional evaluate snapshot. MANUAL origin never produces a story and
 * never writes the learner. Shadow/stories teach better decisions
 * (including +EV takes), not merely fewer trades.
 *
 * Persist: data/trade-stories.jsonl (same jsonl convention as bot-log /
 * research-shadow-log). Does not add a second trade ledger or a new
 * Postgres column (no API bounce / migrate).
 *
 * Learner: winning +EV setups may RAISE weight; losses may lower it;
 * always clamped 0.72–1.18 on a 25-trade bot-fill window. NEVER cuts
 * EV 3¢ / Kelly 0.60 / 9% / 15% reserve / daily halt.
 *
 * Pure compute for build + weight. Persist is a jsonl append.
 */

import fs from "node:fs";
import path from "node:path";

import {
  FILL_ORIGIN_MANUAL,
  MANUAL_STRATEGY_ID,
  isManualFill,
  shouldFeedLearner,
} from "./fill-origin.js";
import {
  LEARNING_WEIGHT_MIN,
  LEARNING_WEIGHT_MAX,
  clampLearningWeight,
} from "./automode-adapter.js";
import { buildExitReasonText } from "./trade-narrative.js";
import { kalshiSettleFromTruth } from "./kalshi-settle-label.js";
import { learnFromClosedStoryRow, emptyStoryLearnState } from "./story-learner.js";
import { buildStoryCounterfactual, type StoryCounterfactual } from "./story-counterfactual.js";

export const STORY_LEARN_WINDOW = 25;
export const STORY_WEIGHT_STEP = 0.02;
export const STORY_LEARN_MIN = LEARNING_WEIGHT_MIN; // 0.72
export const STORY_LEARN_MAX = LEARNING_WEIGHT_MAX; // 1.18

export type TradeStorySide = "YES" | "NO";
export type TradeStorySettlement = "YES" | "NO" | "unknown";
export type TradeStoryResult = "WIN" | "LOSS" | "SKIP_N/A" | "OPEN" | "ORPHAN";

export interface TradeStory {
  side: TradeStorySide;
  settlement: TradeStorySettlement;
  result: TradeStoryResult;
  pnlCents: number;
  setup: string;
  entryReason: string;
  strategy: string;
  duration: string;
  holdToSettlement: boolean;
  soldEarly: boolean;
  /** Held to settle and side != officialSettle. */
  heldWrongSide: boolean;
  whatHappened: string;
  exitReason: string;
  wentRight: string[];
  wentWrong: string[];
  lessons: string[];
  /** Teaching fields (GET /bot/trades + jsonl). Skip PnL is always 0. */
  ask: number | null;
  mtf: number | null;
  evCents: number | null;
  p: number | null;
  valid: boolean | null;
  river: boolean | null;
  holdMs: number | null;
  exitReasonCode: string | null;
  officialSettle: TradeStorySettlement;
  feeNetCents: number;
  skipPnlCents: 0;
  feeNetVsSkip: number;
  counterfactual: StoryCounterfactual;
}

/** Optional evaluate-tick snapshot captured at entry (logging only). */
export interface EvaluateSnapshot {
  strategyId?: string | null;
  signal?: string | null;
  confidence?: number | null;
  regime?: string | null;
  winRate?: number | null;
  expectedEvCents?: number | null;
  sessionMode?: string | null;
  entryReason?: string | null;
  ticker?: string | null;
}

export interface TradeStoryInput {
  /**
   * R4 — only when the win curve is calibrated (mind calibration n ≥ 30 and
   * ECE ≤ 0.08) may story text assert that a positive marked EV was real +EV.
   * Default (absent/false): text treats marked EV as unproven. Text only.
   */
  calibrationReliable?: boolean | null;
  /** Stamped by the settle hook; buildTradeStory derives its own. */
  soldEarly?: boolean;
  heldWrongSide?: boolean;
  fillOrigin?: string | null;
  strategyId?: string | null;
  side: string;
  signal?: string | null;
  outcome?: string | null;
  pnlCents?: number | null;
  entryPriceCents?: number | null;
  exitMktPrice?: number | null;
  exitTheoPrice?: number | null;
  confidence?: number | null;
  entryReason?: string | null;
  exitReason?: string | null;
  exitReasonText?: string | null;
  ticker?: string | null;
  contracts?: number | null;
  filledAt?: string | Date | number | null;
  settledAt?: string | Date | number | null;
  createdAt?: string | Date | number | null;
  cancelledAt?: string | Date | number | null;
  orderPlacedAt?: string | Date | number | null;
  expectedPnlCents?: number | null;
  contractDurationMins?: number | null;
  holdToSettlement?: boolean | null;
  winRate?: number | null;
  regime?: string | null;
  evaluate?: EvaluateSnapshot | null;
  tradeId?: number | null;
  /** Official YES/NO settlement if known. Do not infer from early-exit WIN. */
  settledSide?: TradeStorySettlement | null;
  officialKalshi?: string | null;
  /** BTC close at expiry (not intra-bar live favorite). */
  btcClose?: number | null;
  floorStrike?: number | null;
  ask?: number | null;
  mtf?: number | null;
  evCents?: number | null;
  /** p = winRateAtPrice. Never confidence. */
  p?: number | null;
  winRateAtPrice?: number | null;
  valid?: boolean | null;
  river?: boolean | null;
  holdMs?: number | null;
  exitReasonCode?: string | null;
  feeNetCents?: number | null;
  pathRide?: boolean | null;
  maxGainCents?: number | null;
  yesAsk?: number | null;
  noAsk?: number | null;
  /** Exit-path thesis (decideExit / evaluateOpenThesis). Not pathRide heuristic. */
  thesisStatus?: "VALID" | "BROKEN" | "UNKNOWN" | null;
  thesisStatusPassedToDecideExit?: boolean | null;
  /** HA river agree at exit (decideExit riverValid). Not strategyId.includes("RIVER"). */
  riverValid?: boolean | null;
  ticketGreen?: boolean | null;
  /** TB rule that fired at close (VELOCITY_FLIP_AGAINST / FLOOR_CROSS_AGAINST / …). */
  ruleFired?: string | null;
  /** STORY_STAMP — fee-net score fields. Null = unknown (never invent). */
  fillAsk?: number | null;
  pFilledSide?: number | null;
  SESSION_MODE?: string | null;
  lockSide?: {
    mtf: "yes" | "no" | null;
    ha: "yes" | "no" | null;
    analog: "yes" | "no" | null;
    lagProven: boolean | null;
    result: string | null;
  } | null;
  /** GG R3#1 — storyStamp fee-net quartet (optional; never invent). */
  skipBaselineCents?: number | null;
  feeNetVsSkip?: number | null;
  exitClass?: string | null;
  stampStatus?: string | null;
}

export interface StoryTeachResult {
  story: TradeStory | null;
  taught: boolean;
  weight: number | null;
  reason: string;
}

const HOLD_EXIT_CODES = new Set([
  "SETTLEMENT",
  "SETTLED_KALSHI",
  // D5 — a position still open at expiry, settled from Kalshi's official
  // result (orphan recovery / rebook). It WAS held to settlement, not sold early.
  "ORPHAN_SETTLED_KALSHI",
]);

function normSide(side: string | null | undefined, signal?: string | null): TradeStorySide {
  const s = (side ?? "").trim().toLowerCase();
  if (s === "no" || s === "short") return "NO";
  if (s === "yes" || s === "long") return "YES";
  const sig = (signal ?? "").toUpperCase();
  if (sig === "SHORT") return "NO";
  return "YES";
}

function resultOf(outcome: string | null | undefined): TradeStoryResult {
  const o = (outcome ?? "").toLowerCase().trim();
  if (o === "win") return "WIN";
  if (o === "loss") return "LOSS";
  // Live / ghost open rows — never paint learner SKIP_N/A on pending.
  if (o === "pending" || o === "open") return "OPEN";
  // Null/empty incomplete ledger rows — honest ORPHAN, never SKIP_N/A · open.
  if (o === "" || o === "orphan") return "ORPHAN";
  // Unresolved close (fill couldn't be matched) — ORPHAN, not SKIP_N/A.
  if (o === "unresolved") return "ORPHAN";
  // Cancelled / missed orders — ORPHAN vocab (SKIP_N/A gone from paint path).
  if (o === "cancelled" || o === "canceled") return "ORPHAN";
  return "SKIP_N/A";
}

/** Unsettled vocabulary: not a teachable WIN/LOSS. */
export function isUnsettledStoryResult(r: TradeStoryResult): boolean {
  return r === "SKIP_N/A" || r === "OPEN" || r === "ORPHAN";
}

/** EARLY_EXIT PnL is first-class: green sell is WIN even if settle is wrong. */
export function resultFromPnl(
  outcome: string | null | undefined,
  pnlCents: number | null | undefined,
  soldEarly: boolean,
): TradeStoryResult {
  const base = resultOf(outcome);
  // Never rewrite live/incomplete vocabulary via PnL sign.
  if (base === "OPEN" || base === "ORPHAN") return base;
  const pnl = typeof pnlCents === "number" && Number.isFinite(pnlCents) ? pnlCents : null;
  // Realized fee-net P&L sign is authoritative for WIN/LOSS (held or sold
  // early). Settlement side only decides a flat (0 / unknown) row.
  void soldEarly;
  if (pnl != null) {
    if (pnl > 0) return "WIN";
    if (pnl < 0) return "LOSS";
  }
  if (pnl != null && pnl > 0 && base === "LOSS") {
    // Sold green / fee-net + but tagged settle LOSS — still a cell win.
    return "WIN";
  }
  return base;
}

/**
 * Hold-to-settlement W/L from side vs Kalshi settle.
 * YES fill + settled YES held = WIN (never LOSS). NO + settled NO = WIN.
 * Only when actually held — early exits keep PnL/outcome W/L.
 */
export function resultHeldFromSettle(
  side: TradeStorySide,
  settlement: TradeStorySettlement | null | undefined,
  fallback: TradeStoryResult,
  pnlCents?: number | null,
): TradeStoryResult {
  if (fallback === "OPEN" || fallback === "ORPHAN" || fallback === "SKIP_N/A") return fallback;
  // Nonzero realized fee-net P&L wins over the settle side (label = P&L sign).
  if (typeof pnlCents === "number" && Number.isFinite(pnlCents) && pnlCents !== 0) return fallback;
  const s = String(settlement ?? "").toUpperCase();
  if (s !== "YES" && s !== "NO") return fallback;
  return side === s ? "WIN" : "LOSS";
}


/**
 * Display settle slot for collapsed / whatHappened.
 * Doctrine: known Kalshi YES/NO always appears in the settle slot.
 * - Held: "settled YES|NO"
 * - Early exit + known settle: "sold early · settled YES|NO" (both — not sold-early-only, not settled-only)
 * - Early exit + unknown settle: "sold early"
 * Never "Kalshi unset". Cancelled → orphan.
 * Early-exit W/L still comes from PnL (not settle); settle is market fact only.
 */
export function settlementPhrase(opts: {
  settlement: TradeStorySettlement | null | undefined;
  outcome?: string | null;
  pnlCents?: number | null;
  soldEarly?: boolean;
  exitReason?: string | null;
  holdToSettlement?: boolean | null;
}): string {
  const o = (opts.outcome ?? "").toLowerCase().trim();
  if (o === "pending" || o === "open") return "pending";
  if (o === "cancelled" || o === "canceled") return "orphan";

  const er = String(opts.exitReason ?? "").trim().toUpperCase();
  const hold = opts.holdToSettlement === true || HOLD_EXIT_CODES.has(er);
  const closed = o === "win" || o === "loss"
    || (o !== "" && o !== "pending" && typeof opts.pnlCents === "number" && Number.isFinite(opts.pnlCents));
  const raw = String(opts.settlement ?? "").toUpperCase();
  const known = raw === "YES" || raw === "NO" ? raw : null;

  // Held-to-expiry: settle slot is market YES/NO only.
  if (hold) {
    if (known) return `settled ${known}`;
    return "closed";
  }

  // Incomplete / orphan rows (no hold).
  if (o === "" || o === "orphan" || o === "unresolved") return "orphan";

  // Early exit: paint sold early; append known Kalshi when available.
  if (opts.soldEarly === true || closed) {
    return known ? `sold early · settled ${known}` : "sold early";
  }
  return "open";
}

function settlementOf(
  side: TradeStorySide,
  result: TradeStoryResult,
  settledSide?: TradeStorySettlement | null,
  holdToSettlement?: boolean,
  btcClose?: number | null,
  floorStrike?: number | null,
  officialKalshi?: string | null,
): TradeStorySettlement {
  const truth = kalshiSettleFromTruth({
    officialKalshi: officialKalshi ?? settledSide,
    btcClose,
    floorStrike,
  });
  if (truth) return truth;
  // Hold-to-expiry W/L IS Kalshi PnL. Early-dump W/L is not expiry.
  if (holdToSettlement) {
    if (result === "WIN") return side;
    if (result === "LOSS") return side === "YES" ? "NO" : "YES";
  }
  return "unknown";
}

function toMs(v: string | Date | number | null | undefined): number | null {
  if (v == null || v === "") return null;
  if (typeof v === "number" && Number.isFinite(v)) return v < 1e12 ? v * 1000 : v;
  if (v instanceof Date) {
    const t = v.getTime();
    return Number.isFinite(t) ? t : null;
  }
  const t = new Date(v).getTime();
  return Number.isFinite(t) ? t : null;
}

export function holdMsFromBounds(
  start: string | Date | number | null | undefined,
  end: string | Date | number | null | undefined,
  explicit?: number | null,
): number | null {
  if (typeof explicit === "number" && Number.isFinite(explicit) && explicit >= 0) return Math.round(explicit);
  const a = toMs(start);
  const b = toMs(end);
  if (a == null || b == null) return null;
  return Math.max(0, Math.round(b - a));
}


export function formatStoryDuration(
  start: string | Date | number | null | undefined,
  end: string | Date | number | null | undefined,
): string {
  const a = toMs(start);
  const b = toMs(end);
  if (a == null || b == null) return "unknown";
  const secs = Math.max(0, Math.round((b - a) / 1000));
  if (secs < 60) return `${secs}s`;
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  if (m < 60) return s ? `${m}m ${s}s` : `${m}m`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return rm ? `${h}h ${rm}m` : `${h}h`;
}

function isHoldExit(code: string | null | undefined, flagged?: boolean | null): boolean {
  if (flagged === true) return true;
  if (!code) return false;
  return HOLD_EXIT_CODES.has(code.toUpperCase());
}

function plusEv(input: TradeStoryInput, result: TradeStoryResult): boolean {
  if (result === "WIN" && (input.pnlCents ?? 0) > 0) return true;
  const ev = input.evaluate?.expectedEvCents ?? input.expectedPnlCents;
  if (typeof ev === "number" && Number.isFinite(ev)) return ev > 0;
  return false;
}

function setupLine(input: TradeStoryInput, side: TradeStorySide): string {
  const strat = input.strategyId || input.evaluate?.strategyId || "unnamed";
  const px = input.entryPriceCents != null ? `${input.entryPriceCents}¢` : "n/a";
  const n = input.contracts ?? "?";
  const ticker = input.ticker || input.evaluate?.ticker || "contract";
  const regime = input.evaluate?.regime ?? input.regime;
  const wr = input.evaluate?.winRate ?? input.winRate;
  const wrTxt = typeof wr === "number" && Number.isFinite(wr)
    ? ` · WR ${Math.round(wr * 100)}%`
    : "";
  const ev = input.evaluate?.expectedEvCents ?? input.expectedPnlCents;
  const evTxt = typeof ev === "number" && Number.isFinite(ev)
    ? ` · EV ${ev >= 0 ? "+" : ""}${ev}¢`
    : "";
  const regimeTxt = regime ? ` · ${String(regime).replace(/_/g, " ")}` : "";
  return `${side} ${n}× ${ticker} @ ${px} via ${strat}${regimeTxt}${wrTxt}${evTxt}`;
}

function wentRightWrong(
  result: TradeStoryResult,
  hold: boolean,
  soldEarly: boolean,
  plus: boolean,
  pnlCents: number,
  exitCode: string,
  settleWrongEarlyWin: boolean,
  calibratedEv = false,
): { wentRight: string[]; wentWrong: string[] } {
  const wentRight: string[] = [];
  const wentWrong: string[] = [];
  if (result === "WIN") {
    wentRight.push(plus
      ? "Took a +EV setup and it paid — this is the kind of fill the learner should keep taking."
      : "Finished green even though marked EV was thin/unknown.");
    if (hold) wentRight.push("Held to settlement instead of chopping a winning thesis.");
    if (soldEarly && pnlCents > 0) wentRight.push("Sold early and still locked a profit.");
    if (settleWrongEarlyWin) {
      wentRight.push("Wrong settle + green early sell is a CHEAP_EARLY_EXIT success, not a settle LOSS.");
    }
    if (pnlCents <= 0) wentWrong.push("Labeled a win but P&L is non-positive after fees — check fill/fee math.");
  } else if (result === "LOSS") {
    wentWrong.push("Setup resolved against the position.");
    if (soldEarly) wentWrong.push(`Sold early (${exitCode || "early exit"}) — review whether the thesis was actually broken.`);
    if (hold) wentWrong.push("Rode a losing thesis all the way to settlement.");
    if (plus && calibratedEv) wentWrong.push("Entry EV was positive and still lost — variance, not a reason to stop taking +EV.");
    else if (plus) wentWrong.push("Marked entry EV was positive, but the win curve is not calibrated (measured fee-net ≈ 0¢/contract) — do not treat this as a +EV loss.");
    else wentRight.push("Loss on a non-+EV ticket is information; do not loosen floors to chase it back.");
  } else if (result === "OPEN") {
    wentRight.push("Position still open/pending — not a settled teaching sample yet.");
  } else if (result === "ORPHAN") {
    wentRight.push("Incomplete/orphan row (null outcome) — not a settled teaching sample; never paint SKIP_N/A · open.");
  } else {
    wentRight.push("No teaching sample (skip / cancel / unresolved) — learner left untouched.");
  }
  return { wentRight, wentWrong };
}

function lessonLines(
  result: TradeStoryResult,
  hold: boolean,
  soldEarly: boolean,
  plus: boolean,
  strategy: string,
  exitCode: string,
  calibratedEv = false,
): string[] {
  if (result === "SKIP_N/A") return ["No lesson written — not a bot settled fill for the learner."];
  if (result === "OPEN") return ["Open/pending fill — no settle lesson yet; do not paint SKIP_N/A."];
  if (result === "ORPHAN") return ["Orphan/incomplete row — no settle lesson; never paint SKIP_N/A · open."];
  const lessons: string[] = [];
  if (result === "WIN" && plus) {
    lessons.push(`Keep taking ${strategy} when EV is positive — winning +EV fills raise learner weight (clamp 0.72–1.18), they do not tighten gates.`);
  } else if (result === "WIN") {
    lessons.push(`${strategy} won without a clear +EV tag — log EV at entry so the next win can teach-up cleanly.`);
  } else {
    lessons.push(`${strategy} lost via ${exitCode || "unknown exit"}. Save the lesson; may lower weight inside 0.72–1.18. Do not cut EV 3¢ / Kelly 0.60 / 9% / 15% reserve / daily halt.`);
    if (soldEarly && !hold) {
      lessons.push("Early exit: score EARLY_EXIT PnL first. Wrong settle + green sell is a win for CHEAP_EARLY_EXIT; do not mark it a settle LOSS.");
    }
    if (plus && calibratedEv) {
      lessons.push("Do not stop taking this +EV setup because of one loss — stories teach better decisions, not fewer trades.");
    } else if (plus) {
      lessons.push("Marked EV was positive, but calibration is unreliable and measured fee-net is ≈ 0¢/contract — the +EV claim is unproven; record the sample, do not generalize.");
    }
  }
  if (soldEarly && /PATH_RIDE_TP|HIGH_ODDS/i.test(exitCode)) {
    lessons.push("PATH_RIDE_TP / HIGH_ODDS is sold-early fee-net — not side-skill or settle accuracy. Measure side accuracy only on hold-to-SETTLEMENT with officialSettle.");
  }
  if (hold && result === "LOSS") {
    lessons.push("Held-wrong-side settle crystallizes full loss — stamp heldWrongSide when side != officialSettle.");
  }
  return lessons;
}

function whatHappenedLine(opts: {
  side: TradeStorySide;
  settlement: TradeStorySettlement;
  result: TradeStoryResult;
  pnlCents: number;
  hold: boolean;
  soldEarly: boolean;
  duration: string;
  strategy: string;
  exitText: string;
  outcome?: string | null;
}): string {
  const pnl = `${opts.pnlCents >= 0 ? "+" : ""}${(opts.pnlCents / 100).toFixed(2)}`;
  const how = opts.hold ? "held to settlement" : opts.soldEarly ? "sold early" : "closed";
  const settled = settlementPhrase({ settlement: opts.settlement, outcome: opts.outcome, pnlCents: opts.pnlCents, soldEarly: opts.soldEarly, holdToSettlement: opts.hold });
  return (
    `${opts.strategy} ${opts.side} ${how} (${opts.duration}), ${settled}, ` +
    `${opts.result} ${pnl}. ${opts.exitText}`
  ).trim();
}

/**
 * Story `valid` from exit-path thesis — never invent from pathRide.
 * VALID→true, BROKEN→false, UNKNOWN/absent→null (truly unknown).
 * Explicit `input.valid` wins when provided.
 */
/** Soft-cut exit reasons imply thesis was not VALID at sell. */
export const SOFT_CUT_EXIT_REASONS = new Set([
  "THESIS_BREAK",
  "THESIS_BREAK_EXIT",
  "PATH_RIDE_HA_FLIP",
  "LAG_FLIP",
  "LAG_FLIP_EXIT", // checkLagFlip leftover path (same honesty as LAG_FLIP)
  "PATH_RIDE_90S_FUSE",
]);

/**
 * Story `valid` from exit-path thesis — never invent from pathRide.
 * VALID→true, BROKEN→false, UNKNOWN/absent→null (truly unknown).
 * Soft-cut exits (TB/HA_FLIP/LAG_FLIP/fuse) never stamp valid:true
 * unless thesisStatus is explicitly VALID (should not happen on those sells).
 * Explicit `input.valid` wins only when it does not lie on a soft-cut.
 */
export function storyValidFromThesis(input: Pick<TradeStoryInput, "valid" | "thesisStatus" | "exitReasonCode" | "exitReason">): boolean | null {
  const code = String(input.exitReasonCode || input.exitReason || "");
  const softCut = SOFT_CUT_EXIT_REASONS.has(code);
  if (softCut && input.thesisStatus !== "VALID") {
    // Soft cut without VALID stamp → not a VALID ticket dump in the book.
    if (input.thesisStatus === "BROKEN") return false;
    return false; // missing/UNKNOWN on TB/HA_FLIP → false (never lie true like #716)
  }
  if (typeof input.valid === "boolean") {
    if (softCut && input.valid === true && input.thesisStatus !== "VALID") return false;
    return input.valid;
  }
  if (input.thesisStatus === "VALID") return true;
  if (input.thesisStatus === "BROKEN") return false;
  return null;
}

/** Normalize thesis stamp for soft-cut exits when caller omitted it. */
export function storyThesisStatusForExit(input: Pick<TradeStoryInput, "thesisStatus" | "exitReasonCode" | "exitReason">): TradeStoryInput["thesisStatus"] {
  const code = String(input.exitReasonCode || input.exitReason || "");
  if (SOFT_CUT_EXIT_REASONS.has(code) && (input.thesisStatus == null || input.thesisStatus === "UNKNOWN")) {
    return "BROKEN";
  }
  return input.thesisStatus ?? null;
}

/**
 * Story `river` from exit-path riverValid — never invent from strategyId name.
 * Explicit boolean wins; otherwise null when unknown.
 */
export function storyRiverFromExit(input: Pick<TradeStoryInput, "river" | "riverValid" | "strategyId">): boolean | null {
  if (typeof input.river === "boolean") return input.river;
  if (typeof input.riverValid === "boolean") return input.riverValid;
  return null;
}

/**
 * Deterministic story. Returns null for MANUAL origin / MANUAL strategy
 * so we never persist a teaching story or feed the learner.
 * Legacy empty origin is treated as BOT (same as fill-origin.ts).
 */
export function buildTradeStory(input: TradeStoryInput): TradeStory | null {
  if (isManualFill(input.fillOrigin) || input.strategyId === MANUAL_STRATEGY_ID) {
    return null;
  }
  // Explicit non-bot origin (other than legacy empty) — do not teach.
  if (input.fillOrigin != null && input.fillOrigin !== "" && input.fillOrigin !== "bot") {
    return null;
  }

  const side = normSide(input.side, input.signal);
  const pnlCents = Math.round(input.pnlCents ?? 0);
  const strategy = String(input.strategyId || input.evaluate?.strategyId || "unnamed");
  const exitCode = input.exitReason || "";
  const holdHint = isHoldExit(exitCode, input.holdToSettlement);
  const soldEarlyHint = !holdHint;
  let result = resultFromPnl(input.outcome, pnlCents, soldEarlyHint && !holdHint);
  const settlement = settlementOf(
    side, result, input.settledSide, holdHint, input.btcClose, input.floorStrike, input.officialKalshi,
  );
  // Held + known Kalshi: W/L from side vs settle (YES+settled YES = WIN).
  if (holdHint) {
    result = resultHeldFromSettle(side, settlement, result, pnlCents);
  }
  const hold = !isUnsettledStoryResult(result) && holdHint;
  const soldEarly = !isUnsettledStoryResult(result) && !hold;
  const start = input.filledAt ?? input.orderPlacedAt ?? input.createdAt;
  const end = input.settledAt ?? input.cancelledAt ?? null;
  const duration = formatStoryDuration(start, end);
  const entryReason = (
    input.entryReason
    || input.evaluate?.entryReason
    || setupLine(input, side)
  ).trim();
  const exitReason = (
    input.exitReasonText
    || (exitCode ? buildExitReasonText(exitCode, {
      outcome: result === "WIN" ? "win" : result === "LOSS" ? "loss" : undefined,
    }) : "")
    || (hold ? "Held to settlement." : soldEarly ? "Exited before settlement." : "No exit recorded.")
  ).trim();
  const plus = plusEv(input, result);
  const settleWrongEarlyWin = soldEarly && pnlCents > 0 && settlement !== "unknown" && settlement !== side;
  const { wentRight, wentWrong } = wentRightWrong(result, hold, soldEarly, plus, pnlCents, exitCode, settleWrongEarlyWin, input.calibrationReliable === true);
  const lessons = lessonLines(result, hold, soldEarly, plus, strategy, exitCode || "n/a", input.calibrationReliable === true);

  const ask = input.ask ?? input.entryPriceCents ?? null;
  const p = input.p ?? input.winRateAtPrice ?? input.evaluate?.winRate ?? input.winRate ?? null;
  const evCents = input.evCents ?? input.evaluate?.expectedEvCents ?? input.expectedPnlCents ?? null;
  const holdMs = holdMsFromBounds(start, end, input.holdMs);
  const feeNetCents = Math.round(input.feeNetCents ?? pnlCents);
  const officialSettle: TradeStorySettlement =
    (input.officialKalshi === "YES" || input.officialKalshi === "NO")
      ? input.officialKalshi
      : (input.settledSide === "YES" || input.settledSide === "NO")
        ? input.settledSide
        : settlement;
  const thesisStatusNorm = storyThesisStatusForExit(input);
  const valid = storyValidFromThesis({ ...input, thesisStatus: thesisStatusNorm ?? input.thesisStatus });
  const river = storyRiverFromExit(input);
  const askN = typeof ask === "number" && Number.isFinite(ask) ? ask : null;
  const pN = typeof p === "number" && Number.isFinite(p) ? p : null;
  const counterfactual = buildStoryCounterfactual({
    fillOrigin: input.fillOrigin,
    side,
    ask: askN,
    contracts: input.contracts ?? null,
    p: pN,
    winRateAtPrice: input.winRateAtPrice ?? pN,
    holdMs,
    exitReasonCode: input.exitReasonCode || exitCode || null,
    officialSettle,
    feeNetCents,
    maxGainCents: input.maxGainCents ?? null,
    yesAsk: input.yesAsk ?? null,
    noAsk: input.noAsk ?? null,
    thesisStatus: thesisStatusNorm ?? input.thesisStatus ?? null,
    valid,
    pathRide: input.pathRide ?? null,
    thesisStatusPassedToDecideExit: input.thesisStatusPassedToDecideExit ?? true,
  });

  return {
    side,
    settlement,
    result,
    pnlCents,
    setup: setupLine(input, side),
    entryReason,
    strategy,
    duration,
    holdToSettlement: hold,
    soldEarly,
    heldWrongSide: hold && officialSettle !== "unknown" && officialSettle !== side,
    whatHappened: whatHappenedLine({
      side, settlement, result, pnlCents, hold, soldEarly, duration, strategy, exitText: exitReason,
      outcome: input.outcome,
    }),
    exitReason,
    wentRight: [...wentRight, ...counterfactual.wentRight],
    wentWrong,
    lessons: [...lessons, ...counterfactual.lessons],
    ask: askN,
    mtf: typeof input.mtf === "number" && Number.isFinite(input.mtf) ? input.mtf : null,
    evCents: typeof evCents === "number" && Number.isFinite(evCents) ? evCents : null,
    p: pN,
    valid,
    river,
    holdMs,
    exitReasonCode: input.exitReasonCode || exitCode || null,
    officialSettle,
    feeNetCents,
    skipPnlCents: 0,
    feeNetVsSkip: feeNetCents - 0,
    counterfactual,
  };
}

/**
 * Next learner weight from a 25-trade bot-fill window.
 * Winning +EV setups may RISE. Losses may lower. Always inside 0.72–1.18.
 * Does not touch EV / Kelly / 9% / 15% / daily halt.
 */
export function nextLearningWeightFromStory(opts: {
  currentWeight: number;
  recentBotResults: boolean[];
  result: TradeStoryResult;
  expectedEvCents?: number | null;
}): number {
  const window = opts.recentBotResults.slice(-STORY_LEARN_WINDOW);
  const wins = window.filter(Boolean).length;
  const wr = window.length > 0 ? wins / window.length : 0.5;
  let w = Number.isFinite(opts.currentWeight) ? opts.currentWeight : 1;
  const plus = opts.expectedEvCents == null
    ? opts.result === "WIN"
    : opts.expectedEvCents > 0 || opts.result === "WIN";
  if (opts.result === "WIN" && plus) {
    w += STORY_WEIGHT_STEP;
    if (wr >= 0.55) w += STORY_WEIGHT_STEP * 0.5;
  } else if (opts.result === "LOSS") {
    w -= STORY_WEIGHT_STEP;
    if (wr < 0.45) w -= STORY_WEIGHT_STEP * 0.5;
  }
  return clampLearningWeight(w);
}

export function shouldTeachFromStory(input: Pick<TradeStoryInput, "fillOrigin" | "strategyId" | "outcome" | "pnlCents" | "exitReason" | "holdToSettlement">): boolean {
  if (!shouldFeedLearner(input.fillOrigin, input.strategyId)) return false;
  const hold = isHoldExit(input.exitReason, input.holdToSettlement);
  const r = resultFromPnl(input.outcome, input.pnlCents, !hold);
  return r === "WIN" || r === "LOSS";
}

export function teachLearnerFromStory(
  input: TradeStoryInput,
  story: TradeStory | null,
  currentWeight = 1,
  recentBotResults: boolean[] = [],
): { taught: boolean; weight: number | null; reason: string } {
  if (!story) {
    return { taught: false, weight: null, reason: "no story (MANUAL or non-bot)" };
  }
  if (!shouldTeachFromStory(input)) {
    return { taught: false, weight: null, reason: "not a settled bot win/loss" };
  }
  const weight = nextLearningWeightFromStory({
    currentWeight,
    recentBotResults: [...recentBotResults, story.result === "WIN"],
    result: story.result,
    expectedEvCents: input.evaluate?.expectedEvCents ?? input.expectedPnlCents,
  });
  return {
    taught: true,
    weight,
    reason: story.result === "WIN"
      ? "winning +EV/bot fill may raise weight inside 0.72–1.18"
      : "losing bot fill may lower weight inside 0.72–1.18; lessons saved",
  };
}

function storyFilePath(): string {
  const dir = process.env.TRADE_STORY_DATA_DIR
    ? path.resolve(process.env.TRADE_STORY_DATA_DIR)
    : path.resolve(process.cwd(), "data");
  return path.join(dir, "trade-stories.jsonl");
}

export function appendTradeStoryJsonl(record: Record<string, unknown>): void {
  const file = storyFilePath();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.appendFileSync(file, `${JSON.stringify(record)}\n`, "utf8");
}

/**
 * Persist a BOT settled story next to the trade ledger (jsonl keyed by
 * tradeId) and compute the learner teach-up. MANUAL → no file write, no
 * weight write. Never throws.
 */
export function persistSettledBotStory(
  input: TradeStoryInput,
  opts?: { currentWeight?: number; recentBotResults?: boolean[] },
): StoryTeachResult {
  try {
    const story = buildTradeStory(input);
    if (!story) {
      return { story: null, taught: false, weight: null, reason: "MANUAL/non-bot — no story, no learner write" };
    }
    const teach = teachLearnerFromStory(
      input,
      story,
      opts?.currentWeight ?? 1,
      opts?.recentBotResults ?? [],
    );
    const learn = learnFromClosedStoryRow({
      fillOrigin: input.fillOrigin ?? "bot",
      strategyId: input.strategyId ?? null,
      tradeId: input.tradeId ?? null,
      side: story.side,
      ask: story.ask,
      entryPriceCents: input.entryPriceCents ?? story.ask,
      mtf: story.mtf,
      evCents: story.evCents,
      p: story.p,
      winRateAtPrice: story.p,
      valid: story.valid,
      river: story.river,
      holdMs: story.holdMs,
      exitReason: input.exitReason ?? story.exitReasonCode,
      exitReasonCode: story.exitReasonCode,
      officialSettle: story.officialSettle,
      settlement: story.settlement,
      pnlCents: story.pnlCents,
      feeNetCents: story.feeNetCents,
      outcome: input.outcome ?? null,
      isPaper: true,
    }, emptyStoryLearnState());
    appendTradeStoryJsonl({
      ts: Date.now(),
      tradeId: input.tradeId ?? null,
      strategyId: input.strategyId ?? null,
      fillOrigin: input.fillOrigin ?? "bot",
      side: story.side,
      ask: story.ask,
      mtf: story.mtf,
      ev: story.evCents,
      p: story.p,
      valid: story.valid,
      river: story.river,
      thesisStatus: storyThesisStatusForExit(input) ?? input.thesisStatus ?? null,
      ticketGreen: typeof input.ticketGreen === "boolean" ? input.ticketGreen : null,
      riverValid: typeof input.riverValid === "boolean" ? input.riverValid : null,
      ruleFired: input.ruleFired ?? null,
      fillAsk: typeof input.fillAsk === "number" && Number.isFinite(input.fillAsk) ? input.fillAsk : (typeof input.ask === "number" && Number.isFinite(input.ask) ? input.ask : null),
      yesAsk: typeof input.yesAsk === "number" && Number.isFinite(input.yesAsk) ? input.yesAsk : null,
      noAsk: typeof input.noAsk === "number" && Number.isFinite(input.noAsk) ? input.noAsk : null,
      pFilledSide: typeof input.pFilledSide === "number" && Number.isFinite(input.pFilledSide) ? input.pFilledSide : (typeof story.p === "number" && Number.isFinite(story.p) ? story.p : null),
      evCents: typeof input.evCents === "number" && Number.isFinite(input.evCents) ? input.evCents : story.evCents,
      SESSION_MODE: input.SESSION_MODE ?? null,
      lockSide: input.lockSide ?? null,
      holdMs: story.holdMs,
      exitReason: story.exitReasonCode ?? input.exitReason ?? null,
      officialSettle: story.officialSettle,
      feeNetCents: story.feeNetCents,
      skipPnlCents: 0,
      feeNetVsSkip: story.feeNetVsSkip,
      counterfactual: story.counterfactual,
      wouldHaveWon: story.counterfactual.wouldHaveWon,
      autoApply: story.counterfactual.autoApply,
      story,
      taught: teach.taught,
      weight: teach.weight,
      lessons: story.lessons,
      learner: {
        label: learn.label,
        skipBias: learn.state.skipBias,
        sizeMult: learn.state.sizeMult,
        regimeHint: learn.state.regimeHint,
        evFloor: learn.evFloorAfter,
        writeWinrateCurve: learn.writeWinrateCurve,
        raiseSkipPreserverGates: learn.raiseSkipPreserverGates,
        reason: learn.reason,
      },
    });
    return { story, taught: teach.taught, weight: teach.weight, reason: teach.reason };
  } catch {
    return { story: null, taught: false, weight: null, reason: "persist failed (swallowed)" };
  }
}

/** Collapsed-row fields: YES/NO · WIN/LOSS · settlement · P&L — never empty. */
export function collapsedStoryFields(input: Pick<TradeStoryInput, "side" | "signal" | "outcome" | "pnlCents" | "settledSide" | "officialKalshi" | "exitReason" | "holdToSettlement" | "btcClose" | "floorStrike">): {
  side: TradeStorySide;
  result: TradeStoryResult;
  settlement: TradeStorySettlement;
  pnlCents: number;
  pnlLabel: string;
  line: string;
  settlePhrase: string;
} {
  const side = normSide(input.side, input.signal);
  const outcomeLower = (input.outcome ?? "").toLowerCase().trim();
  // Pending/open fills are live (or ghost) positions — never paint learner SKIP_N/A on the row.
  if (outcomeLower === "pending" || outcomeLower === "open") {
    const signed = "+$0.00";
    return {
      side,
      result: "OPEN",
      settlement: "unknown",
      pnlCents: 0,
      pnlLabel: signed,
      settlePhrase: "pending",
      line: `${side} · OPEN · pending · ${signed}`,
    };
  }
  // Null/empty/unresolved incomplete rows — ORPHAN honestly, never SKIP_N/A · open.
  if (outcomeLower === "" || outcomeLower === "orphan" || outcomeLower === "unresolved") {
    const signed = "+$0.00";
    return {
      side,
      result: "ORPHAN",
      settlement: "unknown",
      pnlCents: 0,
      pnlLabel: signed,
      settlePhrase: "orphan",
      line: `${side} · ORPHAN · orphan · ${signed}`,
    };
  }
  // Cancelled / missed — ORPHAN vocab, never SKIP_N/A.
  if (outcomeLower === "cancelled" || outcomeLower === "canceled") {
    const signed = "+$0.00";
    return {
      side,
      result: "ORPHAN",
      settlement: "unknown",
      pnlCents: 0,
      pnlLabel: signed,
      settlePhrase: "orphan",
      line: `${side} · ORPHAN · orphan · ${signed}`,
    };
  }
  const pnlCents = Math.round(input.pnlCents ?? 0);
  const hold = isHoldExit(input.exitReason, input.holdToSettlement);
  let result = resultFromPnl(input.outcome, pnlCents, !hold);
  const settlement = settlementOf(
    side, result, input.settledSide, hold, input.btcClose, input.floorStrike, input.officialKalshi,
  );
  if (hold) {
    result = resultHeldFromSettle(side, settlement, result, pnlCents);
  }
  const pnlLabel = `${pnlCents >= 0 ? "+" : ""}$${(Math.abs(pnlCents) / 100).toFixed(2)}`.replace("+$-", "-$");
  const signed = `${pnlCents >= 0 ? "+" : "-"}$${(Math.abs(pnlCents) / 100).toFixed(2)}`;
  const settlePhrase = settlementPhrase({ settlement, outcome: input.outcome, pnlCents, soldEarly: !hold, exitReason: input.exitReason, holdToSettlement: hold });
  return {
    side,
    result,
    settlement,
    pnlCents,
    pnlLabel: signed,
    settlePhrase,
    line: `${side} · ${result} · ${settlePhrase} · ${signed}`,
  };
}


function asStringList(v: unknown): string[] {
  if (Array.isArray(v)) return v.map((x) => String(x ?? "")).filter((s) => s.length > 0);
  if (typeof v === "string" && v.trim()) return [v.trim()];
  return [];
}

/** Coerce stored/API stories so expand never crashes; preserve OPEN/ORPHAN vocabulary. */
export function coerceTradeStory(story: Partial<TradeStory> | null | undefined): TradeStory | null {
  if (!story || typeof story !== "object") return null;
  const side = story.side === "NO" ? "NO" : "YES";
  const settlement = story.settlement === "YES" || story.settlement === "NO" ? story.settlement : "unknown";
  let result: TradeStoryResult =
    story.result === "WIN" || story.result === "LOSS" || story.result === "OPEN" || story.result === "ORPHAN"
      ? story.result
      : "SKIP_N/A";
  // Never force SKIP on OPEN: upgrade stale SKIP_N/A when story text still says open/pending.
  if (result === "SKIP_N/A") {
    const hint = `${story.whatHappened ?? ""} ${story.exitReason ?? ""} ${story.setup ?? ""}`.toLowerCase();
    if (hint.includes("pending") || hint.includes("still open") || hint.includes("open/pending")) {
      result = "OPEN";
    } else if (
      hint.includes("orphan")
      || hint.includes("incomplete/orphan")
      || hint.includes("unresolved")
      || hint.includes("cancel")
      || hint.includes("sold early")
    ) {
      result = "ORPHAN";
    }
  }
  return {
    side,
    settlement,
    result,
    pnlCents: typeof story.pnlCents === "number" && Number.isFinite(story.pnlCents) ? story.pnlCents : 0,
    setup: String(story.setup ?? ""),
    entryReason: String(story.entryReason ?? ""),
    strategy: String(story.strategy ?? ""),
    duration: String(story.duration ?? ""),
    holdToSettlement: !!story.holdToSettlement,
    soldEarly: !!story.soldEarly,
    heldWrongSide: !!(story as { heldWrongSide?: unknown }).heldWrongSide,
    whatHappened: String(story.whatHappened ?? ""),
    exitReason: String(story.exitReason ?? ""),
    wentRight: asStringList(story.wentRight),
    wentWrong: asStringList(story.wentWrong),
    lessons: asStringList(story.lessons),
    ask: story.ask ?? null,
    mtf: story.mtf ?? null,
    evCents: story.evCents ?? null,
    p: story.p ?? null,
    valid: story.valid ?? null,
    river: story.river ?? null,
    holdMs: story.holdMs ?? null,
    exitReasonCode: story.exitReasonCode ?? null,
    officialSettle: story.officialSettle ?? settlement,
    feeNetCents: typeof story.feeNetCents === "number" && Number.isFinite(story.feeNetCents) ? story.feeNetCents : 0,
    skipPnlCents: 0,
    feeNetVsSkip: typeof story.feeNetVsSkip === "number" && Number.isFinite(story.feeNetVsSkip) ? story.feeNetVsSkip : 0,
    counterfactual: (story.counterfactual ?? {
      kind: "NO_TB",
      actualExit: null,
      actualFeeNetCents: typeof story.feeNetCents === "number" ? story.feeNetCents : 0,
      altFeeNetCents: null,
      feeNetVsActual: null,
      skipPnlCents: 0 as const,
      wouldHaveWon: false,
      taughtWinner: "unknown" as const,
      autoApply: false,
      wiringBug: null,
      implementHoldToSettlement: false as const,
      organ: "none" as const,
      wentRight: [] as string[],
      lessons: [] as string[],
    }) as TradeStory["counterfactual"],
  };
}

export const FILL_ORIGIN_MANUAL_LOCK = FILL_ORIGIN_MANUAL;
