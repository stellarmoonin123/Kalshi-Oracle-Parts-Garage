/**
 * hold-sell.ts — in-trade hold vs sell (pure).
 *
 * Answers: take profit if green and something negative would send it red;
 * hold to settlement when the strike cannot realistically be reached in
 * time left; know HOLD vs SELL in all scenarios.
 *
 * TradingBot.monitorOpenTrade exit order (Stellar thesis-hold):
 *   THESIS_BREAK > LAG_FLIP 15s+16 > HARD_STOP (catastrophic mark≤5¢ or
 *   thesis BROKEN backup) > Aria Guardian > holdToSettlement branch
 *   (config false) > settlement-hold > trailing/time-stop.
 * Soft/hard % of contract value do not outrank THESIS_BREAK / LAG_FLIP.
 *
 * The settlement-hold eligibility
 * block additionally requires action === HOLD_SETTLE so minProb 0.58 + a
 * 55¢ blended mark cannot ride to expiry on model conviction alone.
 *
 * Cheap-side / OTM never HOLD_SETTLE (sell-before-expiry doctrine).
 * Do not disable lag-flip or thesis-break. Do not set holdToSettlement true.
 *
 * LOCKED_ITM uses projectedSettlement vs floor + a USD wick budget.
 * p is not used. Do NOT use confidence as p.
 */

import {
  decidePathRideExit,
  haFromRaw,
  isPathRideStrategyId,
  remainingVolDollars,
  distanceIsFat,
  last1mRangeDollars,
  isStrikePin,
  isGammaGetout,
  adaptiveScalpGreenCents,
  adaptiveSoftGivebackThresholds,
  type RawOhlc,
} from "./path-ride.js";

export type HoldSellAction = "SELL" | "HOLD_SETTLE" | "HOLD_TRAIL";

export interface HoldSellInput {
  strategyId: string | null;
  isOTMAsymmetry?: boolean;
  markCents: number;
  entryCents: number;
  peakUnrealizedCents: number;
  secsRemaining: number;
  projectedSettlement: number | null;
  floor: number | null;
  side: "yes" | "no";
  hardStop: boolean;
  thesisBreak: boolean;
  lagFlip: boolean;
  /** PATH_RIDE A: LAG_FLIP sell only when lag meter proven. */
  lagProven?: boolean;
  /** When set, PATH_RIDE decidePathRideExit requires BROKEN for TB/LAG/fuse. */
  thesisStatus?: "VALID" | "BROKEN" | "UNKNOWN";
  /** Ms thesis has been BROKEN. Missing does NOT proxy from holdMs (path-ride law). */
  brokenPersistedMs?: number;
  /** config trailingProfitCents, default 12 */
  trailingGivebackCents: number;
  /** High sat fade: scalp a green spike, do not hold-to-settle continuation. */
  preferEarlyExit?: boolean;
  /** Ms since fill. PATH_RIDE 90s fuse. */
  holdMs?: number;
  ohlc1m?: RawOhlc[] | null;
  ohlc5m?: RawOhlc[] | null;
  spot?: number | null;
  contracts?: number;
  halfRideTaken?: boolean;
  brtiPrints?: number[] | null;
  brtiSpot?: number | null;
}

export interface HoldSellDecision {
  action: HoldSellAction | "SELL_PARTIAL";
  reason: string;
  sellContracts?: number;
}

/**
 * Conservative BTC 15m wick budget in USD.
 * Floor $80; ~$1.50 per remaining second. A strike that is at least this
 * far from projected settlement cannot realistically be reached in time.
 */
export function maxWickDollars(secsRemaining: number): number {
  const secs = Number.isFinite(secsRemaining) ? Math.max(0, secsRemaining) : 0;
  return Math.max(80, 1.5 * secs);
}

/**
 * Duplicated from trading-bot.ts `isHoldToSettlementExempt` (OTM or
 * CHEAP_SIDE_15M). Do not import trading-bot.js from this file — that
 * would cycle (bot wires this module). Keep the two-line check in sync.
 */
function isHoldToSettlementExempt(trade: {
  isOTMAsymmetry?: boolean;
  strategyId?: string | null;
}): boolean {
  if (trade.isOTMAsymmetry) return true;
  const id = trade.strategyId;
  return id === "CHEAP_SIDE_15M"
    || id === "PAPER_SCALP"
    || id === "CHEAP_EARLY_EXIT"
    || id === "PANIC_FADE"
    || id === "STREAK_SAT_FADE"
    || id === "TICKET_WAVE";
}

function sell(reason: string): HoldSellDecision {
  return { action: "SELL", reason };
}

function holdTrail(reason: string): HoldSellDecision {
  return { action: "HOLD_TRAIL", reason };
}

function holdSettle(reason: string): HoldSellDecision {
  return { action: "HOLD_SETTLE", reason };
}

function isLockedItm(input: HoldSellInput): boolean {
  const { projectedSettlement, floor, side, markCents, secsRemaining } = input;
  if (!Number.isFinite(projectedSettlement) || !Number.isFinite(floor)) return false;
  const proj = projectedSettlement as number;
  const fl = floor as number;
  const onSide = side === "yes" ? proj >= fl : proj <= fl;
  if (!onSide) return false;
  if (!(markCents >= 90)) return false;
  if (!(secsRemaining > 0)) return false;
  return Math.abs(proj - fl) >= maxWickDollars(secsRemaining);
}

export function decideHoldOrSell(input: HoldSellInput): HoldSellDecision {
  const mark = input.markCents;
  const entry = input.entryCents;
  const unrealized = mark - entry;
  const trailGiveback = Number.isFinite(input.trailingGivebackCents)
    ? input.trailingGivebackCents
    : 12;

  // 1. PATH_RIDE book (CC/LAG/HA_RIVER/HA_FLIP/TICKET_WAVE) and NO_CROSS.
  //    decidePathRideExit is the only TB/LAG/fuse/HA_FLIP seller — never let
  //    raw thesisBreak/lagFlip/hardStop flags bypass VALID/UNKNOWN (P1 class hole).
  //    Ruin ≤8¢ / catastrophic still live inside decidePathRideExit.
  if (isPathRideStrategyId(input.strategyId) || input.strategyId === "NO_CROSS") {
    const ha1m = haFromRaw(input.ohlc1m ?? null);
    const ha5m = haFromRaw(input.ohlc5m ?? null);
    const haOk = ha1m != null && ha5m != null;
    const remainingVol = remainingVolDollars(input.ohlc1m ?? null, input.secsRemaining);
    const volHonest = remainingVol != null && remainingVol > 0;
    const spot = input.spot ?? input.projectedSettlement;
    const floor = input.floor;
    const fat = spot != null && floor != null && volHonest
      ? distanceIsFat({
          spot,
          floor,
          secsRemaining: input.secsRemaining,
          remainingVol,
        })
      : false;
    const riverAgrees = haOk && ha1m != null && ha5m != null
      && ha1m[ha1m.length - 1]!.color === ha5m[ha5m.length - 1]!.color
      && ((input.side === "yes" && ha1m[ha1m.length - 1]!.color === "green")
        || (input.side === "no" && ha1m[ha1m.length - 1]!.color === "red"));
    const last1mRange = last1mRangeDollars(input.ohlc1m ?? null);
    const pinSpot = input.spot ?? input.projectedSettlement;
    const strikePin = isStrikePin({
      ohlc1m: input.ohlc1m ?? null,
      floor: floor ?? 0,
      ha1m,
      ha5m,
      haOk,
    });
    const gammaGetout = pinSpot != null && floor != null
      ? isGammaGetout({
          secsRemaining: input.secsRemaining,
          spot: pinSpot,
          floor,
          last1mRange,
          markCents: mark,
          entryCents: entry,
        })
      : false;
    const pr = decidePathRideExit({
      strategyId: input.strategyId,
      side: input.side,
      markCents: mark,
      entryCents: entry,
      holdMs: Number.isFinite(input.holdMs) ? (input.holdMs as number) : 0,
      secsRemaining: input.secsRemaining,
      ha1m,
      ha5m,
      haOk,
      riverAgrees,
      riverValid: haOk && riverAgrees,
      ticketGreen: unrealized > 0,
      thesisStatus: input.thesisStatus,
      thesisBreak: input.thesisBreak === true || input.thesisStatus === "BROKEN",
      lagFlip: input.lagFlip === true,
      lagProven: input.lagProven === true,
      // Missing brokenPersistedMs → 0 inside decidePathRideExit (never invent from holdMs).
      brokenPersistedMs: Number.isFinite(input.brokenPersistedMs)
        ? (input.brokenPersistedMs as number)
        : undefined,
      volHonest,
      remainingVol,
      distanceFat: fat,
      contracts: input.contracts,
      halfRideTaken: input.halfRideTaken,
      strikePin,
      gammaGetout,
      brtiPrints: input.brtiPrints,
      brtiSpot: input.brtiSpot ?? input.spot ?? null,
      floor: floor ?? null,
      peakUnrealizedCents: input.peakUnrealizedCents,
    });
    if (pr) {
      if (pr.action === "SELL") return sell(pr.reason);
      if (pr.action === "SELL_PARTIAL") {
        return { action: "SELL_PARTIAL", reason: pr.reason, sellContracts: pr.sellContracts };
      }
      if (pr.action === "HOLD_SETTLE") return holdSettle(pr.reason);
      return holdTrail(pr.reason);
    }
  }

  // 2–4. Non-PATH_RIDE only: TB > LAG_FLIP > HARD_STOP (Stellar exit order).
  if (input.thesisBreak) return sell("THESIS_BREAK");
  if (input.lagFlip) return sell("LAG_FLIP");
  if (input.hardStop) return sell("HARD_STOP");

  // 3b. streak-sat fade: cheap→green→sell early (wrong settle OK). ≥8¢ covers
  //     typical cheap-ask fee. Does not dump red. Does not outrank 1–3.
  if (input.preferEarlyExit === true && unrealized >= 8) {
    return sell("STREAK_SAT_EARLY_EXIT");
  }

  // 4. cheap-side / OTM / PAPER_SCALP — never HOLD_SETTLE. Thesis/lag already
  //    matched above even when mark-entry > 0. Near expiry, sell rather than ride.
  //    PAPER_SCALP also sells green (+20¢) or 2× (mark ≥ min(99, 2×entry)).
  if (isHoldToSettlementExempt({
    isOTMAsymmetry: input.isOTMAsymmetry,
    strategyId: input.strategyId,
  })) {
    if (input.strategyId === "PAPER_SCALP") {
      // 2× first (stronger lock), then adaptive green / soft giveback — not rigid +20¢.
      // Still never HOLD_SETTLE.
      const twoX = Math.min(99, 2 * entry);
      if (Number.isFinite(mark) && mark >= twoX) return sell("PAPER_SCALP_TWO_X");
      const greenBar = adaptiveScalpGreenCents({
        entryCents: entry,
        secsRemaining: input.secsRemaining,
      });
      if (unrealized >= greenBar) return sell("PAPER_SCALP_GREEN");
      const soft = adaptiveSoftGivebackThresholds({
        entryCents: entry,
        secsRemaining: input.secsRemaining,
        thesisStatus: input.thesisStatus,
      });
      const peak = Number.isFinite(input.peakUnrealizedCents) ? input.peakUnrealizedCents : unrealized;
      if (
        unrealized > 0
        && peak >= soft.peakMinCents
        && (peak - unrealized) >= soft.givebackCents
      ) {
        return sell("PAPER_SCALP_GIVEBACK");
      }
      if (input.secsRemaining <= 90) return sell("PAPER_SCALP_TIME_STOP");
      return holdTrail("PAPER_SCALP_HOLD_TRAIL");
    }
    if (input.strategyId === "CHEAP_EARLY_EXIT") {
      const twoX = Math.min(99, 2 * entry);
      if (Number.isFinite(mark) && mark >= twoX) return sell("CHEAP_EARLY_TWO_X");
      const greenBar = adaptiveScalpGreenCents({
        entryCents: entry,
        secsRemaining: input.secsRemaining,
      });
      if (unrealized >= greenBar) return sell("CHEAP_EARLY_GREEN");
      if (input.secsRemaining <= 90) return sell("CHEAP_EARLY_TIME_STOP");
      return holdTrail("CHEAP_EARLY_HOLD_TRAIL");
    }
    if (input.strategyId === "PANIC_FADE" || input.strategyId === "STREAK_SAT_FADE") {
      const tag = input.strategyId;
      if (unrealized >= 20) return sell(`${tag}_GREEN`);
      const twoX = Math.min(99, 2 * entry);
      if (Number.isFinite(mark) && mark >= twoX) return sell(`${tag}_TWO_X`);
      if (input.secsRemaining <= 90) return sell(`${tag}_TIME_STOP`);
      return holdTrail(`${tag}_HOLD_TRAIL`);
    }
    if (input.secsRemaining <= 90) return sell("CHEAP_SIDE_NEAR_EXPIRY");
    return holdTrail("CHEAP_SIDE_HOLD_TRAIL");
  }

  // 5. LOCKED_ITM — strike cannot realistically be reached in time left.
  //    Wick budget is USD, not a probability. No confidence-as-p.
  if (isLockedItm(input)) return holdSettle("LOCKED_ITM");

  // 6. Green and threat of red: peak was up, still green, gave back the trail.
  if (
    input.peakUnrealizedCents > 0
    && unrealized >= 0
    && (input.peakUnrealizedCents - unrealized) >= trailGiveback
  ) {
    return sell("TRAIL_GIVEBACK");
  }

  // 7. Dead red: do not ride to 0, but do not dump every red tick (that
  //    would kill the 15s lag-flip / thesis-break grace). Only sell red
  //    when near expiry or already ≥15¢ underwater.
  if (unrealized < 0) {
    if (input.secsRemaining <= 120 || mark <= entry - 15) {
      return sell("DEAD_RED");
    }
    return holdTrail("RED_GRACE_HOLD_TRAIL");
  }

  // 8. Else keep trailing / time-stop stack.
  return holdTrail("HOLD_TRAIL");
}
