# Kalshi Oracle (clean remake)

Single trading product: Express API + in-process bot + Vite dashboard. Paper mode by default. No Replit, no mobile, no perps frontend, no live trading enabled.

Source of truth: /workspace/kalshi-oracle/full (do not destroy it).
Run commands from the root of your checkout.

## Layout

apps/api-server              trading brain, Kalshi client, strategies, risk, Express
apps/kalshi-trader           dashboard (AuthGate + Vite)
packages/db                  Drizzle schema
packages/api-zod             generated Zod types
packages/api-spec            OpenAPI + orval codegen
packages/api-client-react    generated React Query client

## Setup

Needs Node 20+ (24 is fine), pnpm, and Postgres.

Dashboard dev server is port 5173 and proxies /api to the API on 8080.

```bash
cd Kalshi-oracle
cp .env.example .env
# fill DATABASE_URL, BOT_API_KEY, SESSION_SECRET
pnpm install
pnpm db:push
```

## Run

Terminal 1: pnpm run dev:api
Terminal 2: pnpm run dev:dashboard

Open http://localhost:5173 and sign in with your Oracle account (bootstrap the first ADMIN with `ORACLE_ADMIN_USERNAME` / `ORACLE_ADMIN_EMAIL` / `ORACLE_ADMIN_PASSWORD` or `pnpm --filter @workspace/api-server accounts:bootstrap-admin`; see docs/accounts/ACCOUNTS.md).

Production-shaped single process (API serves the built dashboard):
pnpm run build && NODE_ENV=production pnpm start

## Tests

pnpm run test:api          # node:test under apps/api-server
pnpm run test:dashboard    # vitest
pnpm run test              # both

API tests share DATABASE_URL. Use a disposable DB.

## Auth

- BOT_API_KEY is the dashboard password and the x-api-key header.
- Login sets httpOnly cookie kalshi_session (HMAC with SESSION_SECRET).
- Public: GET /api/healthz, POST /api/auth/login|logout, GET /api/auth/me.
- If BOT_API_KEY is unset, production mutating routes return 503; development currently falls open. Set the key.

## What is not wired yet

- Postgres + pnpm db:push against a live database (not run in this pass).
- Docker / Fly deploy (omitted on purpose).
- Hourly diagnostic sweep that spawned the full test suite (dropped). Manual /api/diagnostics/run-now is runtime-health only.
- kalshi-mobile, kalshi-perps UI, solodev-researcher, mockup-sandbox (dropped). API still has a read-only perps market-data poller from the original brain.
- Replit CORS, Replit Vite plugins, .replit workflows.

## Landmines

See docs/LANDMINES.md. Copied trading-bot.ts is the product; do not rewrite it.
