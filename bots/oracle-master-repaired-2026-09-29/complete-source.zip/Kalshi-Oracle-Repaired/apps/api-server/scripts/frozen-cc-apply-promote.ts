/**
 * Apply a frozen-cc promote patch. NEVER runs silently.
 *
 *   pnpm --filter @workspace/api-server exec tsx scripts/frozen-cc-apply-promote.ts \
 *     --confirm "APPLY FROZEN PROMOTE" [--patch path]
 *
 * Requires GO (readyToPromote) + exact phrase. Keeps paperMode true and EV≥3 / Kelly.
 * Does not go live. Draft patches are refused.
 */
import * as fs from "node:fs";
import * as path from "node:path";
import {
  APPLY_FROZEN_PROMOTE_PHRASE,
  assertPromoteApplyGate,
} from "../src/lib/frozen-cc.js";

const args = process.argv.slice(2);
const confirmIdx = args.indexOf("--confirm");
const phrase = confirmIdx >= 0 ? (args[confirmIdx + 1] ?? "") : "";
const patchIdx = args.indexOf("--patch");
const patchPath = patchIdx >= 0
  ? args[patchIdx + 1]!
  : path.resolve(process.cwd(), "data", "frozen-cc-promote-patch.json");

if (!fs.existsSync(patchPath)) {
  // Still enforce phrase-first so missing patch cannot be confused with silent apply.
  const phraseGate = assertPromoteApplyGate({
    confirmPhrase: phrase,
    patch: {
      status: "ready",
      readyToPromote: true,
      goNoGo: "GO",
      actions: { paperMode: true, keepEvFloorCents: 3, keepKelly: true },
    },
  });
  if (!phraseGate.ok) {
    console.error(phraseGate.reason);
    process.exit(2);
  }
  console.error(`No patch at ${patchPath} — wait until GO (readyToPromote) writes a ready patch.`);
  process.exit(1);
}

const patch = JSON.parse(fs.readFileSync(patchPath, "utf8"));
const gate = assertPromoteApplyGate({ confirmPhrase: phrase, patch });
if (!gate.ok) {
  console.error(gate.reason);
  process.exit(2);
}

const volumeCfg = path.resolve(process.env.DESK_DATA_DIR || path.resolve(process.cwd(), "data"), ".bot-config.json");
const cfgPath = process.env.BOT_CONFIG_PATH || (fs.existsSync(volumeCfg) ? volumeCfg : path.resolve(process.cwd(), ".bot-config.json"));
const cfg = JSON.parse(fs.readFileSync(cfgPath, "utf8"));

// Preserve paper + EV/Kelly; exit frozen mode; restore desk door.
cfg.frozenCcMode = false;
cfg.paperMode = true;
cfg.minEntryPrice = Math.min(cfg.minEntryPrice ?? 20, 20);
cfg.maxEntryPrice = Math.max(cfg.maxEntryPrice ?? 55, 55);
cfg.holdToSettlement = cfg.frozenCcSaved?.holdToSettlement ?? false;
if (Array.isArray(cfg.frozenCcSaved?.disabledStrategies)) {
  cfg.disabledStrategies = cfg.frozenCcSaved.disabledStrategies;
}
cfg.frozenCcSaved = null;
cfg._frozenPromoteAppliedAt = new Date().toISOString();
cfg._frozenPromoteTier = patch.tier;
cfg._frozenPromoteScoreboardLabel = patch.scoreboardLabel ?? "GO";
cfg._frozenPromoteHardGates = gate.actions.promoteHardGates ?? [];

fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + "\n");
console.log(`Applied promote patch ${patchPath}`);
console.log(`  frozenCcMode=false paperMode=true askDoor=${cfg.minEntryPrice}-${cfg.maxEntryPrice}`);
console.log(`  promoteHardGates=${JSON.stringify(cfg._frozenPromoteHardGates)}`);
console.log(`  Restart API (bounce-desk-api) to load. PATH_RIDE restore is config-side; verify monitor exits.`);
void APPLY_FROZEN_PROMOTE_PHRASE;
