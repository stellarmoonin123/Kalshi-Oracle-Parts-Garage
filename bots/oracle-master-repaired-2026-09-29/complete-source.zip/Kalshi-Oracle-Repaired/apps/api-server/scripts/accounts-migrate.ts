/**
 * accounts-migrate.ts — run the multi-user accounts migration once, by hand.
 * Idempotent and non-destructive (see src/lib/accounts/migrate.ts). The API
 * also runs it on every boot, so this is optional.
 *
 *   pnpm --filter @workspace/api-server run accounts:migrate
 */
import { runAccountsMigration } from "../src/lib/accounts/migrate.js";

try {
  const r = await runAccountsMigration();
  console.log(JSON.stringify({
    ok: true,
    chatBackupCreatedNow: r.backupCreated,
    backedUpConversations: r.backedUpConversations,
    backedUpMessages: r.backedUpMessages,
    legacyConversationsAssigned: r.legacyAssigned,
    legacyOwnerUserId: r.legacyOwnerId,
    unownedConversationsRemaining: r.unownedRemaining,
  }, null, 2));
  if (r.unownedRemaining > 0) console.log("Note: no ADMIN exists yet — run accounts:bootstrap-admin to adopt legacy conversations.");
  process.exit(0);
} catch (err) {
  console.error("accounts migration failed:", (err as Error)?.message ?? err);
  process.exit(1);
}
