import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { FROZEN_CC_STRATEGY_ID } from "./frozen-cc.js";
import {
  LEFTOVER_EVALUATE_EXTRA_IDS,
  leftoverMayEvaluateOnMain15m,
  paperScalpOffMainEvaluateReason,
  paperScalpRunsOnMain15mEvaluate,
  unionMain15mEvaluateDisabled,
} from "./evaluate-15m-scope.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");

test("PAPER_SCALP stays off the paper and frozen main 15m tick", () => {
  assert.equal(paperScalpRunsOnMain15mEvaluate({ paperMode: true, frozenCcMode: true, feeNetBeatsSkip: true }), false);
  assert.equal(paperScalpRunsOnMain15mEvaluate({ paperMode: true, frozenCcMode: false, feeNetBeatsSkip: true }), false);
  assert.equal(paperScalpRunsOnMain15mEvaluate({ paperMode: false, frozenCcMode: true, feeNetBeatsSkip: true }), false);
  assert.equal(paperScalpRunsOnMain15mEvaluate({ paperMode: false, frozenCcMode: false, feeNetBeatsSkip: false }), false);
  assert.equal(paperScalpRunsOnMain15mEvaluate({ paperMode: false, frozenCcMode: false, feeNetBeatsSkip: true }), true);
  assert.equal(paperScalpOffMainEvaluateReason({ frozenCcMode: true }), "frozen_cc_no_scalp");
  assert.equal(paperScalpOffMainEvaluateReason({ paperMode: true, feeNetBeatsSkip: false }), "fee_net_does_not_beat_skip");
});

test("leftovers cannot evaluate on paper/frozen; CC stays off the denylist", () => {
  assert.equal(leftoverMayEvaluateOnMain15m({ paperMode: true, frozenCcMode: true }), false);
  assert.equal(leftoverMayEvaluateOnMain15m({ paperMode: false, frozenCcMode: false }), true);
  const d = unionMain15mEvaluateDisabled(["VELOCITY_MOMENTUM"], { paperMode: true, frozenCcMode: true });
  assert.equal(d.includes(FROZEN_CC_STRATEGY_ID), false);
  assert.ok(d.includes("BASIS_LAG_EDGE"));
  assert.ok(d.includes("TICKET_WAVE"));
  assert.ok(d.includes("PAPER_SCALP"));
  assert.ok(d.includes("HA_FLIP"));
  assert.ok(LEFTOVER_EVALUATE_EXTRA_IDS.includes("PAPER_SCALP"));
});

test("15m host uses the scope helper and does not record scalp quotes unless permitted", () => {
  const start = BOT.indexOf("private evaluateStrategiesForBot(");
  const end = BOT.indexOf("private recordOtmConfluenceSkip(", start);
  assert.ok(start >= 0 && end > start);
  const gate = BOT.slice(start, end);
  assert.match(gate, /unionMain15mEvaluateDisabled/);
  assert.match(gate, /paperScalpRunsOnMain15mEvaluate/);
  assert.match(gate, /paperScalpOffMainEvaluateReason/);
  assert.match(gate, /frozen_cc_no_scalp/);
  assert.match(gate, /fee_net_does_not_beat_skip/);
  const scopeAt = gate.indexOf("paperScalpRunsOnMain15mEvaluate");
  const quotesAt = gate.indexOf("this.paperScalpQuotes.push");
  const decideAt = gate.indexOf("decidePaperScalp(");
  assert.ok(scopeAt >= 0 && quotesAt > scopeAt && decideAt > quotesAt);
});
