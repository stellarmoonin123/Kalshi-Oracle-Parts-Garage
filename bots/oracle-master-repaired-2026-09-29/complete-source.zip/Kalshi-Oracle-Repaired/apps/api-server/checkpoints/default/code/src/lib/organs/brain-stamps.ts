/**
 * brain-stamps — pure stamp builders for brain-visible organ payloads.
 * Stamp existing truths only. No ENABLE. No floor cuts. paperMode untouched.
 * Sole money authority stays host/frozen; these never placeOrder.
 * Does not import director.ts (avoid cycle) — FROZEN_ORGANS_ADVISORY text mirrored.
 */
import { FEED_STALE_QUOTE_MS } from "../feed-stale.js";
import { pathRideTpFeeNetPositive, type PathRideExit } from "../path-ride.js";

/** Mirror of director.FROZEN_ORGANS_ADVISORY — keep string identical. */
export const BRAIN_FROZEN_ORGANS_ADVISORY = "FROZEN_ORGANS_ADVISORY" as const;

export type QuoteSource = "ws" | "rest" | "unknown";

export type Freshness = {
  asOf: string;
  ageMs: number;
  source: QuoteSource;
  stale: boolean;
};

export type IdentityStamp = {
  kind: "identity";
  side: "yes" | "no" | null;
  strategyId: string | null;
  askCents: number | null;
  /** winRateAtPrice ONLY — never confidence */
  p: number | null;
  pSource: "winRateAtPrice";
  /** UI / CC signal strength only — never admitted as p */
  confidence?: number | null;
  evCents: number | null;
  reason: string;
};

export type AdmissionDecision = "TAKE" | "SKIP" | "SIT";

export type AdmissionMsg = {
  kind: "admission";
  soleAuthority: "decideFrozenCcEntry" | "decideMoneyPath" | "none";
  decision: AdmissionDecision;
  code: string;
  identity: IdentityStamp;
  rulesetVersion?: string;
  advisoryParallel?: {
    action: "take" | "skip";
    strategyId: string | null;
    note: typeof BRAIN_FROZEN_ORGANS_ADVISORY;
  };
};

export type ExitMonitorStamp = {
  kind: "exit";
  book: "PATH_RIDE";
  action: string;
  thesisStatus: string | null;
  /** thesisState.reasons — e.g. FLOOR_CROSS_EVIDENCE / LAG_* when status is UNKNOWN. */
  thesisReasons: string[] | null;
  feeNetTpOk: boolean;
  firstMatchStep: number | null;
  /** Observe-only STRUCTURAL_RUIN_SHADOW (never SELL). */
  structuralRuinShadow?: StructuralRuinShadowStamp | null;
};

/** Desk field for STRUCTURAL_RUIN shadow — observeOnly always true. */
export type StructuralRuinShadowStamp = {
  wouldSell: boolean;
  reasons: string[];
  observeOnly: true;
};

/** Minimal organ report shape for stamps (no director import). */
export type OrganReportStampInput = {
  action: "take" | "skip";
  side: "yes" | "no" | "skip";
  strategyId: string | null;
  askCents: number | null;
  p: number | null;
  ev: number | null;
  reason: string;
};

/** Quote freshness for brain-visible feed/tape rows. Missing age → stale. */
export function stampFreshness(opts: {
  ageMs?: number | null;
  source?: QuoteSource | null;
  asOfMs?: number | null;
  staleMs?: number;
}): Freshness {
  const ageMs =
    typeof opts.ageMs === "number" && Number.isFinite(opts.ageMs)
      ? Math.max(0, opts.ageMs)
      : Number.POSITIVE_INFINITY;
  const staleMs = opts.staleMs ?? FEED_STALE_QUOTE_MS;
  const source: QuoteSource =
    opts.source === "ws" || opts.source === "rest" ? opts.source : "unknown";
  const asOfMs =
    typeof opts.asOfMs === "number" && Number.isFinite(opts.asOfMs)
      ? opts.asOfMs
      : Date.now() - (Number.isFinite(ageMs) ? ageMs : 0);
  return {
    asOf: new Date(asOfMs).toISOString(),
    ageMs: Number.isFinite(ageMs) ? ageMs : Number.POSITIVE_INFINITY,
    source,
    stale: !Number.isFinite(ageMs) || ageMs > staleMs,
  };
}

const SIT_CODES = [
  "STILL_MID",
  "still_mid",
  "AND_SIT",
  "and_sit",
  "SIT",
  "SIZE_ZERO",
  "size_zero",
];

export function admissionDecisionFromOrgan(
  action: "take" | "skip",
  reason: string,
): AdmissionDecision {
  if (action === "take") return "TAKE";
  const r = String(reason ?? "");
  if (SIT_CODES.some((c) => r.includes(c))) return "SIT";
  return "SKIP";
}

export function stampIdentityFromOrgan(
  report: OrganReportStampInput,
  confidence?: number | null,
): IdentityStamp {
  const side =
    report.side === "yes" || report.side === "no" ? report.side : null;
  return {
    kind: "identity",
    side,
    strategyId: report.strategyId ?? null,
    askCents:
      typeof report.askCents === "number" && Number.isFinite(report.askCents)
        ? report.askCents
        : null,
    p: typeof report.p === "number" && Number.isFinite(report.p) ? report.p : null,
    pSource: "winRateAtPrice",
    confidence:
      typeof confidence === "number" && Number.isFinite(confidence)
        ? confidence
        : confidence === null
          ? null
          : undefined,
    evCents:
      typeof report.ev === "number" && Number.isFinite(report.ev) ? report.ev : null,
    reason: report.reason,
  };
}

/**
 * Unified AdmissionMsg. Under frozenCcMode organ take/skip is advisoryParallel;
 * soleAuthority remains decideFrozenCcEntry (decision defaults SKIP until host
 * stamps frozen sole — organ path never overrides sole TAKE).
 */
export function stampAdmissionMsg(opts: {
  report: OrganReportStampInput;
  frozenCcMode?: boolean;
  frozenSoleDecision?: AdmissionDecision | null;
  frozenSoleCode?: string | null;
  rulesetVersion?: string;
  confidence?: number | null;
}): AdmissionMsg {
  const frozen = opts.frozenCcMode === true;
  const identity = stampIdentityFromOrgan(opts.report, opts.confidence);
  const organDecision = admissionDecisionFromOrgan(
    opts.report.action,
    opts.report.reason,
  );
  if (frozen) {
    const soleDecision = opts.frozenSoleDecision ?? "SKIP";
    return {
      kind: "admission",
      soleAuthority: "decideFrozenCcEntry",
      decision: soleDecision,
      code: opts.frozenSoleCode ?? opts.report.reason,
      identity,
      rulesetVersion: opts.rulesetVersion ?? "frozen-cc-v1",
      advisoryParallel: {
        action: opts.report.action,
        strategyId: opts.report.strategyId,
        note: BRAIN_FROZEN_ORGANS_ADVISORY,
      },
    };
  }
  return {
    kind: "admission",
    soleAuthority: "decideMoneyPath",
    decision: organDecision,
    code: opts.report.reason,
    identity,
  };
}

/**
 * PATH_RIDE gold-order step ids (first-match documentation).
 * 1 catastrophic → 3 soft-giveback TP → 4 settle-hold → 5 2×/HIGH_ODDS →
 * 6 last-minute cash → 8 ruin → 9 TB/LAG_FLIP → 10 fuse → 11 soft → 12 HOLD.
 */
export function pathRideFirstMatchStep(reason: string | null | undefined): number | null {
  if (reason == null || reason === "") return null;
  const r = String(reason);
  if (r === "PATH_RIDE_CATASTROPHIC" || r === "PATH_RIDE_CATASTROPHIC_WAIT") return 1;
  if (r === "HIGH_ODDS_EXIT") return 5;
  if (r.includes("PATH_RIDE_TP")) return 5;
  if (r === "PATH_RIDE_SETTLEMENT_HOLD" || r.includes("SETTLEMENT_HOLD")) return 4;
  if (r === "HARD_STOP") return 8;
  if (r === "THESIS_BREAK" || r === "LAG_FLIP") return 9;
  if (r.includes("90S_FUSE") || r.includes("FUSE")) return 10;
  if (r.includes("GAMMA") || r.includes("PIN") || r.includes("HA_FLIP")) return 11;
  if (r === "PATH_RIDE_HOLD_TRAIL" || r === "PATH_RIDE_HOLD_SETTLE" || r.includes("HOLD")) return 12;
  if (r.startsWith("NO_CROSS")) return 12;
  return null;
}

export function stampExitMonitor(opts: {
  ride: PathRideExit;
  entryCents: number;
  markCents: number;
  contracts?: number;
  thesisStatus?: string | null;
  thesisReasons?: string[] | null;
  secsRemaining?: number | null;
  structuralRuinShadow?: StructuralRuinShadowStamp | null;
}): ExitMonitorStamp | null {
  const ride = opts.ride;
  if (ride == null) return null;
  const feeNetTpOk = pathRideTpFeeNetPositive({
    entryCents: opts.entryCents,
    markCents: opts.markCents,
    contracts: opts.contracts,
  });
  let step = pathRideFirstMatchStep(ride.reason);
  if (
    (ride.reason.includes("PATH_RIDE_TP") || ride.reason === "HIGH_ODDS_EXIT")
    && typeof opts.secsRemaining === "number"
    && opts.secsRemaining <= 90
  ) {
    step = 6;
  }
  const reasons = Array.isArray(opts.thesisReasons)
    ? opts.thesisReasons.map(String)
    : null;
  const stamp: ExitMonitorStamp = {
    kind: "exit",
    book: "PATH_RIDE",
    action: ride.reason,
    thesisStatus: opts.thesisStatus ?? null,
    thesisReasons: reasons,
    feeNetTpOk,
    firstMatchStep: step,
  };
  if (opts.structuralRuinShadow != null) {
    stamp.structuralRuinShadow = opts.structuralRuinShadow;
  }
  return stamp;
}

/** Attach exit stamp fields onto a PathRideExit (non-destructive). */
export function withExitMonitorFields(
  ride: PathRideExit,
  opts: {
    entryCents: number;
    markCents: number;
    contracts?: number;
    thesisStatus?: string | null;
    thesisReasons?: string[] | null;
    secsRemaining?: number | null;
    structuralRuinShadow?: StructuralRuinShadowStamp | null;
  },
): PathRideExit {
  if (ride == null) return null;
  const stamp = stampExitMonitor({ ride, ...opts });
  if (!stamp) return ride;
  return {
    ...ride,
    firstMatchStep: stamp.firstMatchStep,
    feeNetTpOk: stamp.feeNetTpOk,
  };
}

/* ── Pass2 stamps: sensors / settlement / governance (observe-only) ───────── */

export type SensorMsg = {
  kind: "sensor";
  /** Doctrine: sensors never spend. Always true. */
  advisory: true;
  /** Doctrine: never a TAKE veto / fill gate. Always false. */
  fillGate: false;
  freshness?: Freshness;
  regime?: {
    vol: string;
    shape: string;
    confidence: number;
    fillGate: false;
  };
  lag?: {
    lagSeconds: number | null;
    lagProven: boolean;
    lagStale: boolean;
    /** R4 — a fresh index/proxy price exists (BRTI proxy + exchange ≤5 s). Lag-meter
     *  staleness (short_series / corr_junk) is NOT a missing index. */
    indexProxyFresh?: boolean;
    fillGate: false;
  };
  gold?: {
    cellId: string | null;
    observeOnly: true;
    fillGate: false;
    nSample?: number | null;
  };
};

/** Brain-visible settle status — incomplete ≠ win. */
export type SettleBrainStatus = "OK" | "STORY_STAMP_INCOMPLETE";

export type SettleMsg = {
  kind: "settlement";
  stampStatus: SettleBrainStatus;
  feeNetCents: number | null;
  feeNetVsSkip: number | null;
  officialSettle: string | null;
  /** Anti-corruption: incomplete stamp must never be narrated as a win. */
  incompleteMeansNotWin: true;
};

export type DirectorSkipTaxonomy = "abortEvaluate" | "sizeRescueContinue";

export type GovernanceMsg = {
  kind: "governance";
  taxonomy: DirectorSkipTaxonomy;
  abortEvaluate: boolean;
  sizeRescueContinue: boolean;
  reason: string;
  /** Literacy: SIZE_RESCUE continue ≠ organs ignored. */
  note: string;
};

const SIZE_RESCUE_REASONS = new Set(["size_zero", "BOOK_IMB_GATE"]);

const SIZE_RESCUE_NOTE =
  "sizeRescueContinue: host may continue evaluate/place for size_zero|BOOK_IMB_GATE — organs not ignored";
const ABORT_EVAL_NOTE =
  "abortEvaluate: director skip aborts evaluate (or blocks placeOrder) — organs honored";

/**
 * Sensor bundle — always advisory / never fillGate.
 * Does NOT convert gold/lag/regime into TAKE vetoes.
 */
export function stampSensorMsg(opts: {
  freshness?: Freshness | null;
  regime?: { vol?: string | null; shape?: string | null; confidence?: number | null } | null;
  lag?: {
    lagSeconds?: number | null;
    lagProven?: boolean | null;
    lagStale?: boolean | null;
    indexProxyFresh?: boolean | null;
  } | null;
  gold?: { cellId?: string | null; nSample?: number | null } | null;
}): SensorMsg {
  const msg: SensorMsg = {
    kind: "sensor",
    advisory: true,
    fillGate: false,
  };
  if (opts.freshness) msg.freshness = opts.freshness;
  if (opts.regime) {
    msg.regime = {
      vol: String(opts.regime.vol ?? "UNKNOWN"),
      shape: String(opts.regime.shape ?? "UNKNOWN"),
      confidence:
        typeof opts.regime.confidence === "number" && Number.isFinite(opts.regime.confidence)
          ? opts.regime.confidence
          : 0,
      fillGate: false,
    };
  }
  if (opts.lag) {
    msg.lag = {
      lagSeconds:
        typeof opts.lag.lagSeconds === "number" && Number.isFinite(opts.lag.lagSeconds)
          ? opts.lag.lagSeconds
          : null,
      lagProven: opts.lag.lagProven === true,
      lagStale: opts.lag.lagStale === true,
      ...(typeof opts.lag.indexProxyFresh === "boolean" ? { indexProxyFresh: opts.lag.indexProxyFresh } : {}),
      fillGate: false,
    };
  }
  // Always stamp gold observeOnly doctrine when caller passes gold (even null cell).
  if (opts.gold !== undefined) {
    msg.gold = {
      cellId: opts.gold?.cellId ?? null,
      observeOnly: true,
      fillGate: false,
      nSample:
        typeof opts.gold?.nSample === "number" && Number.isFinite(opts.gold.nSample)
          ? opts.gold.nSample
          : null,
    };
  }
  return msg;
}

/** Sensor doctrine lock: advisory && !fillGate (and nested fillGate false). */
export function sensorDoctrineOk(msg: SensorMsg | null | undefined): boolean {
  if (msg == null) return false;
  if (msg.advisory !== true || msg.fillGate !== false || msg.kind !== "sensor") return false;
  if (msg.regime && msg.regime.fillGate !== false) return false;
  if (msg.lag && msg.lag.fillGate !== false) return false;
  if (msg.gold) {
    if (msg.gold.fillGate !== false || msg.gold.observeOnly !== true) return false;
  }
  return true;
}

/**
 * Normalize story-stamp status ("ok" | STORY_STAMP_INCOMPLETE) → brain OK | INCOMPLETE.
 * Incomplete never means win.
 */
export function stampSettleMsg(opts: {
  stampStatus?: string | null;
  feeNetCents?: number | null;
  feeNetVsSkip?: number | null;
  officialSettle?: string | null;
  incomplete?: boolean | null;
}): SettleMsg {
  const raw = String(opts.stampStatus ?? "");
  // Fail-closed: only explicit ok/OK is OK; empty/unknown → INCOMPLETE.
  const incomplete =
    opts.incomplete === true
    || raw === "STORY_STAMP_INCOMPLETE"
    || (raw !== "ok" && raw !== "OK");
  const stampStatus: SettleBrainStatus = incomplete ? "STORY_STAMP_INCOMPLETE" : "OK";
  return {
    kind: "settlement",
    stampStatus,
    feeNetCents:
      typeof opts.feeNetCents === "number" && Number.isFinite(opts.feeNetCents)
        ? opts.feeNetCents
        : null,
    feeNetVsSkip:
      typeof opts.feeNetVsSkip === "number" && Number.isFinite(opts.feeNetVsSkip)
        ? opts.feeNetVsSkip
        : null,
    officialSettle:
      opts.officialSettle === "YES" || opts.officialSettle === "NO"
        ? opts.officialSettle
        : opts.officialSettle != null
          ? String(opts.officialSettle)
          : null,
    incompleteMeansNotWin: true,
  };
}

/**
 * Director-skip taxonomy: abortEvaluate vs sizeRescueContinue.
 * SIZE_RESCUE continue must not be misread as "organs ignored."
 */
export function stampGovernanceSkip(opts: {
  organReason: string;
  /** True when directorSkipAbortsEvaluate would abort. */
  abortsEvaluate: boolean;
  frozenCc?: boolean;
}): GovernanceMsg {
  const reason = String(opts.organReason ?? "");
  const sizeRescue =
    SIZE_RESCUE_REASONS.has(reason) && opts.abortsEvaluate === false;
  if (sizeRescue) {
    return {
      kind: "governance",
      taxonomy: "sizeRescueContinue",
      abortEvaluate: false,
      sizeRescueContinue: true,
      reason,
      note: SIZE_RESCUE_NOTE,
    };
  }
  return {
    kind: "governance",
    taxonomy: "abortEvaluate",
    abortEvaluate: opts.abortsEvaluate === true,
    sizeRescueContinue: false,
    reason,
    note: ABORT_EVAL_NOTE,
  };
}
