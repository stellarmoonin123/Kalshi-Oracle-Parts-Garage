/**
 * Deterministic 15m admission envelope. LLM values must not appear here.
 * Paper-release last line + director skip/mismatch. Not a new edge model.
 * This object is the only 15m order-intent admit document at placeOrder.
 */
import { paperReleaseOrderBlockReason } from "./paper-release-policy.js";
import { placeOrderDirectorBlockReason } from "./organs/director-skip.js";

export interface DecisionEnvelope {
  ts: number;
  ticker: string;
  strategyId: string;
  side: "yes" | "no" | null;
  askCents: number | null;
  p: number | null;
  ev: number | null;
  size: number | null;
  organAction: "skip" | "take" | null;
  snapshotId: string | null;
  admit: boolean;
  blockReason: string | null;
  llmMayVetoEntry: false;
  llmMayVetoExit: false;
}

export function evaluate15mAdmissionEnvelope(input: {
  paperMode: boolean | undefined;
  ticker: string | null | undefined;
  strategyId: string | null | undefined;
  askCents: number | null | undefined;
  frozenCc: boolean | undefined;
  reconciliationHalt?: boolean;
  nowMs?: number;
  side?: "yes" | "no" | null;
  durationMins?: number;
  frozenSixGateFill?: boolean;
  organAction?: "skip" | "take" | null;
  organReason?: string | null;
  organSide?: "yes" | "no" | "skip" | null;
  organStrategyId?: string | null;
  organP?: number | null;
  organEv?: number | null;
  organSize?: number | null;
  snapshotId?: string | null;
}): DecisionEnvelope {
  const release = paperReleaseOrderBlockReason(input);
  const orderSide = input.side === "yes" || input.side === "no" ? input.side : "yes";
  const director = placeOrderDirectorBlockReason({
    organAction: input.organAction,
    organReason: input.organReason,
    organSide: input.organSide,
    organStrategyId: input.organStrategyId,
    frozenCc: input.frozenCc === true,
    frozenSixGateFill: input.frozenSixGateFill === true,
    durationMins: input.durationMins ?? 15,
    orderSide,
    orderStrategyId: input.strategyId ?? "",
  });
  const block = release ?? director;
  const p = typeof input.organP === "number" && Number.isFinite(input.organP) ? input.organP : null;
  const ev = typeof input.organEv === "number" && Number.isFinite(input.organEv) ? input.organEv : null;
  const size = typeof input.organSize === "number" && Number.isFinite(input.organSize) ? input.organSize : null;
  return {
    ts: input.nowMs ?? Date.now(),
    ticker: input.ticker ?? "",
    strategyId: input.strategyId ?? "",
    side: input.side === "yes" || input.side === "no" ? input.side : null,
    askCents: typeof input.askCents === "number" && Number.isFinite(input.askCents) ? input.askCents : null,
    p,
    ev,
    size,
    organAction: input.organAction ?? null,
    snapshotId: input.snapshotId ?? null,
    admit: block == null,
    blockReason: block,
    llmMayVetoEntry: false,
    llmMayVetoExit: false,
  };
}
