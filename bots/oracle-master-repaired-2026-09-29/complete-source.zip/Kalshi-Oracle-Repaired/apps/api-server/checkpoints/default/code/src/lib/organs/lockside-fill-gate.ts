/**
 * LOCKSIDE_FILL_GATE — SEV0 #722: SKIP lockSide / null mtf must never placeOrder CC|LAG.
 * Settlement side gate. Floors stay. No ENABLE.
 */
export const LOCKSIDE_SKIP_NO_FILL = "LOCKSIDE_SKIP_NO_FILL";

export type LockSideFillLog = {
  lock_result?: "PASS" | "SKIP" | string | null;
  mtf_side?: string | null;
  lockSide?: {
    result?: "PASS" | "SKIP" | string | null;
    mtf?: string | null;
    why?: string | null;
  } | null;
  lockSide_why?: string | null;
} | null | undefined;

export type LockSideFillGate =
  | { ok: true }
  | { ok: false; reason: string; code: typeof LOCKSIDE_SKIP_NO_FILL };

function normSide(side: string): "yes" | "no" | null {
  const s = String(side ?? "").trim().toLowerCase();
  if (s === "yes" || s === "y" || s === "long") return "yes";
  if (s === "no" || s === "n" || s === "short") return "no";
  return null;
}

/** True only when lockSide.result===PASS, lock_result!==SKIP, and mtf matches fill side. */
export function assertLockSideAllowsFill(
  log: LockSideFillLog,
  fillSide: "yes" | "no" | string,
): LockSideFillGate {
  const side = normSide(fillSide);
  if (!side) {
    return { ok: false, code: LOCKSIDE_SKIP_NO_FILL, reason: "fill_side_null" };
  }
  if (!log) {
    return { ok: false, code: LOCKSIDE_SKIP_NO_FILL, reason: "lockside_log_missing" };
  }
  if (log.lock_result === "SKIP") {
    return {
      ok: false,
      code: LOCKSIDE_SKIP_NO_FILL,
      reason: log.lockSide_why ?? log.lockSide?.why ?? "lock_result_SKIP",
    };
  }
  const ls = log.lockSide;
  const result = ls?.result ?? null;
  if (result !== "PASS") {
    return {
      ok: false,
      code: LOCKSIDE_SKIP_NO_FILL,
      reason: ls?.why ?? log.lockSide_why ?? (result == null ? "lockSide_result_null" : `lockSide_result_${result}`),
    };
  }
  const mtf = normSide(String(ls?.mtf ?? log.mtf_side ?? ""));
  if (!mtf) {
    return { ok: false, code: LOCKSIDE_SKIP_NO_FILL, reason: "mtf_sign_null" };
  }
  if (mtf !== side) {
    return { ok: false, code: LOCKSIDE_SKIP_NO_FILL, reason: `mtf_mismatch_mtf=${mtf}_fill=${side}` };
  }
  return { ok: true };
}

/**
 * PR #14 — frozen-CC lockSide stamp. Built from one lockSide() evaluation on
 * the frozen six-gate tick and merged into lastW2Log so the fill gate below
 * sees THIS tick's result. `null` (organ threw / not run) stamps nulls, which
 * assertLockSideAllowsFill treats as FAIL (fail-closed, never a stale PASS).
 */
export type FrozenLockSideEval = {
  side: "yes" | "no" | "skip";
  why?: string | null;
  tags: { result?: "PASS" | "SKIP" | string | null; mtf?: string | null; why?: string | null } & Record<string, unknown>;
};

export function frozenLockSideStamp(ls: FrozenLockSideEval | null | undefined): {
  lock_result: "PASS" | "SKIP" | null;
  lockSide: FrozenLockSideEval["tags"] | null;
  lockSide_why: string | null;
  mtf_side: string | null;
} {
  if (!ls || !ls.tags) {
    return { lock_result: null, lockSide: null, lockSide_why: null, mtf_side: null };
  }
  const result: "PASS" | "SKIP" = ls.side === "skip" ? "SKIP" : "PASS";
  return {
    lock_result: result,
    lockSide: { ...ls.tags, result },
    lockSide_why: ls.why ?? ls.tags.why ?? null,
    mtf_side: ls.tags.mtf ?? null,
  };
}

/**
 * PR #14 — frozen-CC admission before placeOrder: identical rule to every
 * other CC|LAG path (lockSide.result PASS, lock_result≠SKIP, mtf == fill side).
 */
export function frozenCcLockSideAdmission(
  log: LockSideFillLog,
  fillSide: "yes" | "no" | string,
): LockSideFillGate {
  return assertLockSideAllowsFill(log, fillSide);
}

/** CC/LAG size: clamp contracts into [2%, 4%] of equity by entry cost, then ≤9% cap. */
export function clampContractsToEquityBand(opts: {
  contracts: number;
  entryPriceCents: number;
  equityCents: number;
  feeCentsPerContract?: number;
  minEquityPct?: number;
  maxEquityPct?: number;
  hardCapEquityPct?: number;
}): { contracts: number; detail: string } {
  const entry = Math.max(1, Math.round(opts.entryPriceCents));
  const fee = Math.max(0, Math.round(opts.feeCentsPerContract ?? 0));
  const cost = entry + fee;
  const equity = Math.max(0, Math.round(opts.equityCents));
  const minPct = opts.minEquityPct ?? 0.02;
  const maxPct = opts.maxEquityPct ?? 0.04;
  const hardPct = opts.hardCapEquityPct ?? 0.09;
  if (equity <= 0 || cost <= 0) {
    return { contracts: Math.max(1, Math.round(opts.contracts)), detail: "equity_or_cost_zero" };
  }
  const minC = Math.max(1, Math.ceil((minPct * equity) / cost));
  const maxC = Math.max(minC, Math.floor((maxPct * equity) / cost));
  const hardC = Math.max(1, Math.floor((hardPct * equity) / cost));
  let c = Math.max(1, Math.round(opts.contracts));
  if (c < minC) c = minC;
  if (c > maxC) c = maxC;
  if (c > hardC) c = hardC;
  return {
    contracts: c,
    detail: `equityBand ${minPct * 100}–${maxPct * 100}% → [${minC},${maxC}] hard9%=${hardC} final=${c}`,
  };
}
