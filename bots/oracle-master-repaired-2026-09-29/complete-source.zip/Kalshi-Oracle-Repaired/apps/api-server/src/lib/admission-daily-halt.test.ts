/**
 * #370 flash-crash daily halt waterfall + pWinFromCurve (no 0.75).
 * Does not import trading-bot.ts. Does not cut 9% / 18%.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import test from "node:test";
import assert from "node:assert/strict";
import {
  HARD_RISK_LIMITS,
  EV_FLOOR,
  OTM_EV_FLOOR,
  DAILY_HALT_FLOOR_CENTS,
  DAILY_HALT_PCT,
  effectiveDailyHaltCapCents,
  dailyHaltTrips,
  pWinFromCurve,
  applyHardRiskLimits,
} from "./admission.js";
import { PATH_CONFIGS } from "./trade-path.js";
import { getAllStrategyMeta, getStrategy, evaluateAllStrategies, FAIL_CLOSED_WITHOUT_WINRATE_CURVE } from "./strategy-library.js";
import { evaluateConfluenceCascade } from "./confluence-cascade.js";
import { decideSettlementSide, paperMoneyMakerIgnoresSettlementSideSkip } from "./settlement-side.js";
import type { StrategyObservation } from "./strategy-library.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const ADM = readFileSync(path.join(DIR, "admission.ts"), "utf8");

test("locks: 9%/18%/EV 3/5/7 untouched", () => {
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(HARD_RISK_LIMITS.maxDailyLossPct, 0.18);
  assert.equal(EV_FLOOR, 3);
  assert.equal(OTM_EV_FLOOR, 5);
  assert.equal(PATH_CONFIGS.MULTIPLIER.minEVCents, 7);
  assert.equal(applyHardRiskLimits(31_300, 53, 10_000, -(31_300 * 0.18)), 0);
});

test("#370 daily halt waterfall: max(3000¢, 10% of cash) actually trips", () => {
  assert.equal(DAILY_HALT_FLOOR_CENTS, 3000);
  assert.equal(DAILY_HALT_PCT, 0.10);

  // $313 cash: 10% = 3130¢ > 3000 → cap 3130. Exact boundary trips.
  assert.equal(effectiveDailyHaltCapCents(31_300), 3130);
  assert.equal(dailyHaltTrips(-3130, 31_300), true);
  assert.equal(dailyHaltTrips(-3129, 31_300), false);

  // Small account: 10% of $200 = 2000 < 3000 → floor binds. Flash-crash $30 halt.
  assert.equal(effectiveDailyHaltCapCents(20_000), 3000);
  assert.equal(dailyHaltTrips(-3000, 20_000), true);
  assert.equal(dailyHaltTrips(-2999, 20_000), false);

  // Large account: 10% of $1000 = 10000 > 3000.
  assert.equal(effectiveDailyHaltCapCents(100_000), 10_000);
  assert.equal(dailyHaltTrips(-10_000, 100_000), true);
  assert.equal(dailyHaltTrips(-9_999, 100_000), false);

  // 18% last-resort is a different, larger number — not cut, not this waterfall.
  assert.ok(31_300 * 0.18 > 3130);
});

test("SIZE_RESCUE_MIN1 does not live in admission.ts", () => {
  assert.equal(ADM.includes("SIZE_RESCUE_MIN1"), false);
  assert.equal(ADM.includes('limiter: "SIZE_RESCUE_MIN1"'), false);
});

test("pWinFromCurve: CONFLUENCE curve is real p, never 0.75; null p still skips", () => {
  const metas = getAllStrategyMeta();
  const confluence = metas.find(s => s.id === "CONFLUENCE_CASCADE");
  assert.ok(confluence);
  assert.ok(confluence!.winRateAtPrice, "money-maker restore: real p curve, not 0.75 prior");
  const realCc = pWinFromCurve(confluence!.winRateAtPrice, 49, 5);
  assert.ok(realCc != null && realCc > 0 && realCc <= 1);
  assert.notEqual(realCc, 0.75);

  const lag = metas.find(s => s.id === "BASIS_LAG_EDGE");
  assert.ok(lag?.winRateAtPrice);
  const real = pWinFromCurve(lag!.winRateAtPrice, 40, 8);
  assert.ok(real != null && real > 0 && real <= 1);
  assert.notEqual(real, 0.75);

  const side = decideSettlementSide({ pYes: null, pNo: null, mtf: 0 });
  assert.equal(side.side, "skip");
  assert.equal(side.pWin, null);
  assert.equal(side.reason, "p_null_or_invalid");
});

function confluenceFireObs(): StrategyObservation {
  return {
    currentPrice: 63500,
    floorStrike: 63000,
    velocityDolPerMin: 90,
    threeMinVelocity: 85,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 1.2,
    massAboveFloor: 80,
    secsRemaining: 5 * 60,
    recentUpPct: 0.60,
    regime: "strong_uptrend",
    yesAsk: 30,
    noAsk: 70,
    contractDurationMins: 15,
    ticker: "KXBTC15M-26AUG271615-15",
  };
}

test("CONFLUENCE_CASCADE dual-gate lifts when winRateAtPrice exists", () => {
  assert.equal(FAIL_CLOSED_WITHOUT_WINRATE_CURVE.has("CONFLUENCE_CASCADE"), true);
  const obs = confluenceFireObs();
  const named = evaluateConfluenceCascade(obs);
  assert.ok(named, "named evaluate still exists for unit tests");
  const viaLib = getStrategy("CONFLUENCE_CASCADE")!.evaluate(obs);
  assert.ok(viaLib, "library evaluate() still callable");
  const meta = getStrategy("CONFLUENCE_CASCADE");
  assert.ok(meta?.winRateAtPrice, "curve is the dual-gate lift");
  const { all } = evaluateAllStrategies(obs);
  assert.equal(all.some(r => r.strategyId === "CONFLUENCE_CASCADE"), true);
});

test("paper CC SETTLEMENT_SIDE later-preserver does not cut EV 3c", () => {
  assert.equal(EV_FLOOR, 3);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "lag_stale"), true);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "quote_stale"), false);
  const p = pWinFromCurve(getStrategy("CONFLUENCE_CASCADE")!.winRateAtPrice, 24, 6);
  assert.ok(p != null && p > 0 && p <= 1);
  assert.notEqual(p, 0.75);
});
