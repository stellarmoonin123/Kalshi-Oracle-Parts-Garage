/**
 * Route-layer config PATCH surface.
 *
 * Composer-lock still runs inside TradingBot.updateConfig. This strip happens
 * BEFORE that merge so a dashboard Save, PUT/PATCH /bot/config, or agent
 * update_config cannot:
 *   - paperMode false / enable1HLive true without confirmLiveRealMoney:"LIVE REAL MONEY"
 *   - ExpertAgent live (even with a key).
 *   - autoMode true without confirmAutoMode:"CONFIRM AUTO MODE" (paper desk lock).
 *   - enable1HContracts / candlestickPatternLiveEnabled / leftover ENABLE flags
 *   - arm dailyTarget 50%, packs enforce, unproven opt-in flags
 *   - pull SEV1 / LATE_ENTRY / VSR / OTM out of disabledStrategies
 *   - mutate EV / Kelly / 9% / 18% floor constants via patch body
 *   - frozenCcMode false (desk money-machine stays armed)
 *
 * EV floors / Kelly 0.60 / 9% / 18% live in admission.ts constants — refusing
 * these knobs here is defense-in-depth so a hostile PATCH cannot pretend to
 * cut them by inventing BotConfig field names.
 *
 * Does not import trading-bot.ts. LIVE_APPLY is not a thing here.
 */
export const PATCH_FAIL_CLOSED_DISABLED = [
  "SAKATA_CANDLE_PATTERN",
  "MTF_ALIGNED",
  // BRTI_PROBABILITY unlocked PAPER DESK v2 (paper Tier A)
  "DEEP_OTM_SNIPER",
  "OTM_ASYMMETRY",
  "OTM_BREAKOUT_EXPANSION",
  "LATE_ENTRY_ANCHOR",
  "VELOCITY_STALL_REVERSAL",
  "SETTLEMENT_PREDICTION",
  // Paper fail-closed family (same as SP/LATE_ENTRY): cannot be pulled out of
  // a PATCH. Not SEV1. PAPER DESK v2 six (incl. VELOCITY_MOMENTUM / BRTI /
  // CHEAP / PANIC via Tier A) stay paper-eligible.
  "CHANNEL_BOUNCE",
  "MEAN_REVERSION_STRETCH",
  "FAKEOUT_FADE",
  "FLOOR_DISTANCE",
  "BREAKOUT_CAPTURE",
  "EXHAUSTION_ANCHOR",
  "SQUEEZE_EXPANSION",
] as const;

/** ENABLE leftover / hourly / unproven engines — true is always refused. */
export const PATCH_REFUSE_TRUE_KEYS = [
  "enable1HContracts",
  "enable1HLive",
  "candlestickPatternLiveEnabled",
  "useExpertAgent",
  "useDailyTarget",
  "settlementConsensusVoteEnabled",
  "settlementVetoEnabled",
  "velocityStallReversalEnabled",
  "bollingerBandStrategyEnabled",
  "topReversalEnabled",
  "bottomReversalEnabled",
  // Leftover ENABLE flags (CLEAN-BOT-SPEC): never arm via PATCH.
  "cheapSide15mEnabled",
  "cheapEarlyExitEnabled",
  "panicFadeEnabled",
  "streakSatFadeEnabled",
] as const;

/**
 * Keys that must never appear in an accepted PATCH — EV / Kelly / hard-risk
 * floors are admission.ts constants, not BotConfig knobs. Refusing any value
 * (including invented aliases) keeps floors immutable via patch.
 */
export const PATCH_REFUSE_FLOOR_KEYS = [
  "evFloor",
  "EV_FLOOR",
  "otmEvFloor",
  "OTM_EV_FLOOR",
  "minEVCents",
  "minEvCents",
  "kellyFraction",
  "kellyCap",
  "maxKellyFraction",
  "kellyFracCap",
  "maxRiskPctPerTrade",
  "maxDailyLossPct",
  "HARD_RISK_LIMITS",
  "DAILY_HALT_PCT",
  "DAILY_HALT_FLOOR_CENTS",
] as const;

export type PatchRefuse = { key: string; value: unknown; reason: string };

export type ConfigPatchSanitize = {
  accepted: Record<string, unknown>;
  refused: PatchRefuse[];
  notes: string[];
};

/** Exact operator phrase required to accept paperMode:false or enable1HLive:true. */
export const LIVE_REAL_MONEY_PHRASE = "LIVE REAL MONEY";
/**
 * HARD LOCK: this build is a paper-only desk. There is intentionally no env
 * var, config key or phrase that flips it; leaving paper requires a reviewed
 * code change to this constant (and composer-lock / config-persist follow it).
 */
export const PAPER_ONLY_DESK = true as const;
export const CONFIRM_LIVE_REAL_MONEY_KEY = "confirmLiveRealMoney";
export const CONFIRM_AUTO_MODE_PHRASE = "CONFIRM AUTO MODE";
export const CONFIRM_AUTO_MODE_KEY = "confirmAutoMode";

export function hasLiveRealMoneyConfirm(
  partial: Record<string, unknown> | null | undefined,
): boolean {
  return !!partial && partial[CONFIRM_LIVE_REAL_MONEY_KEY] === LIVE_REAL_MONEY_PHRASE;
}

export function hasAutoModeConfirm(
  partial: Record<string, unknown> | null | undefined,
): boolean {
  return !!partial && partial[CONFIRM_AUTO_MODE_KEY] === CONFIRM_AUTO_MODE_PHRASE;
}

export function sanitizeConfigPatch(
  partial: Record<string, unknown> | null | undefined,
  reference?: object,
): ConfigPatchSanitize {
  const accepted: Record<string, unknown> = {};
  const refused: PatchRefuse[] = [];
  const notes: string[] = [];
  if (!partial || typeof partial !== "object" || Array.isArray(partial)) {
    return { accepted, refused, notes };
  }

  const liveConfirmed = hasLiveRealMoneyConfirm(partial);
  const autoModeConfirmed = hasAutoModeConfirm(partial);

  for (const [key, value] of Object.entries(partial)) {
    if (key === CONFIRM_LIVE_REAL_MONEY_KEY) {
      // Keep the phrase on accepted so a second sanitize (updateConfig) still
      // sees it. Callers must strip before merging into BotConfig.
      if (liveConfirmed) accepted[key] = value;
      continue;
    }
    if (key === CONFIRM_AUTO_MODE_KEY) {
      if (autoModeConfirmed) accepted[key] = value;
      continue;
    }
    if (key === "enabled") {
      notes.push("enabled ignored — use the start/stop controls for runtime state");
      continue;
    }
    if (reference) {
      const schema = reference as Record<string, unknown>;
      if (!Object.prototype.hasOwnProperty.call(schema, key)) {
        refused.push({ key, value, reason: "unknown config key" });
        continue;
      }
      const expected = schema[key];
      const nullableNumber = key === "frozenCcFixedContracts" || key === "frozenCcTakeProfitCents";
      const valid = nullableNumber
        ? value === null || (typeof value === "number" && Number.isFinite(value) && value > 0)
        : key === "manualRiskProfile"
          ? value === null || (typeof value === "string" && ["CONSERVATIVE", "BALANCED", "AGGRESSIVE", "RECOVERY"].includes(value))
        : key === "strategyOverride"
          ? value === null || typeof value === "string"
          : Array.isArray(expected)
            ? Array.isArray(value) && value.every(item => typeof item === "string")
            : expected === null
              ? value === null
              : typeof value === typeof expected && (typeof value !== "number" || Number.isFinite(value));
      if (!valid) {
        refused.push({ key, value, reason: "config value has the wrong type or is not finite" });
        continue;
      }
    }
    if (key === "autoMode" && value === true) {
      if (!autoModeConfirmed) {
        refused.push({
          key,
          value,
          reason: 'autoMode true refused on paper desk — type CONFIRM AUTO MODE to arm Adapt',
        });
        continue;
      }
      accepted[key] = value;
      continue;
    }
    if ((PATCH_REFUSE_FLOOR_KEYS as readonly string[]).includes(key)) {
      refused.push({
        key,
        value,
        reason: `${key} refused — EV/Kelly/9%/18% floors are immutable via patch`,
      });
      continue;
    }
    if (key === "paperMode") {
      // HARD LOCK (unify 2026-09-24): this desk is PAPER ONLY. No patch —
      // not even with the LIVE REAL MONEY phrase — can set paperMode to
      // anything but boolean true. Falsy non-booleans (0, null, "", "false")
      // used to be accepted verbatim and read as live by truthiness checks.
      if (value === true) { accepted[key] = true; continue; }
      refused.push({
        key,
        value,
        reason: PAPER_ONLY_DESK
          ? "paperMode must be true — paper-only desk (hard lock; LIVE REAL MONEY cannot unlock via patch)"
          : liveConfirmed ? "paperMode must be a boolean" : "paperMode false refused until operator says LIVE REAL MONEY",
      });
      continue;
    }
    // Desk money-machine lock: frozenCcMode stays true across PATCH/bounce.
    // Promote-off is a dedicated script, not a dashboard Save.
    if (key === "frozenCcMode" && value === false) {
      refused.push({
        key,
        value,
        reason: "frozenCcMode false refused — desk FROZEN_CC money-machine lock (ask 20–55)",
      });
      continue;
    }
    if (key === "enable1HLive" && value === true) {
      // Even with LIVE REAL MONEY, hourly live stays refuse-true (PATCH_REFUSE_TRUE).
      // Phrase only unlocks paperMode; enable1HLive remains fail-closed.
      refused.push({
        key,
        value,
        reason: "enable1HLive=true refused (standing order fail-closed — no hourly ENABLE)",
      });
      continue;
    }
    if (key === "autoModeV2Mode" && value === "bounded_write") {
      refused.push({
        key,
        value,
        reason: "autoMode v2 bounded_write not implemented — staying suggest-only",
      });
      continue;
    }
    if (key === "specialistPacksMode" && value === "enforce") {
      refused.push({
        key,
        value,
        reason: "specialistPacksMode enforce refused — packs cannot rewrite floors",
      });
      continue;
    }
    if (key === "dailyTargetPct" && typeof value === "number" && Number.isFinite(value) && value > 8) {
      refused.push({
        key,
        value,
        reason: "dailyTargetPct > 8 refused (50% target cannot silently arm)",
      });
      continue;
    }
    if (key === "reservePct" && typeof value === "number" && Number.isFinite(value) && value < 15) {
      refused.push({
        key,
        value,
        reason: "reservePct < 15 refused",
      });
      continue;
    }
    if ((PATCH_REFUSE_TRUE_KEYS as readonly string[]).includes(key) && value === true) {
      refused.push({
        key,
        value,
        reason: `${key}=true refused (standing order fail-closed)`,
      });
      continue;
    }
    if (key === "disabledStrategies") {
      const incoming = Array.isArray(value)
        ? value.filter((x): x is string => typeof x === "string")
        : [];
      const next = [...new Set([...incoming, ...PATCH_FAIL_CLOSED_DISABLED])];
      const omitted = PATCH_FAIL_CLOSED_DISABLED.filter(id => !incoming.includes(id));
      if (omitted.length) {
        notes.push(`disabledStrategies unioned fail-closed: ${omitted.join(",")}`);
      }
      accepted[key] = next;
      continue;
    }
    // P0: never silently drop frozenCcMode true from PATCH/PUT / updateBotConfig.
    // false already refused above (money-machine lock). Only strict true is accepted;
    // loose values are refused so they cannot overwrite a live true with false.
    if (key === "frozenCcMode") {
      if (value === true) {
        accepted[key] = true;
      } else {
        refused.push({
          key,
          value,
          reason: "frozenCcMode must be boolean true — false/loose refused (desk money-machine lock)",
        });
      }
      continue;
    }
    if (
      key === "frozenCcFixedContracts"
      || key === "frozenCcTakeProfitCents"
      || key === "frozenCcCatastrophicCents"
      || key === "frozenCcSaved"
    ) {
      accepted[key] = value;
      continue;
    }
    accepted[key] = value;
  }
  return { accepted, refused, notes };
}

export function refuseToggleStrategy(strategyId: string, enabled: boolean): string | null {
  if (!enabled) return null;
  if ((PATCH_FAIL_CLOSED_DISABLED as readonly string[]).includes(strategyId)) {
    return `${strategyId} enable refused (fail-closed / SEV1 / LATE_ENTRY)`;
  }
  return null;
}
