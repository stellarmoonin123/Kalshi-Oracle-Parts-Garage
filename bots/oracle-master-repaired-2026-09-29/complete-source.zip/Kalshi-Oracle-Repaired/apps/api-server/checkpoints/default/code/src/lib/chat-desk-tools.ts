/**
 * chat-desk-tools.ts — read-only desk tools for the chat agent (round 2),
 * plus propose_fix (→ chat-pr.ts). Every result is compacted/truncated so a
 * turn fits the free-tier token budget.
 */
import { deskKnowledgeText } from "./desk-knowledge.js";
import fs from "node:fs";
import path from "node:path";
import { runChatCodeTool, resolveDeskRoot } from "./chat-code-edit.js";
import { proposePatchPr } from "./chat-pr.js";
import { truncateForModel, type ToolSpec } from "./chat-router.js";
import { deskDataPath } from "./desk-data-dir.js";

export interface DeskToolDeps {
  getStatus: () => any;
  getRecentTrades: (n: number) => Promise<unknown>;
  getRecentLogs?: (n: number) => unknown[];
  healthz?: () => Promise<unknown>;
  deskRoot?: string;
  dataDir?: string;
  userMessage?: string;
  env?: NodeJS.ProcessEnv;
  fetchImpl?: typeof fetch;
}

const obj = (props: Record<string, unknown> = {}, required: string[] = []) => ({ type: "object", properties: props, required });

export const DESK_TOOL_SPECS: ToolSpec[] = [
  { name: "get_status", description: "Compact live desk status: state, paper balance, P&L, open position, regime, last signal, locks.", parameters: obj() },
  { name: "get_entry_funnel", description: "Since-boot entry funnel counts (TAKE_SIGNAL vs BLOCK/SKIP reasons).", parameters: obj() },
  { name: "get_positions", description: "Open paper position (if any) and account position audit.", parameters: obj() },
  { name: "get_recent_trades", description: "Last N bot trades (default 8, max 20).", parameters: obj({ n: { type: "number" } }) },
  { name: "get_decision_traces", description: "Last N evaluate decision-trace rows (default 10, max 30); optional reason filter substring.", parameters: obj({ n: { type: "number" }, reason: { type: "string" } }) },
  { name: "get_calibration", description: "Mind calibration / healthz calibration summary.", parameters: obj() },
  { name: "get_desk_knowledge", description: "Dated standing knowledge (releases, default checkpoint, hard locks, calibration gate, settlement audit, open issues, reporting rules). Historical: prefer live tools when they disagree.", parameters: obj({ section: { type: "string" } }) },
  { name: "get_healthz", description: "Server /healthz summary (DB, WS, MTF, watchdog).", parameters: obj() },
  { name: "tail_log", description: "Last N bot log lines (default 30, max 80); optional grep substring.", parameters: obj({ n: { type: "number" }, grep: { type: "string" } }) },
  { name: "search_code", description: "Case-insensitive literal search in desk source (optionally under a path).", parameters: obj({ query: { type: "string" }, path: { type: "string" } }, ["query"]) },
  { name: "read_file", description: "Read a desk source file; use start_line/end_line (≤200 lines).", parameters: obj({ path: { type: "string" }, start_line: { type: "number" }, end_line: { type: "number" } }, ["path"]) },
  { name: "list_dir", description: "List a desk directory.", parameters: obj({ path: { type: "string" } }) },
  { name: "propose_fix", description: "Propose a code fix as a git-style unified diff (paths from repo root). The server validates it (hard-lock files/params are refused), runs targeted tests in a temp copy, and opens a DRAFT GitHub PR on a new branch if configured; otherwise returns the validated patch. Never merges or deploys.", parameters: obj({ title: { type: "string" }, patch: { type: "string" }, body: { type: "string" } }, ["title", "patch"]) },
];

function clampN(v: unknown, d: number, max: number): number {
  const n = Math.floor(Number(v));
  return Number.isFinite(n) && n > 0 ? Math.min(n, max) : d;
}

function compactStatus(s: any): Record<string, unknown> {
  const c = s?.config ?? {};
  return {
    state: s?.state, paperMode: c.paperMode, frozenCcMode: c.frozenCcMode,
    paperBalance$: typeof s?.paperVirtualBalanceCents === "number" ? (s.paperVirtualBalanceCents / 100).toFixed(2) : null,
    paperPnlCents: s?.paperPnlCents, wins: s?.paperWins, losses: s?.paperLosses,
    reservePool$: typeof s?.reservePoolCents === "number" ? (s.reservePoolCents / 100).toFixed(2) : null,
    dailyLossHalt: s?.dailyLossHalt
      ? { halted: s.dailyLossHalt.halted, today$: (s.dailyLossHalt.dayPnlCents / 100).toFixed(2), cap$: (s.dailyLossHalt.capCents / 100).toFixed(2), etDay: s.dailyLossHalt.etDay }
      : null,
    openTrade: s?.openTrade ? { ticker: s.openTrade.ticker, side: s.openTrade.side, contracts: s.openTrade.contracts, entry: s.openTrade.entryPriceCents } : null,
    ticker: s?.activeTicker ?? s?.ticker, secsRemaining: s?.secsRemaining, regime: s?.detectedRegime,
    lastSignal: typeof s?.lastSignal === "string" ? s.lastSignal.slice(0, 200) : null,
    gitSha: s?.gitSha ?? null, paperRecovery: s?.paperRecoveryInspection?.code ?? null,
  };
}

/** Drop bulky incident timestamp arrays from a healthz subsystem block. */
function slimSubsystem(v: any): unknown {
  if (!v || typeof v !== "object") return v ?? null;
  const { incidentTimestamps: _drop, ...rest } = v;
  void _drop;
  return rest;
}

/** Real /healthz shape: { healthy, build: { gitSha }, watchdog: { subsystems }, subsystems: { database, websocket, calib, calibration, … } }. */
export function summarizeHealthz(h: any): Record<string, unknown> {
  const sub = h?.subsystems ?? {};
  return {
    healthy: h?.healthy,
    gitSha: h?.build?.gitSha ?? null,
    watchdog: h?.watchdog?.subsystems ?? null,
    db: slimSubsystem(sub.database ?? h?.database ?? h?.db),
    ws: slimSubsystem(sub.websocket ?? h?.ws ?? h?.websocket),
    bot: sub.bot ?? null,
    balance: slimSubsystem(sub.balance),
    position: slimSubsystem(sub.position),
    mindCalibration: sub.calib ?? null,
    error: h?.error,
  };
}

/** Mind calibration (shadow/fill ECE gate) + settlement-model accuracy from /healthz. */
export function summarizeCalibration(h: any): Record<string, unknown> | null {
  const sub = h?.subsystems ?? {};
  const mind = sub.calib ?? h?.mindCalibration ?? null;
  const model = sub.calibration ?? h?.calibration ?? null;
  if (!mind && !model) return null;
  return {
    mind,
    settlementModel: model && typeof model === "object"
      ? { brierScore: model.brierScore ?? null, brierSamples: model.brierSamples ?? null, directionThreshold: model.directionThreshold ?? null, buckets: model.buckets ?? null }
      : null,
  };
}

function tailJsonl(file: string, n: number, filter?: string): unknown[] {
  try {
    const st = fs.statSync(file);
    const len = Math.min(st.size, 400_000);
    const fd = fs.openSync(file, "r");
    const buf = Buffer.alloc(len);
    fs.readSync(fd, buf, 0, len, st.size - len);
    fs.closeSync(fd);
    const lines = buf.toString("utf8").split("\n").filter(Boolean).slice(1);
    const rows = (filter ? lines.filter((l) => l.toLowerCase().includes(filter.toLowerCase())) : lines).slice(-n);
    return rows.map((l) => { try { return JSON.parse(l); } catch { return l.slice(0, 300); } });
  } catch { return []; }
}

export async function runDeskTool(name: string, args: Record<string, unknown>, deps: DeskToolDeps): Promise<string> {
  const deskRoot = deps.deskRoot ?? resolveDeskRoot();
  const dataDir = deps.dataDir ?? path.join(deskRoot, "apps/api-server/data");
  const out = await (async (): Promise<unknown> => {
    switch (name) {
      case "get_status": return compactStatus(deps.getStatus());
      case "get_entry_funnel": return deps.getStatus()?.entryFunnel ?? { note: "entryFunnel not available" };
      case "get_positions": { const s = deps.getStatus(); return { openTrade: s?.openTrade ?? null, positionState: s?.positionState ?? null, accountPositionState: s?.accountPositionState ?? null }; }
      case "get_recent_trades": {
        const rows = await Promise.race([deps.getRecentTrades(clampN(args.n, 8, 20)), new Promise((r) => setTimeout(() => r([]), 3000))]);
        // entry = actual fill (paper sim updates entryPriceCents to the fill); slip = fill − signal-time price.
        return (Array.isArray(rows) ? rows : []).map((t: any) => ({
          id: t.id, ticker: t.ticker, side: t.side, n: t.contractsFilled ?? t.contracts, strategy: t.strategyId ?? null,
          entry: t.fillPriceCents ?? t.entryPriceCents, slip: t.slippageCents ?? null,
          exitPx: t.exitMktPrice ?? null, exit: t.exitReason, fee: t.feeCents ?? null,
          outcome: t.outcome, pnlFeeNet: t.pnlCents, settled: t.settledSide ?? null,
          at: t.createdAt, closedAt: t.settledAt ?? null, paper: t.isPaper ?? t.paper ?? null,
        }));
      }
      case "get_decision_traces": return tailJsonl(path.join(dataDir, "evaluate-decision-trace.jsonl"), clampN(args.n, 10, 30), typeof args.reason === "string" ? args.reason : undefined)
        .map((r: any) => (r && typeof r === "object" ? { ts: r.ts, ticker: r.ticker, side: r.sideOrSkip, outcome: r.outcome, reason: r.skipReason, pWin: r.pWin, ev: r.evCents, yesAsk: r.yesAsk, noAsk: r.noAsk } : r));
      case "get_calibration": {
        const h: any = deps.healthz ? await deps.healthz().catch(() => null) : null;
        const summary = summarizeCalibration(h);
        if (summary) return summary;
        const file = deps.dataDir ? path.join(dataDir, "mind-calibration.jsonl") : deskDataPath("mind-calibration.jsonl");
        const rows = tailJsonl(file, 5);
        return rows.length ? { recentRows: rows } : { note: "calibration not available (healthz had no calib block and no mind-calibration.jsonl rows)" };
      }
      case "get_desk_knowledge": return deskKnowledgeText(typeof args.section === "string" ? args.section : null);
      case "get_healthz": {
        const h: any = deps.healthz ? await deps.healthz().catch((e) => ({ error: String(e?.message ?? e) })) : { error: "healthz not wired" };
        return summarizeHealthz(h);
      }
      case "tail_log": {
        const n = clampN(args.n, 30, 80);
        const g = typeof args.grep === "string" ? args.grep.toLowerCase() : "";
        const logs = (deps.getRecentLogs?.(200) ?? []) as any[];
        return logs.filter((l) => !g || String(l?.message ?? l).toLowerCase().includes(g)).slice(-n).map((l) => `${l?.level ?? ""} ${String(l?.message ?? l).slice(0, 220)}`);
      }
      case "search_code": return runChatCodeTool("grep", { pattern: args.query, path: args.path ?? "apps/api-server/src" }, { userMessage: deps.userMessage ?? "", deskRoot });
      case "read_file": {
        const start = clampN(args.start_line, 1, 1_000_000);
        const end = Math.min(clampN(args.end_line, start + 119, 1_000_000), start + 199);
        return runChatCodeTool("read_file", { path: args.path, start_line: start, end_line: end }, { userMessage: deps.userMessage ?? "", deskRoot });
      }
      case "list_dir": return runChatCodeTool("list_dir", { path: args.path ?? "." }, { userMessage: deps.userMessage ?? "", deskRoot });
      case "propose_fix": return proposePatchPr({ patch: String(args.patch ?? ""), title: String(args.title ?? "chat fix"), body: typeof args.body === "string" ? args.body : undefined, userMessage: deps.userMessage }, { deskRoot, env: deps.env, fetchImpl: deps.fetchImpl });
      default: return { refused: true, reason: `unknown or non-read-only tool: ${name}` };
    }
  })();
  return truncateForModel(typeof out === "string" ? out : JSON.stringify(out));
}
