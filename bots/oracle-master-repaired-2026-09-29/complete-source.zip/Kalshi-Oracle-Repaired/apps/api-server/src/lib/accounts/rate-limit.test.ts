import { test } from "node:test";
import assert from "node:assert/strict";
import { FixedWindowCounter } from "./rate-limit.js";

test("counter saturation refuses new identifiers without evicting blocked ones", () => {
  const c = new FixedWindowCounter(2, 1000, 2);
  c.add("a", 0); c.add("a", 0); c.add("b", 0);
  assert.equal(c.isBlocked("a", 1), true);
  assert.equal(c.isBlocked("unknown", 1), true);
  c.add("unknown", 1);
  assert.equal(c.isBlocked("a", 1), true);
  assert.ok(c.retryAfterSec("unknown", 1) > 0);
  assert.equal(c.isBlocked("new", 1001), false);
  c.add("new", 1001);
  assert.equal(c.isBlocked("new", 1001), false);
});

test("expired identifier slots are reusable without deleting active counters", () => {
  const c = new FixedWindowCounter(2, 1000, 2);
  c.add("old", 0); c.add("active", 500); c.add("active", 500);
  c.add("new", 1001);
  assert.equal(c.isBlocked("active", 1001), true);
  assert.equal(c.isBlocked("new", 1001), false);
});
