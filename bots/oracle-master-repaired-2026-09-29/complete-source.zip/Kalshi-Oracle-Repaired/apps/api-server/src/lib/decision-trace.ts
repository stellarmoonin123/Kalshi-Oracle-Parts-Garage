import { kalshiTakerFeeCents, breakevenWinRate as kalshiBreakevenWinRate } from "./fees/kalshi-fee.js";
// GO — SPECIALIST REGIME SYSTEM, Phase 0 (DecisionTrace, behavior-neutral).
//
// This module never gates, sizes, or vetoes a trade. It only observes and
// records what the existing pipeline already decided, under a small closed
// taxonomy of skip codes, so later phases (packs, provenance/cell stats)
// have a stable join key (`traceId`) and a stable vocabulary to build on.
//
// L6 (fail closed): any error here must never affect trading. Every
// exported function that touches the DB swallows its own errors, exactly
// like the existing `logSkippedDecision`/`recordSkippedMetaExample` pattern
// it sits alongside.

import { randomUUID } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { db, decisionTraces } from "@workspace/db";
import { appendEvaluateDecision, honestPWin } from "./evaluate-decision-tape.js";
import { persistSkipPricing } from "./persist-skip-pricing.js";

/**
 * The closed skip-code taxonomy from the spec. Every rejection reason string
 * used anywhere in the live decision pipeline must map onto exactly one of
 * these — see CLOSED_CODE_MAP / mapToClosedCode below. `OTHER` is not a bug
 * bucket to be "fixed away": most of today's ~30 granular rejection codes
 * predate this taxonomy and describe filters (price bands, spread gates,
 * manual disables, ARIA/settlement vetoes, ...) that don't cleanly belong to
 * any of the other 9 — that is exactly what OTHER is for.
 */
export type ClosedSkipCode =
  | "FEED_DEAD"
  | "PACK_SILENT"
  | "CONSENSUS"
  | "CONF_FLOOR"
  | "EV_FAIL"
  | "QUOTE_STALE"
  | "SIZE_ZERO"
  | "DAILY_HALT"
  | "REGIME_HOLD"
  | "OTHER";

export const CLOSED_SKIP_CODES: readonly ClosedSkipCode[] = [
  "FEED_DEAD", "PACK_SILENT", "CONSENSUS", "CONF_FLOOR", "EV_FAIL",
  "QUOTE_STALE", "SIZE_ZERO", "DAILY_HALT", "REGIME_HOLD", "OTHER",
];

/**
 * Direct code → closed-code mapping for the pre-existing, unambiguous
 * rejection codes (grep-audited against every `logSkippedDecision(...)` call
 * site in trading-bot.ts as of Phase 0). PACK_SILENT has no direct source
 * yet — it is defined for Phase 2 (a pack whose entire eligible-strategy set
 * stays STAY_OUT) and cannot fire until specialist packs exist.
 *
 * Two codes — PATH_GATE and PRETRADE_SIM — are current grab-bags that wrap
 * several sub-reasons behind one string (regime-EV, protect mode, hard
 * filters, EV floor, and the pre-trade Monte Carlo/consensus check, or
 * ARIA DANGER). Those are resolved by `mapToClosedCode`'s content-sniffing
 * branch below rather than a 1:1 table entry.
 */
const DIRECT_CLOSED_CODE_MAP: Record<string, ClosedSkipCode> = {
  // Confidence-floor family
  CONFIDENCE_FLOOR: "CONF_FLOOR",
  PROTECT_MODE: "CONF_FLOOR",       // protect mode's "A+ setups only" is a raised confidence bar

  // EV/economics family
  EV_PRE_CHECK: "EV_FAIL",
  EV_FLOOR: "EV_FAIL",
  REGIME_EV_FILTER: "EV_FAIL",
  OTM_EV_NO_EDGE: "EV_FAIL",
  OTM_EV_FLOOR: "EV_FAIL",

  // Regime family
  STRATEGY_REGIME_BLOCK: "REGIME_HOLD",

  // Quote-freshness family (post-sim admission point)
  QUOTE_STALE_POST_SIM: "QUOTE_STALE",
  QUOTE_MOVED_POST_SIM: "QUOTE_STALE",

  // Feed/data-freshness family — an account-data feed being stale is the
  // same underlying failure mode as a stale price feed for this taxonomy's
  // purposes (something the bot depends on stopped updating).
  BALANCE_STALE: "FEED_DEAD",

  // Sizing-collapses-to-zero family
  SIZING_ZERO: "SIZE_ZERO",
  RISK_PROFILE: "SIZE_ZERO",
  DAILY_TARGET_SIZE_ZERO: "SIZE_ZERO",
  DRAWDOWN_GUARD: "SIZE_ZERO",

  // Daily/session halt family
  DAILY_TARGET_LATE_BLOCK: "DAILY_HALT",
  // DAILY-LOSS HALT COVERAGE FIX: the loss-cap circuit breaker's own admission
  // check (shared by _placeOrderBody for both the 15m and hourly paths).
  DAILY_LOSS_HALT: "DAILY_HALT",

  // Agent control plane (operator stamps — map to closed taxonomy)
  AGENT_HALT: "DAILY_HALT",
  AGENT_SKIP_NEXT: "OTHER",
  AGENT_SIT: "REGIME_HOLD",
  AGENT_REJECTED: "OTHER",
  AGENT_TIMEOUT: "OTHER",
  AGENT_STALE: "QUOTE_STALE",
  AGENT_PENDING: "OTHER",
  BRAIN_CENTER_VETO: "REGIME_HOLD",
  MIND_HEAVE_BIND: "REGIME_HOLD",
  MIND_HEAVE_ADVISORY: "OTHER",
  AGENT_APPROVED: "OTHER",
};

/**
 * Maps an existing raw rejection code (+ optional free-text reasons, for the
 * grab-bag codes) onto the closed taxonomy. Never returns undefined — an
 * unrecognized code falls through to OTHER rather than throwing, so a
 * future new call site can never break trace persistence.
 */
export function mapToClosedCode(code: string, reasons: readonly string[] = []): ClosedSkipCode {
  const direct = DIRECT_CLOSED_CODE_MAP[code];
  if (direct) return direct;

  if (code === "PATH_GATE" || code === "PRETRADE_SIM") {
    const text = reasons.join(" ").toLowerCase();
    if (text.includes("vol buffer stale") || text.includes("feed")) return "FEED_DEAD";
    if (text.includes("consensus") || text.includes("pre-trade sim rejected") || text.includes("score")) return "CONSENSUS";
    return "EV_FAIL";
  }

  return "OTHER";
}

/** Minimum DecisionTrace fields per spec, plus a few audit-only extras
 *  (rawCode, ticker/strategyId/side) that don't conflict with the spec and
 *  make the persisted row usable on its own without a join. */
export interface DecisionTrace {
  traceId: string;
  ts: number;
  ticker: string;
  side?: "yes" | "no";
  secsLeft?: number;
  regime?: string;
  regimeHeldBy?: string;
  pack?: string;              // undefined until Phase 2
  V?: number;
  V_bucket?: string;
  strategyId?: string;        // `best`
  eligible?: string[];        // undefined until Phase 2
  agree?: number;
  ask?: number;
  /** D4 — top-of-book YES/NO asks at decision time (cents). Undefined = unknown. */
  yesAsk?: number | null;
  noAsk?: number | null;
  /** Proposed contract count. NOT a probability. Kelly/EV p is `pWin`. */
  pSize?: number | null;
  /** winRateAtPrice (0–1). The p used by PATH_GATE / Kelly. Never confidence. */
  pWin?: number | null;
  /** Heuristic signal score (0–100 or 0–1). Never used as p for EV/Kelly. */
  signalConfidence?: number;
  evCents?: number;
  uMult?: number;
  volMult?: number;
  packCap?: number;           // undefined until Phase 2
  combinedMult?: number;
  contracts?: number;
  /** FEE ORGAN — order-level taker fee cents at ask × contracts (C=1 if size unknown). */
  feeCents?: number;
  /** FEE ORGAN — fee-only breakeven win rate 0–1. */
  breakevenWR?: number;
  outcome: "ORDER" | "SKIP";
  code?: ClosedSkipCode;      // set for SKIP, undefined for ORDER
  rawCode?: string;
  chain: string[];
  botTradeId?: number | null;
}

/** Generates a new per-decision trace id. One per evaluateEntry() /
 *  considerAddingToPosition() / _evaluateHourlyTickBody() invocation —
 *  callers must capture it in a local const at the top of the function and
 *  thread it through every logSkippedDecision/placeOrder call made during
 *  that same invocation, never share it across ticks (see trading-bot.ts
 *  call sites). */
/** D4 — asks outside (0,100) are "no book" sentinels (0/100), not prices. */
export function finiteAskOrNull(a: number | null | undefined): number | null {
  return a != null && Number.isFinite(a) && a > 0 && a < 100 ? a : null;
}

export function generateTraceId(): string {
  return randomUUID();
}

/**
 * Pricing snapshot that keeps the three "p"s distinct:
 *   pWin             — winRateAtPrice (PATH_GATE / Kelly). Never confidence.
 *   signalConfidence — heuristic signal score. Never used as p.
 *   pSizeContracts   — proposed contract count (DB column p_size). NOT a probability.
 *
 * Stored on decision_traces.pricing jsonb (no schema migration). The integer
 * `p_size` column remains the contract count for existing consumers.
 */
export function namedTracePricing(
  trace: Pick<DecisionTrace, "pWin" | "signalConfidence" | "pSize" | "evCents" | "feeCents" | "breakevenWR">,
): Record<string, unknown> {
  return {
    pWin: trace.pWin ?? null,
    signalConfidence: trace.signalConfidence ?? null,
    pSizeContracts: trace.pSize ?? null,
    evCents: trace.evCents ?? null,
    feeCents: trace.feeCents ?? null,
    breakevenWR: trace.breakevenWR ?? null,
  };
}

/**
 * Persists a DecisionTrace row. Per spec: unconditional for every ORDER
 * outcome, and for every SKIP whose closed code is EV_FAIL or SIZE_ZERO —
 * those are the two outcomes where "we almost traded and didn't" carries
 * real economic signal. Other SKIP codes are not written here in Phase 0
 * (bot_trade_skips remains their complete, throttled record) — packs
 * (Phase 2) will widen this list to include CONSENSUS/PACK_SILENT.
 *
 * Never throws — a DB failure here must never affect trading, same
 * contract as logSkippedDecision.
 */
export async function persistDecisionTrace(trace: DecisionTrace): Promise<void> {
  // CC/LAG skips that omitted pWin must still persist winRateAtPrice + EV
  // (not a fake missing-curve). Observational; never gates.
  const priced = persistSkipPricing({
    strategyId: trace.strategyId,
    ask: trace.ask,
    secsLeft: trace.secsLeft,
    pWin: trace.pWin,
    evCents: trace.evCents,
    signalConfidence: trace.signalConfidence,
  });
  const pWin = priced.pWin ?? honestPWin(trace.pWin);
  const evCents = priced.evCents ?? (trace.evCents ?? null);
  const signalConfidence = priced.signalConfidence ?? trace.signalConfidence;
  const feeContracts = Math.max(1, trace.contracts ?? trace.pSize ?? 1);
  const feeCents = trace.feeCents ?? (
    trace.ask != null && Number.isFinite(trace.ask)
      ? kalshiTakerFeeCents(trace.ask, feeContracts)
      : undefined
  );
  const breakevenWR = trace.breakevenWR ?? (
    trace.ask != null && Number.isFinite(trace.ask)
      ? kalshiBreakevenWinRate(trace.ask, feeContracts)
      : undefined
  );
  const traceWithFee: DecisionTrace = { ...trace, pWin: pWin ?? undefined, evCents: evCents ?? undefined, signalConfidence, feeCents, breakevenWR };
  try {
    appendEvaluateDecision({
      kind: "evaluate_decision",
      ts: trace.ts,
      ticker: trace.ticker,
      R_t: null,
      packId: trace.pack ?? null,
      sideOrSkip: trace.side ?? "skip",
      outcome: trace.outcome === "ORDER" ? "TAKE" : "SKIP",
      pWin,
      evCents,
      yesAsk: finiteAskOrNull(trace.yesAsk ?? (trace.side === "yes" ? trace.ask : undefined)),
      noAsk: finiteAskOrNull(trace.noAsk ?? (trace.side === "no" ? trace.ask : undefined)),
      fillAsk: finiteAskOrNull(trace.ask),
      strategyId: trace.strategyId ?? null,
      skipReason: trace.rawCode ?? trace.code ?? null,
      rawCode: trace.rawCode ?? null,
      liveApply: false,
    });
  } catch {
    /* observational jsonl */
  }
  if (trace.outcome === "SKIP" && trace.code !== "EV_FAIL" && trace.code !== "SIZE_ZERO") return;
  try {
    await db.insert(decisionTraces).values({
      traceId: trace.traceId,
      ticker: trace.ticker,
      side: trace.side ?? null,
      secsLeft: trace.secsLeft ?? null,
      regime: trace.regime ?? null,
      regimeHeldBy: trace.regimeHeldBy ?? null,
      pack: trace.pack ?? null,
      v: trace.V ?? null,
      vBucket: trace.V_bucket ?? null,
      strategyId: trace.strategyId ?? null,
      eligible: trace.eligible ?? null,
      agree: trace.agree ?? null,
      ask: trace.ask ?? null,
      pSize: typeof trace.pSize === "number" ? trace.pSize : undefined, // proposed contracts, NOT a probability
      evCents,
      pricing: namedTracePricing({
        ...traceWithFee,
        pWin: typeof pWin === "number" ? pWin : undefined,
        evCents: typeof evCents === "number" ? evCents : undefined,
        signalConfidence,
        feeCents,
        breakevenWR,
      }),
      uMult: trace.uMult ?? null,
      volMult: trace.volMult ?? null,
      packCap: trace.packCap ?? null,
      combinedMult: trace.combinedMult ?? null,
      contracts: trace.contracts ?? null,
      outcome: trace.outcome,
      code: trace.code ?? null,
      rawCode: trace.rawCode ?? null,
      chain: trace.chain ?? [],
      botTradeId: trace.botTradeId ?? null,
    });
  } catch {
    // Trace persistence must never affect trading (L6 fail-closed).
  }
}

// ═════════════════════════════════════════════════════════════════════════
// GO — PROFIT DOCTRINE PHASE 6 (DecisionTrace + Desk Snapshot).
//
// Widens the Phase 0 DecisionTrace table (above) from entry-only (ORDER/SKIP)
// to every decision-worthy event across an open trade's lifecycle:
// CANDIDATE | SKIP | ENTRY | ARIA | TIGHTEN | EXIT | SETTLE | RECON.
//
// This is a read/log-only observability layer — nothing here gates, sizes,
// or vetoes a trade, and every write is fail-open (a DB error here can never
// throw into the caller). CANDIDATE rows are intentionally not written by
// any call site yet (the spec allows omitting them "if noisy" — they would
// fire every tick for every strategy and add little beyond what SKIP/ENTRY
// already capture).
//
// Reuses the Phase 0 `decision_traces` table (see decision-traces.ts schema
// comments) rather than a second table, per the spec's own naming and the
// "no second market model" instruction — `outcome`/`code`/`rawCode` keep
// their exact Phase 0 meaning for existing consumers (admission-survival-
// funnel.ts, autopilot-monitor.ts); `eventType` is purely additive.
// ═════════════════════════════════════════════════════════════════════════

export type DecisionEventType =
  | "CANDIDATE" | "SKIP" | "ENTRY" | "ARIA" | "TIGHTEN" | "EXIT" | "SETTLE" | "RECON";

export interface MarketSnapshot {
  velScale?: number; zVel?: number; rangeScale?: number; volScale?: number;
  regime?: string; session?: string; tau?: number; stale?: boolean;
}
export interface BookSnapshot {
  bookClass?: string | null; spreadCents?: number | null; depthAtAsk?: number | null; imbalance?: number | null; liqAction?: string | null;
}
export interface LagSnapshot {
  projectedSettlement?: number | null;
  rollingBasis?: number | null;
  /** 1s projectedSettlement vs floor. NOT Coinbase lag-meter. */
  projAgrees?: boolean | null;
}
/**
 * Drop the leftover `lagAgrees` alias (it was 1s proj, not Coinbase lag).
 * Extra keys from older callers are stripped so traces cannot lie.
 */
export function sanitizeLagSnapshot(
  lag: (LagSnapshot & { lagAgrees?: unknown; projAgreesWithSide?: unknown }) | null | undefined,
): LagSnapshot | null {
  if (!lag) return null;
  const proj = lag.projAgrees ?? (typeof lag.projAgreesWithSide === "boolean" ? lag.projAgreesWithSide : undefined);
  const out: LagSnapshot = {};
  if (lag.projectedSettlement !== undefined) out.projectedSettlement = lag.projectedSettlement;
  if (lag.rollingBasis !== undefined) out.rollingBasis = lag.rollingBasis;
  if (proj !== undefined) out.projAgrees = proj as boolean | null;
  return out;
}

export interface AriaSnapshot {
  /** e.g. "HOLD" | "TIGHTEN" | "EXIT" — mirrors AriaDecision.action from aria-guardian.ts */
  action?: string;
  confidence?: number;
  reasons?: string[];
  /** whether this ARIA decision actually changed bot behavior (a TIGHTEN/EXIT that fired) vs. was advisory-only */
  applied?: boolean;
}
export interface ExitSnapshot {
  reasonCode?: string;
  pnlCents?: number;
  outcome?: "win" | "loss";
  authoritative?: boolean;
}

/** One P6 decision event. `traceId` is generated if omitted — callers that
 *  already have one in scope (from the same tick's entry evaluation) should
 *  pass it through so an ENTRY/SKIP row can be joined to a later ARIA/EXIT/
 *  SETTLE row for the same trade via ticker, not traceId (each event on an
 *  open trade gets its own traceId; traceId identifies one decision, not
 *  the trade's whole lifecycle — join on ticker + time window instead).
 *
 *  `tradeId` (ARIA-ADDENDUM): stable identifier for "this open trade" across
 *  repeated ARIA evaluations — String(trade.dbId ?? trade.openedAt) at every
 *  call site, never the traceId (which is per-decision, not per-trade). Only
 *  meaningful for eventType ARIA/TIGHTEN; used purely as the in-memory
 *  coalescing key, never persisted as its own column. */
export interface DecisionTraceEvent {
  traceId?: string;
  tradeId?: string;
  eventType: DecisionEventType;
  ticker: string;
  side?: "yes" | "no";
  strategyId?: string;
  family?: string;
  packId?: string;
  secsLeft?: number;
  market?: MarketSnapshot;
  book?: BookSnapshot;
  lag?: LagSnapshot;
  pricing?: Record<string, unknown>;
  sizing?: Record<string, unknown>;
  gates?: Record<string, unknown>;
  aria?: AriaSnapshot;
  exit?: ExitSnapshot;
  skipChain?: string[];
  /** free-text reasons, mirrors the Phase 0 `chain` column */
  chain?: string[];
}

/**
 * ARIA-PERSIST-COALESCE ADDENDUM (required, storage-only — never touches the
 * P5 eval rate limit).
 *
 * In-memory coalescing state for repeated ARIA HOLD/SETTLE_HOLD rows on the
 * same open trade, keyed by tradeId (falls back to ticker if a caller omits
 * tradeId). Reset when the trade closes via clearAriaCoalesceCache().
 *
 * Coalesce (bump repeatCount, no new row) only when ALL of the following
 * match the last written row for this tradeId:
 *   action, primaryReason, applied, AND now - lastTsMs <= COALESCE_MS
 * A new row is always inserted when any of those differ, the trade changes,
 * or COALESCE_MS has elapsed (a periodic heartbeat so the desk view is never
 * stale for more than the window). EXIT and TIGHTEN actions are NEVER
 * coalesced, even if they would otherwise match a cached HOLD row — only
 * HOLD and SETTLE_HOLD (the passive, no-behavior-change actions) are
 * eligible to coalesce at all.
 */
const ariaCoalesceCache = new Map<string, {
  rowId: number; tradeId: string; action: string; primaryReason: string; applied: boolean; lastTsMs: number;
}>();
/** Spec: 45_000ms exactly (not a range) — do not confuse with the separate P5 ARIA eval rate limit. */
const ARIA_COALESCE_WINDOW_MS = 45_000;
/** Only these ARIA actions may ever coalesce; TIGHTEN/EXIT always insert a fresh row. */
const COALESCIBLE_ARIA_ACTIONS = new Set(["HOLD", "SETTLE_HOLD"]);

/** Call when an open trade closes (any exit/settlement path) so the next
 *  trade starts a fresh coalescing window instead of potentially matching a
 *  stale cached row from a prior, already-closed trade. Safe to call
 *  defensively from multiple close paths; matches by tradeId when provided,
 *  otherwise clears every cache entry (ticker-less bulk clear on settlement). */
export function clearAriaCoalesceCache(tradeIdOrTicker?: string): void {
  if (tradeIdOrTicker) ariaCoalesceCache.delete(tradeIdOrTicker);
  else ariaCoalesceCache.clear();
}

/**
 * Persists one P6 decision event. Never throws (L6 fail-closed) — callers
 * must invoke this with `void`, never `await`, from any tick-critical path
 * so a DB hiccup can never add latency or a rejected promise to a live
 * trading decision.
 *
 * See the ARIA-PERSIST-COALESCE ADDENDUM above the cache declaration for the
 * exact coalescing rule applied to eventType "ARIA" with action HOLD or
 * SETTLE_HOLD. Every other event (SKIP/ENTRY/EXIT/SETTLE/RECON/CANDIDATE,
 * and ARIA rows carrying action TIGHTEN/EXIT) is always a fresh insert.
 */
export async function persistDecisionTraceEvent(evt: DecisionTraceEvent): Promise<void> {
  try {
    const traceId = evt.traceId ?? generateTraceId();
    const now = new Date();
    const nowMs = now.getTime();

    const action = evt.aria?.action ?? null;
    const applied = evt.aria?.applied ?? false;
    const primaryReason = evt.aria?.reasons?.[0] ?? "";
    const cacheKey = evt.tradeId ?? evt.ticker;
    const isCoalescible = evt.eventType === "ARIA" && action != null && COALESCIBLE_ARIA_ACTIONS.has(action);

    if (isCoalescible) {
      const cached = ariaCoalesceCache.get(cacheKey);
      if (cached && cached.tradeId === cacheKey && cached.action === action
          && cached.primaryReason === primaryReason && cached.applied === applied
          && nowMs - cached.lastTsMs <= ARIA_COALESCE_WINDOW_MS) {
        cached.lastTsMs = nowMs;
        await db.update(decisionTraces)
          .set({ repeatCount: sql`${decisionTraces.repeatCount} + 1`, ts: now })
          .where(eq(decisionTraces.id, cached.rowId));
        return;
      }
      const inserted = await db.insert(decisionTraces).values({
        traceId, ts: now, ticker: evt.ticker, side: evt.side ?? null,
        strategyId: evt.strategyId ?? null, family: evt.family ?? null, pack: evt.packId ?? null,
        secsLeft: evt.secsLeft ?? null, outcome: "ORDER" /* legacy column — not meaningful for ARIA/TIGHTEN, kept non-null */,
        eventType: evt.eventType, market: evt.market ?? null, book: evt.book ?? null, lag: sanitizeLagSnapshot(evt.lag),
        pricing: evt.pricing ?? null, sizing: evt.sizing ?? null, gatesInfo: evt.gates ?? null,
        aria: evt.aria ?? null, exitInfo: evt.exit ?? null, skipChain: evt.skipChain ?? null,
        chain: evt.chain ?? [], repeatCount: 1,
      }).returning({ id: decisionTraces.id });
      const rowId = inserted[0]?.id;
      if (rowId != null) {
        ariaCoalesceCache.set(cacheKey, { rowId, tradeId: cacheKey, action: action ?? "", primaryReason, applied, lastTsMs: nowMs });
      }
      return;
    }

    // Every other event (SKIP/ENTRY/EXIT/SETTLE/RECON/CANDIDATE, and ARIA
    // rows whose action is TIGHTEN/EXIT) is a plain insert — no coalescing,
    // since each represents a distinct, individually meaningful occurrence
    // rather than a repeated poll result. Per the addendum, TIGHTEN and EXIT
    // must never be merged into a prior HOLD row even if one is cached.
    const evtPricing = evt.pricing ?? null;
    let skipPricing = evtPricing;
    if (evt.eventType === "SKIP") {
      const rec = (evtPricing ?? {}) as Record<string, unknown>;
      const ask = typeof rec.askCents === "number" ? rec.askCents
        : typeof rec.ask === "number" ? rec.ask : undefined;
      const filled = persistSkipPricing({
        strategyId: evt.strategyId,
        ask,
        secsLeft: evt.secsLeft,
        pWin: typeof rec.pWin === "number" ? rec.pWin : null,
        evCents: typeof rec.evCents === "number" ? rec.evCents
          : typeof rec.netEvCents === "number" ? rec.netEvCents : null,
        signalConfidence: typeof rec.signalConfidence === "number" ? rec.signalConfidence : null,
      });
      skipPricing = {
        ...rec,
        pWin: filled.pWin,
        evCents: filled.evCents,
        netEvCents: filled.evCents,
        signalConfidence: filled.signalConfidence,
        pSource: filled.pSource,
      };
    }
    await db.insert(decisionTraces).values({
      traceId, ts: now, ticker: evt.ticker, side: evt.side ?? null,
      strategyId: evt.strategyId ?? null, family: evt.family ?? null, pack: evt.packId ?? null,
      secsLeft: evt.secsLeft ?? null,
      // Legacy `outcome` column stays populated so existing ORDER/SKIP-filtered
      // consumers keep working: ENTRY maps to 'ORDER', SKIP stays 'SKIP',
      // every other new event type gets a non-null placeholder that those
      // consumers' `outcome='ORDER'`/`outcome='SKIP'` filters simply won't match.
      outcome: evt.eventType === "ENTRY" ? "ORDER" : evt.eventType === "SKIP" ? "SKIP" : "OTHER",
      eventType: evt.eventType,
      market: evt.market ?? null, book: evt.book ?? null, lag: sanitizeLagSnapshot(evt.lag),
      pricing: skipPricing, sizing: evt.sizing ?? null, gatesInfo: evt.gates ?? null,
      aria: evt.aria ?? null, exitInfo: evt.exit ?? null, skipChain: evt.skipChain ?? null,
      chain: evt.chain ?? [], repeatCount: 1,
    });
  } catch {
    // Trace persistence must never affect trading (L6 fail-closed).
  }
}
