/**
 * basis-tracker.ts — cross-exchange → BRTI basis tracking for settlement projection.
 *
 * Kalshi's KXBTC15M/KXBTCH markets settle on the 60-second average of CF
 * Benchmarks' BRTI index — not on any single exchange's raw ticker. BRTI
 * itself has no free real-time feed, so the bot's only continuous window
 * into it today is `inferBtcPrice()` (kalshi-price.ts), a Black-Scholes
 * inversion of Kalshi's own YES/NO book. That inversion is noisy — thin
 * books, near-the-money strikes, and low time-to-close all distort it.
 *
 * A fast leading exchange (Coinbase — one of BRTI's constituent venues)
 * updates far more cleanly and often than Kalshi's own book. This module
 * tracks the steady-state price gap ("basis") between that exchange and our
 * BRTI proxy with an EWMA, then uses the CURRENT exchange price minus that
 * smoothed basis as a de-noised fair-BRTI estimate. A capped momentum term
 * projects it forward to the contract's settlement time.
 *
 * Ground-truth recalibration: `floor_strike` on a fresh Kalshi period IS the
 * real BRTI value at that period's open (see kalshi-price.ts comments). Every
 * time a new one appears we blend a zero-noise basis sample in with extra
 * weight, correcting any drift the continuous option-implied EWMA
 * accumulated over the prior 15 minutes.
 */

import { LagMeter, getLagMeterStatus, LAG_METER_GAP_SEC, LAG_METER_MIN_N, type LagTick, type LagLeaderName, type LagMeterStatusFields } from "./lag-meter.js";
import { coinbaseBtcLead, fetchCoinbaseLeadQuote } from "./coinbase-btc-lead.js";

export type ExchangeSource = 'coinbase' | 'binance' | 'coingecko';

export interface BasisState {
  /** EWMA(exchangePrice − brtiProxy), $. Null until the first sample lands. 5-min half-life — the structural/steady-state basis used for fairBRTI. */
  rollingBasis: number | null;
  /**
   * Fast EWMA (20s half-life) of the same (exchangePrice − brtiProxy) sample.
   * Reacts to a genuinely developing lag far faster than rollingBasis, without
   * being a raw single-tick read. Used by lag-exploiting strategies (e.g.
   * BASIS_LAG_EDGE) as a "is this a real, currently-widening gap" signal —
   * never fed into fairBRTI/projectedSettlementPrice (see basis-tracker.md).
   */
  shortBasis: number | null;
  /**
   * Consecutive DISTINCT exchange-price samples (not bot ticks — the exchange
   * feed itself is cached ~2.5s, so a run of identical 500ms ticks doesn't
   * count as multiple confirmations) whose raw basis sample shared the same
   * sign as the most recent one. Resets to 1 on a sign flip, 0 when the
   * sample is exactly zero. This is the "not a 1-tick spike" persistence
   * guard requested for basis-lag strategies.
   */
  basisStreakCount: number;
  /** Sign of the raw basis sample driving basisStreakCount: +1, -1, or 0. */
  basisStreakSign: 1 | -1 | 0;
  /** Wall-clock ms since the current streak began (0 if no streak yet). */
  basisStreakMs: number;
  /**
   * Epoch ms of the most recent genuine sign reversal (+1↔-1) of the raw
   * basis sample. Null until the first such reversal is observed. A sample
   * landing exactly on zero neither counts as a flip nor clears this — the
   * prior nonzero direction is remembered through a zero tick so a
   * subsequent real reversal is still detected correctly. Used by the
   * chaos-mode detector (condition-adapter.ts) to catch a sudden
   * exchange-vs-BRTI lead reversal that pure velocity thresholds miss.
   */
  signFlippedAt: number | null;
  /**
   * Coinbase±basis lead USD (NOT CF Benchmarks BRTI settlement pin).
   * Lag / hold-sell / thesis money path. Prefer operator name basisLeadUsd.
   */
  estimatedFairBRTI: number | null;
  /**
   * Operator-facing alias of estimatedFairBRTI (basis lead USD).
   * Same value — lag math may still read estimatedFairBRTI.
   */
  basisLeadUsd?: number | null;
  /** basisLeadUsd + capped momentum adjustment toward settlement. */
  projectedSettlementPrice: number | null;
  exchangePrice: number | null;
  exchangeSource: ExchangeSource | null;
  /** Last inferBtcPrice() value used as the BRTI-proxy side of the basis. */
  brtiProxy: number | null;
  lastUpdated: number | null; // epoch ms
  lastFloorStrike: number | null; // tracked to detect period rollovers
  sampleCount: number;
  /**
   * Cross-correlation lag of Kalshi-implied (brtiProxy) behind the selected
   * leader, from lag-meter. Null / lagStale=true until enough 1s samples,
   * when corr is junk, when catch-up is unproven, or when the selected
   * leader is stale (fail closed). Consumed as skip/veto at
   * decideSettlementSide / BASIS_LAG evaluate. Never fed into fairBRTI, pWin,
   * or 1s projectedSettlement.
   */
  lagSeconds: number | null;
  lagDollars: number | null;
  lagCorr: number | null;
  lagStale: boolean;
  lagReason: string;
  lagSampleN: number;
  /**
   * Instantaneous (exchange − brtiProxy) − rollingBasis from the lag-meter.
   * NOT the Stellar lag-$ line (that's lagDollars = leader Δ$ over tau).
   */
  lagResidualDollars: number | null;
  leaderName: LagLeaderName | null;
  leadSeconds: number | null;
  leadDollars: number | null;
  proofHitRate: number | null;
  lagProven: boolean;
  /** Epoch ms of the last Coinbase print used for lag rings. Null if never. */
  coinbaseObservedAt: number | null;
  /** now − coinbaseObservedAt. Infinity-equivalent null if never observed. */
  coinbaseAgeMs: number | null;
  binanceObservedAt: number | null;
  binanceAgeMs: number | null;
}

const HALF_LIFE_MS           = 5 * 60_000; // 5-minute half-life for the structural EWMA
const SHORT_HALF_LIFE_MS     = 20_000;     // 20s half-life for the fast/persistence-facing EWMA
const EXCHANGE_CACHE_TTL_MS  = 1_000;      // 15m tape: 2.5s cache was a full lag-sample stall
const FETCH_TIMEOUT_MS       = 2_000;     // REST fallback; live path prefers Coinbase WS cache
const RECALIBRATION_WEIGHT   = 0.35;       // blend weight for ground-truth floor-strike samples
const MOMENTUM_DAMPING       = 0.5;        // fraction of naive linear extrapolation applied
const MOMENTUM_CAP_PCT       = 0.35;       // max |adjustment| as % of fair BRTI
const MOMENTUM_MAX_MINUTES   = 10;         // don't extrapolate momentum further than this
const LOG_INTERVAL_MS        = 45_000;     // log roughly once every 30-60s per spec
const FAIR_VALUE_STALE_MS    = 45_000;     // mirrors trading-bot.ts's BALANCE_STALE_MS / isBalanceStale()
const LAG_RING_MS            = 5 * 60_000; // ~5 min of 1s Coinbase / brtiProxy samples for lag-meter
const LAG_RING_MAX_SAMPLES   = 5 * 60 + 8; // 1s buckets + slack

// ─────────────────────────────────────────────────────────────────────────────
// Pure functions — the three requested building blocks
// ─────────────────────────────────────────────────────────────────────────────

/** EWMA-update a rolling basis given a new (exchangePrice − brtiProxy) sample. */
export function updateRollingBasis(
  prevBasis: number | null,
  exchangePrice: number,
  brtiProxy: number,
  dtMs: number,
  halfLifeMs = HALF_LIFE_MS,
): number {
  const sample = exchangePrice - brtiProxy;
  if (prevBasis === null || !Number.isFinite(prevBasis)) return sample;
  const alpha = 1 - Math.exp((-Math.LN2 * Math.max(0, dtMs)) / halfLifeMs);
  return prevBasis + alpha * (sample - prevBasis);
}

/** Fair BRTI estimate: current exchange price, corrected by the smoothed basis. */
export function estimateFairBRTI(exchangePrice: number, rollingBasis: number): number {
  return exchangePrice - rollingBasis;
}

/**
 * Project the expected settlement price from a fair-BRTI estimate plus a
 * capped, damped momentum term. Momentum is naive velocity × minutes
 * remaining, damped (momentum partially mean-reverts over a 15-min window)
 * and clamped to a max % move so a brief velocity spike can't blow the
 * projection far past anything realistic.
 */
export function projectSettlementPrice(
  fairBRTI: number,
  velocityPerMin: number,
  secsRemaining: number,
  opts: { dampingFactor?: number; maxAdjustmentPct?: number; maxMinutes?: number } = {},
): number {
  const damping = opts.dampingFactor ?? MOMENTUM_DAMPING;
  const maxPct  = opts.maxAdjustmentPct ?? MOMENTUM_CAP_PCT;
  const maxMins = opts.maxMinutes ?? MOMENTUM_MAX_MINUTES;

  const minutesRemaining = Math.max(0, Math.min(secsRemaining / 60, maxMins));
  const rawAdjustment    = velocityPerMin * minutesRemaining * damping;
  const cap              = Math.abs(fairBRTI) * (maxPct / 100);
  const adjustment       = Math.max(-cap, Math.min(cap, rawAdjustment));

  return fairBRTI + adjustment;
}

// ─────────────────────────────────────────────────────────────────────────────
// Leading-exchange price feed — Coinbase → Binance → CoinGecko
// Never Investing.com (per spec: too slow/unreliable as a primary source).
// ─────────────────────────────────────────────────────────────────────────────

let exchangeCache: { price: number; source: ExchangeSource; ts: number } | null = null;

async function fetchWithTimeout(url: string, opts: RequestInit = {}): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
  try {
    return await fetch(url, { ...opts, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

/** Preferred — public Coinbase BTC-USD (WS cache, else REST ticker). No API key. */
async function fetchCoinbasePrice(): Promise<number | null> {
  const q = await fetchCoinbaseLeadQuote(Date.now());
  return q && q.price > 0 ? q.price : null;
}

/**
 * Best pure lead per spec, but Binance is geo-blocked (HTTP 451) from this
 * Replit environment (see market-candles.ts) — kept for portability/parity
 * with other environments. Failures here are expected and stay quiet
 * (no warn-level log) so they don't spam the console on every fallback.
 */
async function fetchBinancePrice(): Promise<number | null> {
  try {
    const resp = await fetchWithTimeout('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT');
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = (await resp.json()) as { price?: string };
    const price = parseFloat(data.price ?? '');
    return Number.isFinite(price) && price > 0 ? price : null;
  } catch {
    return null;
  }
}

/** Clean third fallback if both exchange feeds are unreachable. Not Investing.com. */
async function fetchCoinGeckoPrice(): Promise<number | null> {
  try {
    const resp = await fetchWithTimeout('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd');
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = (await resp.json()) as { bitcoin?: { usd?: number } };
    const price = data.bitcoin?.usd;
    return typeof price === 'number' && price > 0 ? price : null;
  } catch {
    return null;
  }
}

export type ExchangeQuote = { price: number; source: ExchangeSource; observedAt?: number };

/**
 * Hot path is Coinbase only (declared live lead). Binance/CoinGecko are not
 * Coinbase lag and must not be pushed into the lag ring. On Coinbase miss
 * the tracker keeps last-good + age and marks STALE — never a fake mid.
 */
async function fetchLeadingExchangePrice(): Promise<ExchangeQuote | null> {
  const now = Date.now();
  const hot = coinbaseBtcLead.getFreshQuote(now);
  if (hot) {
    exchangeCache = { price: hot.price, source: "coinbase", ts: hot.observedAt };
    return { price: hot.price, source: "coinbase", observedAt: hot.observedAt };
  }
  if (exchangeCache && exchangeCache.source === "coinbase" && now - exchangeCache.ts < EXCHANGE_CACHE_TTL_MS) {
    return { price: exchangeCache.price, source: exchangeCache.source, observedAt: exchangeCache.ts };
  }

  const quote = await fetchCoinbaseLeadQuote(now);
  if (quote !== null) {
    exchangeCache = { price: quote.price, source: "coinbase", ts: quote.observedAt };
    return { price: quote.price, source: "coinbase", observedAt: quote.observedAt };
  }

  return null; // Coinbase down — last-good + STALE, never a fake mid or a stand-in venue
}

function nowStampAge(nowMs: number, observedAt: number): number {
  return Math.max(0, nowMs - observedAt);
}

function pushLagRing(ring: LagTick[], tMs: number, px: number): void {
  if (!Number.isFinite(tMs) || !Number.isFinite(px) || px <= 0) return;
  const sec = Math.floor(tMs / 1000);
  const last = ring[ring.length - 1];
  if (last && Math.floor(last.tMs / 1000) === sec) {
    last.tMs = tMs;
    last.px = px;
  } else {
    ring.push({ tMs, px });
  }
  const cutoff = tMs - LAG_RING_MS;
  while (ring.length > 0 && (ring[0].tMs < cutoff || ring.length > LAG_RING_MAX_SAMPLES)) {
    ring.shift();
  }
}

/**
 * Drop a gappy prefix (maxGap>=3s) only when the dense suffix still has enough
 * samples to warm the lag meter. A single REST/WS hiccup near the tip used to
 * splice the entire warm ring down to 1 sample → permanent short_series while
 * Coinbase+BRTI were live. Does not invent prices or a 5–15s series.
 */
function keepDenseTail(ring: LagTick[]): void {
  if (ring.length < 2) return;
  let cut = 0;
  for (let i = ring.length - 1; i > 0; i--) {
    const gap = Math.floor(ring[i].tMs / 1000) - Math.floor(ring[i - 1].tMs / 1000);
    if (gap >= LAG_METER_GAP_SEC) {
      cut = i;
      break;
    }
  }
  const denseLen = ring.length - cut;
  // Keep full history when the post-gap suffix is too short to estimate lag;
  // estimateLag forward-fills ≤2s holes and fail-closes on real gaps.
  if (cut > 0 && denseLen >= LAG_METER_MIN_N) ring.splice(0, cut);
}

export type BasisTrackerOpts = {
  /** Test clock. Production uses Date.now. */
  now?: () => number;
  /** Test quote injector. Production uses Coinbase for fairBRTI. */
  fetchQuote?: () => Promise<ExchangeQuote | null>;
  /** Optional Binance BTCUSDT injector. Omit in tests → Coinbase-only still works. */
  fetchBinance?: () => Promise<number | null>;
  paperMode?: boolean;
  persistProofs?: boolean;
};

// ─────────────────────────────────────────────────────────────────────────────
// Live tracker — call .tick() once per bot tick
// ─────────────────────────────────────────────────────────────────────────────

/** Kalshi book quoteTs freshness for lagProven. Heartbeat ts does not count. */
export const KALSHI_QUOTE_FRESH_MS = 5_000;

export class BasisTracker {
  private readonly nowFn: () => number;
  private readonly fetchQuoteFn: () => Promise<ExchangeQuote | null>;
  private readonly fetchBinanceFn: (() => Promise<number | null>) | null;
  private readonly awaitBinance: boolean;
  private readonly useLiveLead: boolean;
  private readonly paperMode: boolean;
  private readonly lagMeter: LagMeter;
  private readonly coinbaseRing: LagTick[] = [];
  private readonly binanceRing: LagTick[] = [];
  private readonly kalshiRing: LagTick[] = [];
  private lastKalshiQuoteTs: number | null = null;
  private binanceCache: { px: number; ts: number } | null = null;
  private binanceKickInFlight = false;

  constructor(opts: BasisTrackerOpts = {}) {
    this.nowFn = opts.now ?? Date.now;
    this.fetchQuoteFn = opts.fetchQuote ?? fetchLeadingExchangePrice;
    this.awaitBinance = opts.fetchBinance != null;
    this.fetchBinanceFn = opts.fetchBinance ?? (opts.fetchQuote ? null : fetchBinancePrice);
    this.useLiveLead = !opts.fetchQuote;
    this.paperMode = opts.paperMode === true;
    this.lagMeter = new LagMeter({ persistProofs: opts.persistProofs === true });
  }

  /** Sibling of TradingBot.getStatus — never invents 5–15s. Stale → tau null. */
  getLagMeter(): LagMeter {
    return this.lagMeter;
  }

  getLagMeterStatus(): LagMeterStatusFields {
    return getLagMeterStatus(this.lagMeter);
  }

  private now(): number {
    return this.nowFn();
  }

  private state: BasisState = {
    rollingBasis: null,
    shortBasis: null,
    basisStreakCount: 0,
    basisStreakSign: 0,
    basisStreakMs: 0,
    signFlippedAt: null,
    estimatedFairBRTI: null,
    basisLeadUsd: null,
    projectedSettlementPrice: null,
    exchangePrice: null,
    exchangeSource: null,
    brtiProxy: null,
    lastUpdated: null,
    lastFloorStrike: null,
    sampleCount: 0,
    lagSeconds: null,
    lagDollars: null,
    lagCorr: null,
    lagStale: true,
    lagReason: "empty_series",
    lagSampleN: 0,
    lagResidualDollars: null,
    leaderName: null,
    leadSeconds: null,
    leadDollars: null,
    proofHitRate: null,
    lagProven: false,
    coinbaseObservedAt: null,
    coinbaseAgeMs: null,
    binanceObservedAt: null,
    binanceAgeMs: null,
  };
  private inFlight = false;
  private lastLoggedAt = 0;
  // ── Persistence-streak bookkeeping ────────────────────────────────────────
  // Keyed off DISTINCT exchange price samples, not bot-tick calls, so the
  // 500ms tick cadence against a ~2.5s-cached exchange feed can't inflate the
  // streak by re-counting the same underlying sample multiple times.
  private lastSampledExchangePrice: number | null = null;
  private basisStreakStartedAt: number | null = null;
  // Last nonzero sign seen, remembered across exact-zero samples, so a real
  // reversal is still detected even if a zero-basis tick lands in between.
  private prevNonZeroSign: 1 | -1 | 0 = 0;
  private lastSignFlipAt: number | null = null;

  getState(): BasisState {
    const s = { ...this.state };
    const now = this.now();
    s.coinbaseAgeMs = s.coinbaseObservedAt != null ? now - s.coinbaseObservedAt : null;
    s.binanceAgeMs = s.binanceObservedAt != null ? now - s.binanceObservedAt : null;
    // Fail closed: selected leader stale / unproven / fair-value must not
    // advertise LIVE lag. Last-observed lag$ / tau stay visible with age.
    // Never invent lagProven=true when the leader print is missing/aged.
    const leader = s.leaderName ?? "coinbase";
    const leaderAge = leader === "binance" ? s.binanceAgeMs : s.coinbaseAgeMs;
    const leaderSeen = leader === "binance" ? s.binanceObservedAt : s.coinbaseObservedAt;
    if (s.lagReason === "lag_unproven") s.lagStale = true;
    if (leaderSeen == null || (leaderAge != null && leaderAge > FAIR_VALUE_STALE_MS)) {
      s.lagStale = true;
      s.lagProven = false;
    }
    if (leader === "coinbase" && this.isFairValueStale()) {
      s.lagStale = true;
      s.lagProven = false;
    }
    // lagProven only when the lead is fresh vs Kalshi book quoteTs (not heartbeat ts).
    if (this.lastKalshiQuoteTs != null) {
      const qAge = now - this.lastKalshiQuoteTs;
      if (!(this.lastKalshiQuoteTs > 0) || qAge > KALSHI_QUOTE_FRESH_MS) {
        s.lagStale = true;
        s.lagProven = false;
      }
    }
    // Belt: never surface lagProven∧lagStale (n_low catch-up vs thin series).
    if (s.lagStale) s.lagProven = false;
    // Operator alias — always mirror estimatedFairBRTI (lag math unchanged).
    s.basisLeadUsd = s.estimatedFairBRTI;
    return s;
  }

  /**
   * True when the fair-value output (basisLeadUsd/estimatedFairBRTI/projectedSettlementPrice)
   * has no update yet, or its last update is older than FAIR_VALUE_STALE_MS.
   * Mirrors trading-bot.ts's isBalanceStale() fail-closed pattern: previously
   * a total exchange-feed outage let tick() silently keep returning the last
   * known state forever with no caller-visible signal that it had gone stale.
   * Callers must treat true as "do not use this fair value to corroborate a
   * decision right now".
   */
  isFairValueStale(): boolean {
    return this.state.lastUpdated === null || this.now() - this.state.lastUpdated > FAIR_VALUE_STALE_MS;
  }

  /**
   * Called once per bot tick. Internally throttled (exchange fetch is cached
   * ~2.5s and mutex-guarded), so it's safe to call at the bot's 500ms tick
   * cadence. Never throws: on exchange-fetch failure, or while a fetch is
   * already in flight, it returns the last known state unchanged so a
   * transient outage degrades gracefully instead of blanking strategy input.
   */
  private kickBinanceBackground(): void {
    if (this.awaitBinance || !this.fetchBinanceFn || this.binanceKickInFlight) return;
    this.binanceKickInFlight = true;
    const fn = this.fetchBinanceFn;
    void fn().then((px) => {
      if (px != null && Number.isFinite(px) && px > 0) {
        this.binanceCache = { px, ts: this.now() };
      }
    }).finally(() => {
      this.binanceKickInFlight = false;
    });
  }

  async tick(input: {
    brtiProxy: number;
    floorStrike: number;
    velocityPerMin: number;
    secsRemaining: number;
    paperMode?: boolean;
    /** Kalshi book quoteTs — heartbeat ts must not count as fresh. */
    quoteTs?: number | null;
  }): Promise<BasisState> {
    if (input.quoteTs !== undefined) {
      this.lastKalshiQuoteTs = typeof input.quoteTs === "number" && input.quoteTs > 0 ? input.quoteTs : null;
    }
    if (this.inFlight) return this.getState();
    if (!Number.isFinite(input.brtiProxy) || input.brtiProxy <= 0) return this.getState();

    this.inFlight = true;
    try {
      const paperMode = input.paperMode === true || this.paperMode;
      if (this.useLiveLead) {
        for (const t of coinbaseBtcLead.getRing()) pushLagRing(this.coinbaseRing, t.tMs, t.px);
      }
      this.kickBinanceBackground();
      const quoteP = this.fetchQuoteFn();
      const binanceP = this.awaitBinance && this.fetchBinanceFn
        ? this.fetchBinanceFn()
        : Promise.resolve(null);
      let quote = await quoteP;
      const now = this.now();
      let binancePx = await binanceP;
      if (!this.awaitBinance) {
        const cached = this.binanceCache;
        binancePx = cached && now - cached.ts <= FAIR_VALUE_STALE_MS ? cached.px : null;
      }

      if (binancePx != null && Number.isFinite(binancePx) && binancePx > 0) {
        pushLagRing(this.binanceRing, now, binancePx);
        this.state = { ...this.state, binanceObservedAt: now, binanceAgeMs: 0 };
      }

      if (this.useLiveLead && (!quote || quote.source !== "coinbase" || !(quote.price > 0))) {
        const last = this.coinbaseRing[this.coinbaseRing.length - 1];
        if (last && now - last.tMs <= FAIR_VALUE_STALE_MS) {
          quote = { price: last.px, source: "coinbase", observedAt: last.tMs };
        }
      }

      const observedAt = quote?.observedAt ?? now;
      const coinbaseLive = !!(quote && quote.source === "coinbase" && quote.price > 0
        && now - observedAt <= FAIR_VALUE_STALE_MS);
      if (!coinbaseLive) {
        pushLagRing(this.kalshiRing, now, input.brtiProxy);
        keepDenseTail(this.coinbaseRing);
        keepDenseTail(this.binanceRing);
        keepDenseTail(this.kalshiRing);
        const lagReading = this.lagMeter.update(
          { coinbase: this.coinbaseRing, binance: this.binanceRing, kalshiImplied: this.kalshiRing },
          { nowMs: now, brtiProxy: input.brtiProxy, rollingBasis: this.state.rollingBasis, paperMode },
        );
        const cbAge = this.state.coinbaseObservedAt ? nowStampAge(now, this.state.coinbaseObservedAt) : null;
        const leader = lagReading.leaderName ?? "coinbase";
        const binanceLive = binancePx != null && Number.isFinite(binancePx) && binancePx > 0;
        const lagLiveOnBinance = leader === "binance" && binanceLive && lagReading.stale === false;
        this.state = {
          ...this.state,
          lagSeconds: lagReading.lagSeconds,
          lagDollars: lagReading.lagDollars,
          lagCorr: lagReading.corr,
          lagStale: lagLiveOnBinance ? false : true,
          lagReason: lagLiveOnBinance
            ? lagReading.reason
            : (this.state.coinbaseObservedAt
              ? `coinbase_stale:${cbAge}`
              : (paperMode ? "coinbase_missing:paper_coinbase_cold" : "coinbase_missing")),
          lagSampleN: lagReading.sampleN,
          lagResidualDollars: lagReading.residualDollars,
          leaderName: lagReading.leaderName,
          leadSeconds: lagReading.leadSeconds,
          leadDollars: lagReading.leadDollars,
          proofHitRate: lagReading.proofHitRate,
          // Coinbase missing: never invent lagProven=true (Binance live leader may keep it).
          lagProven: lagLiveOnBinance ? lagReading.proven : false,
        };
        return this.getState();
      }

      const dtMs = this.state.lastUpdated ? now - this.state.lastUpdated : 0;
      let basis      = updateRollingBasis(this.state.rollingBasis, quote!.price, input.brtiProxy, dtMs);
      let shortBasis = updateRollingBasis(this.state.shortBasis, quote!.price, input.brtiProxy, dtMs, SHORT_HALF_LIFE_MS);

      // Ground-truth recalibration on a fresh period's floor_strike (real BRTI at open).
      const isNewPeriod = input.floorStrike > 0 && this.state.lastFloorStrike !== null
        && input.floorStrike !== this.state.lastFloorStrike;
      if (isNewPeriod) {
        const trueSample = quote!.price - input.floorStrike;
        basis      = basis      + RECALIBRATION_WEIGHT * (trueSample - basis);
        shortBasis = shortBasis + RECALIBRATION_WEIGHT * (trueSample - shortBasis);
      }

      const isNewExchangeSample = this.lastSampledExchangePrice === null
        || quote!.price !== this.lastSampledExchangePrice;
      let streakCount = this.state.basisStreakCount;
      let streakSign  = this.state.basisStreakSign;
      let streakStartedAt = this.basisStreakStartedAt;
      if (isNewExchangeSample) {
        const rawSample = quote!.price - input.brtiProxy;
        const sign: 1 | -1 | 0 = rawSample > 0 ? 1 : rawSample < 0 ? -1 : 0;
        if (sign !== 0 && sign === streakSign) {
          streakCount += 1;
        } else {
          streakCount = sign === 0 ? 0 : 1;
          streakStartedAt = now;
        }
        streakSign = sign;
        this.lastSampledExchangePrice = quote!.price;
        this.basisStreakStartedAt = streakStartedAt;

        if (sign !== 0) {
          if (this.prevNonZeroSign !== 0 && sign !== this.prevNonZeroSign) {
            this.lastSignFlipAt = now;
          }
          this.prevNonZeroSign = sign;
        }
      }
      const streakMs = streakStartedAt ? now - streakStartedAt : 0;

      const fairBRTI  = estimateFairBRTI(quote!.price, basis);
      const projected = projectSettlementPrice(fairBRTI, input.velocityPerMin, input.secsRemaining);

      const cbTs = quote!.observedAt ?? now;
      pushLagRing(this.coinbaseRing, cbTs, quote!.price);
      pushLagRing(this.kalshiRing, now, input.brtiProxy);
      keepDenseTail(this.coinbaseRing);
      keepDenseTail(this.binanceRing);
      keepDenseTail(this.kalshiRing);
      const lagReading = this.lagMeter.update(
        { coinbase: this.coinbaseRing, binance: this.binanceRing, kalshiImplied: this.kalshiRing },
        {
          nowMs: now,
          exchange: quote!.price,
          brtiProxy: input.brtiProxy,
          rollingBasis: basis,
          paperMode,
        },
      );

      this.state = {
        rollingBasis: basis,
        shortBasis,
        basisStreakCount: streakCount,
        basisStreakSign: streakSign,
        basisStreakMs: streakMs,
        signFlippedAt: this.lastSignFlipAt,
        estimatedFairBRTI: fairBRTI,
        basisLeadUsd: fairBRTI,
        projectedSettlementPrice: projected,
        exchangePrice: quote!.price,
        exchangeSource: quote!.source,
        brtiProxy: input.brtiProxy,
        lastUpdated: now,
        coinbaseObservedAt: cbTs,
        coinbaseAgeMs: nowStampAge(now, cbTs),
        binanceObservedAt: this.state.binanceObservedAt,
        binanceAgeMs: this.state.binanceObservedAt != null ? now - this.state.binanceObservedAt : this.state.binanceAgeMs,
        lastFloorStrike: input.floorStrike || this.state.lastFloorStrike,
        sampleCount: this.state.sampleCount + 1,
        lagSeconds: lagReading.lagSeconds,
        lagDollars: lagReading.lagDollars,
        lagCorr: lagReading.corr,
        lagStale: lagReading.stale,
        lagReason: lagReading.reason,
        lagSampleN: lagReading.sampleN,
        lagResidualDollars: lagReading.residualDollars,
        leaderName: lagReading.leaderName,
        leadSeconds: lagReading.leadSeconds,
        leadDollars: lagReading.leadDollars,
        proofHitRate: lagReading.proofHitRate,
        lagProven: lagReading.proven,
      };

      if (now - this.lastLoggedAt >= LOG_INTERVAL_MS) {
        this.lastLoggedAt = now;
        console.log(
          `[basis] ${quote!.source} $${quote!.price.toFixed(0)} · brtiProxy $${input.brtiProxy.toFixed(0)} · ` +
          `basis ${basis >= 0 ? '+' : ''}${basis.toFixed(2)} (short ${shortBasis >= 0 ? '+' : ''}${shortBasis.toFixed(2)}) · ` +
          `streak ${streakSign >= 0 ? '+' : ''}${streakSign}×${streakCount} (${(streakMs / 1000).toFixed(0)}s) · ` +
          `fairBRTI $${fairBRTI.toFixed(0)} · projected $${projected.toFixed(0)} · ${input.secsRemaining.toFixed(0)}s left` +
          ` · leader=${lagReading.leaderName ?? "coinbase"} proven=${lagReading.proven} hit=${lagReading.proofHitRate ?? "n/a"}` +
          ` lead=${lagReading.leadSeconds ?? "n/a"}s $${lagReading.leadDollars ?? "n/a"}` +
          (paperMode ? " · paper" : "") +
          (isNewPeriod ? ' · recalibrated vs floor_strike' : '')
        );
      }

      return this.getState();
    } finally {
      this.inFlight = false;
    }
  }
}

export const basisTracker = new BasisTracker({ persistProofs: true });

/**
 * True when the most recent genuine basis sign reversal happened within the
 * last `windowMs`. Used by condition-adapter.ts's chaos-mode detector to
 * catch a sudden exchange-vs-BRTI lead reversal — a distinct signal from the
 * existing velocity-based waterfall threshold.
 */
export function isRecentBasisSignFlip(
  state:    Pick<BasisState, 'signFlippedAt'>,
  windowMs: number,
  now = Date.now(),
): boolean {
  return state.signFlippedAt !== null && now - state.signFlippedAt <= windowMs;
}
