/**
 * R4 — live price lag: entries are judged on the freshest valid same-ticker
 * source (WS tick, or a newer L2 top when the WS value lags by >2¢).
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { freshestEntryQuote, quoteValueLag, type ObSnap } from "./orderbook-consistency.js";

const NOW = 1_800_000_000_000;
const T = "KXBTC15M-26SEP250600-00";
function tick(over: Partial<Record<string, unknown>> = {}) {
  return {
    ticker: T, yesBid: 40, yesAsk: 42, noBid: 58, noAsk: 60, yesPrice: 41, noPrice: 59,
    source: "ws" as const, ts: NOW - 1_000, quoteTs: NOW - 20_000, ...over,
  } as { ticker: string; yesBid: number; yesAsk: number; noBid: number; noAsk: number; yesPrice: number; noPrice: number; source: "ws" | "rest"; ts: number; quoteTs: number };
}
function ob(over: Partial<ObSnap> = {}): ObSnap {
  return { ticker: T, yesBids: [[47, 10], [46, 5]], yesAsks: [[49, 8], [50, 3]], ts: NOW - 3_000, ...over };
}

test("lagging WS quote → entry quote taken from newer same-ticker L2 top", () => {
  const r = freshestEntryQuote(tick(), ob(), NOW);
  assert.equal(r.origin, "l2");
  assert.equal(r.tick!.yesBid, 47);
  assert.equal(r.tick!.yesAsk, 49);
  assert.equal(r.tick!.noBid, 51);
  assert.equal(r.tick!.noAsk, 53);
  assert.equal(r.tick!.quoteTs, NOW - 3_000);
  assert.equal(r.tick!.yesPrice, 48);
  assert.equal(r.tick!.noPrice, 52);
  assert.equal(r.tick!.source, "ws", "source kept so live REST guards are unchanged");
  assert.equal(r.tick!.ticker, T);
});

test("swapped quote is no longer flagged D9-stale against the same book", () => {
  const before = quoteValueLag({ tick: tick(), ob: ob(), now: NOW });
  assert.equal(before.stale, true);
  const after = quoteValueLag({ tick: freshestEntryQuote(tick(), ob(), NOW).tick, ob: ob(), now: NOW });
  assert.equal(after.stale, false);
});

test("cross-contract guard: different-ticker L2 is never used", () => {
  const r = freshestEntryQuote(tick(), ob({ ticker: "KXBTC15M-26SEP250615-15" }), NOW);
  assert.equal(r.origin, "tick");
  assert.equal(r.tick!.yesAsk, 42);
});

test("WS quote newer than (or within 2s of) L2 → keep WS", () => {
  assert.equal(freshestEntryQuote(tick({ quoteTs: NOW - 2_000 }), ob({ ts: NOW - 3_000 }), NOW).origin, "tick");
  assert.equal(freshestEntryQuote(tick({ quoteTs: NOW - 4_000 }), ob({ ts: NOW - 3_000 }), NOW).origin, "tick");
});

test("L2 older than 30s → keep WS", () => {
  const r = freshestEntryQuote(tick({ quoteTs: NOW - 60_000 }), ob({ ts: NOW - 31_000 }), NOW);
  assert.equal(r.origin, "tick");
});

test("agreement within 2¢ → keep WS (no churn)", () => {
  const r = freshestEntryQuote(tick(), ob({ yesBids: [[41, 1]], yesAsks: [[44, 1]] }), NOW);
  assert.equal(r.origin, "tick");
  assert.equal(r.tick!.yesAsk, 42);
});

test("invalid L2 tops (crossed, missing side, out of 1–99) → keep WS", () => {
  for (const bad of [
    ob({ yesBids: [[50, 1]], yesAsks: [[49, 1]] }),
    ob({ yesBids: [], yesAsks: [[49, 1]] }),
    ob({ yesBids: [[47, 1]], yesAsks: [] }),
    ob({ yesBids: [[0, 1]], yesAsks: [[49, 1]] }),
    ob({ yesBids: [[47, 1]], yesAsks: [[100, 1]] }),
  ]) {
    assert.equal(freshestEntryQuote(tick(), bad, NOW).origin, "tick");
  }
});

test("null inputs pass through", () => {
  assert.equal(freshestEntryQuote(null, ob(), NOW).tick, null);
  assert.equal(freshestEntryQuote(tick(), null, NOW).tick!.yesAsk, 42);
});

test("WS with a missing side and fresher valid L2 → L2", () => {
  const r = freshestEntryQuote(tick({ yesBid: 0, noAsk: 0 }), ob(), NOW);
  assert.equal(r.origin, "l2");
  assert.equal(r.tick!.noAsk, 53);
});

test("wiring: evaluateEntry and placeOrder ask re-read use getLatestForEntry", async () => {
  const { readFileSync } = await import("node:fs");
  const src = readFileSync(new URL("./trading-bot.ts", import.meta.url), "utf8");
  assert.match(src, /const tick = kalshiWS\.getLatestForEntry\(\);\n\s+if \(tick && kalshiWS\.getEntryQuoteStats\(\)/);
  assert.match(src, /const tick = kalshiWS\.getLatestForEntry\(\);\n\s+liveTickerMatches = !!tick && tick\.ticker === ticker;/);
  assert.match(src, /liveQuoteValueLag\(tick\)/);
  const ws = readFileSync(new URL("./kalshi-ws.ts", import.meta.url), "utf8");
  assert.match(ws, /freshestEntryQuote\(this\.getLatest\(\), this\.getLatestOrderbook\(\)/);
});
