/**
 * mind-calibration — binned p (winRateAtPrice) vs settle/outcome hit rate.
 *
 * ECE-like error: Σ_b (|acc_b − conf_b| · n_b / N). Pure. No network. No LLM.
 * Unreliable → bounded SKIP lean in council (never cuts floors / ENABLE).
 *
 * P2-A: durable JSONL sample store so calib.n grows across process restarts
 * (healthz calib.n ≠ stuck-0 forever). Smallest working path.
 */
import { existsSync, mkdirSync, appendFileSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { deskDataPath } from "../desk-data-dir.js";
import { runningGitSha, FROZEN_CC_RULESET_VERSION } from "../frozen-cc.js";
import { activeWinCurveModel } from "../win-curve-refit.js";

export const MIND_CALIBRATION_LOADED = "MIND_CALIBRATION_LOADED" as const;

/** Default equal-width bins on [0,1]. */
export const CAL_BIN_EDGES = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0] as const;

/** n below this → ESTIMATE only; unreliable. */
export const CAL_N_MIN_RELIABLE = 30 as const;

/** ECE above this → unreliable (raise SKIP lean). */
export const CAL_ECE_MAX_RELIABLE = 0.08 as const;

/** Bounded council skip-weight bump when unreliable (clamped later). */
export const CAL_SKIP_LEAN_UNRELIABLE = 0.12 as const;

export type CalibrationObs = {
  /** Predicted win probability at traded ask (winRateAtPrice). */
  p: number;
  /** True when side matched settle, or (fallback) outcome===win on settlement exit. */
  hit: boolean;
  askCents?: number | null;
  side?: "yes" | "no" | null;
  atMs?: number | null;
  /**
   * "fill" = real settled paper/live trade (default when absent — legacy rows).
   * "shadow" = a take the captain/mind BLOCKED at placeOrder, resolved against
   * the market's real settlement (shadow-calibration.ts). Never a position,
   * never balance, never a trade. Same reliability rule counts both.
   */
  source?: "fill" | "shadow";
  ticker?: string | null;
  /** Code version that produced the record (baked GIT_SHA at build). */
  gitSha?: string | null;
  /** Model/ruleset version whose p this is (see currentCalibrationModelVersion). */
  modelVersion?: string | null;
};

/**
 * Version scoping for the reliability rule (n ≥ 30 & ECE ≤ 0.08).
 *
 *   MIND_CALIBRATION_MODEL_VERSION  current model/ruleset tag stamped on new
 *                                   records (default: FROZEN_CC_RULESET_VERSION
 *                                   + "+" + active win-curve model id, e.g.
 *                                   "frozen-cc-v1+wincurve-…-v1"). Bump it when the p
 *                                   model changes to start a fresh count.
 *   MIND_CALIBRATION_VERSION_SCOPE  which records count toward reliability:
 *                                     "model"  (default) only modelVersion === current
 *                                     "gitSha" only records from the running gitSha
 *                                     "all"    every record (legacy behaviour)
 * Untagged legacy rows never count under "model"/"gitSha".
 */
export type CalibrationVersionScope = "model" | "gitSha" | "all";

export function currentCalibrationModelVersion(env: NodeJS.ProcessEnv = process.env): string {
  const v = (env.MIND_CALIBRATION_MODEL_VERSION ?? "").trim();
  // Legacy curve (default) keeps the existing "frozen-cc-v1" tag so current
  // records keep counting; the refit curve starts a fresh, separately-tagged count.
  const curve = activeWinCurveModel(env);
  return v || (curve === "legacy-cc-v0" ? FROZEN_CC_RULESET_VERSION : `${FROZEN_CC_RULESET_VERSION}+${curve}`);
}

export function calibrationVersionScope(env: NodeJS.ProcessEnv = process.env): CalibrationVersionScope {
  const v = (env.MIND_CALIBRATION_VERSION_SCOPE ?? "").trim().toLowerCase();
  return v === "all" ? "all" : v === "gitsha" ? "gitSha" : "model";
}

/** Records that count toward reliability under the active scope. */
export function scopeCalibrationObs(
  obs: readonly CalibrationObs[],
  opts: { scope?: CalibrationVersionScope; modelVersion?: string; gitSha?: string | null } = {},
): CalibrationObs[] {
  const scope = opts.scope ?? calibrationVersionScope();
  if (scope === "all") return [...obs];
  if (scope === "gitSha") {
    const sha = opts.gitSha !== undefined ? opts.gitSha : runningGitSha();
    return sha ? obs.filter((o) => o.gitSha === sha) : [];
  }
  const mv = opts.modelVersion ?? currentCalibrationModelVersion();
  return obs.filter((o) => o.modelVersion === mv);
}

function normSource(v: unknown): "fill" | "shadow" {
  return v === "shadow" ? "shadow" : "fill";
}

export type CalibrationBin = {
  lo: number;
  hi: number;
  n: number;
  meanP: number;
  hitRate: number;
  /** |hitRate − meanP| */
  gap: number;
};

export type CalibrationReport = {
  n: number;
  ece: number;
  bins: CalibrationBin[];
  reliable: boolean;
  /** Epistemic label — ESTIMATE when n small. */
  label: "MEASUREMENT" | "ESTIMATE";
  skipLean: number;
  note: string;
  /** PR #14 bootstrap gate details (present on calibrationSnapshot / computeCalibrationGate). */
  gate?: CalibrationGateDetail;
};

/**
 * PR #14 — calibration gate (the OV-SKIP / ECE brake), bootstrap rule.
 *
 * RULE (one rule, documented): with the gate sample S (one sample per 15m
 * window, see sampleCalibrationForGate) of size n:
 *   • n < 30                       → unreliable (unchanged: ESTIMATE, SKIP lean).
 *   • n ≥ 30: draw B = 2000 nonparametric bootstrap resamples of S with a fixed
 *     seed; ECE*_b on the same 10 equal-width bins. Bias-corrected ("basic")
 *     one-sided 95% lower bound  L = 2·ECE_obs − q95(ECE*).
 *     Equivalent p-value  p = #{ 2·ECE_obs − ECE*_b ≤ 0.08 } / B.
 *     TRIP (unreliable → SKIP lean) iff  L > 0.08  (⇔ p < 0.05).
 *     Otherwise reliable.
 * Why "basic" and not the raw percentile bound: ECE is biased upward in
 * small samples and a bootstrap ECE* is biased upward again, so the raw
 * percentile bound trips on perfectly calibrated models whose p spreads over
 * several bins (Monte Carlo: ~44% false trips at n=63). The basic bound
 * subtracts that bias (Monte Carlo: ~1–3% false trips at n≥63; ~12% at n=30
 * with widely spread p — small-n caveat).
 * Power is modest at desk sizes (true gap 0.12 trips ~20% at n≈60–100;
 * gap 0.20 trips ~60–80%). A pass is NOT evidence of edge or of good
 * calibration — only that miscalibration > 0.08 is not statistically shown.
 * Touches only `reliable`/`skipLean` (the brake). Never EV, Kelly or sizing.
 */
export const CAL_GATE_BOOTSTRAP_B = 2000 as const;
export const CAL_GATE_BOOTSTRAP_SEED = 0x5eed14 as const;
export const CAL_GATE_ALPHA = 0.05 as const;
export const CAL_GATE_RULE =
  "trip iff n>=30 AND basic-bootstrap one-sided 95% lower bound of ECE (2*ECE_obs - q95(ECE*), B=2000, seed 0x5eed14) > 0.08 (equiv. p<0.05); n<30 unreliable; one sample per window" as const;

export type CalibrationGateDetail = {
  rule: string;
  /** Scoped rows before window dedupe. */
  nRaw: number;
  /** Gate sample size (one per window). */
  n: number;
  /** Rows dropped because their window already had an earlier sample. */
  droppedSameWindow: number;
  nFill: number;
  nShadow: number;
  /** Point ECE on the gate sample. */
  ece: number;
  /** Bias-corrected one-sided 95% lower bound (null when n < nMin). */
  eceLower95: number | null;
  /** Bootstrap p-value for H0: ECE ≤ threshold (null when n < nMin). */
  pBoot: number | null;
  threshold: number;
  alpha: number;
  B: number;
  seed: number;
  trip: boolean;
};

const RING_MAX = 512;
let calRing: CalibrationObs[] = [];

function defaultCalibPath(): string {
  return deskDataPath("mind-calibration.jsonl");
}

export function resetMindCalibrationForTests(): void {
  calRing = [];
}

export function getCalibrationRing(): readonly CalibrationObs[] {
  return calRing;
}

function isValidCalibrationObs(obs: unknown): obs is CalibrationObs {
  if (typeof obs !== "object" || obs === null) return false;
  const value = obs as Partial<CalibrationObs>;
  return typeof value.p === "number" && Number.isFinite(value.p)
    && value.p >= 0 && value.p <= 1 && typeof value.hit === "boolean";
}

function round4(n: number): number {
  return Math.round(n * 10000) / 10000;
}

function persistCalibrationObs(obs: CalibrationObs, filePath?: string): void {
  try {
    const file = filePath ?? defaultCalibPath();
    const dir = path.dirname(file);
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    appendFileSync(file, `${JSON.stringify(obs)}\n`, "utf8");
  } catch {
    /* never block settle */
  }
}

/**
 * Record one closed-trade calibration observation.
 * Persists to JSONL by default so n survives bounce (P2-A).
 */
export function recordCalibrationObs(
  obs: CalibrationObs,
  ring?: CalibrationObs[],
  opts?: { persist?: boolean; filePath?: string },
): CalibrationObs {
  if (!isValidCalibrationObs(obs)) {
    throw new TypeError("Calibration requires a finite probability in [0,1] and a boolean outcome");
  }
  const clean: CalibrationObs = {
    p: obs.p,
    hit: obs.hit,
    askCents: typeof obs.askCents === "number" && Number.isFinite(obs.askCents) ? obs.askCents : null,
    side: obs.side === "no" ? "no" : obs.side === "yes" ? "yes" : null,
    atMs: typeof obs.atMs === "number" && Number.isFinite(obs.atMs) ? obs.atMs : Date.now(),
    source: normSource(obs.source),
    ...(typeof obs.ticker === "string" && obs.ticker ? { ticker: obs.ticker } : {}),
    gitSha: typeof obs.gitSha === "string" && obs.gitSha ? obs.gitSha : runningGitSha(),
    modelVersion: typeof obs.modelVersion === "string" && obs.modelVersion ? obs.modelVersion : currentCalibrationModelVersion(),
  };
  if (ring) {
    ring.push(clean);
    if (ring.length > RING_MAX) ring.splice(0, ring.length - RING_MAX);
  } else {
    calRing = [...calRing, clean];
    if (calRing.length > RING_MAX) calRing = calRing.slice(calRing.length - RING_MAX);
  }
  const inTest =
    process.env.NODE_TEST_CONTEXT != null
    || (typeof process.env.BOT_CONFIG_PATH === "string"
      && process.env.BOT_CONFIG_PATH.includes("/tmp"));
  if (opts?.persist === true || (opts?.persist !== false && ring == null && !inTest)) {
    persistCalibrationObs(clean, opts?.filePath);
  }
  return clean;
}

/** Load JSONL into ring (startup / tests). Returns lines loaded. */
export function loadCalibrationFromDisk(filePath?: string): number {
  try {
    const file = filePath ?? defaultCalibPath();
    if (!existsSync(file)) return 0;
    const lines = readFileSync(file, "utf8").split("\n").filter(Boolean);
    let n = 0;
    // Reset then reload so restart is idempotent for ring contents from disk
    const loaded: CalibrationObs[] = [];
    for (const line of lines) {
      try {
        const o = JSON.parse(line) as CalibrationObs;
        // GE_001: same validity rule as recordCalibrationObs (skip bad rows,
        // never clamp an out-of-range probability into a fake observation).
        if (isValidCalibrationObs(o)) {
          loaded.push({
            p: o.p,
            hit: o.hit,
            askCents: typeof o.askCents === "number" ? o.askCents : null,
            side: o.side === "no" ? "no" : o.side === "yes" ? "yes" : null,
            atMs: typeof o.atMs === "number" ? o.atMs : null,
            source: normSource(o.source),
            ...(typeof o.ticker === "string" && o.ticker ? { ticker: o.ticker } : {}),
            gitSha: typeof o.gitSha === "string" ? o.gitSha : null,
            modelVersion: typeof o.modelVersion === "string" ? o.modelVersion : null,
          });
          n += 1;
        }
      } catch {
        /* skip */
      }
    }
    if (loaded.length > RING_MAX) {
      calRing = loaded.slice(loaded.length - RING_MAX);
    } else {
      calRing = loaded;
    }
    return n;
  } catch {
    return 0;
  }
}

/**
 * Expected Calibration Error (ECE) over equal-width bins.
 * ECE = Σ_b (|acc_b − conf_b| · n_b / N). Empty → ece=0, reliable=false.
 */
export function computeCalibration(
  observations: readonly CalibrationObs[],
  opts?: {
    binEdges?: readonly number[];
    nMinReliable?: number;
    eceMaxReliable?: number;
  },
): CalibrationReport {
  const edges = opts?.binEdges ?? CAL_BIN_EDGES;
  const nMin = opts?.nMinReliable ?? CAL_N_MIN_RELIABLE;
  const eceMax = opts?.eceMaxReliable ?? CAL_ECE_MAX_RELIABLE;
  if (edges.length < 2 || edges[0] !== 0 || edges[edges.length - 1] !== 1
      || edges.some((edge, i) => !Number.isFinite(edge) || (i > 0 && edge <= edges[i - 1]!))) {
    throw new RangeError("Calibration bins must be strictly increasing and span [0,1]");
  }
  if (!Number.isSafeInteger(nMin) || nMin < 1
      || !Number.isFinite(eceMax) || eceMax < 0 || eceMax > 1) {
    throw new RangeError("Calibration reliability thresholds are invalid");
  }
  // Invalid imported rows are excluded rather than converted into fabricated evidence.
  const obs = observations.filter(isValidCalibrationObs);
  const n = obs.length;
  if (n === 0) {
    return {
      n: 0,
      ece: 0,
      bins: [],
      reliable: false,
      label: "ESTIMATE",
      skipLean: CAL_SKIP_LEAN_UNRELIABLE,
      note: "no calibration obs — unreliable by default",
    };
  }

  const bins: CalibrationBin[] = [];
  let eceSum = 0;
  for (let i = 0; i < edges.length - 1; i++) {
    const lo = edges[i]!;
    const hi = edges[i + 1]!;
    const inBin = obs.filter((o) => {
      const p = o.p;
      return i === edges.length - 2 ? p >= lo && p <= hi : p >= lo && p < hi;
    });
    const bn = inBin.length;
    if (bn === 0) {
      bins.push({ lo, hi, n: 0, meanP: (lo + hi) / 2, hitRate: 0, gap: 0 });
      continue;
    }
    const meanP = inBin.reduce((s, o) => s + o.p, 0) / bn;
    const hits = inBin.filter((o) => o.hit).length;
    const hitRate = hits / bn;
    const gap = Math.abs(hitRate - meanP);
    eceSum += gap * (bn / n);
    bins.push({
      lo,
      hi,
      n: bn,
      meanP: round4(meanP),
      hitRate: round4(hitRate),
      gap: round4(gap),
    });
  }

  const ece = round4(eceSum);
  // Display rounding must not turn a threshold failure into a pass.
  const reliable = n >= nMin && eceSum <= eceMax;
  const label: CalibrationReport["label"] =
    n >= nMin ? "MEASUREMENT" : "ESTIMATE";
  const skipLean = reliable ? 0 : CAL_SKIP_LEAN_UNRELIABLE;
  const note = reliable
    ? `ECE=${ece} n=${n} ≤${eceMax} — reliable`
    : `ECE=${ece} n=${n} (need n≥${nMin} & ECE≤${eceMax}) — unreliable → SKIP lean +${skipLean}`;

  return { n, ece, bins, reliable, label, skipLean, note };
}

// ── PR #14 gate sampler + bootstrap ─────────────────────────────────────────

const WINDOW_MS_15M = 15 * 60_000;

/**
 * Window key for dedupe: the 15m ticker IS the window. Legacy rows without a
 * ticker fall back to a 15-minute atMs bucket; rows with neither get a unique
 * key (cannot be deduped, never merged with another row).
 */
export function calibrationWindowKey(o: CalibrationObs, index: number): string {
  if (typeof o.ticker === "string" && o.ticker.trim()) return `t:${o.ticker.trim()}`;
  if (typeof o.atMs === "number" && Number.isFinite(o.atMs)) return `b:${Math.floor(o.atMs / WINDOW_MS_15M)}`;
  return `u:${index}`;
}

/**
 * Gate sampler — ONE sample per window: the first qualifying decision
 * (earliest atMs; ties keep ledger order). Fixes the paired YES+NO shadow bias
 * (both sides of one window → exactly one hit, pulling hit-rate to 50%).
 * Fills (incl. early exits resolved against settlement, source:"fill") and
 * shadows compete equally; each row's p is already scored against the outcome
 * of the side it refers to (hit = side === settled side).
 */
export function sampleCalibrationForGate(obs: readonly CalibrationObs[]): {
  sample: CalibrationObs[];
  nRaw: number;
  droppedSameWindow: number;
} {
  const valid = obs.filter(isValidCalibrationObs);
  const indexed = valid.map((o, i) => ({ o, i }));
  indexed.sort((a, b) => {
    const ta = typeof a.o.atMs === "number" && Number.isFinite(a.o.atMs) ? a.o.atMs : Number.POSITIVE_INFINITY;
    const tb = typeof b.o.atMs === "number" && Number.isFinite(b.o.atMs) ? b.o.atMs : Number.POSITIVE_INFINITY;
    return ta !== tb ? ta - tb : a.i - b.i;
  });
  const seen = new Set<string>();
  const sample: CalibrationObs[] = [];
  for (const { o, i } of indexed) {
    const k = calibrationWindowKey(o, i);
    if (seen.has(k)) continue;
    seen.add(k);
    sample.push(o);
  }
  return { sample, nRaw: valid.length, droppedSameWindow: valid.length - sample.length };
}

/** Deterministic PRNG (mulberry32) — stable gate decisions and tests. */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function binIndex(p: number, edges: readonly number[]): number {
  const last = edges.length - 2;
  for (let i = 0; i < last; i++) {
    if (p >= edges[i]! && p < edges[i + 1]!) return i;
  }
  return last;
}

/** ECE over an index multiset (bootstrap inner loop; same bins as computeCalibration). */
function eceIndexed(ps: Float64Array, ys: Uint8Array, bins: Int32Array, idx: Int32Array, nb: number): number {
  const sp = new Float64Array(nb);
  const sy = new Float64Array(nb);
  const cnt = new Float64Array(nb);
  for (let j = 0; j < idx.length; j++) {
    const k = idx[j]!;
    const b = bins[k]!;
    sp[b] += ps[k]!;
    sy[b] += ys[k]!;
    cnt[b] += 1;
  }
  let e = 0;
  for (let b = 0; b < nb; b++) if (cnt[b]! > 0) e += Math.abs(sy[b]! - sp[b]!) / idx.length;
  return e;
}

/**
 * Bootstrap test of H0: ECE ≤ threshold on an (already deduped) sample.
 * Returns the bias-corrected one-sided lower bound and p-value (see rule).
 */
export function bootstrapEceTest(
  sample: readonly CalibrationObs[],
  opts?: { B?: number; seed?: number; threshold?: number; alpha?: number; binEdges?: readonly number[] },
): { ece: number; eceLower95: number; pBoot: number; trip: boolean } {
  const B = opts?.B ?? CAL_GATE_BOOTSTRAP_B;
  const seed = opts?.seed ?? CAL_GATE_BOOTSTRAP_SEED;
  const thr = opts?.threshold ?? CAL_ECE_MAX_RELIABLE;
  const alpha = opts?.alpha ?? CAL_GATE_ALPHA;
  const edges = opts?.binEdges ?? CAL_BIN_EDGES;
  const n = sample.length;
  const nb = edges.length - 1;
  const ps = new Float64Array(n);
  const ys = new Uint8Array(n);
  const bins = new Int32Array(n);
  for (let i = 0; i < n; i++) {
    ps[i] = sample[i]!.p;
    ys[i] = sample[i]!.hit ? 1 : 0;
    bins[i] = binIndex(sample[i]!.p, edges);
  }
  const all = new Int32Array(n);
  for (let i = 0; i < n; i++) all[i] = i;
  const ece0 = n > 0 ? eceIndexed(ps, ys, bins, all, nb) : 0;
  if (n === 0 || B < 1) return { ece: ece0, eceLower95: ece0, pBoot: 1, trip: false };
  const rnd = mulberry32(seed);
  const reps = new Float64Array(B);
  const idx = new Int32Array(n);
  let atOrBelow = 0;
  for (let b = 0; b < B; b++) {
    for (let i = 0; i < n; i++) idx[i] = Math.floor(rnd() * n);
    const e = eceIndexed(ps, ys, bins, idx, nb);
    reps[b] = e;
    if (2 * ece0 - e <= thr) atOrBelow += 1;
  }
  const sorted = Array.from(reps).sort((a, c) => a - c);
  const q = sorted[Math.min(B - 1, Math.floor((1 - alpha) * B))]!;
  const eceLower95 = 2 * ece0 - q;
  const pBoot = atOrBelow / B;
  return { ece: ece0, eceLower95, pBoot, trip: eceLower95 > thr };
}

/**
 * PR #14 gate: sampler (one per window) + bootstrap rule. Same report shape
 * as computeCalibration; `reliable`/`skipLean`/`note` follow the new rule and
 * `gate` carries the numbers. n < nMin behaves exactly as before.
 */
export function computeCalibrationGate(
  observations: readonly CalibrationObs[],
  opts?: { nMinReliable?: number; eceThreshold?: number; B?: number; seed?: number; alpha?: number },
): CalibrationReport {
  const nMin = opts?.nMinReliable ?? CAL_N_MIN_RELIABLE;
  const thr = opts?.eceThreshold ?? CAL_ECE_MAX_RELIABLE;
  const B = opts?.B ?? CAL_GATE_BOOTSTRAP_B;
  const seed = opts?.seed ?? CAL_GATE_BOOTSTRAP_SEED;
  const alpha = opts?.alpha ?? CAL_GATE_ALPHA;
  const { sample, nRaw, droppedSameWindow } = sampleCalibrationForGate(observations);
  // Point stats (bins/ece) on the gate sample; legacy fixed verdict discarded.
  const base = computeCalibration(sample, { nMinReliable: nMin, eceMaxReliable: thr });
  const bySrc = calibrationSourceCounts(sample);
  const n = sample.length;
  let eceLower95: number | null = null;
  let pBoot: number | null = null;
  let trip = false;
  if (n >= nMin) {
    const t = bootstrapEceTest(sample, { B, seed, threshold: thr, alpha });
    eceLower95 = round4(t.eceLower95);
    pBoot = round4(t.pBoot);
    trip = t.trip;
  }
  const reliable = n >= nMin && !trip;
  const skipLean = reliable ? 0 : CAL_SKIP_LEAN_UNRELIABLE;
  const note = n === 0
    ? "no calibration obs — unreliable by default"
    : n < nMin
      ? `ECE=${base.ece} n=${n} (raw ${nRaw}, one per window; need n≥${nMin}) — unreliable → SKIP lean +${skipLean}`
      : reliable
        ? `ECE=${base.ece} n=${n} (raw ${nRaw}) bootstrap L95=${eceLower95} p=${pBoot} — miscalibration >${thr} not significant → reliable`
        : `ECE=${base.ece} n=${n} (raw ${nRaw}) bootstrap L95=${eceLower95} p=${pBoot} — miscalibration >${thr} significant → unreliable → SKIP lean +${skipLean}`;
  return {
    ...base,
    reliable,
    skipLean,
    note,
    gate: {
      rule: CAL_GATE_RULE,
      nRaw,
      n,
      droppedSameWindow,
      nFill: bySrc.fill,
      nShadow: bySrc.shadow,
      ece: base.ece,
      eceLower95,
      pBoot,
      threshold: thr,
      alpha,
      B,
      seed,
      trip,
    },
  };
}

let gateMemo: { ringRef: readonly CalibrationObs[]; key: string; report: CalibrationReport } | null = null;

/** Snapshot from in-process ring (desk / tests). PR #14: bootstrap gate. */
export function calibrationSnapshot(
  ring: readonly CalibrationObs[] = calRing,
): CalibrationReport {
  // Reliability counts only the current model/ruleset version (see scope knob).
  // Memo: calRing is replaced (never mutated) on record/load, so identity +
  // scope + model version pin the input; the bootstrap is deterministic anyway.
  const key = `${calibrationVersionScope()}|${currentCalibrationModelVersion()}|${runningGitSha() ?? ""}`;
  const memoOk = ring === calRing; // caller rings may be mutated in place — never memo those
  if (memoOk && gateMemo && gateMemo.ringRef === ring && gateMemo.key === key) return gateMemo.report;
  const report = computeCalibrationGate(scopeCalibrationObs(ring));
  if (memoOk) gateMemo = { ringRef: ring, key, report };
  return report;
}

/** Split n by data source — shadow (blocked takes) kept distinct from real fills. */
export function calibrationSourceCounts(
  ring: readonly CalibrationObs[] = calRing,
): { fill: number; shadow: number } {
  let fill = 0;
  let shadow = 0;
  for (const o of ring) {
    if (!isValidCalibrationObs(o)) continue;
    if (normSource(o.source) === "shadow") shadow += 1;
    else fill += 1;
  }
  return { fill, shadow };
}

/** Lean healthz payload — calib.n for operators. */
export function calibHealthz(): {
  n: number;
  ece: number;
  reliable: boolean;
  label: CalibrationReport["label"];
  note: string;
  nFill: number;
  nShadow: number;
  nTotal: number;
  scope: CalibrationVersionScope;
  modelVersion: string;
  gitSha: string | null;
  gate: CalibrationGateDetail | null;
} {
  const snap = calibrationSnapshot();
  const bySrc = calibrationSourceCounts(scopeCalibrationObs(calRing));
  return {
    n: snap.n,
    ece: snap.ece,
    reliable: snap.reliable,
    label: snap.label,
    note: snap.note,
    nFill: bySrc.fill,
    nShadow: bySrc.shadow,
    nTotal: calRing.length,
    gate: snap.gate ?? null,
    scope: calibrationVersionScope(),
    modelVersion: currentCalibrationModelVersion(),
    gitSha: runningGitSha(),
  };
}

/** Best-effort load at module init so n ≠ 0 after bounce when JSONL exists. */
const _inTestInit =
  process.env.NODE_TEST_CONTEXT != null
  || (typeof process.env.BOT_CONFIG_PATH === "string"
    && process.env.BOT_CONFIG_PATH.includes("/tmp"));
if (!_inTestInit) {
  try {
    loadCalibrationFromDisk();
  } catch {
    /* ignore */
  }
}
