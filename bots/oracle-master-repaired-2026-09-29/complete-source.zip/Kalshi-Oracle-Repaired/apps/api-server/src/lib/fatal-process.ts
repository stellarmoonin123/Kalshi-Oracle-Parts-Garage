import { writeSync } from "node:fs";

/** Fatal process state must never return to the trading event loop. */
export function installFatalProcessHandlers(): void {
  const terminate = (event: "uncaughtException" | "unhandledRejection") => {
    try {
      // Synchronous, bounded metadata survives immediate exit and cannot expose
      // arbitrary rejection payloads (which may contain credentials).
      writeSync(2, JSON.stringify({ level: "fatal", event, exitCode: 1,
        message: "Process state is unsafe; exiting for supervisor recovery" }) + "\n");
    } finally {
      // No async recovery, order placement, or graceful-close attempt is safe
      // after an unhandled error. Startup reconciles durable pending trades.
      process.exit(1);
    }
  };
  process.on("uncaughtException", () => terminate("uncaughtException"));
  process.on("unhandledRejection", () => terminate("unhandledRejection"));
}
