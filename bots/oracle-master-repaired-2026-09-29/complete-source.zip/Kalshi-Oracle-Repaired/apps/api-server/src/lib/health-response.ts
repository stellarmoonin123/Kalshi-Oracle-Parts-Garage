/** Anonymous probes must never expose the authenticated desk report. */
export function healthResponse<T extends { healthy: boolean; timestamp: string }>(report: T, authenticated: boolean): T | { healthy: boolean; timestamp: string } {
  return authenticated ? report : { healthy: report.healthy, timestamp: report.timestamp };
}
