/**
 * bollinger-bands.ts — Shared Bollinger Band math + a self-calibrating squeeze detector.
 *
 * Extracted so the live bot (trading-bot.ts obs-builder), the strategy
 * library (BOLLINGER_BAND strategy), the regime classifier
 * (condition-adapter.ts squeeze detection), and the historical backtester
 * (historical-backtester.ts calcBBPercent) all compute the identical band
 * math from one place instead of duplicating (and potentially drifting).
 *
 * Research basis: John Bollinger, "Bollinger on Bollinger Bands" (2001).
 * %B and bandwidth are the two standard derived readings:
 *   %B    — where price sits within the bands (0 = lower band, 1 = upper band,
 *           can exceed [0,1] on a strong break).
 *   Bandwidth — (upper - lower) / mean, a normalized measure of how wide the
 *           bands currently are. A "squeeze" is bandwidth compressing to an
 *           unusually low value relative to its OWN recent history — there is
 *           no universal absolute threshold, since normal bandwidth varies by
 *           instrument and volatility regime.
 */

export interface BollingerBandsResult {
  mean:         number;
  upper:        number;
  lower:        number;
  stdDev:       number;
  /** Where price sits within the bands: 0 = lower band, 1 = upper band. Not clamped — can go <0 or >1 on a strong break. */
  percentB:     number;
  /** (upper - lower) / mean * 100 — normalized band width. */
  bandwidthPct: number;
}

/**
 * Computes Bollinger Bands from a series of closes. Returns null when there
 * isn't enough history yet (period samples minimum) — callers must treat
 * that as "insufficient data", never substitute a default reading.
 */
export function computeBollingerBands(
  closes: number[],
  period = 20,
  stdDevMult = 2,
): BollingerBandsResult | null {
  if (closes.length < period) return null;
  const slice    = closes.slice(-period);
  const mean     = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((s, v) => s + (v - mean) ** 2, 0) / period;
  const stdDev   = Math.sqrt(variance);
  const upper    = mean + stdDevMult * stdDev;
  const lower    = mean - stdDevMult * stdDev;
  const width    = upper - lower;
  const last     = closes[closes.length - 1];

  const percentB     = width > 1e-9 ? (last - lower) / width : 0.5;
  const bandwidthPct = mean > 0 ? (width / mean) * 100 : 0;

  return { mean, upper, lower, stdDev, percentB, bandwidthPct };
}

// ── Self-calibrating squeeze detector ───────────────────────────────────────

const SQUEEZE_HISTORY_MAX    = 200; // rolling window of past bandwidth readings
const SQUEEZE_MIN_HISTORY    = 30;  // don't declare a squeeze off a thin history
const SQUEEZE_PERCENTILE     = 0.20; // bottom 20th percentile of own recent bandwidth

/**
 * Tracks a rolling history of bandwidth readings and flags a squeeze when the
 * current bandwidth sits in the bottom ~20th percentile of its own recent
 * history — a self-calibrating definition (per Bollinger's own guidance) that
 * avoids inventing an arbitrary absolute bandwidth threshold, which would
 * need separate tuning per volatility regime.
 *
 * Also tracks how many updates have passed since the last squeeze reading, so
 * callers (e.g. a squeeze-breakout strategy) can detect "a squeeze recently
 * ended" without needing their own state machine.
 */
export class BollingerSqueezeTracker {
  private history: number[] = [];
  private ticksSinceSqueeze = Infinity;

  /** Feed the latest bandwidthPct reading. Returns undefined until enough history has accumulated. */
  update(bandwidthPct: number): boolean | undefined {
    this.history.push(bandwidthPct);
    if (this.history.length > SQUEEZE_HISTORY_MAX) this.history.shift();
    if (this.history.length < SQUEEZE_MIN_HISTORY) return undefined;

    const sorted    = [...this.history].sort((a, b) => a - b);
    const idx       = Math.floor(sorted.length * SQUEEZE_PERCENTILE);
    const threshold = sorted[Math.min(idx, sorted.length - 1)];
    const isSqueeze = bandwidthPct <= threshold;

    this.ticksSinceSqueeze = isSqueeze ? 0 : this.ticksSinceSqueeze + 1;
    return isSqueeze;
  }

  /** True when a squeeze reading occurred within the last `withinUpdates` calls to update() (but isn't the current reading). */
  recentlyExpanded(withinUpdates = 12): boolean {
    return this.ticksSinceSqueeze > 0 && this.ticksSinceSqueeze <= withinUpdates;
  }

  reset() {
    this.history = [];
    this.ticksSinceSqueeze = Infinity;
  }
}
