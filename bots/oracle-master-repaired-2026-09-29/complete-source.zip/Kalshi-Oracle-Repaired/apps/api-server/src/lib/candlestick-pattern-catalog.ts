/**
 * candlestick-pattern-catalog.ts — static candlestick-pattern encyclopedia.
 *
 * Pure reference data (no market I/O, no gating logic) describing every
 * pattern name the live detector in candlestick-patterns.ts can emit, plus
 * several well-known patterns the detector does not (yet) scan for — kept
 * here anyway so the Markets page can teach the full classical vocabulary,
 * not just the subset that's cheaply/reliably detectable on 1-minute BTC
 * candles. `autoDetected: false` entries are informational only.
 *
 * Sourced from the same classical references as candlestick-patterns.ts:
 * Munehisa Homma's Sakata Goho tradition (18th-century rice-trading records)
 * and standard Western candlestick-charting literature (Nison et al.) that
 * catalogued and renamed the same shapes. This file is display/education
 * only — it never feeds sizing, EV, or gating logic.
 */

export type PatternDirection = 'bullish' | 'bearish' | 'neutral';
export type PatternCategory = 'single' | 'double' | 'triple' | 'swing';
export type PatternReliability = 'low' | 'moderate' | 'high';

export interface PatternCatalogEntry {
  /** Matches CandlePatternName in candlestick-patterns.ts when autoDetected is true. */
  id: string;
  name: string;
  /** Classical Sakata/Japanese name, when one exists. */
  aka?: string;
  category: PatternCategory;
  direction: PatternDirection;
  reliability: PatternReliability;
  /** What the candle shape physically looks like. */
  description: string;
  /** The market psychology / order-flow story behind the shape. */
  whatItMeans: string;
  /** Plain-English guidance: confirmation to wait for, entry, stop, target. */
  howToTrade: string;
  /** Whether the live scanner on the Markets page currently looks for this shape. */
  autoDetected: boolean;
}

export const PATTERN_CATALOG: PatternCatalogEntry[] = [
  // ── Single-candle ──────────────────────────────────────────────────────────
  {
    id: 'HAMMER', name: 'Hammer', category: 'single', direction: 'bullish', reliability: 'moderate',
    autoDetected: true,
    description: 'A small body near the top of the candle with a long lower wick (at least ~2× the body) and little or no upper wick, appearing after a decline.',
    whatItMeans: 'Sellers pushed price sharply lower intraperiod, but buyers stepped in and drove it back up near the open — a rejection of the lows. On its own it only shows a stall, not a reversal.',
    howToTrade: 'Wait for the NEXT candle to close above the hammer\'s high before entering long — that confirmation is what turns "sellers got tired" into "buyers are in control." Place a stop just below the hammer\'s low; the setup is invalidated if price revisits that low. Take partial profit at the most recent swing high or a fixed R multiple.',
  },
  {
    id: 'HANGING_MAN', name: 'Hanging Man', category: 'single', direction: 'bearish', reliability: 'moderate',
    autoDetected: true,
    description: 'Same shape as a Hammer — small body near the top, long lower wick, little upper wick — but appearing after an ADVANCE instead of a decline.',
    whatItMeans: 'Despite the uptrend, sellers were able to drag price well below the open before buyers clawed it back — the first sign that the buying pressure that built the trend may be running out.',
    howToTrade: 'Needs a bearish confirmation candle (a close below the hanging man\'s low) before acting — many hanging men are simply absorbed and the uptrend continues. If confirmed, short with a stop above the hanging man\'s high and target the next support level.',
  },
  {
    id: 'INVERTED_HAMMER', name: 'Inverted Hammer', category: 'single', direction: 'bullish', reliability: 'moderate',
    autoDetected: true,
    description: 'A small body near the bottom of the candle with a long upper wick and little or no lower wick, appearing after a decline — visually the Hammer flipped upside down.',
    whatItMeans: 'Buyers tried to push price up sharply intraperiod; the push was sold back down, but the attempt itself shows the first real buying interest after a slide.',
    howToTrade: 'Like the Hammer, treat it as a heads-up rather than a signal on its own — wait for a close above the inverted hammer\'s high before entering long. Stop below its low. This is a weaker setup than a Hammer since the failed upside push shows sellers are still active.',
  },
  {
    id: 'SHOOTING_STAR', name: 'Shooting Star', category: 'single', direction: 'bearish', reliability: 'moderate',
    autoDetected: true,
    description: 'A small body near the bottom of the candle with a long upper wick (at least ~2× the body) and little lower wick, appearing after a rally.',
    whatItMeans: 'Buyers pushed price sharply higher intraperiod, but sellers overwhelmed them and drove it back down near the open — a rejection of the highs after an advance.',
    howToTrade: 'Wait for the next candle to close below the shooting star\'s low before shorting — that confirms the rejection rather than a brief pause. Stop above the shooting star\'s high. Target the next support / a fixed R multiple.',
  },
  {
    id: 'BULLISH_MARUBOZU', name: 'Bullish Marubozu', category: 'single', direction: 'bullish', reliability: 'moderate',
    autoDetected: true,
    description: 'A long solid candle that opens at (or almost at) its low and closes at (or almost at) its high, with little to no wick on either end.',
    whatItMeans: 'Buyers were in control from the opening print to the close with essentially no seller pushback — one of the cleanest single-candle displays of conviction.',
    howToTrade: 'Often used as continuation confirmation rather than a standalone reversal signal — favor longs on the next pullback toward the marubozu\'s midpoint rather than chasing the close. A stop below the marubozu\'s low keeps risk defined if the conviction reverses immediately.',
  },
  {
    id: 'BEARISH_MARUBOZU', name: 'Bearish Marubozu', category: 'single', direction: 'bearish', reliability: 'moderate',
    autoDetected: true,
    description: 'A long solid candle that opens at (or almost at) its high and closes at (or almost at) its low, with little to no wick on either end.',
    whatItMeans: 'Sellers controlled the entire period from open to close with essentially no buyer pushback.',
    howToTrade: 'Treat as strong continuation confirmation for existing short positions rather than a fresh standalone signal; favor shorts on the next bounce toward the marubozu\'s midpoint. Stop above the marubozu\'s high.',
  },
  {
    id: 'DOJI', name: 'Doji', category: 'single', direction: 'neutral', reliability: 'low',
    autoDetected: true,
    description: 'Open and close are essentially equal, so the body all but disappears, regardless of how long the wicks are.',
    whatItMeans: 'Buyers and sellers fought to a standstill over the period — the market is genuinely undecided about direction right now.',
    howToTrade: 'A Doji is a "no edge here" signal on its own, not a trade trigger — the right action is usually to stand aside until the NEXT candle breaks decisively above or below the Doji\'s range. Its significance is amplified when it appears after a strong trend (see Morning/Evening Doji Star below).',
  },
  {
    id: 'DRAGONFLY_DOJI', name: 'Dragonfly Doji', category: 'single', direction: 'bullish', reliability: 'moderate',
    autoDetected: true,
    description: 'A Doji whose open, close, and high all sit at (or almost at) the top of the range, with a long lower wick and essentially no upper wick.',
    whatItMeans: 'A Hammer-like rejection of the lows, but with the added significance that open equals close exactly — an especially clean signature of a failed sell-off, most meaningful after a decline.',
    howToTrade: 'Wait for a bullish confirmation candle before entering; stop below the Dragonfly\'s low. Most reliable at the bottom of a downtrend or at a known support level, weaker mid-range.',
  },
  {
    id: 'GRAVESTONE_DOJI', name: 'Gravestone Doji', category: 'single', direction: 'bearish', reliability: 'moderate',
    autoDetected: true,
    description: 'A Doji whose open, close, and low all sit at (or almost at) the bottom of the range, with a long upper wick and essentially no lower wick.',
    whatItMeans: 'A Shooting-Star-like rejection of the highs with open exactly equal to close — most meaningful after an advance or at resistance.',
    howToTrade: 'Wait for a bearish confirmation candle before shorting; stop above the Gravestone\'s high. Strongest at the top of an uptrend or a known resistance level.',
  },
  {
    id: 'LONG_LEGGED_DOJI', name: 'Long-Legged Doji', category: 'single', direction: 'neutral', reliability: 'low',
    autoDetected: true,
    description: 'A Doji with long wicks on BOTH sides — price traveled far in both directions during the period before closing back near the open.',
    whatItMeans: 'Extreme two-way disagreement and volatility with no net winner — often marks a turning point or a volatile chop zone rather than a directional edge.',
    howToTrade: 'Stand aside until the next candle establishes direction with a close outside the Doji\'s range; the wide wicks mean any stop placed at the Doji\'s extremes is unusually far away, so size down if trading the breakout.',
  },
  {
    id: 'SPINNING_TOP', name: 'Spinning Top', category: 'single', direction: 'neutral', reliability: 'low',
    autoDetected: true,
    description: 'A small real body centered between two wicks of roughly similar (moderate, not extreme) length on both sides.',
    whatItMeans: 'Similar story to a Doji but with a small real body instead of none — a modest tug-of-war with no clear winner.',
    howToTrade: 'Treat as a caution flag that momentum is fading rather than a trade trigger by itself; look for a same-direction Spinning Top run to strengthen (or a reversal candle to weaken) the read before committing.',
  },

  // ── Double-candle ────────────────────────────────────────────────────────
  {
    id: 'BULLISH_ENGULFING', name: 'Bullish Engulfing', category: 'double', direction: 'bullish', reliability: 'high',
    autoDetected: true,
    description: 'A falling candle is immediately followed by a rising candle whose body fully "swallows" the prior candle\'s body (opens at/below the prior close, closes at/above the prior open).',
    whatItMeans: 'One of the most statistically consistent two-candle reversal signals: a full round of selling gets completely overrun by buying within a single following period — a genuine shift in control, not just a pause.',
    howToTrade: 'Most reliable after a clear downtrend. Enter long on the close of the engulfing candle or on a pullback into its body; stop below the engulfing candle\'s low (or the prior candle\'s low for extra room). Target the next resistance / prior swing high.',
  },
  {
    id: 'BEARISH_ENGULFING', name: 'Bearish Engulfing', category: 'double', direction: 'bearish', reliability: 'high',
    autoDetected: true,
    description: 'A rising candle is immediately followed by a falling candle whose body fully swallows the prior candle\'s body.',
    whatItMeans: 'A full round of buying gets completely overrun by selling in one period — most meaningful after an uptrend, signaling that buyers just lost control.',
    howToTrade: 'Enter short on the close of the engulfing candle or on a bounce into its body; stop above the engulfing candle\'s high. Target the next support / prior swing low.',
  },
  {
    id: 'BULLISH_HARAMI', name: 'Bullish Harami', category: 'double', direction: 'bullish', reliability: 'moderate',
    autoDetected: true,
    aka: 'Pregnant line',
    description: 'A large falling candle is followed by a small rising (or small-bodied) candle whose entire body sits INSIDE the prior candle\'s body — the mirror image of Engulfing.',
    whatItMeans: 'The strong selling momentum abruptly compresses into a narrow-range candle — sellers have stopped pressing and the move is losing energy, though buyers haven\'t yet taken control.',
    howToTrade: 'Weaker than an Engulfing pattern — wait for a further bullish close above the harami\'s high before entering. Stop below the low of the large first candle. Best used at support / after an extended decline.',
  },
  {
    id: 'BEARISH_HARAMI', name: 'Bearish Harami', category: 'double', direction: 'bearish', reliability: 'moderate',
    autoDetected: true,
    description: 'A large rising candle is followed by a small falling (or small-bodied) candle whose entire body sits inside the prior candle\'s body.',
    whatItMeans: 'Strong buying momentum abruptly compresses — buyers have stopped pressing, though sellers haven\'t yet confirmed control.',
    howToTrade: 'Wait for a further bearish close below the harami\'s low before shorting. Stop above the high of the large first candle. Best used at resistance / after an extended advance.',
  },
  {
    id: 'PIERCING_LINE', name: 'Piercing Line', category: 'double', direction: 'bullish', reliability: 'moderate',
    autoDetected: true,
    description: 'A falling candle is followed by a rising candle that opens BELOW the prior candle\'s low, then closes above the midpoint of the prior candle\'s body (but not above its open).',
    whatItMeans: 'Sellers pushed the open even lower, but buyers reversed it hard enough to erase over half of the prior decline within one period — a strong but not-quite-complete reversal (compare to the fuller Bullish Engulfing).',
    howToTrade: 'Treat similarly to a Bullish Engulfing but slightly weaker — confirm with the next candle holding above the piercing candle\'s midpoint before adding size. Stop below the pattern\'s combined low.',
  },
  {
    id: 'DARK_CLOUD_COVER', name: 'Dark Cloud Cover', category: 'double', direction: 'bearish', reliability: 'moderate',
    autoDetected: true,
    description: 'A rising candle is followed by a falling candle that opens ABOVE the prior candle\'s high, then closes below the midpoint of the prior candle\'s body (but not below its open).',
    whatItMeans: 'Buyers pushed the open to a fresh high, but sellers reversed it hard enough to erase over half of the prior advance — a strong but not-quite-complete bearish reversal.',
    howToTrade: 'Confirm with the next candle holding below the dark-cloud candle\'s midpoint before shorting. Stop above the pattern\'s combined high.',
  },
  {
    id: 'TWEEZER_TOP', name: 'Tweezer Top', category: 'double', direction: 'bearish', reliability: 'low',
    autoDetected: true,
    description: 'Two (or more) consecutive candles whose highs land at essentially the same level, the first typically bullish and the second bearish, after an uptrend.',
    whatItMeans: 'The market tested the same ceiling twice and failed both times — a visible, specific resistance level that buyers could not clear.',
    howToTrade: 'A weak signal alone — much stronger when it lines up with an existing resistance level or a round number. Look for a bearish confirmation close below the tweezer low before shorting; stop just above the shared high.',
  },
  {
    id: 'TWEEZER_BOTTOM', name: 'Tweezer Bottom', category: 'double', direction: 'bullish', reliability: 'low',
    autoDetected: true,
    description: 'Two (or more) consecutive candles whose lows land at essentially the same level, the first typically bearish and the second bullish, after a downtrend.',
    whatItMeans: 'The market tested the same floor twice and held both times — a visible, specific support level that sellers could not break.',
    howToTrade: 'Strongest when it aligns with a known support level. Wait for a bullish confirmation close above the tweezer high before entering long; stop just below the shared low.',
  },

  // ── Triple-candle (Sanzon / "three" formations) ─────────────────────────────
  {
    id: 'THREE_WHITE_SOLDIERS', name: 'Three White Soldiers', category: 'triple', direction: 'bullish', reliability: 'high',
    aka: 'Sanpei', autoDetected: true,
    description: 'Three consecutive solid-bodied rising candles, each opening within the prior candle\'s body and closing at a new, higher high, with little upper wick.',
    whatItMeans: 'Sustained, steady buying pressure across three full periods with no meaningful pushback from sellers — one of the clearest displays of an established (or newly forming) uptrend.',
    howToTrade: 'Because the move is already extended by the time all three candles close, chasing the third candle\'s close is often late — better entries are on the first shallow pullback afterward, with a stop below the low of the third soldier. Watch for shrinking bodies/growing upper wicks on later candles as an early exhaustion warning.',
  },
  {
    id: 'THREE_BLACK_CROWS', name: 'Three Black Crows', category: 'triple', direction: 'bearish', reliability: 'high',
    aka: 'Sanpei', autoDetected: true,
    description: 'Three consecutive solid-bodied falling candles, each opening within the prior candle\'s body and closing at a new, lower low, with little lower wick.',
    whatItMeans: 'Sustained, steady selling pressure across three full periods with no meaningful buyer pushback.',
    howToTrade: 'Similarly, avoid chasing the third candle\'s close — better entries are on the first shallow bounce, with a stop above the high of the third crow. Watch for shrinking bodies/growing lower wicks as an early exhaustion warning.',
  },
  {
    id: 'MORNING_STAR', name: 'Morning Star', category: 'triple', direction: 'bullish', reliability: 'high',
    autoDetected: true,
    description: 'A large falling candle, then a small-bodied candle that gaps or drifts lower (the "star"), then a rising candle that closes back into (ideally past the midpoint of) the first candle\'s body.',
    whatItMeans: 'A three-act reversal story: strong selling, then hesitation/indecision as the selling loses steam, then buyers decisively retaking the ground that was lost — a well-documented, reliable bottoming signal.',
    howToTrade: 'Enter long on the close of the third candle, or a pullback into it; stop below the low of the star (middle) candle or the pattern\'s overall low. Target the next resistance level. Confirmation with above-average volume on the third candle strengthens the read where volume data is available.',
  },
  {
    id: 'EVENING_STAR', name: 'Evening Star', category: 'triple', direction: 'bearish', reliability: 'high',
    autoDetected: true,
    description: 'A large rising candle, then a small-bodied candle that gaps or drifts higher (the "star"), then a falling candle that closes back into (ideally past the midpoint of) the first candle\'s body.',
    whatItMeans: 'The mirror of the Morning Star: strong buying, then hesitation as it stalls out, then sellers decisively retaking the ground — a reliable topping signal.',
    howToTrade: 'Enter short on the close of the third candle or a bounce into it; stop above the high of the star (middle) candle or the pattern\'s overall high. Target the next support level.',
  },
  {
    id: 'MORNING_DOJI_STAR', name: 'Morning Doji Star', category: 'triple', direction: 'bullish', reliability: 'high',
    autoDetected: true,
    description: 'A Morning Star where the middle "star" candle is specifically a Doji (open ≈ close) rather than just any small body, after a decline.',
    whatItMeans: 'An even sharper version of the Morning Star\'s indecision phase — the exact tie between buyers and sellers on the middle candle marks a precise pivot before the third candle confirms buyers won.',
    howToTrade: 'Same plan as a Morning Star: enter on/after the third candle\'s bullish close, stop below the Doji\'s low (or the pattern low), target the next resistance. Considered slightly more reliable than a plain Morning Star because the exact-tie Doji is a cleaner indecision signature.',
  },
  {
    id: 'EVENING_DOJI_STAR', name: 'Evening Doji Star', category: 'triple', direction: 'bearish', reliability: 'high',
    autoDetected: true,
    description: 'An Evening Star where the middle "star" candle is specifically a Doji, after an advance.',
    whatItMeans: 'A sharper version of the Evening Star\'s stall phase, with the exact buyer/seller tie on the middle candle marking a precise pivot before sellers confirm control on the third candle.',
    howToTrade: 'Same plan as an Evening Star: enter on/after the third candle\'s bearish close, stop above the Doji\'s high (or the pattern high), target the next support.',
  },

  // ── Swing (multi-candle price-structure formations) ─────────────────────────
  {
    id: 'DOUBLE_BOTTOM', name: 'Double Bottom', category: 'swing', direction: 'bullish', reliability: 'high',
    aka: 'W Bottom', autoDetected: true,
    description: 'Two comparable lows separated by a bounce (an intervening "neckline" peak), with price then closing back above that neckline — a "W" shape across many candles rather than a single/triple-candle body shape.',
    whatItMeans: 'The market tested a price floor, bounced, came back down to retest that same floor and held again — showing buyers are willing to defend that level twice — then broke back above the level where the first bounce failed, confirming demand is now stronger than supply there.',
    howToTrade: 'The neckline break IS the entry signal (unlike single-candle shapes, there is no further confirmation candle to wait for — this pattern is defined by the break itself). Stop below the second low; a revisit of that low invalidates the pattern. Target is typically measured as the neckline-to-trough distance projected upward from the breakout.',
  },
  {
    id: 'DOUBLE_TOP', name: 'Double Top', category: 'swing', direction: 'bearish', reliability: 'high',
    aka: 'M Top', autoDetected: true,
    description: 'The mirror of a Double Bottom: two comparable highs separated by a pullback (an intervening "neckline" trough), with price then closing back below that neckline — an "M" shape across many candles.',
    whatItMeans: 'The market tested a price ceiling twice and failed to break through either time, while the pullback low between the two highs is where buyers eventually gave up — confirming supply now dominates at that level.',
    howToTrade: 'The neckline break is the entry signal. Stop above the second high; a revisit of that high invalidates the pattern. Target is typically the neckline-to-peak distance projected downward from the breakout.',
  },
];

export const PATTERN_CATALOG_BY_ID: Record<string, PatternCatalogEntry> =
  Object.fromEntries(PATTERN_CATALOG.map(p => [p.id, p]));
