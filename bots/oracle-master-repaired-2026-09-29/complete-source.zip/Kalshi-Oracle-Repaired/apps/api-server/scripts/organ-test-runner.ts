/** Build/CI only. Never import this module from the runtime server. */
import { execFile } from "node:child_process";
import { promises as fs } from "node:fs";
import path from "node:path";
import { API_SERVER_ROOT, LIB_ROOT } from "../src/lib/organ-debug/hard-locks.js";
import type { OrganRegistryEntry } from "../src/lib/organ-debug/registry.js";
import type { OrganUnitTestResult } from "../src/lib/organ-debug/types.js";

function runNodeTest(filesAbs: string[], timeoutMs: number): Promise<OrganUnitTestResult> {
  return new Promise((resolve) => {
    if (filesAbs.length === 0) {
      resolve({
        ran: false,
        ok: null,
        passed: 0,
        failed: 0,
        timedOut: false,
        files: [],
      });
      return;
    }
    const args = [
      "--import",
      "./load-env.mjs",
      "--import",
      "./isolate-strategy-learning-test.mjs",
      "--import",
      "tsx",
      "--test",
      "--test-force-exit",
      ...filesAbs,
    ];
    const env = {
      ...process.env,
      BOT_CONFIG_PATH:
        process.env.BOT_CONFIG_PATH || "/tmp/api-server-organ-debug-bot-config.json",
    };
    execFile(
      process.execPath,
      args,
      {
        cwd: API_SERVER_ROOT,
        timeout: timeoutMs,
        maxBuffer: 4 * 1024 * 1024,
        env,
      },
      (err, stdout, stderr) => {
        const out = `${stdout ?? ""}\n${stderr ?? ""}`;
        const timedOut =
          !!err &&
          ((err as NodeJS.ErrnoException & { killed?: boolean }).killed === true ||
            /TIMEOUT|timed out/i.test(String(err.message)));
        const passMatch = out.match(/ℹ pass (\d+)/) || out.match(/# pass (\d+)/);
        const failMatch = out.match(/ℹ fail (\d+)/) || out.match(/# fail (\d+)/);
        const passed = passMatch ? parseInt(passMatch[1], 10) : 0;
        const failed = failMatch
          ? parseInt(failMatch[1], 10)
          : timedOut
            ? 1
            : err
              ? 1
              : 0;
        const ok = !timedOut && !err && failed === 0;
        resolve({
          ran: true,
          ok,
          passed,
          failed,
          timedOut,
          error: timedOut
            ? `unit tests timed out after ${timeoutMs}ms`
            : err && failed === 0
              ? (err.message || String(err)).slice(0, 500)
              : undefined,
          files: filesAbs.map((f) => path.relative(LIB_ROOT, f)),
        });
      },
    );
  });
}

async function existingTestFiles(relPaths: string[]): Promise<string[]> {
  const out: string[] = [];
  for (const rel of relPaths) {
    const abs = path.join(LIB_ROOT, rel);
    try {
      await fs.access(abs);
      out.push(abs);
    } catch {
      /* optional */
    }
  }
  return out;
}

/** R3 — used only by scripts/organ-test-receipt.ts on the build/dev box (never at runtime). */
export async function runOrganTestsForReceipt(
  entry: OrganRegistryEntry,
  timeoutMs = 180_000,
): Promise<OrganUnitTestResult> {
  const files = await existingTestFiles(entry.testPaths);
  return runNodeTest(files, timeoutMs);
}
