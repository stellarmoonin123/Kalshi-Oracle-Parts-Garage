/**
 * ai-client.test.ts — Test the AI client functionality
 */
import { test, describe, afterEach } from "node:test";
import * as assert from "node:assert/strict";
import { aiComplete, aiCompleteJSON, getRateLimitStatus } from "./ai-client.js";

const originalFetch = globalThis.fetch;

afterEach(() => {
  globalThis.fetch = originalFetch;
});

describe("AI Client", () => {
  test("aiComplete() responds to a simple prompt", async () => {
    // Skip if no API keys configured
    const hasKey = !!(process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY || process.env.XAI_API_KEY);
    if (!hasKey) {
      console.log("⚠️ Skipping test: No AI API keys configured");
      return;
    }
    
    console.log("🧪 Testing aiComplete() with simple prompt...");
    
    const response = await aiComplete(
      "You are a helpful assistant.",
      "Say hello in exactly 5 words.",
      { maxTokens: 50, temperature: 0.5, timeoutMs: 30000 }
    );
    
    console.log("✅ AI Response:", response);
    
    // Basic validation
    assert.ok(response.length > 0, "Response should not be empty");
    assert.ok(response.length < 200, "Response should be concise (under 200 chars)");
    
    console.log("✅ Test passed - AI client is working");
  });
  
  test("getRateLimitStatus() returns status object", () => {
    const status = getRateLimitStatus();
    assert.ok(typeof status === "object", "Status should be an object");
    console.log("✅ Rate limit status:", Object.keys(status).length === 0 ? "(no rate limits)" : status);
  });

  test("aiCompleteJSON skips a provider with empty content and uses the next model", async () => {
    const hasOpenRouterKey = !!process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY;
    if (!hasOpenRouterKey) {
      console.log("⚠️ Skipping fallback test: No OpenRouter API key configured");
      return;
    }

    const requestedModels: string[] = [];
    globalThis.fetch = async (_input, init) => {
      const body = JSON.parse(String(init?.body)) as { model?: string };
      requestedModels.push(body.model ?? "");

      if (requestedModels.length === 1) {
        return new Response(JSON.stringify({
          choices: [{ message: { content: null }, finish_reason: "length" }],
        }), { status: 200, headers: { "content-type": "application/json" } });
      }

      return new Response(JSON.stringify({
        choices: [{ message: { content: '{"ok":true}' }, finish_reason: "stop" }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    };

    const result = await aiCompleteJSON<{ ok: boolean }>(
      "Return JSON.",
      "Confirm the fallback.",
      {
        model: "deepseek/deepseek-r1-0528",
        maxTokens: 32,
        timeoutMs: 1_000,
      },
    );

    assert.deepEqual(result, { ok: true });
    assert.equal(requestedModels.length, 2, "empty content should advance to the next model immediately");
    assert.equal(requestedModels[0], "deepseek/deepseek-r1-0528");
    assert.notEqual(requestedModels[1], requestedModels[0]);
  });
});
