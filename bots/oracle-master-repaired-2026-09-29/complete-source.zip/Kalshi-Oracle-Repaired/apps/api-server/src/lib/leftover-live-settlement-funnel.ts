/**
 * Leftover live Kalshi settlements API + unresolved timeout.
 * Paper KXBTC15M never runs it. Paper SETTLEMENT stays in host detectSettlement.
 * Does not ENABLE, cut EV/Kelly/9%, or flip paperMode. Does not stamp officialYesNo from side×win.
 */
import { KALSHI_API_DOMAIN, kalshiSettlementsPath, kalshiTakerFeeCents, SETTLEMENT_UNRESOLVED_TIMEOUT_MS } from "./constants.js";
import { resolveSkipsForTicker } from "./skip-settlement-resolver.js";

/** Archive no longer exports this; leftover live path stays fail-closed. */
function extractExplicitKalshiYesNo(_match: unknown): "yes" | "no" | null {
  return null;
}

export const LEFTOVER_LIVE_SETTLEMENT_LOADED = true as const;

export const FROZEN_LIVE_SETTLEMENT_MARKERS = [
  "kalshiSettlementsPath(5)",
  'SETTLED_KALSHI", true, true, explicitYesNo',
  "extractExplicitKalshiYesNo(match)",
  "Settlement API fetch failed",
] as const;

export type LeftoverLiveSettlementHelpers = {
  kalshiAuthHeaders: (method: string, apiPath: string) => Promise<Record<string, string>>;
  resolveSettlementFallbackOutcome: (...args: any[]) => { action: string; since?: number; elapsedMs: number };
};

export async function leftoverLiveSettlementFunnel(this: any, helpers: LeftoverLiveSettlementHelpers): Promise<void> {
  const trade = this.openTrade;
  if (!trade || trade.paper) return;
  const { kalshiAuthHeaders, resolveSettlementFallbackOutcome } = helpers;

    try {
      const apiPath = kalshiSettlementsPath(5);
      const r       = await fetch(`${KALSHI_API_DOMAIN}${apiPath}`, {
        headers: { ...await kalshiAuthHeaders("GET", apiPath), Accept: "application/json" },
        signal: AbortSignal.timeout(6_000),
      });
      if (r.ok) {
        const data = (await r.json()) as { settlements?: Array<{ ticker: string; revenue: number; profit?: number; result?: string }> };
        const match = (data.settlements ?? []).find(s => s.ticker === trade.ticker);
        if (match) {
          // match.profit from Kalshi API is already net of fees.
          // The manual fallback (revenue − cost) is gross — fee-adjust it.
          const grossProfit    = match.revenue - trade.contracts * trade.entryPriceCents;
          // The entry (taker) fee was paid regardless of outcome — subtract it on losses too.
          const fallbackFee    = kalshiTakerFeeCents(trade.entryPriceCents, trade.contracts);
          const profit         = match.profit ?? (grossProfit - fallbackFee);
          // Win/loss is the contract result (revenue > 0), not the sign of
          // fee-net profit — a won contract at a rich ask is still a win.
          const won            = match.revenue > 0;
          // Infer contract YES/NO from our side × win, then label sat-outs.
          const settledYesNo   = trade.side === "yes" ? (won ? "YES" : "NO") : (won ? "NO" : "YES");
          try { resolveSkipsForTicker(trade.ticker, settledYesNo); } catch { /* observational */ }
          const explicitYesNo  = extractExplicitKalshiYesNo(match);
          await this.recordSettlement(trade, won ? "win" : "loss", Math.round(profit), match.revenue, undefined, "SETTLED_KALSHI", true, true, explicitYesNo);
          return;
        }
      }
    } catch (err) {
      this.log("warn", `Settlement API fetch failed: ${(err as Error).message}`);
    }

    // Settlement API unavailable or had no match for this ticker yet.
    // BUG FIX (settlement-fallback): this used to infer win/loss from the
    // last fresh BTC price observation (tick.floorStrike / lastObs vs
    // trade.floorStrike) whenever Kalshi's own settlement wasn't available —
    // a stale (up to 90s-old) proxy price could book the OPPOSITE of
    // Kalshi's real outcome at a boundary, and even though that heuristic
    // outcome was flagged authoritative=false (excluded from strategy
    // learning), it still advanced todayStats/paperStats win-loss counters
    // and the consecutive-loss streak via recordSettlement()'s default
    // affectsRiskCounters=true — i.e. it silently invented a settled result
    // that moved live risk state. Removed entirely: Kalshi is the only
    // source of truth for a live settlement outcome. We only ever retry
    // (poll) or, after a bounded timeout, give up cleanly as "unresolved"
    // (no win/loss booked, no risk counters touched) — see
    // resolveSettlementFallbackOutcome().
    const outcome = resolveSettlementFallbackOutcome(
      this.settlementUnresolvedSinceTs,
      Date.now(),
      SETTLEMENT_UNRESOLVED_TIMEOUT_MS,
    );
    if (outcome.action === "keep-waiting") {
      if (outcome.since !== this.settlementUnresolvedSinceTs) this.settlementUnresolvedSinceTs = outcome.since;
      this.log("warn",
        `Settlement API unavailable/no match for ${trade.ticker} — retrying (${Math.round(outcome.elapsedMs / 1000)}s of ${Math.round(SETTLEMENT_UNRESOLVED_TIMEOUT_MS / 1000)}s timeout)`
      );
    } else {
      await this.recordUnresolvedSettlement(trade,
        `Kalshi settlement unavailable/no match for ${Math.round(outcome.elapsedMs / 1000)}s (timeout ${Math.round(SETTLEMENT_UNRESOLVED_TIMEOUT_MS / 1000)}s) — no win/loss booked.`
      );
    }
}
