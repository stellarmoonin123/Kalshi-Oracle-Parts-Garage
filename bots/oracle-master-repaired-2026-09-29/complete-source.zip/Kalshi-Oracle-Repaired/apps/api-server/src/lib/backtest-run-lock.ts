/**
 * Task #134: one grid search at a time.
 * GET /backtest/run (SSE) and POST /backtest/run share this mutex.
 * Busy → 409. Does not touch EV / paperMode / strategies.
 */
let gridRunning = false;

export function isGridSearchRunning(): boolean {
  return gridRunning;
}

/** True if this caller now owns the lock. */
export function tryAcquireGridSearch(): boolean {
  if (gridRunning) return false;
  gridRunning = true;
  return true;
}

export function releaseGridSearch(): void {
  gridRunning = false;
}
