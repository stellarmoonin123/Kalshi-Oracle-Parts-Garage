/**
 * Fill/exit authority for ARIA and the settlement-model veto.
 * Observational reads may still happen. These functions are the only
 * permission for those systems to skip an entry or flatten a ride.
 */
export function ariaMayGovernOrders(cfg: {
  useExpertAgent?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return cfg.useExpertAgent === true && cfg.frozenCcMode !== true;
}

export function settlementModelMayVetoEntry(cfg: {
  settlementVetoEnabled?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return cfg.settlementVetoEnabled === true && cfg.frozenCcMode !== true;
}
