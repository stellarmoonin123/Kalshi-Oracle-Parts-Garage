/**
 * money-gate-card.ts — EVALUATING card source of truth for the real take path.
 *
 * Composite pre-trade 74-score is keep-warm theater only and must NOT drive
 * this card's headline / checks / overall score. Fill director stays:
 *   MTF side + ask door YES 20–55 / NO 20–55 (still-mid 48–52 = SIT) + EV≥3 + W2 hard vetoes → Kelly.
 *   ha_disagree is tag-only (cannot fail this card / block a hard-gate TAKE).
 *
 * Card honesty (Phase 2): any hard skip → named SIT reason, never TAKE.
 * Surface names (aliases OK internally): HARVEST_CC_BLOCK, CC_VEL_AGAINST,
 * LAG_COLD, STILL_MID, ASK_OUT_OF_BAND, PIN, NO_TAPE, LAST_60S, PATH_GATE,
 * SIZE_ZERO. Token = winning gate; never sticky TAKE after placeOrder skip.
 *
 * Does not ENABLE leftovers. Does not cut EV_FLOOR. Does not flip paperMode.
 * Weekend: getCurrentSessionMode is always HUNT; HARVEST_CC_BLOCK only when
 * sessionMode==="HARVEST" is injected (asia/dead telemetry / tests).
 */
import { EV_FLOOR } from "./admission.js";
import {
  LAST_60S_BRTI_AVG_SKIP,
  STILL_MID_UNCLEAR_SKIP,
  inLast60sBrti,
  inStillMidCoinFlip,
  isLeftoverStrategyId,
  mtfSignToSide,
  type AlignedTake,
  type AlignedMtfSign,
} from "./aligned-take-gate.js";
import type { DirectionW2 } from "./organs/direction-w2.js";
import { HA_DISAGREE_SKIP } from "./organs/direction-w2.js";
import { assertLagAllowsMoneyMakerFill } from "./organs/lag-unproven-fill-gate.js";
import { isHarvestSessionFamilyAllowed } from "./settlement-side.js";
import {
  DESK_YES_ASK_MIN,
  DESK_YES_ASK_MAX,
  DESK_NO_ASK_MIN,
  DESK_NO_ASK_MAX,
  inDeskAskBand,
} from "./paper-desk-v2.js";
import { ccVelocityAgainstGate } from "./cc-velocity-gate.js";

export const MONEY_GATE_THRESHOLD = 100;

/** Quote / tape freshness for money-card NO_TAPE (Clock A, 5s). Split from lag series cold. */
export const MONEY_GATE_NO_TAPE_MS = 5_000;

/** Canonical SIT reason names surfaced on card/API. */
export type MoneyGateSitReason =
  | "HARVEST_CC_BLOCK"
  | "CC_VEL_AGAINST"
  | "CC_VEL_AGAINST_YES"
  | "CC_VEL_AGAINST_NO"
  | "LAG_COLD"
  | "STILL_MID"
  | "ASK_OUT_OF_BAND"
  | "PIN"
  | "NO_TAPE"
  | "LAST_60S"
  | "PATH_GATE"
  | "SIZE_ZERO"
  | string;

/** Map internal aliases → required card/API surface names. */
export function toMoneyGateSitReason(raw: string | null | undefined): string | null {
  if (raw == null || raw === "") return null;
  const s = String(raw).trim();
  const u = s.toUpperCase().replace(/-/g, "_");
  if (
    u === "HARVEST_CC_BLOCK"
    || u === "SESSION_FAMILY_SUPPRESSED"
    || u.includes("SESSION_FAMILY")
  ) return "HARVEST_CC_BLOCK";
  if (u === "CC_VEL_AGAINST" || u === "CC_VEL_AGAINST_YES" || u === "CC_VEL_AGAINST_NO") {
    return u === "CC_VEL_AGAINST" ? "CC_VEL_AGAINST" : u;
  }
  if (u.includes("CC_VEL_AGAINST")) {
    if (u.includes("YES")) return "CC_VEL_AGAINST_YES";
    if (u.includes("NO")) return "CC_VEL_AGAINST_NO";
    return "CC_VEL_AGAINST";
  }
  if (
    u === "LAG_COLD"
    || u === "LAG_UNPROVEN"
    || u === "LAG_UNPROVEN_NO_FILL"
    || u.includes("LAG_STALE")
    || u.includes("LAG_SHORT_SERIES")
    || u === "ASIA_LAG_UNPROVEN"
    || u === "LAG_UNPROVEN"
    || s === "lag_stale"
    || s === "lag_short_series"
    || s === "lag_unproven"
    || s === "asia_lag_unproven"
  ) return "LAG_COLD";
  if (
    u === "STILL_MID"
    || u === "STILL_MID_UNCLEAR"
    || s === STILL_MID_UNCLEAR_SKIP
    || u.includes("STILL_MID")
  ) return "STILL_MID";
  if (u === "ASK_OUT_OF_BAND" || s === "ask_out_of_band") return "ASK_OUT_OF_BAND";
  if (
    u === "PIN"
    || u === "BINARY_PIN"
    || s === "binary_pin"
    || u === "PIN_REACHABLE"
  ) return "PIN";
  if (u === "NO_TAPE" || u.includes("NO_TAPE") || u === "QUOTE_STALE_TAPE") return "NO_TAPE";
  if (
    u === "LAST_60S"
    || s === LAST_60S_BRTI_AVG_SKIP
    || u.includes("LAST_60S")
  ) return "LAST_60S";
  if (u === "PATH_GATE" || u.includes("PATH_GATE")) return "PATH_GATE";
  if (
    u === "NO_ELIGIBLE_STRATEGY"
    || u === "NO_ELIGIBLE"
    || u === "SELECT_MISS_GATED"
    || u.includes("NO_ELIGIBLE")
  ) return "NO_ELIGIBLE_STRATEGY";
  // LIVE hard AND sit (ha_disagree ∧ regimeWouldBlock) — named SIT, never fake TAKE.
  if (
    u === "AND_SIT_HA_REGIME"
    || u === "AND_SIT"
    || u.includes("AND_SIT_HA")
  ) return "AND_SIT_HA_REGIME";
  // Protective / Kelly / risk / depth size floors to 0 — named SIT, never sticky TAKE.
  if (
    u === "SIZE_ZERO"
    || u === "SIZING_ZERO"
    || u === "DAILY_TARGET_SIZE_ZERO"
    || u === "DEPTH_SIZE_ZERO"
    || u === "LIQ_HAIRCUT_ZERO"
    || u === "PROTECTIVE_SIZE_ZERO"
    || u === "DRAWDOWN_GUARD"
    || u === "RISK_PROFILE"
    || u.includes("SIZE_ZERO")
  ) return "SIZE_ZERO";
  return s;
}

export type MoneyGateCheck = {
  id: string;
  name: string;
  category: "money";
  passed: boolean;
  score: number;
  weight: number;
  detail: string;
  value?: string;
};

export type MoneyGateCard = {
  kind: "TAKE" | "SKIP";
  headline: string;
  /** 0–100 from required money checks only (not composite theater). */
  overallScore: number;
  scoreThreshold: number;
  approved: boolean;
  direction: "LONG" | "SHORT" | "FLAT";
  checks: MoneyGateCheck[];
  side: "yes" | "no" | null;
  ask: number | null;
  ev: number | null;
  p: number | null;
  /** Always winRateAtPrice — confidence never admitted as p. */
  pSource: "winRateAtPrice";
  /** UI / CC signal strength only — never used as p / Kelly / EV. */
  confidence?: number | null;
  strategyId: string | null;
  skipReason: string | null;
  w2Result: "PASS" | "SKIP" | null;
  lagProven: boolean;
  mtfScore: number | null;
  timestamp: number;
  /** Always false — 74 composite is not the fill gate. */
  compositeIsFillGate: false;
  /** Session / DOW / consensus are not on this card. */
  sessionLabel?: string;
};

export type BuildMoneyGateCardInput = {
  aligned: AlignedTake;
  w2: DirectionW2 | null;
  mtfSign?: AlignedMtfSign;
  lagProven?: boolean;
  lagStale?: boolean | null;
  lagReason?: string | null;
  timeOfDayRegime?: string | null;
  /** Admission session mode — HARVEST + non-exempt CC must never headline TAKE. */
  sessionMode?: "HUNT" | "HARVEST";
  secsRemaining?: number;
  /** Proposed / active strategy id (leftover HARD_NO_FILL check). */
  strategyId?: string | null;
  sessionClockLabel?: string;
  nowMs?: number;
  /** 1m velocity $/min — wires ccVelocityAgainstGate onto the card. */
  velocityDolPerMin?: number | null;
  /** Quote age ms — NO_TAPE when > MONEY_GATE_NO_TAPE_MS (Clock A). */
  quoteAgeMs?: number | null;
  /** Hard PIN skip (binary_pin / pinRisk). Tag-only pin_reachable does not set this. */
  pinHard?: boolean;
  /** PATH_GATE hard block already decided upstream. */
  pathGateBlocked?: boolean;
  pathGateReason?: string | null;
  /** UI confidence only — never admitted as p. */
  confidence?: number | null;
};

function chk(
  id: string,
  name: string,
  passed: boolean,
  detail: string,
  value?: string,
): MoneyGateCheck {
  return {
    id,
    name,
    category: "money",
    passed,
    score: passed ? 100 : 0,
    weight: 1,
    detail,
    value,
  };
}

function sideLabel(side: "yes" | "no" | null): string {
  if (side === "yes") return "YES";
  if (side === "no") return "NO";
  return "skip";
}

function directionFromSide(side: "yes" | "no" | null, mtfFlat: boolean): "LONG" | "SHORT" | "FLAT" {
  if (mtfFlat || side == null) return "FLAT";
  return side === "yes" ? "LONG" : "SHORT";
}

/**
 * Build the EVALUATING money-gate card from alignedTake + W2.
 * Score = % of required checks passed. TAKE only when every check passes
 * and aligned is TAKE and W2 is PASS (or aligned already encodes skip).
 */

/** Prefer first hard checklist FAIL for card headline (not stale aligned.reason). */
function firstHardMoneyFailReason(
  checks: MoneyGateCheck[],
  opts: {
    w2: DirectionW2 | null;
    ask: number | null;
    stillMid: boolean;
    ccVelReason?: string | null;
  },
): string | null {
  const HARD_ORDER = [
    "NO_TAPE",
    "PIN",
    "CC_VEL",
    "PATH_GATE",
    "SIDE_LOCK",
    "ASK_BAND",
    "EV",
    "W2",
    "LAG_PROVEN",
    "SESSION_FAMILY",
    "LAST_60S",
    "NOT_LEFTOVER",
  ] as const;
  for (const id of HARD_ORDER) {
    const c = checks.find(x => x.id === id);
    if (!c || c.passed) continue;
    if (id === "NO_TAPE") return "NO_TAPE";
    if (id === "PIN") return "PIN";
    if (id === "CC_VEL") return opts.ccVelReason ?? "CC_VEL_AGAINST";
    if (id === "PATH_GATE") return "PATH_GATE";
    if (id === "ASK_BAND") {
      return opts.stillMid ? "STILL_MID" : "ASK_OUT_OF_BAND";
    }
    if (id === "EV") return "ev_below_3";
    if (id === "W2") {
      const raw = opts.w2?.kind === "SKIP" ? opts.w2.reason : "w2_skip";
      return toMoneyGateSitReason(raw) ?? raw;
    }
    if (id === "LAG_PROVEN") return "LAG_COLD";
    if (id === "SESSION_FAMILY") return "HARVEST_CC_BLOCK";
    if (id === "LAST_60S") return "LAST_60S";
    if (id === "NOT_LEFTOVER") return "leftover_id";
    if (id === "SIDE_LOCK") return "mtf_sign_null";
  }
  return null;
}

export function buildMoneyGateCard(input: BuildMoneyGateCardInput): MoneyGateCard {
  const aligned = input.aligned;
  const w2 = input.w2;
  const lagProven = input.lagProven === true;
  const mtfSide = mtfSignToSide(input.mtfSign);
  const mtfFlat =
    input.mtfSign === 0 ||
    input.mtfSign === null ||
    input.mtfSign === undefined ||
    mtfSide == null;
  const mtfNum =
    typeof input.mtfSign === "number" && Number.isFinite(input.mtfSign)
      ? input.mtfSign
      : null;

  const takeSide = aligned.kind === "TAKE" ? aligned.side : (w2?.kind === "PASS" ? w2.side : mtfSide);
  const takeAsk = aligned.kind === "TAKE" ? aligned.ask : (w2?.kind === "PASS" ? w2.ask : null);
  const takeEv = aligned.kind === "TAKE" ? aligned.ev : null;
  const takeP = aligned.kind === "TAKE" ? aligned.p : null;
  const strategyId =
    aligned.kind === "TAKE"
      ? aligned.strategyId
      : (input.strategyId ?? null);

  // 1. Side lock — MTF flat/0 = skip, no SHORT lean
  const sidePass = !mtfFlat && mtfSide != null;
  const sideCheck = chk(
    "SIDE_LOCK",
    "Side lock (MTF)",
    sidePass,
    mtfFlat
      ? "MTF flat / 0 — no lean; money lock skips (not SHORT pass)."
      : `MTF side ${sideLabel(mtfSide)} (score ${mtfNum != null ? (mtfNum > 0 ? "+" : "") + mtfNum.toFixed(1) : "n/a"}).`,
    mtfFlat ? "0.0 FLAT" : sideLabel(mtfSide),
  );

  // 2. HA: tag-only when defined disagree (fill-power lock — cannot fail card)
  const haSide = w2?.log.ha_side ?? null;
  const lockSide = w2?.log.lock_side ?? takeSide;
  const haTagged =
    (w2?.log.lockSide_why === HA_DISAGREE_SKIP)
    || (haSide != null && lockSide != null && haSide !== lockSide);
  const haPass = true; // demoted off fill power
  const haCheck = chk(
    "HA",
    "HA tag (non-blocking)",
    haPass,
    haTagged
      ? `HA ${sideLabel(haSide)} ≠ lock ${sideLabel(lockSide)} (${HA_DISAGREE_SKIP}) — tag only, not a fill block.`
      : haSide == null
        ? "HA null — no tag."
        : `HA ${sideLabel(haSide)} agrees lock ${sideLabel(lockSide)}.`,
    haTagged ? `TAG:${HA_DISAGREE_SKIP}` : (haSide == null ? "null" : sideLabel(haSide)),
  );

  // 3. Ask band PAPER DESK v2 door ONLY: YES 20–55 / NO 20–55; still-mid 48–52 illegal.
  // Do NOT admit YES 10–27 via LAG floor on this card (fights desk door + lottery).
  const ask = takeAsk ?? w2?.log.ask_cents ?? null;
  const sideForBand: "yes" | "no" | null =
    takeSide === "yes" || takeSide === "no" ? takeSide : null;
  // When MTF is flat there is no lean side — ask door is N/A (not a hard fail).
  // Painting ASK_BAND fail with "ask missing" while SIDE_LOCK already skipped is a
  // display lie that buries the real sit reason (mtf_sign_null).
  const askInBand = (
    sideForBand != null
    && typeof ask === "number"
    && inDeskAskBand(sideForBand, ask)
  );
  const askNa = mtfFlat || sideForBand == null;
  const askPass = askNa || askInBand;
  const askReason =
    askNa
      ? "N/A — no lean side (MTF flat / side lock)"
      : ask == null
        ? "ask missing"
        : inStillMidCoinFlip(ask)
          ? STILL_MID_UNCLEAR_SKIP
          : askInBand
            ? `${ask}¢ in ${sideForBand === "no" ? "NO" : "YES"} ${sideForBand === "no" ? DESK_NO_ASK_MIN : DESK_YES_ASK_MIN}–${sideForBand === "no" ? DESK_NO_ASK_MAX : DESK_YES_ASK_MAX}`
            : `ask_out_of_band (${ask}¢; YES ${DESK_YES_ASK_MIN}–${DESK_YES_ASK_MAX} / NO ${DESK_NO_ASK_MIN}–${DESK_NO_ASK_MAX})`;
  const stillMid = !askNa && ask != null && inStillMidCoinFlip(ask);
  const askCheck = chk(
    "ASK_BAND",
    `Ask YES ${DESK_YES_ASK_MIN}–${DESK_YES_ASK_MAX} / NO ${DESK_NO_ASK_MIN}–${DESK_NO_ASK_MAX}`,
    askPass,
    askNa
      ? `Ask door N/A until MTF leans (side lock). ${askReason}.`
      : stillMid
        ? `Still-mid ${48}–${52} — SIT STILL_MID (${askReason}).`
        : askInBand
          ? `Door OK · ${askReason} · still-mid 48–52 is SIT (separate).`
          : `Ask band fail (desk door). ${askReason}.`,
    askNa ? "N/A" : (ask == null ? "—" : `${ask}¢`),
  );

  // 4. EV ≥ 3¢ — unknown until aligned TAKE is N/A (pass), not a hard fail.
  // Painting EV fail while ASK_BAND / SIDE_LOCK already sat buries the real veto
  // (same honesty class as ASK_BAND N/A when MTF flat).
  const evKnown = typeof takeEv === "number" && Number.isFinite(takeEv);
  const evNa = !evKnown;
  const evOk = evNa || (takeEv as number) >= EV_FLOOR;
  const evCheck = chk(
    "EV",
    `EV ≥ ${EV_FLOOR}¢`,
    evOk,
    evNa
      ? "EV N/A until aligned TAKE (p=winRateAtPrice on side)."
      : `EV ${(takeEv as number).toFixed(1)}¢ vs floor ${EV_FLOOR}¢ (p=winRateAtPrice).`,
    evNa ? "N/A" : `${(takeEv as number).toFixed(1)}¢`,
  );

  // 5. W2 vetoes clear
  const w2Pass = w2?.kind === "PASS";
  const w2SkipReason = w2?.kind === "SKIP" ? w2.reason : null;
  const w2Check = chk(
    "W2",
    "W2 vetoes",
    w2Pass,
    w2Pass
      ? "W2 PASS — BRTI/analog/venue2/lag disagree clear."
      : w2SkipReason
        ? `W2 SKIP · ${w2SkipReason}`
        : aligned.kind === "SKIP"
          ? `W2 not run (aligned SKIP · ${aligned.reason}).`
          : "W2 pending / missing.",
    w2Pass ? "PASS" : (w2SkipReason ?? "—"),
  );

  // 6. lagProven — Clock B (series cold). Card surfaces LAG_COLD when lag cannot trade.
  const isLag = strategyId === "BASIS_LAG_EDGE";
  const isCc = strategyId === "CONFLUENCE_CASCADE";
  const lagGate = (isLag || isCc)
    ? assertLagAllowsMoneyMakerFill({
        strategyId: strategyId ?? "CONFLUENCE_CASCADE",
        lagProven,
        lagStale: input.lagStale,
        lagReason: input.lagReason,
        timeOfDayRegime: input.timeOfDayRegime,
      })
    : { ok: true as const };
  // LAG always needs lagProven on the money card; CC also fails when
  // assertLagAllowsMoneyMakerFill requires proven (Asia/stale/short_series).
  const lagOk = isLag ? (lagProven && lagGate.ok) : lagGate.ok;
  const lagCheck = chk(
    "LAG_PROVEN",
    "lagProven (CC|LAG gate)",
    lagOk,
    lagOk
      ? (isLag
        ? "LAG path — lagProven true (assertLagAllowsMoneyMakerFill / aligned TAKE)."
        : isCc
          ? "CC path — assertLagAllowsMoneyMakerFill ok (not Asia/stale/short_series, or proven)."
          : "Non-CC/LAG — lag gate n/a.")
      : isLag && !lagProven
        ? "LAG path — lagProven false (LAG_COLD)."
        : `CC|LAG blocked — ${"reason" in lagGate ? lagGate.reason : "lag_unproven"} (LAG_COLD).`,
    lagOk ? (lagProven ? "proven" : "ok") : "LAG_COLD",
  );

  // 6b. HARVEST + non-exempt CC → HARVEST_CC_BLOCK (never false TAKE while HARVEST).
  // Admission is always HUNT today; this stays honest if mode is injected HARVEST.
  // Paper≡live: no paper-only LAG exempt — family set via isHarvestSessionFamilyAllowed.
  const sessionFamilyBlock =
    input.sessionMode === "HARVEST"
    && !!strategyId
    && !isHarvestSessionFamilyAllowed(true, strategyId);
  const sessionCheck = chk(
    "SESSION_FAMILY",
    "Session family (HARVEST)",
    !sessionFamilyBlock,
    sessionFamilyBlock
      ? `HARVEST — ${strategyId} not harvest-exempt (HARVEST_CC_BLOCK); never TAKE.`
      : input.sessionMode === "HARVEST"
        ? `${strategyId ?? "—"} harvest-exempt or n/a.`
        : `sessionMode=${input.sessionMode ?? "HUNT"} — no HARVEST family suppress.`,
    sessionFamilyBlock ? "HARVEST_CC_BLOCK" : (input.sessionMode ?? "HUNT"),
  );

  // 7. Last-60s → no new take
  const last60 = inLast60sBrti(input.secsRemaining);
  const last60Check = chk(
    "LAST_60S",
    "Last-60s BRTI",
    !last60,
    last60
      ? `${LAST_60S_BRTI_AVG_SKIP} — no new take (LAST_60S).`
      : "Outside last-60s — new takes allowed.",
    last60 ? "LAST_60S" : "ok",
  );

  // 8. Not leftover HARD_NO_FILL
  const leftover = isLeftoverStrategyId(strategyId);
  const leftoverCheck = chk(
    "NOT_LEFTOVER",
    "Not leftover HARD_NO_FILL",
    !leftover,
    leftover
      ? `${strategyId} is leftover — cannot placeOrder.`
      : strategyId
        ? `${strategyId} is money-maker eligible.`
        : "No leftover id on path.",
    leftover ? "HARD_NO_FILL" : (strategyId ?? "—"),
  );

  // 9. CC velocity-against (#725) — NO vs +56$/min → SIT CC_VEL_AGAINST not TAKE
  const ccVelSide = sideForBand ?? takeSide;
  const ccVelGate = ccVelocityAgainstGate({
    strategyId,
    side: ccVelSide ?? "",
    velocityDolPerMin: input.velocityDolPerMin,
  });
  const ccVelOk = !ccVelGate.block;
  const ccVelReason = ccVelGate.block ? ccVelGate.reason : null;
  const ccVelCheck = chk(
    "CC_VEL",
    "CC velocity-against",
    ccVelOk,
    ccVelOk
      ? (strategyId === "CONFLUENCE_CASCADE"
        ? "CC vel clear (or velocity missing — no invent block)."
        : "Non-CC — vel gate n/a.")
      : `CC ${String(ccVelSide).toUpperCase()} vs 1m vel=${input.velocityDolPerMin} $/min — ${ccVelReason}.`,
    ccVelOk ? "ok" : (ccVelReason ?? "CC_VEL_AGAINST"),
  );

  // 10. NO_TAPE — Clock A: quote stale >3s
  const quoteAge = input.quoteAgeMs;
  const noTape =
    quoteAge != null
    && (!Number.isFinite(quoteAge) || quoteAge > MONEY_GATE_NO_TAPE_MS);
  const noTapeCheck = chk(
    "NO_TAPE",
    `Quote tape ≤${MONEY_GATE_NO_TAPE_MS / 1000}s`,
    !noTape,
    noTape
      ? `NO_TAPE — quote age ${quoteAge != null && Number.isFinite(quoteAge) ? `${(quoteAge / 1000).toFixed(1)}s` : "∞"} > ${MONEY_GATE_NO_TAPE_MS / 1000}s.`
      : quoteAge == null
        ? "quoteAgeMs omitted — tape check n/a."
        : `Quote age ${(quoteAge / 1000).toFixed(2)}s — tape fresh.`,
    noTape ? "NO_TAPE" : (quoteAge == null ? "n/a" : "ok"),
  );

  // 11. PIN hard skip (binary_pin). pin_reachable tag-only does not fail this.
  const pinHard = input.pinHard === true
    || (w2?.kind === "SKIP" && (w2.reason === "binary_pin" || w2.reason === "PIN"));
  const pinCheck = chk(
    "PIN",
    "Binary pin",
    !pinHard,
    pinHard
      ? "PIN — binary pin / still-mid magnet — SIT."
      : (w2?.log.pin_reachable
        ? "pin_reachable tag only — not a hard fill block."
        : "No hard PIN."),
    pinHard ? "PIN" : (w2?.log.pin_reachable ? "TAG" : "ok"),
  );

  // 12. PATH_GATE
  const pathBlocked = input.pathGateBlocked === true;
  const pathCheck = chk(
    "PATH_GATE",
    "PATH_GATE",
    !pathBlocked,
    pathBlocked
      ? `PATH_GATE — ${input.pathGateReason ?? "blocked"}.`
      : "PATH_GATE clear / not asserted.",
    pathBlocked ? "PATH_GATE" : "ok",
  );

  const checks = [
    noTapeCheck,
    pinCheck,
    ccVelCheck,
    pathCheck,
    sideCheck,
    haCheck,
    askCheck,
    evCheck,
    w2Check,
    lagCheck,
    sessionCheck,
    last60Check,
    leftoverCheck,
  ];

  const passedN = checks.filter(c => c.passed).length;
  const overallScore = Math.round((passedN / checks.length) * 100);
  const allPass = passedN === checks.length;

  // Headline/skipReason = first hard FAIL in checklist order.
  // Never keep a stale opposed_side when ASK_BAND (or another hard check) is the real veto.
  // HA is tag-only and always passed — excluded from hard-fail headline.
  const hardFailReason = firstHardMoneyFailReason(checks, {
    w2,
    ask,
    stillMid,
    ccVelReason,
  });

  let skipReason: string | null = null;
  if (sessionFamilyBlock) skipReason = "HARVEST_CC_BLOCK";
  else if (hardFailReason) skipReason = toMoneyGateSitReason(hardFailReason) ?? hardFailReason;
  else if (aligned.kind === "SKIP") {
    skipReason = toMoneyGateSitReason(aligned.reason) ?? aligned.reason;
  } else if (w2?.kind === "SKIP") {
    skipReason = toMoneyGateSitReason(w2.reason) ?? w2.reason;
  } else if (!allPass) {
    skipReason = "money_gate";
  }

  // Any hard check fail → never TAKE (named SIT).
  const kind: "TAKE" | "SKIP" =
    aligned.kind === "TAKE" && w2Pass && allPass ? "TAKE" : "SKIP";

  let headline: string;
  if (kind === "TAKE" && takeSide != null && ask != null) {
    const evPart = typeof takeEv === "number" ? ` EV ${Math.round(takeEv)}¢` : "";
    headline = `TAKE ${sideLabel(takeSide)} @${ask}¢${evPart} · W2 PASS`;
  } else {
    headline = `SKIP · ${skipReason ?? "money_gate"}`;
  }

  return {
    kind,
    headline,
    overallScore: kind === "TAKE" ? 100 : overallScore,
    scoreThreshold: MONEY_GATE_THRESHOLD,
    approved: kind === "TAKE",
    direction: directionFromSide(takeSide, mtfFlat),
    checks,
    side: takeSide,
    ask,
    ev: takeEv,
    p: takeP,
    pSource: "winRateAtPrice",
    confidence:
      typeof input.confidence === "number" && Number.isFinite(input.confidence)
        ? input.confidence
        : null,
    strategyId,
    skipReason,
    w2Result: w2 ? (w2.kind === "PASS" ? "PASS" : "SKIP") : null,
    lagProven,
    mtfScore: mtfNum,
    timestamp: input.nowMs ?? Date.now(),
    compositeIsFillGate: false,
    sessionLabel: input.sessionClockLabel,
  };
}


/**
 * Card honesty for operators: if fill path later refuses after a TAKE paint,
 * demote the card to named SIT so Trade/BOT never keeps a lying TAKE.
 * Marks the matching Phase-2 checklist row failed when id is known.
 * Token = winning gate (PATH_GATE, STILL_MID, SIZE_ZERO, …). Every placeOrder
 * refuse path must call this (or never paint TAKE until post-gate).
 */
export function demoteMoneyGateCardToSit(
  card: MoneyGateCard,
  rawReason: string,
  nowMs?: number,
): MoneyGateCard {
  const raw = String(rawReason ?? "").trim();
  const sit = (toMoneyGateSitReason(raw) ?? raw) || "money_gate";
  const checkId =
    sit === "NO_TAPE" ? "NO_TAPE"
    : sit === "PIN" ? "PIN"
    : sit.startsWith("CC_VEL") ? "CC_VEL"
    : sit === "PATH_GATE" ? "PATH_GATE"
    : sit === "STILL_MID" || sit === "ASK_OUT_OF_BAND" ? "ASK_BAND"
    : sit === "LAG_COLD" ? "LAG_PROVEN"
    : sit === "HARVEST_CC_BLOCK" ? "SESSION_FAMILY"
    : sit === "LAST_60S" ? "LAST_60S"
    : sit === "AND_SIT_HA_REGIME" ? "HA"
    : null;
  const checks = card.checks.map((c) => {
    if (!checkId || c.id !== checkId) return c;
    return {
      ...c,
      passed: false,
      score: 0,
      detail: `${sit} — fill path refused after card paint.`,
      value: sit,
    };
  });
  const passedN = checks.filter((c) => c.passed).length;
  const overallScore = checks.length
    ? Math.round((passedN / checks.length) * 100)
    : Math.min(card.overallScore, 99);
  return {
    ...card,
    kind: "SKIP",
    approved: false,
    headline: `SKIP · ${sit}`,
    skipReason: sit,
    checks,
    overallScore,
    timestamp: nowMs ?? Date.now(),
  };
}

/** Session clock label only — no regime adjectives (choppy/prime/fair). */
export function sessionClockLabel(utcHour: number): string {
  if (utcHour >= 13 && utcHour < 17) return "NY+London";
  if (utcHour >= 8 && utcHour < 13) return "London open";
  if (utcHour >= 17 && utcHour < 21) return "NY afternoon";
  if (utcHour >= 21 && utcHour < 24) return "Overnight";
  if (utcHour >= 0 && utcHour < 3) return "Asia open";
  return "Asia mid";
}

/** True when a string still has banned regime adjectives on the session label. */
export function sessionLabelHasRegimeAdjective(label: string): boolean {
  return /\b(choppy|prime|fair|good|low\s*liq)\b/i.test(label);
}
