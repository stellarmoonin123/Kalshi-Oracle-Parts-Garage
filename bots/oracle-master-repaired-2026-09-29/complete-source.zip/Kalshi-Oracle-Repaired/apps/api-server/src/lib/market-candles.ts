/**
 * market-candles.ts — shared real-OHLC fetcher (Binance → Coinbase fallback)
 *
 * Extracted from historical-backtester.ts so any backtest tool can source
 * genuine, non-interpolated intraday candles instead of building synthetic
 * sub-candles from Kalshi 15-minute settlements.
 *
 * Why this exists: `fetchKalshiCandles()` in kalshi-price.ts, when asked for
 * sub-15-minute granularity, LINEARLY INTERPOLATES between a period's open
 * price and the *next* settlement's floor strike across the whole 15-minute
 * window. That means every "5-minute candle" inside a period already reflects
 * where price ends up at settlement — a lookahead-bias bug: a strategy
 * evaluated on minute-5 or minute-10 data is secretly seeing the future
 * minute-15 outcome baked into the interpolation. This is almost certainly
 * why the backtest-engine.ts grid search reported unrealistically high
 * (~100%) out-of-sample win rates.
 *
 * Binance is geo-blocked (HTTP 451) from Replit-hosted servers, so Coinbase's
 * public Exchange API is the practical primary source here; both return real
 * intra-candle price action with no knowledge of future settlements.
 */

export interface RealCandle {
  time:   number;  // unix seconds
  open:   number;
  high:   number;
  low:    number;
  close:  number;
  volume: number;
}

export type CandleSource = 'binance' | 'coinbase' | 'coingecko' | 'bitstamp';

const FETCH_DELAY_MS = 110; // polite rate-limit gap between paginated requests

function binanceInterval(intervalMins: number): string {
  if (intervalMins % 60 === 0 && intervalMins < 1440) return `${intervalMins / 60}h`;
  if (intervalMins >= 1440) return `${intervalMins / 1440}d`;
  return `${intervalMins}m`;
}

async function fetchBinanceCandles(
  startMs:      number,
  count:        number,
  intervalMins: number,
): Promise<RealCandle[]> {
  const results: RealCandle[] = [];
  let currentStart = startMs;
  const batchSize   = 1000;
  const batches     = Math.ceil(count / batchSize);
  const interval    = binanceInterval(intervalMins);

  for (let b = 0; b < batches; b++) {
    const limit = Math.min(batchSize, count - results.length);
    const url   = `https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=${interval}&startTime=${currentStart}&limit=${limit}`;

    try {
      const resp = await fetch(url);
      if (!resp.ok) throw new Error(`Binance HTTP ${resp.status}`);
      const raw = await resp.json() as Array<[number, string, string, string, string, string]>;
      if (!raw.length) break;

      for (const c of raw) {
        results.push({
          time:   Math.floor(c[0] / 1000),
          open:   parseFloat(c[1]),
          high:   parseFloat(c[2]),
          low:    parseFloat(c[3]),
          close:  parseFloat(c[4]),
          volume: parseFloat(c[5]),
        });
      }
      currentStart = raw[raw.length - 1][0] + 1;
    } catch (err) {
      console.warn(`[market-candles] Binance fetch error (batch ${b}): ${(err as Error).message}`);
      break;
    }

    if (b < batches - 1) await new Promise(r => setTimeout(r, FETCH_DELAY_MS));
  }
  return results;
}

async function fetchCoinbaseCandles(
  startMs:      number,
  count:        number,
  intervalMins: number,
): Promise<RealCandle[]> {
  const granularitySec = intervalMins * 60;
  const results: RealCandle[] = [];
  let cursorSec    = Math.floor(startMs / 1000);
  const maxPerReq  = 300; // Coinbase Exchange API hard cap per request
  const batches    = Math.ceil(count / maxPerReq);

  for (let b = 0; b < batches; b++) {
    const remaining = count - results.length;
    const thisBatch = Math.min(maxPerReq, remaining);
    if (thisBatch <= 0) break;
    const endSec   = cursorSec + thisBatch * granularitySec;
    const startIso = new Date(cursorSec * 1000).toISOString();
    const endIso   = new Date(endSec * 1000).toISOString();
    const url = `https://api.exchange.coinbase.com/products/BTC-USD/candles?granularity=${granularitySec}&start=${startIso}&end=${endIso}`;

    try {
      const resp = await fetch(url, { headers: { 'User-Agent': 'kalshi-bot-backtester/1.0' } });
      if (!resp.ok) throw new Error(`Coinbase HTTP ${resp.status}`);
      const raw = await resp.json() as Array<[number, number, number, number, number, number]>;
      if (!raw.length) { cursorSec = endSec; continue; }

      // Coinbase returns [time, low, high, open, close, volume], newest-first.
      const sorted = [...raw].sort((a, b) => a[0] - b[0]);
      for (const c of sorted) {
        results.push({ time: c[0], low: c[1], high: c[2], open: c[3], close: c[4], volume: c[5] });
      }
      cursorSec = endSec;
    } catch (err) {
      console.warn(`[market-candles] Coinbase fetch error (batch ${b}): ${(err as Error).message}`);
      break;
    }

    if (b < batches - 1) await new Promise(r => setTimeout(r, FETCH_DELAY_MS));
  }
  return results;
}

/**
 * Bitstamp public OHLC — deepest free USD daily series we can reach from this
 * box (continuous from 2011-08-18). Coinbase Exchange starts ~2015-07-20;
 * Binance is geo-blocked (451) here. Use for long-TF Charts (All / multi-year).
 * step must be a supported Bitstamp grain (60…86400). Max 1000 bars / request.
 */
function bitstampStepSec(intervalMins: number): number | null {
  const sec = intervalMins * 60;
  const allowed = [60, 180, 300, 900, 1800, 3600, 7200, 14400, 21600, 43200, 86400];
  return allowed.includes(sec) ? sec : null;
}

async function fetchBitstampCandles(
  startMs:      number,
  count:        number,
  intervalMins: number,
): Promise<RealCandle[]> {
  const step = bitstampStepSec(intervalMins);
  if (!step) return [];
  const results: RealCandle[] = [];
  let cursorSec = Math.floor(startMs / 1000);
  const endTarget = cursorSec + count * step;
  const maxPerReq = 1000;
  // Cap pages so a runaway loop cannot hang Charts forever.
  const maxPages = Math.min(Math.ceil(count / maxPerReq) + 2, 20);

  for (let page = 0; page < maxPages && results.length < count; page++) {
    const remaining = count - results.length;
    const limit = Math.min(maxPerReq, remaining);
    const url =
      `https://www.bitstamp.net/api/v2/ohlc/btcusd/?step=${step}&limit=${limit}&start=${cursorSec}`;
    try {
      const resp = await fetch(url, { headers: { 'User-Agent': 'kalshi-bot-backtester/1.0' } });
      if (!resp.ok) throw new Error(`Bitstamp HTTP ${resp.status}`);
      const data = await resp.json() as {
        data?: { ohlc?: Array<{ timestamp: string; open: string; high: string; low: string; close: string; volume: string }> };
      };
      const raw = data.data?.ohlc ?? [];
      if (!raw.length) break;

      let added = 0;
      for (const c of raw) {
        const t = parseInt(c.timestamp, 10);
        if (!Number.isFinite(t)) continue;
        if (results.length && t <= results[results.length - 1]!.time) continue;
        results.push({
          time: t,
          open: parseFloat(c.open),
          high: parseFloat(c.high),
          low: parseFloat(c.low),
          close: parseFloat(c.close),
          volume: parseFloat(c.volume),
        });
        added++;
      }
      if (!added) break;
      const last = results[results.length - 1]!.time;
      const next = last + step;
      if (next <= cursorSec) break;
      cursorSec = next;
      if (last >= endTarget - step) break;
    } catch (err) {
      console.warn(`[market-candles] Bitstamp fetch error (page ${page}): ${(err as Error).message}`);
      break;
    }
    if (page < maxPages - 1 && results.length < count) {
      await new Promise(r => setTimeout(r, FETCH_DELAY_MS));
    }
  }
  return results.slice(0, count);
}

/**
 * Third-tier fallback — CoinGecko's free `market_chart/range` endpoint.
 * Only reached when BOTH Coinbase and Binance are unreachable (a genuine
 * dual-exchange outage, or both geo-blocked/rate-limited at once).
 *
 * CoinGecko returns raw (timestamp, price) points, not real OHLC candles —
 * granularity is auto-selected by range (~5min for <=1 day, hourly for
 * <=90 days, daily beyond that) and isn't guaranteed to match `intervalMins`.
 * We bucket whatever points come back into `intervalMins`-wide windows
 * (open=first, close=last, high=max, low=min in each bucket) so callers get
 * a real-data candle shape even if intra-bucket resolution is coarser than
 * requested. This is a last-resort source for continuity, not a precision
 * replacement for Coinbase/Binance.
 */
async function fetchCoinGeckoCandles(
  startMs:      number,
  count:        number,
  intervalMins: number,
): Promise<RealCandle[]> {
  const fromSec = Math.floor(startMs / 1000);
  const toSec   = fromSec + count * intervalMins * 60;

  try {
    const url = `https://api.coingecko.com/api/v3/coins/bitcoin/market_chart/range?vs_currency=usd&from=${fromSec}&to=${toSec}`;
    const resp = await fetch(url, { headers: { 'User-Agent': 'kalshi-bot-backtester/1.0' } });
    if (!resp.ok) throw new Error(`CoinGecko HTTP ${resp.status}`);
    const data = await resp.json() as { prices?: [number, number][]; total_volumes?: [number, number][] };
    const prices = data.prices ?? [];
    if (!prices.length) return [];

    const volByTs = new Map<number, number>();
    for (const [ts, vol] of data.total_volumes ?? []) volByTs.set(ts, vol);

    const bucketMs = intervalMins * 60_000;
    const buckets = new Map<number, { open: number; high: number; low: number; close: number; volume: number }>();

    for (const [tsMs, price] of prices) {
      const bucketStart = Math.floor(tsMs / bucketMs) * bucketMs;
      const existing = buckets.get(bucketStart);
      if (!existing) {
        buckets.set(bucketStart, { open: price, high: price, low: price, close: price, volume: volByTs.get(tsMs) ?? 0 });
      } else {
        existing.high  = Math.max(existing.high, price);
        existing.low   = Math.min(existing.low, price);
        existing.close = price; // points arrive in chronological order
        existing.volume += volByTs.get(tsMs) ?? 0;
      }
    }

    return [...buckets.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([bucketStart, c]) => ({ time: Math.floor(bucketStart / 1000), ...c }));
  } catch (err) {
    console.warn(`[market-candles] CoinGecko fetch error: ${(err as Error).message}`);
    return [];
  }
}

/**
 * Fetch `count` real candles at `intervalMins` granularity starting at
 * `startMs`, trying Bitstamp first for deep daily (2011+), else Coinbase, then
 * Binance, and finally CoinGecko. Returns whichever source produces at
 * least `minAcceptable` candles (default: 80% of requested). Throws if no
 * source returns usable data — callers must not silently fall back to
 * synthetic/interpolated candles, which reintroduces the lookahead-bias bug
 * this module exists to avoid.
 *
 * Coinbase is tried first: Binance is unconditionally geo-blocked (HTTP 451)
 * from Replit-hosted servers, so putting it first meant every single call —
 * including on the live tick path (settlement-predictor, candle-patterns),
 * not just backtests — paid for a guaranteed-failing network round trip
 * (plus inter-batch delays) before ever reaching the source that actually
 * works. Binance is kept as a fallback in case Coinbase ever has an outage
 * or this code runs somewhere Binance isn't blocked. CoinGecko is a third,
 * fully independent source (different infra, no shared outage surface with
 * either exchange) used only if both of the above fail.
 */
export async function fetchRealCandles(
  startMs:      number,
  count:        number,
  intervalMins: number,
): Promise<{ candles: RealCandle[]; source: CandleSource }> {
  const minAcceptable = Math.floor(count * 0.8);
  // Coinbase BTC-USD daily starts ~2015-07-20; Bitstamp USD daily ~2011-08-18.
  const wantDeepDaily =
    intervalMins >= 1440 &&
    (count > 400 || startMs < Date.UTC(2015, 6, 1));

  let bitstamp: RealCandle[] = [];
  if (wantDeepDaily) {
    bitstamp = await fetchBitstampCandles(startMs, count, intervalMins);
    if (bitstamp.length >= minAcceptable) return { candles: bitstamp, source: 'bitstamp' };
  }

  const coinbase = await fetchCoinbaseCandles(startMs, count, intervalMins);
  if (coinbase.length >= minAcceptable) return { candles: coinbase, source: 'coinbase' };

  // Bitstamp for shorter daily / other grains if Coinbase thin.
  if (!bitstamp.length) {
    bitstamp = await fetchBitstampCandles(startMs, count, intervalMins);
  }
  if (bitstamp.length >= minAcceptable) return { candles: bitstamp, source: 'bitstamp' };

  const binance = await fetchBinanceCandles(startMs, count, intervalMins);
  if (binance.length >= minAcceptable) return { candles: binance, source: 'binance' };

  const coingecko = await fetchCoinGeckoCandles(startMs, count, intervalMins);
  if (coingecko.length >= minAcceptable) return { candles: coingecko, source: 'coingecko' };

  // No source produced enough real data. Prefer whichever got furthest, but
  // if all are too thin to be meaningful, fail loudly instead of
  // falling back to interpolated candles.
  const candidates: [RealCandle[], CandleSource][] = [
    [bitstamp, 'bitstamp'], [coinbase, 'coinbase'], [binance, 'binance'], [coingecko, 'coingecko'],
  ];
  candidates.sort((a, b) => b[0].length - a[0].length);
  const [best, bestSource] = candidates[0]!;

  if (best.length >= Math.max(60, count * 0.3)) {
    console.warn(`[market-candles] Only ${best.length}/${count} real candles fetched at ${intervalMins}m (source: ${bestSource}) — proceeding with reduced sample`);
    return { candles: best, source: bestSource };
  }

  throw new Error(
    `Could not fetch real ${intervalMins}m BTC candles from Bitstamp, Coinbase, Binance, or CoinGecko ` +
    `(got ${bitstamp.length} / ${coinbase.length} / ${binance.length} / ${coingecko.length} of ${count} requested). ` +
    `Sources appear unreachable — refusing to fall back to interpolated Kalshi settlement data, ` +
    `which would silently reintroduce lookahead bias.`
  );
}
