/**
 * backtest-engine.ts  (v4 — walk-forward + Monte Carlo + dynamic stops)
 *
 * Core simulation model: 5-min candles, grouped into 15-min periods.
 * Observation points:
 *   minute-5  (c0 elapsed / c1.open): first look — 5 min of price action, no c1.close
 *   minute-10 (c1 close): second look — more data, higher certainty, less time
 * Vol (#346): last 40 FIVE-MIN closes available at the decision, never c2 settlement.
 * Accel (#347): minute-5 compares vs previous period's last 5m bar, not priorVelocity=0.
 * Lookahead (#354): stalling at minute-5 uses c0 only; accel is false without a prior bar.
 *
 * v4 improvements over v3:
 *  - 3-fold time-series walk-forward cross-validation (no leakage)
 *  - Monte Carlo bootstrap (1,000×) on OOS fold for confidence intervals
 *  - Stop-loss simulation: if c2 opens against us past stop threshold, exit early
 *  - Profit-take simulation: if c2 moves favorably past target, lock in gain
 *  - Kelly-sized contracts in simulation (half-Kelly)
 *  - Capital preservation search: drawdownGuardPct grid
 *  - Composite score: 0.4×Sharpe + 0.3×ProfitFactor + 0.3×Calmar
 *  - Grid search on 8 parameters (~2,880 combos) — top-10 by composite score
 *  - OOS win rate 90% CI via bootstrap
 *
 * Data source: real BTC candles via market-candles.ts (Binance, falling back to
 * Coinbase's Exchange API since Binance is geo-blocked on Replit servers).
 *
 * 2026-08-02 fix: this previously sourced sub-15-minute candles from
 * fetchKalshiCandles(), which LINEARLY INTERPOLATES between a period's open
 * price and the floor strike of the *next* settlement across the whole
 * 15-minute window. That means every intra-period candle already reflected
 * where price would end up at settlement — a lookahead-bias bug that
 * explained this tool's implausibly high (~100%) out-of-sample win rates.
 * Switched to real, non-interpolated candles so a signal evaluated at
 * minute-5 or minute-10 can no longer "see" the minute-15 outcome.
 */

// ── Types ─────────────────────────────────────────────────────────────────────

export interface OHLCCandle {
  time:   number;  // unix seconds
  open:   number;
  high:   number;
  low:    number;
  close:  number;
  volume: number;
}

export interface StrategyDef {
  name:                string;
  minVelocity:         number;    // $/min over 5-min observation window
  useEdge:             boolean;
  minEdge:             number;    // probability edge % (e.g. 5 = 5%)
  useAcceleration:     boolean;
  useStallFilter:      boolean;
  useLossCooldown:     boolean;
  cooldownMultiplier:  number;
  useStopLoss:         boolean;
  stopLossCents:       number;    // ¢ per contract to cut loss (sim: map to price move)
  useProfitTake:       boolean;
  profitTakeCents:     number;    // ¢ per contract to lock profit
  drawdownGuardPct:    number;    // scale down when drawdown exceeds this %
  observationMinute:   5 | 10;   // which observation point to evaluate at
}

export interface TradeRecord {
  periodIdx:       number;
  foldIdx:         number;   // 0=train, 1..k=oos fold
  signal:          'LONG' | 'SHORT' | 'STAY_OUT';
  velocity5:       number;
  velocity10:      number;
  modelProb:       number;
  edge:            number;
  stalling:        boolean;
  accelerating:    boolean;
  confidence:      number;
  entryPriceCents: number;
  exitPriceCents:  number | null;  // early exit price if stop/profit fired
  outcome:         'win' | 'loss' | 'no_trade' | 'early_win' | 'early_loss';
  pnlCents:        number;      // GROSS — frictionless, no fee, no EV-floor gate (research baseline)
  contracts:       number;
  settledAbove:    boolean;
  exitReason:      'settlement' | 'stop_loss' | 'profit_take' | 'no_trade';
  feeCentsPaid:    number;      // real Kalshi taker fee this trade would pay live (0 for no_trade)
  evPasses:        boolean;     // would this entry have passed the live EV-floor/PATH_GATE at entry time?
  netPnlCents:     number;      // live-proxy P&L: 0 if !evPasses (would not have traded live), else pnlCents - feeCentsPaid
}

export interface RegimeStat {
  regime: string; trades: number; wins: number; winRate: number;
}

export interface BootstrapCI {
  p5:    number;   // 5th percentile win rate
  p50:   number;   // median
  p95:   number;   // 95th percentile
  mean:  number;
}

/**
 * Live-proxy ("net") aggregate, computed from the same trades[] as the
 * enclosing GROSS BacktestResult by filtering to `evPasses` trades and using
 * `netPnlCents` (fee-adjusted) instead of `pnlCents` (frictionless). This is
 * what the live/paper bot would actually have realized: trades that would
 * have failed the live EV floor never happened, and every trade that did pays
 * a real Kalshi taker fee. Shares the same field shape as BacktestResult's
 * top-level numbers so UI/API consumers can render them side by side.
 */
export interface NetMetrics {
  tradesEntered:    number;   // subset of gross tradesEntered that also passed evPasses
  excludedForEv:    number;   // gross-entered trades that would NOT have passed the live EV floor
  wins:             number;
  losses:           number;
  winRate:          number;
  pnlCents:         number;
  pnlDollars:       number;
  roi:              number;
  sharpe:           number;
  profitFactor:     number;
  maxDrawdown:      number;
  calmar:           number;
  compositeScore:   number;
  avgWinCents:      number;
  avgLossCents:     number;
  expectancyCents:  number;
}

export interface BacktestResult {
  strategy:        StrategyDef;
  phase:           'train' | 'oos';
  totalPeriods:    number;
  tradesEntered:   number;
  wins:            number;
  losses:          number;
  winRate:         number;
  pnlCents:        number;
  pnlDollars:      number;
  roi:             number;
  sharpe:          number;
  profitFactor:    number;
  maxDrawdown:     number;      // peak-to-trough as fraction (e.g. 0.20 = 20%)
  calmar:          number;      // annualised return / max drawdown
  compositeScore:  number;      // 0.4×Sharpe + 0.3×PF + 0.3×Calmar
  avgWinCents:     number;
  avgLossCents:    number;
  expectancyCents: number;
  trades:          TradeRecord[];
  regimeStats:     RegimeStat[];
  earlyExits:      number;      // count of stop-loss + profit-take exits
  /**
   * `true` when every top-level number above (winRate, pnlCents, sharpe, …)
   * is the GROSS/RESEARCH baseline: frictionless fills, no live EV-floor
   * gate — raw signal quality, not what the live/paper bot would actually
   * do. `false` when the engine already applies fee + EV-floor economics to
   * its top-level numbers (in which case `netMetrics` mirrors them). Always
   * check this flag before treating a bare WR/PnL number as live-tradable.
   */
  researchOnly:    boolean;
  netMetrics:      NetMetrics;
}

/**
 * Recompute win/loss/pnl/risk metrics for the LIVE-PROXY ("net") view: only
 * trades that passed the live EV floor (`evPasses`), using fee-adjusted
 * `netPnlCents`. Mirrors the gross aggregation math in runBacktest/
 * poolBacktestResults exactly, just filtered + re-keyed to the net fields.
 */
export function summarizeNet(trades: TradeRecord[], _totalPeriods: number): NetMetrics {
  const grossEntered   = trades.filter(t => t.outcome !== 'no_trade');
  const netEntered     = grossEntered.filter(t => t.evPasses);
  const wins           = netEntered.filter(t => t.outcome === 'win' || t.outcome === 'early_win');
  const losses         = netEntered.filter(t => t.outcome === 'loss' || t.outcome === 'early_loss');
  const totalPnl       = netEntered.reduce((s, t) => s + t.netPnlCents, 0);
  const winPnls        = wins.map(t => t.netPnlCents);
  const lossPnls       = losses.map(t => Math.abs(t.netPnlCents));
  const pnlSeries      = netEntered.map(t => t.netPnlCents);
  let equity = 10_000;
  const equityCurve    = [equity];
  for (const pnl of pnlSeries) { equity += pnl; equityCurve.push(equity); }
  const maxDD    = computeMaxDrawdown(equityCurve);
  const sharpe   = computeSharpe(pnlSeries);
  const pf       = computeProfitFactor(winPnls, lossPnls);
  const annRet   = pnlSeries.length > 0
    ? (pnlSeries.reduce((a, b) => a + b, 0) / pnlSeries.length) * CANDLES_PER_YEAR / 100
    : 0;
  const calmar    = maxDD > 0 ? annRet / maxDD : annRet > 0 ? 10 : 0;
  const composite = 0.4 * Math.min(sharpe, 5) / 5 + 0.3 * Math.min(pf, 5) / 5 + 0.3 * Math.min(Math.max(calmar, 0), 5) / 5;

  return {
    tradesEntered:   netEntered.length,
    excludedForEv:   grossEntered.length - netEntered.length,
    wins:            wins.length,
    losses:          losses.length,
    winRate:         netEntered.length > 0 ? wins.length / netEntered.length : 0,
    pnlCents:        totalPnl,
    pnlDollars:      totalPnl / 100,
    roi:             totalPnl / 10_000,
    sharpe,
    profitFactor:    pf,
    maxDrawdown:     maxDD,
    calmar,
    compositeScore:  composite,
    avgWinCents:     wins.length > 0 ? winPnls.reduce((a, b) => a + b, 0) / wins.length : 0,
    avgLossCents:    losses.length > 0 ? lossPnls.reduce((a, b) => a + b, 0) / losses.length : 0,
    expectancyCents: netEntered.length > 0 ? totalPnl / netEntered.length : 0,
  };
}

export interface GridResult {
  oos:             BacktestResult;
  train:           BacktestResult;
  composite:       number;
  /**
   * Task #400: sample-size-adjusted ranking score.
   *
   * Raw composite can be arbitrarily high on thin-sample combos that got
   * lucky across the 3 OOS folds — e.g. 78 trades / 97% WR still ranks above
   * well-evidenced combos when composite is used directly. wilsonRankScore
   * replaces composite as the sort key by blending:
   *   - Wilson 95% lower-bound win rate (shrinks toward 50% as n falls)
   *   - the raw composite score (Sharpe + PF + Calmar quality)
   * via a geometric mean, so a combo must have BOTH a good result AND enough
   * evidence to rank highly. Follows the same Wilson LB approach used in
   * strategy-learner.ts / strategy-performance.ts quarantine logic.
   */
  wilsonRankScore: number;
  /**
   * Live-proxy counterpart of wilsonRankScore, computed from oos.netMetrics
   * (fee-adjusted P&L, EV-floor-passing trades only) instead of the gross
   * oos numbers. This — not wilsonRankScore — is the default sort/rank key
   * for any "best strategies" leaderboard, since it reflects what the
   * live/paper bot would actually have realized. 0 when oos.netMetrics has
   * too few trades to be meaningful (mirrors the gross eligibility filter).
   */
  netWilsonRankScore: number;
  ci:              BootstrapCI;   // OOS win rate 90% CI from Monte Carlo
}

// ── Data fetch ────────────────────────────────────────────────────────────────
// Re-exported so backtest-scenarios.ts / routes/backtest.ts can keep importing
// fetchKrakenCandles by the same name for their own (live-accuracy / snapshot)
// uses, which are out of scope for this fix and intentionally untouched.
export { fetchKalshiCandles as fetchKrakenCandles } from "./kalshi-price.js";

// Real, non-interpolated candle source for the grid-search backtest itself.
import { fetchRealCandles } from "./market-candles.js";

// 2026-08-25 fix: grid-search previously simulated frictionless fills (no
// Kalshi taker fee) and had no EV-floor entry gate at all, unlike every live
// order path (trading-bot.ts's estimateTradeEV / trade-path.ts's PATH_GATE).
// That let the grid search rank parameter combos on P&L that real live/paper
// orders could never actually realize — a combo could look profitable here
// purely because ~2-7¢/contract of real fee was never charged, and because
// trades the live bot would reject on EV grounds were still counted here.
// Reusing the same fee formula + PATH_GATE floors keeps this backtest's
// numbers comparable to what the bot would actually do with the same signal.
import { kalshiFeeCents, kalshiTakerFeeCents } from "./constants.js";
import { computeTradeEV, getPathConfig } from "./trade-path.js";

// ── Math helpers ──────────────────────────────────────────────────────────────

const CANDLES_PER_YEAR = (365 * 24 * 60) / 15;

function normCDF(z: number): number {
  const sign = z >= 0 ? 1 : -1;
  const za   = Math.abs(z);
  const t    = 1 / (1 + 0.2316419 * za);
  const poly = t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
  const pdf  = Math.exp(-za * za / 2) / Math.sqrt(2 * Math.PI);
  const p    = 1 - pdf * poly;
  return sign === 1 ? p : 1 - p;
}

function realizedVol(prices: number[]): number {
  if (prices.length < 3) return 0.007;
  const rets: number[] = [];
  for (let i = 1; i < prices.length; i++) rets.push(Math.log(prices[i] / prices[i - 1]));
  const mean = rets.reduce((a, b) => a + b, 0) / rets.length;
  const v    = rets.map(r => (r - mean) ** 2).reduce((a, b) => a + b, 0) / (rets.length - 1);
  return Math.sqrt(v) * Math.sqrt(CANDLES_PER_YEAR);
}

/**
 * Proper binary option pricing: P(BTC > K at expiry) = N(d₁)
 * where d₁ = (ln(S/K) + 0.5σ²T) / (σ√T)
 * S = current BTC price, K = floor strike, σ = annualised vol, T = time in years.
 * Replaces the old linear `(S-K)/(K·σ·√T)` approximation that missed the drift term
 * and used K instead of S as the vol scalar.
 */
function probEdge(currentPrice: number, strike: number, vol: number, minutesLeft: number) {
  if (vol <= 0 || minutesLeft <= 0 || strike <= 0 || currentPrice <= 0) return { prob: 0.5, edge: 0 };
  const T   = minutesLeft / (365 * 24 * 60);
  const d1  = (Math.log(currentPrice / strike) + 0.5 * vol * vol * T) / (vol * Math.sqrt(T));
  const prob = normCDF(d1);
  return { prob, edge: Math.abs(prob - 0.5) * 100 };
}

/**
 * Binary option (digital call) price in cents: P(BTC closes above K at T) × 100¢.
 * Used in simulateTrade to value the contract at mid-period without the linear approximation.
 */
export function binaryCallPrice(S: number, K: number, vol: number, minutesLeft: number): number {
  if (minutesLeft <= 0) return S > K ? 100 : 0;
  if (S <= 0 || K <= 0 || vol <= 0) return S > K ? 75 : 25;
  const T  = minutesLeft / (365 * 24 * 60);
  const d1 = (Math.log(S / K) + 0.5 * vol * vol * T) / (vol * Math.sqrt(T));
  // Honest digital: no invent 1¢/99¢ floors. FILL/CLOSE/shadow persist via sanitizeTheoCents [10,90].
  return normCDF(d1) * 100;
}

/**
 * Wilson score interval lower bound (z = 1.96, 95% CI).
 * Mirrors strategy-learner.ts / strategy-performance.ts — same formula,
 * kept local to avoid a circular import with those modules.
 * Returns 0 when n ≤ 0.
 */
function wilsonLowerBound(wins: number, n: number): number {
  if (n <= 0) return 0;
  const z      = 1.96;
  const p      = wins / n;
  const denom  = 1 + (z * z) / n;
  const center = p + (z * z) / (2 * n);
  const margin = z * Math.sqrt((p * (1 - p) + (z * z) / (4 * n)) / n);
  return (center - margin) / denom;
}

/**
 * Task #400: sample-size-adjusted ranking score for grid-search results.
 *
 * Thin-sample combos (e.g. 78 trades, 97% WR) can top the ranking on raw
 * composite purely due to multiple-comparisons luck — the composite's
 * Sharpe/PF/Calmar are all inflated by a handful of lucky OOS periods.
 *
 * Fix: rank by a geometric blend of:
 *   A) Wilson 95% LB win rate, mapped to [0,1] relative to break-even (0.50).
 *      This shrinks toward 0 as n falls, exactly penalising thin samples.
 *   B) Normalised composite score (already in [0,1]).
 *
 * A and B get equal weight in the geometric mean so neither alone can drive
 * the ranking. A combo with n=78 / WR=97% gets a Wilson LB of ~91% (large
 * penalty absorbed), while n=500 / WR=70% gets a Wilson LB of ~66% (smaller
 * penalty) — the evidenced combo out-ranks the lucky thin one.
 *
 * Thin-sample combos remain in the results list (not filtered), they just
 * can't out-rank well-evidenced ones purely on luck.
 *
 * Exported for unit tests.
 */
export function computeWilsonRankScore(tradesEntered: number, wins: number, composite: number): number {
  if (tradesEntered <= 0 || wins <= 0) return 0;

  // A: Wilson LB shrinkage factor = wilsonLB / rawWinRate.
  //    Interpretation: "what fraction of the stated win rate is statistically
  //    confirmed at 95% confidence". Near 1.0 for large n (LB ≈ rawWR), shrinks
  //    toward 0 for very thin n or extreme win rates where the CI is wide.
  //    A combo claiming 97.4% WR on 78 trades gets LB ≈ 91.1%, so shrinkage ≈ 0.936.
  //    A combo with 70% WR on 500 trades gets LB ≈ 65.8%, so shrinkage ≈ 0.941 —
  //    the well-evidenced combo's shrinkage matches or exceeds the thin one, even
  //    though the raw win rates differ by 27 percentage points.
  const rawWR    = wins / tradesEntered;
  const wlb      = wilsonLowerBound(wins, tradesEntered);
  const shrinkage = rawWR > 0 ? wlb / rawWR : 0;  // 0 ≤ shrinkage ≤ ~1

  // B: composite is already in [0,1] (0.4×Sharpe/5 + 0.3×PF/5 + 0.3×Calmar/5)
  const compNorm = Math.max(0, Math.min(1, composite));

  // Geometric mean — both components must be positive to score well.
  return Math.sqrt(Math.max(0, shrinkage) * compNorm);
}

// Half-Kelly formula: f* = p - (1-p)/b,  use f*/2
function kellyContracts(winRate: number, entryPrice: number, maxContracts: number): number {
  const p = winRate;
  const q = 1 - p;
  const b = entryPrice > 0 ? (100 - entryPrice) / entryPrice : 1;
  const k = p - q / b;
  if (k <= 0) return 1;
  return Math.max(1, Math.min(maxContracts, Math.floor(k / 2 * maxContracts)));
}

function computeSharpe(pnlSeries: number[]): number {
  if (pnlSeries.length < 2) return 0;
  const mean = pnlSeries.reduce((a, b) => a + b, 0) / pnlSeries.length;
  const std  = Math.sqrt(pnlSeries.map(x => (x - mean) ** 2).reduce((a, b) => a + b, 0) / (pnlSeries.length - 1));
  if (std === 0) return mean > 0 ? 3 : 0;
  return (mean / std) * Math.sqrt(CANDLES_PER_YEAR / pnlSeries.length);
}

// BACKTEST LAB v5 (2026-08-22): computeMaxDrawdown/computeProfitFactor/
// bootstrapCI below are exported (were module-private) — pure statistics on
// an already-computed P&L/equity series, no admit/EV logic — so the causal
// LEAN-vs-LEGACY simulator (backtest-lab-v5/validation.ts) reuses this
// already-tested math instead of a third copy of it. Purely additive.
export function computeMaxDrawdown(equity: number[]): number {
  let peak = equity[0] ?? 0;
  let maxDD = 0;
  for (const e of equity) {
    if (e > peak) peak = e;
    const dd = peak > 0 ? (peak - e) / peak : 0;
    if (dd > maxDD) maxDD = dd;
  }
  return maxDD;
}

export function computeProfitFactor(wins: number[], losses: number[]): number {
  const gw = wins.reduce((a, b)  => a + b, 0);
  const gl = losses.reduce((a, b) => a + b, 0);
  return gl > 0 ? gw / gl : gw > 0 ? 10 : 0;
}

// ── Monte Carlo bootstrap ─────────────────────────────────────────────────────

export function bootstrapCI(oosWins: number[], oosLosses: number[], iterations = 1_000): BootstrapCI {
  const trades = [...oosWins.map(() => 1), ...oosLosses.map(() => 0)];
  if (trades.length < 5) return { p5: 0, p50: 0, p95: 0, mean: 0 };
  const samples: number[] = [];
  for (let i = 0; i < iterations; i++) {
    let wins = 0;
    const n  = trades.length;
    for (let j = 0; j < n; j++) wins += trades[Math.floor(Math.random() * n)];
    samples.push(wins / n);
  }
  samples.sort((a, b) => a - b);
  const p5   = samples[Math.floor(samples.length * 0.05)];
  const p50  = samples[Math.floor(samples.length * 0.50)];
  const p95  = samples[Math.floor(samples.length * 0.95)];
  const mean = samples.reduce((a, b) => a + b, 0) / samples.length;
  return { p5, p50, p95, mean };
}

// ── Period grouping ───────────────────────────────────────────────────────────

export interface Period15m {
  periodOpen:  number;     // price at c0.open (= the "floor strike")
  c0:          OHLCCandle; // minutes 0-5
  c1:          OHLCCandle; // minutes 5-10
  c1b?:        OHLCCandle; // minutes 10-15 (last 5-min candle) — hidden at eval
  c2:          OHLCCandle; // minutes 0-15  (full 15-min candle — settlement)
  settledAbove: boolean;   // close > open (YES wins)
}

function groupPeriods(c5m: OHLCCandle[], c15m: OHLCCandle[]): Period15m[] {
  const periods: Period15m[] = [];

  // De-dup and sort 5-min candles
  const sorted5m = [...new Map(c5m.map(c => [c.time, c])).values()]
    .sort((a, b) => a.time - b.time);

  // Fast map lookup for 15-min candles by their start time
  const c15mMap = new Map(c15m.map(c => [c.time, c]));

  // Critical fix: skip leading candles until we land on a 15-min UTC boundary
  // (Kraken returns candles starting at whatever the last N were; the array may
  //  start at :05 or :10 which would misalign every group of 3.)
  let startIdx = 0;
  while (startIdx < sorted5m.length && sorted5m[startIdx].time % 900 !== 0) {
    startIdx++;
  }

  for (let i = startIdx; i + 2 < sorted5m.length; i += 3) {
    const c0  = sorted5m[i];
    const c1  = sorted5m[i + 1];
    const c1b = sorted5m[i + 2];

    // Verify the three candles are exactly 300 s apart (true consecutive 5-min bars)
    if (c1.time - c0.time !== 300 || c1b.time - c0.time !== 600) continue;

    // Prefer the real 15-min candle; fall back to a synthetic built from the 3×5-min bars
    const match = c15mMap.get(c0.time) ?? c15m.find(c => Math.abs(c.time - c0.time) < 30);
    const c2: OHLCCandle = match ?? {
      time:   c0.time,
      open:   c0.open,
      high:   Math.max(c0.high,  c1.high,  c1b.high),
      low:    Math.min(c0.low,   c1.low,   c1b.low),
      close:  c1b.close,
      volume: c0.volume + c1.volume + c1b.volume,
    };

    periods.push({
      periodOpen:   c0.open,
      c0, c1, c1b, c2,
      settledAbove: c2.close > c0.open,
    });
  }
  return periods;
}

// ── Single period evaluation ──────────────────────────────────────────────────

type Observation = {
  currentPrice:    number;
  velocity:        number;  // $/min over observation window
  priorVelocity:   number;  // $/min in the candle before observation
  modelProb:       number;
  edge:            number;
  stalling:        boolean;
  accelerating:    boolean;
};

/** Last 5m bar of the previous 15m period (c1b, else c1). Used as prior velocity at minute-5. */
export function priorBarOf(prev: Period15m | null | undefined): OHLCCandle | null {
  if (!prev) return null;
  return prev.c1b ?? prev.c1;
}

/** $/min over a 5-minute OHLC bar. */
export function barVelocityPerMin(bar: OHLCCandle | null | undefined): number {
  if (!bar) return 0;
  return (bar.close - bar.open) / 5;
}

/**
 * Task #347/#354: acceleration needs a real prior window.
 * priorVelocity === 0 used to make `abs(v) > 0` so every moving minute-5
 * print counted as accelerating (inflated WR). No prior → not accelerating.
 */
export function isAccelerating(velocity: number, priorVelocity: number): boolean {
  if (!Number.isFinite(velocity) || !Number.isFinite(priorVelocity)) return false;
  if (priorVelocity === 0) return false;
  return Math.abs(velocity) > Math.abs(priorVelocity) * 1.3;
}

/**
 * Task #346: 5-minute closes visible at the decision timestamp.
 * Minute-5: prior periods' c0/c1/c1b + current c0.close. Never current c1/c2.
 * Minute-10: those plus current c1.close. Never current c1b/c2 (settlement).
 */
export function fiveMinClosesAtDecision(
  periods: Period15m[],
  i: number,
  observationMinute: 5 | 10,
): number[] {
  const closes: number[] = [];
  const last = Math.max(0, Math.min(i, periods.length));
  for (let j = 0; j < last; j++) {
    const p = periods[j];
    closes.push(p.c0.close, p.c1.close);
    if (p.c1b) closes.push(p.c1b.close);
  }
  if (i < 0 || i >= periods.length) return closes;
  const cur = periods[i];
  closes.push(cur.c0.close);
  if (observationMinute === 10) closes.push(cur.c1.close);
  return closes;
}

export function volAtDecision(periods: Period15m[], i: number, observationMinute: 5 | 10): number {
  const closes = fiveMinClosesAtDecision(periods, i, observationMinute);
  return realizedVol(closes.slice(-40));
}

export function observeAtMinute5(p: Period15m, vol: number, prev: Period15m | null = null): Observation {
  const currentPrice   = p.c1.open;        // observation is at start of c1 (c0 just elapsed)
  const velocity       = (p.c1.open - p.c0.open) / 5;
  const priorVelocity  = barVelocityPerMin(priorBarOf(prev));
  const { prob, edge } = probEdge(currentPrice, p.periodOpen, vol, 10);
  // Lookahead fix (Task #354): the minute-5 decision only has c0 (minutes 0-5)
  // fully elapsed — c1.close is the price at minute 10, which is future data
  // relative to this decision point. The old formula compared c1's net move to
  // c0's, silently letting the backtest "see" 5 minutes ahead when applying
  // useStallFilter, which is what inflated win rates for minute-5 strategies.
  // Fix: derive stalling from c0's own shape only (net move vs its own
  // high-low range — a small net move inside a wide range means the price
  // chopped back and forth indecisively, the same "stalling" concept, without
  // reading anything past the decision timestamp).
  const c0Range        = p.c0.high - p.c0.low;
  const c0Net          = Math.abs(p.c0.close - p.c0.open);
  const stalling       = c0Range > 0 && (c0Net / c0Range) < 0.35 && Math.abs(velocity) > 5;
  const accelerating   = isAccelerating(velocity, priorVelocity);
  return { currentPrice, velocity, priorVelocity, modelProb: prob, edge, stalling, accelerating };
}

export function observeAtMinute10(p: Period15m, vol: number): Observation {
  const currentPrice   = p.c1.close;      // at end of c1 (minute 10)
  const velocity       = (p.c1.close - p.c0.open) / 10;
  const priorVelocity  = (p.c1.open - p.c0.open) / 5;
  const { prob, edge } = probEdge(currentPrice, p.periodOpen, vol, 5);
  const stalling       = Math.abs(p.c1.close - p.c1.open) < Math.abs(p.c0.close - p.c0.open) * 0.35 && Math.abs(velocity) > 5;
  const accelerating   = isAccelerating(velocity, priorVelocity);
  return { currentPrice, velocity, priorVelocity, modelProb: prob, edge, stalling, accelerating };
}

// ── Simulate trade P&L for a period ──────────────────────────────────────────

interface SimResult {
  outcome:         'win' | 'loss' | 'early_win' | 'early_loss';
  pnlCents:        number;      // GROSS — frictionless, no fee (unchanged research baseline)
  feeCents:        number;      // real Kalshi taker fee for this trade, for callers computing net
  exitPriceCents:  number;
  exitReason:      'settlement' | 'stop_loss' | 'profit_take';
}

/**
 * Simulate trade P&L using proper binary option pricing at the mid-period check.
 *
 * The old linear model (6¢ per 0.1% BTC move) significantly underestimates
 * ITM option value near expiry and overestimates OTM recovery potential.
 *
 * New model: use binaryCallPrice() to value the contract at minute ~10 of the
 * period (c1b.open), which has ~2.5 min remaining. This correctly captures:
 *   - Deep ITM: price → 95–99¢ even with small displacement (time decay working)
 *   - ATM: steep, non-linear sensitivity near expiry
 *   - Deep OTM: price → 1–5¢ (hard floor, not negative like the linear model)
 */
function simulateTrade(
  signal:          'LONG' | 'SHORT',
  entryPriceCents: number,
  period:          Period15m,
  strat:           StrategyDef,
  contracts:       number,
  vol:             number,      // annualised realized vol for this period window
  _minsAtEntry:    number,      // minutes remaining at entry (kept for future use)
): SimResult {
  const side      = signal === 'LONG' ? 'yes' : 'no';
  const settledUp = period.c2.close > period.periodOpen;
  const won       = side === 'yes' ? settledUp : !settledUp;

  // Real Kalshi taker fee — charged once per contract at fill time regardless
  // of outcome (not refunded on a loss). Live order paths always pay this;
  // omitting it here made every simulated trade ~2-7¢/contract too profitable.
  const feeCents = kalshiTakerFeeCents(entryPriceCents, contracts);

  // Mid-period BTC price: c1b.open = minute 10, approximately 2.5 min before expiry
  const midBtcPrice  = period.c1b?.open ?? period.c2.open;
  const safeVol      = Math.max(0.20, Math.min(3.0, vol));  // clamp to plausible range

  // Binary option price at the mid-period check (2.5 minutes remaining)
  const midYesPrice  = binaryCallPrice(midBtcPrice, period.periodOpen, safeVol, 2.5);
  const midSidePrice = side === 'yes' ? midYesPrice : 100 - midYesPrice;
  const perContrPnl  = midSidePrice - entryPriceCents;

  // Stop-loss: unrealized loss at mid-period exceeds threshold
  // NOTE: pnlCents here is GROSS (frictionless) — this is the research/signal
  // baseline. Callers that want live-realistic numbers use `feeCents` to
  // derive net P&L themselves (see runBacktest's evPasses/netPnlCents).
  if (strat.useStopLoss && perContrPnl < -strat.stopLossCents) {
    const exitP = Math.max(1, entryPriceCents - strat.stopLossCents);
    const pnl   = (exitP - entryPriceCents) * contracts;
    return { outcome: 'early_loss', pnlCents: pnl, feeCents, exitPriceCents: exitP, exitReason: 'stop_loss' };
  }

  // Profit-take: unrealized gain at mid-period exceeds threshold
  if (strat.useProfitTake && perContrPnl > strat.profitTakeCents) {
    const exitP = Math.min(99, entryPriceCents + strat.profitTakeCents);
    const pnl   = (exitP - entryPriceCents) * contracts;
    return { outcome: 'early_win', pnlCents: pnl, feeCents, exitPriceCents: exitP, exitReason: 'profit_take' };
  }

  // Settlement
  const settlePnl = won ? contracts * (100 - entryPriceCents) : -contracts * entryPriceCents;
  return { outcome: won ? 'win' : 'loss', pnlCents: settlePnl, feeCents, exitPriceCents: won ? 100 : 0, exitReason: 'settlement' };
}

// ── Core backtest runner ──────────────────────────────────────────────────────

const BASE_WIN_RATE = 0.70;   // assumed win rate for Kelly sizing in sim

/** Shared STAY_OUT record builder — every no-trade skip reason uses the same shape. */
function noTradeRecord(
  periodIdx: number, foldIdx: number, p: Period15m,
  vel: number, obs: { modelProb: number; edge: number; stalling: boolean; accelerating: boolean },
  entryPriceCents = 50,
): TradeRecord {
  return {
    periodIdx, foldIdx, signal: 'STAY_OUT', velocity5: vel, velocity10: 0,
    modelProb: obs.modelProb, edge: obs.edge, stalling: obs.stalling, accelerating: obs.accelerating,
    confidence: 0, entryPriceCents, exitPriceCents: null, outcome: 'no_trade', pnlCents: 0,
    contracts: 0, settledAbove: p.settledAbove, exitReason: 'no_trade',
    feeCentsPaid: 0, evPasses: false, netPnlCents: 0,
  };
}

function runBacktest(periods: Period15m[], strat: StrategyDef, foldIdx: number): BacktestResult {
  const trades: TradeRecord[]  = [];
  const pnlSeries: number[]    = [];
  let equity = 10_000;           // starting paper balance (¢)
  let peak   = 10_000;
  const equityCurve: number[]  = [equity];
  let consecutiveLosses = 0;
  let cooldownRemaining = 0;
  let tradedThisPeriod  = false;
  let lastPeriodIdx     = -1;

  // Vol from 5m closes visible at the decision (#346). Never c2 settlement.
  for (let i = 20; i < periods.length; i++) {
    const p   = periods[i];
    const vol = volAtDecision(periods, i, strat.observationMinute);

    if (i !== lastPeriodIdx) {
      tradedThisPeriod = false;
      lastPeriodIdx    = i;
      if (cooldownRemaining > 0) cooldownRemaining--;
    }

    if (tradedThisPeriod) continue;
    if (cooldownRemaining > 0) {
      trades.push(noTradeRecord(i, foldIdx, p, 0, { modelProb: 0.5, edge: 0, stalling: false, accelerating: false }));
      continue;
    }

    const obs = strat.observationMinute === 5
      ? observeAtMinute5(p, vol, i > 0 ? periods[i - 1] : null)
      : observeAtMinute10(p, vol);

    const vel  = obs.velocity;
    const minsLeft = strat.observationMinute === 5 ? 10 : 5;

    // Velocity filter
    if (Math.abs(vel) < strat.minVelocity) {
      trades.push(noTradeRecord(i, foldIdx, p, vel, obs));
      continue;
    }
    if (strat.useEdge && obs.edge < strat.minEdge) {
      trades.push(noTradeRecord(i, foldIdx, p, vel, obs));
      continue;
    }
    if (strat.useStallFilter && obs.stalling) {
      trades.push(noTradeRecord(i, foldIdx, p, vel, obs));
      continue;
    }
    if (strat.useAcceleration && !obs.accelerating) {
      trades.push(noTradeRecord(i, foldIdx, p, vel, obs));
      continue;
    }

    // Loss cooldown
    if (strat.useLossCooldown && consecutiveLosses >= 2) {
      if (Math.abs(vel) < strat.minVelocity * strat.cooldownMultiplier) {
        trades.push(noTradeRecord(i, foldIdx, p, vel, obs));
        continue;
      }
    }

    // Drawdown guard
    const ddPct       = peak > 0 ? (peak - equity) / peak * 100 : 0;
    const guardFactor = ddPct < strat.drawdownGuardPct ? 1
                      : ddPct < strat.drawdownGuardPct * 1.5 ? 0.5 : 0.25;

    const signal: 'LONG' | 'SHORT' = vel > 0 ? 'LONG' : 'SHORT';
    const entryPriceCents           = Math.max(25, Math.min(75, Math.round(obs.modelProb * 100)));
    const contracts                 = Math.max(1, Math.round(kellyContracts(BASE_WIN_RATE, entryPriceCents, 5) * guardFactor));
    const cost                      = contracts * entryPriceCents;

    if (equity < cost) {
      trades.push(noTradeRecord(i, foldIdx, p, vel, obs, entryPriceCents));
      continue;
    }

    // EV/fee economics — mirrors live's PATH_GATE (trade-path.ts). GROSS
    // signal generation and entry admission above are left exactly as they
    // were (research/signal-quality baseline, unaffected by economics), but
    // every entered trade is stamped with whether it would have cleared the
    // live EV floor and what real Kalshi fee it would pay. Net/live-proxy
    // aggregates (see summarizeTrades) are derived from these per-trade
    // stamps, not by re-running the simulation — so a research combo's raw
    // signal quality and its live-tradability are always reported side by
    // side, never conflated into one number.
    const pathCfg   = getPathConfig(entryPriceCents);
    const ev        = computeTradeEV({
      entryPriceCents,
      winRate:    Math.min(0.97, Math.max(0.03, obs.modelProb)),
      minEVCents: pathCfg.minEVCents,
    });
    const evPasses  = ev.passes;

    const { outcome, pnlCents, feeCents, exitPriceCents: exitP, exitReason } = simulateTrade(signal, entryPriceCents, p, strat, contracts, vol, minsLeft);
    const netPnlCents = evPasses ? pnlCents - feeCents : 0;

    equity       += pnlCents;
    if (equity > peak) peak = equity;

    const conf   = Math.min(95, Math.round(obs.edge * 3 + Math.abs(vel) / 5 + 55));
    const won    = outcome === 'win' || outcome === 'early_win';

    if (won) {
      consecutiveLosses = 0;
    } else {
      consecutiveLosses++;
      // NOTE: cooldownRemaining timer is intentionally inert (always 0).
      // The loss-cooldown is enforced by the inline velocity gate at lines
      // 460–465 above (skip if consecutiveLosses >= 2 and vel < multiplied threshold).
      // The timer path (this variable + checks at lines ~410/424/428) is dead code
      // left from an earlier design. Do not set to a positive value here without
      // also verifying the timer-guard interactions don't double-block trades.
    }

    equityCurve.push(equity);
    pnlSeries.push(pnlCents);
    tradedThisPeriod = true;

    trades.push({
      periodIdx: i, foldIdx, signal,
      velocity5: vel, velocity10: 0, modelProb: obs.modelProb,
      edge: obs.edge, stalling: obs.stalling, accelerating: obs.accelerating,
      confidence: conf, entryPriceCents, exitPriceCents: exitP,
      outcome, pnlCents, contracts, settledAbove: p.settledAbove, exitReason,
      feeCentsPaid: feeCents, evPasses, netPnlCents,
    });
  }

  const entered   = trades.filter(t => t.outcome !== 'no_trade');
  const wins      = entered.filter(t => t.outcome === 'win' || t.outcome === 'early_win');
  const losses    = entered.filter(t => t.outcome === 'loss' || t.outcome === 'early_loss');
  const earlyExits = entered.filter(t => t.exitReason !== 'settlement' && t.exitReason !== 'no_trade');
  const totalPnl  = entered.reduce((s, t) => s + t.pnlCents, 0);
  const winPnls   = wins.map(t => t.pnlCents);
  const lossPnls  = losses.map(t => Math.abs(t.pnlCents));
  const maxDD     = computeMaxDrawdown(equityCurve);
  const sharpe    = computeSharpe(pnlSeries);
  const pf        = computeProfitFactor(winPnls, lossPnls);
  const annRet    = pnlSeries.length > 0
    ? (pnlSeries.reduce((a, b) => a + b, 0) / pnlSeries.length) * CANDLES_PER_YEAR / 100
    : 0;
  const calmar    = maxDD > 0 ? annRet / maxDD : annRet > 0 ? 10 : 0;
  const composite = 0.4 * Math.min(sharpe, 5) / 5 + 0.3 * Math.min(pf, 5) / 5 + 0.3 * Math.min(Math.max(calmar, 0), 5) / 5;
  const netMetrics = summarizeNet(trades, periods.length);

  return {
    netMetrics,
    researchOnly:    true,
    strategy:        strat,
    phase:           foldIdx === 0 ? 'train' : 'oos',
    totalPeriods:    periods.length,
    tradesEntered:   entered.length,
    wins:            wins.length,
    losses:          losses.length,
    winRate:         entered.length > 0 ? wins.length / entered.length : 0,
    pnlCents:        totalPnl,
    pnlDollars:      totalPnl / 100,
    roi:             totalPnl / 10_000,
    sharpe,
    profitFactor:    pf,
    maxDrawdown:     maxDD,
    calmar,
    compositeScore:  composite,
    avgWinCents:     wins.length > 0 ? winPnls.reduce((a, b) => a + b, 0) / wins.length : 0,
    avgLossCents:    losses.length > 0 ? lossPnls.reduce((a, b) => a + b, 0) / losses.length : 0,
    expectancyCents: entered.length > 0 ? totalPnl / entered.length : 0,
    trades,
    regimeStats:     [],
    earlyExits:      earlyExits.length,
  };
}

// ── 3-fold time-series cross-validation ──────────────────────────────────────

/**
 * Merge several fold-level BacktestResults into one pooled result, as if all
 * their trades had happened back-to-back on a single continuous equity curve.
 * Folds must already be in chronological order (non-overlapping, increasing
 * periodIdx across folds) for the rebuilt equity curve / Sharpe to be valid.
 */
function poolBacktestResults(results: BacktestResult[], phase: 'train' | 'oos'): BacktestResult {
  const trades      = results.flatMap(r => r.trades);
  const entered     = trades.filter(t => t.outcome !== 'no_trade');
  const wins        = entered.filter(t => t.outcome === 'win' || t.outcome === 'early_win');
  const losses      = entered.filter(t => t.outcome === 'loss' || t.outcome === 'early_loss');
  const earlyExits  = entered.filter(t => t.exitReason !== 'settlement' && t.exitReason !== 'no_trade');
  const totalPnl    = entered.reduce((s, t) => s + t.pnlCents, 0);
  const winPnls     = wins.map(t => t.pnlCents);
  const lossPnls    = losses.map(t => Math.abs(t.pnlCents));
  const totalPeriods = results.reduce((s, r) => s + r.totalPeriods, 0);

  // Rebuild one continuous equity curve across all folds, in the same
  // chronological order the trades were generated in.
  let equity = 10_000;
  const equityCurve: number[] = [equity];
  const pnlSeries: number[]   = [];
  for (const t of entered) {
    equity += t.pnlCents;
    equityCurve.push(equity);
    pnlSeries.push(t.pnlCents);
  }

  const maxDD  = computeMaxDrawdown(equityCurve);
  const sharpe = computeSharpe(pnlSeries);
  const pf     = computeProfitFactor(winPnls, lossPnls);
  const annRet = pnlSeries.length > 0
    ? (pnlSeries.reduce((a, b) => a + b, 0) / pnlSeries.length) * CANDLES_PER_YEAR / 100
    : 0;
  const calmar    = maxDD > 0 ? annRet / maxDD : annRet > 0 ? 10 : 0;
  const composite = 0.4 * Math.min(sharpe, 5) / 5 + 0.3 * Math.min(pf, 5) / 5 + 0.3 * Math.min(Math.max(calmar, 0), 5) / 5;
  const netMetrics = summarizeNet(trades, totalPeriods);

  return {
    netMetrics,
    researchOnly:    true,
    strategy:        results[0]?.strategy as StrategyDef,
    phase,
    totalPeriods,
    tradesEntered:   entered.length,
    wins:            wins.length,
    losses:          losses.length,
    winRate:         entered.length > 0 ? wins.length / entered.length : 0,
    pnlCents:        totalPnl,
    pnlDollars:      totalPnl / 100,
    roi:             totalPnl / 10_000,
    sharpe,
    profitFactor:    pf,
    maxDrawdown:     maxDD,
    calmar,
    compositeScore:  composite,
    avgWinCents:     wins.length > 0 ? winPnls.reduce((a, b) => a + b, 0) / wins.length : 0,
    avgLossCents:    losses.length > 0 ? lossPnls.reduce((a, b) => a + b, 0) / losses.length : 0,
    expectancyCents: entered.length > 0 ? totalPnl / entered.length : 0,
    trades,
    regimeStats:     [],
    earlyExits:      earlyExits.length,
  };
}

/**
 * Genuine 3-fold expanding-window walk-forward CV (Task #354).
 *
 * The previous implementation only ever produced ONE 75%/25% train/OOS split,
 * despite the module docstring claiming "3-fold walk-forward". With a
 * 1,728-combo grid search ranking purely on that single small OOS slice, the
 * winner was effectively selected by which combo got luckiest against one
 * fixed holdout window — classic backtest-overfitting via test-set reuse.
 * That's what produced Sharpe ratios >60 and 100% OOS win rates on combos
 * with as few as 24 trades: not a literal future-data peek (those were fixed
 * 2026-08-02), but the search process itself "leaking" information about the
 * one OOS window into which combo got picked.
 *
 * Fix: evaluate every combo against 3 independent, non-overlapping,
 * chronologically-later OOS windows (expanding training window ahead of
 * each), then pool all 3 OOS folds into one combined result before ranking.
 * A combo now has to hold up across 3 different slices of market history
 * instead of getting lucky on one.
 */
function walkForwardCV(periods: Period15m[], strat: StrategyDef): { train: BacktestResult; oos: BacktestResult; ci: BootstrapCI } {
  const n = periods.length;
  const NUM_FOLDS = 3;
  const initialTrainEnd = Math.floor(n * 0.4);
  const foldSize = Math.floor((n - initialTrainEnd) / NUM_FOLDS);

  // Only the 3 OOS windows are disjoint and worth pooling. The strategy's
  // rule thresholds are fixed (never fit from train data), so re-running
  // train on 3 growing, heavily-overlapping windows and concatenating them
  // would just re-process the same early periods 2-3× over for no benefit —
  // that redundant duplication (up to ~1.6n TradeRecords/combo instead of
  // ~0.4n) is what OOM'd the 1,728-combo grid search the first time this was
  // tried. One reference train run on the initial 40% window is enough.
  const oosFolds: BacktestResult[] = [];
  for (let k = 0; k < NUM_FOLDS; k++) {
    const trainEnd = initialTrainEnd + foldSize * k;
    const oosStart = trainEnd;
    const oosEnd   = k === NUM_FOLDS - 1 ? n : trainEnd + foldSize;
    const oosP     = periods.slice(oosStart, oosEnd);
    if (oosP.length < 15) continue;
    oosFolds.push(runBacktest(oosP, strat, k + 1));
  }

  // Not enough history to form 3 real folds (e.g. thin test fixtures) — fall
  // back to the old single 75/25 split rather than producing no result.
  if (oosFolds.length === 0) {
    const fold   = Math.floor(n / 4);
    const trainP = periods.slice(0, fold * 3);
    const oosP   = periods.slice(fold * 3);
    const train  = runBacktest(trainP, strat, 0);
    const oos    = runBacktest(oosP,   strat, 1);
    const oosTrades = oos.trades.filter(t => t.outcome !== 'no_trade');
    const oosWins   = oosTrades.filter(t => t.outcome === 'win' || t.outcome === 'early_win').map(() => 1);
    const oosLosses = oosTrades.filter(t => t.outcome === 'loss' || t.outcome === 'early_loss').map(() => 0);
    return { train, oos, ci: bootstrapCI(oosWins, oosLosses, 500) };
  }

  const trainP = periods.slice(0, initialTrainEnd);
  const train  = trainP.length >= 40 ? runBacktest(trainP, strat, 0) : oosFolds[0];
  const oos    = poolBacktestResults(oosFolds, 'oos');

  // Bootstrap CI from the pooled OOS results (3 folds' worth of trades)
  const oosTrades = oos.trades.filter(t => t.outcome !== 'no_trade');
  const oosWins   = oosTrades.filter(t => t.outcome === 'win' || t.outcome === 'early_win').map(() => 1);
  const oosLosses = oosTrades.filter(t => t.outcome === 'loss' || t.outcome === 'early_loss').map(() => 0);
  const ci        = bootstrapCI(oosWins, oosLosses, 500);  // 500 iter in grid search (full 1000 in best config)

  return { train, oos, ci };
}

// ── Grid search ───────────────────────────────────────────────────────────────

const GRID = {
  minVelocity:         [15, 25, 40, 60],
  minEdge:             [3, 6, 10],
  useEdge:             [true, false],
  useStallFilter:      [true, false],
  useAcceleration:     [false, true],
  useLossCooldown:     [true],
  cooldownMultiplier:  [1.5, 2.0],
  useStopLoss:         [true, false],
  stopLossCents:       [12, 18],
  useProfitTake:       [true, false],
  profitTakeCents:     [10, 16],
  drawdownGuardPct:    [15, 25],
  observationMinute:   [5, 10] as (5 | 10)[],
};

export async function runGridSearch(
  onProgress?: (done: number, total: number, msg: string) => void,
): Promise<{ top: GridResult[]; all: GridResult[]; allPeriods: Period15m[]; dataSource: string }> {

  onProgress?.(0, 1, 'Fetching real 5-min BTC candles (Binance/Coinbase)…');

  // 8,000 real 5-min candles ≈ 28 days. The old Kalshi-settlement source only
  // had ~7-10 days of history to begin with (240-960 settlements per the
  // startup log), which made walk-forward's 25% OOS slice too thin (~166
  // periods) for a ≥10-trade filter to mean much even before the leak was
  // fixed. Real Coinbase/Binance history goes back years, so widen the
  // window now that doing so no longer costs any data integrity — but keep
  // it well short of 20k, which OOM'd the grid search's 4,608-combo sweep.
  const CANDLE_COUNT = 8_000;
  const startMs       = Date.now() - CANDLE_COUNT * 5 * 60 * 1000;
  const { candles: c5m, source } = await fetchRealCandles(startMs, CANDLE_COUNT, 5);

  if (c5m.length < 200) throw new Error(`Insufficient real 5-min candle data (got ${c5m.length} from ${source})`);

  // No separate 15m fetch: groupPeriods() already synthesizes each period's
  // 15m candle from its three real 5m candles when no exact match is passed,
  // which avoids a second fetch and keeps every input candle genuinely real.
  const periods = groupPeriods(c5m, []);
  if (periods.length < 60) throw new Error(`Only ${periods.length} 15-min periods — need ≥60`);

  onProgress?.(1, periods.length, `${periods.length} periods loaded. Starting grid search…`);

  // Build all combos
  const combos: StrategyDef[] = [];
  for (const vel of GRID.minVelocity)
  for (const edge of GRID.minEdge)
  for (const useEdge of GRID.useEdge)
  for (const stall of GRID.useStallFilter)
  for (const accel of GRID.useAcceleration)
  for (const cdMult of GRID.cooldownMultiplier)
  for (const useStop of GRID.useStopLoss)
  for (const stopC of (useStop ? GRID.stopLossCents : [12]))
  for (const useProfit of GRID.useProfitTake)
  for (const profC of (useProfit ? GRID.profitTakeCents : [10]))
  for (const ddGuard of GRID.drawdownGuardPct)
  for (const obsMin of GRID.observationMinute) {
    if (!useEdge && edge !== GRID.minEdge[0]) continue;  // deduplicate
    combos.push({
      name:               `v${vel}_e${useEdge ? edge : 0}_s${stall ? 1 : 0}_a${accel ? 1 : 0}_sl${useStop ? stopC : 0}_pt${useProfit ? profC : 0}_d${ddGuard}_o${obsMin}`,
      minVelocity:        vel,
      useEdge,
      minEdge:            edge,
      useStallFilter:     stall,
      useAcceleration:    accel,
      useLossCooldown:    true,
      cooldownMultiplier: cdMult,
      useStopLoss:        useStop,
      stopLossCents:      stopC,
      useProfitTake:      useProfit,
      profitTakeCents:    profC,
      drawdownGuardPct:   ddGuard,
      observationMinute:  obsMin,
    });
  }

  const all: GridResult[] = [];
  const total = combos.length;

  for (let idx = 0; idx < combos.length; idx++) {
    const combo = combos[idx];
    try {
      const { train, oos, ci } = walkForwardCV(periods, combo);
      // Filter: OOS must have >= 30 trades and >= 50% win rate.
      // Raised from >=10 (Task #354): now that OOS is pooled across 3 folds
      // spanning ~60% of history, a combo with only 10-20 trades is still
      // thin enough that a lucky run can hit 90-100% win rate purely by
      // chance out of 2,000+ combos tested (multiple-comparisons bias) —
      // e.g. one combo hit 97% WR / Sharpe 35 on just 78 trades before this
      // was raised. 30 keeps genuinely rare-signal strategies eligible while
      // filtering out the thinnest, least trustworthy samples.
      if (oos.tradesEntered >= 30 && oos.winRate >= 0.50) {
        const wilsonRankScore    = computeWilsonRankScore(oos.tradesEntered, oos.wins, oos.compositeScore);
        // Same Wilson-LB blend, but computed from the live-proxy (net) OOS
        // numbers — fee-adjusted P&L, only trades that passed the live EV
        // floor. 0 (never top-ranked) when net has too few trades to trust,
        // even if the gross/research side looks strong.
        const nm                = oos.netMetrics;
        const netWilsonRankScore = nm.tradesEntered >= 30
          ? computeWilsonRankScore(nm.tradesEntered, nm.wins, nm.compositeScore)
          : 0;
        all.push({ train, oos, composite: oos.compositeScore, wilsonRankScore, netWilsonRankScore, ci });
      }
    } catch (err) {
      console.debug(`[backtest] Grid search combo ${idx} error:`, (err as Error).message);
    }
    if (idx % 50 === 0) onProgress?.(idx, total, `Grid search: ${idx}/${total} combos…`);
  }

  // 2026-08-25: default rank is now the LIVE-PROXY (net) Wilson-adjusted
  // score, not the gross/research one — a combo that only "wins" on
  // frictionless, EV-floor-ignoring numbers should not top the leaderboard.
  // wilsonRankScore (gross) is preserved on every result for side-by-side
  // display, but no longer decides ranking order.
  all.sort((a, b) => b.netWilsonRankScore - a.netWilsonRankScore);
  const top10 = all.slice(0, 10);

  // Re-run top-3 with full 1,000-iteration Monte Carlo
  for (const r of top10.slice(0, 3)) {
    const oosTrades = r.oos.trades.filter(t => t.outcome !== 'no_trade');
    const oosWins   = oosTrades.filter(t => t.outcome === 'win' || t.outcome === 'early_win').map(() => 1);
    const oosLosses = oosTrades.filter(t => t.outcome === 'loss' || t.outcome === 'early_loss').map(() => 0);
    r.ci            = bootstrapCI(oosWins, oosLosses, 1_000);
  }

  onProgress?.(total, total, `Done! ${all.length} valid strategies found.`);

  return { top: top10, all, allPeriods: periods, dataSource: source };
}

// ── Map best strategy → bot config ───────────────────────────────────────────

export function configFromBacktest(strat: StrategyDef): {
  minVelocity:        number;
  minProbEdge:        number;
  useProbEdge:        boolean;
  useStallFilter:     boolean;
  useAcceleration:    boolean;
  useLossCooldown:    boolean;
  cooldownMultiplier: number;
  useStopLoss:        boolean;
  stopLossCents:      number;
  useProfitTake:      boolean;
  profitTakeCents:    number;
  drawdownGuardPct:   number;
} {
  return {
    minVelocity:        strat.minVelocity,
    minProbEdge:        strat.useEdge ? strat.minEdge : 0,
    useProbEdge:        strat.useEdge,
    useStallFilter:     strat.useStallFilter,
    useAcceleration:    strat.useAcceleration,
    useLossCooldown:    strat.useLossCooldown,
    cooldownMultiplier: strat.cooldownMultiplier,
    useStopLoss:        strat.useStopLoss,
    stopLossCents:      strat.stopLossCents,
    useProfitTake:      strat.useProfitTake,
    profitTakeCents:    strat.profitTakeCents,
    drawdownGuardPct:   strat.drawdownGuardPct,
  };
}
