/**
 * cors-origin.test.ts — allowlist for Vite localhost + rotating trycloudflare
 * tunnels. Deny must be a boolean false (never throw → HTTP 500).
 *
 * LOCKS: paper stays paper. Do not edit trading-bot.ts.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { isAllowedOrigin } from "./cors-origin.js";

const allow = new Set([
  "https://kalshi-oracle.fly.dev",
  "http://127.0.0.1:8080",
]);

test("no Origin header (curl / server-to-server) is allowed", () => {
  assert.equal(isAllowedOrigin(undefined, allow), true);
  assert.equal(isAllowedOrigin("", allow), true);
});

test("env / FLY allowlist exact match", () => {
  assert.equal(isAllowedOrigin("https://kalshi-oracle.fly.dev", allow), true);
  assert.equal(isAllowedOrigin("http://127.0.0.1:8080", allow), true);
});

test("localhost and 127.0.0.1 with any port (Vite)", () => {
  assert.equal(isAllowedOrigin("http://localhost:5173", allow), true);
  assert.equal(isAllowedOrigin("http://localhost", allow), true);
  assert.equal(isAllowedOrigin("https://localhost:4173", allow), true);
  assert.equal(isAllowedOrigin("http://127.0.0.1:5173", allow), true);
  assert.equal(isAllowedOrigin("https://127.0.0.1:8080", allow), true);
});

test("https://*.trycloudflare.com quick tunnels (rotating names)", () => {
  assert.equal(
    isAllowedOrigin("https://hidden-safari-caps-leaf.trycloudflare.com", allow),
    true,
  );
  assert.equal(
    isAllowedOrigin("https://some-other-random-words.trycloudflare.com", allow),
    true,
  );
});

test("http trycloudflare and unrelated origins are denied", () => {
  assert.equal(
    isAllowedOrigin("http://hidden-safari-caps-leaf.trycloudflare.com", allow),
    false,
  );
  assert.equal(isAllowedOrigin("https://evil.example", allow), false);
  assert.equal(isAllowedOrigin("https://trycloudflare.com.evil.example", allow), false);
});
