/**
 * Tasks #346 / #347 / #354 — backtest honesty.
 * Vol uses 5m closes available at the decision (never settlement c2).
 * Minute-5 accel compares vs the previous period's last 5m bar.
 * No prior bar → not accelerating (old priorVelocity=0 inflated WR).
 */
import test from "node:test";
import assert from "node:assert/strict";
import {
  barVelocityPerMin,
  fiveMinClosesAtDecision,
  isAccelerating,
  observeAtMinute5,
  observeAtMinute10,
  priorBarOf,
  type OHLCCandle,
  type Period15m,
} from "./backtest-engine.js";

function bar(time: number, open: number, close: number, high = close, low = open): OHLCCandle {
  return { time, open, high: Math.max(high, open, close), low: Math.min(low, open, close), close, volume: 1 };
}

function period(open: number, c0c: number, c1c: number, c1bc: number, settle: number, t0: number): Period15m {
  const c0 = bar(t0, open, c0c);
  const c1 = bar(t0 + 300, c0c, c1c);
  const c1b = bar(t0 + 600, c1c, c1bc);
  const c2 = bar(t0, open, settle, Math.max(open, c0c, c1c, c1bc, settle), Math.min(open, c0c, c1c, c1bc, settle));
  return { periodOpen: open, c0, c1, c1b, c2, settledAbove: settle > open };
}

test("#347 isAccelerating: no prior window is never accelerating", () => {
  assert.equal(isAccelerating(80, 0), false);
  assert.equal(isAccelerating(-80, 0), false);
});

test("#347 isAccelerating: current must beat |prior| * 1.3", () => {
  assert.equal(isAccelerating(13, 10), false); // 1.3x exact is not >
  assert.equal(isAccelerating(14, 10), true);
  assert.equal(isAccelerating(-14, -10), true);
  assert.equal(isAccelerating(5, 10), false);
});

test("#347 minute-5 prior velocity is previous period last 5m bar, not 0", () => {
  const prev = period(100, 101, 102, 108, 108, 0); // last bar +6 / 5 = 1.2 $/min
  const cur = period(108, 120, 121, 122, 130, 900); // first 5m +12 / 5 = 2.4
  const obs = observeAtMinute5(cur, 0.5, prev);
  assert.equal(obs.priorVelocity, barVelocityPerMin(priorBarOf(prev)));
  assert.equal(obs.priorVelocity, (108 - 102) / 5);
  assert.ok(obs.priorVelocity !== 0);
  assert.equal(obs.accelerating, isAccelerating(obs.velocity, obs.priorVelocity));
});

test("#347/#354 minute-5 without prev is not accelerating even with a big move", () => {
  const cur = period(100, 200, 201, 202, 250, 900);
  const obs = observeAtMinute5(cur, 0.5, null);
  assert.equal(obs.priorVelocity, 0);
  assert.equal(obs.accelerating, false);
});

test("#354 minute-5 observation never reads c1.close / c2.close", () => {
  const prev = period(100, 100, 100, 100, 100, 0);
  const cur = period(100, 110, 999, 999, 999, 900); // future prints are 999
  const obs = observeAtMinute5(cur, 0.5, prev);
  assert.equal(obs.currentPrice, cur.c1.open);
  assert.ok(obs.currentPrice !== 999);
  assert.equal(obs.velocity, (cur.c1.open - cur.c0.open) / 5);
});

test("#346 vol closes at minute-5 exclude current c1/c2 and include current c0", () => {
  const periods = [
    period(100, 101, 102, 103, 999, 0),
    period(103, 104, 105, 106, 999, 900),
    period(106, 107, 888, 888, 999, 1800),
  ];
  const closes = fiveMinClosesAtDecision(periods, 2, 5);
  assert.deepEqual(closes, [101, 102, 103, 104, 105, 106, 107]);
  assert.ok(!closes.includes(888));
  assert.ok(!closes.includes(999));
});

test("#346 vol closes at minute-10 include current c1, still not settlement", () => {
  const periods = [
    period(100, 101, 102, 103, 999, 0),
    period(103, 104, 105, 106, 999, 900),
  ];
  const closes = fiveMinClosesAtDecision(periods, 1, 10);
  assert.deepEqual(closes, [101, 102, 103, 104, 105]);
  assert.ok(!closes.includes(999));
});

test("#354 minute-10 stalling uses c0 vs c1 only (no c1b/c2)", () => {
  const p = period(100, 110, 101, 999, 999, 0);
  const obs = observeAtMinute10(p, 0.5);
  assert.equal(obs.currentPrice, 101);
  assert.equal(obs.priorVelocity, (p.c1.open - p.c0.open) / 5);
});
