/**
 * Leftover 1H evaluate body (OTM breakout / hourly admission). Not frozen 15m law.
 *
 * Host _evaluateHourlyTickBody must not contain this body. Paper/frozen never
 * invoke leftoverHourlyEvaluateFunnel (leftoverHourlyEvaluateRun deny).
 * Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
import {
  VOLUME_HIGH_RATIO, VOLUME_LOW_RATIO, ADD_POSITION_MIN_PROFIT_CENTS,
  ACCEL_CONF_BONUS, ACCEL_CONF_PENALTY,
  STREAK_FADE_THRESH, STREAK_CONF_PENALTY, STREAK_CONF_BONUS, ALTERNATING_FADE_BONUS,
  REGIME_TREND_CONF_BONUS, REGIME_UNCLEAR_CONF_PENALTY,
  KALSHI_TAKER_FEE,
  KALSHI_API_DOMAIN,
  KALSHI_PATH_PORTFOLIO_BALANCE, KALSHI_PATH_PORTFOLIO_POSITIONS, KALSHI_PATH_PORTFOLIO_FILLS,
  KALSHI_PATH_PORTFOLIO_ORDERS, kalshiEventsOrderPath, kalshiOrderStatusPath, kalshiSettlementsPath,
  getEntryPriceBand, getUniversalPriceBandTier, PRICE_BAND_HALF_MAX_CENTS,
  RICH_ASK_EXTRA_EV_MARGIN_CENTS,
  HARVEST_ALLOWED_FAMILIES, HARVEST_SIZE_MULT, HARVEST_ASK_MAX_CENTS,
  PRICE_BAND_LATE_EXCEPTION_STRATEGIES, PRICE_BAND_EXTREME_DISPLACEMENT_PCT, PRICE_BAND_LATE_MAX_MINS_LEFT,
  PRICE_BAND_STANDARD_MAX_CENTS, computeStackTier, STACK_PRESS_COOLDOWN_MS, type SizeTier,
  SETTLEMENT_UNRESOLVED_TIMEOUT_MS, KALSHI_EXPECTED_SLIPPAGE_CENTS, expectedSlippageCents,
  observedSlippageFloorCents,
  ASIAN_HOURS_SIZE_MULT, applyTimeOfDaySizeMultiplier, capContractsToLiquidityLimit, getTimeOfDayRegime, type TimeOfDayRegime,
  MAX_DEPTH_FRACTION,
} from "./constants.js";
import { ariaMayGovernOrders, settlementModelMayVetoEntry } from "./fill-authority.js";
import { FROZEN_CC_STRATEGY_ID } from "./frozen-cc.js";
import { kalshiWS, restQuoteBlocksFill } from "./kalshi-ws.js";
import { mtfAnalyzer, getMtfOhlcBars } from "./mtf-analyzer.js";
import {
  applyHtfStructureToSide,
  computeLiveHtfStructure,
  velocitySideFromDollarsPerMin,
  type HtfStructureSnapshot,
} from "./mtf-structure.js";
import { collectAdviceShadow, formatAdviceDeskLine, type AdviceShadowLabel } from "./advice-shadow.js";
import { ticketDeltasFromHistory } from "./intra-scalp-replay.js";
import {
  evaluateAllStrategies,
  FILL_PATH_PLACE_FALSE_STRATEGY_IDS,
  placeableWithoutHaWhenMoneyMakerFires,
  classifyRegimeFromBuffer,
  getAllStrategyMeta,
  computePsychLevel,
  isStrategyAllowedForDuration,
  drainOtmConfluenceSkipEvents,
  getStrategyFamily,
  type OtmConfluenceSkipEvent,
  type StrategyResult as LibStrategyResult,
  type StrategyObservation,
} from "./strategy-library.js";
import { binaryCallPrice } from "./backtest-engine.js";
import { getBotFillLearningWeights, pathPWinFromCurveOrLearner, getLearnerPathWinRateSample } from "./strategy-learner.js";
import { isDecisionSafe, recordSuccess, recordFailure } from "./decision-safety.js";
import { getDbDisabledStrategies, getStrategyMultipliersSync, getLiveTradeStatsSync, computePSizeForKelly, computeSizeUncertaintyMult, onTradeSettled as onTradeSettledForPerformance, ensureFillOriginColumn } from "./strategy-performance.js";
import { adaptiveTuningLog } from "./adaptive-tuning-log.js";
import {
  DEFAULT_AUTO_POLICY_PARAMS, applyAutoPolicyOverlay, derivePolicy, judgeFill, normalizeBounds, normalizeMode,
  policySizeMult, stateIdFor, summarizeShadow,
  type AutoPolicy, type AutoPolicyMode, type PolicyVerdict,
} from "./auto-policy.js";
import { getPatternBoost, fingerprintObs } from "./pattern-learner.js";
import {
  computeMarketIntelligenceObs, computeMIAdjustment,
  getCurrentSessionMode, type SessionMode,
  type MarketIntelligenceData,
} from "./market-intelligence.js";
import {
  canReusePreTradeAdmissionForRequote,
  doesPreTradeVerdictMatchEntryPrice,
  getPreTradeEntryPath,
  runPreTradeSim,
} from "./pre-trade-sim.js";
import { basisTracker, projectSettlementPrice } from "./basis-tracker.js";
import { shouldSkipConfidenceFloor, resolveMoneyMakerConfFloorSideAgree, ticketEVCentsFromP } from "./confidence-floor.js";
import {
  notePaperBarEvaluate,
  notePaperBarExit,
  notePaperBarFill,
  flushPaperBar,
  flushPaperBarsExcept,
} from "./paper-bar-tape.js";
import {
  findMoneyCandSelectMiss,
  reinjectMoneyCandSelectMiss,
  meterLagSideForW2,
} from "./select-miss-recover.js";
import {
  PATH_RIDE_EXIT_BOOK,
  distanceIsFat,
  haFromRaw,
  isPathRideKellyBook,
  isPathRideFlickerBook,
  isPathRideOpenTrade,
  isPathRideStrategyId,
  PATH_RIDE_RUIN_CENTS,
  holdHardFloorMaySell,
  isStrikePin,
  isGammaGetout,
  last1mRangeDollars,
  pathRidePlus50TargetCents,
  pathRideTwoXTargetCents,
  remainingVolDollars,
  tagPathRideFill,
} from "./path-ride.js";
import { decideSettlementSideLogged, paperMoneyMakerLagMinAbsDollars, paperMoneyMakerHarvestExempt, paperMoneyMakerIgnoresSettlementSideSkip, /* F4_REMAKE_UNSTARVE */ paperPathRidePreservesThroughSettlementSkip, isPathRideKellyStrategyId, isMoneyMakerStrategyId, isRemakeSettlementSideSkip, isOriginalSettlementSideLock, moneyMakerIgnoresOverpayGate, leftoverYesAskIsPoison, leftoverRegimeBlockPlacesMoneyMaker, filterPoolToMtfAlignedCheap, isMtfAlignedCheapTake, mtfAlignedCheapWantSignal } from "./settlement-side.js";
import {
  buildMoneyGateCard,
  sessionClockLabel,
  type MoneyGateCard,
  evaluatePathDecision,
  getPathConfig,
  computeTradeEV,
  moneyMakerIgnoresPathGateSkip,
  evaluateEntryEVGate,
} from "./organs/path-gate.js";
import {
  alignedTakeGate,
  overlayAlignedTake,
  formatConstructedNoLog,
  direction_w2,
  overlayDirectionW2,
  formatDirectionW2Log,
  shouldEmitDirectionW2Log,
  createDirectionW2LogThrottleState,
} from "./organs/side-lock.js";
import {
  inStillMidCoinFlip,
  STILL_MID_UNCLEAR_SKIP,
} from "./aligned-take-gate.js";
import {
  PAPER_SCALP_STRATEGY_ID,
  PAPER_SCALP_FEE_NET_BEATS_SKIP,
  applyPaperScalpAfterSettlement,
  decidePaperScalp,
  obsToTickQuote,
  type TickQuote as PaperScalpTickQuote,
} from "./paper-scalp.js";
import {
  HARD_RISK_LIMITS,
  EV_FLOOR,
  applyHardRiskLimits,
  canScaleIntoPosition,
  computeContracts as computeKellyContracts,
  kellyPayoutRatio,
  computeKellyEdge,
} from "./organs/size.js";
import {
  OTM_EV_FLOOR,
  MIN_EDGE_OVER_MARKET,
  scoreStrategyEV,
  estimateTradeEV,
  pWinFromCurve,
  DAILY_HALT_FLOOR_CENTS,
} from "./admission.js";
import { predictionLearner } from "./prediction-learner.js";
import {
  classifyDetailedCondition,
  getConditionOverrides,
  CONDITION_META,
  type DetailedCondition,
  type AdaptiveConditionResult,
} from "./condition-adapter.js";
import type { PreTradeVerdict } from "./pre-trade-sim.js";
import type { ChannelInfo, StrategyId } from "./strategy-library.js";
import {
  updateRegime, getRegime, getGrokRegimeFromDetailed, getRegimeDebug, getRegimeHeldBy,
  type GrokRegime, type RegimeId,
} from "./regime-engine.js";
import {
  evaluateSpecialistPackShadow, type ShadowPackEvaluation, type SpecialistPacksMode,
  getPack, computeWouldEligible, type SpecialistPack, type PackId,
  filterPoolByPack, computePackConfFloor, computePackCombinedMult,
  computeConsensusDisabledIds,
} from "./specialist-packs.js";
import { computeAutoModeV2Suggestion, type AutoModeV2Suggestion } from "./automode-v2.js";
import { computeAdaptation, echoOperatorFloors, applyBotFillLearning, freshLagDisagreeSkip, type AdaptationResult } from "./automode-adapter.js";
import { lagAgreesWithSide } from "./lag-meter.js";
import { recordBounceTick, getBounceInfo, getBounceConfidenceBonus } from "./bounce-level-tracker.js";
import { settlementPredictor } from "./settlement-predictor.js";
import { expertAgent } from "./expert-agent.js";
import {
  decideMoneyPath,
  directorSkipEmptiesEvaluateResult,
  snapshotTape,
  tagPaperFill,
  pathRideMonitorDisposition,
  sizePathRide,
  pForStrategyAtAsk,
  observeAdaptiveRegime,
  fillPathRegimeTraceFields,
  planMakerEntry,
  bookImbGate,
  direction_lock,
  overlayDirectionLock,
  formatDirectionLockLog,
  type AdaptiveRegimeSnapshot,
  type OrganReport,
  type TapeSnapshot,
} from "./organs/index.js";
import { bindSideWinRateAtPrice } from "./organs/filled-side.js";
import {
  applyPathAwareContracts, applyAsianHoursMoneyMakerFloor, applyAriaPathRules, isAriaDangerVeto,
  buildModeState, applyRiskProfileSizing,
  evaluateEntryGuards, evaluateRichAskBlock, isPathBlockedForTimeOfDay,
} from "./trade-path.js";
import type { AriaAssessment, ModeState, RiskProfile } from "./trade-path.js";
import { computeVolumeScore, getVolumeSizeMult, VOLUME_BUCKET_POLICY, warmVolumeRiskCache, recordVolumeBucketSettlement } from "./volume-risk.js";
import {
  CONFIDENCE_CALIBRATION_ENABLED,
  LEFTOVER_15M_FAST_VEL as FAST_VEL,
  LEFTOVER_15M_SUSTAINED_V3 as SUSTAINED_V3,
  LEFTOVER_15M_SWEEP_PREMIUM as SWEEP_PREMIUM,
  buildAriaInput,
} from "./leftover-15m-evaluate.js";
import {
  applyStrongMTFDirectionLock,
  basisLagRegimeGateOk,
  detectGrokRegime,
  isReversalCapable,
  isStrategyAllowedInRegime,
  metaLabelConfidence,
  mtfCompositeLockAllowsSide,
  otmAwareMTFThresholds,
  pWinAtPriceRejectingThinLearner,
  passesHardFilters,
  passesStrategyRegimeFilter,
  settlementHoldOverrideEligible,
  settlementVetoOpposes,
} from "./admission.js";
import { effectiveDisabledStrategies } from "./strategy-gates.js";
import { selectBestEnabled, selectPaperDeskWinnerFromPool } from "./select-best-enabled.js";
import { makeTraceScopedSkip } from "./organs/position-admission.js";
import { computePriceChannel } from "./tick-sensors.js";
import { leftoverHourlyEvaluateMayRun } from "./leftover-hourly-evaluate.js";
import { generateTraceId } from "./decision-trace.js";
import { dailyTargetEntryBlock } from "./daily-target.js";
import { hourlyPoller, type Hourly1HTick } from "./kalshi-1h-poll.js";
import { candlePatternAnalyzer } from "./candlestick-patterns.js";
import { liveOrigLagStreakOnObs } from "./basis-lag-edge.js";
import { computeMarketState } from "./market-state.js";
import { buildBookSnap } from "./liquidity-policy.js";

import { admit15m } from "./organs/admit-15m.js";

import { snapshotLastW2Log } from "./organs/direction-w2.js";
import { hourlyOrPerpEvaluateAllowed } from "./15m-product.js";
// unify: imports for names the funnel referenced but never imported (tsc TS2304)
import { isHarvestSessionFamilyAllowed } from "./settlement-side.js";
import { detectStallInfo, computeVolumeState, realizedVolFromBuffer, probabilityEdge } from "./tick-sensors.js";
import { detectBreakoutFakeout } from "./admission.js";
const KNOWN_GROK_REGIMES = ['trending', 'ranging', 'high_vol', 'low_vol', 'transitioning'] as const;

export async function leftoverHourlyEvaluateFunnel(this: any): Promise<void> {
  if (!leftoverHourlyEvaluateMayRun(this.config)) return;

    // GO — SPECIALIST REGIME SYSTEM Phase 0 (DecisionTrace): one traceId per
    // tick invocation, captured in a local const (not a shared mutable field)
    // so it can never leak across a concurrent 15m-path/hourly-path tick.
    // `skip` is a thin closure wrapper so every logSkippedDecision call made
    // during this invocation carries it automatically.
    const traceId = generateTraceId();
    const skip = makeTraceScopedSkip(this.logSkippedDecision.bind(this), { traceId });
    if (!this.config.enabled)             return;
    if (!this.config.enable1HContracts)   return;
    if (this.openTrade)                   return; // already in a position
    if (this.state !== "WATCHING")        return;
    if (this.prices.length < 4)           return; // need price buffer

    // ── DAILY-LOSS HALT COVERAGE FIX ──────────────────────────────────────────
    // Same precedence as the 15-min path (breakers > profile > target engine):
    // check the loss-cap circuit breaker before the daily-target gates below.
    // This mirrors evaluateEntry()'s own early check — _placeOrderBody also
    // re-checks at admission (covers both paths + any race), but failing
    // closed here too avoids running the rest of this tick's evaluation
    // (strategy selection, pre-trade sim, etc.) once the bot should already
    // be halted, exactly like the 15-min evaluator does.
    if (this.isDailyLossHalted()) {
      this.lastHourlySkipReason = "daily loss cap reached — auto-suspending bot";
      this.log("warn", "🛑 Daily loss cap reached (hourly path) — auto-suspending bot");
      this.suspend();
      return;
    }

    // The 1H path must honor the same daily-target admission gates as the
    // 15-min path — otherwise it can keep trading after a +50% stand-down or
    // during a fail-closed persistence outage (arch critic).
    if (dailyTargetEntryBlock(this.lastDailyTarget, this.dailyTargetLatchDirty, this.dailyTargetLoadFailed)) return;
    if (this.config.useDailyTarget && (!this.dailyTargetDay || this.dailyTargetDay.loading)) return;

    // Live-money admission gate: hourly stays paper-only until explicitly
    // enabled. This is separate from paperMode so taking the 15-min bot live
    // never silently takes the unproven hourly path live with it.
    if (!this.config.paperMode && !this.config.enable1HLive) {
      this.lastHourlySkipReason = "live mode active but hourly live trading not enabled (paper-only)";
      return;
    }

    const currentPrice = this.prices[this.prices.length - 1].price;
    hourlyPoller.setReferencePrice(currentPrice);

    // Freshness circuit: never act on a stale hourly feed (>90s).
    const h1tick: Hourly1HTick | null = hourlyPoller.getFreshLatest();
    if (!h1tick) {
      this.lastHourlySkipReason = hourlyPoller.getSkipReason() ?? "hourly feed absent or stale (>90s)";
      return;
    }

    const { ticker, floorStrike, secsRemaining, yesAsk, noBid, noAsk, yesBid } = h1tick;
    if (secsRemaining <= 0 || !floorStrike) { this.lastHourlySkipReason = "contract expired or missing strike"; return; }
    // Hard settlement cutoff, same rationale as the 15-min path.
    if (secsRemaining < 90) { this.lastHourlySkipReason = "under 90s to hourly close"; return; }
    this.lastHourlySkipReason = null;
    const { isStalling, stallStrength } = detectStallInfo(this.prices);
    const distFromFloorPct = floorStrike > 0 ? ((currentPrice - floorStrike) / floorStrike) * 100 : 0;
    // GO — HYSTERETIC REGIME ENGINE: the 1H poller runs on its own independent
    // ~30s timer, separate from the 15m tick loop that owns updateRegime()
    // (evaluateEntry()/considerAddingToPosition()) — so this path is a
    // READ-ONLY consumer of the single committed R_t, never a second writer.
    // shadowInstantRegime is the old memoryless classifier, kept only for
    // logging/comparison; it never gates anything below.
    const regime = getRegime();
    const shadowInstantRegime = classifyRegimeFromBuffer({
      velocityDolPerMin: this.currentVelocity, threeMinVelocity: this.threeMinVelocity,
      isStalling, stallStrength, distFromFloorPct,
    });
    const mtfScore    = mtfAnalyzer.getScore();
    const volumeState = computeVolumeState(this.prices);
    const { recentlyBrokeLevel, quickReclaim } = detectBreakoutFakeout(this.prices, floorStrike);
    const annualVol   = realizedVolFromBuffer(this.prices);
    const minsLeft    = secsRemaining / 60;
    const { prob }    = probabilityEdge(currentPrice, floorStrike, annualVol, minsLeft);

    const obs: import("./strategy-library.js").StrategyObservation = {
      currentPrice, floorStrike,
      ticker,
      cheapSide15mEnabled: this.config.cheapSide15mEnabled === true, // paper≡live: no paperMode OR-unlock
      cheapEarlyExitEnabled: this.config.cheapEarlyExitEnabled === true,
      panicFadeEnabled: this.config.panicFadeEnabled === true, // paper≡live: no paperMode OR-unlock
      streakSatFadeEnabled: this.config.streakSatFadeEnabled === true,
      // Same NO_QUOTE fix as the 15-min path: yesAsk/noAsk/yesBid/noBid were
      // destructured from h1tick above but never copied into obs, so every
      // 1H strategy reading a live ask (BASIS_LAG_EDGE) always saw undefined.
      yesBid, yesAsk, noBid, noAsk,
      velocityDolPerMin: this.currentVelocity,
      threeMinVelocity:  this.threeMinVelocity,
      isStalling, stallStrength,
      distFromFloorPct,
      massAboveFloor:   prob * 100,
      secsRemaining,
      contractDurationMins: 60,   // ← key gate for OTM_BREAKOUT_EXPANSION
      shortTrend:  this.currentVelocity  >  20 ? 'up' : this.currentVelocity  < -20 ? 'down' : 'sideways',
      mediumTrend: this.threeMinVelocity >  15 ? 'up' : this.threeMinVelocity < -15 ? 'down' : 'sideways',
      regime, mtfScore, volumeState, recentlyBrokeLevel, quickReclaim,
      channelInfo:  computePriceChannel(this.prices) ?? undefined,
      psychLevel:   computePsychLevel(currentPrice, floorStrike),
      candlePattern: candlePatternAnalyzer.getLatest() ?? undefined,
      // ── Cross-exchange BRTI basis / settlement projection ───────────────────
      // Hourly stays DISARMED. If this body still builds an obs, reuse the 15m
      // canonical snapshot — do not rebuild projectSettlementPrice on hourly
      // secsRemaining (that disagrees with getStatus / lastBasisState / 15m desk).
      rollingBasis:      this.lastBasisState?.rollingBasis ?? undefined,
      estimatedFairBRTI: this.lastBasisState?.estimatedFairBRTI ?? undefined,
      /** Operator alias — basis lead USD (not CF BRTI pin). */
      basisLeadUsd: this.lastBasisState?.basisLeadUsd ?? this.lastBasisState?.estimatedFairBRTI ?? undefined,
      projectedSettlementPrice: this.lastBasisState?.projectedSettlementPrice ?? undefined,
      basisShort:         this.lastBasisState?.shortBasis ?? undefined,
      basisExchangePrice: this.lastBasisState?.exchangePrice ?? undefined,
      basisProxyPrice:    this.lastBasisState?.brtiProxy ?? undefined,
      // fairDistFromFloorPct: additive only, gated on the new staleness guard.
      // Not read by any strategy yet — see StrategyObservation's field comment.
      fairDistFromFloorPct: (!basisTracker.isFairValueStale() && this.lastBasisState?.estimatedFairBRTI != null && floorStrike > 0)
        ? ((this.lastBasisState.estimatedFairBRTI - floorStrike) / floorStrike) * 100
        : undefined,
      basisStreakCount: liveOrigLagStreakOnObs({
        analog: this.origLagProjStreak,
        lagDollars: this.lastBasisState?.lagDollars,
        lagStale: this.lastBasisState?.lagStale,
      }).basisStreakCount,
      basisStreakSign: liveOrigLagStreakOnObs({
        analog: this.origLagProjStreak,
        lagDollars: this.lastBasisState?.lagDollars,
        lagStale: this.lastBasisState?.lagStale,
      }).basisStreakSign,
      lagSeconds:         this.lastBasisState?.lagSeconds ?? null,
      lagDollars:         this.lastBasisState?.lagDollars ?? null,
      lagCorr:            this.lastBasisState?.lagCorr ?? null,
      lagStale:           this.lastBasisState?.lagStale ?? true,
      lagReason:          this.lastBasisState?.lagReason,
      lagResidualDollars: this.lastBasisState?.lagResidualDollars ?? null,
      leaderName:         this.lastBasisState?.leaderName ?? null,
      leadSeconds:        this.lastBasisState?.leadSeconds ?? null,
      leadDollars:        this.lastBasisState?.leadDollars ?? null,
      proofHitRate:       this.lastBasisState?.proofHitRate ?? null,
      lagProven:          this.lastBasisState?.lagProven === true,
      paperMode:          this.config.paperMode === true,
    };

    // P4 LIQUIDITY POLICY: per-side book snapshots for BASIS_LAG_EDGE's
    // Part C net-edge carve-out (the general haircut/skip for every other
    // strategy applies downstream in _placeOrderBody, not here).
    {
      const ob = kalshiWS.getLatestOrderbook();
      obs.liquidityBook = {
        YES: buildBookSnap({ side: 'YES', currentTicker: ticker, quote: { yesBid, yesAsk, noBid, noAsk }, latestOrderbook: ob }),
        NO:  buildBookSnap({ side: 'NO',  currentTicker: ticker, quote: { yesBid, yesAsk, noBid, noAsk }, latestOrderbook: ob }),
      };
    }

    // P3 MARKETSTATE: local hourly scales only. 15m tick owns lastMarketState
    // (periodSecs 15*60). Writing 60-min tau here poisons getStatus / ARIA.
    {
      const ms = computeMarketState({
        velocityHistory: this.velocityHistory, velocityEma: this.velocityEma,
        obs, periodSecs: 60 * 60,
      });
      obs.velScale = ms.velScale; obs.zVel = ms.zVel; obs.rangeScale = ms.rangeScale;
      obs.volScale = ms.volScale; obs.marketStale = ms.stale;
    }

    // ── Unified strategy selection (same controls as the 15-min path) ────────
    // Honors strategyOverride, the user's disabledStrategies toggle, the
    // performance quarantine list, and the Grok-regime allowlist — previously
    // the hourly path bypassed all four and could fire a disabled or
    // quarantined strategy.
    // GO PRODUCTION QUALITY 8.0→8.5 Step B: hourlyDisabled (user config +
    // duration-scoped DB quarantine) is hoisted above the evaluate call
    // — previously computed further below at line ~2847 and only applied
    // downstream via selectBestEnabled — so it can also be passed into the
    // shared enumeration function and a disabled strategy's evaluate() is
    // never invoked at all for the 1h path, not evaluated-then-filtered.
    const hourlyDisabled = [
      ...effectiveDisabledStrategies(this.config),
      // Duration-scoped (1H): a strategy quarantined only on 15m still trades 1h.
      ...getDbDisabledStrategies(60),
    ];
    const hourlyEval: ReturnType<typeof evaluateAllStrategies> = this.evaluateStrategiesForBot(obs, hourlyDisabled);
    const { all: hourlyResults } = hourlyEval;
    // READ-ONLY: derived from the shared committed R_t (see comment above at
    // the `regime`/shadowInstantRegime assignment) rather than an independent
    // detectGrokRegime() recompute, so this path can never disagree with the
    // 15m path about which market regime is currently active.
    const hourlyGrokRegime = getGrokRegimeFromDetailed(regime as RegimeId);
    const shadowInstantHourlyGrokRegime = detectGrokRegime(obs, computePriceChannel(this.prices) ?? null);
    if (shadowInstantHourlyGrokRegime !== hourlyGrokRegime) {
      this.log("info", `[regime] 1H shadow instant grokRegime disagrees with committed: shadow=${shadowInstantHourlyGrokRegime} committed=${hourlyGrokRegime}`);
    }
    if (shadowInstantRegime !== regime) {
      this.log("info", `[regime] 1H shadow instant classifier disagrees with committed R_t: shadow=${shadowInstantRegime} committed=${regime}`);
    }
    this.warnIfDisabledStrategyOverride("1h");
    const overridePool = this.config.strategyOverride
      ? hourlyResults.filter(r => r.strategyId === this.config.strategyOverride)
      : hourlyResults;
    // Duration gate (Priority 2): only strategies deliberately allowlisted for
    // the 1-hour contract may fire on this 60-min tick. Previously EVERY
    // strategy could fire here with 15m-tuned, minutes-to-expiry logic.
    const hourlyDurationPool = overridePool.filter(r => isStrategyAllowedForDuration(r.strategyId, 60));
    let hourlyRegimePool = hourlyDurationPool.filter(r => isStrategyAllowedInRegime(r.strategyId, hourlyGrokRegime));
    if (hourlyRegimePool.length === 0 && hourlyDurationPool.some(r => r.signal !== 'STAY_OUT')) {
      // Never let the regime allowlist fully silence 1H trading when
      // duration-valid signals exist; downstream gates still apply.
      this.log("info", `[1h] regime allowlist [${hourlyGrokRegime}] left 0 strategies — falling back to duration-valid pool`);
      hourlyRegimePool = hourlyDurationPool;
    }
    // Task #278: same strong-trend direction lock as the 15m path.
    const hourlyTrendFilteredPool = applyStrongMTFDirectionLock(
      hourlyRegimePool,
      mtfAnalyzer.getScore(),
      this.config.useStrongMTFDirectionLock,
      msg => this.log("info", msg),
      { yesAsk, noAsk, spot: currentPrice, floorStrike },
    );

    // ── Hunt vs Harvest session mode (master bot upgrade step 3) ─────────────
    // Same rule as the 15m path — see the comment there. MTF_ALIGNED and the
    // late-displacement/basis-lag strategies are duration-allowlisted for 1H
    // too, so the same restriction applies here.
    const hourlySessionMode: SessionMode = getCurrentSessionMode();
    this.lastSessionMode = hourlySessionMode;
    if (this.lastLoggedSessionMode !== hourlySessionMode) {
      this.log("info", `[session] mode=${hourlySessionMode} (1h tick, utcHour=${new Date().getUTCHours()}, utcDay=${new Date().getUTCDay()})`);
      this.lastLoggedSessionMode = hourlySessionMode;
    }
    const isHourlyHarvestFamily = (strategyId: StrategyId): boolean =>
      isHarvestSessionFamilyAllowed(this.config.paperMode, strategyId);
    if (hourlySessionMode === 'HARVEST') {
      for (const r of hourlyTrendFilteredPool) {
        if (!isHourlyHarvestFamily(r.strategyId)) {
          skip("SESSION_FAMILY_SUPPRESSED", [
            `[1h][HARVEST] ${r.strategyId} (family=${getStrategyFamily(r.strategyId) ?? 'unknown'}) suppressed — only basis-lag/late-displacement trade during Asia/Sunday/dead hours`,
          ], {
            ticker, side: r.signal === 'YES' ? 'yes' : 'no', strategyId: r.strategyId,
            entryPriceCents: r.signal === 'YES' ? yesAsk : noAsk,
            confidence: Math.round(r.confidence * 100), secsRemaining, floorStrike,
          });
        }
      }
    }
    const hourlySessionFilteredPool = hourlySessionMode === 'HARVEST'
      ? hourlyTrendFilteredPool.filter(r => isHourlyHarvestFamily(r.strategyId))
      : hourlyTrendFilteredPool;

    // hourlyDisabled is now hoisted above the evaluateAllStrategies() call
    // above (GO PRODUCTION QUALITY 8.0→8.5 Step B) — reused here unchanged.
    // ── Manual-disable visibility (master bot upgrade step 1A) ───────────────
    // Same rationale as the 15m path: surface a config-level manual disable
    // (e.g. MTF_ALIGNED, which is duration-allowlisted for 1H too) under its
    // own code instead of it disappearing into the merged hourlyDisabled set.
    const hourlyManualDisabledSet = new Set(effectiveDisabledStrategies(this.config));
    for (const r of hourlySessionFilteredPool) {
      if (hourlyManualDisabledSet.has(r.strategyId)) {
        skip("STRATEGY_MANUAL_DISABLE", [`[1h] ${r.strategyId} manually disabled via config — signal ignored`], {
          ticker, side: r.signal === 'YES' ? 'yes' : 'no', strategyId: r.strategyId,
          entryPriceCents: r.signal === 'YES' ? yesAsk : noAsk,
          confidence: Math.round(r.confidence * 100), secsRemaining, floorStrike,
        });
      }
    }
    let best = selectBestEnabled(hourlySessionFilteredPool, hourlyDisabled);
    // admit15m owns aligned → overlay → W2 → card → W2 overlay (same as 15m).
    // recoverPool [] — hourly historically had no SELECT_MISS reinject (behavior-identical).
    const hourlyW2LagSide = meterLagSideForW2({
      lagProven: obs.lagProven === true,
      lagStale: this.lastBasisState?.lagStale ?? true,
      lagDollars: this.lastBasisState?.lagDollars ?? obs.lagDollars ?? null,
    });
    // Hourly W2 identity pin: same fresh CF Benchmarks BRTI as 15m (fail-closed if missing).
    // Never invent estimatedFairBRTI / book proxy into brtiPx.
    const hourlyBrtiPx = kalshiWS.getFreshBrtiUsd(2_500);
    const hourlyAdmit = admit15m({
      aligned: {
        mtfSign: mtfAnalyzer.getScore(),
        yesAsk,
        noAsk,
        lagProven: obs.lagProven === true,
        quoteStale: false,
        secsRemaining,
        spot: currentPrice,
        floorStrike,
        winRateAtPrice: bindSideWinRateAtPrice({
          yesAsk,
          noAsk,
          minutesLeft: secsRemaining / 60,
          curveFor: (strategyId) => {
            const id = strategyId === "BASIS_LAG_EDGE" ? "BASIS_LAG_EDGE" : "CONFLUENCE_CASCADE";
            const meta = getAllStrategyMeta().find(s => s.id === id);
            return meta?.winRateAtPrice ?? null;
          },
        }),
      },
      stratResult: best,
      selectionPool: hourlySessionFilteredPool,
      recoverPool: [],
      w2: {
        lagSide: hourlyW2LagSide,
        ohlc1m: getMtfOhlcBars(1)?.bars,
        ohlc5m: getMtfOhlcBars(5)?.bars,
        analog15mBars: getMtfOhlcBars(15)?.bars,
        ohlc4h: getMtfOhlcBars(240)?.bars,
        ohlc15m: getMtfOhlcBars(15)?.bars,
        spot: currentPrice,
        floorStrike,
        strike: floorStrike,
        projectedSettlement: obs.projectedSettlementPrice,
        lagProven: obs.lagProven === true,
        lagStale: this.lastBasisState?.lagStale ?? true,
        orderbookImbalance: obs.orderbookImbalance,
        brtiPx: hourlyBrtiPx,
        brtiDefined: hourlyBrtiPx != null,
        venue2Live: false,
        deltaSign: null,
      },
      moneyGate: {
        // unify: these locals never existed here (TS2304 → ReferenceError if reached)
        lagProven: obs.lagProven === true,
        lagStale: this.lastBasisState?.lagStale ?? true,
        lagReason: (this.lastBasisState as { lagReason?: string | null } | null | undefined)?.lagReason ?? obs.lagReason ?? null,
        sessionMode: hourlySessionMode,
        sessionClockLabel: sessionClockLabel(new Date().getUTCHours()),
        velocityDolPerMin: obs.velocityDolPerMin ?? this.currentVelocity,
        quoteAgeMs: (() => {
          const qTs = kalshiWS.getLatest()?.quoteTs;
          return typeof qTs === "number" && qTs > 0 ? Date.now() - qTs : null;
        })(),
      },
    });
    const hourlyAlignedGate = hourlyAdmit.alignedGate;
    const hourlyW2Lock = hourlyAdmit.w2Lock;
    best = hourlyAdmit.stratResult;
    if (hourlyAlignedGate.kind === "TAKE" && hourlyAlignedGate.constructedNo === true) {
      this.log("info", formatConstructedNoLog({ p: hourlyAlignedGate.p, ask: hourlyAlignedGate.ask }));
    }
    {
      const w2Emit = shouldEmitDirectionW2Log(hourlyW2Lock.log, this.w2LogThrottle);
      if (w2Emit.emit) this.log("info", formatDirectionW2Log(hourlyW2Lock.log) + w2Emit.suppressedSuffix);
    }
    this.lastW2Log = snapshotLastW2Log(hourlyW2Lock.log);
    this.lastMoneyGateCard = hourlyAdmit.moneyGateCard;
    if (!best || best.signal === 'STAY_OUT') {
      if (hourlyResults.some(r => r.signal !== 'STAY_OUT')) {
        this.lastHourlySkipReason = "signal present but blocked by strategy enable/quarantine/regime gates";
      }
      return;
    }

    const isLong  = best.signal === 'YES';
    const side    = isLong ? 'yes' : 'no';
    const rawAsk  = isLong ? yesAsk : noAsk;
    const rawBid  = isLong ? yesBid : noBid;
    const hourlySpread = rawAsk - rawBid;
    const isOTMBreakout = best.strategyId === 'OTM_BREAKOUT_EXPANSION';

    // Profit Doctrine P1 (2026-08-26): the 15m path always prices its
    // executable ask at rawAsk + sweep (see SWEEP_PREMIUM / entryPrice above
    // in evaluateEntry()) because a limit order sitting exactly at the
    // top-of-book ask has no book depth to actually cross and can sit
    // unfilled (same rationale as the 15m comment on SWEEP_PREMIUM). The
    // hourly path used to skip this and pass the bare `rawAsk` straight into
    // winRateAtPrice/computeTradeEV/placeOrder, which both under-priced the
    // fill it would actually get AND violated P1's "single computeTradeEV on
    // the executable (post-sweep) ask" rule relative to the 15m path. OTM
    // Breakout keeps its research-backed sweet-spot ask unswept, same as the
    // 15m OTM exemption, since its edge is defined at that exact price band.
    const hourlySweep = isOTMBreakout ? 0 : 1;
    const entryPrice  = rawAsk + hourlySweep;

    // Fill-power still-mid HARD on executable hourly limit (ask+sweep).
    if (!isOTMBreakout && inStillMidCoinFlip(entryPrice)) {
      const msg = `[1h] ${best.strategyId}: fill ${entryPrice}¢ still-mid 48–52 (rawAsk ${rawAsk}¢) — skip`;
      this.lastHourlySkipReason = msg;
      this.log("info", msg);
      skip(STILL_MID_UNCLEAR_SKIP, [msg], {
        ticker, side, strategyId: best.strategyId, entryPriceCents: entryPrice,
        confidence: Math.round(best.confidence * 100), secsRemaining, floorStrike,
      });
      return;
    }

    // ── Entry price gates ─────────────────────────────────────────────────────
    // Same shared resolver as the 15-min path and both backtest engines
    // (Task #368) — OTM Breakout keeps its research-backed 11–38¢ sweet spot;
    // every other hourly strategy gets the generic 15–85¢ hourly band.
    const hourlyBand = getEntryPriceBand(best.strategyId, { contractDurationMins: 60 });
    if (rawAsk < hourlyBand.min || rawAsk > hourlyBand.max) {
      this.log("info", `[1h] ${best.strategyId}: ask ${rawAsk}¢ outside ${hourlyBand.min}–${hourlyBand.max}¢ band — skip`);
      // Task #315: the hourly path had its own blind spot in the meta-labeling
      // skip corpus — every 15m-path early return logs via logSkippedDecision
      // (which feeds recordSkippedMetaExample), but this 1H-only gate never
      // did, so hourly near-miss training examples were silently uncollected.
      skip("ENTRY_PRICE_BAND", [`[1h] ask ${rawAsk}¢ outside ${hourlyBand.min}-${hourlyBand.max}¢`], {
        ticker, side, strategyId: best.strategyId, entryPriceCents: rawAsk,
        confidence: Math.round(best.confidence * 100), secsRemaining, floorStrike,
      });
      return;
    }

    // ── HARVEST stricter ask ceiling (master bot upgrade step 3) ─────────────
    // Only lag/anchor strategies can even reach this point during HARVEST
    // (family filter above already excluded everything else), and those are
    // exactly PRICE_BAND_LATE_EXCEPTION_STRATEGIES — so the ceiling reuses the
    // same extreme-displacement + <=5min-left exception already defined for
    // the universal price band, rather than inventing a second concept.
    if (hourlySessionMode === 'HARVEST' && rawAsk > HARVEST_ASK_MAX_CENTS
        && !paperMoneyMakerHarvestExempt(this.config.paperMode, best.strategyId)) {
      const hourlyHasExtremeDisplacement = Math.abs(distFromFloorPct) >= PRICE_BAND_EXTREME_DISPLACEMENT_PCT;
      const hourlyLateException = PRICE_BAND_LATE_EXCEPTION_STRATEGIES.has(best.strategyId)
        && hourlyHasExtremeDisplacement && minsLeft <= PRICE_BAND_LATE_MAX_MINS_LEFT;
      if (!hourlyLateException) {
        const msg = `[1h][HARVEST] ask ${rawAsk}¢ > ${HARVEST_ASK_MAX_CENTS}¢ HARVEST ceiling — skip`;
        this.lastHourlySkipReason = msg;
        this.log("info", msg);
        skip("HARVEST_PRICE_BAND", [msg], {
          ticker, side, strategyId: best.strategyId, entryPriceCents: rawAsk,
          confidence: Math.round(best.confidence * 100), secsRemaining, floorStrike,
        });
        return;
      }
    }

    // Apply the 1H-bucket learning weight + online-adapter conf multiplier
    // (same soft-confidence adaptation as the 15m path, but keyed to the 1H
    // realized stats so a strategy's 15m form never steers its 1h sizing).
    const hourlyLw = getBotFillLearningWeights(60)[best.strategyId] ?? 1.0;
    const hourlyPerfConf = getStrategyMultipliersSync(best.strategyId).conf;
    const conf       = Math.min(0.94, best.confidence * hourlyLw * hourlyPerfConf);
    const stratMeta  = getAllStrategyMeta().find(s => s.id === best.strategyId);
    // Same win-rate resolution as the 15-min path (trading-bot.ts ~4494):
    // price/time-conditioned winRateAtPrice() when the strategy defines one,
    // else its flat expectedWinRate. Previously this always used the flat
    // number even for strategies with no duration guard in evaluate() (e.g.
    // LATE_ENTRY_ANCHOR, FLOOR_DISTANCE, EXHAUSTION_ANCHOR, LATE_MOMENTUM_
    // CONTINUATION) that can fire on this 60-min tick, so hourly sizing and
    // EV checks on those strategies silently ignored their calibrated curve.
    const stratWR    = stratMeta?.winRateAtPrice
      ? stratMeta.winRateAtPrice(entryPrice, secsRemaining / 60)
      : stratMeta?.expectedWinRate ?? 0.65;
    const signal: "LONG" | "SHORT" = isLong ? "LONG" : "SHORT";
    // Library confidence is 0–1; placeOrder and every downstream gate expect an
    // integer 0–100 (same scale conversion as the 15-min path).
    let confPct = Math.round(conf * 94);
    // Realized-outcome confidence calibration — DISABLED (see flag decl at top
    // of file). Same invalid global-arrow-accuracy correction as the 15m path;
    // it must not move money. Computed and logged for data accumulation only.
    {
      const cal = predictionLearner.getConfidenceCorrection(confPct / 100);
      if (cal.applied) {
        const wouldBe = Math.max(0, Math.min(100, Math.round(cal.corrected * 100)));
        this.log("info",
          `🎯 [1h] [calibration DISABLED] would adjust ${confPct}% → ${wouldBe}% ` +
          `(${(cal.adjust * 100).toFixed(1)}pts) · ${best.strategyName ?? best.strategyId} · ` +
          `NOT applied (CONFIDENCE_CALIBRATION_ENABLED=false)`);
      }
      if (CONFIDENCE_CALIBRATION_ENABLED && cal.applied) {
        confPct = Math.max(0, Math.min(100, Math.round(cal.corrected * 100)));
      }
    }

    this.log("signal",
      `🕐 1H SIGNAL · ${best.strategyName ?? best.strategyId} · ${signal} · conf ${confPct}% · ` +
      `${ticker} · ask ${rawAsk}¢ · ${Math.round(minsLeft)}m left · ${best.reason}`
    );

    // ── Shared admission gates (same pipeline as the 15-min path) ────────────
    // Regime-EV filter, protect-mode A+ bar, hard entry filters, EV floor, and
    // the fail-closed pre-trade simulation all run before any hourly order.
    const admission = await this.runSharedAdmissionGates({
      obs, stratResult: best, signal, entryPrice, conf: confPct,
      secs: secsRemaining, grokRegime: hourlyGrokRegime, regime,
      // Task #397: same calibrated winRateAtPrice/expectedWinRate number
      // passed to placeOrder below (stratWR), so the EV floor gate inside
      // runSharedAdmissionGates and placeOrder's own EV gates agree.
      strategyWinRate: stratWR,
      // CONSENSUS MEASUREMENT PURITY: same disabled set already passed to this
      // 1h tick's own evaluateAllStrategies() selection call above — disabled
      // strategies must not affect the pre-trade sim's CONSENSUS check either.
      disabledIds: hourlyDisabled,
    });
    if (!admission.ok) {
      this.lastHourlySkipReason = admission.reason;
      this.log("info", `[1h] ${best.strategyId}: ${admission.reason} — skip`);
      // Task #315: same hourly-path meta-labeling gap fix as the entry-band
      // gate above — this shared-admission-gate rejection previously never
      // reached recordSkippedMetaExample either.
      // Profit Doctrine Phase 3: runSharedAdmissionGates' {ok:false} result
      // carries no numeric EV — recompute the same fee/slippage-aware cents
      // figure independently for decision_traces.ev_cents (observability
      // only; does not affect the admission decision already made above).
      const hourlyPathGateNetEV = computeTradeEV({
        entryPriceCents:    entryPrice,
        winRate:            stratWR,
        secsRemaining,
        velocityDolPerMin:  obs.velocityDolPerMin,
      }).netEV;
      const hourlyPathGateVol = computeVolumeScore(obs);
      skip("PATH_GATE", [`[1h] ${admission.reason}`], {
        ticker, side, strategyId: best.strategyId, entryPriceCents: entryPrice,
        confidence: confPct, secsRemaining, floorStrike,
        pWin: stratWR,
        netEVcents: hourlyPathGateNetEV,
        volumeScoreV: hourlyPathGateVol.V, volumeBucket: hourlyPathGateVol.bucket,
      });
      return;
    }

    // ── RICH_ASK_BLOCK (Master Desk Order P3, S4) ─────────────────────────────
    // Previously 15m-only (H2 requires this on EVERY live path). Uses the
    // exact same shared evaluateRichAskBlock() the 15m path now calls too —
    // one implementation, so this can never silently drift between paths.
    const hourlyRichAsk = evaluateRichAskBlock({
      askCents:          entryPrice,
      side,
      strategyId:        best.strategyId,
      entryPriceCents:   entryPrice,
      secsRemaining,
      winRate:           stratWR,
      velocityDolPerMin: obs.velocityDolPerMin,
      spreadCents:       hourlySpread,
      projectedSettlementPrice: obs.projectedSettlementPrice ?? null,
      basisStreakCount:  obs.basisStreakCount,
      basisStreakSign:   obs.basisStreakSign,
    });
    if (hourlyRichAsk.blocked) {
      const msg = `[1h] ${hourlyRichAsk.reason}`;
      this.lastHourlySkipReason = msg;
      this.log("info", msg);
      skip("RICH_ASK_BLOCK", [msg], {
        ticker, side, strategyId: best.strategyId, entryPriceCents: entryPrice,
        confidence: confPct, secsRemaining, floorStrike,
        netEVcents: hourlyRichAsk.netEV,
      });
      return;
    }

    // ── PATH_GATE (Master Desk Order P3, S5) ──────────────────────────────────
    // Previously 15m-only. Same evaluatePathDecision() call the 15m path uses
    // (contractDurationMins: 60 here) — score gate + credible-interval EV gate
    // now apply uniformly to every live entry, not just 15m contracts.
    const timeOfDayRegime = getTimeOfDayRegime();
    const hourlyPathDecision = evaluatePathDecision({
      entryPriceCents:      entryPrice,
      regime,
      velocityDolPerMin:    obs.velocityDolPerMin ?? 0,
      threeMinVelocity:     obs.threeMinVelocity  ?? 0,
      isStalling:           obs.isStalling         ?? false,
      volumeState:          obs.volumeState,
      velocityAccel:        obs.velocityAccel,
      distFromFloorPct:     obs.distFromFloorPct,
      secsRemaining,
      contractDurationMins: 60,
      preTradeScore:        admission.verdict.overallScore,
      estimatedWinRate:     stratWR,
      historicalN:          admission.verdict.historicalSampleSize,
      mode:                 admission.modeState,
      spreadCents:          hourlySpread,
      timeOfDayRegime,
    });
    if (!hourlyPathDecision.allowed) {
      this.lastHourlySkipReason = `[1h] ${hourlyPathDecision.reason}`;
      admission.verdict.blockedAfterApproval = `Path gate [${hourlyPathDecision.path}/${admission.modeState.riskProfile}]: ${hourlyPathDecision.reason}`;
      this.log("info", `[1h] 🛤️ Path gate [${hourlyPathDecision.path}] BLOCKED: ${hourlyPathDecision.reason}`);
      const hourlyPathGateNetEV2 = computeTradeEV({
        entryPriceCents:    entryPrice,
        winRate:            stratWR,
        secsRemaining,
        velocityDolPerMin:  obs.velocityDolPerMin,
        spreadCents:        hourlySpread,
      }).netEV;
      const hourlyPathGateVol2 = computeVolumeScore(obs);
      skip("PATH_GATE", [`[1h] ${hourlyPathDecision.reason}`], {
        ticker, side, strategyId: best.strategyId, entryPriceCents: entryPrice,
        confidence: confPct, secsRemaining, floorStrike,
        pWin: stratWR,
        netEVcents: hourlyPathGateNetEV2,
        volumeScoreV: hourlyPathGateVol2.V, volumeBucket: hourlyPathGateVol2.bucket,
      });
      return;
    }

    // GO — VOLUME AS RISK SCALAR (2026-08-18): same score/bucket/mult as the
    // 15m path (evaluateEntry), computed here since the 1h path doesn't share
    // that function's scope. `obs` above is already this tick's shared
    // observation, computed identically for both paths.
    const hourlyVolScore = computeVolumeScore(obs);
    const hourlyVolumeSizeMult = getVolumeSizeMult(best.strategyId, hourlyVolScore.bucket);

    await this.placeOrder({
      signal, side, entryPrice, floorStrike, ticker,
      confidence: confPct, secs: secsRemaining,
      strategyWinRate: stratWR, strategyId: best.strategyId,
      grokRegime: hourlyGrokRegime, detailedRegime: regime,
      isOTMExpansion: isOTMBreakout,   // 45% size reduction for the OTM specialist
      edgePct: best.edgePct,
      contractDurationMins: 60,
      closeTimeMs: h1tick.closeTime ? new Date(h1tick.closeTime).getTime() : Date.now() + secsRemaining * 1000,
      conditionMaxContracts: this.config.hourlyMaxContracts,
      modeState: admission.modeState,
      timeOfDayRegime,
      velocityDolPerMin: obs.velocityDolPerMin,
      spreadCents: hourlySpread,
      decisionAskCents: rawAsk,
      traceId,
      verdict: admission.verdict,
      entryBandMin: hourlyBand.min,
      entryBandMax: hourlyBand.max,
      volumeSizeMult: hourlyVolumeSizeMult,
      volumeBucket: hourlyVolScore.bucket,
      volumeScoreV: hourlyVolScore.V,
    });
  
}
