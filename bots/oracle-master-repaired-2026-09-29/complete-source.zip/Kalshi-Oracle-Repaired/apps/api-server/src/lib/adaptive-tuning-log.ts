/**
 * adaptive-tuning-log.ts
 *
 * Phase 1 of the adaptive control plan (artifacts/api-server/docs/
 * adaptive-control-plan.md): pure observability, zero behavior change.
 *
 * Call `adaptiveTuningLog.recordChange(...)` from the existing (pre-refactor)
 * writers — autoMode, ARIA/expert-agent, condition-adapter, online-adapter —
 * every time they set a value for a tracked parameter, whether or not the
 * value actually changed. This module does the diff/coalesce work so call
 * sites don't have to: it is a no-op unless the value differs from what was
 * last recorded, and it collapses repeated same-direction changes to the
 * same parameter within COALESCE_WINDOW_MS into a single row (repeatCount++)
 * instead of one row per tick.
 *
 * This lets us capture a baseline of *today's* overlapping/duplicated writer
 * behavior (e.g. autoMode and condition-adapter both computing minConfidence)
 * before the ownership refactor in later phases, so the before/after can be
 * compared from real logged data rather than reasoning about it in the
 * abstract.
 */

import { db, adaptiveTuningLog as adaptiveTuningLogTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

export type AdaptiveOwner =
  | "autoMode"
  | "autoMode(composer)"
  | "ARIA"
  | "condition-adapter"
  | "online-adapter";

export type AdaptiveRole = "baseline" | "tighten-only-overlay" | "would_suppress" | "would_apply";

export type AdaptiveSignal =
  | "regime"
  | "session"
  | "wilson"
  | "basis"
  | "velocity"
  | "technical";

export interface AdaptiveChangeInput {
  parameter: string;
  owner: AdaptiveOwner;
  role: AdaptiveRole;
  /** The value being set this tick. Numbers/booleans are stringified for storage. */
  newValue: number | string | boolean;
  /** [min, max] if the knob has a fixed band; omit for unbounded/enum knobs. */
  band?: [number, number];
  signal: AdaptiveSignal;
  /** Human-readable snapshot of the market/bot state driving this value. */
  condition?: string;
  reason: string;
  tickId?: string;
}

const COALESCE_WINDOW_MS = 60_000;
/** Soft PG circuit: after failures, skip DB for this long (ms) and warn at most once per window. */
const PG_DEGRADED_TTL_MS = 60_000;

function toStoredValue(v: number | string | boolean): string {
  return typeof v === "number" ? String(v) : typeof v === "boolean" ? String(v) : v;
}

function directionOf(oldV: string, newV: string): "up" | "down" | "other" {
  const oldN = Number(oldV);
  const newN = Number(newV);
  if (Number.isFinite(oldN) && Number.isFinite(newN)) {
    if (newN > oldN) return "up";
    if (newN < oldN) return "down";
  }
  return "other";
}

// ── Repository interface — isolates the store from Drizzle for testability ──

export interface AdaptiveTuningLogRepo {
  insertRow(row: {
    parameter: string; owner: string; role: string;
    oldValue: string | null; newValue: string; band: string | null;
    signal: string; condition: string | null; reason: string;
    tickId: string | null; occurredAt: Date; lastRepeatAt: Date;
  }): Promise<{ id: number }>;
  updateRepeat(id: number, newValue: string, reason: string, lastRepeatAt: Date): Promise<void>;
  findLatestForParameter(parameter: string): Promise<{
    id: number; newValue: string; lastRepeatAt: Date;
  } | undefined>;
}

const drizzleRepo: AdaptiveTuningLogRepo = {
  async insertRow(row) {
    const [inserted] = await db
      .insert(adaptiveTuningLogTable)
      .values(row)
      .returning({ id: adaptiveTuningLogTable.id });
    return inserted;
  },
  async updateRepeat(id, newValue, reason, lastRepeatAt) {
    await db
      .update(adaptiveTuningLogTable)
      .set({
        newValue,
        reason,
        lastRepeatAt,
        repeatCount: undefined, // set via sql below
      } as never)
      .where(eq(adaptiveTuningLogTable.id, id));
    // repeatCount++ needs a raw increment — done separately to keep the
    // typed `.set()` call above simple and avoid a redundant read.
    await db.execute(
      /* sql */ `update adaptive_tuning_log set repeat_count = repeat_count + 1 where id = ${id}`,
    );
  },
  async findLatestForParameter(parameter) {
    const rows = await db
      .select({
        id: adaptiveTuningLogTable.id,
        newValue: adaptiveTuningLogTable.newValue,
        lastRepeatAt: adaptiveTuningLogTable.lastRepeatAt,
      })
      .from(adaptiveTuningLogTable)
      .where(eq(adaptiveTuningLogTable.parameter, parameter))
      .orderBy(desc(adaptiveTuningLogTable.id))
      .limit(1);
    return rows[0] ?? undefined;
  },
};

// ── In-memory last-known-value cache ────────────────────────────────────────
//
// Avoids a DB read on every recordChange() call (this runs on the trading
// tick, every 500ms-3s). Seeded lazily from the DB the first time a given
// parameter is seen after a process restart, so a restart can at most cause
// one redundant row per parameter, never a lost row.

interface CacheEntry {
  value: string;
  rowId: number;
  lastRepeatAt: number; // epoch ms
  direction: "up" | "down" | "other";
}

class AdaptiveTuningLogStore {
  private pgDegradedUntil = 0;
  private pgDegradedWarnedAt = 0;

  private cache = new Map<string, CacheEntry>();
  private seeding = new Map<string, Promise<void>>();
  // Per-parameter serialization queue. Two owners (e.g. the autoMode
  // composer and condition-adapter) routinely log the SAME parameter name
  // with the SAME value in the same tick, fired concurrently via
  // `void Promise.all(...)`. Without this, both calls can read the cache
  // before either writes it back, each conclude "changed, insert", and
  // produce a near-duplicate row. Chaining every call for a given parameter
  // onto the previous one serializes them so the second call always sees
  // the first's cache update.
  private queues = new Map<string, Promise<void>>();
  private readonly repo: AdaptiveTuningLogRepo;

  constructor(repo: AdaptiveTuningLogRepo = drizzleRepo) {
    this.repo = repo;
  }

  /**
   * Record a value the given owner set for `parameter` this tick. No-op if
   * unchanged from the last recorded value. Coalesces repeated
   * same-direction changes within COALESCE_WINDOW_MS into one row.
   */
  async recordChange(input: AdaptiveChangeInput): Promise<void> {
    const prior = this.queues.get(input.parameter) ?? Promise.resolve();
    const next = prior
      .catch(() => {}) // a prior failure must not permanently jam this parameter's queue
      .then(() => this.recordChangeSerialized(input));
    this.queues.set(input.parameter, next);
    return next;
  }

  private markPgDegraded(msg: string, where: string): void {
    const now = Date.now();
    this.pgDegradedUntil = now + PG_DEGRADED_TTL_MS;
    if (now - this.pgDegradedWarnedAt >= PG_DEGRADED_TTL_MS) {
      this.pgDegradedWarnedAt = now;
      console.warn(`[adaptive-tuning-log] ${where} failed (PG soft-degraded ${PG_DEGRADED_TTL_MS / 1000}s):`, msg);
    }
  }

  private async recordChangeSerialized(input: AdaptiveChangeInput): Promise<void> {
    if (Date.now() < this.pgDegradedUntil) return; // soft PG — do not spam select/insert
    const newValue = toStoredValue(input.newValue);

    if (!this.cache.has(input.parameter)) {
      await this.seedFromDb(input.parameter);
    }

    const cached = this.cache.get(input.parameter);
    if (cached && cached.value === newValue) return; // unchanged — nothing to log

    const now = Date.now();
    const direction = cached ? directionOf(cached.value, newValue) : "other";
    const withinWindow = cached && now - cached.lastRepeatAt <= COALESCE_WINDOW_MS;
    const sameDirection = cached && direction === cached.direction && direction !== "other";

    try {
      if (cached && withinWindow && sameDirection) {
        await this.repo.updateRepeat(cached.rowId, newValue, input.reason, new Date(now));
        this.cache.set(input.parameter, { value: newValue, rowId: cached.rowId, lastRepeatAt: now, direction });
      } else {
        const row = await this.repo.insertRow({
          parameter: input.parameter,
          owner: input.owner,
          role: input.role,
          oldValue: cached?.value ?? null,
          newValue,
          band: input.band ? JSON.stringify(input.band) : null,
          signal: input.signal,
          condition: input.condition ?? null,
          reason: input.reason,
          tickId: input.tickId ?? null,
          occurredAt: new Date(now),
          lastRepeatAt: new Date(now),
        });
        this.cache.set(input.parameter, { value: newValue, rowId: row.id, lastRepeatAt: now, direction });
      }
    } catch (err) {
      // Observability must never take down the trading loop.
      this.markPgDegraded((err as Error).message ?? String(err), `recordChange(${input.parameter})`);
    }
  }

  private async seedFromDb(parameter: string): Promise<void> {
    if (Date.now() < this.pgDegradedUntil) return; // soft PG circuit
    // Coalesce concurrent seed attempts for the same parameter into one query.
    const inFlight = this.seeding.get(parameter);
    if (inFlight) return inFlight;

    const promise = (async () => {
      try {
        const latest = await this.repo.findLatestForParameter(parameter);
        if (latest) {
          this.cache.set(parameter, {
            value: latest.newValue,
            rowId: latest.id,
            lastRepeatAt: latest.lastRepeatAt.getTime(),
            direction: "other", // unknown after a restart; next change always inserts a fresh row
          });
        }
      } catch (err) {
        this.markPgDegraded((err as Error).message ?? String(err), `seedFromDb(${parameter})`);
      } finally {
        this.seeding.delete(parameter);
      }
    })();

    this.seeding.set(parameter, promise);
    return promise;
  }
}

export const adaptiveTuningLog = new AdaptiveTuningLogStore();
