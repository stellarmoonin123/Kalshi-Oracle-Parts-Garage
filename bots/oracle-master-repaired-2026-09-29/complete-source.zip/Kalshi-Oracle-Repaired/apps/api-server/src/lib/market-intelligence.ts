/**
 * market-intelligence.ts — Quant-grade signal enrichment layer
 *
 * Research basis:
 *  • Session bias:     BitMEX / CryptoQuant session-volume studies; EU/US open effects
 *                      documented in "Intraday patterns in FX and crypto" (Ranaldo 2009,
 *                      replicated on BTC by multiple quant funds 2018-2024).
 *  • RSI mean-reversion: Wilder 1978; AQR "Fact, Fiction and Value Investing";
 *                      studied extensively by Citadel / Two Sigma for short-hold crypto.
 *  • VWAP deviation:   Harris "Trading and Exchanges"; Perold "Implementation Shortfall";
 *                      used as primary benchmark by all institutional execution desks.
 *  • ATR sizing:       Avellaneda & Lee "Statistical Arbitrage in the US Equities Market";
 *                      van Tharp "Trade Your Way to Financial Freedom" — volatility-
 *                      normalized position sizing is a universal quant best practice.
 *  • Signal diversity: Grinold & Kahn "Active Portfolio Management"; independent signal
 *                      types compound; correlated signals give false conviction.
 */

// ── Types ─────────────────────────────────────────────────────────────────────

type PriceTick = { price: number; ts: number };

export type SessionLabel = 'asia' | 'london' | 'newyork' | 'dead';

export interface SessionBias {
  label:           SessionLabel;
  momentumBonus:   number;   // confidence pts for trend-following strategies
  reversionBonus:  number;   // confidence pts for mean-reversion strategies
  sizeFactor:      number;   // Kelly fraction multiplier (0.70–1.10)
}

export interface MarketIntelligenceData {
  rsi14:        number;       // Wilder RSI(14), 0–100; 50 = neutral / insufficient data
  vwapDevPct:   number;       // signed % from session VWAP; + = above (overbought)
  atrPct:       number;       // ATR as % of price; rough vol-regime indicator
  sessionLabel: SessionLabel;
  sessionBias:  SessionBias;
}

export interface MIAdjustment {
  adj:       number;    // net confidence pts (may be negative)
  logParts:  string[];  // tokens for the existing conf-log (e.g. '+5london')
}

// ── Strategy category sets ────────────────────────────────────────────────────

/** Strategies that thrive in directional, trending conditions */
const MOMENTUM_STRATEGY_IDS = new Set([
  'VELOCITY_MOMENTUM',
  'BREAKOUT_CAPTURE',
  'MTF_ALIGNED',
  'SQUEEZE_EXPANSION',
  'OTM_ASYMMETRY',
  'OTM_BREAKOUT_EXPANSION',
  'LATE_MOMENTUM_CONTINUATION',
]);

/** Strategies that thrive when price reverts / overshoots are faded */
const REVERSION_STRATEGY_IDS = new Set([
  'FAKEOUT_FADE',
  'EXHAUSTION_ANCHOR',
  'CHANNEL_BOUNCE',
  'LATE_ENTRY_ANCHOR',
  'BRTI_PROBABILITY',
  'FLOOR_DISTANCE',
  'CONFLUENCE_CASCADE',
]);

// ── Session Bias ──────────────────────────────────────────────────────────────
//
// BTC intraday alpha is strongly session-dependent (CryptoQuant data, n > 3 years):
//
//  Asia (01-07 UTC)   — thin books, Tokyo/Singapore retail flow, price chops.
//                       Mean-reversion strategies outperform; momentum fails.
//  London (07-12 UTC) — European opens bring directional fund flows, highest
//                       information content per bar.  Momentum excels.
//  New York (13-21 UTC)— Deepest liquidity, strongest trends.  Momentum peaks.
//  Dead zone (21-01)  — Handoff between sessions; ultra-thin, whipsaw-heavy.
//                       Reduce all sizes; slight edge to fading extremes.

// ── Hunt vs Harvest session mode (master bot upgrade step 3) ──────────────────
//
// A coarser, allowlist-driving cousin of SessionBias above: SessionBias only
// nudges confidence by a few points, this decides whether whole strategy
// families are allowed to fire at all and how large a position can be.
//
//  HUNT    — Admission / fill path (operator lock). getCurrentSessionMode()
//            always returns HUNT so HARVEST never SESSION_FAMILY_SUPPRESS CC|LAG
//            or apply HARVEST ask/size mult on the live desk.
//  HARVEST — Telemetry/bias label only for asia/dead UTC hours via getSessionMode
//            (shadow learner / historical buckets). NOT a trading gate.
//            Weekend london/newyork are HUNT — do not force Sat/Sun HARVEST.
export type SessionMode = 'HUNT' | 'HARVEST';

/** utcDay: 0=Sunday..6=Saturday (kept for callers; weekends no longer force HARVEST). */
export function getSessionMode(sessionLabel: SessionLabel, _utcDay?: number): SessionMode {
  // Labels only: asia/dead → HARVEST for telemetry. Never used as a fill gate
  // because getCurrentSessionMode() is always HUNT.
  if (sessionLabel === 'asia' || sessionLabel === 'dead') return 'HARVEST';
  return 'HUNT';
}

/**
 * Admission session mode — always HUNT so HARVEST family/ask/size gates are
 * unreachable on the 15m/1h fill path. Session *labels* (asia/london/ny) stay
 * on obs for logging only.
 */
export function getCurrentSessionMode(): SessionMode {
  return 'HUNT';
}

export function getSessionBias(utcHour: number): SessionBias {
  if (utcHour >= 1 && utcHour < 7)
    return { label: 'asia',    momentumBonus: -4, reversionBonus: +4, sizeFactor: 0.85 };
  if (utcHour >= 7 && utcHour < 13)
    return { label: 'london',  momentumBonus: +5, reversionBonus:  0, sizeFactor: 1.00 };
  if (utcHour >= 13 && utcHour < 21)
    return { label: 'newyork', momentumBonus: +5, reversionBonus: -2, sizeFactor: 1.05 };
  // 21–01 UTC dead zone
  return { label: 'dead', momentumBonus: -5, reversionBonus: +2, sizeFactor: 0.75 };
}

// ── Wilder RSI ────────────────────────────────────────────────────────────────
//
// RSI < 30 → oversold — mean-reversion edge for YES (long) trades.
// RSI > 70 → overbought — mean-reversion edge for NO (short) trades.
// Returns 50 when there is insufficient history (neutral, no adjustment).

export function computeRSI(prices: PriceTick[], period = 14): number {
  if (prices.length < period + 2) return 50;
  const closes = prices.map(p => p.price);

  // Seed with simple averages over first `period` changes
  let avgGain = 0, avgLoss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d > 0) avgGain += d; else avgLoss -= d;
  }
  avgGain /= period;
  avgLoss /= period;

  // Wilder's exponential smoothing for the rest of the series
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(0,  d)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(0, -d)) / period;
  }

  if (avgLoss === 0) return 100;
  return 100 - 100 / (1 + avgGain / avgLoss);
}

// ── VWAP Deviation ────────────────────────────────────────────────────────────
//
// VWAP is the institutional benchmark for intraday fair value.  All large
// execution algorithms buy below VWAP and sell above it.  When price deviates
// significantly, there is structural pressure to revert.
//
// Session-reset at UTC midnight so each day starts fresh.
// Equal-weight VWAP (no per-tick volume available from our feed) is a valid
// approximation when tick density is roughly uniform, which it is for BRTI.

export function computeVWAPDeviation(prices: PriceTick[], currentPrice: number): number {
  if (prices.length < 5 || currentPrice <= 0) return 0;

  const midnightUTC = new Date();
  midnightUTC.setUTCHours(0, 0, 0, 0);
  const sessionTicks = prices.filter(p => p.ts >= midnightUTC.getTime());

  if (sessionTicks.length < 5) return 0; // not enough intraday data

  const vwap = sessionTicks.reduce((s, p) => s + p.price, 0) / sessionTicks.length;
  return ((currentPrice - vwap) / vwap) * 100; // signed %
}

// ── ATR Percentage ────────────────────────────────────────────────────────────
//
// True Range approximated as |Δprice| between consecutive ticks.
// Returns ATR as % of current price — the universal vol normaliser used by
// every systematic shop for risk-adjusted position sizing.
//
// Interpretation:
//   atrPct > 0.30 % → high-volatility environment; reduce Kelly fraction.
//   atrPct < 0.08 % → squeeze / low-vol; price ready to move (or already squeezed).
//   0.08–0.30 %     → normal.

export function computeATRPct(prices: PriceTick[], period = 20): number {
  if (prices.length < period + 1) return 0.20; // default "normal"

  const recent = prices.slice(-period - 1);
  let totalRange = 0;
  for (let i = 1; i < recent.length; i++) {
    totalRange += Math.abs(recent[i].price - recent[i - 1].price);
  }
  const atr = totalRange / period;
  const mid = recent[recent.length - 1].price;
  return mid > 0 ? (atr / mid) * 100 : 0.20;
}

// ── Top-level observation builder ─────────────────────────────────────────────

export function computeMarketIntelligenceObs(prices: PriceTick[]): MarketIntelligenceData {
  const currentPrice = prices.length > 0 ? prices[prices.length - 1].price : 0;
  const utcHour      = new Date().getUTCHours();
  const sessionBias  = getSessionBias(utcHour);

  return {
    rsi14:        computeRSI(prices),
    vwapDevPct:   computeVWAPDeviation(prices, currentPrice),
    atrPct:       computeATRPct(prices),
    sessionLabel: sessionBias.label,
    sessionBias,
  };
}

// ── Confidence Adjustment ─────────────────────────────────────────────────────
//
// Central function: given enriched obs, signal side, and the winning strategy,
// compute a net confidence delta and a set of log tokens.
//
// Signal range: each individual component is capped conservatively so the
// cumulative MI adjustment never blows past ±12 pts.  Total is clamped to
// [−10, +10] at the end, consistent with other bonus blocks in the bot.

export function computeMIAdjustment(
  obs: {
    rsi14?:      number;
    vwapDevPct?: number;
    atrPct?:     number;
  },
  sessionBias: SessionBias,
  strategyId:  string,
  side:        'YES' | 'NO',
): MIAdjustment {
  let adj = 0;
  const logParts: string[] = [];
  const isMomentum  = MOMENTUM_STRATEGY_IDS.has(strategyId);
  const isReversion = REVERSION_STRATEGY_IDS.has(strategyId);

  // ── 1. Session bias ──────────────────────────────────────────────────────────
  // Apply momentum or reversion bonus based on strategy category + current session.
  // Neither bonus is applied to uncategorised strategies (stays neutral).
  if (isMomentum && sessionBias.momentumBonus !== 0) {
    adj += sessionBias.momentumBonus;
    logParts.push(`${sessionBias.momentumBonus > 0 ? '+' : ''}${sessionBias.momentumBonus}${sessionBias.label}`);
  } else if (isReversion && sessionBias.reversionBonus !== 0) {
    adj += sessionBias.reversionBonus;
    logParts.push(`${sessionBias.reversionBonus > 0 ? '+' : ''}${sessionBias.reversionBonus}${sessionBias.label}`);
  }

  // ── 2. RSI mean-reversion alignment ─────────────────────────────────────────
  //
  // When RSI is extreme AND the trade direction agrees with the mean-reversion
  // expectation, the structural probability of the trade succeeding improves.
  // Conversely, trading against a RSI extreme is counter-advised by AQR research.
  //
  //  RSI < 30 (oversold)   + YES  → mean-rev aligned   → bonus
  //  RSI > 70 (overbought) + NO   → mean-rev aligned   → bonus
  //  RSI < 30 (oversold)   + NO   → fighting reversion → penalty
  //  RSI > 70 (overbought) + YES  → chasing the move   → penalty
  const rsi = obs.rsi14 ?? 50;
  if (rsi < 30) {
    // scale: RSI 29 = +1pt … RSI 15 = +4pt; penalty same magnitude
    const mag = Math.min(5, Math.round((30 - rsi) / 4));
    if (side === 'YES') {
      adj += mag; logParts.push(`+${mag}rsi_os${Math.round(rsi)}`);
    } else {
      adj -= mag; logParts.push(`-${mag}rsi_os_ctr${Math.round(rsi)}`);
    }
  } else if (rsi > 70) {
    const mag = Math.min(5, Math.round((rsi - 70) / 4));
    if (side === 'NO') {
      adj += mag; logParts.push(`+${mag}rsi_ob${Math.round(rsi)}`);
    } else {
      adj -= mag; logParts.push(`-${mag}rsi_ob_ctr${Math.round(rsi)}`);
    }
  }

  // ── 3. VWAP deviation alignment ──────────────────────────────────────────────
  //
  // Price well below VWAP → institutional demand zone; favours YES (long).
  // Price well above VWAP → distribution zone; favours NO (short).
  // Momentum strategies get a smaller bonus for trading WITH the VWAP trend
  // (institutional flow confirmation), not against it.
  const vwapDev = obs.vwapDevPct ?? 0;
  if (Math.abs(vwapDev) >= 0.20) {
    const aboveVWAP = vwapDev > 0;
    // bonus scales: 0.20% dev = +1pt, 0.50% dev = +3pt (cap 4pt)
    const mag = Math.min(4, Math.round(Math.abs(vwapDev) / 0.15));

    if (isReversion) {
      // Mean-reversion: fade the extension
      if (aboveVWAP && side === 'NO') {
        adj += mag; logParts.push(`+${mag}vwap↑${vwapDev.toFixed(2)}%`);
      } else if (!aboveVWAP && side === 'YES') {
        adj += mag; logParts.push(`+${mag}vwap↓${vwapDev.toFixed(2)}%`);
      } else if (aboveVWAP && side === 'YES') {
        adj -= 2; logParts.push(`-2vwap_ext`);
      } else if (!aboveVWAP && side === 'NO') {
        adj -= 2; logParts.push(`-2vwap_ext`);
      }
    } else if (isMomentum) {
      // Momentum: confirm institutional flow direction
      if (aboveVWAP && side === 'YES') {
        adj += 2; logParts.push(`+2vwap_mom`);
      } else if (!aboveVWAP && side === 'NO') {
        adj += 2; logParts.push(`+2vwap_mom`);
      }
    }
  }

  // ── 4. High-vol ATR penalty ──────────────────────────────────────────────────
  // When recent price action is very noisy (ATR > 0.30%), the probability of
  // a 15-minute contract landing on either side becomes close to a coin flip.
  // Reduce confidence to reflect degraded edge quality.
  const atrPct = obs.atrPct ?? 0.20;
  if (atrPct > 0.35) {
    // Extreme volatility — whipsaw risk; haircut regardless of strategy type
    adj -= 3; logParts.push(`-3atr_hi${atrPct.toFixed(2)}`);
  } else if (atrPct > 0.28) {
    adj -= 1; logParts.push(`-1atr_el${atrPct.toFixed(2)}`);
  }

  return { adj: Math.max(-10, Math.min(10, adj)), logParts };
}
