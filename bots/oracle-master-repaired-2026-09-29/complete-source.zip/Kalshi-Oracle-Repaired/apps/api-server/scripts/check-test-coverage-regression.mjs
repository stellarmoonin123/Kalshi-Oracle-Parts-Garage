#!/usr/bin/env node
/**
 * Regression fixture for check-test-coverage.mjs.
 *
 * Keep this outside src/ because it is a check of the test-discovery guard,
 * not an API test that should be discovered by the API test command.
 */

import { mkdtempSync, mkdirSync, rmSync, writeFileSync, cpSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const scriptDir = fileURLToPath(new URL(".", import.meta.url));
const checkerPath = join(scriptDir, "check-test-coverage.mjs");
const fixtureRoot = mkdtempSync(join(tmpdir(), "api-test-coverage-"));

try {
  mkdirSync(join(fixtureRoot, "scripts"), { recursive: true });
  mkdirSync(join(fixtureRoot, "src"), { recursive: true });
  cpSync(checkerPath, join(fixtureRoot, "scripts", "check-test-coverage.mjs"));

  writeFileSync(
    join(fixtureRoot, "package.json"),
    JSON.stringify({
      scripts: {
        test: "tsx --test --test-force-exit 'src/**/*.test.ts'",
      },
    }),
  );
  writeFileSync(
    join(fixtureRoot, "tsconfig.json"),
    JSON.stringify({
      include: ["src"],
      exclude: ["src/excluded.test.ts"],
    }),
  );
  writeFileSync(
    join(fixtureRoot, "src", "excluded.test.ts"),
    "export const fixtureTest = true;\n",
  );

  const result = spawnSync(
    process.execPath,
    [join(fixtureRoot, "scripts", "check-test-coverage.mjs")],
    {
      cwd: fixtureRoot,
      encoding: "utf8",
    },
  );
  const output = `${result.stdout ?? ""}\n${result.stderr ?? ""}`;
  const expectedDiagnostic =
    `Test file excluded from tsconfig type-checking by 'exclude: "src/excluded.test.ts"': ` +
    "src/excluded.test.ts";

  if (result.error) {
    throw result.error;
  }
  if (result.status === 0) {
    throw new Error(
      "The discovery guard unexpectedly passed for a test file excluded by tsconfig.",
    );
  }
  if (!output.includes(expectedDiagnostic)) {
    throw new Error(
      `The discovery guard failed without the expected diagnostic.\nExpected: ${expectedDiagnostic}\nOutput:\n${output}`,
    );
  }

  console.log(
    "✅ check-test-coverage regression: excluded test file fails loudly.",
  );
} finally {
  rmSync(fixtureRoot, { recursive: true, force: true });
}
