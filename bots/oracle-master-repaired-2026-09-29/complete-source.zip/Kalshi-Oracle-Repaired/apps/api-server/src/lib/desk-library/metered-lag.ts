/**
 * metered-lag.ts — settlement book, shadow.
 *
 * Wraps persist-lag + lag-meter. Skip if lagStale, !lagAgreesWithSide,
 * |lagDollars| too small, or ask > 55.
 *
 * Reuses persist-lag.ts and lag-meter.ts. Does not duplicate them.
 *
 * paperMode true. autoMode false. LIVE_APPLY false.
 * Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR.
 */
import {
  shouldPersistLagTake,
  PERSIST_LAG_MAX_ASK_CENTS,
  type PersistLagOpts,
} from "../persist-lag.js";
import { lagAgreesWithSide } from "../lag-meter.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;

/** Fail closed: a Coinbase move this small over tau is not lag. */
export const METERED_LAG_MIN_ABS_DOLLARS = 16;

export type MeteredLagOpts = PersistLagOpts & {
  lagStale: boolean;
  lagDollars: number | null;
};

export type MeteredLagDecision = {
  take: boolean;
  reason: string;
};

function skip(reason: string): MeteredLagDecision {
  return { take: false, reason };
}

/**
 * Shadow predicate. persist-lag is the inner take; lag-meter is the outer skip.
 */
export function shouldMeteredLagTake(opts: MeteredLagOpts): MeteredLagDecision {
  if (LIVE_APPLY || LIVE_APPLY_ENABLED) {
    return skip("live_apply_refused");
  }
  if (opts.lagStale) {
    return skip("lag_stale");
  }
  if (!lagAgreesWithSide(opts.side, opts.lagDollars)) {
    return skip("lag_disagrees");
  }
  if (
    opts.lagDollars == null
    || !Number.isFinite(opts.lagDollars)
    || Math.abs(opts.lagDollars) < METERED_LAG_MIN_ABS_DOLLARS
  ) {
    return skip("lag_dollars_too_small");
  }
  if (opts.askCents > PERSIST_LAG_MAX_ASK_CENTS) {
    return skip("ask_gt_55");
  }

  const inner = shouldPersistLagTake({
    side: opts.side,
    askCents: opts.askCents,
    msOnSideOfFloor: opts.msOnSideOfFloor,
    evCents: opts.evCents,
    mtf: opts.mtf,
  });
  if (!inner.take) return inner;
  return { take: true, reason: "metered_lag" };
}
