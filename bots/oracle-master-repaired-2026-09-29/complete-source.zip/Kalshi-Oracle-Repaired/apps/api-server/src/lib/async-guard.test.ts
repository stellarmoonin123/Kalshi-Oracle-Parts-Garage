/**
 * async-guard.test.ts — regression tests for timer overlap protection.
 *
 * The Aug 2026 latency audit found background loops (rollover, market-trade
 * fetch, period recorder, settlement predictor) could overlap themselves when
 * a network/DB call ran slower than the interval, stacking duplicate work and
 * stalling the bot's 500ms decision tick. These tests pin the guard behavior.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { makeGuarded } from "./async-guard.js";

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

test("slow operation: overlapping fires are skipped, not stacked", async () => {
  let started = 0;
  let finished = 0;
  const guarded = makeGuarded(async () => {
    started++;
    await sleep(80);            // simulates a slow settlement fetch / DB write
    finished++;
  });

  // Simulate a 20ms interval firing 4 times while the first call is in flight
  const fires = [guarded(), sleep(20).then(guarded), sleep(40).then(guarded), sleep(60).then(guarded)];
  await Promise.all(fires);
  await sleep(100);

  assert.equal(started, 1, "only the first fire should run while slow op is in flight");
  assert.equal(finished, 1);
});

test("guard releases after completion — next fire runs", async () => {
  let runs = 0;
  const guarded = makeGuarded(async () => { runs++; await sleep(10); });
  await guarded();
  await guarded();
  assert.equal(runs, 2, "sequential (non-overlapping) fires must both run");
});

test("guard releases even when the operation throws", async () => {
  let errors = 0;
  let runs = 0;
  const guarded = makeGuarded(
    async () => { runs++; throw new Error("boom"); },
    () => { errors++; },
  );
  await guarded();
  await guarded();
  assert.equal(runs, 2, "a thrown error must not latch the guard closed");
  assert.equal(errors, 2, "errors are routed to onError, never unhandled");
});

test("concurrent burst: exactly one execution wins", async () => {
  let runs = 0;
  const guarded = makeGuarded(async () => { runs++; await sleep(30); });
  await Promise.all([guarded(), guarded(), guarded(), guarded(), guarded()]);
  assert.equal(runs, 1);
});
