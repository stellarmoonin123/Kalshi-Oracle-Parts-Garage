import { test } from "node:test";
import assert from "node:assert/strict";
import { computeTradeEV } from "./trade-path.js";
import { evaluateEntryEVGate, EV_FLOOR } from "./admission.js";
import { kalshiTakerFeeCents } from "./fees/kalshi-fee.js";

test("D13: fee on the real order size = exact whole-order fee / C (18@37 → 30¢/18)", () => {
  const r = computeTradeEV({ entryPriceCents: 37, winRate: 0.55, contracts: 18 });
  assert.equal(kalshiTakerFeeCents(37, 18), 30);
  assert.ok(Math.abs(r.feeCents - 30 / 18) < 1e-9);
  const c1 = computeTradeEV({ entryPriceCents: 37, winRate: 0.55 });
  assert.equal(c1.feeCents, kalshiTakerFeeCents(37, 1)); // conservative default unchanged
});

test("D13: exact fee never exceeds the conservative C=1 fee (any price, any size)", () => {
  for (let p = 1; p <= 99; p++) {
    for (const c of [1, 2, 3, 7, 18, 34, 72, 150]) {
      assert.ok(kalshiTakerFeeCents(p, c) / c <= kalshiTakerFeeCents(p, 1) + 1e-9, `p=${p} c=${c}`);
    }
  }
});

test("D13: EV ≥ 3¢ still enforced with exact fees (floor unchanged)", () => {
  assert.equal(EV_FLOOR, 3);
  // find a p right at the boundary for 18@37 and check pass/fail flips at 3¢ exactly
  for (const wr of [0.38, 0.40, 0.42, 0.44, 0.46, 0.5, 0.55]) {
    const g = evaluateEntryEVGate({ entryPriceCents: 37, strategyWinRate: wr, strategyId: "CONFLUENCE_CASCADE", contracts: 18 });
    assert.equal(g.passes, (g.netEV ?? -Infinity) >= 3, `wr=${wr} ev=${g.netEV}`);
    const r = computeTradeEV({ entryPriceCents: 37, winRate: wr, contracts: 18 });
    assert.ok(Math.abs((g.netEV ?? 0) - r.netEV) < 1e-9);
  }
  const rich = evaluateEntryEVGate({ entryPriceCents: 87, strategyWinRate: 0.54, strategyId: "CONFLUENCE_CASCADE", contracts: 50 });
  assert.equal(rich.passes, false);
});
