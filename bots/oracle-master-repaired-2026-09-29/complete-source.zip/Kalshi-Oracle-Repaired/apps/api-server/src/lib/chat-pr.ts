/**
 * chat-pr.ts — "propose a code fix" for the desk chat (round 2).
 *
 * Flow: unified diff → hard-lock denial → per-file lock lint
 * (scanProposedEdit) → apply in a TEMP copy of the api-server → run the
 * targeted tests there (minimal env, no secrets, timeout) → open a DRAFT PR
 * on a NEW branch `chat/<slug>-<ts>` via the GitHub REST API.
 *
 * Never: master/main as head, auto-merge, deploy, or writing the live tree.
 * Without CHAT_PR_GITHUB_TOKEN it degrades to "here is the patch" (plus the
 * sandbox test result). The operator's own gh token must NOT be put on Fly;
 * use a fine-grained token scoped to the one repo (contents+pull_requests).
 *
 * Env: CHAT_PR_GITHUB_TOKEN (optional), CHAT_PR_REPO (default
 * stellarmoonin123/Kalshi-oracle), CHAT_PR_BASE (default master — the PR's
 * target; the head is always a new chat/* branch).
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { applyUnifiedPatch, scanProposedEdit, isSecretPath } from "./chat-code-edit.js";

/** Files/params the chat may never patch (EV/Kelly/band/reserve/caps/paperMode/organ locks + lock tests). */
export const HARD_LOCK_PATH_PATTERNS: readonly RegExp[] = [
  /(^|\/)[^/]*lock[^/]*\.(ts|tsx|mjs|js)$/i,           // *lock*.ts incl. desk-lock, paper-size-lock, composer-lock, direction-lock…
  /(^|\/)hard-locks[^/]*$/i,
  /(^|\/)risk-invariants[^/]*$/i,
  /apps\/api-server\/src\/lib\/admission(\.isolate)?\.ts$/,
  /apps\/api-server\/src\/lib\/organs\/size\.ts$/,
  /apps\/api-server\/src\/lib\/paper-equity-size\.ts$/,
  /apps\/api-server\/src\/lib\/paper-desk-product\.ts$/,
  /apps\/api-server\/src\/lib\/risk-kernel\.ts$/,
  /apps\/api-server\/src\/lib\/constants\.ts$/,
  /apps\/api-server\/src\/lib\/trade-path\.ts$/,
  /apps\/api-server\/src\/lib\/fees\//,
  /apps\/api-server\/src\/lib\/config-guard\.ts$/,
  /apps\/api-server\/src\/lib\/config-patch-surface\.ts$/,
  /apps\/api-server\/src\/lib\/control-boundary[^/]*$/,
  /apps\/api-server\/src\/lib\/default-settings\.ts$/,
  /apps\/api-server\/src\/lib\/organs\/(edge|mind-place-bind|brain-center|side-lock|lock-side-context|lockside-fill-gate|direction-lock|book-depth-stamp|mind-calibration|shadow-calibration)\.ts$/,
  /apps\/api-server\/src\/lib\/chat-(pr|code-edit|router)\.ts$/,   // the guards themselves
  /apps\/api-server\/src\/routes\/kalshi-manual-exchange-boundary[^/]*$/,
  /(^|\/)(ci|\.github)\//,
  /(^|\/)(Dockerfile|fly\.toml|railway\.toml)$/,
];

/** Added-line patterns that touch locked params regardless of file. */
export const HARD_LOCK_LINE_PATTERNS: readonly { re: RegExp; label: string }[] = [
  { re: /\bpaperMode\s*[:=]\s*false\b/, label: "paperMode false" },
  { re: /\bEV_FLOOR\b|\bOTM_EV_FLOOR\b|\bminEVCents\b/, label: "EV floor" },
  { re: /\bkelly(Fraction|Lambda\w*|Cap|Mult)\b|\bKELLY_\w+/i, label: "Kelly" },
  { re: /\bHARD_RISK_LIMITS\b|\bmaxRiskPctPerTrade\b|\bDAILY_HALT_\w+|\bapplyHardRiskLimits\b/, label: "9%/18% caps" },
  { re: /\breservePct\b|\bRESERVE_PCT\b/, label: "reserve" },
  { re: /\bPAPER_EQUITY_(FLOOR|CEIL)_PCT\b|\bmaxEntryPrice\b|\bminEntryPrice\b|\bASK_BAND\w*/, label: "ask/equity band" },
  { re: /\bfrozenCcMode\s*[:=]\s*false\b|\bliveMoneyMayEnable\b/, label: "organ/desk lock" },
];

export interface PatchFile { path: string; isNew: boolean; isDelete: boolean; hunks: string }

/** Split a multi-file unified diff (git style) into per-file patches. */
export function splitUnifiedDiff(patch: string): PatchFile[] {
  const text = patch.replace(/\r\n/g, "\n");
  const files: PatchFile[] = [];
  const chunks = text.split(/^(?=diff --git |--- (?:a\/|\/dev\/null))/m).filter((c) => /^(\+\+\+ |@@)/m.test(c));
  for (const c of chunks) {
    const minus = /^--- (?:a\/)?(.+)$/m.exec(c)?.[1]?.trim();
    const plus = /^\+\+\+ (?:b\/)?(.+)$/m.exec(c)?.[1]?.trim();
    const p = plus && plus !== "/dev/null" ? plus : minus;
    if (!p) continue;
    files.push({ path: p.replace(/^\.\//, ""), isNew: minus === "/dev/null", isDelete: plus === "/dev/null", hunks: c });
  }
  return files;
}

export interface Denial { ok: false; denied: true; reason: string; paths?: string[] }

export function checkHardLocks(files: PatchFile[]): Denial | { ok: true } {
  const bad = files.filter((f) => HARD_LOCK_PATH_PATTERNS.some((re) => re.test(f.path)) || isSecretPath(f.path) || /(^|\/)\.env/.test(f.path));
  if (bad.length) return { ok: false, denied: true, reason: "patch touches hard-lock / protected files", paths: bad.map((f) => f.path) };
  for (const f of files) {
    const touched = f.hunks.split("\n").filter((l) => (l.startsWith("+") || l.startsWith("-")) && !l.startsWith("+++") && !l.startsWith("---"));
    for (const l of touched) {
      const hit = HARD_LOCK_LINE_PATTERNS.find((p) => p.re.test(l));
      if (hit) return { ok: false, denied: true, reason: `patch changes a locked parameter (${hit.label})`, paths: [f.path] };
    }
  }
  return { ok: true };
}

export interface SandboxResult { ran: boolean; ok: boolean; tests: string[]; pass: number; fail: number; tail: string; note?: string }

export interface ProposeDeps {
  deskRoot: string;
  env?: NodeJS.ProcessEnv;
  fetchImpl?: typeof fetch;
  runTests?: (appDir: string, tests: string[]) => { status: number | null; out: string };
  now?: () => number;
}

const MAX_PATCH_BYTES = 80_000;
const MAX_FILES = 10;
let lastPrAtMs = 0;

function readLocal(deskRoot: string, rel: string): string | null {
  try { return fs.readFileSync(path.join(deskRoot, rel), "utf8"); } catch { return null; }
}

/** Apply every file patch against `readBase`; returns new contents or a denial. */
export function applyAll(files: PatchFile[], readBase: (rel: string) => string | null, userMessage = ""): Denial | { ok: true; contents: Map<string, string | null> } {
  const contents = new Map<string, string | null>();
  for (const f of files) {
    const before = f.isNew ? "" : readBase(f.path);
    if (before == null) return { ok: false, denied: true, reason: `cannot read ${f.path} at base`, paths: [f.path] };
    if (f.isDelete) { contents.set(f.path, null); continue; }
    const applied = applyUnifiedPatch(before, f.hunks);
    if (!applied.ok) return { ok: false, denied: true, reason: `${f.path}: ${applied.reason}`, paths: [f.path] };
    const lint = scanProposedEdit({ relPath: f.path, before, after: applied.next, userMessage });
    if (!lint.ok) return { ok: false, denied: true, reason: `${f.path}: ${lint.reason}`, paths: [f.path] };
    contents.set(f.path, applied.next);
  }
  return { ok: true, contents };
}

export function targetedTests(changed: string[], exists: (rel: string) => boolean): string[] {
  const tests = new Set<string>();
  for (const rel of changed) {
    if (!rel.startsWith("apps/api-server/")) continue;
    if (/\.test\.ts$/.test(rel)) { tests.add(rel); continue; }
    const t = rel.replace(/\.ts$/, ".test.ts");
    if (t !== rel && exists(t)) tests.add(t);
  }
  return [...tests].slice(0, 8);
}

function defaultRunTests(appDir: string, tests: string[]): { status: number | null; out: string } {
  const r = spawnSync(process.execPath, ["--import", "tsx", "--test", "--test-force-exit", ...tests], {
    cwd: appDir, encoding: "utf8", timeout: 180_000, maxBuffer: 8 * 1024 * 1024,
    // Minimal env: no DATABASE_URL, no API keys, no tokens.
    env: { PATH: process.env.PATH ?? "/usr/bin:/bin", NODE_ENV: "test", HOME: appDir, TZ: "America/New_York" },
  });
  return { status: r.status, out: `${r.stdout ?? ""}\n${r.stderr ?? ""}` };
}

/** Temp copy of apps/api-server (src + manifests; node_modules symlinked) with the patch overlaid. */
export function runSandboxTests(deps: ProposeDeps, contents: Map<string, string | null>, extraTestFiles: Map<string, string> = new Map()): SandboxResult {
  const app = path.join(deps.deskRoot, "apps/api-server");
  if (!fs.existsSync(path.join(app, "src"))) return { ran: false, ok: false, tests: [], pass: 0, fail: 0, tail: "", note: "api-server source not present on this host" };
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "chat-pr-"));
  try {
    const tApp = path.join(tmp, "apps/api-server");
    fs.mkdirSync(tApp, { recursive: true });
    fs.cpSync(path.join(app, "src"), path.join(tApp, "src"), { recursive: true });
    for (const f of ["package.json", "tsconfig.json", "load-env.mjs", "isolate-strategy-learning-test.mjs"]) {
      if (fs.existsSync(path.join(app, f))) fs.copyFileSync(path.join(app, f), path.join(tApp, f));
    }
    if (fs.existsSync(path.join(app, "node_modules"))) fs.symlinkSync(path.join(app, "node_modules"), path.join(tApp, "node_modules"));
    if (fs.existsSync(path.join(deps.deskRoot, "node_modules"))) fs.symlinkSync(path.join(deps.deskRoot, "node_modules"), path.join(tmp, "node_modules"));
    for (const [rel, body] of [...extraTestFiles, ...contents]) {
      if (!rel.startsWith("apps/api-server/")) continue;
      const abs = path.join(tmp, rel);
      if (body == null) { fs.rmSync(abs, { force: true }); continue; }
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, body);
    }
    const tests = targetedTests([...contents.keys(), ...extraTestFiles.keys()], (rel) => fs.existsSync(path.join(tmp, rel)))
      .map((rel) => rel.replace(/^apps\/api-server\//, ""));
    if (tests.length === 0) return { ran: false, ok: true, tests: [], pass: 0, fail: 0, tail: "", note: "no targeted tests found for the changed files" };
    const r = (deps.runTests ?? defaultRunTests)(tApp, tests);
    const pass = Number(/# pass (\d+)/.exec(r.out)?.[1] ?? 0);
    const fail = Number(/# fail (\d+)/.exec(r.out)?.[1] ?? (r.status === 0 ? 0 : 1));
    return { ran: true, ok: r.status === 0 && fail === 0, tests, pass, fail, tail: r.out.split("\n").slice(-25).join("\n") };
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

async function gh(fetchImpl: typeof fetch, token: string, method: string, url: string, body?: unknown): Promise<any> {
  const r = await fetchImpl(`https://api.github.com${url}`, {
    method,
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "Content-Type": "application/json", "User-Agent": "oracle-desk-chat" },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(20_000),
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`GitHub ${method} ${url.split("?")[0]} → ${r.status}`);
  return text ? JSON.parse(text) : {};
}

export function prBranchName(title: string, nowMs: number): string {
  const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "fix";
  return `chat/${slug}-${nowMs.toString(36)}`;
}

export type ProposeResult =
  | Denial
  | { ok: true; mode: "patch_only"; patch: string; files: string[]; tests: SandboxResult; message: string }
  | { ok: true; mode: "pr"; url: string; branch: string; files: string[]; tests: SandboxResult; message: string }
  | { ok: false; denied: false; reason: string; tests?: SandboxResult; patch?: string };

export async function proposePatchPr(input: { patch: string; title: string; body?: string; userMessage?: string }, deps: ProposeDeps): Promise<ProposeResult> {
  const env = deps.env ?? process.env;
  const now = (deps.now ?? Date.now)();
  const patch = String(input.patch ?? "");
  if (!patch.trim()) return { ok: false, denied: true, reason: "empty patch" };
  if (Buffer.byteLength(patch) > MAX_PATCH_BYTES) return { ok: false, denied: true, reason: "patch too large (80 KB max)" };
  const files = splitUnifiedDiff(patch);
  if (files.length === 0) return { ok: false, denied: true, reason: "no file hunks found (send a git-style unified diff)" };
  if (files.length > MAX_FILES) return { ok: false, denied: true, reason: `too many files (${files.length} > ${MAX_FILES})` };
  if (files.some((f) => f.path.includes("..") || path.isAbsolute(f.path))) return { ok: false, denied: true, reason: "path traversal refused" };
  const locks = checkHardLocks(files);
  if (!locks.ok) return locks;

  const token = (env.CHAT_PR_GITHUB_TOKEN ?? "").trim();
  const repo = (env.CHAT_PR_REPO ?? "stellarmoonin123/Kalshi-oracle").trim();
  const base = (env.CHAT_PR_BASE ?? "master").trim();
  const fetchImpl = deps.fetchImpl ?? globalThis.fetch;

  // Base content: GitHub base ref when a token is present (the PR must apply there), else the local desk tree.
  const remote = new Map<string, string | null>();
  if (token) {
    for (const f of files) {
      try {
        const j = await gh(fetchImpl, token, "GET", `/repos/${repo}/contents/${encodeURI(f.path)}?ref=${encodeURIComponent(base)}`);
        remote.set(f.path, typeof j.content === "string" ? Buffer.from(j.content, "base64").toString("utf8") : null);
      } catch { remote.set(f.path, null); }
    }
  }
  const readBase = (rel: string) => (token && remote.has(rel) ? remote.get(rel)! : readLocal(deps.deskRoot, rel));
  const applied = applyAll(files, readBase, input.userMessage ?? "");
  if (!applied.ok) return applied;

  // Sibling tests missing locally (the Fly image strips *.test.ts) → fetch from GitHub when possible.
  const extra = new Map<string, string>();
  if (token) {
    for (const t of targetedTests([...applied.contents.keys()], () => true)) {
      if (applied.contents.has(t) || readLocal(deps.deskRoot, t) != null) continue;
      try {
        const j = await gh(fetchImpl, token, "GET", `/repos/${repo}/contents/${encodeURI(t)}?ref=${encodeURIComponent(base)}`);
        if (typeof j.content === "string") extra.set(t, Buffer.from(j.content, "base64").toString("utf8"));
      } catch { /* no sibling test */ }
    }
  }
  let tests: SandboxResult;
  try { tests = runSandboxTests(deps, applied.contents, extra); } catch (e) {
    tests = { ran: false, ok: false, tests: [], pass: 0, fail: 0, tail: "", note: `sandbox failed: ${(e as Error).message}` };
  }
  if (tests.ran && !tests.ok) return { ok: false, denied: false, reason: "targeted tests failed in the sandbox — no PR opened", tests, patch };

  const fileList = files.map((f) => f.path);
  if (!token) {
    return { ok: true, mode: "patch_only", patch, files: fileList, tests,
      message: "CHAT_PR_GITHUB_TOKEN is not set on this server, so no PR was opened. Here is the validated patch — apply it through the normal review flow." };
  }
  if (now - lastPrAtMs < 10 * 60_000) return { ok: false, denied: false, reason: "one chat PR per 10 minutes — try again later", tests, patch };
  const branch = prBranchName(input.title, now);
  if (/^(master|main)$/i.test(branch)) return { ok: false, denied: true, reason: "refusing to push to master/main" };
  try {
    const ref = await gh(fetchImpl, token, "GET", `/repos/${repo}/git/ref/heads/${encodeURIComponent(base)}`);
    const baseSha: string = ref.object.sha;
    const baseCommit = await gh(fetchImpl, token, "GET", `/repos/${repo}/git/commits/${baseSha}`);
    const tree: unknown[] = [];
    for (const [rel, body] of applied.contents) {
      if (body == null) { tree.push({ path: rel, mode: "100644", type: "blob", sha: null }); continue; }
      const blob = await gh(fetchImpl, token, "POST", `/repos/${repo}/git/blobs`, { content: body, encoding: "utf-8" });
      tree.push({ path: rel, mode: "100644", type: "blob", sha: blob.sha });
    }
    const newTree = await gh(fetchImpl, token, "POST", `/repos/${repo}/git/trees`, { base_tree: baseCommit.tree.sha, tree });
    const commit = await gh(fetchImpl, token, "POST", `/repos/${repo}/git/commits`, { message: `chat: ${input.title}`.slice(0, 200), tree: newTree.sha, parents: [baseSha] });
    await gh(fetchImpl, token, "POST", `/repos/${repo}/git/refs`, { ref: `refs/heads/${branch}`, sha: commit.sha });
    const pr = await gh(fetchImpl, token, "POST", `/repos/${repo}/pulls`, {
      title: `[chat] ${input.title}`.slice(0, 120), head: branch, base, draft: true,
      body: `${input.body ?? ""}\n\nOpened by the desk chat (propose_fix). Not merged, not deployed.\nSandbox tests: ${tests.ran ? `${tests.pass} pass / ${tests.fail} fail (${tests.tests.join(", ")})` : tests.note ?? "not run"}.`,
    });
    lastPrAtMs = now;
    return { ok: true, mode: "pr", url: pr.html_url, branch, files: fileList, tests, message: `Draft PR opened on ${branch} → ${base}. Not merged, not deployed.` };
  } catch (e) {
    return { ok: false, denied: false, reason: `GitHub PR failed (${(e as Error).message}); patch returned instead`, tests, patch };
  }
}

/** Test hook. */
export function __resetChatPrRateLimit(): void { lastPrAtMs = 0; }
