/**
 * Research-grade meta-label data store.
 *
 * Records only facts known at a trade decision, then attaches an outcome later.
 * This prevents look-ahead leakage in backtests and keeps heuristic settlement
 * fallbacks out of training data.
 */

import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export type MetaLabel = 0 | 1;
export type MetaOutcomeSource = "OFFICIAL_SETTLEMENT" | "EARLY_EXIT" | "HEURISTIC" | "SIMULATED";

export interface MetaFeatures {
  timestamp: number;
  /**
   * MARKET rows describe a directional contract candidate. SYSTEM rows capture
   * an entry gate observed before market data exists, using a sentinel ticker
   * rather than pretending that a tradable YES/NO candidate was available.
   */
  decisionScope?: "MARKET" | "SYSTEM";
  marketTicker: string;
  contractDurationMins: number;
  secsRemaining: number;
  path: "HIGH_PROB" | "GRAY" | "MULTIPLIER";
  regime: string;
  session: string;
  dayOfWeek: number;
  hourOfDay: number;
  strategyId: string;
  direction: "YES" | "NO";
  strategyConfidence: number;
  preTradeScore: number;
  entryPriceCents: number;
  btcPrice: number;
  floorStrike: number;
  distFromFloorPct: number;
  distFromFloorAbs: number;
  velocity1m: number;
  velocity3m: number;
  acceleration?: number;
  isStalling: boolean;
  spreadCents: number;
  bestBidSize: number;
  bestAskSize: number;
  bookImbalance: number;
  opposingDepth: number;
  suspicionScore?: number;
  volumeState?: "low" | "normal" | "high";
  mtfScore?: number;
  mtfBias?: "BULL" | "BEAR" | "NEUTRAL";
  // Per-timeframe raw scores + regime-clarity bonus/penalty flags, added
  // 2026-08-11 (knowledge-utilization follow-up #2). Logging-only: these
  // change no live behavior. They exist so that once ~30+ settled trades
  // have accumulated with this data, the same settled-trade subtractive
  // walk-forward method already used elsewhere in this codebase can ask
  // "if this MTF weight/regime-bonus value had been different, would this
  // trade still have cleared the entry threshold, and what's that subset's
  // realized win rate?" — without needing a new historical replay engine.
  mtfM1Score?: number;
  mtfM5Score?: number;
  mtfM15Score?: number;
  mtfH1Score?: number;
  /** Best-effort: true if the REGIME_TREND_CONF_BONUS branch fired for this decision. */
  regimeBonusFired?: boolean;
  /** Best-effort: true if the REGIME_UNCLEAR_CONF_PENALTY (low_vol) branch fired for this decision. */
  regimePenaltyFired?: boolean;
  estimatedWinRate: number;
  theoreticalEV?: number;
  netEVAfterFees?: number;
  balanceCents?: number;
  currentDrawdownPct?: number;
  consecutiveLosses?: number;
  riskProfile?: "CONSERVATIVE" | "BALANCED" | "AGGRESSIVE" | "RECOVERY";
}

/** Inputs accepted by the canonical decision-time feature builder. */
export type MetaFeatureInput = Omit<MetaFeatures, "session" | "dayOfWeek" | "hourOfDay" | "distFromFloorAbs">;

/**
 * Build a research feature vector only from facts available at decision time.
 * Time fields use America/New_York because Kalshi's BTC session analysis and
 * daily risk controls are ET-based. Keeping this mapping centralized makes
 * future backtests reproducible.
 */
export function buildMetaFeatures(input: MetaFeatureInput): MetaFeatures {
  const etParts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    weekday: "short",
    hour: "numeric",
    hourCycle: "h23",
  }).formatToParts(new Date(input.timestamp));
  const hour = Number(etParts.find(p => p.type === "hour")?.value ?? 0);
  const weekdayName = etParts.find(p => p.type === "weekday")?.value ?? "Sun";
  const dayOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(weekdayName);
  const session = hour >= 8 && hour < 12 ? "NY_AM"
    : hour >= 12 && hour < 17 ? "NY_PM"
    : hour >= 19 || hour < 2 ? "ASIA"
    : "OTHER";

  return {
    ...input,
    session,
    dayOfWeek: Math.max(0, dayOfWeek),
    hourOfDay: hour,
    distFromFloorAbs: Math.abs(input.distFromFloorPct),
  };
}

export interface MetaOutcome {
  wasTaken: boolean;
  fillPriceCents?: number;
  filledContracts?: number;
  feesPaidCents?: number;
  slippageCents?: number;
  settledITM?: boolean;
  exitReason?: string;
  pnlCents?: number;
  pnlAfterAllCosts?: number;
  holdTimeSec?: number;
  outcomeSource: MetaOutcomeSource;
  isReliableForLearning: boolean;
}

export interface MetaExample {
  id: string;
  features: MetaFeatures;
  outcome?: MetaOutcome;
  metaLabel?: MetaLabel;
  metaLabelReason?: string;
  createdAt: number;
  labeledAt?: number;
}

/**
 * Default training label:
 * 1 means this signal was worth taking after all known costs;
 * 0 means it was not.
 *
 * Unreliable or incomplete examples return 0 for API convenience, but callers
 * must use the reason/reliability flag to exclude them from a training set.
 */
export function computeMetaLabel(example: MetaExample): { label: MetaLabel; reason: string } {
  const { outcome } = example;

  if (!outcome || !outcome.isReliableForLearning) {
    return { label: 0, reason: "unreliable or missing outcome" };
  }

  const pnl = outcome.pnlAfterAllCosts ?? outcome.pnlCents;
  if (pnl === undefined || pnl === null) {
    return { label: 0, reason: "missing PnL" };
  }

  return pnl > 0
    ? { label: 1, reason: `positive net PnL (${pnl}¢)` }
    : { label: 0, reason: `non-positive net PnL (${pnl}¢)` };
}

/** Optional stricter label for high-confidence research datasets. */
export function computeStrictMetaLabel(
  example: MetaExample,
  minPnlCents = 2,
): { label: MetaLabel; reason: string } {
  const base = computeMetaLabel(example);
  if (base.label === 0) return base;

  const pnl = example.outcome?.pnlAfterAllCosts ?? example.outcome?.pnlCents ?? 0;
  return pnl >= minPnlCents
    ? { label: 1, reason: `PnL ${pnl}¢ ≥ ${minPnlCents}¢ threshold` }
    : { label: 0, reason: `PnL ${pnl}¢ below strict threshold` };
}

const MAX_EXAMPLES = 20_000;

/**
 * Small-account JSONL store. It rewrites atomically today; the public class
 * keeps the persistence boundary ready for append-and-compact at higher volume.
 */
export class JsonlMetaStore {
  private examples: MetaExample[] | null = null;

  constructor(
    private readonly filePath = path.join(process.cwd(), "data", "meta-examples.jsonl"),
    private readonly legacyFilePath = path.join(process.cwd(), "data", "meta-examples.json"),
  ) {}

  load(): MetaExample[] {
    if (this.examples) return this.examples;
    try {
      const raw = fs.readFileSync(this.filePath, "utf8");
      this.examples = raw.split(/\r?\n/)
      .filter(Boolean)
      .flatMap(line => {
        try {
          const parsed = JSON.parse(line) as MetaExample;
          return parsed?.id && parsed?.features ? [parsed] : [];
        } catch {
          return []; // A corrupt JSONL row must not prevent recovery of later rows.
        }
      });
  } catch {
    // One-time compatibility migration. Existing IDs must survive because an
    // in-flight OpenTrade may refer to one when it settles after a restart.
    try {
      const legacy = JSON.parse(fs.readFileSync(this.legacyFilePath, "utf8"));
      this.examples = Array.isArray(legacy) ? legacy.filter(row => row?.id && row?.features) : [];
    } catch {
      this.examples = [];
    }
    return this.examples!;
  }
  return this.examples!;
  }

  persist(): void {
    const rows = this.load();
    if (rows.length > MAX_EXAMPLES) rows.splice(0, rows.length - MAX_EXAMPLES);
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    // A complete temporary write followed by rename ensures a process crash
    // cannot leave the primary store half-written.
    const tempFile = `${this.filePath}.tmp`;
    const body = rows.map(row => JSON.stringify(row)).join("\n");
    fs.writeFileSync(tempFile, body ? `${body}\n` : "", "utf8");
    fs.renameSync(tempFile, this.filePath);
  }

  save(example: MetaExample): void {
    const rows = this.load();
    const index = rows.findIndex(row => row.id === example.id);
    if (index >= 0) rows[index] = example;
    else rows.push(example);
    this.persist();
  }

  get(id: string): MetaExample | undefined {
    return this.load().find(row => row.id === id);
  }

  list(): MetaExample[] {
    return this.load();
  }
}

const store = new JsonlMetaStore();
// Module-level shorthands so callers don't need to reference `store` directly.
const load    = (): MetaExample[]  => store.load();
const persist = (): void           => store.persist();

/** Capture an immutable decision-time feature vector for a trade that was filled. */
export function recordTakenMetaExample(features: MetaFeatures, outcome: Omit<MetaOutcome, "wasTaken">): string {
  const id = randomUUID();
  load().push({ id, features, outcome: { wasTaken: true, ...outcome }, createdAt: Date.now() });
  persist();
  return id;
}

/**
 * Record a complete entry decision exactly once. A rejected decision has no
 * counterfactual trade outcome, so it stays explicitly unreliable. For an
 * allowed decision this creates the stable ID later used by attachMetaOutcome.
 */
export function recordMetaDecision(
  features: MetaFeatures,
  opts: {
    allowed: boolean;
    finalContracts?: number;
    reasons?: string[];
    rejectionCode?: string;
  },
  targetStore: JsonlMetaStore = store,
): string {
  const id = randomUUID();
  targetStore.load().push({
    id,
    features,
    outcome: {
      wasTaken: opts.allowed,
      filledContracts: opts.allowed ? opts.finalContracts : 0,
      exitReason: opts.allowed ? undefined : opts.rejectionCode ?? "NOT_TAKEN",
      outcomeSource: "HEURISTIC",
      isReliableForLearning: false,
    },
    metaLabelReason: opts.allowed
      ? "decision allowed; awaiting fill and outcome"
      : opts.reasons?.length ? `skipped: ${opts.reasons.join("; ")}` : "skipped",
    createdAt: Date.now(),
  });
  targetStore.persist();
  return id;
}

/**
 * Decision logger for evaluated-but-not-taken entries (guard rejections, skips).
 * These records stay permanently unlabeled and unreliable: there is no honest
 * counterfactual outcome for a trade that was never placed. They exist so a
 * future meta-model / walk-forward engine can study the full decision
 * distribution, not just the survivor set of filled trades.
 */
export function recordSkippedMetaExample(features: MetaFeatures, guard: {
  proposedContracts?: number;
  reasons?: string[];
  rejectionCode?: string;
}, targetStore: JsonlMetaStore = store): string {
  return recordMetaDecision(features, { allowed: false, ...guard }, targetStore);
}

/** Export examples for research. reliableOnly filters to labeled, trustworthy rows. */
export function getMetaExamples(filter?: {
  fromTs?: number;
  toTs?: number;
  reliableOnly?: boolean;
  limit?: number;
}, targetStore: Pick<JsonlMetaStore, "load"> = store): MetaExample[] {
  let rows = targetStore.load().slice();
  if (filter?.fromTs !== undefined) rows = rows.filter(r => r.createdAt >= filter.fromTs!);
  if (filter?.toTs !== undefined) rows = rows.filter(r => r.createdAt <= filter.toTs!);
  if (filter?.reliableOnly) rows = rows.filter(r => r.outcome?.isReliableForLearning && r.labeledAt);
  if (filter?.limit !== undefined && rows.length > filter.limit) rows = rows.slice(-filter.limit);
  return rows;
}

/**
 * Label a record only after an authoritative settlement. The label answers the
 * research question: after all known costs, was taking this signal worthwhile?
 */
export function resolveTakenMetaExample(opts: {
  id?: string;
  ticker: string;
  openedAt: number;
  settledITM: boolean;
  pnlCents: number;
  exitReason: string;
  authoritative: boolean;
}): void {
  const row = opts.id
    ? load().find(x => x.id === opts.id)
    : load().filter(x => x.features.marketTicker === opts.ticker && x.outcome?.wasTaken && !x.labeledAt)
      .sort((a, b) => Math.abs(b.features.timestamp - opts.openedAt) - Math.abs(a.features.timestamp - opts.openedAt))[0];
  if (!row || row.labeledAt) return;

  row.outcome = {
    ...row.outcome,
    wasTaken: true,
    settledITM: opts.settledITM,
    pnlCents: opts.pnlCents,
    pnlAfterAllCosts: opts.pnlCents,
    exitReason: opts.exitReason,
    holdTimeSec: Math.max(0, Math.round((Date.now() - opts.openedAt) / 1000)),
    outcomeSource: opts.authoritative
      ? (opts.exitReason === "SETTLEMENT" || opts.exitReason === "SETTLED_KALSHI" ? "OFFICIAL_SETTLEMENT" : "EARLY_EXIT")
      : "HEURISTIC",
    isReliableForLearning: opts.authoritative,
  };
  if (opts.authoritative) {
    const label = computeMetaLabel(row);
    row.metaLabel = label.label;
    row.metaLabelReason = label.reason;
    row.labeledAt = Date.now();
  }
  persist();
}

/** Attach an authoritative settlement or clean exit to the exact saved decision. */
export function attachMetaOutcome(id: string, outcome: Partial<MetaOutcome> & {
  wasTaken: true;
  isReliableForLearning: boolean;
}): void {
  const row = load().find(example => example.id === id);
  if (!row) return;
  row.outcome = { ...row.outcome, ...outcome, wasTaken: true } as MetaOutcome;
  if (outcome.isReliableForLearning) {
    const label = computeMetaLabel(row);
    row.metaLabel = label.label;
    row.metaLabelReason = label.reason;
    row.labeledAt = Date.now();
  }
  persist();
}