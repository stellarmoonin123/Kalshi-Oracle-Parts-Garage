/**
 * kalshi-auth.test.ts
 *
 * Tests for normalisePem / loadPrivateKey / signKalshi / kalshiAuthHeaders and
 * the keyCompatible logic that powers GET /api/kalshi/config.  Run with:
 *
 *   node --experimental-strip-types src/lib/kalshi-auth.test.ts
 *
 * (Node ≥ 22.6 supports TypeScript stripping natively.)
 *
 * keyCompatible semantics (from kalshi.ts's GET /kalshi/config):
 *   normPem = normalisePem(storedKeyRaw)
 *   loadPrivateKey(normPem)                    // throws → keyCompatible = false
 *   keyCompatible = detectKeyFormat(storedKeyRaw) === "pkcs8"
 *
 * So PKCS#8 → true, PKCS#1 → false (including bare-base64 PKCS#1, which
 * detectKeyFormat() catches via real DER-structure validation — a plain
 * header-text check on normPem would NOT catch it, since normalisePem()
 * wraps any bare base64 in "BEGIN PRIVATE KEY" headers regardless of the
 * real underlying format), unloadable → false.
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";
import { normalisePem, loadPrivateKey, signKalshi, buildKalshiAuthHeaders, kalshiAuthHeaders, detectKeyFormat } from "./kalshi-auth.js";
import { buildKalshiWsAuthHeaders } from "./kalshi-ws.js";

// ── Generate two real RSA keypairs once for all tests ─────────────────────────
const { privateKey: pkcs8PemKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048,
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
  publicKeyEncoding:  { type: "spki",  format: "pem" },
});

const { privateKey: pkcs1PemKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048,
  privateKeyEncoding: { type: "pkcs1", format: "pem" },
  publicKeyEncoding:  { type: "spki",  format: "pem" },
});

// ── Helper: simulate the keyCompatible evaluation in kalshi.ts ────────────────
function evalKeyCompatible(storedKeyRaw: string): boolean {
  try {
    const normPem = normalisePem(storedKeyRaw);
    loadPrivateKey(normPem);
    return detectKeyFormat(storedKeyRaw) === "pkcs8";
  } catch {
    return false;
  }
}

// ── 1. Bare base64 PKCS#8 key → keyCompatible: true ─────────────────────────
test("bare base64 PKCS#8 key → keyCompatible true", () => {
  // Strip PEM headers and all whitespace to get bare base64
  const bareBase64 = pkcs8PemKey
    .replace(/-----[^-]+-----/g, "")
    .replace(/\s+/g, "");

  assert.ok(!bareBase64.startsWith("-----"), "should have no PEM headers");

  const normPem = normalisePem(bareBase64);
  assert.ok(
    normPem.includes("-----BEGIN PRIVATE KEY-----"),
    "normalisePem should wrap bare PKCS#8 base64 in PKCS#8 headers",
  );

  const compatible = evalKeyCompatible(bareBase64);
  assert.equal(compatible, true, "bare base64 PKCS#8 key should be compatible");
});

// ── 2. Fully-formed PKCS#8 PEM → keyCompatible: true ─────────────────────────
test("fully-formed PKCS#8 PEM → keyCompatible true", () => {
  assert.ok(
    pkcs8PemKey.includes("-----BEGIN PRIVATE KEY-----"),
    "fixture should be PKCS#8",
  );

  const compatible = evalKeyCompatible(pkcs8PemKey);
  assert.equal(compatible, true, "full PKCS#8 PEM should be compatible");
});

// ── 3. Escaped-newline env-var style PKCS#8 key → keyCompatible: true ────────
test("escaped-newline env-var style PKCS#8 key → keyCompatible true", () => {
  // Simulate how a multiline PEM gets stored in a .env / Replit Secret
  const escapedKey = pkcs8PemKey.replace(/\n/g, "\\n");

  assert.ok(escapedKey.includes("\\n"), "fixture should contain literal \\n");

  const normPem = normalisePem(escapedKey);
  assert.ok(
    normPem.includes("-----BEGIN PRIVATE KEY-----"),
    "normalisePem should restore escaped newlines",
  );

  const compatible = evalKeyCompatible(escapedKey);
  assert.equal(compatible, true, "escaped-newline PKCS#8 key should be compatible");
});

// ── 4. PKCS#1 PEM (BEGIN RSA PRIVATE KEY) → keyCompatible: false ─────────────
test("PKCS#1 PEM (BEGIN RSA PRIVATE KEY) → keyCompatible false", () => {
  assert.ok(
    pkcs1PemKey.includes("-----BEGIN RSA PRIVATE KEY-----"),
    "fixture should be PKCS#1",
  );

  // loadPrivateKey supports PKCS#1 via fallback, so it doesn't throw —
  // but normPem won't include "BEGIN PRIVATE KEY", so compatible = false.
  const compatible = evalKeyCompatible(pkcs1PemKey);
  assert.equal(compatible, false, "PKCS#1 PEM should not be compatible");
});

// ── 4b. Bare base64 PKCS#1 key (no PEM headers) → keyCompatible: false ───────
//
// This is the case a plain header-text check on normalisePem()'s output
// cannot catch: normalisePem() wraps ANY bare base64 body in
// "-----BEGIN PRIVATE KEY-----" headers by string shape alone, so a bare
// PKCS#1 RSAPrivateKey blob comes out looking like PKCS#8. detectKeyFormat()
// must inspect the real DER structure instead.
test("bare base64 PKCS#1 key (no PEM headers) → keyCompatible false", () => {
  const bareBase64 = pkcs1PemKey
    .replace(/-----[^-]+-----/g, "")
    .replace(/\s+/g, "");

  assert.ok(!bareBase64.startsWith("-----"), "should have no PEM headers");

  const normPem = normalisePem(bareBase64);
  assert.ok(
    normPem.includes("-----BEGIN PRIVATE KEY-----"),
    "normalisePem() mislabels bare-base64 PKCS#1 with PKCS#8 headers by shape alone",
  );
  assert.equal(
    detectKeyFormat(bareBase64), "pkcs1",
    "detectKeyFormat() must see through normalisePem()'s header guess to the real DER structure",
  );

  const compatible = evalKeyCompatible(bareBase64);
  assert.equal(compatible, false, "bare base64 PKCS#1 key must not be reported compatible");
});

// ── 5. Garbage string → keyCompatible: false ─────────────────────────────────
test("garbage string → keyCompatible false", () => {
  const garbage = "this-is-not-a-key-xyzzy-12345";
  const compatible = evalKeyCompatible(garbage);
  assert.equal(compatible, false, "garbage string should not be compatible");
});

// ── Bonus: normalisePem idempotency ──────────────────────────────────────────
test("normalisePem is idempotent on a PKCS#8 PEM", () => {
  const once  = normalisePem(pkcs8PemKey);
  const twice = normalisePem(once);
  assert.equal(once, twice, "normalising an already-normalised PEM should be a no-op");
});

test("normalisePem resolves escaped newlines in PKCS#1 PEM without altering type", () => {
  const escaped = pkcs1PemKey.replace(/\n/g, "\\n");
  const norm    = normalisePem(escaped);
  // Starts with PEM header, still PKCS#1
  assert.ok(norm.startsWith("-----BEGIN RSA PRIVATE KEY-----"));
});

// ── Signing failure tests — verify the path never silently falls back ─────────

// 7. signKalshi succeeds with a valid PKCS#8 key (happy path)
test("signKalshi returns a base64 signature with a valid PKCS#8 key", () => {
  const sig = signKalshi(pkcs8PemKey, Date.now().toString(), "POST", "/trade-api/v2/portfolio/events/orders");
  assert.ok(typeof sig === "string" && sig.length > 0, "signature should be a non-empty string");
  // Base64 characters only
  assert.match(sig, /^[A-Za-z0-9+/]+=*$/, "signature should be valid base64");
});

// 8. signKalshi throws on a garbage key — proves the order route cannot
//    silently proceed with an unauthenticated request when the key is bad.
test("signKalshi throws on a garbage private key", () => {
  assert.throws(
    () => signKalshi("this-is-not-a-key", Date.now().toString(), "POST", "/trade-api/v2/portfolio/events/orders"),
    (err: unknown) => err instanceof Error,
    "signKalshi must throw, not swallow, when the key cannot be loaded",
  );
});

// 9. kalshiAuthHeaders throws when env credentials are set but the key is invalid.
//    This confirms the signing error propagates instead of returning bare headers.
test("kalshiAuthHeaders throws when oraclekey is garbage", () => {
  const saved = { id: process.env.oracle, key: process.env.oraclekey };
  process.env.oracle         = "test-key-id";
  process.env.oraclekey = "not-a-real-key";
  try {
    assert.throws(
      () => kalshiAuthHeaders("POST", "/trade-api/v2/portfolio/events/orders"),
      (err: unknown) => err instanceof Error,
      "kalshiAuthHeaders must throw on a bad private key, not return unauthenticated headers",
    );
  } finally {
    // Always restore env regardless of assertion outcome
    if (saved.id === undefined) delete process.env.oracle;
    else process.env.oracle = saved.id;
    if (saved.key === undefined) delete process.env.oraclekey;
    else process.env.oraclekey = saved.key;
  }
});

// 10. kalshiAuthHeaders returns empty object when no credentials are set —
//     no credentials → no auth → empty headers (not an error).
test("kalshiAuthHeaders returns empty object when no credentials are configured", () => {
  const saved = { id: process.env.oracle, key: process.env.oraclekey };
  delete process.env.oracle;
  delete process.env.oraclekey;
  try {
    const headers = kalshiAuthHeaders("GET", "/trade-api/v2/markets");
    assert.deepStrictEqual(headers, {}, "should return empty object when no credentials are set");
  } finally {
    if (saved.id !== undefined)  process.env.oracle          = saved.id;
    if (saved.key !== undefined) process.env.oraclekey  = saved.key;
  }
});

// ── Timestamp regression guards ───────────────────────────────────────────────
//
// Kalshi accepts UNIX seconds here, not JavaScript's epoch milliseconds. Keep
// the check strict enough to reject a 13-digit millisecond value immediately,
// while allowing the small amount of time spent signing the request.
function assertUnixSecondsTimestamp(headers: Record<string, string>, source: string): void {
  const timestamp = headers["KALSHI-ACCESS-TIMESTAMP"];
  assert.ok(timestamp, `${source} should include KALSHI-ACCESS-TIMESTAMP`);
  assert.match(timestamp, /^\d{10}$/, `${source} timestamp must be a 10-digit UNIX-seconds value`);
  const nowSeconds = Math.floor(Date.now() / 1000);
  assert.ok(
    Math.abs(Number(timestamp) - nowSeconds) <= 30,
    `${source} timestamp must be within 30 seconds of current UNIX time`,
  );
}

function withAuthEnv<T>(fn: () => T): T {
  const saved = { id: process.env.oracle, key: process.env.oraclekey };
  process.env.oracle = "timestamp-test-key-id";
  process.env.oraclekey = pkcs8PemKey;
  try {
    return fn();
  } finally {
    if (saved.id === undefined) delete process.env.oracle;
    else process.env.oracle = saved.id;
    if (saved.key === undefined) delete process.env.oraclekey;
    else process.env.oraclekey = saved.key;
  }
}

test("kalshiAuthHeaders uses a current UNIX-seconds timestamp", () => {
  withAuthEnv(() => {
    const headers = kalshiAuthHeaders("GET", "/trade-api/v2/markets");
    assertUnixSecondsTimestamp(headers, "REST auth headers");
  });
});

test("explicit Kalshi route credentials use a current UNIX-seconds timestamp", () => {
  const headers = buildKalshiAuthHeaders(
    "route-timestamp-test-key-id",
    pkcs8PemKey,
    "POST",
    "/trade-api/v2/portfolio/events/orders",
  );
  assertUnixSecondsTimestamp(headers, "explicit-credential auth headers");
});

test("Kalshi WebSocket auth headers use a current UNIX-seconds timestamp", async () => {
  const saved = { id: process.env.oracle, key: process.env.oraclekey };
  process.env.oracle = "timestamp-test-ws-key-id";
  process.env.oraclekey = pkcs8PemKey;
  try {
    const headers = await buildKalshiWsAuthHeaders();
    assertUnixSecondsTimestamp(headers, "WebSocket auth headers");
  } finally {
    if (saved.id === undefined) delete process.env.oracle;
    else process.env.oracle = saved.id;
    if (saved.key === undefined) delete process.env.oraclekey;
    else process.env.oraclekey = saved.key;
  }
});
