/**
 * advice-observe.ts — OBSERVE-only helpers from public 15m research.
 *
 * Not strategies. Never ENABLE. LIVE_APPLY false. paperMode true.
 * Do not cut EV 3¢ / Kelly 0.60 / 9% / 15% reserve.
 *
 *   dead zone     — skip NEW entries in last 120s (OddsShopper / WagerTalk / Gillett)
 *   dual-ask <98  — YES+NO ask sum (kalshibot structural; OBSERVE, not a take)
 *   late NO chase — do not fade/buy NO into late drift (ContractTax / Turbine)
 *   spot lag 3–30s lives in lag-meter.ts (not duplicated)
 */
export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;

/** Skip NEW entries in the last 2 minutes. Existing positions may still exit. */
export const DEAD_ZONE_SECS = 120;
/** kalshibot dual-side structural: YES_ask + NO_ask < $0.98. OBSERVE only. */
export const DUAL_ASK_SUM_MAX_CENTS = 98;
/** Do not chase / fade NO in the last 3 minutes (Turbine: do not buy NO late). */
export const LATE_NO_CHASE_SECS = 180;

export function isDeadZone(secsRemaining: number | null | undefined): boolean {
  return typeof secsRemaining === "number" && Number.isFinite(secsRemaining) && secsRemaining <= DEAD_ZONE_SECS;
}

export function dualAskSumCents(yesAsk: number | null | undefined, noAsk: number | null | undefined): number | null {
  if (typeof yesAsk !== "number" || typeof noAsk !== "number") return null;
  if (!Number.isFinite(yesAsk) || !Number.isFinite(noAsk)) return null;
  return yesAsk + noAsk;
}

export function dualAskUnder98(yesAsk: number | null | undefined, noAsk: number | null | undefined): boolean {
  const sum = dualAskSumCents(yesAsk, noAsk);
  return sum != null && sum < DUAL_ASK_SUM_MAX_CENTS;
}

/** True when fading/buying NO this close to expiry would be a late-NO chase. */
export function isLateNoChase(side: "yes" | "no" | "YES" | "NO", secsRemaining: number): boolean {
  const s = typeof side === "string" ? side.toLowerCase() : "";
  if (s !== "no") return false;
  return Number.isFinite(secsRemaining) && secsRemaining < LATE_NO_CHASE_SECS;
}
