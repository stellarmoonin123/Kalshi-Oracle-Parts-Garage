/**
 * Desk identity — FLY vs LOCAL. Two paper books; never imply they share a ledger.
 * Observational. Does not ENABLE or cut floors.
 */

export type DeskIdentityKind = "FLY" | "LOCAL";

export function resolveDeskIdentity(env: NodeJS.ProcessEnv = process.env): {
  kind: DeskIdentityKind;
  label: string;
  publicUrl: string | null;
  hostname: string | null;
  reason: string;
} {
  const explicit = (env.DESK_IDENTITY ?? "").trim().toUpperCase();
  if (explicit === "FLY" || explicit === "LOCAL") {
    return {
      kind: explicit,
      label: explicit,
      publicUrl: env.PUBLIC_URL ?? null,
      hostname: env.HOSTNAME ?? null,
      reason: "DESK_IDENTITY",
    };
  }
  if (env.FLY_APP_NAME || env.FLY_ALLOC_ID || env.FLY_REGION) {
    return {
      kind: "FLY",
      label: "FLY",
      publicUrl: env.PUBLIC_URL ?? (env.FLY_APP_NAME ? `https://${env.FLY_APP_NAME}.fly.dev` : null),
      hostname: env.HOSTNAME ?? null,
      reason: "FLY_* env",
    };
  }
  const pub = (env.PUBLIC_URL ?? "").toLowerCase();
  if (pub.includes("fly.dev") || pub.includes("fly.io")) {
    return {
      kind: "FLY",
      label: "FLY",
      publicUrl: env.PUBLIC_URL ?? null,
      hostname: env.HOSTNAME ?? null,
      reason: "PUBLIC_URL fly",
    };
  }
  return {
    kind: "LOCAL",
    label: "LOCAL",
    publicUrl: env.PUBLIC_URL ?? null,
    hostname: env.HOSTNAME ?? null,
    reason: "default local",
  };
}
