/**
 * market-learning-v4.ts — GO: MARKET-LEARNING v4.1 (PhD RESEARCH PLANE,
 * SHADOW ONLY), 2026-08-24.
 *
 * Builds a real model (logistic regression + isotonic calibration, purged
 * walk-forward evaluation, a deterministic POLICY_LEAN baseline replay) on
 * top of market-learning-v2.ts's state machine, canary envelope, and
 * pass/fail plumbing — none of which this file touches or duplicates.
 * Read docs/market-learning-v4.1.md FIRST; this file implements exactly what
 * that document commits to, in the same order.
 *
 * ── Locks (do not touch from this file) ────────────────────────────────
 * Same as market-learning-v2.ts's header: live EV/PATH_GATE, packs,
 * consensus, quarantine, minConfidence values; BRTI/MTF/SAKATA/OTM
 * enablement; any auto shadow→canary trigger; any BotConfig write; no
 * `/apply` call anywhere in this file. `learning_state.mode` is read-only
 * here (via market-learning-v2.ts's getLearningState()).
 *
 * ── Why trading-bot.ts is never imported here ──────────────────────────
 * trading-bot.ts is a large stateful module with import-time side effects
 * (Kalshi WS connections, timers). Importing it from this research module
 * would create a live-plane dependency this shadow-only plane must never
 * have, and (per market-learning.ts's own header, and
 * .agents/memory/node-test-import-isolation.md) risks reviving the bot
 * singleton / hanging test processes via a circular import
 * (trading-bot.ts -> market-learning.ts -> market-learning-v4.ts ->
 * trading-bot.ts). `computeVolumeState` below is therefore a deliberate,
 * small, pure-function duplicate of trading-bot.ts's own (~line 1399),
 * and `LIVE_EV_FLOOR_CENTS_MIRROR_V4` duplicates trading-bot.ts's
 * `export const EV_FLOOR = 3` — kept in sync by the static (no-import)
 * parity check in market-learning-v4.test.ts.
 */

import { createHash } from "node:crypto";
import { db, marketObservations, shadowDecisions } from "@workspace/db";
import { and, eq, isNotNull, isNull, sql } from "drizzle-orm";
import { computeTradeEV } from "./trade-path.js";
import { computeVolumeScore } from "./volume-risk.js";
import { computeATRPct } from "./market-intelligence.js";
import type { StrategyObservation } from "./strategy-library.js";
import { getLearningState } from "./market-learning-v2.js";
import { POLICY_LEAN } from "./backtest-lab-v5/sim-policy.js";
import { runPolicyOverPeriods, groupIntoPeriods, type SimTrade } from "./backtest-lab-v5/causal-sim.js";
import { fetchRealCandles } from "./market-candles.js";

export const V4_MODEL_VERSION = "logistic-v4.1";

// Mirrors trading-bot.ts's `export const EV_FLOOR = 3;` (~line 1809). See
// file header for why this is duplicated rather than imported. Kept
// numerically honest by a static-source-text parity check in the test file
// (never by importing trading-bot.ts).
export const LIVE_EV_FLOOR_CENTS_MIRROR_V4 = 3;

/** Every feature the v4.1 model is allowed to see — nothing settlement-derived. Mirrors docs/market-learning-v4.1.md §2. */
export const REQUIRED_FEATURES = [
  "basisValue", "basisStreakSign", "basisStreakLen", "leadExchangeDelta",
  "distFromFloorPct", "secsRemaining", "yesAskCents", "noAskCents",
  "spreadCents", "volumeScoreLive", "sessionLabel",
] as const;

export const ABLATION_FEATURES = ["mtfScore", "candlePattern"] as const;

export type TimeBucket = "12-8m" | "8-3m" | "<3m";

/** Single source of truth for the three time buckets docs/market-learning-v4.1.md §2 requires be calibrated separately. */
export function timeBucketFor(secsRemaining: number): TimeBucket {
  if (secsRemaining > 480) return "12-8m";
  if (secsRemaining > 180) return "8-3m";
  return "<3m";
}

// ── Live-parity volumeScore (v3 gap-fix folded into v4.1, see docs §0) ─────

/**
 * Calls the REAL live `computeVolumeScore()` from volume-risk.ts — the exact
 * function trading-bot.ts uses for sizing — fed with the minimal set of
 * fields it actually reads. `prices`/`velocityDolPerMin` must come from the
 * SAME live buffers trading-bot.ts already maintains (passed in by the
 * caller, e.g. `this.prices`/`this.currentVelocity` at the recordMarketObservation
 * call site); this function does not fetch or approximate them itself.
 */
export function computeLiveVolumeScore(input: {
  prices: { price: number; ts: number }[];
  velocityDolPerMin: number;
  yesAskCents: number | null;
  yesBidCents: number | null;
}): number {
  const volumeState = computeVolumeState(input.prices);
  const atrPct = computeATRPct(input.prices as any);
  const minimalObs: Partial<StrategyObservation> = {
    volumeState,
    velocityDolPerMin: input.velocityDolPerMin,
    atrPct: Number.isFinite(atrPct) ? atrPct : undefined,
    yesAsk: input.yesAskCents ?? undefined,
    yesBid: input.yesBidCents ?? undefined,
  };
  return computeVolumeScore(minimalObs as StrategyObservation).V;
}

const VOLUME_HIGH_RATIO = 1.6;
const VOLUME_LOW_RATIO = 0.55;

/** Deliberate small pure-function duplicate of trading-bot.ts's computeVolumeState — see file header for why. */
function computeVolumeState(prices: { price: number; ts: number }[]): "low" | "normal" | "high" {
  if (prices.length < 8) return "normal";
  const speeds: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    const dt = (prices[i].ts - prices[i - 1].ts) / 1000;
    if (dt > 0 && dt < 30) speeds.push(Math.abs(prices[i].price - prices[i - 1].price) / dt);
  }
  if (speeds.length < 4) return "normal";
  const allAvg = speeds.reduce((a, b) => a + b, 0) / speeds.length;
  if (allAvg < 0.01) return "normal";
  const recentWindow = speeds.slice(-Math.max(4, Math.floor(speeds.length / 4)));
  const recentAvg = recentWindow.reduce((a, b) => a + b, 0) / recentWindow.length;
  const ratio = recentAvg / allAvg;
  return ratio > VOLUME_HIGH_RATIO ? "high" : ratio < VOLUME_LOW_RATIO ? "low" : "normal";
}

// ── Logistic regression (standardized features, L2-regularized gradient descent) ──

export interface StandardizeStats { means: number[]; stds: number[]; }

export function fitStandardizeStats(rows: number[][]): StandardizeStats {
  const nFeat = rows[0]?.length ?? 0;
  const means = new Array(nFeat).fill(0);
  const stds = new Array(nFeat).fill(1);
  if (rows.length === 0) return { means, stds };
  for (let j = 0; j < nFeat; j++) {
    const col = rows.map(r => r[j]);
    const mean = col.reduce((a, b) => a + b, 0) / col.length;
    const variance = col.reduce((a, b) => a + (b - mean) ** 2, 0) / col.length;
    means[j] = mean;
    stds[j] = Math.sqrt(variance) || 1; // avoid divide-by-zero on a constant column
  }
  return { means, stds };
}

export function applyStandardize(row: number[], stats: StandardizeStats): number[] {
  return row.map((v, j) => (v - stats.means[j]) / stats.stds[j]);
}

export function sigmoid(z: number): number {
  if (z >= 0) { const ez = Math.exp(-z); return 1 / (1 + ez); }
  const ez = Math.exp(z); return ez / (1 + ez);
}

export interface LogisticModel { weights: number[]; bias: number; }

/**
 * Plain batch gradient descent with L2 regularization — no external ML
 * dependency. Small feature count (<=13) and modest expected row counts
 * make this cheap; correctness (a real, monotone-decreasing loss) matters
 * more than optimizer sophistication here.
 */
export function trainLogisticRegression(
  X: number[][], y: number[],
  opts: { l2?: number; lr?: number; iters?: number } = {},
): LogisticModel {
  const { l2 = 1e-3, lr = 0.2, iters = 500 } = opts;
  const n = X.length;
  const nFeat = X[0]?.length ?? 0;
  let weights = new Array(nFeat).fill(0);
  let bias = 0;
  if (n === 0 || nFeat === 0) return { weights, bias };

  for (let iter = 0; iter < iters; iter++) {
    const gradW = new Array(nFeat).fill(0);
    let gradB = 0;
    for (let i = 0; i < n; i++) {
      const z = X[i].reduce((s, x, j) => s + x * weights[j], bias);
      const p = sigmoid(z);
      const err = p - y[i];
      for (let j = 0; j < nFeat; j++) gradW[j] += err * X[i][j];
      gradB += err;
    }
    for (let j = 0; j < nFeat; j++) {
      weights[j] -= lr * (gradW[j] / n + l2 * weights[j]);
    }
    bias -= lr * (gradB / n);
  }
  return { weights, bias };
}

export function predictLogit(model: LogisticModel, xStd: number[]): number {
  const z = xStd.reduce((s, x, j) => s + x * model.weights[j], model.bias);
  return sigmoid(z);
}

// ── Isotonic calibration (pool-adjacent-violators) ─────────────────────────

export interface IsotonicCalibrator { xs: number[]; ys: number[]; }

/**
 * Fits a monotone-nondecreasing step function mapping raw score -> calibrated
 * probability via PAV, on (score, outcome) pairs — meant to be fit on purged
 * OOS predictions, never on in-sample training predictions (that would
 * calibrate a model to its own overfit, not to reality).
 */
export function fitIsotonic(pairs: { x: number; y: number }[]): IsotonicCalibrator {
  if (pairs.length === 0) return { xs: [0, 1], ys: [0.5, 0.5] };
  const sorted = [...pairs].sort((a, b) => a.x - b.x);
  // PAV via a stack of (sum, weight, x) blocks.
  const blocks: { sum: number; weight: number; xMin: number; xMax: number }[] = [];
  for (const p of sorted) {
    let block = { sum: p.y, weight: 1, xMin: p.x, xMax: p.x };
    blocks.push(block);
    while (blocks.length > 1) {
      const last = blocks[blocks.length - 1];
      const prev = blocks[blocks.length - 2];
      if (prev.sum / prev.weight > last.sum / last.weight) {
        blocks.pop(); blocks.pop();
        blocks.push({ sum: prev.sum + last.sum, weight: prev.weight + last.weight, xMin: prev.xMin, xMax: last.xMax });
      } else break;
    }
  }
  const xs: number[] = [];
  const ys: number[] = [];
  for (const b of blocks) { xs.push(b.xMax); ys.push(Math.max(0, Math.min(1, b.sum / b.weight))); }
  return { xs, ys };
}

/** Step-function lookup (nearest x <= query; below range clamps to the first bucket, above clamps to the last). */
export function applyIsotonic(cal: IsotonicCalibrator, x: number): number {
  let idx = cal.xs.findIndex(xi => x <= xi);
  if (idx === -1) idx = cal.xs.length - 1;
  return cal.ys[idx];
}

// ── Purged walk-forward folds with embargo ─────────────────────────────────

export interface WalkForwardRow { periodStartMs: number; features: number[]; label: number; }
export interface PurgedFold { trainIdx: number[]; oosIdx: number[]; }

/**
 * Sequential expanding-window folds (same shape as
 * backtest-lab-v5/validation.ts's sequentialOosFolds), extended with an
 * embargo: rows within `embargoPeriods` period-widths of the train/OOS
 * boundary on EITHER side are dropped from both, not just excluded from
 * train. This did not exist anywhere in the codebase before v4.1 — the
 * existing sequentialOosFolds has no purge/embargo logic (see
 * docs/market-learning-v4.1.md §4).
 */
export function purgedWalkForwardFolds(
  rows: WalkForwardRow[], k = 3, embargoPeriods = 1, periodWidthMs = 15 * 60_000,
): PurgedFold[] {
  if (rows.length < k * 2) return [{ trainIdx: [], oosIdx: rows.map((_, i) => i) }];
  const order = rows.map((_, i) => i).sort((a, b) => rows[a].periodStartMs - rows[b].periodStartMs);
  const foldSize = Math.floor(order.length / k);
  const embargoMs = embargoPeriods * periodWidthMs;
  const folds: PurgedFold[] = [];
  for (let i = 0; i < k; i++) {
    const start = i * foldSize;
    const end = i === k - 1 ? order.length : start + foldSize;
    const oosIdx = order.slice(start, end);
    if (oosIdx.length === 0) continue;
    const oosMinTs = Math.min(...oosIdx.map(idx => rows[idx].periodStartMs));
    const oosMaxTs = Math.max(...oosIdx.map(idx => rows[idx].periodStartMs));
    const trainIdx = order.slice(0, start).filter(idx =>
      rows[idx].periodStartMs < oosMinTs - embargoMs || rows[idx].periodStartMs > oosMaxTs + embargoMs
    );
    folds.push({ trainIdx, oosIdx });
  }
  return folds;
}

// ── Trained per-bucket model cache ──────────────────────────────────────────

interface BucketModel {
  n: number;
  logistic: LogisticModel;
  stats: StandardizeStats;
  isotonic: IsotonicCalibrator;
  oosEce: number; // expected calibration error on the pooled purged-OOS predictions
}

const MIN_BUCKET_N = 30;
const REFRESH_MS = 5 * 60_000;

const bucketModels = new Map<TimeBucket, BucketModel>();

function featureRowFrom(o: {
  basisValue: number | null; basisStreakSign: number | null; basisStreakLen: number | null;
  leadExchangeDelta: number | null; distFromFloorPct: number | null; secsRemaining: number;
  yesAskCents: number | null; noAskCents: number | null; spreadCents: number | null;
  volumeScoreLive: number | null; sessionLabel: string | null;
}): number[] | null {
  // Every required feature must be present — a partial row would silently
  // bias the model toward whichever features happen to be null-heavy.
  if (o.basisValue == null || o.leadExchangeDelta == null || o.distFromFloorPct == null ||
      o.yesAskCents == null || o.noAskCents == null || o.spreadCents == null || o.volumeScoreLive == null) {
    return null;
  }
  const sessionOneHot = ["asia", "london", "newyork", "dead"].map(s => (o.sessionLabel === s ? 1 : 0));
  return [
    o.basisValue, o.basisStreakSign ?? 0, o.basisStreakLen ?? 0, o.leadExchangeDelta,
    o.distFromFloorPct, o.secsRemaining, o.yesAskCents, o.noAskCents,
    o.spreadCents, o.volumeScoreLive, ...sessionOneHot,
  ];
}

function eceOf(pairs: { p: number; y: number }[], nBins = 10): number {
  if (pairs.length === 0) return 0;
  let ece = 0;
  for (let b = 0; b < nBins; b++) {
    const lo = b / nBins, hi = (b + 1) / nBins;
    const inBin = pairs.filter(p => p.p >= lo && p.p < hi || (b === nBins - 1 && p.p === 1));
    if (inBin.length === 0) continue;
    const avgP = inBin.reduce((s, p) => s + p.p, 0) / inBin.length;
    const avgY = inBin.reduce((s, p) => s + p.y, 0) / inBin.length;
    ece += (inBin.length / pairs.length) * Math.abs(avgP - avgY);
  }
  return ece;
}

/**
 * Trains one logistic model + isotonic calibrator per time bucket, from
 * resolved market_observations rows with every REQUIRED_FEATURES column
 * present. Calibration is fit on POOLED purged-OOS predictions across
 * purgedWalkForwardFolds (never on in-sample predictions); the final
 * production logistic model is refit on all of that bucket's rows (standard
 * practice: final params from all data, calibration mapping from honest OOS
 * predictions only).
 */
export async function refreshShadowModelsV4(): Promise<void> {
  try {
    const rows = await db.select({
      periodOpenTs: marketObservations.periodOpenTs,
      secsRemaining: marketObservations.secsRemaining,
      basisValue: marketObservations.basisValue,
      basisStreakSign: marketObservations.basisStreakSign,
      basisStreakLen: marketObservations.basisStreakLen,
      leadExchangeDelta: marketObservations.leadExchangeDelta,
      distFromFloorPct: marketObservations.distFromFloorPct,
      yesAskCents: marketObservations.yesAskCents,
      noAskCents: marketObservations.noAskCents,
      spreadCents: marketObservations.spreadCents,
      volumeScoreLive: marketObservations.volumeScoreLive,
      sessionLabel: marketObservations.sessionLabel,
      settledDirection: marketObservations.settledDirection,
    }).from(marketObservations)
      .where(and(isNotNull(marketObservations.settledDirection), isNotNull(marketObservations.volumeScoreLive)));

    const byBucket = new Map<TimeBucket, WalkForwardRow[]>();
    for (const r of rows) {
      const features = featureRowFrom(r);
      if (!features) continue;
      const bucket = timeBucketFor(r.secsRemaining);
      const arr = byBucket.get(bucket) ?? [];
      arr.push({ periodStartMs: r.periodOpenTs.getTime(), features, label: r.settledDirection === "up" ? 1 : 0 });
      byBucket.set(bucket, arr);
    }

    for (const bucket of ["12-8m", "8-3m", "<3m"] as TimeBucket[]) {
      const bucketRows = byBucket.get(bucket) ?? [];
      if (bucketRows.length < MIN_BUCKET_N) { bucketModels.delete(bucket); continue; }

      const stats = fitStandardizeStats(bucketRows.map(r => r.features));
      const folds = purgedWalkForwardFolds(bucketRows, 3, 1);
      const oosPairs: { p: number; y: number }[] = [];
      for (const fold of folds) {
        if (fold.trainIdx.length < 5 || fold.oosIdx.length === 0) continue;
        const trainX = fold.trainIdx.map(i => applyStandardize(bucketRows[i].features, stats));
        const trainY = fold.trainIdx.map(i => bucketRows[i].label);
        const foldModel = trainLogisticRegression(trainX, trainY);
        for (const i of fold.oosIdx) {
          const p = predictLogit(foldModel, applyStandardize(bucketRows[i].features, stats));
          oosPairs.push({ p, y: bucketRows[i].label });
        }
      }
      const isotonic = fitIsotonic(oosPairs.map(p => ({ x: p.p, y: p.y })));
      const oosEce = eceOf(oosPairs.map(p => ({ p: applyIsotonic(isotonic, p.p), y: p.y })));

      const finalX = bucketRows.map(r => applyStandardize(r.features, stats));
      const finalY = bucketRows.map(r => r.label);
      const logistic = trainLogisticRegression(finalX, finalY);

      bucketModels.set(bucket, { n: bucketRows.length, logistic, stats, isotonic, oosEce });
    }
  } catch (err) {
    console.warn("[market-learning-v4] model refresh failed:", (err as Error).message);
  }
}

/** Sync, hot-path-safe — reads the in-memory model cache only. Returns null when the bucket has no trained model yet (n < MIN_BUCKET_N) — caller must force SKIP but still log the raw proposal is not possible without a model, so this IS the "insufficient data" signal itself. */
export function predictPUpV4(features: number[], secsRemaining: number): { pModel: number; pUp: number; n: number } | null {
  const bucket = timeBucketFor(secsRemaining);
  const model = bucketModels.get(bucket);
  if (!model) return null;
  const xStd = applyStandardize(features, model.stats);
  const pModel = predictLogit(model.logistic, xStd);
  const pUp = applyIsotonic(model.isotonic, pModel);
  return { pModel, pUp, n: model.n };
}

export function getBucketModelSummary(): Array<{ bucket: TimeBucket; n: number; oosEce: number }> {
  return (["12-8m", "8-3m", "<3m"] as TimeBucket[])
    .filter(b => bucketModels.has(b))
    .map(b => ({ bucket: b, n: bucketModels.get(b)!.n, oosEce: bucketModels.get(b)!.oosEce }));
}

/**
 * Deterministic sha256 (16 hex chars) over every trained coefficient
 * currently in memory (logistic weights+bias, standardize means/stds,
 * isotonic breakpoints, per-bucket n) plus REQUIRED_FEATURES and
 * V4_MODEL_VERSION. Two calls return the same hash iff the model that would
 * be used to score a live decision right now is byte-identical — this is
 * the model-promotion protocol's G9 anti-swap check (model-promotion.ts),
 * not a general model-identity fingerprint. Returns a stable
 * "no-model-loaded" hash when bucketModels is empty so G9 fails closed
 * rather than throwing.
 */
export function computeModelHashV4(): string {
  const parts = (["12-8m", "8-3m", "<3m"] as TimeBucket[]).map(b => {
    const m = bucketModels.get(b);
    if (!m) return `${b}:none`;
    return `${b}:n=${m.n}:w=${m.logistic.weights.join(",")}:bias=${m.logistic.bias}` +
      `:means=${m.stats.means.join(",")}:stds=${m.stats.stds.join(",")}` +
      `:iso_xs=${m.isotonic.xs.join(",")}:iso_ys=${m.isotonic.ys.join(",")}`;
  });
  const material = `${V4_MODEL_VERSION}|${REQUIRED_FEATURES.join(",")}|${parts.join("|")}`;
  return createHash("sha256").update(material).digest("hex").slice(0, 16);
}

/** sha256 (16 hex chars) of REQUIRED_FEATURES alone — changes only when the feature contract itself changes, independent of retraining. Part of the G9 audit row, kept separate from computeModelHashV4 so a feature-list change is distinguishable from an ordinary retrain in the audit ledger. */
export function computeFeatureListHashV4(): string {
  return createHash("sha256").update(REQUIRED_FEATURES.join(",")).digest("hex").slice(0, 16);
}

// ── v4.1 shadow decision (separate from v2's bucket-lookup decision) ───────

export type ShadowActionV4 = "TAKE_BASE" | "TAKE_PROBE" | "SKIP";

export interface ShadowDecisionV4Input {
  ticker: string;
  periodOpenTs: Date;
  secsRemaining: number;
  yesAskCents: number | null;
  noAskCents: number | null;
  basisValue: number | null;
  basisStreakSign: number | null;
  basisStreakLen: number | null;
  leadExchangeDelta: number | null;
  distFromFloorPct: number | null;
  spreadCents: number | null;
  volumeScoreLive: number | null;
  sessionLabel: string | null;
}

export interface ShadowDecisionV4Result {
  pModel: number | null;
  pUpV4: number | null;
  evYesCents: number | null;
  evNoCents: number | null;
  actionV4: ShadowActionV4;
  intendedSizeMult: 0 | 0.5 | 1.0;
  sampleSize: number;
}

/**
 * Pure function, mirrors market-learning-v2.ts's computeShadowDecision shape
 * but reports EV_yes/EV_no separately and forces SKIP under data
 * insufficiency (per docs §3's uncertainty rule) while STILL returning the
 * raw unrestricted pModel/pUpV4 for research visibility.
 */
export function computeShadowDecisionV4(input: ShadowDecisionV4Input): ShadowDecisionV4Result | null {
  if (input.yesAskCents == null || input.noAskCents == null) return null;
  const features = featureRowFrom(input);
  const prediction = features ? predictPUpV4(features, input.secsRemaining) : null;

  if (!prediction || prediction.n < MIN_BUCKET_N) {
    return {
      pModel: prediction?.pModel ?? null, pUpV4: prediction?.pUp ?? null,
      evYesCents: null, evNoCents: null, actionV4: "SKIP", intendedSizeMult: 0,
      sampleSize: prediction?.n ?? 0,
    };
  }

  const { pUp, pModel, n } = prediction;
  const evYes = computeTradeEV({ entryPriceCents: input.yesAskCents, winRate: pUp, secsRemaining: input.secsRemaining, spreadCents: input.spreadCents ?? undefined });
  const evNo = computeTradeEV({ entryPriceCents: input.noAskCents, winRate: 1 - pUp, secsRemaining: input.secsRemaining, spreadCents: input.spreadCents ?? undefined });

  const bestEV = Math.max(evYes.netEV, evNo.netEV);
  let actionV4: ShadowActionV4 = "SKIP";
  let intendedSizeMult: 0 | 0.5 | 1.0 = 0;
  if (bestEV >= LIVE_EV_FLOOR_CENTS_MIRROR_V4 * 2) { actionV4 = "TAKE_BASE"; intendedSizeMult = 1.0; }
  else if (bestEV >= LIVE_EV_FLOOR_CENTS_MIRROR_V4) { actionV4 = "TAKE_PROBE"; intendedSizeMult = 0.5; }

  return {
    pModel, pUpV4: pUp,
    evYesCents: evYes.netEV, evNoCents: evNo.netEV,
    actionV4, intendedSizeMult, sampleSize: n,
  };
}

/**
 * Updates the SAME shadow_decisions row market-learning-v2.ts's
 * maybeLogShadowDecision already inserted for this ticker+period (unique
 * index on ticker+periodOpenTs) with v4.1's own fields. Never inserts a
 * second row, never overwrites v2's original pUp/action/evHatCents columns
 * — the two model outputs are stored side by side for honest comparison.
 * Fire-and-forget, swallows its own errors.
 */
export async function maybeLogShadowDecisionV4(input: ShadowDecisionV4Input): Promise<void> {
  try {
    const decision = computeShadowDecisionV4(input);
    if (!decision) return;
    await db.update(shadowDecisions).set({
      pModel: decision.pModel,
      pUpV4: decision.pUpV4,
      evYesCents: decision.evYesCents,
      evNoCents: decision.evNoCents,
      actionV4: decision.actionV4,
      intendedSizeMult: decision.intendedSizeMult,
      modelVersion: V4_MODEL_VERSION,
    }).where(and(eq(shadowDecisions.ticker, input.ticker), eq(shadowDecisions.periodOpenTs, input.periodOpenTs)));
  } catch (err) {
    console.warn("[market-learning-v4] shadow decision v4 log failed:", (err as Error).message);
  }
}

// ── LEAN baseline replay (v2→v4.1 gap fix — see docs §1) ───────────────────

export interface LeanReplayResult {
  coveragePct: number;
  trades: SimTrade[];
  matchedPeriods: number;
  totalOurPeriods: number;
}

/**
 * Deterministically replays POLICY_LEAN over real (non-interpolated) 5-min
 * candles covering `ourPeriodOpenTsMs`'s span, using the FULL fetched
 * series (not just each period's own 3 candles) so causal-sim's
 * lookback-dependent features (regime classification, MTF proxy SMA) see
 * real prior history — never a single isolated period in a vacuum. Matches
 * our periods to the causal-sim's own grouped periods by exact
 * periodStartMs; any of ours with no match is excluded and counted against
 * coveragePct, never silently dropped without a trace.
 */
export async function computeLeanBaseline(ourPeriodOpenTsMs: number[]): Promise<LeanReplayResult> {
  if (ourPeriodOpenTsMs.length === 0) return { coveragePct: 0, trades: [], matchedPeriods: 0, totalOurPeriods: 0 };

  const minMs = Math.min(...ourPeriodOpenTsMs);
  const maxMs = Math.max(...ourPeriodOpenTsMs);
  // Fetch from well before the earliest period (lookback headroom for
  // causal-sim's longer-window features) through just past the latest.
  const lookbackCandles = 200; // ~16.6h of 5m candles of headroom
  const startMs = minMs - lookbackCandles * 5 * 60_000;
  const spanMins = (maxMs - startMs) / 60_000 + 15;
  const count = Math.ceil(spanMins / 5) + 5;

  const { candles } = await fetchRealCandles(startMs, count, 5);
  const periods = groupIntoPeriods(candles);
  const { trades } = runPolicyOverPeriods(candles, periods, POLICY_LEAN);

  const tradeByPeriodStart = new Map(trades.map(t => [t.periodStartMs, t]));
  const periodStartSet = new Set(periods.map(p => p.periodStartMs));

  const matched = ourPeriodOpenTsMs.filter(ms => periodStartSet.has(ms));
  const matchedTrades = matched.map(ms => tradeByPeriodStart.get(ms)).filter((t): t is SimTrade => !!t);

  return {
    coveragePct: ourPeriodOpenTsMs.length > 0 ? (matched.length / ourPeriodOpenTsMs.length) * 100 : 0,
    trades: matchedTrades,
    matchedPeriods: matched.length,
    totalOurPeriods: ourPeriodOpenTsMs.length,
  };
}

// ── Walk-forward evaluation (primary Δ fee-net + secondary metrics + verdict) ──

export type WalkForwardVerdict = "WIN" | "INCONCLUSIVE" | "INSUFFICIENT_DATA";

export interface WalkForwardReport {
  nResolved: number;
  leanReplayCoveragePct: number;
  deltaFeeNetCents: number;
  ciLowCents: number;
  ciHighCents: number;
  verdict: WalkForwardVerdict;
  tradeCountShadow: number;
  tradeCountLean: number;
  tradeCountRatio: number;
  maxDrawdownRatio: number;
  calibrationEce: number;
}

const MIN_RESOLVED_FOR_VERDICT = 150;

function maxDrawdownOf(pnls: number[]): number {
  let cum = 0, peak = 0, maxDd = 0;
  for (const p of pnls) { cum += p; peak = Math.max(peak, cum); maxDd = Math.max(maxDd, peak - cum); }
  return maxDd;
}

/** Block bootstrap over contiguous period-ordered blocks (not i.i.d. rows) of the (shadow - lean) per-period paired difference. */
function blockBootstrapDeltaCI(paired: number[], iterations = 1000, blockSize = 5): { lo: number; hi: number } {
  if (paired.length < 5) return { lo: 0, hi: 0 };
  const n = paired.length;
  const means: number[] = [];
  for (let iter = 0; iter < iterations; iter++) {
    const sample: number[] = [];
    while (sample.length < n) {
      const start = Math.floor(Math.random() * n);
      for (let k = 0; k < blockSize && sample.length < n; k++) sample.push(paired[(start + k) % n]);
    }
    means.push(sample.reduce((a, b) => a + b, 0) / sample.length);
  }
  means.sort((a, b) => a - b);
  return { lo: means[Math.floor(means.length * 0.05)], hi: means[Math.floor(means.length * 0.95)] };
}

/**
 * Runs the full pre-registered evaluation (docs §4). Pulls resolved
 * shadow_decisions rows, replays LEAN over the same periods, computes the
 * primary Δ fee-net with a block-bootstrap CI, secondary metrics, and
 * applies the exact pre-registered verdict rule. `INSUFFICIENT_DATA` is an
 * expected, correct outcome while resolved volume is thin — never
 * suppressed or re-labeled to look more conclusive.
 */
export async function evaluateWalkForwardV4(): Promise<WalkForwardReport> {
  const resolvedRows = await db.select({
    periodOpenTs: shadowDecisions.periodOpenTs,
    action: shadowDecisions.action,
    feeNetCents: shadowDecisions.feeNetCents,
  }).from(shadowDecisions).where(isNotNull(shadowDecisions.resolvedAt));

  const nResolved = resolvedRows.length;
  const empty: WalkForwardReport = {
    nResolved, leanReplayCoveragePct: 0, deltaFeeNetCents: 0, ciLowCents: 0, ciHighCents: 0,
    verdict: "INSUFFICIENT_DATA", tradeCountShadow: 0, tradeCountLean: 0, tradeCountRatio: 0,
    maxDrawdownRatio: 0, calibrationEce: 0,
  };
  if (nResolved < MIN_RESOLVED_FOR_VERDICT) return empty;

  const periodMs = resolvedRows.map(r => r.periodOpenTs.getTime());
  let lean: LeanReplayResult;
  try {
    lean = await computeLeanBaseline(periodMs);
  } catch (err) {
    console.warn("[market-learning-v4] LEAN replay failed, cannot verdict:", (err as Error).message);
    return empty;
  }

  const shadowFeeNetByPeriod = new Map(resolvedRows.filter(r => r.action !== "SKIP").map(r => [r.periodOpenTs.getTime(), r.feeNetCents ?? 0]));
  const leanFeeNetByPeriod = new Map(lean.trades.map(t => [t.periodStartMs, t.pnlCents]));

  // Period-aligned paired comparison: only periods where BOTH sides have a
  // graded outcome (shadow took a position AND LEAN's replay produced one,
  // or either explicitly skipped -> 0). SKIP counts as 0 fee-net on that
  // side, matching how a real "did not trade" period contributes to a
  // portfolio comparison.
  const commonPeriods = periodMs.filter(ms => lean.trades.some(t => t.periodStartMs === ms) || shadowFeeNetByPeriod.has(ms));
  const paired = commonPeriods.map(ms => (shadowFeeNetByPeriod.get(ms) ?? 0) - (leanFeeNetByPeriod.get(ms) ?? 0));

  const deltaFeeNetCents = paired.length > 0 ? paired.reduce((a, b) => a + b, 0) / paired.length : 0;
  const { lo, hi } = blockBootstrapDeltaCI(paired);

  const shadowPnls = commonPeriods.map(ms => shadowFeeNetByPeriod.get(ms) ?? 0);
  const leanPnls = commonPeriods.map(ms => leanFeeNetByPeriod.get(ms) ?? 0);
  const tradeCountShadow = Array.from(shadowFeeNetByPeriod.values()).length;
  const tradeCountLean = lean.trades.length;
  const tradeCountRatio = tradeCountLean > 0 ? tradeCountShadow / tradeCountLean : (tradeCountShadow > 0 ? Infinity : 0);
  const maxDdShadow = maxDrawdownOf(shadowPnls);
  const maxDdLean = maxDrawdownOf(leanPnls);
  const maxDrawdownRatio = maxDdLean > 0 ? maxDdShadow / maxDdLean : (maxDdShadow > 0 ? Infinity : 0);

  const calibrationEce = getBucketModelSummary().reduce((s, b) => s + b.oosEce, 0) / Math.max(1, getBucketModelSummary().length);

  let verdict: WalkForwardVerdict = "INCONCLUSIVE";
  if (lo > 0 && tradeCountRatio <= 1.5 && maxDrawdownRatio <= 1.25) verdict = "WIN";

  return {
    nResolved, leanReplayCoveragePct: lean.coveragePct, deltaFeeNetCents,
    ciLowCents: lo, ciHighCents: hi, verdict, tradeCountShadow, tradeCountLean,
    tradeCountRatio, maxDrawdownRatio, calibrationEce,
  };
}

// ── Canary admission thresholds (DOCUMENT ONLY — not wired anywhere) ───────
// Per docs/market-learning-v4.1.md §6: no live order path exists for this to
// gate yet. Recorded here as a string, not executable gating code, so a
// future human-initiated canary APPLY has a single source to read.
export const V4_CANARY_ADMISSION_NOTE =
  "Do not APPLY canary unless evaluateWalkForwardV4().verdict === 'WIN'. " +
  "Re-check verdict on every autoRevertCanaryIfFailing() tick (v2, already wired); " +
  "a WIN that degrades to INCONCLUSIVE or worse mid-canary should auto-revert, same as v2's existing pass/fail auto-revert. " +
  "v2's CANARY_ENVELOPE (size/trade/loss caps) remains authoritative and is not superseded by this note.";

// ── Reporting ────────────────────────────────────────────────────────────

export interface MarketLearningV4Report {
  mode: string;
  policyVersion: string;
  /** Always `learning_state.sizeMult` (v2-owned, stays 0 in shadow) — v4.1 has no size authority of its own; see V4_CANARY_ADMISSION_NOTE. */
  sizeMult: number;
  modelVersion: string;
  bucketModels: Array<{ bucket: TimeBucket; n: number; oosEce: number }>;
  walkForward: WalkForwardReport;
}

export async function getMarketLearningV4Report(): Promise<MarketLearningV4Report> {
  const state = await getLearningState();
  const walkForward = await evaluateWalkForwardV4();
  return {
    mode: state.mode,
    policyVersion: state.policyVersion,
    sizeMult: state.sizeMult,
    modelVersion: V4_MODEL_VERSION,
    bucketModels: getBucketModelSummary(),
    walkForward,
  };
}

// ── Lifecycle ────────────────────────────────────────────────────────────

let v4RefreshTimer: NodeJS.Timeout | null = null;

/** Called once from market-learning.ts's startMarketLearning(). Refreshes the per-time-bucket logistic+isotonic models every 5m. */
export function startMarketLearningV4(): void {
  if (v4RefreshTimer) return;
  void refreshShadowModelsV4();
  v4RefreshTimer = setInterval(() => void refreshShadowModelsV4(), REFRESH_MS);
  console.info("[market-learning-v4] Started — per-time-bucket logistic+isotonic model refresh every 5m (shadow only, zero live effect)");
}
