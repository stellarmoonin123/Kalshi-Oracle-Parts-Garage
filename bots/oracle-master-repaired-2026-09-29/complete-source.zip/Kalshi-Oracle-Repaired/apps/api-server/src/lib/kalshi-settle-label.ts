/**
 * kalshi-settle-label.ts
 *
 * Informational YES/NO labels must match Kalshi truth:
 *   official Kalshi result, or BTC close vs floor_strike.
 * Never infer expiry settlement from paper W/L, live favorite, or
 * period "up"/"down" (those are not YES/NO).
 *
 * Observational. Does not ENABLE, cut EV/Kelly/9%, or paperMode false.
 */

export type KalshiYesNo = "YES" | "NO";

const EXPIRY_EXIT = new Set(["SETTLEMENT", "SETTLED_KALSHI"]);

export function isExpirySettleReason(code?: string | null): boolean {
  if (!code) return false;
  return EXPIRY_EXIT.has(code.trim().toUpperCase());
}

function asYesNo(v: string | null | undefined): KalshiYesNo | null {
  const s = (v ?? "").trim().toUpperCase();
  if (s === "YES" || s === "Y") return "YES";
  if (s === "NO" || s === "N") return "NO";
  return null;
}

/**
 * Official market result. Prefer Kalshi's YES/NO; else BTC close vs floor
 * (YES iff close > floor; Kalshi "greater" strike is strictly greater-than). Never paper W/L. Never "up"/"down".
 */
export function kalshiSettleFromTruth(opts: {
  officialKalshi?: string | null;
  btcClose?: number | null;
  floorStrike?: number | null;
}): KalshiYesNo | null {
  const official = asYesNo(opts.officialKalshi);
  if (official) return official;
  const px = opts.btcClose;
  const floor = opts.floorStrike;
  if (
    typeof px === "number" && Number.isFinite(px) &&
    typeof floor === "number" && Number.isFinite(floor) && floor > 0
  ) {
    return px > floor ? "YES" : "NO";
  }
  return null;
}

/** Chat/desk: one number when they agree; both labeled when they disagree. */
export function labeledProjectionPair(
  basisProj: number | null | undefined,
  modelProj: number | null | undefined,
): { line: string; agree: boolean; basis: number | null; model: number | null } {
  const basis = typeof basisProj === "number" && Number.isFinite(basisProj) ? basisProj : null;
  const model = typeof modelProj === "number" && Number.isFinite(modelProj) ? modelProj : null;
  if (basis == null && model == null) {
    return { line: "proj n/a", agree: true, basis, model };
  }
  if (basis != null && model != null && Math.abs(basis - model) < 1) {
    return { line: `proj $${Math.round(basis)}`, agree: true, basis, model };
  }
  if (basis != null && model != null) {
    return {
      line: `basis proj $${Math.round(basis)} · model proj $${Math.round(model)}`,
      agree: false,
      basis,
      model,
    };
  }
  if (basis != null) return { line: `basis proj $${Math.round(basis)}`, agree: true, basis, model };
  return { line: `model proj $${Math.round(model!)}`, agree: true, basis, model };
}

/** Canonical lag proj vs dedicated model. Split-brain is labeled, never a silent pick. */
export function labeledCanonicalAndModel(
  canon: { proj?: number | null; splitBrain: boolean },
  modelProj: number | null | undefined,
): { line: string; agree: boolean; basis: number | null; model: number | null; splitBrain: boolean } {
  const model = typeof modelProj === "number" && Number.isFinite(modelProj) ? modelProj : null;
  if (canon.splitBrain) {
    const pair = labeledProjectionPair(null, model);
    return {
      line: model != null ? `split-brain · ${pair.line}` : "split-brain · proj n/a",
      agree: false,
      basis: null,
      model,
      splitBrain: true,
    };
  }
  const pair = labeledProjectionPair(canon.proj ?? null, model);
  return { ...pair, splitBrain: false };
}

/** Same lock as applyStrongMTFDirectionLock: |score| >= 3. */
export const MTF_STRONG_LOCK = 3;

export function mtfAgreementLabel(signed: number): { score: number; label: string } {
  if (signed >= MTF_STRONG_LOCK) return { score: 90, label: "strongly aligned" };
  if (signed >= 2) return { score: 78, label: "aligned" };
  if (signed > 0) return { score: 70, label: "mildly aligned" };
  if (signed === 0) return { score: 55, label: "flat" };
  if (signed > -2) return { score: 30, label: "mildly opposed" };
  if (signed > -MTF_STRONG_LOCK) return { score: 22, label: "opposed" };
  return { score: 10, label: "strongly opposed" };
}
