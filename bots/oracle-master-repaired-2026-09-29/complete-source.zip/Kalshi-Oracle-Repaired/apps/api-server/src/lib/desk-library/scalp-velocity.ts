/**
 * scalp-velocity.ts — scalp book, shadow.
 *
 * Ticket dMid/dt moving with the trade. Never both sides. One 9% budget/bar.
 * A still print is skip.
 *
 * Reuses intra-scalp-replay helpers (ticketVelocity, ask band, window, MTF).
 * Reuses HARD_RISK_LIMITS 9% — does not cut it.
 *
 * paperMode true. autoMode false. LIVE_APPLY false.
 * Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR.
 */
import { HARD_RISK_LIMITS } from "../admission.js";
import {
  INTRA_BAR_RISK_PCT,
  TICKET_VEL_MIN_MOVE_CENTS,
  inIntraWindow,
  isIntraAskBand,
  mtfFightsSide,
  ticketVelocity,
  type TickQuote,
} from "../intra-scalp-replay.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;

export const SCALP_BAR_RISK_PCT = INTRA_BAR_RISK_PCT;
export const SCALP_MIN_DMID_CENTS = TICKET_VEL_MIN_MOVE_CENTS;

export type ScalpVelocityOpts = {
  side: "yes" | "no";
  askCents: number;
  secsRemaining: number;
  /** Already in a trade on this bar — never both sides. */
  open?: boolean;
  openSide?: "yes" | "no" | null;
  remainingBudgetCents?: number;
  fillCostCents?: number;
  mtf?: number;
  /** Precomputed ticket motion. Prefer history+now when present. */
  inBuyDirection?: boolean;
  dMidCents?: number | null;
  still?: boolean;
  now?: TickQuote;
  history?: TickQuote[];
};

export type ScalpVelocityDecision = {
  take: boolean;
  reason: string;
};

function skip(reason: string): ScalpVelocityDecision {
  return { take: false, reason };
}

function ticketMovingWithSide(opts: ScalpVelocityOpts): boolean {
  if (opts.now && opts.history) {
    const vel = ticketVelocity({ side: opts.side, now: opts.now, history: opts.history });
    return Boolean(vel && vel.inBuyDirection);
  }
  if (opts.still === true) return false;
  if (opts.inBuyDirection === true) return true;
  if (opts.inBuyDirection === false) return false;
  if (typeof opts.dMidCents === "number" && Number.isFinite(opts.dMidCents)) {
    return opts.dMidCents >= SCALP_MIN_DMID_CENTS;
  }
  return false;
}

/**
 * Shadow predicate. Still ticket → skip. Open position → skip.
 * Remaining 9% bar budget must cover notional+fee.
 */
export function shouldScalpVelocityTake(opts: ScalpVelocityOpts): ScalpVelocityDecision {
  if (LIVE_APPLY || LIVE_APPLY_ENABLED) {
    return skip("live_apply_refused");
  }
  if (HARD_RISK_LIMITS.maxRiskPctPerTrade !== 0.09 || SCALP_BAR_RISK_PCT !== 0.09) {
    return skip("nine_pct_lock");
  }
  if (opts.open) {
    return skip("already_open");
  }
  if (opts.openSide && opts.openSide !== opts.side) {
    return skip("never_both_sides");
  }
  if (!inIntraWindow(opts.secsRemaining)) {
    return skip("window");
  }
  if (!isIntraAskBand(opts.askCents)) {
    return skip("ask_out_of_band");
  }
  if (mtfFightsSide(opts.side, opts.mtf ?? 0)) {
    return skip(opts.side === "yes" ? "mtf_veto_yes" : "mtf_veto_no");
  }
  if (!ticketMovingWithSide(opts)) {
    return skip("still");
  }
  if (
    typeof opts.remainingBudgetCents === "number"
    && typeof opts.fillCostCents === "number"
    && opts.remainingBudgetCents < opts.fillCostCents
  ) {
    return skip("bar_budget");
  }

  return { take: true, reason: "scalp_velocity" };
}
