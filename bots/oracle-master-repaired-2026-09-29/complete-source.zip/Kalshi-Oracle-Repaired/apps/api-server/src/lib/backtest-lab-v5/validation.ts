/**
 * backtest-lab-v5/validation.ts
 *
 * GO — BACKTEST LAB v5 + CONTINUOUS POLICY REGRESSION (2026-08-22), PART I-C.
 *
 * Sequential (walk-forward) out-of-sample split, bootstrap confidence
 * intervals, headline metrics, and the LEAN vs LEGACY verdict. Reuses
 * backtest-engine.ts's already-exported pure statistics helpers
 * (computeMaxDrawdown, computeProfitFactor, bootstrapCI) instead of a third
 * copy of this math — see that file's export doc comments (2026-08-22).
 */

import { computeMaxDrawdown, computeProfitFactor, bootstrapCI } from '../backtest-engine.js';
import type { BootstrapCI } from '../backtest-engine.js';
import type { SimTrade } from './causal-sim.js';

export interface PolicyMetrics {
  trades:        number;
  wins:          number;
  losses:        number;
  winRate:       number;
  feeNetPnlCents: number;   // primary metric — sum of SimTrade.pnlCents (already fee/slip-net)
  maxDrawdown:   number;    // fraction, e.g. 0.12 = 12%
  profitFactor:  number;
  /** Fair, policy-neutral wrong-kit rate (ACK LAB v5 — FAIR METRICS
   *  HARDENING, 2026-08-22): fraction of admitted trades whose strategy
   *  family conflicts with the causal regime label at decision time, under
   *  wrong-kit.ts's shared map. Computed identically for LEAN and LEGACY,
   *  independent of pack filtering — see WRONG_KIT_FORMULA_SUMMARY. */
  wrongKitRate:  number;
  bootstrap:     BootstrapCI; // win-rate CI from resampling the OOS trade set
  /** Bootstrap CI of the per-trade fee-net mean (cents), used by the
   *  verdict's explicit "CIs overlap => INCONCLUSIVE" check (ACK LAB v5 —
   *  FAIR METRICS HARDENING, Item 2). Distinct from `bootstrap`, which is a
   *  win-rate CI — this one is on the continuous P&L statistic the verdict
   *  actually reasons about. */
  feeNetCI:      BootstrapCI;
}

/**
 * Bootstrap CI of the resampled MEAN per-trade fee-net cents. Mirrors
 * backtest-engine.ts's `bootstrapCI` resampling pattern (same iteration
 * count and percentile convention) but resamples a continuous per-trade
 * P&L statistic instead of a binary win/loss — that function's own
 * signature (`oosWins: number[], oosLosses: number[]`) is win/loss-count
 * specific and cannot express "mean cents", so this is a deliberate sibling
 * helper, not a duplicate of the same logic.
 */
function bootstrapFeeNetCI(pnlCents: number[], iterations = 1_000): BootstrapCI {
  if (pnlCents.length < 5) return { p5: 0, p50: 0, p95: 0, mean: 0 };
  const n = pnlCents.length;
  const samples: number[] = [];
  for (let i = 0; i < iterations; i++) {
    let sum = 0;
    for (let j = 0; j < n; j++) sum += pnlCents[Math.floor(Math.random() * n)];
    samples.push(sum / n);
  }
  samples.sort((a, b) => a - b);
  const p5   = samples[Math.floor(samples.length * 0.05)];
  const p50  = samples[Math.floor(samples.length * 0.50)];
  const p95  = samples[Math.floor(samples.length * 0.95)];
  const mean = samples.reduce((a, b) => a + b, 0) / samples.length;
  return { p5, p50, p95, mean };
}

export function computeMetrics(trades: SimTrade[]): PolicyMetrics {
  const wins   = trades.filter(t => t.won);
  const losses = trades.filter(t => !t.won);
  const winPnls   = wins.map(t => t.pnlCents);
  const lossPnls  = losses.map(t => Math.abs(t.pnlCents));
  let equity = 0;
  const equityCurve = trades.map(t => (equity += t.pnlCents));
  const wrongKit = trades.filter(t => t.wrongKitFamily === true).length;

  return {
    trades:        trades.length,
    wins:          wins.length,
    losses:        losses.length,
    winRate:       trades.length ? wins.length / trades.length : 0,
    feeNetPnlCents: trades.reduce((s, t) => s + t.pnlCents, 0),
    maxDrawdown:   computeMaxDrawdown([0, ...equityCurve]),
    profitFactor:  computeProfitFactor(winPnls, lossPnls),
    wrongKitRate:  trades.length ? wrongKit / trades.length : 0,
    bootstrap:     bootstrapCI(wins.map(() => 1), losses.map(() => 0)),
    feeNetCI:      bootstrapFeeNetCI(trades.map(t => t.pnlCents)),
  };
}

// ── Sequential walk-forward OOS split ──────────────────────────────────────────

export interface OosFold {
  trainTrades: SimTrade[];
  oosTrades:   SimTrade[];
}

/**
 * Splits an already-time-ordered trade list into `k` sequential folds, each
 * using everything BEFORE the fold's OOS window as "train" (unused by this
 * lab's metrics today — kept for symmetry with backtest-engine.ts's
 * walk-forward shape and for a future train-tuned-threshold extension) and
 * the fold's own window as the out-of-sample slice actually scored. This is
 * a genuine sequential/expanding-window split (never a random shuffle), so
 * no OOS trade is ever evaluated using a threshold picked with knowledge of
 * its own outcome.
 */
export function sequentialOosFolds(trades: SimTrade[], k = 3): OosFold[] {
  if (trades.length < k) return [{ trainTrades: [], oosTrades: trades }];
  const sorted = [...trades].sort((a, b) => a.periodStartMs - b.periodStartMs);
  const foldSize = Math.floor(sorted.length / k);
  const folds: OosFold[] = [];
  for (let i = 0; i < k; i++) {
    const start = i * foldSize;
    const end   = i === k - 1 ? sorted.length : start + foldSize;
    folds.push({ trainTrades: sorted.slice(0, start), oosTrades: sorted.slice(start, end) });
  }
  return folds;
}

/** Pools every fold's OOS slice into one metrics object — the number the
 *  verdict is actually based on (not any single fold, and not the train
 *  slices, which this lab does not use to pick thresholds). */
export function pooledOosMetrics(trades: SimTrade[], k = 3): PolicyMetrics {
  const folds = sequentialOosFolds(trades, k);
  const pooled = folds.flatMap(f => f.oosTrades);
  return computeMetrics(pooled);
}

// ── Verdict ─────────────────────────────────────────────────────────────────────

export type Verdict = 'LEAN_WINS' | 'LEGACY_WINS' | 'INCONCLUSIVE';

export interface VerdictResult {
  verdict: Verdict;
  reason:  string;
}

/**
 * ACK LAB v5 — FAIR METRICS HARDENING (2026-08-22), Item 2 — VERDICT
 * DISCIPLINE: a policy "wins" only when ALL of the following hold; any one
 * failing forces INCONCLUSIVE, never a tie-break toward either side:
 *   1. Both policies have >= MIN_TRADES_FOR_VERDICT OOS trades.
 *   2. The two policies' fee-net bootstrap CIs (p5..p95 of the resampled
 *      per-trade mean, see `feeNetCI`) do NOT overlap.
 *   3. The per-trade fee-net gap is outside the stated noise band (the
 *      win-rate-CI-derived tolerance already in use before this hardening
 *      pass — kept as a second, independent check, since two policies can
 *      have non-overlapping fee-net CIs yet still show only a hair's-width
 *      per-trade gap once translated to a practical dollar difference).
 * "One side simply produced too few trades to say anything" is always
 * INCONCLUSIVE, never treated as evidence for the side with more trades.
 */
const MIN_TRADES_FOR_VERDICT = 50;

/** True when the closed intervals [aLo, aHi] and [bLo, bHi] intersect. */
function rangesOverlap(aLo: number, aHi: number, bLo: number, bHi: number): boolean {
  return aLo <= bHi && bLo <= aHi;
}

export function decideVerdict(lean: PolicyMetrics, legacy: PolicyMetrics): VerdictResult {
  if (lean.trades < MIN_TRADES_FOR_VERDICT || legacy.trades < MIN_TRADES_FOR_VERDICT) {
    return {
      verdict: 'INCONCLUSIVE',
      reason: `Too few trades to compare (LEAN=${lean.trades}, LEGACY=${legacy.trades}, need >= ${MIN_TRADES_FOR_VERDICT} each).`,
    };
  }

  if (rangesOverlap(lean.feeNetCI.p5, lean.feeNetCI.p95, legacy.feeNetCI.p5, legacy.feeNetCI.p95)) {
    return {
      verdict: 'INCONCLUSIVE',
      reason: `Fee-net bootstrap CIs overlap (LEAN [${lean.feeNetCI.p5.toFixed(2)}c, ${lean.feeNetCI.p95.toFixed(2)}c], LEGACY [${legacy.feeNetCI.p5.toFixed(2)}c, ${legacy.feeNetCI.p95.toFixed(2)}c]) — cannot separate the two policies from resampling noise alone.`,
    };
  }

  const leanPerTrade   = lean.trades   ? lean.feeNetPnlCents   / lean.trades   : 0;
  const legacyPerTrade = legacy.trades ? legacy.feeNetPnlCents / legacy.trades : 0;
  const ciWidth = Math.max(
    lean.bootstrap.p95   - lean.bootstrap.p5,
    legacy.bootstrap.p95 - legacy.bootstrap.p5,
  );
  // Rough per-trade noise tolerance: a win-rate CI band of `ciWidth` at a
  // typical ~50c entry maps to about `ciWidth * 100` cents of win-rate-
  // driven P&L uncertainty per trade — deliberately conservative (wide) so
  // this errs toward INCONCLUSIVE rather than a false verdict.
  const noiseToleranceCents = Math.max(1, ciWidth * 100);
  const diff = leanPerTrade - legacyPerTrade;

  if (Math.abs(diff) < noiseToleranceCents) {
    return {
      verdict: 'INCONCLUSIVE',
      reason: `Per-trade fee-net gap (${diff.toFixed(2)}c) is within the bootstrap noise band (±${noiseToleranceCents.toFixed(2)}c).`,
    };
  }
  return diff > 0
    ? { verdict: 'LEAN_WINS',   reason: `LEAN beats LEGACY by ${diff.toFixed(2)}c/trade fee-net, outside both the non-overlapping fee-net CIs and the ±${noiseToleranceCents.toFixed(2)}c noise band.` }
    : { verdict: 'LEGACY_WINS', reason: `LEGACY beats LEAN by ${(-diff).toFixed(2)}c/trade fee-net, outside both the non-overlapping fee-net CIs and the ±${noiseToleranceCents.toFixed(2)}c noise band.` };
}

// ── Sensitivity analysis ────────────────────────────────────────────────────────

export interface SensitivityRow {
  label:  string;
  lean:   PolicyMetrics;
  legacy: PolicyMetrics;
  verdict: VerdictResult;
}
