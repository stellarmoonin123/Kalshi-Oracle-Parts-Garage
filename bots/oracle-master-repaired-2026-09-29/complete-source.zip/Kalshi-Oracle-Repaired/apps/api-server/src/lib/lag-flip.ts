/**
 * LAG_FLIP_EXIT persistence gate.
 *
 * Extracted from trading-bot.ts so the hold / consecutive-sample lock lives in
 * one named module. TradingBot is a caller. Do not cut these floors.
 *
 * Paper #725 (2026-09-05): CC NO @37 sold LAG_FLIP @19¢ in ~31s on a 1-tick
 * lead twitch with lagProven:false. PATH_RIDE money-makers need **3 consecutive
 * 1-second samples** where BOTH (a) Coinbase lead/lag is against the fill AND
 * (b) BRTI/projection vs strike is against — plus lagProven===true and ≥15s hold.
 * Unproven lag = HOLD. Do not sell on a single tick.
 */
/** Min life of a fill before LAG_FLIP_EXIT may fire. Kills the ~3s paper-tape leak. */
/** PAPER DESK v2 PATH_RIDE FLIP: hold≥20s (+ lagProven + 3×1s). */
export const LAG_FLIP_MIN_HOLD_MS = 20_000;
/**
 * Legacy sample floor (500ms ticks). Prefer LAG_FLIP_CONSECUTIVE_BOTH_AGAINST
 * for PATH_RIDE / money-maker LAG_FLIP. Kept so mid-migration callers compile.
 */
export const LAG_FLIP_MIN_SAMPLES = 16;
/** PATH_RIDE money-maker: 3 consecutive 1s samples of lead-against AND BRTI-against. */
export const LAG_FLIP_CONSECUTIVE_BOTH_AGAINST = 3;
/** Earliest the 3×1s gate may arm after fill (samples themselves must be consecutive). */
export const LAG_FLIP_THREE_SAMPLE_MIN_MS = 3_000;

/** Min |projected-floor|/floor before a 1s projection counts as against. */
export const PROJ_AGAINST_MIN_DISPLACEMENT_PCT = 0.0005;

export type ShouldLagFlipExitOpts = {
  /** Legacy consecutive against count (proj-only, any tick cadence). */
  samplesAgainst?: number;
  samplesAgainstLead?: number;
  samplesAgainstBrti?: number;
  /** Preferred: consecutive 1s buckets where BOTH lead+BRTI were against. */
  consecutiveBothAgainst?: number;
  msSinceFill: number;
  /** Unproven lag cannot authorize LAG_FLIP (PATH_RIDE). false → HOLD. omit → ignore. */
  lagProven?: boolean;
};

/**
 * Pure LAG_FLIP_EXIT predicate.
 * - lagProven===false → never exit (HOLD).
 * - msSinceFill < 20s → never exit.
 * - When consecutiveBothAgainst (or both lead+brti counters) provided: need ≥3.
 * - Else legacy samplesAgainst ≥ LAG_FLIP_MIN_SAMPLES.
 * Stale/missing lag is handled by the caller (fail-open / not against).
 */
export function shouldLagFlipExit(opts: ShouldLagFlipExitOpts): boolean {
  if (opts.lagProven === false) return false;
  if (!(opts.msSinceFill >= LAG_FLIP_MIN_HOLD_MS)) return false;

  if (typeof opts.consecutiveBothAgainst === "number") {
    return opts.consecutiveBothAgainst >= LAG_FLIP_CONSECUTIVE_BOTH_AGAINST;
  }

  if (
    typeof opts.samplesAgainstLead === "number"
    && typeof opts.samplesAgainstBrti === "number"
  ) {
    // Callers that keep synced consecutive counters: both must meet the floor.
    return opts.samplesAgainstLead >= LAG_FLIP_CONSECUTIVE_BOTH_AGAINST
      && opts.samplesAgainstBrti >= LAG_FLIP_CONSECUTIVE_BOTH_AGAINST;
  }

  if (typeof opts.samplesAgainst === "number") {
    return opts.samplesAgainst >= LAG_FLIP_MIN_SAMPLES;
  }

  return false;
}

/**
 * Coinbase lead/lag against filled side.
 * YES against when lagDollars < 0; NO against when lagDollars > 0.
 * Missing / zero / non-finite → false (never invent against).
 */
export function leadAgainstSide(opts: {
  tradeSide: "yes" | "no";
  lagDollars: number | null | undefined;
}): boolean {
  const d = opts.lagDollars;
  if (d == null || !Number.isFinite(d) || d === 0) return false;
  return opts.tradeSide === "yes" ? d < 0 : d > 0;
}

/**
 * 1s projectedSettlement vs floor — NOT Coinbase lag-meter.
 * Missing/stale/too-small displacement → false (never "against").
 * Callers that used to name this isLagAgainstSide / lagAgrees were lying.
 */
export function projAgainstSide(opts: {
  tradeSide: "yes" | "no";
  projected: number | null | undefined;
  floorStrike: number;
}): boolean {
  const projected = opts.projected;
  if (projected == null || !Number.isFinite(projected) || !(opts.floorStrike > 0)) return false;
  const displacementOk =
    Math.abs(projected - opts.floorStrike) / opts.floorStrike >= PROJ_AGAINST_MIN_DISPLACEMENT_PCT;
  if (!displacementOk) return false;
  return opts.tradeSide === "yes" ? projected < opts.floorStrike : projected > opts.floorStrike;
}

/**
 * Tri-state 1s-projection agreement. null = unknown (stale / no displacement).
 * Coinbase lag stays lagAgreesWithSide(lagDollars) in lag-meter.ts.
 */
export function projAgreesWithSide(opts: {
  tradeSide: "yes" | "no";
  projected: number | null | undefined;
  floorStrike: number;
}): boolean | null {
  const projected = opts.projected;
  if (projected == null || !Number.isFinite(projected) || !(opts.floorStrike > 0)) return null;
  const displacementOk =
    Math.abs(projected - opts.floorStrike) / opts.floorStrike >= PROJ_AGAINST_MIN_DISPLACEMENT_PCT;
  if (!displacementOk) return null;
  return !projAgainstSide(opts);
}

/**
 * Pure 1s-bucket consecutive counter for BOTH lead-against AND BRTI-against.
 * Call once per monitor tick; only advances on a new UTC second.
 */
export function nextLagFlipBothAgainstStreak(opts: {
  prevStreak: number;
  lastSampleSec: number;
  nowMs: number;
  leadAgainst: boolean;
  brtiAgainst: boolean;
}): { streak: number; lastSampleSec: number } {
  const sec = Math.floor(opts.nowMs / 1000);
  if (sec === opts.lastSampleSec) {
    return { streak: opts.prevStreak, lastSampleSec: opts.lastSampleSec };
  }
  const both = opts.leadAgainst === true && opts.brtiAgainst === true;
  return {
    streak: both ? opts.prevStreak + 1 : 0,
    lastSampleSec: sec,
  };
}
