/**
 * Leftover 15m evaluate funnel — packs, HARVEST, SETTLEMENT_PREDICTION,
 * paper-desk winner, W2-as-law, ARIA composer. Not frozen entry law.
 *
 * Host: after the frozen six-gate jump, leftover15mEvaluateMayRun is the
 * only door. Frozen returns. This module does not import trading-bot.
 * Not an edge claim. Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
export {
  leftover15mEvaluateMayRun,
  FROZEN_LEFTOVER_FUNNEL_MARKERS,
} from "./frozen-six-gate-evaluate.js";
import { leftover15mEvaluateMayRun as leftoverMayRun } from "./frozen-six-gate-evaluate.js";
import { expertAgent } from "./expert-agent.js";
import type { AgentAssessment } from "./expert-agent.js";
import type { AriaAssessment } from "./trade-path.js";

export const LEFTOVER_15M_EVALUATE_LOADED = true as const;

/** Host source must contain this exact leftover deny after the six-gate jump. */
export const LEFTOVER_15M_HOST_GUARD =
  "if (!leftover15mEvaluateMayRun(this.config)) return;";

/** Same floors trading-bot historically used on the leftover 15m entry path. */
export const LEFTOVER_15M_FAST_VEL = 80;
export const LEFTOVER_15M_SUSTAINED_V3 = 40;
export const LEFTOVER_15M_SWEEP_PREMIUM = 2;
/** Fail-closed: calibration must not move money until proven. */
export const CONFIDENCE_CALIBRATION_ENABLED = false;

/**
 * Thin ARIA input mapper — pure wiring, no judgment.
 * Kept here so leftover-15m-funnel never imports trading-bot (circular wall).
 */
export function buildAriaInput(a: AgentAssessment | null): AriaAssessment | null {
  if (!a) return null;
  return {
    confAdj:           a.confAdj,
    riskLevel:         a.riskLevel,
    reasoning:         a.reasoning,
    signal:            a.signal,
    sustainedHighRisk: expertAgent.isSustainedHighRisk(),
  };
}

/** DI bag for leftover15mEvaluateFunnel — no judgment, no trading-bot import. */
export function leftover15mEvaluateHelpers() {
  return {
    FAST_VEL: LEFTOVER_15M_FAST_VEL,
    SUSTAINED_V3: LEFTOVER_15M_SUSTAINED_V3,
    SWEEP_PREMIUM: LEFTOVER_15M_SWEEP_PREMIUM,
    CONFIDENCE_CALIBRATION_ENABLED,
    buildAriaInput,
  } as const;
}

export function leftover15mEvaluateHostDenied(cfg: {
  frozenCcMode?: boolean;
  paperMode?: boolean;
}): boolean {
  return leftoverMayRun(cfg) === false;
}

/** Named leftover runner. Frozen or paper config returns without invoking `run`. */
export function leftover15mEvaluateRun(
  cfg: { frozenCcMode?: boolean; paperMode?: boolean },
  run: () => Promise<void>,
): Promise<void> {
  if (!leftoverMayRun(cfg)) return Promise.resolve();
  return run();
}
