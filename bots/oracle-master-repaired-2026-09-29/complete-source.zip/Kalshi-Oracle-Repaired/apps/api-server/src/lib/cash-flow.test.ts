/**
 * Pure-function tests for the Modified Dietz ROI calculation — no DB needed.
 * See cash-flow.db.test.ts for the ledger persistence/confirmation-gating
 * tests (T3, T4, T5).
 */
import test from "node:test";
import assert from "node:assert/strict";
import { computeModifiedDietz, autoDetectClientKey } from "./cash-flow.js";

const day = (n: number) => new Date(Date.UTC(2026, 0, n));

test("T1: a mid-window deposit changes Modified Dietz ROI but the caller's trading_pnl is untouched", () => {
  // 10-day window, no external flow: pure trading gain of 1,000c on 10,000c.
  const noFlow = computeModifiedDietz({
    v0Cents: 10_000, v1Cents: 11_000, t0: day(1), t1: day(11), flows: [],
  });
  assert.ok(noFlow.roiPct !== null);
  assert.ok(Math.abs(noFlow.roiPct! - 10) < 1e-9, "no-flow case is a plain 10% return");

  // Same trading result, but a 5,000c deposit lands exactly mid-window —
  // ending equity is now 16,000c purely because of the deposit, not trading.
  const withDeposit = computeModifiedDietz({
    v0Cents: 10_000, v1Cents: 16_000, t0: day(1), t1: day(11), flows: [{ ts: day(6), amountCents: 5_000 }],
  });
  // Numerator strips the deposit back out: 16,000 - 10,000 - 5,000 = 1,000 (same trading gain).
  // Denominator gets ~half the deposit as extra capital (mid-window => w≈0.5).
  assert.ok(withDeposit.roiPct !== null);
  assert.ok(withDeposit.roiPct! < noFlow.roiPct!, "ROI should be diluted by the added capital, not inflated by the deposit");
  assert.ok(withDeposit.roiPct! > 0, "the underlying 1,000c trading gain should still show up as positive ROI");
  assert.equal(withDeposit.sumDepositsCents, 5_000);
  assert.equal(withDeposit.netExternalCents, 5_000);

  // The trading P&L itself (what a caller reports separately) never appears
  // inside this pure function's inputs/outputs at all — this asserts the
  // "residual" figure only reflects the KNOWN deposit, proving trading P&L
  // (the 1,000c gain) round-trips unchanged regardless of the deposit.
  assert.ok(Math.abs((withDeposit.simpleResidualPct! / 100) * 10_000 - 1_000) < 1e-6);
});

test("a withdrawal near the end of the window barely dilutes the denominator", () => {
  const early = computeModifiedDietz({
    v0Cents: 10_000, v1Cents: 5_000, t0: day(1), t1: day(11), flows: [{ ts: day(2), amountCents: -6_000 }],
  });
  const late = computeModifiedDietz({
    v0Cents: 10_000, v1Cents: 5_000, t0: day(1), t1: day(11), flows: [{ ts: day(10), amountCents: -6_000 }],
  });
  // Same net cash math, but timing changes the denominator -> different ROI.
  assert.notEqual(early.roiPct, late.roiPct);
  assert.equal(early.sumWithdrawalsCents, -6_000);
});

test("roiPct is null (not a fabricated number) when there's no usable capital base", () => {
  const r = computeModifiedDietz({ v0Cents: 0, v1Cents: 0, t0: day(1), t1: day(2), flows: [] });
  assert.equal(r.roiPct, null);
  assert.equal(r.simpleResidualPct, null);
});

test("autoDetectClientKey buckets to the minute and is stable for identical inputs", () => {
  const t = new Date("2026-08-16T12:00:30.000Z");
  const tSameMinute = new Date("2026-08-16T12:00:59.000Z");
  const tNextMinute = new Date("2026-08-16T12:01:01.000Z");
  assert.equal(autoDetectClientKey(false, t, 8_800), autoDetectClientKey(false, tSameMinute, 8_800));
  assert.notEqual(autoDetectClientKey(false, t, 8_800), autoDetectClientKey(false, tNextMinute, 8_800));
  assert.notEqual(autoDetectClientKey(false, t, 8_800), autoDetectClientKey(true, t, 8_800), "paper/live must not share a key");
});
