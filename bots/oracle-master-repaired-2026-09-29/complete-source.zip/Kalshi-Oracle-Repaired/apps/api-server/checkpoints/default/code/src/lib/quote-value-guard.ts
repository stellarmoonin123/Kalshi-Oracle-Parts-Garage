import { quoteValueLag } from "./orderbook-consistency.js";

export const QUOTE_VALUE_CHECK_FAILED = "quote value check failed";

/** Include source reads in the guard: an unavailable source is not fresh. */
export function guardedQuoteValueLag(
  readInputs: () => Parameters<typeof quoteValueLag>[0],
): { stale: boolean; reason: string | null } {
  try {
    const result = quoteValueLag(readInputs());
    return { stale: result.stale, reason: result.reason };
  } catch {
    return { stale: true, reason: QUOTE_VALUE_CHECK_FAILED };
  }
}
