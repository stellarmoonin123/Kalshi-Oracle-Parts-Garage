/**
 * Mind Heartbeat — cortex vitals across Mind layers (separate from organism 9-system pulse).
 *
 * Proves single-pass flow: reflex→tactical→strategic→phd→council→oracleV2→selfDrive→captain→heartbeat
 * Efficiency: selfDriveBuildsPerTick=1, captainBuildsPerTick=1 (early peeks only).
 *
 * Pure. No network. No LLM. Diagnose-only — never cuts floors / never ENABLE.
 */

export const MIND_HEARTBEAT_SCHEMA = "mind_heartbeat_v1" as const;
export const MIND_HEARTBEAT_LOADED = "MIND_HEARTBEAT_LOADED" as const;

/** Fixed pipeline order — single-pass proof. */
export const MIND_HEARTBEAT_FLOW = [
  "reflex",
  "tactical",
  "strategic",
  "phd",
  "council",
  "oracleV2",
  "selfDrive",
  "captain",
  "heartbeat",
] as const;

export type MindHeartbeatLayerId = (typeof MIND_HEARTBEAT_FLOW)[number];
export type MindHeartbeatBeatStatus = "ok" | "stale" | "fail";
export type MindHeartbeatHealth = "alive" | "degraded" | "critical";

export type MindHeartbeatBeat = {
  id: MindHeartbeatLayerId;
  status: MindHeartbeatBeatStatus;
  ageMs: number | null;
  detail: string;
};

export type MindHeartbeatLayers = {
  reflex?: unknown;
  tactical?: unknown;
  strategic?: unknown;
  council?: unknown;
  phd?: unknown;
  oracleV2?: unknown;
  selfDrive?: unknown;
  captain?: unknown;
  goldenEgg?: unknown;
  /** Optional organism 9-system pulse summary (body; cortex is separate). */
  organism?: { health?: string; summary?: string } | null;
};

export type BuildMindHeartbeatInput = {
  nowMs: number;
  /** Rhythm pulseMs → metaphorical bpm when healthy. */
  pulseMs?: number | null;
  layers: MindHeartbeatLayers;
  /** Stamp age for layers built this tick (0 when present). */
  tickAgeMs?: number | null;
};

export type MindHeartbeat = {
  schema: typeof MIND_HEARTBEAT_SCHEMA;
  bpm: number;
  health: MindHeartbeatHealth;
  flow: string[];
  beats: MindHeartbeatBeat[];
  summary: string;
  efficient: {
    selfDriveBuildsPerTick: 1;
    captainBuildsPerTick: 1;
  };
  floorsIntact: boolean;
  organismNote: string | null;
};

function present(v: unknown): boolean {
  return v != null;
}

function layerDetail(
  id: MindHeartbeatLayerId,
  layer: unknown,
): { status: MindHeartbeatBeatStatus; detail: string } {
  if (!present(layer)) {
    if (id === "heartbeat") {
      return { status: "ok", detail: "cortex vitals emitter" };
    }
    return { status: "stale", detail: "missing this tick" };
  }

  // Captain heave / SelfDrive brake are healthy choices (beating, choosing skip)
  if (id === "captain") {
    const c = layer as {
      heaveTo?: boolean;
      voyageOrder?: string;
      coastGuard?: { floorsIntact?: boolean };
    };
    if (c.heaveTo === true) {
      return {
        status: "ok",
        detail: `heaveTo=${c.voyageOrder ?? "HEAVE_TO"} (skip is success)`,
      };
    }
    return {
      status: "ok",
      detail: `voyage=${c.voyageOrder ?? "HOLD_COURSE"}`,
    };
  }
  if (id === "selfDrive") {
    const s = layer as {
      safety?: { brake?: boolean };
      planAction?: string;
      brake?: boolean;
    };
    const brake = s.safety?.brake === true || s.brake === true;
    if (brake) {
      return {
        status: "ok",
        detail: `brake plan=${s.planAction ?? "PULL_OVER_SKIP"} (skip is success)`,
      };
    }
    return { status: "ok", detail: `plan=${s.planAction ?? "ok"}` };
  }
  if (id === "oracleV2") {
    const o = layer as { action?: string; risk_veto?: boolean };
    return {
      status: "ok",
      detail: `action=${o.action ?? "?"}${o.risk_veto ? " risk_veto" : ""}`,
    };
  }
  if (id === "phd") {
    const p = layer as {
      optionValueSkip?: { preferSkip?: boolean; score?: number };
    };
    const pref = p.optionValueSkip?.preferSkip === true;
    return {
      status: "ok",
      detail: pref
        ? `OV preferSkip score=${p.optionValueSkip?.score ?? "?"}`
        : "phd pack present",
    };
  }
  if (id === "council") {
    const c = layer as { resolved?: string; dissent?: unknown };
    return {
      status: "ok",
      detail: `resolved=${c.resolved ?? "?"}${c.dissent ? " +dissent" : ""}`,
    };
  }
  if (id === "reflex" || id === "tactical" || id === "strategic") {
    const l = layer as { verdict?: string; hard?: boolean };
    return {
      status: "ok",
      detail: `${l.verdict ?? "PASS"}${l.hard ? " hard" : ""}`,
    };
  }
  return { status: "ok", detail: "present" };
}

/**
 * Build Mind heartbeat vitals from cortex layers stamped this tick.
 */
export function buildMindHeartbeat(input: BuildMindHeartbeatInput): MindHeartbeat {
  const age =
    typeof input.tickAgeMs === "number" && Number.isFinite(input.tickAgeMs)
      ? Math.max(0, input.tickAgeMs)
      : 0;
  const L = input.layers;

  const byId: Record<string, unknown> = {
    reflex: L.reflex,
    tactical: L.tactical,
    strategic: L.strategic,
    phd: L.phd,
    council: L.council,
    oracleV2: L.oracleV2,
    selfDrive: L.selfDrive,
    captain: L.captain,
    heartbeat: { schema: MIND_HEARTBEAT_SCHEMA },
  };

  const beats: MindHeartbeatBeat[] = MIND_HEARTBEAT_FLOW.map((id) => {
    const { status, detail } = layerDetail(id, byId[id]);
    return {
      id,
      status,
      ageMs: status === "stale" ? null : age,
      detail,
    };
  });

  const goldenPresent = present(L.goldenEgg);
  const failN = beats.filter((b) => b.status === "fail").length;
  const staleN = beats.filter((b) => b.status === "stale").length;

  let floorsIntact = true;
  const cap = L.captain as
    | { coastGuard?: { floorsIntact?: boolean } }
    | null
    | undefined;
  if (cap?.coastGuard && cap.coastGuard.floorsIntact === false) {
    floorsIntact = false;
  }

  let health: MindHeartbeatHealth;
  if (failN > 0 || !floorsIntact) health = "critical";
  else if (staleN > 0) health = "degraded";
  else health = "alive";

  let bpm = 60;
  if (
    typeof input.pulseMs === "number" &&
    Number.isFinite(input.pulseMs) &&
    input.pulseMs > 0
  ) {
    bpm = Math.max(20, Math.min(180, Math.round(60_000 / input.pulseMs)));
  } else if (health !== "alive") {
    bpm = health === "critical" ? 30 : 45;
  }

  const okN = beats.filter((b) => b.status === "ok").length;
  const organismNote = L.organism?.summary
    ? `organism body: ${L.organism.summary}`
    : L.organism?.health
      ? `organism body health=${L.organism.health}`
      : "organism body vitals separate (9 systems); this is cortex";

  const summary =
    health === "alive"
      ? `MIND heartbeat alive · bpm=${bpm} · ${okN}/${beats.length} beats · flow single-pass · builds sd=1 cap=1${goldenPresent ? " · goldenEgg" : ""}`
      : health === "degraded"
        ? `MIND heartbeat degraded · bpm=${bpm} · stale=${staleN} · builds sd=1 cap=1`
        : `MIND heartbeat critical · bpm=${bpm} · fail=${failN} stale=${staleN} floorsIntact=${floorsIntact}`;

  return {
    schema: MIND_HEARTBEAT_SCHEMA,
    bpm,
    health,
    flow: [...MIND_HEARTBEAT_FLOW],
    beats,
    summary,
    efficient: {
      selfDriveBuildsPerTick: 1,
      captainBuildsPerTick: 1,
    },
    floorsIntact,
    organismNote,
  };
}
