/**
 * YES_40_55_PIN_SHADOW_V1 — retrospective unique-28 fixture + pure organ locks.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  YES_40_55_PIN_SHADOW_V1,
  classifyFrozenCcEntryShadow,
  summarizeShadowV1,
  FROZEN_CC_MIN_SECS,
  FROZEN_CC_MAX_SECS,
  FROZEN_CC_ASK_MIN,
  FROZEN_CC_ASK_MAX,
  FROZEN_CC_STILL_MID_MIN,
  FROZEN_CC_STILL_MID_MAX,
  type FrozenCcEntryShadowInput,
} from "./frozen-cc-entry-shadow.js";
import {
  decideFrozenCcEntry,
  emptyShadowFlags,
  FROZEN_CC_STRATEGY_ID,
  type FrozenCcEntryDecision,
  type FrozenSide,
} from "./frozen-cc.js";

type FixtureRow = {
  i: number;
  ticker: string;
  side: FrozenSide;
  ask: number;
  w2Reason: string;
  regimeWouldBlock: boolean;
  pnlCents: number;
  expect: {
    baseEligible: boolean;
    shadowSit: boolean;
    protectedCheapNo: boolean;
    protectedCheapYes: boolean;
    note: string;
  };
};

/** Official unique-28 Drive stamps (pnl actual). Classify as if baseEligible otherwise true. */
const UNIQUE28: FixtureRow[] = [
  { i: 1, ticker: "KXBTC15M-26SEP111030-30", side: "yes", ask: 43, w2Reason: "ha_disagree", regimeWouldBlock: false, pnlCents: 76,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "bucket A" } },
  { i: 2, ticker: "KXBTC15M-26SEP110000-00", side: "no", ask: 42, w2Reason: "ha_disagree", regimeWouldBlock: true, pnlCents: -1269,
    expect: { baseEligible: false, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "AND" } },
  { i: 3, ticker: "KXBTC15M-26SEP110030-30", side: "yes", ask: 46, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: 76,
    expect: { baseEligible: true, shadowSit: true, protectedCheapNo: false, protectedCheapYes: false, note: "SHADOW SIT" } },
  { i: 4, ticker: "KXBTC15M-26SEP110045-45", side: "yes", ask: 44, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -311,
    expect: { baseEligible: true, shadowSit: true, protectedCheapNo: false, protectedCheapYes: false, note: "SHADOW SIT" } },
  { i: 5, ticker: "KXBTC15M-26SEP110115-15", side: "yes", ask: 40, w2Reason: "ha_disagree", regimeWouldBlock: false, pnlCents: 661,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "A, not shadow" } },
  { i: 6, ticker: "KXBTC15M-26SEP110130-30", side: "yes", ask: 37, w2Reason: "ha_disagree", regimeWouldBlock: true, pnlCents: -406,
    expect: { baseEligible: false, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "AND" } },
  { i: 7, ticker: "KXBTC15M-26SEP110145-45", side: "no", ask: 40, w2Reason: "pin_reachable", regimeWouldBlock: true, pnlCents: 169,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: true, protectedCheapYes: false, note: "PROTECTED_CHEAP_NO" } },
  { i: 8, ticker: "KXBTC15M-26SEP110215-15", side: "yes", ask: 47, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: 305,
    expect: { baseEligible: true, shadowSit: true, protectedCheapNo: false, protectedCheapYes: false, note: "SHADOW SIT" } },
  { i: 9, ticker: "KXBTC15M-26SEP110230-30", side: "yes", ask: 43, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -517,
    expect: { baseEligible: true, shadowSit: true, protectedCheapNo: false, protectedCheapYes: false, note: "SHADOW SIT" } },
  { i: 10, ticker: "KXBTC15M-26SEP110245-45", side: "yes", ask: 40, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -548,
    expect: { baseEligible: true, shadowSit: true, protectedCheapNo: false, protectedCheapYes: false, note: "SHADOW SIT" } },
  { i: 11, ticker: "KXBTC15M-26SEP110415-15", side: "yes", ask: 48, w2Reason: "pin_reachable", regimeWouldBlock: true, pnlCents: -587,
    expect: { baseEligible: false, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "still-mid" } },
  { i: 12, ticker: "KXBTC15M-26SEP110500-00", side: "yes", ask: 43, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -575,
    expect: { baseEligible: true, shadowSit: true, protectedCheapNo: false, protectedCheapYes: false, note: "SHADOW SIT" } },
  { i: 13, ticker: "KXBTC15M-26SEP110515-15", side: "yes", ask: 46, w2Reason: "ha_disagree", regimeWouldBlock: true, pnlCents: -388,
    expect: { baseEligible: false, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "AND" } },
  { i: 14, ticker: "KXBTC15M-26SEP110545-45", side: "no", ask: 42, w2Reason: "pin_reachable", regimeWouldBlock: true, pnlCents: 653,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "not cheap-NO" } },
  { i: 15, ticker: "KXBTC15M-26SEP110600-00", side: "no", ask: 36, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -384,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: true, protectedCheapYes: false, note: "PROTECTED_CHEAP_NO" } },
  { i: 16, ticker: "KXBTC15M-26SEP110615-15", side: "no", ask: 42, w2Reason: "ha_disagree", regimeWouldBlock: true, pnlCents: -235,
    expect: { baseEligible: false, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "AND" } },
  { i: 17, ticker: "KXBTC15M-26SEP110630-30", side: "no", ask: 39, w2Reason: "ha_disagree", regimeWouldBlock: false, pnlCents: 620,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: true, protectedCheapYes: false, note: "A / PROTECTED_CHEAP_NO" } },
  { i: 18, ticker: "KXBTC15M-26SEP110700-00", side: "no", ask: 40, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -37,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: true, protectedCheapYes: false, note: "PROTECTED_CHEAP_NO" } },
  { i: 19, ticker: "KXBTC15M-26SEP110730-30", side: "no", ask: 44, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -216,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "not cheap-NO" } },
  { i: 20, ticker: "KXBTC15M-26SEP110745-45", side: "no", ask: 46, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -7,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "not cheap-NO" } },
  { i: 21, ticker: "KXBTC15M-26SEP110800-00", side: "no", ask: 32, w2Reason: "pin_reachable", regimeWouldBlock: true, pnlCents: -40,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: true, protectedCheapYes: false, note: "PROTECTED_CHEAP_NO regime alone" } },
  { i: 22, ticker: "KXBTC15M-26SEP110815-15", side: "no", ask: 37, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: 643,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: true, protectedCheapYes: false, note: "PROTECTED_CHEAP_NO" } },
  { i: 23, ticker: "KXBTC15M-26SEP110830-30", side: "no", ask: 34, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -557,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: true, protectedCheapYes: false, note: "PROTECTED_CHEAP_NO" } },
  { i: 24, ticker: "KXBTC15M-26SEP110915-15", side: "yes", ask: 38, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: -561,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "yes 38 not 40-55" } },
  { i: 25, ticker: "KXBTC15M-26SEP110930-30", side: "yes", ask: 47, w2Reason: "ha_disagree", regimeWouldBlock: false, pnlCents: 6,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: false, protectedCheapYes: false, note: "A, not shadow" } },
  { i: 26, ticker: "KXBTC15M-26SEP111015-15", side: "yes", ask: 43, w2Reason: "pin_reachable", regimeWouldBlock: true, pnlCents: -601,
    expect: { baseEligible: true, shadowSit: true, protectedCheapNo: false, protectedCheapYes: false, note: "SHADOW SIT regime alone" } },
  { i: 27, ticker: "KXBTC15M-26SEP111030-30", side: "yes", ask: 47, w2Reason: "pin_reachable", regimeWouldBlock: false, pnlCents: 68,
    expect: { baseEligible: true, shadowSit: true, protectedCheapNo: false, protectedCheapYes: false, note: "SHADOW SIT second 111030" } },
  { i: 28, ticker: "KXBTC15M-26SEP111115-15", side: "yes", ask: 35, w2Reason: "strike_disagree", regimeWouldBlock: false, pnlCents: 635,
    expect: { baseEligible: true, shadowSit: false, protectedCheapNo: false, protectedCheapYes: true, note: "PROTECTED_CHEAP_YES" } },
];

function baseInput(row: FixtureRow, overrides: Partial<FrozenCcEntryShadowInput> = {}): FrozenCcEntryShadowInput {
  return {
    paperMode: true,
    frozenCcMode: true,
    market: "KXBTC15M",
    quoteFresh: true,
    secsRemaining: 600,
    side: row.side,
    ask: row.ask,
    feeNetEvCents: 5,
    kellyFrac: 0.60,
    positionAndPendingClear: true,
    w2Reason: row.w2Reason,
    regimeWouldBlock: row.regimeWouldBlock,
    ...overrides,
  };
}

function deepFreeze<T>(obj: T): T {
  if (obj && typeof obj === "object") {
    Object.freeze(obj);
    for (const v of Object.values(obj as object)) {
      if (v && typeof v === "object" && !Object.isFrozen(v)) deepFreeze(v);
    }
  }
  return obj;
}

test("reuses frozen-cc band/time constants (no duplicate)", () => {
  assert.equal(FROZEN_CC_MIN_SECS, 180);
  assert.equal(FROZEN_CC_MAX_SECS, 780);
  assert.equal(FROZEN_CC_ASK_MIN, 20);
  assert.equal(FROZEN_CC_ASK_MAX, 55);
  assert.equal(FROZEN_CC_STILL_MID_MIN, 48);
  assert.equal(FROZEN_CC_STILL_MID_MAX, 52);
  assert.equal(YES_40_55_PIN_SHADOW_V1, "YES_40_55_PIN_SHADOW_V1");
});

test("unique-28: every row matches expected bucket stamps", () => {
  for (const row of UNIQUE28) {
    const got = classifyFrozenCcEntryShadow(baseInput(row));
    assert.equal(got.predicate, YES_40_55_PIN_SHADOW_V1, `row ${row.i}`);
    assert.equal(got.baseEligible, row.expect.baseEligible, `row ${row.i} baseEligible (${row.expect.note})`);
    assert.equal(got.shadowSit, row.expect.shadowSit, `row ${row.i} shadowSit (${row.expect.note})`);
    assert.equal(got.protectedCheapNo, row.expect.protectedCheapNo, `row ${row.i} cheapNo`);
    assert.equal(got.protectedCheapYes, row.expect.protectedCheapYes, `row ${row.i} cheapYes`);
  }
});

test("shadowSit candidates N=8, 3W-5L, pnl −2103; winners +449 losers −2552 net +2103", () => {
  const sits = UNIQUE28.filter((r) => classifyFrozenCcEntryShadow(baseInput(r)).shadowSit);
  assert.equal(sits.length, 8);
  const pnls = sits.map((r) => r.pnlCents);
  const wins = pnls.filter((p) => p > 0);
  const losses = pnls.filter((p) => p <= 0);
  assert.equal(wins.length, 3);
  assert.equal(losses.length, 5);
  const pnlCents = pnls.reduce((a, b) => a + b, 0);
  assert.equal(pnlCents, -2103);
  const winnersGivenUpCents = wins.reduce((a, b) => a + b, 0);
  const losersSavedCents = losses.reduce((a, b) => a + b, 0);
  assert.equal(winnersGivenUpCents, 449);
  assert.equal(losersSavedCents, -2552);
  assert.equal(-pnlCents, 2103);

  const summary = summarizeShadowV1(
    sits.map((r) => ({
      predicate: YES_40_55_PIN_SHADOW_V1,
      shadowSit: true,
      pnlCents: r.pnlCents,
    })),
  );
  assert.equal(summary.n, 8);
  assert.equal(summary.wins, 3);
  assert.equal(summary.losses, 5);
  assert.equal(summary.pnlCents, -2103);
  assert.equal(summary.winnersGivenUpCents, 449);
  assert.equal(summary.losersSavedCents, -2552);
  assert.equal(summary.netImprovementCents, 2103);
});

test("four bucket-A rows (1,5,17,25) remain unsat and pnl +1363", () => {
  const aIdx = [1, 5, 17, 25];
  const aRows = UNIQUE28.filter((r) => aIdx.includes(r.i));
  assert.equal(aRows.length, 4);
  let pnl = 0;
  for (const r of aRows) {
    const c = classifyFrozenCcEntryShadow(baseInput(r));
    assert.equal(c.baseEligible, true, `A row ${r.i}`);
    assert.equal(c.shadowSit, false, `A row ${r.i} unsat`);
    pnl += r.pnlCents;
  }
  assert.equal(pnl, 76 + 661 + 620 + 6);
  assert.equal(pnl, 1363);
});

test("111115 strike_disagree is PROTECTED_CHEAP_YES, NOT shadowSit; strike never overridden", () => {
  const row = UNIQUE28.find((r) => r.i === 28)!;
  const c = classifyFrozenCcEntryShadow(baseInput(row));
  assert.equal(row.ticker, "KXBTC15M-26SEP111115-15");
  assert.equal(c.shadowSit, false);
  assert.equal(c.protectedCheapYes, true);
  assert.equal(c.baseEligible, true);
  // Even if pin were somehow true, strike blocks shadowSit — prove with override attempt
  const forced = classifyFrozenCcEntryShadow(baseInput(row, { w2Reason: "strike_disagree" }));
  assert.equal(forced.shadowSit, false);
});

test("classify never mutates a FrozenCcEntryDecision object passed in", () => {
  const decision: FrozenCcEntryDecision = {
    kind: "TAKE",
    strategyId: FROZEN_CC_STRATEGY_ID,
    side: "yes",
    ask: 43,
    p: 0.55,
    ev: 5,
    confidence: 0.7,
    shadow: emptyShadowFlags(),
  };
  const snapshot = JSON.stringify(decision);
  deepFreeze(decision);
  const c = classifyFrozenCcEntryShadow(
    baseInput(UNIQUE28[2]!, { decision }),
  );
  assert.equal(c.shadowSit, true);
  assert.equal(JSON.stringify(decision), snapshot);
  assert.ok(Object.isFrozen(decision));
});

test("missing/UNKNOWN w2Reason → shadowSit=false (fail-open)", () => {
  const base = {
    paperMode: true,
    frozenCcMode: true,
    market: "KXBTC15M" as const,
    quoteFresh: true,
    secsRemaining: 600,
    side: "yes" as const,
    ask: 43,
    feeNetEvCents: 5,
    kellyFrac: 0.60,
    positionAndPendingClear: true,
    regimeWouldBlock: false,
  };
  assert.equal(classifyFrozenCcEntryShadow({ ...base, w2Reason: null }).shadowSit, false);
  assert.equal(classifyFrozenCcEntryShadow({ ...base, w2Reason: undefined }).shadowSit, false);
  assert.equal(classifyFrozenCcEntryShadow({ ...base, w2Reason: "UNKNOWN" }).shadowSit, false);
  assert.equal(classifyFrozenCcEntryShadow({ ...base, w2Reason: "" }).shadowSit, false);
  assert.equal(classifyFrozenCcEntryShadow({ ...base, w2Reason: "pin_reachable" }).shadowSit, true);
});

test("still-mid 48-52 → not baseEligible", () => {
  for (const ask of [48, 50, 52]) {
    const c = classifyFrozenCcEntryShadow({
      paperMode: true,
      frozenCcMode: true,
      market: "KXBTC15M",
      quoteFresh: true,
      secsRemaining: 600,
      side: "yes",
      ask,
      feeNetEvCents: 5,
      kellyFrac: 0.60,
      positionAndPendingClear: true,
      w2Reason: "pin_reachable",
      regimeWouldBlock: false,
    });
    assert.equal(c.baseEligible, false, `ask ${ask}`);
    assert.equal(c.shadowSit, false);
  }
});

test("AND (ha∧regime) → not baseEligible", () => {
  const c = classifyFrozenCcEntryShadow({
    paperMode: true,
    frozenCcMode: true,
    market: "KXBTC15M",
    quoteFresh: true,
    secsRemaining: 600,
    side: "yes",
    ask: 43,
    feeNetEvCents: 5,
    kellyFrac: 0.60,
    positionAndPendingClear: true,
    w2Reason: "ha_disagree",
    regimeWouldBlock: true,
  });
  assert.equal(c.baseEligible, false);
  assert.equal(c.shadowSit, false);
  assert.equal(c.reason, "AND_SIT_HA_REGIME");
});

test("regime alone / ha alone do not exclude baseEligible; protected never bypasses AND", () => {
  const regimeOnly = classifyFrozenCcEntryShadow({
    paperMode: true,
    frozenCcMode: true,
    market: "KXBTC15M",
    quoteFresh: true,
    secsRemaining: 600,
    side: "yes",
    ask: 43,
    feeNetEvCents: 5,
    kellyFrac: 0.60,
    positionAndPendingClear: true,
    w2Reason: "pin_reachable",
    regimeWouldBlock: true,
  });
  assert.equal(regimeOnly.baseEligible, true);
  assert.equal(regimeOnly.shadowSit, true);

  const haOnly = classifyFrozenCcEntryShadow({
    paperMode: true,
    frozenCcMode: true,
    market: "KXBTC15M",
    quoteFresh: true,
    secsRemaining: 600,
    side: "yes",
    ask: 43,
    feeNetEvCents: 5,
    kellyFrac: 0.60,
    positionAndPendingClear: true,
    w2Reason: "ha_disagree",
    regimeWouldBlock: false,
  });
  assert.equal(haOnly.baseEligible, true);
  assert.equal(haOnly.shadowSit, false);

  // Protected labels never bypass AND
  const andNo = classifyFrozenCcEntryShadow({
    paperMode: true,
    frozenCcMode: true,
    market: "KXBTC15M",
    quoteFresh: true,
    secsRemaining: 600,
    side: "no",
    ask: 32,
    feeNetEvCents: 5,
    kellyFrac: 0.60,
    positionAndPendingClear: true,
    w2Reason: "ha_disagree",
    regimeWouldBlock: true,
  });
  assert.equal(andNo.baseEligible, false);
  assert.equal(andNo.protectedCheapNo, false);
});

test("brtiSign is stratum echo only — never a gate", () => {
  const withOpp = classifyFrozenCcEntryShadow({
    paperMode: true,
    frozenCcMode: true,
    market: "KXBTC15M",
    quoteFresh: true,
    secsRemaining: 600,
    side: "yes",
    ask: 43,
    feeNetEvCents: 5,
    kellyFrac: 0.60,
    positionAndPendingClear: true,
    w2Reason: "pin_reachable",
    regimeWouldBlock: false,
    brtiSign: "opp",
  });
  assert.equal(withOpp.shadowSit, true);
  assert.equal(withOpp.brtiSign, "opp");
});

test("summarizeShadowV1 protected buckets from close tags", () => {
  const rows = UNIQUE28.map((r) => {
    const c = classifyFrozenCcEntryShadow(baseInput(r));
    return {
      predicate: YES_40_55_PIN_SHADOW_V1,
      shadowSit: c.shadowSit,
      protectedCheapNo: c.protectedCheapNo,
      protectedCheapYes: c.protectedCheapYes,
      pnlCents: r.pnlCents,
    };
  });
  const s = summarizeShadowV1(rows);
  assert.equal(s.n, 8);
  assert.equal(s.pnlCents, -2103);
  assert.ok(s.protectedCheapNo.n >= 1);
  assert.ok(s.protectedCheapYes.n >= 1);
  // Row 28 alone is protectedCheapYes
  assert.equal(s.protectedCheapYes.n, 1);
  assert.equal(s.protectedCheapYes.pnlCents, 635);
});

test("observe-only: classify does not change decideFrozenCcEntry output", () => {
  const aligned = {
    kind: "TAKE" as const,
    strategyId: FROZEN_CC_STRATEGY_ID,
    side: "yes" as const,
    ask: 46,
    p: 0.58,
    ev: 6,
    confidence: 0.7,
  };
  const input = {
    secsRemaining: 600,
    yesAsk: 46,
    noAsk: 54,
    cc: { signal: "YES" as const, confidence: 0.7 },
    aligned,
    shadow: { ...emptyShadowFlags(), w2Reason: "pin_reachable", regimeWouldBlock: false },
    andSitArmed: true,
  };
  const before = decideFrozenCcEntry(input);
  const shadow = classifyFrozenCcEntryShadow({
    paperMode: true,
    frozenCcMode: true,
    market: "KXBTC15M",
    quoteFresh: true,
    secsRemaining: 600,
    side: "yes",
    ask: 46,
    feeNetEvCents: 6,
    kellyFrac: 0.60,
    positionAndPendingClear: true,
    w2Reason: "pin_reachable",
    regimeWouldBlock: false,
    decision: before,
  });
  const after = decideFrozenCcEntry(input);
  assert.equal(before.kind, "TAKE");
  assert.equal(after.kind, "TAKE");
  assert.equal(shadow.shadowSit, true);
  assert.deepEqual(before, after);
});
