/**
 * scripts/run-policy-grid-search.ts
 *
 * GO — BOUNDED WALK-FORWARD POLICY SEARCH (2026-08-23), user-directed
 * one-off research run. Enumerates the exact bounded grid the user
 * specified, runs each candidate through the causal backtest-lab-v5 engine
 * over real historical BTC candles, ranks candidates by pooled sequential
 * walk-forward OOS fee-net P&L, and reports the top 5 against a
 * live-approximating baseline — with strict verdict discipline (never
 * forces a winner when the gap is within bootstrap noise).
 *
 * HARD CONTRACT (identical to regression-runner.ts's): this script NEVER
 * writes to `.bot-config.json`, calls any BotConfig setter, or otherwise
 * touches live/paper trading behavior. It only reads real market data and
 * writes its own report files under docs/policy-grid-search/.
 *
 * Search space (exactly as specified, ≤200-400 eval cap):
 *   minConfidence      {52, 55, 58, 62}
 *   minVelocity        {18, 24, 30}
 *   consensusMode      'solo'      (FIXED)
 *   packMode           'enforce'   (FIXED)
 *   packConfBumpMax    {0, 1}
 *   sizeModel          'fixed1' | 'halfKellyCapped'
 *     fixed1:            (no further axes)                     ->  4*3*2        = 24 combos
 *     halfKellyCapped:   maxContracts {8,12} x portfolioRiskPct {0.05,0.06} -> 4*3*2*2*2 = 96 combos
 *   TOTAL MAIN GRID = 120 combos (well under the 200-400 cap)
 *
 * Fixed / never searched: EV floor (3% of entry, inside decideAtPoint,
 * untouched), quarantine list (BRTI/MTF/SAKATA/OTM families — see
 * grid-policy.ts's GRID_QUARANTINED_STRATEGY_IDS), specialistPacksMode
 * enforce, realistic fee/slip model (real Kalshi taker fee + policy.slipCents).
 *
 * Early-exit (thesis-break proxy) is NOT part of the main grid — it is run
 * only as a sensitivity cut on the top-5 candidates (ON vs OFF), reported
 * without assuming either direction is better.
 */

import fs from 'fs';
import path from 'path';
import { fetchRealCandles } from '../src/lib/market-candles.js';
import { groupIntoPeriods } from '../src/lib/backtest-lab-v5/causal-sim.js';
import { POLICY_LEAN } from '../src/lib/backtest-lab-v5/sim-policy.js';
import type { SimPolicy } from '../src/lib/backtest-lab-v5/sim-policy.js';
import {
  makeGridPolicy, runGridPolicyOverPeriods, precomputeObservations,
  GRID_QUARANTINED_STRATEGY_IDS,
} from '../src/lib/backtest-lab-v5/grid-policy.js';
import type { GridPolicy, SizeModel } from '../src/lib/backtest-lab-v5/grid-policy.js';
import { pooledOosMetrics, decideVerdict } from '../src/lib/backtest-lab-v5/validation.js';
import type { PolicyMetrics } from '../src/lib/backtest-lab-v5/validation.js';
import { runPoisonTest, LIMITATIONS as LAB_LIMITATIONS } from '../src/lib/backtest-lab-v5/regression-runner.js';

const REPORT_DIR = path.join(process.cwd(), 'docs', 'policy-grid-search');
const LOOKBACK_DAYS = 180;
const INTERVAL_MINS = 5 as const;
const CANDLE_COUNT = Math.round((LOOKBACK_DAYS * 24 * 60) / INTERVAL_MINS);

// ── Grid enumeration ────────────────────────────────────────────────────────

interface GridSpec {
  id: string;
  minConfidence: number;
  minVelocity: number;
  packConfBumpMax: number;
  sizeModel: SizeModel;
  maxContracts: number;
  portfolioRiskPct: number;
}

function buildGrid(): GridSpec[] {
  const confidences = [52, 55, 58, 62];
  const velocities = [18, 24, 30];
  const bumpMaxes = [0, 1];
  const specs: GridSpec[] = [];
  for (const c of confidences) {
    for (const v of velocities) {
      for (const bump of bumpMaxes) {
        specs.push({ id: `c${c}-v${v}-b${bump}-fixed1`, minConfidence: c, minVelocity: v, packConfBumpMax: bump, sizeModel: 'fixed1', maxContracts: 1, portfolioRiskPct: 0 });
        for (const mc of [8, 12]) {
          for (const pr of [0.05, 0.06]) {
            specs.push({
              id: `c${c}-v${v}-b${bump}-kelly-mc${mc}-pr${Math.round(pr * 100)}`,
              minConfidence: c, minVelocity: v, packConfBumpMax: bump,
              sizeModel: 'halfKellyCapped', maxContracts: mc, portfolioRiskPct: pr,
            });
          }
        }
      }
    }
  }
  return specs;
}

function specToPolicy(spec: GridSpec): GridPolicy {
  const gp = makeGridPolicy(POLICY_LEAN, {
    id: spec.id, label: spec.id,
    sizeModel: spec.sizeModel, maxContracts: spec.maxContracts, portfolioRiskPct: spec.portfolioRiskPct,
    earlyExitEnabled: false,
  });
  gp.minConfidence = spec.minConfidence;
  gp.minVelocity = spec.minVelocity;
  gp.packConfBumpMax = spec.packConfBumpMax;
  return gp;
}

/**
 * Baseline = current LIVE policy, approximated as a GridPolicy.
 *
 * IMPORTANT FINDING: sim-policy.ts's POLICY_LEAN constant documents
 * minConfidence=55 ("persisted .bot-config.json, Step 5A, 2026-08-22"), but
 * the ACTUAL current .bot-config.json (read 2026-08-23) has minConfidence=52
 * — live config has drifted since that comment was written. This baseline
 * uses the REAL current value (52), not the stale preset, and that drift is
 * called out explicitly in the report rather than silently masked.
 */
function buildBaselinePolicy(): GridPolicy {
  const gp = makeGridPolicy(POLICY_LEAN, {
    id: 'BASELINE_LIVE_APPROX', label: 'Baseline (current live policy, approximated)',
    sizeModel: 'halfKellyCapped', maxContracts: 15, portfolioRiskPct: 0.06,
    earlyExitEnabled: false,
  });
  gp.minConfidence = 52;   // CURRENT .bot-config.json value (not stale POLICY_LEAN 55 — see doc above)
  gp.minVelocity = 24;     // matches .bot-config.json
  gp.packConfBumpMax = 1;  // matches .bot-config.json / specialist-packs.ts clamp
  return gp;
}

// ── Candidate result shape ───────────────────────────────────────────────────

interface CandidateResult {
  spec: GridSpec | { id: string; label: string };
  policy: GridPolicy;
  metrics: PolicyMetrics;
  stopExitRate: number | null; // null when earlyExitEnabled=false (not modeled in main grid)
}

function runCandidate(
  fullSeries: Awaited<ReturnType<typeof fetchRealCandles>>['candles'],
  periods: ReturnType<typeof groupIntoPeriods>,
  obsMap: ReturnType<typeof precomputeObservations>,
  policy: GridPolicy,
): CandidateResult {
  const { trades } = runGridPolicyOverPeriods(fullSeries, periods, policy, obsMap);
  const metrics = pooledOosMetrics(trades as any, 3);
  const stopExitRate = policy.earlyExitEnabled
    ? (trades.length ? trades.filter(t => t.exitedEarly).length / trades.length : 0)
    : null;
  return { spec: { id: policy.id, label: policy.label }, policy, metrics, stopExitRate };
}

// ── Verdict relabeling (decideVerdict is written for LEAN/LEGACY naming —
//    reused as-is for its statistics, relabeled for readability here) ──────

function relabelVerdict(raw: ReturnType<typeof decideVerdict>, leanLabel: string, legacyLabel: string) {
  return {
    verdict: raw.verdict === 'LEAN_WINS' ? 'CANDIDATE_WINS' : raw.verdict === 'LEGACY_WINS' ? 'BASELINE_WINS' : 'INCONCLUSIVE',
    reason: raw.reason.replaceAll('LEAN', leanLabel).replaceAll('LEGACY', legacyLabel),
  };
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  console.log(`[grid-search] Fetching ${CANDLE_COUNT} real ${INTERVAL_MINS}m BTC candles (${LOOKBACK_DAYS}d lookback)...`);
  const { candles, source } = await fetchRealCandles(Date.now() - LOOKBACK_DAYS * 24 * 60 * 60 * 1000, CANDLE_COUNT, INTERVAL_MINS);
  const periods = groupIntoPeriods(candles);
  console.log(`[grid-search] Got ${candles.length} candles from ${source} -> ${periods.length} 15-min periods.`);

  console.log(`[grid-search] Precomputing decision observations (shared across all grid candidates)...`);
  const obsMap = precomputeObservations(candles, periods);

  const grid = buildGrid();
  console.log(`[grid-search] Grid size: ${grid.length} combos (cap: 200-400). Running...`);

  const t0 = Date.now();
  const baselinePolicy = buildBaselinePolicy();
  const baselineResult = runCandidate(candles, periods, obsMap, baselinePolicy);

  const results: CandidateResult[] = grid.map((spec, i) => {
    if (i > 0 && i % 20 === 0) console.log(`[grid-search]   ...${i}/${grid.length}`);
    const policy = specToPolicy(spec);
    return { ...runCandidate(candles, periods, obsMap, policy), spec };
  });
  const elapsedMs = Date.now() - t0;
  console.log(`[grid-search] Done: ${grid.length} candidates in ${(elapsedMs / 1000).toFixed(1)}s.`);

  // Rank by pooled OOS fee-net P&L, descending.
  const ranked = [...results].sort((a, b) => b.metrics.feeNetPnlCents - a.metrics.feeNetPnlCents);
  const top5 = ranked.slice(0, 5);

  // Verdict: best candidate vs baseline.
  const best = top5[0];
  const verdictRaw = decideVerdict(best.metrics, baselineResult.metrics);
  const verdict = relabelVerdict(verdictRaw, `CANDIDATE(${best.policy.id})`, 'BASELINE');

  // Poison/lookahead guard — reuse the existing primitive on the winning
  // candidate's policy (GridPolicy is structurally a superset of SimPolicy).
  const poisonSampleSize = Math.min(candles.length, 300);
  const poisonTest = runPoisonTest(candles.slice(0, poisonSampleSize), best.policy as unknown as SimPolicy);

  // Early-exit sensitivity cut — top-5 candidates only, ON vs OFF, no winner assumed.
  const earlyExitSensitivity = top5.map(r => {
    const onPolicy: GridPolicy = { ...r.policy, earlyExitEnabled: true, id: `${r.policy.id}+earlyExit`, label: `${r.policy.label} (early-exit ON)` };
    const onResult = runCandidate(candles, periods, obsMap, onPolicy);
    return {
      candidateId: r.policy.id,
      earlyExitOff: { feeNetPnlCents: r.metrics.feeNetPnlCents, trades: r.metrics.trades, winRate: r.metrics.winRate, maxDrawdown: r.metrics.maxDrawdown },
      earlyExitOn: { feeNetPnlCents: onResult.metrics.feeNetPnlCents, trades: onResult.metrics.trades, winRate: onResult.metrics.winRate, maxDrawdown: onResult.metrics.maxDrawdown, stopExitRate: onResult.stopExitRate },
    };
  });

  const limitations = [
    ...LAB_LIMITATIONS,
    'Sizing (halfKellyCapped) is a NEW approximation of live Kelly/portfolio-risk sizing added for this search (half-Kelly on a fixed $1,000 reference bankroll, capped by maxContracts/portfolioRiskPct/9% hard ceiling) — it does not model live stack tiers (probe/standard/press), the ARIA sizing overlay, HARVEST/session multipliers, or real compound-mode balance tracking.',
    'The early-exit (thesis-break) proxy only has ONE causal checkpoint per period (minute-10, for minute-5 admissions only) since this lab groups candles into 3-candle (15-min) periods — it cannot model a continuous stop-loss trigger the way the live bot\'s real-time quote stream does. It is a coarse, honestly-approximate proxy, not a replay of live exit logic.',
    'Quarantine (BRTI/MTF/SAKATA/OTM) is enforced as a POST-selection override (force the decision to non-admitted) rather than removing those strategies from the candidate pool before selection — conservative (can only reduce trade count), not a bug, but not identical to how live pack filtering would exclude them upstream.',
    `Baseline uses .bot-config.json's ACTUAL current minConfidence=52, not sim-policy.ts's POLICY_LEAN preset (documented as 55) — that preset has drifted stale relative to a live config change; flagged here rather than silently masked.`,
    `Backtest window is ${LOOKBACK_DAYS} days of real ${source} 5-min OHLC — a real, single, contiguous market regime sample. This is NOT a claim of testing "all market conditions"; see the sequential 3-fold walk-forward split for how this window's own regime drift is handled, but a longer/independent out-of-window validation before any live change is still warranted.`,
  ];

  const report = {
    generatedAt: new Date().toISOString(),
    lookbackDays: LOOKBACK_DAYS,
    candleCount: candles.length,
    candleSource: source,
    periodCount: periods.length,
    gridSize: grid.length,
    gridCapAcknowledged: '≤200-400 evals per user spec — actual: ' + grid.length,
    quarantinedStrategyIds: Array.from(GRID_QUARANTINED_STRATEGY_IDS),
    baseline: { id: baselinePolicy.id, policy: baselinePolicy, metrics: baselineResult.metrics },
    top5: top5.map(r => ({ id: r.policy.id, policy: r.policy, metrics: r.metrics, stopExitRate: r.stopExitRate })),
    verdict,
    poisonTest,
    earlyExitSensitivity,
    limitations,
    noLiveConfigWrites: true,
    doNotDeployWithoutHumanAck: 'This report is research output only. No .bot-config.json, BotConfig, paperMode, or live setting was written by this run. Any adoption of a candidate policy requires explicit human review and ACK before touching paper or live config.',
  };

  fs.mkdirSync(REPORT_DIR, { recursive: true });
  const stamp = report.generatedAt.replace(/[:.]/g, '-');
  const jsonPath = path.join(REPORT_DIR, `${stamp}.json`);
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2));
  console.log(`[grid-search] Report written to ${jsonPath}`);

  return report;
}

main().then(report => {
  console.log('\n=== SUMMARY ===');
  console.log(`Grid size: ${report.gridSize} (cap 200-400)`);
  console.log(`Baseline (${report.baseline.id}): trades=${report.baseline.metrics.trades} winRate=${(report.baseline.metrics.winRate * 100).toFixed(1)}% feeNet=${report.baseline.metrics.feeNetPnlCents.toFixed(0)}c maxDD=${(report.baseline.metrics.maxDrawdown * 100).toFixed(1)}% PF=${report.baseline.metrics.profitFactor.toFixed(2)} wrongKit=${(report.baseline.metrics.wrongKitRate * 100).toFixed(1)}%`);
  console.log('\nTop 5 candidates by OOS fee-net:');
  for (const c of report.top5) {
    console.log(`  ${c.id}: trades=${c.metrics.trades} winRate=${(c.metrics.winRate * 100).toFixed(1)}% feeNet=${c.metrics.feeNetPnlCents.toFixed(0)}c CI=[${c.metrics.feeNetCI.p5.toFixed(2)},${c.metrics.feeNetCI.p95.toFixed(2)}] maxDD=${(c.metrics.maxDrawdown * 100).toFixed(1)}% PF=${c.metrics.profitFactor.toFixed(2)} wrongKit=${(c.metrics.wrongKitRate * 100).toFixed(1)}%`);
  }
  console.log(`\nVERDICT: ${report.verdict.verdict} — ${report.verdict.reason}`);
  console.log(`Poison test: ${report.poisonTest.passed ? 'PASSED' : 'FAILED'} (${report.poisonTest.periodsChecked} checked, ${report.poisonTest.mismatches.length} mismatches)`);
  console.log(`\n${report.doNotDeployWithoutHumanAck}`);
  console.log('\nSTOP — awaiting human review/ACK before any config change.');
  process.exit(0);
}).catch(err => {
  console.error('[grid-search] FAILED:', err);
  process.exit(1);
});
