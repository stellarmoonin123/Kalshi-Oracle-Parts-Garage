import { botTrades } from "@workspace/db";
import { sql } from "drizzle-orm";

/**
 * A submitted order is the denominator for fill rate. `outcome` is settlement
 * state, not execution state: a genuinely filled open trade remains pending
 * until it resolves, so it must not be excluded from this count.
 *
 * The resolved-outcome fallback keeps historical rows from before
 * order_placed_at was added in the denominator without counting unresolved
 * submission intents.
 */
export const acceptedOrderForFillRate = sql`(
  ${botTrades.orderPlacedAt} IS NOT NULL
  OR ${botTrades.orderId} IS NOT NULL
  OR ${botTrades.filledAt} IS NOT NULL
  OR ${botTrades.outcome} IN ('win', 'loss', 'cancelled')
)`;

export interface FillAggregate {
  placed: number;
  filled: number;
  cancelled: number;
  slippageSamples: number;
  totalSlippageCents: number;
}

export function summarizeFillAggregate(stats: FillAggregate) {
  return {
    placed: stats.placed,
    filled: stats.filled,
    cancelled: stats.cancelled,
    avgSlippageCents: stats.slippageSamples > 0
      ? Math.round((stats.totalSlippageCents / stats.slippageSamples) * 10) / 10
      : null,
    fillRate: stats.placed > 0
      ? Math.round((stats.filled / stats.placed) * 1000) / 1000
      : null,
  };
}