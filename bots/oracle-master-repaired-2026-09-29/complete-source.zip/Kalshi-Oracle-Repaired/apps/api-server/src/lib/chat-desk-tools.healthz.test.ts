/** Chat desk tools read the real /healthz + trade shapes (polish 2026-09-25). */
import { test } from "node:test";
import assert from "node:assert/strict";
import { runDeskTool } from "./chat-desk-tools.js";

const healthz = {
  healthy: true,
  build: { gitSha: "a881e25ba4d1" },
  watchdog: { subsystems: { "kalshi-ws": { status: "ok" } } },
  subsystems: {
    database: { ok: true, latencyMs: 3, incidentCount24h: 35, incidentTimestamps: [1, 2, 3] },
    websocket: { connected: true, status: "ok", incidentTimestamps: [4] },
    calib: { n: 39, ece: 0.0971, reliable: false, nFill: 0, nShadow: 39 },
    calibration: { brierScore: 0.1897, brierSamples: 200, directionThreshold: 0.55, buckets: {} },
    bot: { state: "WATCHING", paperMode: true },
  },
};
const deps: any = {
  getStatus: () => ({ state: "WATCHING", config: { paperMode: true } }),
  getRecentTrades: async () => [{ id: 74, ticker: "KXBTC15M-26SEP251100-00", side: "no", contracts: 17, entryPriceCents: 39, fillPriceCents: 39, slippageCents: 2, exitMktPrice: 58, exitReason: "PATH_RIDE_TP", feeCents: 58, outcome: "win", pnlCents: 265, settledSide: "YES", isPaper: true }],
  healthz: async () => healthz,
};

test("get_healthz reports db + websocket from subsystems (was always null)", async () => {
  const h = JSON.parse(await runDeskTool("get_healthz", {}, deps));
  assert.equal(h.healthy, true);
  assert.equal(h.gitSha, "a881e25ba4d1");
  assert.equal(h.db.ok, true);
  assert.equal(h.db.incidentTimestamps, undefined, "bulky timestamps dropped");
  assert.equal(h.ws.connected, true);
  assert.equal(h.mindCalibration.ece, 0.0971);
});

test("get_calibration returns Mind calibration from healthz.subsystems.calib", async () => {
  const c = JSON.parse(await runDeskTool("get_calibration", {}, deps));
  assert.equal(c.mind.n, 39);
  assert.equal(c.mind.reliable, false);
  assert.equal(c.settlementModel.brierScore, 0.1897);
});

test("get_recent_trades includes fill, slippage, exit price and fee-net P&L", async () => {
  const [t] = JSON.parse(await runDeskTool("get_recent_trades", { n: 1 }, deps));
  assert.deepEqual({ entry: t.entry, slip: t.slip, exitPx: t.exitPx, fee: t.fee, pnlFeeNet: t.pnlFeeNet, settled: t.settled }, { entry: 39, slip: 2, exitPx: 58, fee: 58, pnlFeeNet: 265, settled: "YES" });
});
