import test from "node:test";
import assert from "node:assert/strict";
import {
  isGridSearchRunning,
  releaseGridSearch,
  tryAcquireGridSearch,
} from "./backtest-run-lock.js";

test("#134 second acquire fails until release", () => {
  releaseGridSearch();
  assert.equal(tryAcquireGridSearch(), true);
  assert.equal(isGridSearchRunning(), true);
  assert.equal(tryAcquireGridSearch(), false);
  releaseGridSearch();
  assert.equal(isGridSearchRunning(), false);
  assert.equal(tryAcquireGridSearch(), true);
  releaseGridSearch();
});
