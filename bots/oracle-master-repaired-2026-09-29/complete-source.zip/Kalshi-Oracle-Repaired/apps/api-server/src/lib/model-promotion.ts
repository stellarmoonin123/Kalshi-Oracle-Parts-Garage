/**
 * model-promotion.ts — GO: INSTITUTIONAL PROMOTION + ADMISSION SURVIVAL
 * ANALYSIS, Part I (Auto-Canary Protocol), 2026-08-25.
 *
 * Read docs/model-promotion-protocol-v2.md FIRST; this file implements
 * exactly what that document pre-registers, in the same order.
 *
 * Computes the 9-gate vector (G1-G9) for the v4.1 shadow model every
 * EVALUATOR_INTERVAL_MS, writes ONE immutable row to model_promotion_audit
 * every cycle (transition or not), and is the ONLY place in the codebase
 * allowed to call market-learning-v2.ts's applyLearningMode() for an
 * UPWARD (shadow->canary) transition — and only when every gate is true.
 * canary->full is never called from here; it requires a separate, explicit
 * human "APPLY FULL" (out of scope for this file — see Part III note in the
 * protocol doc, not implemented).
 *
 * ── Locks (do not touch from this file) ────────────────────────────────
 * Same as market-learning-v2.ts / market-learning-v4.ts: live EV/PATH_GATE,
 * packs, consensus, quarantine, minConfidence values; BRTI/MTF/SAKATA/OTM
 * enablement. This file never mutates BotConfig and never calls
 * applyLearningMode(..., "full", ...) — that is a human-only action.
 */

import { db, modelPromotionAudit } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { getLearningState, applyLearningMode, autoRevertCanaryIfFailing } from "./market-learning-v2.js";
import {
  evaluateWalkForwardV4, getBucketModelSummary, computeModelHashV4, computeFeatureListHashV4,
  V4_MODEL_VERSION, type WalkForwardReport,
} from "./market-learning-v4.js";
import { incidentStore, type Subsystem } from "./incident-store.js";
import {
  N_MIN_RESOLVED, CI_LOW_DELTA_MIN, LEAN_COVERAGE_MIN, TRADE_COUNT_RATIO_MAX, MAXDD_RATIO_MAX,
  SNAPSHOT_STALENESS_MS, PROMOTION_ELIGIBLE_MODEL_VERSION, EVALUATOR_INTERVAL_MS,
} from "./model-promotion-constants.js";

// ── Gate vector ──────────────────────────────────────────────────────────

export interface GateVector {
  G1_verdictWin: boolean;
  G2_nResolvedMet: boolean;
  G3_ciLowClears: boolean;
  G4_leanCoverageMet: boolean;
  G5_tradeCountRatioOk: boolean;
  G6_maxDdRatioOk: boolean;
  G7_snapshotFresh: boolean;
  G8_botNotHaltedOrKilled: boolean;
  G9_modelHashMatchesLastWin: boolean;
}

export interface GateEvaluation {
  gates: GateVector;
  allPass: boolean;
  failingGates: string[];
  walkForward: WalkForwardReport;
  modelHash: string;
  featureListHash: string;
  modelVersion: string;
  snapshotAgeMs: number;
}

let lastSnapshotAt = 0;
let lastSnapshot: WalkForwardReport | null = null;

/**
 * Wraps evaluateWalkForwardV4() with an in-process "when was this last
 * computed" timestamp so G7 can fail closed on a stale snapshot even though
 * evaluateWalkForwardV4() itself is stateless (recomputed from DB every
 * call — see market-learning-v4.ts). Kept module-local rather than
 * persisted: a process restart forces a fresh computation, which is the
 * safe direction to fail.
 */
async function getFreshWalkForwardSnapshot(): Promise<{ report: WalkForwardReport; ageMs: number }> {
  const report = await evaluateWalkForwardV4();
  lastSnapshot = report;
  lastSnapshotAt = Date.now();
  return { report, ageMs: 0 }; // freshly computed this instant — age is meaningful only for a cached read, which this module never does
}

/**
 * G8 — the bot must not be in a state where starting a new (even tiny,
 * canary-sized) live-money commitment would be irresponsible: an open
 * daily-loss halt, or any open incident on a safety-relevant subsystem.
 * Reads incident-store.ts directly (no trading-bot.ts import — see
 * market-learning-v4.ts header for why that import is forbidden here too).
 */
function isBotSafeForTransition(): { safe: boolean; reason?: string } {
  const safetySubsystems: Subsystem[] = ["position", "balance", "auth", "volfeed", "strategy", "modelAccuracy", "websocket", "settlement"];
  for (const s of safetySubsystems) {
    const since = incidentStore.getDegradedSince(s);
    if (since !== null) return { safe: false, reason: `incident open on '${s}' subsystem since ${new Date(since).toISOString()}` };
  }
  return { safe: true };
}

/** Most recent audit row whose G1 (verdict WIN) was true — the "last WIN evaluation" G9 anti-swap compares against. Returns null if the ledger has never observed a WIN (the honest current state). */
async function getLastWinModelHash(): Promise<string | null> {
  const [row] = await db.select({ modelHash: modelPromotionAudit.modelHash })
    .from(modelPromotionAudit)
    .where(eq(modelPromotionAudit.verdictWin, true))
    .orderBy(desc(modelPromotionAudit.ts))
    .limit(1);
  return row?.modelHash ?? null;
}

/**
 * Computes the full G1-G9 vector for the CURRENT in-memory model + freshest
 * DB-backed walk-forward snapshot. Pure with respect to its own inputs
 * (does not itself write anything) — callers decide whether to persist an
 * audit row and/or act on the result.
 */
export async function evaluateGateVector(): Promise<GateEvaluation> {
  const { report } = await getFreshWalkForwardSnapshot();
  const modelHash = computeModelHashV4();
  const featureListHash = computeFeatureListHashV4();
  const lastWinHash = await getLastWinModelHash();
  const botSafety = isBotSafeForTransition();

  const gates: GateVector = {
    G1_verdictWin: report.verdict === "WIN",
    G2_nResolvedMet: report.nResolved >= N_MIN_RESOLVED,
    G3_ciLowClears: report.ciLowCents > CI_LOW_DELTA_MIN,
    G4_leanCoverageMet: report.leanReplayCoveragePct >= LEAN_COVERAGE_MIN * 100,
    G5_tradeCountRatioOk: report.tradeCountRatio <= TRADE_COUNT_RATIO_MAX,
    G6_maxDdRatioOk: report.maxDrawdownRatio <= MAXDD_RATIO_MAX,
    G7_snapshotFresh: true, // freshly computed above in the same call — see getFreshWalkForwardSnapshot() comment
    G8_botNotHaltedOrKilled: botSafety.safe,
    // If we've never logged a WIN before, this is by construction the FIRST
    // WIN candidate — nothing to have swapped away from, so it passes. Once
    // a WIN has been logged, every later transition attempt must match it.
    G9_modelHashMatchesLastWin: lastWinHash === null || lastWinHash === modelHash,
  };

  const failingGates = Object.entries(gates).filter(([, v]) => !v).map(([k]) => k);
  const modelEligible = V4_MODEL_VERSION === PROMOTION_ELIGIBLE_MODEL_VERSION;
  if (!modelEligible) failingGates.push("MODEL_VERSION_NOT_PROMOTION_ELIGIBLE");

  return {
    gates,
    allPass: failingGates.length === 0,
    failingGates,
    walkForward: report,
    modelHash,
    featureListHash,
    modelVersion: V4_MODEL_VERSION,
    snapshotAgeMs: 0,
  };
}

// ── Audit ledger ─────────────────────────────────────────────────────────

async function writeAuditRow(opts: {
  fromMode: string; toMode: string; trigger: string; evaluation: GateEvaluation; operator?: string;
}): Promise<void> {
  try {
    await db.insert(modelPromotionAudit).values({
      fromMode: opts.fromMode,
      toMode: opts.toMode,
      trigger: opts.trigger,
      gatesJson: opts.evaluation.gates,
      verdictWin: opts.evaluation.gates.G1_verdictWin,
      modelVersion: opts.evaluation.modelVersion,
      modelHash: opts.evaluation.modelHash,
      featureListHash: opts.evaluation.featureListHash,
      nResolved: opts.evaluation.walkForward.nResolved,
      deltaFeeNetCents: opts.evaluation.walkForward.deltaFeeNetCents,
      ciLowCents: opts.evaluation.walkForward.ciLowCents,
      leanCoveragePct: opts.evaluation.walkForward.leanReplayCoveragePct,
      operator: opts.operator ?? "auto",
    });
  } catch (err) {
    console.warn("[model-promotion] audit row write failed:", (err as Error).message);
  }
}

// ── One evaluator cycle ──────────────────────────────────────────────────

/**
 * Runs one gate-evaluation cycle: computes G1-G9, writes exactly one audit
 * row, and — ONLY if every gate passes AND current mode is 'shadow' — calls
 * applyLearningMode('canary', ..., { auto: true }). This is the single
 * codepath in the whole promotion protocol allowed to move mode upward
 * automatically; it is expected to be a no-op (mode stays 'shadow') for a
 * long time given current live data volume (nResolved << N_MIN_RESOLVED).
 * Also delegates the existing canary->shadow auto-revert check to v2's own
 * autoRevertCanaryIfFailing() so this protocol and v2's don't race on two
 * separate revert implementations.
 */
export async function runPromotionEvaluatorCycle(): Promise<GateEvaluation> {
  const state = await getLearningState();
  const evaluation = await evaluateGateVector();

  if (state.mode === "shadow" && evaluation.allPass) {
    const result = await applyLearningMode("canary", `auto-canary: all gates passed (${JSON.stringify(evaluation.gates)})`, { auto: true });
    await writeAuditRow({
      fromMode: state.mode, toMode: result.success ? "canary" : state.mode,
      trigger: result.success ? "G_ALL_PASS_AUTO_CANARY" : `G_ALL_PASS_BUT_APPLY_FAILED:${result.reason}`,
      evaluation,
    });
  } else {
    await writeAuditRow({ fromMode: state.mode, toMode: state.mode, trigger: "DRY_RUN_NO_TRANSITION", evaluation });
  }

  // canary->shadow auto-revert stays owned by v2 (single implementation);
  // this just makes sure it still gets a tick even if nothing else calls it
  // for the v4.1-driven canary in the future.
  await autoRevertCanaryIfFailing();

  return evaluation;
}

// ── Reporting ────────────────────────────────────────────────────────────

export interface ModelPromotionReport {
  mode: string;
  evaluation: GateEvaluation;
  recentAuditRows: Array<{
    ts: Date; fromMode: string; toMode: string; trigger: string; nResolved: number;
    deltaFeeNetCents: number | null; ciLowCents: number | null; leanCoveragePct: number | null;
  }>;
}

export async function getModelPromotionReport(): Promise<ModelPromotionReport> {
  const state = await getLearningState();
  const evaluation = await evaluateGateVector();
  const rows = await db.select({
    ts: modelPromotionAudit.ts, fromMode: modelPromotionAudit.fromMode, toMode: modelPromotionAudit.toMode,
    trigger: modelPromotionAudit.trigger, nResolved: modelPromotionAudit.nResolved,
    deltaFeeNetCents: modelPromotionAudit.deltaFeeNetCents, ciLowCents: modelPromotionAudit.ciLowCents,
    leanCoveragePct: modelPromotionAudit.leanCoveragePct,
  }).from(modelPromotionAudit).orderBy(desc(modelPromotionAudit.ts)).limit(20);

  return { mode: state.mode, evaluation, recentAuditRows: rows };
}

// ── Lifecycle ────────────────────────────────────────────────────────────

let evaluatorTimer: NodeJS.Timeout | null = null;

/** Called once from market-learning.ts's startMarketLearning(). Dormant in effect (mode stays 'shadow') until every G1-G9 gate genuinely passes. */
export function startModelPromotionEvaluator(): void {
  if (evaluatorTimer) return;
  void runPromotionEvaluatorCycle().catch(err => console.warn("[model-promotion] initial cycle failed:", (err as Error).message));
  evaluatorTimer = setInterval(() => {
    void runPromotionEvaluatorCycle().catch(err => console.warn("[model-promotion] cycle failed:", (err as Error).message));
  }, EVALUATOR_INTERVAL_MS);
  console.info(`[model-promotion] Started — auto-canary gate evaluator every ${EVALUATOR_INTERVAL_MS / 60_000}m (shadow-only until all G1-G9 pass)`);
}
