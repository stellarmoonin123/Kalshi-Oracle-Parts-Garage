/**
 * alignedTakeGate isolate — UNCHANGED holes at isolate time:
 *   CONFLUENCE_CASCADE inherits LAG_UNPROVEN
 *   opposed YES vs MTF short is veto-only (does not construct cheap NO)
 *   leftover id can still TAKE / beat CC
 *   analog last-close-vs-next-close / HA green → YES (ignores Kalshi strike)
 * Compare-only. Not a live selector.
 */
import type { AlignedMtfSign, AlignedTake, AlignedTakeInput } from "./aligned-take-gate.js";

function inBand(ask: number | null | undefined): ask is number {
  return typeof ask === "number" && Number.isFinite(ask) && ask >= 28 && ask <= 55;
}

/** Frozen analog mapper: long / HA green / spot>lastClose → YES. Not Kalshi strike. */
export function analogMtfSignToSide(mtfSign: AlignedMtfSign): "yes" | "no" | null {
  if (mtfSign === "long" || mtfSign === "yes") return "yes";
  if (mtfSign === "short" || mtfSign === "no") return "no";
  if (typeof mtfSign === "number" && Number.isFinite(mtfSign)) {
    if (mtfSign > 0) return "yes";
    if (mtfSign < 0) return "no";
  }
  return null;
}

/** Isolate analog HA: candle color close-vs-close → YES/NO. */
export function analogHaColorToSide(color: "green" | "red"): "yes" | "no" {
  return color === "green" ? "yes" : "no";
}

/** Isolate analog BTC: spot>lastClose → YES. Disagrees with Kalshi floor/strike. */
export function analogSpotVsLastCloseToSide(
  spot: number | null | undefined,
  lastClose: number | null | undefined,
): "yes" | "no" | null {
  if (typeof spot !== "number" || !Number.isFinite(spot) || !(spot > 0)) return null;
  if (typeof lastClose !== "number" || !Number.isFinite(lastClose) || !(lastClose > 0)) return null;
  if (spot > lastClose) return "yes";
  if (spot < lastClose) return "no";
  return null;
}

export function alignedTakeGateIsolate(input: AlignedTakeInput): AlignedTake {
  const mtfSide = analogMtfSignToSide(input.mtfSign);
  if (input.lagProven !== true) {
    return { kind: "SKIP", reason: "LAG_UNPROVEN" };
  }
  if (input.strategyId && input.strategyId !== "CONFLUENCE_CASCADE" && input.strategyId !== "BASIS_LAG_EDGE") {
    const ask = input.yesAsk;
    if (inBand(ask) && mtfSide) {
      const p = typeof input.p === "number" ? input.p : 0.54;
      const ev = typeof input.ev === "number" ? input.ev : 10;
      return { kind: "TAKE", strategyId: "CONFLUENCE_CASCADE", side: "yes", ask, p, ev };
    }
  }
  if (!mtfSide) return { kind: "SKIP", reason: "mtf_sign_null" };
  // Hole: YES-ask book only. Analog long maps to YES. Strike cheap NO is ignored.
  if (mtfSide === "no") {
    if (inBand(input.yesAsk)) return { kind: "SKIP", reason: "opposed_side" };
    return { kind: "SKIP", reason: "ask_out_of_band" };
  }
  if (inBand(input.yesAsk)) {
    const p = typeof input.p === "number" ? input.p : 0.54;
    const ev = typeof input.ev === "number" ? input.ev : 10;
    return { kind: "TAKE", strategyId: "CONFLUENCE_CASCADE", side: "yes", ask: input.yesAsk, p, ev };
  }
  return { kind: "SKIP", reason: "ask_out_of_band" };
}

export function overlayAlignedTakeIsolate<T extends { strategyId: string; signal: string }>(
  selected: T | null,
  _pool: T[],
  _gate: AlignedTake,
): T | null {
  return selected;
}
