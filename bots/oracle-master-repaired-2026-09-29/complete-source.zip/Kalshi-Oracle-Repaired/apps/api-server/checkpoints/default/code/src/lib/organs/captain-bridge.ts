/**
 * Captain Bridge — unify SelfDrive + oracleV2 + PhD into one voyage order.
 *
 * Ship metaphor (see docs/CAPTAIN_BRIDGE.md):
 *   Captain = this module — issues one voyage order
 *   Bridge officers = FORECASTER/ADVERSARY/MICRO/RISK + SelfDrive + PhD
 *   Engine room = deterministic bot (six-gate, PATH_RIDE, fills) — hands, not mouth
 *   Coast guard = floors — captain CANNOT override
 *   Destination = fee-net + survive
 *   Heave-to = SKIP/ABSTAIN (first-class success)
 *
 * Pure. No network. No LLM. Never replaces decideFrozenCcEntry / PATH_RIDE / tick.
 * Never cuts floors (EV≥3¢ / Kelly≤0.60 / ask 20–55 / 9%).
 */
export const CAPTAIN_BRIDGE_LOADED = "CAPTAIN_BRIDGE_LOADED" as const;

/** Mirror floors — must stay equal to MIND_FLOOR_LOCKS (tested). */
export const CAPTAIN_FLOOR_MIRROR = {
  evFloorCents: 3,
  kellyCap: 0.6,
  maxRiskPctPerTrade: 0.09,
  askMinCents: 20,
  askMaxCents: 55,
} as const;

export type CaptainVoyageOrder =
  | "SAIL_YES"
  | "SAIL_NO"
  | "HOLD_COURSE"
  | "HEAVE_TO"
  | "ABANDON";

export type CaptainFeeNetVsSkip = "sail" | "skip_preferred" | "unknown";

export type CaptainBridge = {
  schema: "captain_bridge_v1";
  voice: "captain-goldenegg";
  voyageOrder: CaptainVoyageOrder;
  destination: "fee_net_survive";
  standingOrders: string[];
  weather: { fog: boolean; reasons: string[] };
  charts: {
    p_ind: number | null;
    p_yes: number | null;
    band80: [number | null, number | null];
    settleLean: "yes" | "no" | "skip" | null;
  };
  officers: {
    selfDrivePlan: string;
    oracleAction: string;
    riskPass: boolean;
    phdPreferSkip: boolean;
  };
  coastGuard: {
    floorsIntact: true;
    note: "EV3/Kelly0.60/ask20-55 — uncuttable";
  };
  heaveTo: boolean;
  heaveReasons: string[];
  thoughtTrace: string[];
  feeNetVsSkip: CaptainFeeNetVsSkip;
};

/** Structural slices — avoid importing brain-center (cycle). */
export type CaptainSelfDriveSlice = {
  planAction: string;
  safety: { brake: boolean; brakeReasons?: readonly string[] };
  brakeReasons?: readonly string[];
  perception?: { weather?: string };
  prediction?: {
    pInd?: number | null;
    band80?: [number | null, number | null];
    settlePick?: "yes" | "no" | "skip" | null;
    ovPreferSkip?: boolean;
  };
} | null;

export type CaptainOracleV2Slice = {
  action: string;
  risk_pass: boolean;
  risk_veto: boolean;
  risk_veto_reasons?: readonly string[];
  p_ind?: number | null;
  p_yes?: number | null;
  band80?: [number | null, number | null];
  gates_failed?: readonly string[];
  missing_inputs?: readonly string[];
} | null;

export type CaptainPhdSlice = {
  optionValueSkip?: {
    preferSkip?: boolean;
    score?: number;
    reasons?: readonly string[];
  };
  uncertainty?: { coversBoth?: boolean };
  calibration?: { reliable?: boolean; ece?: number; n?: number };
  /** PhD trading-education common-sense (soft heave / abandon lean). */
  education?: {
    heaveTo?: boolean;
    heaveReasons?: readonly string[];
    abandonLean?: boolean;
  } | null;
} | null;

export type BuildCaptainBridgeInput = {
  decisionKind: string;
  soleDecision?: string | null;
  side?: "yes" | "no" | null;
  paperMode?: boolean | null;
  frozenCcMode?: boolean | null;
  selfDrive: CaptainSelfDriveSlice;
  oracleV2: CaptainOracleV2Slice;
  phd: CaptainPhdSlice;
  /** KXBTC15M specialist soft heave / abandon lean (compose with education). */
  kxbct15m?: {
    heaveTo?: boolean;
    heaveReasons?: readonly string[];
    abandonLean?: boolean;
  } | null;
  /** Thesis broken / EXIT shadow when open. */
  exitHold?: boolean | null;
  ruinWouldSell?: boolean | null;
  thesisBroken?: boolean | null;
  /** Optional charts override when officers lack them. */
  pInd?: number | null;
  pYes?: number | null;
  band80?: [number | null, number | null] | null;
  settleLean?: "yes" | "no" | "skip" | null;
  evCents?: number | null;
  askCents?: number | null;
};

function label(kind: string, text: string): string {
  return `${kind}: ${text}`;
}

/** Shared voyage resolution — used by peek + full stamp. */
export type CaptainVoyageResolution = {
  voyageOrder: CaptainVoyageOrder;
  heaveTo: boolean;
  heaveReasons: string[];
  weatherReasons: string[];
  fog: boolean;
  feeNetVsSkip: CaptainFeeNetVsSkip;
  plan: string;
  oracleAction: string;
  riskPass: boolean;
  phdPrefer: boolean;
  coversBoth: boolean;
  p_ind: number | null;
  p_yes: number | null;
  band80: [number | null, number | null];
  settleLean: "yes" | "no" | "skip" | null;
};

/**
 * Captain rules (encode):
 * 1. Floors would fail → HEAVE_TO
 * 2. SelfDrive.brake OR oracleV2.risk_veto OR PhD preferSkip/coversBoth/unreliable ECE OR PhD education.heaveTo → HEAVE_TO
 * 3. Open position + thesis broken / EXIT_RAMP OR education.abandonLean → ABANDON
 * 4. Else clear cruise YES/NO with risk_pass → SAIL_YES / SAIL_NO
 * 5. Else HOLD_COURSE
 */
/** P3-A: share resolve between peekCaptainHeave and buildCaptainBridge (same tick). */
let _voyageResolveCache: { key: string; result: CaptainVoyageResolution } | null = null;

function captainVoyageCacheKey(input: BuildCaptainBridgeInput): string {
  const sd = input.selfDrive;
  const ov = input.oracleV2;
  const phd = input.phd;
  return [
    input.decisionKind ?? "",
    input.soleDecision ?? "",
    input.side ?? "",
    input.paperMode === true ? "1" : "0",
    input.frozenCcMode === true ? "1" : "0",
    input.evCents ?? "",
    input.askCents ?? "",
    sd?.planAction ?? "",
    sd?.safety?.brake === true ? "1" : "0",
    (sd?.brakeReasons ?? sd?.safety?.brakeReasons ?? []).slice(0, 2).join("|"),
    sd?.perception?.weather ?? "",
    sd?.prediction?.ovPreferSkip === true ? "1" : "0",
    ov?.action ?? "",
    ov?.risk_veto === true ? "1" : "0",
    ov?.p_ind ?? "",
    ov?.p_yes ?? "",
    phd?.optionValueSkip?.preferSkip === true ? "1" : "0",
    phd?.uncertainty?.coversBoth === true ? "1" : "0",
    phd?.calibration?.reliable === false ? "0" : "1",
    phd?.calibration?.n ?? "",
    phd?.education?.heaveTo === true ? "1" : "0",
    phd?.education?.abandonLean === true ? "1" : "0",
    input.kxbct15m?.heaveTo === true ? "1" : "0",
    input.exitHold === true ? "1" : "0",
    input.ruinWouldSell === true ? "1" : "0",
    input.settleLean ?? "",
  ].join("::");
}

export function resolveCaptainVoyage(
  input: BuildCaptainBridgeInput,
): CaptainVoyageResolution {
  const cacheKey = captainVoyageCacheKey(input);
  if (_voyageResolveCache && _voyageResolveCache.key === cacheKey) {
    return _voyageResolveCache.result;
  }
  const result = resolveCaptainVoyageUncached(input);
  _voyageResolveCache = { key: cacheKey, result };
  return result;
}

function resolveCaptainVoyageUncached(
  input: BuildCaptainBridgeInput,
): CaptainVoyageResolution {
  const sd = input.selfDrive;
  const ov = input.oracleV2;
  const phd = input.phd;

  const heaveReasons: string[] = [];
  const weatherReasons: string[] = [];

  const p_ind =
    typeof ov?.p_ind === "number"
      ? ov.p_ind
      : typeof sd?.prediction?.pInd === "number"
        ? sd.prediction.pInd
        : typeof input.pInd === "number"
          ? input.pInd
          : null;
  const p_yes =
    typeof ov?.p_yes === "number"
      ? ov.p_yes
      : typeof input.pYes === "number"
        ? input.pYes
        : null;
  const band80: [number | null, number | null] =
    ov?.band80 ??
    sd?.prediction?.band80 ??
    input.band80 ?? [null, null];
  const settleLean =
    input.settleLean ?? sd?.prediction?.settlePick ?? null;

  const coversBoth = phd?.uncertainty?.coversBoth === true;
  const calibUnrel = phd?.calibration?.reliable === false;
  const missing =
    (ov?.missing_inputs != null && ov.missing_inputs.length > 0) ||
    (ov?.gates_failed != null && ov.gates_failed.length > 0);
  const fog =
    coversBoth ||
    calibUnrel ||
    missing === true ||
    sd?.perception?.weather === "storm" ||
    sd?.perception?.weather === "haze";
  if (coversBoth) {
    weatherReasons.push("MEASUREMENT: coversBoth — band spans YES+NO");
  }
  if (calibUnrel) {
    weatherReasons.push(
      `MEASUREMENT: ECE unreliable n=${phd?.calibration?.n ?? "?"} ece=${phd?.calibration?.ece ?? "?"}`,
    );
  }
  if (missing) {
    weatherReasons.push(
      `UNKNOWN: gates/missing=[${[...(ov?.gates_failed ?? []), ...(ov?.missing_inputs ?? [])].slice(0, 4).join(",")}]`,
    );
  }
  if (
    sd?.perception?.weather === "storm" ||
    sd?.perception?.weather === "haze"
  ) {
    weatherReasons.push(
      `ESTIMATE: selfDrive weather=${sd.perception.weather}`,
    );
  }

  const ask = input.askCents;
  const ev = input.evCents;
  if (
    typeof ask === "number" &&
    (ask < CAPTAIN_FLOOR_MIRROR.askMinCents ||
      ask > CAPTAIN_FLOOR_MIRROR.askMaxCents)
  ) {
    heaveReasons.push(
      `FACT: ask ${ask}¢ outside coast-guard ${CAPTAIN_FLOOR_MIRROR.askMinCents}–${CAPTAIN_FLOOR_MIRROR.askMaxCents}`,
    );
  }
  if (typeof ev === "number" && ev < CAPTAIN_FLOOR_MIRROR.evFloorCents) {
    heaveReasons.push(
      `FACT: EV ${ev}¢ < coast-guard floor ${CAPTAIN_FLOOR_MIRROR.evFloorCents}¢`,
    );
  }

  const sdBrake = sd?.safety?.brake === true;
  if (sdBrake) {
    const br = (sd?.brakeReasons ?? sd?.safety?.brakeReasons ?? []).slice(0, 3);
    heaveReasons.push(
      `INFERENCE: SelfDrive.brake${br.length ? ` — ${br.join("; ")}` : ""}`,
    );
  }
  if (ov?.risk_veto === true) {
    const rr = (ov.risk_veto_reasons ?? []).slice(0, 2);
    heaveReasons.push(
      `INFERENCE: oracleV2.risk_veto${rr.length ? ` — ${rr.join("; ")}` : ""}`,
    );
  }
  const phdPrefer =
    phd?.optionValueSkip?.preferSkip === true ||
    sd?.prediction?.ovPreferSkip === true;
  if (phdPrefer) {
    heaveReasons.push(
      `INFERENCE: PhD preferSkip OV=${phd?.optionValueSkip?.score ?? "?"}`,
    );
  }
  if (coversBoth) {
    heaveReasons.push("MEASUREMENT: PhD coversBoth → heave-to");
  }
  if (calibUnrel) {
    heaveReasons.push(
      "MEASUREMENT: unreliable ECE → heave-to (calibrated skip)",
    );
  }
  if (fog && heaveReasons.length === 0) {
    heaveReasons.push("ESTIMATE: fog/weather without clear cruise → heave-to");
  }

  // PhD trading-education common sense (soft; floors uncut; CC_VEL observe-only)
  if (phd?.education?.heaveTo === true) {
    const er = (phd.education.heaveReasons ?? []).slice(0, 3);
    if (er.length > 0) {
      for (const r of er) {
        heaveReasons.push(`INFERENCE: PhD education — ${r}`);
      }
    } else {
      heaveReasons.push("INFERENCE: PhD education heaveTo");
    }
  }

  // KXBTC15M specialist (soft; floors uncut; compose with education)
  if (input.kxbct15m?.heaveTo === true) {
    const kr = (input.kxbct15m.heaveReasons ?? []).slice(0, 3);
    if (kr.length > 0) {
      for (const r of kr) {
        heaveReasons.push(`INFERENCE: KXBTC15M specialist — ${r}`);
      }
    } else {
      heaveReasons.push("INFERENCE: KXBTC15M specialist heaveTo");
    }
  }


  const plan = sd?.planAction ?? "PULL_OVER_SKIP";
  const oracleAction = ov?.action ?? "ABSTAIN";
  const riskPass = ov?.risk_pass !== false && ov?.risk_veto !== true;
  const dk = String(input.decisionKind || "");
  const openExit =
    plan === "EXIT_RAMP" ||
    input.exitHold === true ||
    input.ruinWouldSell === true ||
    input.thesisBroken === true ||
    dk === "EXIT";
  const educationAbandon =
    phd?.education?.abandonLean === true ||
    input.kxbct15m?.abandonLean === true;
  const inPosition =
    openExit ||
    input.exitHold === true ||
    dk === "HOLD" ||
    plan === "HOLD_LANE";

  let voyageOrder: CaptainVoyageOrder;
  let heaveTo = false;

  if (heaveReasons.length > 0) {
    voyageOrder = "HEAVE_TO";
    heaveTo = true;
  } else if (openExit || (educationAbandon && inPosition)) {
    voyageOrder = "ABANDON";
    heaveTo = false;
  } else if (
    riskPass &&
    (plan === "CRUISE_TAKE_YES" ||
      (dk === "TAKE_YES" && oracleAction === "BUY_YES"))
  ) {
    voyageOrder = "SAIL_YES";
  } else if (
    riskPass &&
    (plan === "CRUISE_TAKE_NO" ||
      (dk === "TAKE_NO" && oracleAction === "BUY_NO"))
  ) {
    voyageOrder = "SAIL_NO";
  } else if (
    plan === "PULL_OVER_SKIP" ||
    oracleAction === "ABSTAIN" ||
    oracleAction === "SKIP" ||
    dk === "SKIP"
  ) {
    voyageOrder = "HEAVE_TO";
    heaveTo = true;
    if (heaveReasons.length === 0) {
      heaveReasons.push(
        `INFERENCE: officers lean skip (plan=${plan} oracle=${oracleAction} kind=${dk})`,
      );
    }
  } else {
    voyageOrder = "HOLD_COURSE";
  }

  let feeNetVsSkip: CaptainFeeNetVsSkip;
  if (voyageOrder === "HEAVE_TO" || voyageOrder === "ABANDON") {
    feeNetVsSkip = "skip_preferred";
  } else if (voyageOrder === "SAIL_YES" || voyageOrder === "SAIL_NO") {
    feeNetVsSkip =
      typeof ev === "number" && ev >= CAPTAIN_FLOOR_MIRROR.evFloorCents
        ? "sail"
        : "unknown";
  } else {
    feeNetVsSkip = "unknown";
  }

  return {
    voyageOrder,
    heaveTo,
    heaveReasons: heaveReasons.slice(0, 8),
    weatherReasons: weatherReasons.slice(0, 6),
    fog,
    feeNetVsSkip,
    plan,
    oracleAction,
    riskPass,
    phdPrefer,
    coversBoth,
    p_ind,
    p_yes,
    band80,
    settleLean,
  };
}

/** Lean early peek — heaveTo for council preferSkip; no thoughtTrace. */
export type CaptainHeavePeek = {
  heaveTo: boolean;
  reasons: string[];
};

/**
 * Cheap Captain peek for council preferSkip lean.
 * Same heaveTo logic as full bridge (oracleV2 may be null — same as early path).
 */
export function peekCaptainHeave(
  input: BuildCaptainBridgeInput,
): CaptainHeavePeek {
  const r = resolveCaptainVoyage(input);
  return { heaveTo: r.heaveTo, reasons: r.heaveReasons };
}

export function buildCaptainBridge(
  input: BuildCaptainBridgeInput,
): CaptainBridge {
  const r = resolveCaptainVoyage(input);

  const standingOrders: string[] = [
    label("FACT", "destination=fee_net_survive (not trade frequency)"),
    label("FACT", "coast guard floors uncuttable — captain cannot override"),
    label(
      "FACT",
      `paper=${input.paperMode === true} frozenCc=${input.frozenCcMode === true}`,
    ),
    label(
      "ASSUMPTION",
      "engine room owns fills — captain issues voyage order only",
    ),
    label("FACT", "SKIP/heave-to is first-class success"),
  ];

  const bottomLine =
    r.voyageOrder === "HEAVE_TO"
      ? `HEAVE_TO — skip@0 preferred (${r.heaveReasons[0] ?? "fog"})`
      : r.voyageOrder === "ABANDON"
        ? "ABANDON — thesis broken / EXIT_RAMP; PATH_RIDE owns hands"
        : r.voyageOrder === "SAIL_YES"
          ? "SAIL_YES — clear cruise YES; risk_pass; fee-net vs skip framed"
          : r.voyageOrder === "SAIL_NO"
            ? "SAIL_NO — clear cruise NO; risk_pass; fee-net vs skip framed"
            : "HOLD_COURSE — flat or hold open; no new sail";

  const thoughtTrace: string[] = [
    `BOTTOM LINE: ${bottomLine}`,
    `EVIDENCE: officers plan=${r.plan} oracle=${r.oracleAction} riskPass=${r.riskPass} phdPreferSkip=${r.phdPrefer}`,
    `CHARTS: p_ind=${r.p_ind ?? "?"} p_yes=${r.p_yes ?? "?"} settle=${r.settleLean ?? "?"} band80=[${r.band80[0] ?? "?"},${r.band80[1] ?? "?"}]`,
    `WEATHER: fog=${r.fog}${r.weatherReasons[0] ? ` — ${r.weatherReasons[0]}` : ""}`,
    `ORDER: ${r.voyageOrder} (destination=fee_net_survive)`,
    `WHY: ${r.heaveTo ? r.heaveReasons.slice(0, 2).join(" | ") || "heave" : r.voyageOrder === "HOLD_COURSE" ? "no clear cruise; hold" : "officers agree cruise + risk_pass"}`,
    `RISKS: wrong-side into settle; fee drag; coast-guard floors never cut`,
    `CHECK: fee-net vs skip@0 — prefer ${r.feeNetVsSkip === "sail" ? "sail only if edge clear" : "skip when edge unclear"}`,
    `COAST GUARD: floorsIntact — EV3/Kelly0.60/ask20-55 uncuttable`,
    `LOGBOOK: scar-echo/episodic observe; no LLM on tick/fill`,
  ].slice(0, 10);

  while (thoughtTrace.length < 6) {
    thoughtTrace.push(
      `NOTE: standing order — heave-to is success when unclear`,
    );
  }

  return {
    schema: "captain_bridge_v1",
    voice: "captain-goldenegg",
    voyageOrder: r.voyageOrder,
    destination: "fee_net_survive",
    standingOrders,
    weather: { fog: r.fog, reasons: r.weatherReasons },
    charts: {
      p_ind: r.p_ind,
      p_yes: r.p_yes,
      band80: r.band80,
      settleLean: r.settleLean,
    },
    officers: {
      selfDrivePlan: r.plan,
      oracleAction: r.oracleAction,
      riskPass: r.riskPass,
      phdPreferSkip: r.phdPrefer || r.coversBoth,
    },
    coastGuard: {
      floorsIntact: true,
      note: "EV3/Kelly0.60/ask20-55 — uncuttable",
    },
    heaveTo: r.heaveTo,
    heaveReasons: r.heaveReasons,
    thoughtTrace,
    feeNetVsSkip: r.feeNetVsSkip,
  };
}
