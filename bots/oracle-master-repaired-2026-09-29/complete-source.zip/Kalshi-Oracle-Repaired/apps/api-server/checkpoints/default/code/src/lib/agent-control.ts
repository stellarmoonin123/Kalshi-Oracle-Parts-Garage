/**
 * Agent control plane — chat agent (Grok Bot / Oracle copy) = operator;
 * deterministic TradingBot = executor. NO LLM on evaluateEntry/placeOrder.
 *
 * Paper-only mutating commands. Floors uncut (EV 3¢, Kelly 0.60, 9%, 15% reserve, ask 20–55).
 */
import { randomUUID } from "node:crypto";
import { EV_FLOOR, HARD_RISK_LIMITS } from "./admission.js";
import {
  type BrainCenterReport,
} from "./organs/brain-center.js";
import {
  classifyMindHeave,
  brainCenterHardVetoReason,
} from "./organs/mind-place-bind.js";

export const FORCE_EXIT_CONFIRM_PHRASE = "FORCE EXIT" as const;
export const AGENT_ENTRY_TTL_MS = 45_000;
export const AGENT_CONTROL_LOADED = "AGENT_CONTROL_LOADED" as const;

/** Floors surfaced on agent/status — immutable admission constants + desk doors. */
export const AGENT_FLOORS = {
  evFloorCents: EV_FLOOR,
  kellyCap: 0.6,
  maxRiskPctPerTrade: HARD_RISK_LIMITS.maxRiskPctPerTrade,
  reservePctFloor: 15,
  askMinCents: 20,
  askMaxCents: 55,
} as const;

export type AgentDirectiveType =
  | "SKIP_NEXT"
  | "HALT_ENTRIES"
  | "RESUME_ENTRIES"
  | "SIT_UNTIL_SECS";

export type AgentDirective = {
  id: string;
  type: AgentDirectiveType;
  armedAtMs: number;
  /** Absolute deadline for SIT_UNTIL_SECS (ms since epoch). */
  untilMs?: number;
  /** Remaining SKIP_NEXT count (usually 1). */
  skipRemaining?: number;
  note?: string;
};

export type PendingAgentEntry = {
  id: string;
  side: "yes" | "no";
  ask: number;
  strategyId: string;
  ticker: string;
  traceId?: string;
  proposal: Record<string, unknown>;
  brainReport: BrainCenterReport | null;
  createdAtMs: number;
  expiresAtMs: number;
};

export type AgentControlConfigFlags = {
  agentControlMode: boolean;
  requireAgentEntryApproval: boolean;
  brainCenterAuthority: boolean;
  paperMode: boolean;
};

/** Allowlisted keys for POST /api/bot/agent/config (plus paperMode forced true). */
export const AGENT_CONFIG_ALLOWLIST = [
  "agentControlMode",
  "requireAgentEntryApproval",
  "brainCenterAuthority",
  "autopilotMode",
  "frozenCcMode",
  "frozenCcAndSit",
  "enabled",
  "holdToSettlement",
  "useStopLoss",
  "useProfitTake",
  "strategyOverride",
] as const;

export type AgentConfigAllowKey = (typeof AGENT_CONFIG_ALLOWLIST)[number];

export type AgentTraceStamp =
  | "AGENT_APPROVED"
  | "AGENT_REJECTED"
  | "AGENT_HALT"
  | "AGENT_SKIP_NEXT"
  | "AGENT_SIT"
  | "BRAIN_CENTER_VETO"
  | "MIND_HEAVE_BIND"
  | "AGENT_STALE"
  | "AGENT_TIMEOUT";

export function refuseAgentAuthorityWhenNotPaper(
  flags: Partial<AgentControlConfigFlags> & { paperMode?: boolean },
  currentPaperMode: boolean,
): { ok: true } | { ok: false; reason: string } {
  const nextPaper =
    typeof flags.paperMode === "boolean" ? flags.paperMode : currentPaperMode;
  if (nextPaper !== true) {
    const arming =
      flags.agentControlMode === true ||
      flags.requireAgentEntryApproval === true ||
      flags.brainCenterAuthority === true;
    if (arming) {
      return {
        ok: false,
        reason:
          "agentControlMode / requireAgentEntryApproval / brainCenterAuthority require paperMode true",
      };
    }
  }
  return { ok: true };
}

export function filterAgentConfigPatch(
  body: Record<string, unknown> | null | undefined,
): {
  accepted: Record<string, unknown>;
  refused: Array<{ key: string; value: unknown; reason: string }>;
} {
  const accepted: Record<string, unknown> = {};
  const refused: Array<{ key: string; value: unknown; reason: string }> = [];
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return { accepted, refused };
  }
  for (const [key, value] of Object.entries(body)) {
    if (!(AGENT_CONFIG_ALLOWLIST as readonly string[]).includes(key)) {
      refused.push({
        key,
        value,
        reason: `key not on agent config allowlist`,
      });
      continue;
    }
    accepted[key] = value;
  }
  // Always force paper on agent config writes.
  accepted.paperMode = true;
  return { accepted, refused };
}

export function newPendingAgentEntry(input: {
  side: "yes" | "no";
  ask: number;
  strategyId: string;
  ticker: string;
  proposal: Record<string, unknown>;
  brainReport?: BrainCenterReport | null;
  traceId?: string;
  nowMs?: number;
  ttlMs?: number;
}): PendingAgentEntry {
  const now = input.nowMs ?? Date.now();
  const ttl = input.ttlMs ?? AGENT_ENTRY_TTL_MS;
  return {
    id: randomUUID(),
    side: input.side,
    ask: input.ask,
    strategyId: input.strategyId,
    ticker: input.ticker,
    traceId: input.traceId,
    proposal: input.proposal,
    brainReport: input.brainReport ?? null,
    createdAtMs: now,
    expiresAtMs: now + ttl,
  };
}

export function isPendingExpired(
  pending: PendingAgentEntry | null | undefined,
  nowMs = Date.now(),
): boolean {
  if (!pending) return true;
  return nowMs >= pending.expiresAtMs;
}

/** Freshness + floor check before agent approve → placeOrder. */
export function validatePendingApprove(input: {
  pending: PendingAgentEntry;
  liveTicker: string | null | undefined;
  liveAsk: number | null | undefined;
  askMin?: number;
  askMax?: number;
  nowMs?: number;
}): { ok: true } | { ok: false; stamp: AgentTraceStamp; reason: string } {
  const now = input.nowMs ?? Date.now();
  if (isPendingExpired(input.pending, now)) {
    return { ok: false, stamp: "AGENT_STALE", reason: "pendingAgentEntry expired" };
  }
  if (!input.liveTicker || input.liveTicker !== input.pending.ticker) {
    return {
      ok: false,
      stamp: "AGENT_STALE",
      reason: `ticker mismatch pending=${input.pending.ticker} live=${input.liveTicker ?? "null"}`,
    };
  }
  const askMin = input.askMin ?? AGENT_FLOORS.askMinCents;
  const askMax = input.askMax ?? AGENT_FLOORS.askMaxCents;
  const liveAsk = input.liveAsk;
  if (!(typeof liveAsk === "number" && Number.isFinite(liveAsk) && liveAsk > 0)) {
    return { ok: false, stamp: "AGENT_STALE", reason: "no live ask" };
  }
  if (liveAsk < askMin || liveAsk > askMax) {
    return {
      ok: false,
      stamp: "AGENT_STALE",
      reason: `live ask ${liveAsk}¢ outside door ${askMin}–${askMax}`,
    };
  }
  // Ask drift > 2¢ from proposal → stale (floors still apply via door).
  if (Math.abs(liveAsk - input.pending.ask) > 2) {
    return {
      ok: false,
      stamp: "AGENT_STALE",
      reason: `ask drifted pending=${input.pending.ask} live=${liveAsk}`,
    };
  }
  return { ok: true };
}

export function parseDirective(
  body: Record<string, unknown> | null | undefined,
  nowMs = Date.now(),
): { ok: true; directive: AgentDirective } | { ok: false; reason: string } {
  if (!body || typeof body !== "object") {
    return { ok: false, reason: "body required" };
  }
  const type = body.type;
  if (
    type !== "SKIP_NEXT" &&
    type !== "HALT_ENTRIES" &&
    type !== "RESUME_ENTRIES" &&
    type !== "SIT_UNTIL_SECS"
  ) {
    return { ok: false, reason: `unknown directive type: ${String(type)}` };
  }
  const note = typeof body.note === "string" ? body.note : undefined;
  if (type === "SIT_UNTIL_SECS") {
    const secs = Number(body.secs ?? body.sitSecs);
    if (!(Number.isFinite(secs) && secs > 0 && secs <= 3600)) {
      return { ok: false, reason: "SIT_UNTIL_SECS requires secs in (0, 3600]" };
    }
    return {
      ok: true,
      directive: {
        id: randomUUID(),
        type,
        armedAtMs: nowMs,
        untilMs: nowMs + Math.round(secs * 1000),
        note,
      },
    };
  }
  if (type === "SKIP_NEXT") {
    return {
      ok: true,
      directive: {
        id: randomUUID(),
        type,
        armedAtMs: nowMs,
        skipRemaining: 1,
        note,
      },
    };
  }
  return {
    ok: true,
    directive: { id: randomUUID(), type, armedAtMs: nowMs, note },
  };
}

export type DirectiveState = {
  haltEntries: boolean;
  skipNextRemaining: number;
  sitUntilMs: number | null;
  lastDirective: AgentDirective | null;
};

export function emptyDirectiveState(): DirectiveState {
  return {
    haltEntries: false,
    skipNextRemaining: 0,
    sitUntilMs: null,
    lastDirective: null,
  };
}

export function applyDirectiveToState(
  state: DirectiveState,
  directive: AgentDirective,
): DirectiveState {
  const next = { ...state, lastDirective: directive };
  switch (directive.type) {
    case "HALT_ENTRIES":
      return { ...next, haltEntries: true };
    case "RESUME_ENTRIES":
      return { ...next, haltEntries: false, sitUntilMs: null, skipNextRemaining: 0 };
    case "SKIP_NEXT":
      return {
        ...next,
        skipNextRemaining: Math.max(1, directive.skipRemaining ?? 1),
      };
    case "SIT_UNTIL_SECS":
      return {
        ...next,
        sitUntilMs: directive.untilMs ?? null,
      };
    default:
      return next;
  }
}

export type EntryGateDecision =
  | { action: "ALLOW" }
  | { action: "BLOCK"; stamp: AgentTraceStamp; reason: string }
  | { action: "PARK"; reason: string };

/**
 * Deterministic pre-placeOrder gate. No LLM.
 * Order: expire → halt → sit → skip_next → brain veto → park-for-approve.
 */
export function decideAgentEntryGate(input: {
  agentControlMode: boolean;
  requireAgentEntryApproval: boolean;
  brainCenterAuthority: boolean;
  paperMode: boolean;
  directives: DirectiveState;
  brainReport: BrainCenterReport | null | undefined;
  nowMs?: number;
}): EntryGateDecision {
  if (input.agentControlMode !== true) return { action: "ALLOW" };
  if (input.paperMode !== true) {
    // Fail closed: agent control never mutates live path.
    return {
      action: "BLOCK",
      stamp: "AGENT_HALT",
      reason: "agentControlMode armed but paperMode false — refuse place",
    };
  }
  const now = input.nowMs ?? Date.now();
  if (input.directives.haltEntries) {
    return {
      action: "BLOCK",
      stamp: "AGENT_HALT",
      reason: "HALT_ENTRIES directive active",
    };
  }
  if (
    typeof input.directives.sitUntilMs === "number" &&
    now < input.directives.sitUntilMs
  ) {
    return {
      action: "BLOCK",
      stamp: "AGENT_SIT",
      reason: `SIT_UNTIL_SECS until ${new Date(input.directives.sitUntilMs).toISOString()}`,
    };
  }
  if (input.directives.skipNextRemaining > 0) {
    return {
      action: "BLOCK",
      stamp: "AGENT_SKIP_NEXT",
      reason: "SKIP_NEXT directive consuming one take",
    };
  }
  if (input.brainCenterAuthority === true) {
    // PR #16 option B — OV-SKIP / coversBoth / calibration heave terms are
    // advisory here too (same classifier as the placeOrder bind); every other
    // heave term (risk veto, blind, vel_against, missing inputs/band…) blocks.
    const heave = classifyMindHeave(input.brainReport);
    if (heave.block) {
      return {
        action: "BLOCK",
        stamp: "MIND_HEAVE_BIND",
        reason: heave.block,
      };
    }
    const veto = brainCenterHardVetoReason(input.brainReport, true);
    if (veto) {
      return {
        action: "BLOCK",
        stamp: "BRAIN_CENTER_VETO",
        reason: veto,
      };
    }
  }
  if (input.requireAgentEntryApproval === true) {
    return { action: "PARK", reason: "requireAgentEntryApproval — awaiting agent approve" };
  }
  return { action: "ALLOW" };
}

/**
 * When brainCenterAuthority is armed (paper): Oracle Mind layered veto.
 * Reflex hard-blocks and tactical NO/SKIP veto new TAKE.
 * HOLD/EXIT_SHADOW do not block entries (PATH_RIDE owns open-book exits).
 */
export function brainCenterWouldVeto(
  report: BrainCenterReport | null | undefined,
): string | null {
  // Soft CC_VEL alone does not veto (n < 40). Prefer brainCenterHardVetoReason.
  return brainCenterHardVetoReason(report, true);
}

/** Consume one SKIP_NEXT after a blocked take. */
export function consumeSkipNext(state: DirectiveState): DirectiveState {
  if (state.skipNextRemaining <= 0) return state;
  return {
    ...state,
    skipNextRemaining: Math.max(0, state.skipNextRemaining - 1),
  };
}

export type AgentHelpCommand = {
  method: "GET" | "POST";
  path: string;
  body?: Record<string, unknown>;
  description: string;
  mutates: boolean;
  confirm?: string;
};

export function agentHelpCatalog(): AgentHelpCommand[] {
  return [
    {
      method: "GET",
      path: "/api/bot/agent/status",
      description: "Full operator snapshot (config flags, state, openTrade, brain, pending, directives, floors)",
      mutates: false,
    },
    {
      method: "GET",
      path: "/api/bot/agent/help",
      description: "This machine-readable command list",
      mutates: false,
    },
    {
      method: "POST",
      path: "/api/bot/agent/start",
      description: "Start bot (paper)",
      mutates: true,
    },
    {
      method: "POST",
      path: "/api/bot/agent/stop",
      description: "Stop bot",
      mutates: true,
    },
    {
      method: "POST",
      path: "/api/bot/agent/restart",
      description: "Restart bot timers (config preserved)",
      mutates: true,
    },
    {
      method: "POST",
      path: "/api/bot/agent/config",
      body: {
        agentControlMode: true,
        brainCenterAuthority: true,
        requireAgentEntryApproval: false,
        autopilotMode: true,
      },
      description:
        "Allowlisted config patch; always forces paperMode true. autopilotMode:true applies best paper bundle + starts bot. Flip requireAgentEntryApproval true to gate every TAKE.",
      mutates: true,
    },
    {
      method: "POST",
      path: "/api/bot/agent/autopilot",
      body: { enabled: true },
      description:
        "Arm/disarm built-in paper autopilot (best settings, YES/NO/SKIP unattended). Paper-only. Deterministic — no LLM on tick.",
      mutates: true,
    },
    {
      method: "POST",
      path: "/api/bot/agent/entry/approve",
      body: { id: "<pendingId>" },
      description: "Approve pendingAgentEntry → placeOrder if still fresh",
      mutates: true,
    },
    {
      method: "POST",
      path: "/api/bot/agent/entry/reject",
      body: { id: "<pendingId>", reason: "optional" },
      description: "Reject pending TAKE",
      mutates: true,
    },
    {
      method: "POST",
      path: "/api/bot/agent/exit",
      body: { confirm: "FORCE EXIT" },
      description: "Paper force-close open trade (exact confirm phrase required)",
      mutates: true,
      confirm: FORCE_EXIT_CONFIRM_PHRASE,
    },
    {
      method: "POST",
      path: "/api/bot/agent/directive",
      body: { type: "HALT_ENTRIES" },
      description:
        "Sticky directives: SKIP_NEXT | HALT_ENTRIES | RESUME_ENTRIES | SIT_UNTIL_SECS{secs}",
      mutates: true,
    },
  ];
}
