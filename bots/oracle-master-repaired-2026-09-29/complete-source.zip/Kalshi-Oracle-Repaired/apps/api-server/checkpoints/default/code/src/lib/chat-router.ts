/**
 * chat-router.ts — free-model routing for the in-app desk chat (round 2).
 *
 * Why this exists (diagnosed from the Fly DB/logs, 2026-09-25):
 *  - Groq free tier is 8 000 tokens/min per model. The old chat sent a long
 *    system prompt + 24 turns + raw tool dumps (whole files), so requests hit
 *    413/429 and were silently skipped (`if (!resp.ok) continue`).
 *  - Gemini fallbacks included models the key has no free quota for
 *    (gemini-flash-latest / 3.8 / pro → 429 RESOURCE_EXHAUSTED) or that are
 *    overloaded (3.7 → 503), with no cooldown, so every turn re-paid them.
 *  - Groq ran a text-parsed "XML tool call" loop although Groq supports
 *    native OpenAI tool calls, so answers often stopped at "Let me dig…".
 *  - Every failure collapsed into one generic line.
 *
 * Policy: FREE models only. Order = strongest free first:
 *   groq openai/gpt-oss-120b → gemini-3.6-flash → groq qwen/qwen3.8-27b →
 *   gemini-3.5-flash → groq openai/gpt-oss-20b
 * (+ OpenRouter `:free` models only when OPENROUTER_API_KEY is set; a 402
 * puts the whole provider on a 30 min cooldown — paid OpenRouter is never
 * used.) Per-model cooldowns honor Retry-After; 5xx/timeouts get one backoff
 * retry; each call has a hard timeout; the context is budgeted to fit the
 * 8k TPM free tier. Native tool calls on both providers.
 */

export type ChatRole = "system" | "user" | "assistant" | "tool";
export type ProviderId = "groq" | "gemini" | "openrouter";

export interface RouteModel { provider: ProviderId; model: string; label: string }

export const FREE_MODEL_ROUTE: readonly RouteModel[] = [
  { provider: "groq", model: "openai/gpt-oss-120b", label: "Groq GPT-OSS 120B" },
  { provider: "gemini", model: "gemini-3.6-flash", label: "Gemini 3.6 Flash" },
  { provider: "groq", model: "qwen/qwen3.8-27b", label: "Groq Qwen3.8 27B" },
  { provider: "gemini", model: "gemini-3.5-flash", label: "Gemini 3.5 Flash" },
  { provider: "groq", model: "openai/gpt-oss-20b", label: "Groq GPT-OSS 20B" },
];
/** Only `:free` slugs — never a paid OpenRouter model. */
export const OPENROUTER_FREE_ROUTE: readonly RouteModel[] = [
  { provider: "openrouter", model: "openai/gpt-oss-120b:free", label: "OpenRouter GPT-OSS 120B (free)" },
];

export interface ToolSpec { name: string; description: string; parameters: Record<string, unknown> }
export interface ToolCall { id: string; name: string; args: Record<string, unknown>; /** Gemini 3 thought signature, echoed back verbatim. */ thoughtSignature?: string }
export interface Msg { role: ChatRole; content: string; toolCalls?: ToolCall[]; toolCallId?: string; toolName?: string }

export type ErrKind = "rate_limited" | "quota" | "payment_required" | "unavailable" | "timeout" | "too_large" | "not_found" | "auth" | "bad_response" | "network";

export class ProviderError extends Error {
  constructor(public readonly kind: ErrKind, public readonly status: number | null, public readonly retryAfterMs: number | null, msg: string) {
    super(msg);
    this.name = "ProviderError";
  }
}

export function classifyHttpError(status: number, bodyText: string, retryAfterHeader: string | null): ProviderError {
  const ra = parseRetryAfterMs(retryAfterHeader, bodyText);
  const b = bodyText.slice(0, 400);
  if (status === 402) return new ProviderError("payment_required", status, ra, "payment required (402)");
  if (status === 429) {
    const quota = /RESOURCE_EXHAUSTED|quota|per day|daily/i.test(b) && !/per minute|TPM|RPM/i.test(b);
    return new ProviderError(quota ? "quota" : "rate_limited", status, ra, quota ? "daily quota exhausted" : "rate limited");
  }
  if (status === 413 || /context|too large|maximum.*tokens|Request too large/i.test(b) && status === 400) return new ProviderError("too_large", status, ra, "request too large for the free tier");
  if (status === 401 || status === 403) return new ProviderError("auth", status, null, "key rejected");
  if (status === 404) return new ProviderError("not_found", status, null, "model not available to this key");
  if (status >= 500) return new ProviderError("unavailable", status, ra, `provider unavailable (${status})`);
  return new ProviderError("bad_response", status, null, `HTTP ${status}`);
}

export function parseRetryAfterMs(header: string | null, body = ""): number | null {
  if (header) {
    const n = Number(header);
    if (Number.isFinite(n) && n >= 0) return Math.round(n * 1000);
    const d = Date.parse(header);
    if (Number.isFinite(d)) return Math.max(0, d - Date.now());
  }
  const m = /try again in ([0-9.]+)\s*(ms|s|m)\b/i.exec(body) ?? /"retryDelay":\s*"([0-9.]+)(s)"/.exec(body);
  if (m) {
    const v = Number(m[1]);
    const unit = (m[2] ?? "s").toLowerCase();
    return Math.round(unit === "ms" ? v : unit === "m" ? v * 60_000 : v * 1000);
  }
  return null;
}

/** Cooldown per model (and per provider for 402). In-memory; process-local. */
export class CooldownBook {
  private until = new Map<string, { untilMs: number; kind: ErrKind }>();
  constructor(private readonly now: () => number = Date.now) {}
  key(m: RouteModel): string { return `${m.provider}:${m.model}`; }
  nowMs(): number { return this.now(); }
  isCooling(m: RouteModel): { cooling: boolean; untilMs?: number; kind?: ErrKind } {
    for (const k of [this.key(m), `${m.provider}:*`]) {
      const e = this.until.get(k);
      if (e && e.untilMs > this.now()) return { cooling: true, untilMs: e.untilMs, kind: e.kind };
    }
    return { cooling: false };
  }
  note(m: RouteModel, err: ProviderError): void {
    const ms = cooldownMsFor(err);
    if (ms <= 0) return;
    const k = err.kind === "payment_required" || err.kind === "auth" ? `${m.provider}:*` : this.key(m);
    this.until.set(k, { untilMs: this.now() + ms, kind: err.kind });
  }
  clear(): void { this.until.clear(); }
  snapshot(): Record<string, { untilMs: number; kind: ErrKind }> { return Object.fromEntries(this.until); }
}

export function cooldownMsFor(err: ProviderError): number {
  switch (err.kind) {
    case "payment_required": return 30 * 60_000;           // OpenRouter paid exhausted → skip 30 min
    case "quota": return Math.max(err.retryAfterMs ?? 0, 60 * 60_000);
    case "rate_limited": return Math.min(Math.max(err.retryAfterMs ?? 20_000, 5_000), 10 * 60_000);
    case "unavailable": return Math.min(Math.max(err.retryAfterMs ?? 30_000, 10_000), 5 * 60_000);
    case "not_found": return 6 * 60 * 60_000;
    case "auth": return 60 * 60_000;
    case "timeout": return 20_000;
    default: return 0;
  }
}

/** ~4 chars/token. Free Groq = 8k TPM; keep a request ≤ ~5.5k tokens incl. output. */
export const CONTEXT_TOKEN_BUDGET = 3_800;
export const MAX_OUTPUT_TOKENS = 1_200;
export const TOOL_RESULT_MAX_CHARS = 2_400;
export const estTokens = (s: string): number => Math.ceil((s ?? "").length / 4);

export function truncateForModel(s: string, max = TOOL_RESULT_MAX_CHARS): string {
  if (s.length <= max) return s;
  return `${s.slice(0, max)}\n…[truncated ${s.length - max} chars — ask for a narrower range]`;
}

/** Keep the system prompt + the newest turns that fit the budget (never drops the last user turn). */
export function budgetMessages(system: string, turns: Msg[], budget = CONTEXT_TOKEN_BUDGET): Msg[] {
  let used = estTokens(system);
  const kept: Msg[] = [];
  for (let i = turns.length - 1; i >= 0; i--) {
    const t = turns[i]!;
    const cost = estTokens(t.content) + 8;
    if (kept.length > 0 && used + cost > budget) break;
    kept.unshift(t.role === "tool" ? t : { ...t, content: kept.length === 0 ? t.content : truncateForModel(t.content, 3_000) });
    used += cost;
  }
  // A tool message must follow its assistant call; drop orphaned leading tool rows.
  while (kept.length > 1 && kept[0]!.role === "tool") kept.shift();
  return kept;
}

export interface ProviderEnv { GROQ_API_KEY?: string; GEMINI_API_KEY?: string; GOOGLE_GENERATIVE_AI_API_KEY?: string; OPENROUTER_API_KEY?: string; [k: string]: string | undefined }

export function providerKey(p: ProviderId, env: ProviderEnv): string {
  if (p === "groq") return (env.GROQ_API_KEY ?? "").trim();
  if (p === "gemini") return (env.GEMINI_API_KEY ?? env.GOOGLE_GENERATIVE_AI_API_KEY ?? "").trim();
  return (env.OPENROUTER_API_KEY ?? "").trim();
}

export function availableRoute(env: ProviderEnv, prefer?: ProviderId): RouteModel[] {
  const base = [...FREE_MODEL_ROUTE, ...OPENROUTER_FREE_ROUTE].filter((m) => providerKey(m.provider, env));
  if (!prefer) return base;
  return [...base.filter((m) => m.provider === prefer), ...base.filter((m) => m.provider !== prefer)];
}

export interface CompletionOut { text: string; toolCalls: ToolCall[] }

type FetchLike = typeof fetch;

async function fetchWithTimeout(fetchImpl: FetchLike, url: string, init: RequestInit, timeoutMs: number): Promise<Response> {
  try {
    return await fetchImpl(url, { ...init, signal: AbortSignal.timeout(timeoutMs) });
  } catch (e) {
    const name = (e as Error)?.name ?? "";
    if (name === "TimeoutError" || name === "AbortError") throw new ProviderError("timeout", null, null, `timed out after ${Math.round(timeoutMs / 1000)}s`);
    throw new ProviderError("network", null, null, "network error");
  }
}

function openAiMessages(system: string, msgs: Msg[]): unknown[] {
  const out: unknown[] = [{ role: "system", content: system }];
  for (const m of msgs) {
    if (m.role === "tool") out.push({ role: "tool", tool_call_id: m.toolCallId, content: m.content });
    else if (m.role === "assistant" && m.toolCalls?.length) {
      out.push({ role: "assistant", content: m.content || null, tool_calls: m.toolCalls.map((c) => ({ id: c.id, type: "function", function: { name: c.name, arguments: JSON.stringify(c.args) } })) });
    } else out.push({ role: m.role, content: m.content });
  }
  return out;
}

/** Google's documented sentinel for replayed function calls that have no signature (e.g. made by Groq). */
export const GEMINI_SKIP_SIGNATURE = "skip_thought_signature_validator";

/**
 * Gemini 3 rejects (400) a replayed functionCall without its thoughtSignature,
 * and wants all functionResponses of a step in ONE user content (FC1, FC2, FR1, FR2).
 */
export function geminiContents(msgs: Msg[]): unknown[] {
  const out: { role: string; parts: unknown[] }[] = [];
  for (const m of msgs) {
    if (m.role === "tool") {
      const part = { functionResponse: { name: m.toolName ?? "tool", response: { result: m.content } } };
      const prev = out[out.length - 1];
      if (prev && prev.role === "user" && prev.parts.every((p) => (p as { functionResponse?: unknown }).functionResponse)) prev.parts.push(part);
      else out.push({ role: "user", parts: [part] });
    } else if (m.role === "assistant" && m.toolCalls?.length) {
      out.push({ role: "model", parts: [
        ...(m.content ? [{ text: m.content }] : []),
        ...m.toolCalls.map((c, i) => ({ functionCall: { name: c.name, args: c.args }, ...(c.thoughtSignature ? { thoughtSignature: c.thoughtSignature } : i === 0 ? { thoughtSignature: GEMINI_SKIP_SIGNATURE } : {}) })),
      ] });
    } else out.push({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] });
  }
  return out;
}

function geminiSchema(v: unknown): unknown {
  if (Array.isArray(v)) return v.map(geminiSchema);
  if (v && typeof v === "object") {
    const o: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
      o[k] = k === "type" && typeof val === "string" ? val.toUpperCase() : geminiSchema(val);
    }
    return o;
  }
  return v;
}

let toolCallSeq = 0;
const nextId = () => `call_${Date.now().toString(36)}_${(toolCallSeq++).toString(36)}`;

export async function callModelOnce(opts: {
  model: RouteModel; system: string; messages: Msg[]; tools: ToolSpec[]; env: ProviderEnv; fetchImpl?: FetchLike; timeoutMs?: number;
}): Promise<CompletionOut> {
  const fetchImpl = opts.fetchImpl ?? globalThis.fetch;
  const key = providerKey(opts.model.provider, opts.env);
  if (!key) throw new ProviderError("auth", null, null, "no key");
  const timeoutMs = opts.timeoutMs ?? 30_000;
  if (opts.model.provider === "gemini") {
    const body: Record<string, unknown> = {
      systemInstruction: { parts: [{ text: opts.system }] },
      contents: geminiContents(opts.messages),
      generationConfig: { temperature: 0.4, maxOutputTokens: MAX_OUTPUT_TOKENS },
    };
    if (opts.tools.length) {
      body.tools = [{ functionDeclarations: opts.tools.map((t) => ({ name: t.name, description: t.description, parameters: geminiSchema(t.parameters) })) }];
      body.toolConfig = { functionCallingConfig: { mode: "AUTO" } };
    }
    const r = await fetchWithTimeout(fetchImpl, `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(opts.model.model)}:generateContent`, {
      method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": key }, body: JSON.stringify(body),
    }, timeoutMs);
    const text = await r.text();
    if (!r.ok) throw classifyHttpError(r.status, text, r.headers.get("retry-after"));
    let data: { candidates?: { content?: { parts?: { text?: string; thought?: boolean; thoughtSignature?: string; functionCall?: { name?: string; args?: Record<string, unknown> } }[] } }[] };
    try { data = JSON.parse(text); } catch { throw new ProviderError("bad_response", r.status, null, "unparseable response"); }
    const parts = data.candidates?.[0]?.content?.parts ?? [];
    const toolCalls: ToolCall[] = parts.filter((p) => p.functionCall?.name).map((p) => ({ id: nextId(), name: String(p.functionCall!.name), args: (p.functionCall!.args ?? {}) as Record<string, unknown>, ...(p.thoughtSignature ? { thoughtSignature: p.thoughtSignature } : {}) }));
    const out = parts.filter((p) => !p.thought).map((p) => p.text ?? "").join("").trim();
    if (!out && toolCalls.length === 0) throw new ProviderError("bad_response", r.status, null, "empty answer");
    return { text: out, toolCalls };
  }
  const url = opts.model.provider === "groq" ? "https://api.groq.com/openai/v1/chat/completions" : "https://openrouter.ai/api/v1/chat/completions";
  const body: Record<string, unknown> = { model: opts.model.model, messages: openAiMessages(opts.system, opts.messages), temperature: 0.4, max_tokens: MAX_OUTPUT_TOKENS };
  if (opts.tools.length) { body.tools = opts.tools.map((t) => ({ type: "function", function: t })); body.tool_choice = "auto"; }
  const r = await fetchWithTimeout(fetchImpl, url, {
    method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" }, body: JSON.stringify(body),
  }, timeoutMs);
  const text = await r.text();
  if (!r.ok) throw classifyHttpError(r.status, text, r.headers.get("retry-after"));
  let data: { choices?: { message?: { content?: string | null; tool_calls?: { id?: string; function?: { name?: string; arguments?: string } }[] } }[] };
  try { data = JSON.parse(text); } catch { throw new ProviderError("bad_response", r.status, null, "unparseable response"); }
  const msg = data.choices?.[0]?.message;
  const toolCalls: ToolCall[] = (msg?.tool_calls ?? []).filter((c) => c.function?.name).map((c) => {
    let args: Record<string, unknown> = {};
    try { const p = JSON.parse(c.function?.arguments || "{}"); if (p && typeof p === "object" && !Array.isArray(p)) args = p; } catch { /* empty */ }
    return { id: c.id || nextId(), name: String(c.function!.name), args };
  });
  const out = (msg?.content ?? "").trim();
  if (!out && toolCalls.length === 0) throw new ProviderError("bad_response", r.status, null, "empty answer");
  return { text: out, toolCalls };
}

export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export interface RouteAttempt { model: string; provider: ProviderId; outcome: "ok" | "skipped_cooldown" | ErrKind; ms: number; status?: number | null; detail?: string }

/** When every model is cooling and the soonest frees within this window, wait once instead of failing. */
export const SHORT_RATE_LIMIT_WAIT_MS = 12_000;

/**
 * Try models in order; skip cooling models; one backoff retry for timeout /
 * 5xx / network on the same model; otherwise cool down and move on.
 */
export async function completeWithFallback(opts: {
  system: string; messages: Msg[]; tools: ToolSpec[]; env: ProviderEnv; cooldowns: CooldownBook;
  fetchImpl?: FetchLike; route?: RouteModel[]; timeoutMs?: number; backoffMs?: number; sleepImpl?: (ms: number) => Promise<void>;
  attempts?: RouteAttempt[]; shortWaitMs?: number;
}): Promise<{ out: CompletionOut; model: RouteModel }> {
  const route = opts.route ?? availableRoute(opts.env);
  const attempts = opts.attempts ?? [];
  const sl = opts.sleepImpl ?? sleep;
  if (route.length === 0) throw new ChatRouteError("no_keys", attempts, null);
  let lastErr: ProviderError | null = null;
  for (let pass = 0; pass < 2; pass++) {
  if (pass === 1) {
    // Rate-limit-aware: all models failed/cooling; if one frees up soon, wait for it once.
    const now = opts.cooldowns.nowMs();
    const soon = route.map((m) => opts.cooldowns.isCooling(m)).filter((c) => c.cooling).map((c) => (c.untilMs ?? 0) - now).filter((ms) => ms > 0).sort((a, b) => a - b)[0];
    if (soon === undefined || soon > (opts.shortWaitMs ?? SHORT_RATE_LIMIT_WAIT_MS)) break;
    await sl(soon + 250);
  }
  for (const model of route) {
    const c = opts.cooldowns.isCooling(model);
    if (c.cooling) { attempts.push({ model: model.model, provider: model.provider, outcome: "skipped_cooldown", ms: 0 }); continue; }
    for (let attempt = 0; attempt < 2; attempt++) {
      const t0 = Date.now();
      try {
        const out = await callModelOnce({ model, system: opts.system, messages: opts.messages, tools: opts.tools, env: opts.env, fetchImpl: opts.fetchImpl, timeoutMs: opts.timeoutMs });
        attempts.push({ model: model.model, provider: model.provider, outcome: "ok", ms: Date.now() - t0 });
        return { out, model };
      } catch (e) {
        const err = e instanceof ProviderError ? e : new ProviderError("network", null, null, String((e as Error)?.message ?? e));
        attempts.push({ model: model.model, provider: model.provider, outcome: err.kind, ms: Date.now() - t0, status: err.status, detail: String(err.message ?? "").replace(/(key|token|bearer)[=: ]+\S+/gi, "$1=<redacted>").slice(0, 160) });
        lastErr = err;
        const retryable = err.kind === "timeout" || err.kind === "unavailable" || err.kind === "network";
        if (retryable && attempt === 0) { await sl((opts.backoffMs ?? 600) * (1 + Math.random())); continue; }
        opts.cooldowns.note(model, err);
        break;
      }
    }
  }
  }
  throw new ChatRouteError("all_failed", attempts, lastErr);
}

export class ChatRouteError extends Error {
  constructor(public readonly code: "no_keys" | "all_failed", public readonly attempts: RouteAttempt[], public readonly last: ProviderError | null) {
    super(code);
    this.name = "ChatRouteError";
  }
}

/** Plain-language failure for the chat pane (never a generic "hiccup"). */
export function userFacingRouteError(err: ChatRouteError, cooldowns: CooldownBook, nowMs = Date.now()): string {
  if (err.code === "no_keys") return "Chat has no free model key configured (GROQ_API_KEY or GEMINI_API_KEY). Desk snapshot below instead.";
  const kinds = new Set(err.attempts.map((a) => a.outcome));
  const soonest = Object.values(cooldowns.snapshot()).map((v) => v.untilMs).filter((u) => u > nowMs).sort((a, b) => a - b)[0];
  const wait = soonest ? Math.max(1, Math.round((soonest - nowMs) / 1000)) : null;
  const parts: string[] = [];
  if (kinds.has("rate_limited") || kinds.has("skipped_cooldown")) parts.push(`the free models are rate-limited right now${wait ? ` (next one frees up in ~${wait}s)` : ""}`);
  if (kinds.has("quota")) parts.push("Gemini's free daily quota is used up");
  if (kinds.has("too_large")) parts.push("the question plus context was too big for the free tier (try a narrower question)");
  if (kinds.has("timeout")) parts.push("a provider timed out");
  if (kinds.has("unavailable")) parts.push("a provider is overloaded (5xx)");
  if (kinds.has("payment_required")) parts.push("OpenRouter returned 402 (paid credits exhausted) and is paused for 30 min");
  if (kinds.has("auth")) parts.push("a provider key was rejected");
  if (parts.length === 0) parts.push("every free model failed");
  return `Couldn't get a model answer: ${parts.join("; ")}. Try again shortly. Desk snapshot below.`;
}
