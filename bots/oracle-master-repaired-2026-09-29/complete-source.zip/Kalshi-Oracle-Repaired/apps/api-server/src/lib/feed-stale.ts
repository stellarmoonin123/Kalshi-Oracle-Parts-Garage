/**
 * Feed staleness predicates for entry/exit gates.
 * Extracted so organs/entry-guards can stay free of trading-bot cycles.
 * Behavior-identical to prior trading-bot exports.
 */

/** Msg silence → feed dead. */
export const FEED_STALE_TICK_MS = 5_000;
/** Quote unchanged this long with no refresh → truly frozen poll. */
export const FEED_STALE_QUOTE_MS = 60_000;

/**
 * Pure fail-closed decision for the live-mode entry gate's feed-staleness
 * check. Paper proves live — gate identical in both modes.
 */
export function isFeedStaleForEntry(tickAgeMs: number, quoteAgeMs: number, paperMode: boolean): boolean {
  void paperMode;
  return tickAgeMs > FEED_STALE_TICK_MS || quoteAgeMs > FEED_STALE_QUOTE_MS;
}

/**
 * STALE-QUOTE EXIT GUARD. Max age a 15m open trade's live quote may be.
 * Reuses FEED_STALE_QUOTE_MS: one feed, one answer.
 */
export const MAX_QUOTE_AGE_MS = FEED_STALE_QUOTE_MS;

export function isQuoteStaleForExit(quoteAgeMs: number): boolean {
  return !Number.isFinite(quoteAgeMs) || quoteAgeMs > MAX_QUOTE_AGE_MS;
}
