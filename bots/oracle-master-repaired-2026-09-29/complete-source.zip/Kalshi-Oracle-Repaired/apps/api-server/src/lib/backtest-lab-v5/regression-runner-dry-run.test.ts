import assert from "node:assert/strict";
import test from "node:test";
import { getCurrentGitSha, hasPolicyRelevantCommitsSince, POLICY_RELEVANT_PATHS } from "./regression-runner.js";
import { computeMetrics, pooledOosMetrics, decideVerdict } from "./validation.js";
import type { SimTrade } from "./causal-sim.js";

/**
 * GO — BACKTEST LAB v5 + CONTINUOUS POLICY REGRESSION (2026-08-22): a "dry
 * run" of the regression runner's non-network, non-DB pieces — the trigger
 * logic and the metrics/verdict math a full `runPolicyRegression()` call
 * builds on. Deliberately does NOT call `runLeanVsLegacy()`/
 * `runPolicyRegression()` themselves here: those hit a real market-data
 * fetch (Coinbase/Binance/CoinGecko) and the Postgres `policy_snapshots`
 * table, which would make this test flaky/slow in CI. The full end-to-end
 * path is exercised manually (see PROOF) and by the poison-test /
 * lean-vs-legacy-solo tests, which already cover the pipeline's actual
 * decision logic without needing live network+DB in the automated suite.
 */

test("regression-runner dry run: trigger logic and metrics/verdict math complete without crashing", () => {
  // Trigger logic — must not throw even outside a git repo / on any git error.
  const sha = getCurrentGitSha();
  assert.ok(sha === null || typeof sha === "string");
  assert.equal(hasPolicyRelevantCommitsSince(null), true, "no prior sha => always worth an initial baseline run");
  assert.ok(POLICY_RELEVANT_PATHS.length > 0);
  // A bogus sha must fail open to false, never throw.
  assert.doesNotThrow(() => hasPolicyRelevantCommitsSince("0000000000000000000000000000000000000000"));

  // Metrics/verdict math — synthetic trade lists standing in for a real
  // runLeanVsLegacy() run's output.
  const makeTrade = (won: boolean, pnlCents: number, i: number): SimTrade => ({
    periodStartMs: i * 900_000, minuteMark: 5, regime: "range", vBucket: "NORMAL",
    packId: null, admitted: true, strategyId: "VELOCITY_MOMENTUM", side: "YES",
    confidence: 0.7, entryPriceCents: 50, consensusCount: 1, wrongKitFamily: false,
    won, pnlCents,
  } as SimTrade);

  // 60 trades/policy — above the FAIR METRICS HARDENING (2026-08-22)
  // MIN_TRADES_FOR_VERDICT=50 floor, so this exercises the CI-overlap and
  // noise-band checks too, not just the trade-count gate.
  const leanTrades: SimTrade[] = Array.from({ length: 60 }, (_, i) => makeTrade(i % 3 !== 0, i % 3 !== 0 ? 40 : -55, i));
  const legacyTrades: SimTrade[] = Array.from({ length: 60 }, (_, i) => makeTrade(i % 2 === 0, i % 2 === 0 ? 40 : -55, i));

  const leanMetrics = computeMetrics(leanTrades);
  const legacyMetrics = computeMetrics(legacyTrades);
  assert.equal(leanMetrics.trades, 60);
  assert.ok(leanMetrics.winRate > 0 && leanMetrics.winRate < 1);
  assert.ok(typeof leanMetrics.feeNetCI.p5 === "number");

  const pooled = pooledOosMetrics(leanTrades);
  assert.equal(pooled.trades, leanTrades.length);

  const verdict = decideVerdict(leanMetrics, legacyMetrics);
  assert.ok(["LEAN_WINS", "LEGACY_WINS", "INCONCLUSIVE"].includes(verdict.verdict));

  // Too-few-trades path (below the new 50-trade floor) must be
  // INCONCLUSIVE, not a crash or a false verdict.
  const thin = computeMetrics(leanTrades.slice(0, 10));
  const thinVerdict = decideVerdict(thin, legacyMetrics);
  assert.equal(thinVerdict.verdict, "INCONCLUSIVE");
});
