import { test } from "node:test";
import assert from "node:assert/strict";
import { detectConfigDrift, configGuardRestorePatch, isPaperLocked, MIN_CONFIDENCE_DRIFT_THRESHOLD, type ManualFloorSnapshot } from "./config-guard.js";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const goodManual: ManualFloorSnapshot = {
  autoMode: false, paperMode: true, enabled: true,
  minConfidence: 52, minVelocity: 24,
  minEntryPrice: 20, maxEntryPrice: 80, minProbEdge: 0.05,
};

test("detectConfigDrift: no lastGoodManual yet (first run) — never flags drift", () => {
  const r = detectConfigDrift({ ...goodManual, autoMode: true, minConfidence: 90, minVelocity: 10 }, null);
  assert.equal(r.drifted, false);
  assert.deepEqual(r.reasons, []);
});

test("detectConfigDrift: config unchanged from lastGoodManual — no drift", () => {
  const r = detectConfigDrift({ ...goodManual }, goodManual);
  assert.equal(r.drifted, false);
});

test("detectConfigDrift: autoMode silently flips false→true — Adapt, not drift", () => {
  const r = detectConfigDrift({ ...goodManual, autoMode: true }, goodManual);
  assert.equal(r.drifted, false);
  assert.equal(r.reasons.some(s => s.includes("autoMode")), false);
});

test("detectConfigDrift: minConfidence jumps by the threshold (or more) — flags drift", () => {
  const exact = detectConfigDrift(
    { ...goodManual, minConfidence: goodManual.minConfidence + MIN_CONFIDENCE_DRIFT_THRESHOLD },
    goodManual,
  );
  assert.equal(exact.drifted, true);
  assert.ok(exact.reasons.some(r => r.includes("minConfidence")));

  // The exact regression scenario from Phase 0/1: manual 52, drifted to 72.
  const big = detectConfigDrift({ ...goodManual, minConfidence: 72 }, goodManual);
  assert.equal(big.drifted, true);
});

test("detectConfigDrift: a small minConfidence move below the threshold is not drift", () => {
  const r = detectConfigDrift(
    { ...goodManual, minConfidence: goodManual.minConfidence + (MIN_CONFIDENCE_DRIFT_THRESHOLD - 1) },
    goodManual,
  );
  assert.equal(r.drifted, false);
});

test("detectConfigDrift: minConfidence going DOWN is never flagged (operator loosening is not drift)", () => {
  const r = detectConfigDrift({ ...goodManual, minConfidence: 10 }, goodManual);
  assert.equal(r.drifted, false);
});

test("detectConfigDrift: minVelocity changing alone (no autoMode/minConfidence change) is not flagged", () => {
  const r = detectConfigDrift({ ...goodManual, minVelocity: 99 }, goodManual);
  assert.equal(r.drifted, false);
});

test("detectConfigDrift: minConfidence jump still reported when autoMode also true", () => {
  const r = detectConfigDrift({ ...goodManual, autoMode: true, minConfidence: 72 }, goodManual);
  assert.equal(r.drifted, true);
  assert.equal(r.reasons.length, 1);
  assert.ok(r.reasons[0].includes("minConfidence"));
});

test("detectConfigDrift: paperMode true→false is drift (#409)", () => {
  const r = detectConfigDrift({ ...goodManual, paperMode: false }, goodManual);
  assert.equal(r.drifted, true);
  assert.ok(r.reasons.some(s => s.includes("paperMode")));
});

test("detectConfigDrift: enabled true→false is drift (#409)", () => {
  const r = detectConfigDrift({ ...goodManual, enabled: false }, goodManual);
  assert.equal(r.drifted, true);
  assert.ok(r.reasons.some(s => s.includes("enabled")));
});

test("detectConfigDrift: paperMode staying true is not drift", () => {
  const r = detectConfigDrift({ ...goodManual, paperMode: true }, goodManual);
  assert.equal(r.drifted, false);
});


const DIR = path.dirname(fileURLToPath(import.meta.url));
const PRODUCTION_CONFIG = path.resolve(DIR, "../../.bot-config.json");

test("CONFIG_GUARD doctrine: production disk paperMode true, autoMode false, hourly/perp off, SEV1/OTM disabled", () => {
  const cfg = JSON.parse(fs.readFileSync(PRODUCTION_CONFIG, "utf8")) as Record<string, unknown>;
  assert.equal(cfg.paperMode, true);
  assert.equal(cfg.autoMode, false, "autoMode false on production disk (LOCK)");
  assert.equal(cfg.enable1HContracts, false);
  assert.equal(cfg.enable1HLive, false);
  assert.equal(cfg.candlestickPatternLiveEnabled, false);
  assert.equal(cfg.useExpertAgent, false);
  const disabled = cfg.disabledStrategies as string[];
  for (const id of [
    "DEEP_OTM_SNIPER", "OTM_ASYMMETRY", "OTM_BREAKOUT_EXPANSION",
    "SAKATA_CANDLE_PATTERN", "SETTLEMENT_PREDICTION", "LATE_ENTRY_ANCHOR",
  ]) {
    assert.ok(disabled.includes(id), `disk must keep ${id} disabled`);
  }
  // A checked-in safe baseline may keep optional strategies disabled even
  // outside frozen mode; this test must never demand that one be enabled.
  assert.equal(disabled.includes("BRTI_PROBABILITY"), true,
    "the committed baseline keeps BRTI fail-closed");
});

test("detectConfigDrift: autoMode true→false is not drift (operator turning composer off)", () => {
  const armed: ManualFloorSnapshot = { ...goodManual, autoMode: true };
  const r = detectConfigDrift({ ...armed, autoMode: false }, armed);
  assert.equal(r.drifted, false);
});

test("detectConfigDrift: lastGoodManual paperMode true is the live-money lock", () => {
  assert.equal(goodManual.paperMode, true);
});

test("configGuardRestorePatch omits autoMode and keeps paperMode true", () => {
  const patch = configGuardRestorePatch({ ...goodManual, autoMode: false });
  assert.equal("autoMode" in patch, false);
  assert.equal(patch.paperMode, true);
  assert.equal(patch.minConfidence, 52);
  assert.equal(patch.minEntryPrice, 20);
});


test("configGuardRestorePatch ALWAYS pins paperMode true (even if last-good said false)", () => {
  const patch = configGuardRestorePatch({ ...goodManual, paperMode: false });
  assert.equal(patch.paperMode, true);
  assert.equal("autoMode" in patch, false);
});

test("detectConfigDrift: unspecified last-good paperMode still locks silent false", () => {
  const last = { ...goodManual };
  delete (last as { paperMode?: boolean }).paperMode;
  assert.equal(isPaperLocked(last), true);
  const r = detectConfigDrift({ ...goodManual, paperMode: false }, last);
  assert.equal(r.drifted, true);
  assert.ok(r.reasons.some(s => s.includes("paperMode")));
});

test("detectConfigDrift: paperMode false is ALWAYS drift (even if last-good was false)", () => {
  const last = { ...goodManual, paperMode: false };
  assert.equal(isPaperLocked(last), false);
  const r = detectConfigDrift({ ...goodManual, paperMode: false }, last);
  assert.equal(r.drifted, true);
  assert.ok(r.reasons.some(s => s.includes("paperMode")));
});
