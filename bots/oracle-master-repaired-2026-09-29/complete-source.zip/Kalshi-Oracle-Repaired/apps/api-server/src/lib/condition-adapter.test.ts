import assert from "node:assert/strict";
import test from "node:test";
import { classifyDetailedCondition } from "./condition-adapter.js";
import type { StrategyObservation } from "./strategy-library.js";
import type { BasisState } from "./basis-tracker.js";
import { __resetRegimeStateForTests, computeRegimeScores, propose } from "./regime-engine.js";

function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 63500,
    floorStrike: 63500,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0,
    massAboveFloor: 50,
    secsRemaining: 600,
    ...overrides,
  };
}

/**
 * GO — HYSTERETIC REGIME ENGINE cutover: classifyDetailedCondition() no
 * longer classifies `obs` itself — it reads the persistent committed regime
 * from regime-engine.ts. These tests exercise the overlay/chaos-mode logic
 * in isolation (hysteresis timing itself is covered by regime-engine.test.ts),
 * so each test force-commits the state to whatever the pure classifier would
 * propose for its `obs`, bypassing CONFIRM_TICKS/MIN_DWELL_MS.
 */
function forceRegimeFor(obs: StrategyObservation): void {
  const scores = computeRegimeScores(obs);
  __resetRegimeStateForTests({ current: propose(scores), lastScores: scores });
}

function basisState(overrides: Partial<BasisState> = {}): BasisState {
  return {
    rollingBasis: 0,
    shortBasis: 0,
    basisStreakCount: 3,
    basisStreakSign: 1,
    basisStreakMs: 5000,
    signFlippedAt: null,
    estimatedFairBRTI: 63500,
  basisLeadUsd: 63500,
    projectedSettlementPrice: 63500,
    exchangePrice: 63500,
    exchangeSource: "coinbase",
    brtiProxy: 63500,
    lastUpdated: Date.now(),
    lastFloorStrike: 63500,
    sampleCount: 10,
    lagSeconds: null,
    lagDollars: null,
    lagCorr: null,
    lagStale: true,
    lagReason: "empty_series",
    lagSampleN: 0,
    lagResidualDollars: null,
    leaderName: null,
    leadSeconds: null,
    leadDollars: null,
    proofHitRate: null,
    lagProven: false,
    coinbaseObservedAt: null,
    coinbaseAgeMs: null,
    binanceObservedAt: null,
    binanceAgeMs: null,
    ...overrides,
  };
}

test("chaosMode is false with calm velocity and no recent basis flip", () => {
  const obs = baseObs();
  forceRegimeFor(obs);
  const result = classifyDetailedCondition(obs, "unclear", 0, basisState());
  assert.equal(result.chaosMode, false);
});

test("chaosMode triggers on an extreme velocity spike regardless of direction", () => {
  const upObs = baseObs({ velocityDolPerMin: 150, threeMinVelocity: 10 });
  forceRegimeFor(upObs);
  const up = classifyDetailedCondition(upObs, "unclear", 0, basisState());
  assert.equal(up.chaosMode, true);

  const downObs = baseObs({ velocityDolPerMin: -150, threeMinVelocity: -10 });
  forceRegimeFor(downObs);
  const down = classifyDetailedCondition(downObs, "unclear", 0, basisState());
  assert.equal(down.chaosMode, true);
});

test("chaosMode triggers on a recent basis sign flip even with calm velocity", () => {
  const obs = baseObs();
  forceRegimeFor(obs);
  const result = classifyDetailedCondition(
    obs,
    "unclear",
    0,
    basisState({ signFlippedAt: Date.now() - 3000 }),
  );
  assert.equal(result.chaosMode, true);
});

test("chaosMode does not trigger on a stale (>window) basis sign flip", () => {
  const obs = baseObs();
  forceRegimeFor(obs);
  const result = classifyDetailedCondition(
    obs,
    "unclear",
    0,
    basisState({ signFlippedAt: Date.now() - 60_000 }),
  );
  assert.equal(result.chaosMode, false);
});

test("chaosMode is false when no basisState is supplied at all (optional-param safety)", () => {
  const obs = baseObs();
  forceRegimeFor(obs);
  const result = classifyDetailedCondition(obs, "unclear", 0);
  assert.equal(result.chaosMode, false);
});

test("chaosMode merges the momentum-suppress cluster into whatever the base condition already suppresses", () => {
  const obs = baseObs({ velocityDolPerMin: 150, threeMinVelocity: 10 });
  forceRegimeFor(obs);
  const result = classifyDetailedCondition(obs, "unclear", 0, basisState());
  for (const id of ["VELOCITY_MOMENTUM", "BREAKOUT_CAPTURE", "CONFLUENCE_CASCADE", "MTF_ALIGNED"]) {
    assert.ok(result.overlay.suppressStrategies.includes(id), `expected ${id} suppressed in chaos mode`);
  }
});

test("chaosMode redirects the boost to a lag-exploiting strategy when the base boost would be suppressed", () => {
  // 'unclear' condition normally boosts CONFLUENCE_CASCADE, which chaos suppresses.
  const obs = baseObs({ velocityDolPerMin: 150, threeMinVelocity: 10 });
  forceRegimeFor(obs);
  const result = classifyDetailedCondition(obs, "unclear", 0, basisState());
  assert.equal(result.condition, "unclear");
  assert.equal(result.overlay.boostStrategy, "BASIS_LAG_EDGE");
});

test("chaosMode leaves a non-suppressed condition-specific boost alone", () => {
  // Squeeze condition boosts SQUEEZE_EXPANSION, which is not in the chaos-suppress cluster.
  const obs = baseObs({
    velocityDolPerMin: 150, // forces chaos on
    threeMinVelocity: 10,
    volumeState: "low",
    bbSqueezeStrong: true,
  } as Partial<StrategyObservation>);
  forceRegimeFor(obs);
  const result = classifyDetailedCondition(obs, "unclear", 0, basisState());
  assert.equal(result.condition, "squeeze");
  assert.equal(result.overlay.boostStrategy, "SQUEEZE_EXPANSION");
});
