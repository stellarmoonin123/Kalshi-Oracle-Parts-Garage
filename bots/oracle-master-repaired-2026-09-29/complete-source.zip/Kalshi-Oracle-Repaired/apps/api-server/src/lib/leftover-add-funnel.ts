/**
 * Leftover add-to-position evaluate + fill. Paper KXBTC15M never runs it.
 * Host leftoverAddEvaluateMayRun is the only door. Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
import { ADD_POSITION_MIN_PROFIT_CENTS, KALSHI_API_DOMAIN, KALSHI_PATH_PORTFOLIO_ORDERS, kalshiEventsOrderPath } from "./constants.js";
import { ariaMayGovernOrders } from "./fill-authority.js";
import { kalshiWS } from "./kalshi-ws.js";
import { mtfAnalyzer, getMtfOhlcBars } from "./mtf-analyzer.js";
import { candlePatternAnalyzer } from "./candlestick-patterns.js";
import { computePsychLevel, type StrategyObservation } from "./strategy-library.js";
import { canScaleIntoPosition, computeContracts as computeKellyContracts, EV_FLOOR, HARD_RISK_LIMITS } from "./organs/size.js";
import { shouldDiscountAdd } from "./thesis-state.js";
import { computeTradeEV } from "./organs/path-gate.js";
import { buildBookSnap } from "./liquidity-policy.js";
import { updateRegime, getRegime, getRegimeHeldBy } from "./regime-engine.js";
import { generateTraceId, persistDecisionTrace } from "./decision-trace.js";
import { snapshotTape } from "./organs/tape.js";
import { observeAdaptiveRegime, fillPathRegimeTraceFields } from "./organs/regime.js";
import { computeLiveHtfStructure } from "./mtf-structure.js";
import { expertAgent } from "./expert-agent.js";
import { paperFillCostCents } from "./settlement-helpers.js";
import { dailyTargetEntryBlock } from "./daily-target.js";
import { buildKalshiV2Body, stableClientOrderId } from "./kalshi-order-body.js";
import { recordFailure, recordSuccess } from "./decision-safety.js";
import { paperDeskAddToPositionMayRun } from "./evaluate-15m-scope.js";

export const LEFTOVER_ADD_EVALUATE_LOADED = true as const;

export const FROZEN_ADD_FUNNEL_MARKERS = [
  "ADD_BLOCKED_LAG_DISAGREE",
  "DISCOUNT-ADD",
  "ADD-TO-POSITION:",
  "STREAK_SATURATION no_size_up",
  "selectBestEnabled(addPool",
  "paperVirtualBalanceCents -= costCents",
  "ADD_TO_POSITION DEPTH_UNAVAILABLE",
] as const;

export type LeftoverAddHelpers = {
  detectStallInfo: (prices: { price: number; ts: number }[]) => { isStalling: boolean; stallStrength: "none" | "weak" | "strong" };
  resolveAddPositionVolatility: (...args: any[]) => { annualVol: number; stale: boolean };
  isVolBufferRecovery: (wasStale: boolean, isStale: boolean) => boolean;
  probabilityEdge: (...args: any[]) => { prob: number; edge: number };
  selectBestEnabled: (...args: any[]) => any;
  effectiveDisabledStrategies: (cfg: any) => string[];
  makeTraceScopedSkip: (...args: any[]) => any;
  blendedEntryPriceCents: (...args: any[]) => number;
  resolveAddFillOutcome: (...args: any[]) => string;
  getKalshiRejectionDetail: (...args: any[]) => string;
  kalshiAuthHeaders: (...args: any[]) => Promise<Record<string, string>>;
  tradeSecsRemaining: (trade: any) => number;
  fetchOrderbookDepthAtEntry: (...args: any[]) => Promise<any>;
  resolveDepthAwareSizing: (...args: any[]) => any;
};

export async function leftoverAddEvaluateFunnel(this: any, helpers: LeftoverAddHelpers): Promise<void> {
  const {
    detectStallInfo,
    resolveAddPositionVolatility,
    isVolBufferRecovery,
    probabilityEdge,
    selectBestEnabled,
    effectiveDisabledStrategies,
    makeTraceScopedSkip,
    tradeSecsRemaining,
  } = helpers;

    const traceId = generateTraceId();
    const skip = makeTraceScopedSkip(this.logSkippedDecision.bind(this), { traceId });
    if (!paperDeskAddToPositionMayRun(this.config)) return;
    if (!this.config.useAddToPosition) return;
    if (!this.openTrade) return;

    const secs = tradeSecsRemaining(this.openTrade);
    if (secs < 4 * 60) return;                     // need 4+ minutes left

    const tick = kalshiWS.getLatest();
    if (!tick) return;
    if (tick.source === "rest") return;            // REST-not-live: refuse add

    const currentPrice = this.prices.length > 0 ? this.prices[this.prices.length - 1].price : 0;
    if (currentPrice === 0) return;

    // ── Buffer staleness guard (add-to-position) ──────────────────────────────
    // A one-off stale cycle uses conservative neutral vol, matching the
    // probability model's short-buffer default. If the feed remains dark for
    // a second consecutive add evaluation, do not let a discretionary scale-in
    // proceed on synthetic volatility. This is intentionally checked before
    // strategy evaluation, so no later path can place an add while blocked.
    const addLastTickAgeMs = this.prices.length > 0
      ? Date.now() - this.prices[this.prices.length - 1].ts
      : Infinity;
    const { annualVol, stale: addBufStale } = resolveAddPositionVolatility(this.prices);
    if (addBufStale) {
      this.addPositionStaleStreak++;
      if (!this.volStaleAddLogged) {
        this.log("warn",
          `[add-to-position] Vol buffer stale (last tick ${(addLastTickAgeMs / 1000).toFixed(1)}s ago) — ` +
          `using conservative vol fallback for probability-edge model`
        );
        this.volStaleAddLogged = true;
      }
      if (this.addPositionStaleStreak > 1) return;
    } else {
      if (isVolBufferRecovery(this.volStaleAddLogged, addBufStale)) {
        this.log("info",
          "[add-to-position] Vol buffer recovered — re-evaluating add-to-position"
        );
      }
      this.volStaleAddLogged = false;
      this.addPositionStaleStreak = 0;
    }

    const { isStalling: stalling, stallStrength } = detectStallInfo(this.prices);
    if (stalling) return;                            // don't add into stalling momentum

    const floorStrike    = tick.floorStrike;
    const distFromFloor  = floorStrike > 0 ? ((currentPrice - floorStrike) / floorStrike) * 100 : 0;

    // ── Block adds while lag disagrees (2026-08-14) ───────────────────────────
    // Single-tick check (no persistence) — adding is a discretionary scale-in,
    // not a forced exit, so the bar for refusing it is lower than
    // LAG_FLIP_EXIT's persistence requirement. Missing/stale lag data never
    // blocks an add (isLagAgainstSide already treats that as "not against").
    if (this.isLagAgainstSide(this.openTrade.side, floorStrike, this.currentVelocity, secs)) {
      const lagMsg = `🚫 ADD_BLOCKED_LAG_DISAGREE: side=${this.openTrade.side.toUpperCase()} — exchange-led ` +
        `settlement projection disagrees with open side, refusing add`;
      this.log("info", lagMsg);
      // Phase 2 skip-audit (2026-08-15): this was the one genuine gap found —
      // lag disagreement blocked the add but was never recorded via
      // logSkippedDecision, so it never reached the skip-code funnel/meta-
      // labeling corpus like every other rejection reason. Logging only —
      // the block itself (isLagAgainstSide) is unchanged.
      skip("LAG_DISAGREE", [lagMsg], {
        ticker: this.openTrade.ticker, side: this.openTrade.side, strategyId: this.openTrade.strategyId,
        entryPriceCents: this.openTrade.entryPriceCents, confidence: this.openTrade.confidence, secsRemaining: secs,
        floorStrike,
      });
      return;
    }

    // Never increase size into a streak fade / past-max rewrite (friend 8→11).
    {
      const addSat = this.evaluateLiveStreakSat(this.openTrade.side, this.lastObservation, currentPrice);
      if (addSat.noSizeUp || this.openTrade.preferEarlyExit === true) {
        const msg = `STREAK_SATURATION no_size_up — never add/martingale a streak fade (${addSat.displayLine ?? ""})`;
        this.log("info", msg);
        skip("STREAK_SATURATION", [msg], {
          ticker: this.openTrade.ticker, side: this.openTrade.side, strategyId: this.openTrade.strategyId,
          entryPriceCents: this.openTrade.entryPriceCents, confidence: this.openTrade.confidence, secsRemaining: secs,
          floorStrike,
        });
        return;
      }
    }

    const addAsk = this.openTrade.side === "yes" ? tick.yesAsk : tick.noAsk;
    const addMark = this.openTrade.side === "yes" ? tick.yesBid : tick.noBid;
    const addThesis = this.evaluateOpenThesis(this.openTrade, {
      markCents: addMark,
      askCents: addAsk,
      quoteSource: tick.source,
      quoteStale: false,
      secs,
      vel: this.currentVelocity,
      floorStrike,
    });
    if (addThesis.status !== "VALID") return; // tighten: no add unless thesis holds

    // Discount add (VALID + 3–8¢ cheaper ask). Same addToPosition path.
    {
      const pWin = this.openTrade.strategyWinRateAtEntry;
      const evCents = (typeof pWin === "number" && pWin > 0)
        ? computeTradeEV({
            entryPriceCents: addAsk,
            winRate: pWin,
            strategyId: this.openTrade.strategyId,
            secsRemaining: secs,
            velocityDolPerMin: this.currentVelocity,
            minEVCents: EV_FLOOR,
          }).netEV
        : 0;
      const addBalance = this.effectiveBalance();
      const underNinePctCap = canScaleIntoPosition({
        balanceCents: addBalance,
        todayPnlCents: this.dayPnlForHalt(),
        existingContracts: this.openTrade.contracts,
        existingEntryPriceCents: this.openTrade.entryPriceCents,
        addContracts: 1,
        addPriceCents: addAsk,
      });
      let kellyResidualContracts = 0;
      if (typeof pWin === "number" && pWin > 0 && addBalance > 0) {
        const sized = computeKellyContracts({
          pWin,
          pSizeClamped: pWin,
          entryPriceCents: addAsk,
          confidence: this.openTrade.confidence,
          edge: Math.abs(pWin - 0.5) * 100,
          balanceCents: addBalance,
          maxContracts: this.config.maxContractsPerTrade,
          uMult: 1,
        });
        kellyResidualContracts = sized.contracts - this.openTrade.contracts;
      }
      const discount = shouldDiscountAdd({
        thesisStatus: addThesis.status,
        entryCents: this.openTrade.entryPriceCents,
        askCents: addAsk,
        addedContracts: this.openTrade.addedContracts,
        evCents,
        kellyResidualContracts,
        originalContracts: this.openTrade.contracts,
        underNinePctCap,
        lagAgainst: false, // already returned above if against
        quoteSource: tick.source,
        secsRemaining: secs,
      });
      if (discount.allow) {
        this.log("signal",
          `➕ DISCOUNT-ADD: ${this.openTrade.side.toUpperCase()} +1 @ ${addAsk}¢ ` +
          `(entry ${this.openTrade.entryPriceCents}¢ dip ${this.openTrade.entryPriceCents - addAsk}¢) · thesis VALID`);
        await this.addToPosition(tick, traceId);
        return;
      }
    }

    if (this.openTradePnlCents < ADD_POSITION_MIN_PROFIT_CENTS) return;  // winner-add: must already be winning

    const minsLeft       = secs / 60;
    const { prob, edge } = probabilityEdge(currentPrice, floorStrike, annualVol, minsLeft);
    const mtfScore = mtfAnalyzer.getScore();

    const obs: StrategyObservation = {
      currentPrice, floorStrike,
      ticker: this.openTrade.ticker,
      cheapSide15mEnabled: this.config.paperMode === true || this.config.cheapSide15mEnabled === true, // paper desk v2
      cheapEarlyExitEnabled: this.config.cheapEarlyExitEnabled === true,
      panicFadeEnabled: this.config.paperMode === true || this.config.panicFadeEnabled === true, // paper desk v2
      streakSatFadeEnabled: this.config.streakSatFadeEnabled === true,
      // Same NO_QUOTE fix as the main entry-evaluation obs below — must carry
      // the live ask/bid through or any add-to-position strategy check that
      // reads obs.yesAsk/noAsk always sees undefined.
      yesBid: tick.yesBid, yesAsk: tick.yesAsk, noBid: tick.noBid, noAsk: tick.noAsk,
      microstructureTs: tick.quoteTs,
      velocityDolPerMin: this.currentVelocity, threeMinVelocity: this.threeMinVelocity,
      isStalling: stalling, stallStrength,
      distFromFloorPct: distFromFloor, massAboveFloor: prob * 100,
      secsRemaining: secs,
      shortTrend:  this.currentVelocity  >  20 ? 'up' : this.currentVelocity  < -20 ? 'down' : 'sideways',
      mediumTrend: this.threeMinVelocity >  15 ? 'up' : this.threeMinVelocity < -15 ? 'down' : 'sideways',
      mtfScore,
      psychLevel: computePsychLevel(currentPrice, floorStrike),
      candlePattern: candlePatternAnalyzer.getLatest() ?? undefined,
      lagSeconds: this.lastBasisState?.lagSeconds ?? null,
      lagDollars: this.lastBasisState?.lagDollars ?? null,
      lagCorr: this.lastBasisState?.lagCorr ?? null,
      lagStale: this.lastBasisState?.lagStale ?? true,
      lagReason: this.lastBasisState?.lagReason,
      lagResidualDollars: this.lastBasisState?.lagResidualDollars ?? null,
      leaderName: this.lastBasisState?.leaderName ?? null,
      leadSeconds: this.lastBasisState?.leadSeconds ?? null,
      leadDollars: this.lastBasisState?.leadDollars ?? null,
      proofHitRate: this.lastBasisState?.proofHitRate ?? null,
      lagProven: this.lastBasisState?.lagProven === true,
      paperMode: this.config.paperMode === true,
      ohlc1m: getMtfOhlcBars(1)?.bars,
      ohlc5m: getMtfOhlcBars(5)?.bars,
      openStrategyId: this.openTrade?.strategyId ?? null,
    };
    // P4 LIQUIDITY POLICY: per-side book snapshots for BASIS_LAG_EDGE's Part C.
    {
      const addOb = kalshiWS.getLatestOrderbook();
      obs.liquidityBook = {
        YES: buildBookSnap({ side: 'YES', currentTicker: this.openTrade.ticker, quote: { yesBid: tick.yesBid, yesAsk: tick.yesAsk, noBid: tick.noBid, noAsk: tick.noAsk }, latestOrderbook: addOb }),
        NO:  buildBookSnap({ side: 'NO',  currentTicker: this.openTrade.ticker, quote: { yesBid: tick.yesBid, yesAsk: tick.yesAsk, noBid: tick.noBid, noAsk: tick.noAsk }, latestOrderbook: addOb }),
      };
    }
    // GO — HYSTERETIC REGIME ENGINE: this path (in-trade, deciding whether to
    // scale in) is a WRITER — it is the only tick-cadence path that runs
    // while a position is open (evaluateEntry() below does not run while
    // this.openTrade is set), so R_t must keep updating here or it would
    // freeze for the entire lifetime of every open trade. This obs is a
    // lighter subset than evaluateEntry()'s (no volumeState/
    // recentlyBrokeLevel/quickReclaim/bbSqueezeStrong) — propose() treats
    // those as simply non-matching, not invalid (see regime-engine.ts).
    const regime = updateRegime(obs, Date.now());
    obs.regime = regime;
    try {
      this.lastAdaptiveRegime = observeAdaptiveRegime({
        obs,
        now: Date.now(),
        ...fillPathRegimeTraceFields({
          yesAsk: obs.yesAsk, noAsk: obs.noAsk,
          side: this.openTrade?.side ?? null,
          strategyId: this.openTrade?.strategyId ?? this.lastStrategyResult?.strategyId ?? null,
          pWinAtEntry: this.openTrade?.strategyWinRateAtEntry ?? null,
          minutesLeft: (obs.secsRemaining ?? 0) / 60,
          secsRemaining: obs.secsRemaining,
        }),
      });
    } catch { /* log-only organ */ }
    this.lastTapeOrgan = snapshotTape({
      quotes: { yesAsk: obs.yesAsk, noAsk: obs.noAsk, yesBid: obs.yesBid, noBid: obs.noBid },
      floor: obs.floorStrike,
      velocity: obs.velocityDolPerMin,
      ohlc1m: obs.ohlc1m ?? null,
      ohlc5m: obs.ohlc5m ?? null,
      mtf: obs.mtfScore ?? null,
      lag: this.lastBasisState,
      htf: computeLiveHtfStructure(currentPrice),
      streakSaturation: obs.streakSaturation ?? null,
      settlementStreak: obs.settlementStreak ?? null,
    });
    this.lastObservation = obs;
    this.lastObsTs = Date.now();

    // GO PRODUCTION QUALITY 8.0→8.5 Step B: same disabled set already used by
    // selectBestEnabled() below is now also passed into the shared
    // enumeration function, so a disabled strategy's evaluate() is never
    // invoked for the add-to-position decision either.
    const addDisabled = effectiveDisabledStrategies(this.config);
    const addEval: { all: Array<{ strategyId: string; signal: string; confidence: number }> } = this.evaluateStrategiesForBot(obs, addDisabled);
    const { all: allAddResults } = addEval;
    this.warnIfDisabledStrategyOverride("add");
    const addPool = this.config.strategyOverride
      ? allAddResults.filter(r => r.strategyId === this.config.strategyOverride)
      : allAddResults;
    const stratResult = selectBestEnabled(addPool, addDisabled);
    if (!stratResult) return;

    // Must confirm the same direction as our open trade
    const addSide = stratResult.signal === 'YES' ? 'yes' : 'no';
    if (addSide !== this.openTrade.side) return;

    // ── Expert Agent setup-control override (tighten-only) ─────────────────────
    // ARIA may raise the confidence bar required to scale into a winning
    // position; Math.max against the static config guarantees a fresh AI read
    // can only require MORE conviction to add, never less.
    const addSetupAi = ariaMayGovernOrders(this.config) ? expertAgent.getSetupControlOverrides() : null;
    const effAddConfidenceThreshold = addSetupAi?.minAddConfidence !== undefined
      ? Math.max(this.config.addConfidenceThreshold, addSetupAi.minAddConfidence)
      : this.config.addConfidenceThreshold;
    if (addSetupAi) this.lastAgentSetupControls = addSetupAi;

    const conf = stratResult.confidence * 100;
    if (conf < effAddConfidenceThreshold) return;

    // MTF must be aligned
    const mtfAligned = (this.openTrade.side === "yes" && mtfScore >= 1) ||
                       (this.openTrade.side === "no"  && mtfScore <= -1);
    if (!mtfAligned) return;

    // Extreme confidence gate: require velocity to be strong
    if (Math.abs(this.currentVelocity) < 70) return;

    // All checks passed — add 1 contract
    this.log("signal", `➕ ADD-TO-POSITION: ${this.openTrade.side.toUpperCase()} +1 contract · conf ${Math.round(conf)}% · MTF ${mtfScore > 0 ? '+' : ''}${mtfScore}`);
    await this.addToPosition(tick, traceId);
}

export async function leftoverAddFillFunnel(this: any, tick: any, traceId: string | undefined, helpers: LeftoverAddHelpers): Promise<void> {
  const {
    blendedEntryPriceCents,
    resolveAddFillOutcome,
    getKalshiRejectionDetail,
    kalshiAuthHeaders,
    fetchOrderbookDepthAtEntry,
    resolveDepthAwareSizing,
  } = helpers;
    if (!paperDeskAddToPositionMayRun(this.config)) return;
    if (!this.openTrade) return;
    const trade     = this.openTrade;
    const addPrice  = trade.side === "yes" ? tick.yesAsk : tick.noAsk;  // ask → immediate fill
    const addContracts = 1;
    const costCents = paperFillCostCents(addContracts, addPrice);
    // GO — SPECIALIST REGIME SYSTEM Phase 0: addToPosition never creates a new
    // bot_trades row (it scales an existing open trade), so there's no
    // traceId column to attach here — but a successful add is still a real
    // ORDER outcome and gets its own DecisionTrace row, referencing the
    // existing open trade's dbId rather than a new one.
    const addTraceId = traceId ?? generateTraceId();

    if (trade.paper) {
      if (this.paperVirtualBalanceCents < costCents) return;
      this.paperVirtualBalanceCents -= costCents;
      this.persistPaperLedger();
      // Re-average the cost basis: every P&L/fee helper prices ALL contracts
      // at entryPriceCents, so an add filled above entry used to be booked as
      // if bought at the original price (paper cash and paper P&L drifted apart).
      this.openTrade.entryPriceCents = blendedEntryPriceCents(
        this.openTrade.entryPriceCents, this.openTrade.contracts, addPrice, addContracts,
      );
      this.openTrade.contracts    += addContracts;
      this.openTrade.addedContracts = true;
      this.log("order", `➕ ADDED 1 contract [PAPER] · now ${this.openTrade.contracts}× ${trade.side.toUpperCase()} @ ${addPrice}¢`);
      void persistDecisionTrace({
        traceId: addTraceId, ts: Date.now(), ticker: trade.ticker, side: trade.side,
        contracts: this.openTrade.contracts, ask: addPrice, outcome: "ORDER",
        // Phase 1 (SPECIALIST REGIME SYSTEM): wire the sticky committed
        // regime + its current hold reason, per spec.
        regime: getRegime(), regimeHeldBy: getRegimeHeldBy() ?? undefined,
        chain: ["ADD_TO_POSITION", "paper"], botTradeId: trade.dbId ?? undefined,
      });
      return;
    }

    // 2026-08-25 PhD audit fix: a scale-in add used to skip every admission
    // check a fresh entry gets. Refresh balance and re-check daily-target /
    // circuit-breaker / cumulative-9%-cap here, exactly like a new entry
    // would, before this add is allowed to place a real order.
    await this.refreshBalance();
    if (this.isBalanceStale()) {
      this.log("warn",
        `⛔ Add-to-position BLOCKED — balance ${this.accountBalance === null ? "never fetched" : "stale"}` +
        (this.lastBalanceError ? ` (${this.lastBalanceError})` : ""));
      return;
    }
    const addBalanceCents = this.effectiveBalance();
    const addDailyBlock = dailyTargetEntryBlock(this.lastDailyTarget, this.dailyTargetLatchDirty, this.dailyTargetLoadFailed);
    if (addDailyBlock) {
      this.log("warn", `⛔ Add-to-position BLOCKED — ${addDailyBlock}`);
      return;
    }
    if (!canScaleIntoPosition({
      balanceCents: addBalanceCents,
      todayPnlCents: this.dayPnlForHalt(),
      existingContracts: trade.contracts,
      existingEntryPriceCents: trade.entryPriceCents,
      addContracts, addPriceCents: addPrice,
    })) {
      this.log("warn",
        `⛔ Add-to-position BLOCKED — cumulative exposure (${trade.contracts + addContracts}× ${trade.side.toUpperCase()}) ` +
        `would exceed the ${(HARD_RISK_LIMITS.maxRiskPctPerTrade * 100).toFixed(0)}% equity cap.`);
      return;
    }

    // A scale-in is still a live entry order. It must use the same fresh,
    // fail-closed depth admission as a new position so a one-contract add
    // cannot consume all of a thin book or bypass the configured cap.
    const addDepthResult = await fetchOrderbookDepthAtEntry(
      trade.ticker,
      trade.side,
      addPrice,
    );
    const addDepthSizing = resolveDepthAwareSizing(
      addContracts,
      addDepthResult,
      this.config.maxDepthFraction,
    );
    if (!addDepthResult.available) {
      this.log("warn",
        `[depth] ADD_TO_POSITION DEPTH_UNAVAILABLE: ${addDepthResult.warning}; blocking live add`
      );
      return;
    }
    if (addDepthSizing.contracts < addContracts) {
      this.log("info",
        `depth cap: sized down ${addContracts}→${addDepthSizing.contracts} ` +
        `(${addDepthSizing.visibleDepth} contracts visible at price)`
      );
      this.log("warn",
        `[depth] ADD_TO_POSITION DEPTH_SIZE_ZERO: visible depth is too small ` +
        `for the configured ${this.config.maxDepthFraction * 100}% cap; blocking live add`
      );
      return;
    }

    // Buy more of trade.side using Kalshi V2 API
    // Buy YES → bid at yes ask price; Buy NO → ask at (100 - no_ask) = yes bid price
    let orderId: string | null = null;
    try {
      const apiPath    = KALSHI_PATH_PORTFOLIO_ORDERS;
      const addHeaders = await kalshiAuthHeaders("POST", apiPath);

      // Auth guard — same as entry and exit order paths.
      if (!addHeaders["KALSHI-ACCESS-KEY"]) {
        this.log("warn",
          `⚠️ CRITICAL: Add-to-position BLOCKED — auth signing failed. ` +
          `Check your API key in Settings.`);
        return;
      }

      // D7 — same trade + same pre-add size + same add → same client_order_id (retry-safe).
      const body = buildKalshiV2Body(trade.ticker, trade.side, addContracts, addPrice,
        stableClientOrderId("add", trade.dbId ?? trade.ticker, trade.contracts, addContracts, addPrice));
      // Task #158/#161: log the base URL used for every live order so
      // endpoint routing can be audited from logs alone.
      this.log("order", `POST ${KALSHI_API_DOMAIN}${apiPath} · ticker=${trade.ticker} side=${body.side} reason=ADD_TO_POSITION`);
      const r = await fetch(`${KALSHI_API_DOMAIN}${apiPath}`, {
        method: "POST", headers: addHeaders,
        body: JSON.stringify(body), signal: AbortSignal.timeout(4_000),
      });
      if (!r.ok) {
        recordFailure("kalshi-api");
        const errBody = await r.json().catch(() => ({})) as Record<string, unknown>;
        const detail = getKalshiRejectionDetail(errBody, r.status);
        this.log("warn", `Add-to-position FAILED [HTTP ${r.status}]: ${detail}`);
        // Task #204: surface the exact rejection reason on BotStatus.
        this.publishOrderRejection(trade.ticker, trade.side, detail);
        return;
      }
      recordSuccess("kalshi-api");
      const data = await r.json().catch(() => ({})) as { order_id?: string; order?: { order_id?: string } };
      orderId = data.order_id ?? data.order?.order_id ?? null;
    } catch (err) {
      recordFailure("kalshi-api");
      this.log("warn", `Add-to-position ERROR: ${(err as Error).message}`);
      return;
    }

    // GO EXECUTION INTEGRITY BATCH — A1: a 2xx accept is not a fill. This
    // used to increment openTrade.contracts unconditionally right after a
    // successful POST, regardless of whether Kalshi actually filled the
    // order — an unconfirmed or unfilled add would silently inflate the
    // tracked position size (and, on a rejected/expired resting order,
    // create a phantom contract the account never held). Confirm the real
    // fill first; an unconfirmed poll (network failure throughout the
    // window) is treated as "unknown", not as filled, and leaves the
    // position size unchanged.
    if (!orderId) {
      this.log("warn", `⚠️ Add-to-position accepted but no order_id returned — cannot confirm fill; NOT increasing position size.`);
      return;
    }
    // The confirm/don't-confirm branching lives in the pure, independently
    // tested resolveAddFillOutcome() so it can't silently drift.
    const fill    = await this.pollOrderFillStatus(orderId, { attempts: 3, intervalMs: 700, expectedContracts: addContracts });
    const outcome = resolveAddFillOutcome(fill);
    if (outcome === "hold-unconfirmed") {
      this.log("warn",
        `⚠️ Add-to-position order ${orderId} fill UNCONFIRMED after poll (no definitive Kalshi read) — ` +
        `cancelling and leaving position size unchanged.`);
      const cancelPath = kalshiEventsOrderPath(orderId);
      await fetch(`${KALSHI_API_DOMAIN}${cancelPath}`, {
        method: "DELETE",
        headers: { ...await kalshiAuthHeaders("DELETE", cancelPath), Accept: "application/json" },
        signal:  AbortSignal.timeout(4_000),
      }).catch(() => {});
      return;
    }
    if (outcome === "hold-unfilled") {
      this.log("info", `Add-to-position order ${orderId} did not fill (status=${fill.status}) — position size unchanged.`);
      return;
    }

    // Update the open trade record — only now that a real fill is confirmed.
    // Re-average the cost basis with the confirmed fill price (see paper branch).
    this.openTrade.entryPriceCents = blendedEntryPriceCents(
      this.openTrade.entryPriceCents, this.openTrade.contracts, fill.avgPriceCents ?? addPrice, addContracts,
    );
    this.openTrade.contracts    += addContracts;
    this.openTrade.addedContracts = true;

    this.log("order",
      `➕ ADDED 1 contract (confirmed fill @ ${fill.avgPriceCents ?? addPrice}¢) · ` +
      `now ${this.openTrade.contracts}× ${trade.side.toUpperCase()} @ ${addPrice}¢`);
    void persistDecisionTrace({
      traceId: addTraceId, ts: Date.now(), ticker: trade.ticker, side: trade.side,
      contracts: this.openTrade.contracts, ask: fill.avgPriceCents ?? addPrice, outcome: "ORDER",
      regime: getRegime(), regimeHeldBy: getRegimeHeldBy() ?? undefined,
      chain: ["ADD_TO_POSITION", "live", "fill_confirmed"], botTradeId: trade.dbId ?? undefined,
    });
  }

