> **Multi-user accounts (feature/multi-user-accounts):** the API is now default-deny behind per-user sessions.
> `BOT_API_KEY` login and `DESK_ADMIN_TOKEN` are superseded. New env: `ORACLE_ADMIN_USERNAME` / `ORACLE_ADMIN_EMAIL` /
> `ORACLE_ADMIN_PASSWORD` (first boot only), `ORACLE_SESSION_TTL_HOURS`, `ORACLE_SESSION_IDLE_MINUTES`,
> `ORACLE_LOGIN_MAX_*`, `ORACLE_TRUSTED_ORIGINS`, `ORACLE_SERVICE_TOKEN` (off by default), `ORACLE_ACCOUNTS_BACKUP_SCHEMA`.
> See [docs/accounts/ACCOUNTS.md](docs/accounts/ACCOUNTS.md) before deploying.

# DEPLOY_NOTES — unify/sep19-desk-plus-fixes

## Verification (final run, 2026-09-24 ~21:45 ET)
- **API tests** (`pnpm run test`, apps/api-server, Postgres 17 test DB): **3596 tests, 3093 pass, 0 fail, 503 skipped**. The total/skip count moves ±40 between runs because some suites generate cases dynamically; failures were 0 on the last three runs after the two flake fixes.
  Baseline, the Sep 19 handoff on the same box: 3320 tests, 2848 pass, **15 fail**, 457 skipped.
- **Dashboard tests** (vitest): **54 files, 332 tests, all pass**. Baseline was 310.
- **Typecheck:**
  - `pnpm run typecheck:libs`: clean.
  - Dashboard `tsc --noEmit`: **0** errors (was 16).
  - API `tsc --noEmit`: **306** (was 349). What's left is strictness only; see Open items. The Docker build does not gate on API tsc, same as before.
- **Build:** `SKIP_BUILD_TESTS=1 pnpm build` succeeds (API esbuild bundle + Vite). There is no Docker daemon on the build box, so the image is built by the Fly remote builder from the unchanged Dockerfile.
- **Local boot smoke** (production bundle, `NODE_ENV=production`, throwaway DB `kalshi_smoke` and config at `/tmp/smoke`, port 18080):
  - Of 59 frontend GET routes, 55 returned 200.
  - The other 4 are expected locally: `/api/kalshi/balance`, `/markets` and `/live-market` return 503 because there are no Kalshi credentials locally, and `/api/kalshi/api-key` returns 404 on GET because the UI uses POST.
  - Timings: `/backtest/snapshot` 0.15 s (was >60 s), `/agent/models` 3 ms, `/aria-lessons` 1 ms, `/backtest/scenarios` 5.2 s (8.3 MB, see Open items).
  - `GET /backtest/tick-sim` returns 405.
  - `paperMode` is true and the paper balance is 31300.
- **Headless Chrome:** 14 pages, each at desktop and at 390 px phone width (28 loads). No error boundary and no horizontal overflow. The only console/API errors are the local `/api/kalshi/balance` 503.
- **`/bot/stream` bytes over 12 s:** legacy 1.10 MB; with deltas 353 KB (~3× less), and phones use a 2 s interval on top of that.

## Deploy
```
cd <repo> && flyctl deploy -a kalshi-oracle-desk      # fly.toml keeps [mounts] desk_data -> /app/apps/api-server/data
```
- Do **not** set `DESK_ADMIN_TOKEN` unless you want the admin prompt. The default (unset) keeps today's behaviour.
- `.bot-config.json` is not on the volume, so every deploy regenerates it from defaults plus the env. This matches v11 behaviour, and paperMode stays true.
- Rollback: `flyctl deploy -a kalshi-oracle-desk --image registry.fly.io/kalshi-oracle-desk:deployment-01M2XKQ9BM2SVGVBK1ZNTJA422` (v11).

## New / relevant env vars
| Var | Default | Notes |
|---|---|---|
| `DESK_ADMIN_TOKEN` | unset | Opt-in auth on non-GET `/api/*`. The UI prompts once and stores the token in localStorage. |
| `GROQ_BASE_URL` / `GROQ_MODELS` | Groq OpenAI endpoint / `openai/gpt-oss-120b,openai/gpt-oss-20b` | Uses the existing `GROQ_API_KEY`. |
| `GEMINI_OPENAI_BASE_URL` / `GEMINI_MODELS` | Google OpenAI-compatible endpoint / `gemini-flash-latest,gemini-flash-lite-latest` | Uses the existing `GEMINI_API_KEY`. |
| `AI_INTEGRATIONS_OPENROUTER_API_KEY` / `..._BASE_URL` | already on Fly | The account currently returns HTTP 402 (no credits). |

## Entry diagnosis (Fly, since the 20:37 ET restart)
No new paper trades. Every evaluate decision in the trace is SKIP, counted from 00:38Z (20:38 ET) onward in `evaluate-decision-trace.jsonl`:

| Skip reason | Count | What it means |
|---|---|---|
| FROZEN_TIME_WINDOW | 4740 | The frozen-CC entry path only trades with 180–780 s left |
| TIME_GATE | 2166 | Last 60 s, no new take |
| STALE_QUOTE | 786 | |
| FROZEN_ALIGNED_SKIP | 63 | |
| FEED_UNAVAILABLE | 7 | |
| PRICE_BUFFER_WARMUP | 6 | |

**Inside the window,** CONFLUENCE_CASCADE fired (for example 21:00 ET contract: YES ask 45¢, pWin 0.545, EV 5.5¢, which clears the 3¢ floor) but `alignedTakeGate` returned SKIP. The logged reason is almost always `mtf_sign_null`: 192 of 193 aligned-gate skips in `meta-examples.jsonl`, the other being `still_mid_unclear`. In other words, the multi-timeframe sign was null, so the gate cannot pick a side. No floors were loosened.

## Follow-up (2026-09-24 22:35 ET, Fly v13): `mtf_sign_null` root cause
- **The MTF feed is not empty.** Live `mtfBias` has all of 1m/5m/15m/1h/4h populated from fresh candles (`usedStaleFastCache:false`, updated within 30 s, score ranging -4..+4).
- `alignedTakeGate` returns `mtf_sign_null` only when the weighted composite is exactly **0**. All 193 `mtf_sign_null` meta-examples on the volume have `mtfScore:0` with conflicting legs (e.g. m1 -2 / m15 +2). That is a genuinely flat sign, and the gate is right to refuse it (no code change, no fabricated sign).
- Since the v12 deploy there are **0** FROZEN_ALIGNED_SKIPs.
- **The real blocker after the gate:** `placeOrder` → `decideFrozenCcMindBind` → captain **HEAVE_TO** (`MIND_HEAVE_BIND`: "calibration unreliable ECE; MISSING_INPUTS=book_depth; thin_book").
  - Mind calibration has `n=0`. It needs ≥30 settled trades with ECE ≤ 0.08, and only settled trades feed it. That makes it a paper-desk deadlock: no trades means no calibration, and no calibration means heave.
  - `book_depth` is hard-coded unknown in brain-center (`depthKnown:false`, `thinBook:true`).
  - These are doctrine gates, deliberately **not loosened**; see open item 1.
- **Real bug fixed (v13):** mind-calibration, brain-episodes, scar-echo, lag-proof and organ-debug files resolved their paths relative to `import.meta.url`. Inside the esbuild bundle that meant `/app/data` or `/app/apps/data`, which is **off the volume**, so every deploy/restart wiped them (calibration could never accumulate even with trades). They now use `deskDataDir()` = `cwd/data` (the volume; `DESK_DATA_DIR` overrides). Test: `desk-data-dir.test.ts` (3). Live: `/app/data` is gone and organ-debug writes to the volume.

## Shadow calibration + real book depth (2026-09-24 ~23:35 ET, Fly v15)

- **Shadow calibration** (`organs/shadow-calibration.ts`, `shadow-calibration-sweep.ts`): when the
  mind/captain bind BLOCKS a take at placeOrder, a pending shadow row (ticker, side, p =
  strategyWinRate, entry ask, ts, `source:"shadow"`, block stamp, brain depth stamp) is written to
  `data/mind-calibration-shadow.jsonl`. Dedupe: one per market+side+15m window. A 60 s sweep (public
  `GET /markets/{ticker}`, off the tick path, no auth/orders/LLM) resolves it after close+60 s and
  appends `{p, hit, source:"shadow"}` to `data/mind-calibration.jsonl`. Reliability rule unchanged
  (n ≥ 30 AND ECE ≤ 0.08). Shadows never touch positions, balance or trade counts. Healthz
  `subsystems.calib` now has `nFill`, `nShadow`, `shadow{pending,resolved,hits,expired,deduped}`.
  Verified on Fly: 23:18 ET HEAVE block → pending (KXBTC15M-26SEP242330-30 NO p=0.52 @39¢), survived
  the v15 restart, resolved 23:31 ET (result NO, hit) → calib n=1 (nShadow=1); balance $313.00.
- **Real depth** (`organs/book-depth-stamp.ts`): brain `depthKnown`/`thinBook` now come from
  `kalshiWS.getLatestOrderbook()` — contracts executable on the side taken at ≤ ask+1¢.
  Thin = depth < max(10, 2 × floor(0.09 × balance / ask)) (2× because depth sizing takes ≤ 50% of the
  visible book). Fail safe → `depthKnown:false` (thin default kept) when the snapshot is missing,
  wrong-ticker, > 30 s old, empty, has no side/ask, or its top disagrees with a fresher live WS
  quote (`checkOrderbookConsistency`). Report field `brainCenter.bookDepth` on `/api/bot/status`.
- **Open:** the L2 snapshot on Fly is usually inconsistent with the WS quote (e.g. book 11/12¢ vs
  quote 51/52¢), so depth is mostly UNKNOWN until the L2 capture is fixed.

## Open items (ranked)
0. **Paper desk cannot trade under frozenCc until you choose a calibration policy.** Options:
   - (a) record shadow calibration observations (p vs actual settlement) for gate-passing takes the captain heaved;
   - (b) seed calibration from historical settled trades;
   - (c) exempt paper mode from the calibration heave.
   Also wire real L2 depth into brain-center instead of `depthKnown:false`. All of these change gate behaviour: your decision.
1. **Entries blocked by `mtf_sign_null`** in `alignedTakeGate` (see above). Investigate why the MTF sign is null on the desk; do not loosen floors.
2. **OpenRouter out of credits (402).** Top it up and rotate the key that was pasted in chat. Groq/Gemini legs cover settlement AI meanwhile.
3. **Paper-only lock removed the LIVE REAL MONEY unlock.** This was deliberate; reverting it is your decision.
4. **`DESK_ADMIN_TOKEN` / real auth:** your decision. It is not set on Fly.
5. `/backtest/scenarios`: 8.3 MB payload and ~5 s of synchronous CPU on a cold compute (cached 15 min afterwards). Needs a worker thread, trimming, or gzip.
6. Fly volume: `evaluate-decision-trace.jsonl` is 305 MB and `regime-decision-trace.jsonl` 74 MB on the 1 GB volume. Needs rotation.
7. API tsc: 306 strictness errors (61 `noImplicitReturns`, nullability, test typings). The dead file `leftover-live-settlement-funnel.ts` is still there.
8. `/healthz` still writes incidents on GET.
9. The settlement predictor's lastSettleTicker was stale in the earlier live check; re-verify after deploy.
10. Deferred: GE_013 ledger boot check, the GE_001 settle-null hunk, and wiring the manual-exchange control boundary into routes.
11. The `/agent/models` chat catalog does not list OpenRouter (unchanged by design).
12. **Corrected (round 2, 2026-09-25):** the earlier note here said the Sep 19 orphan's Kalshi outcome was YES. That was wrong. Trade #72 (KXBTC15M-26SEP191130-30, YES 18@37¢) settled **NO** (Kalshi public API: status=finalized, result=no, expiration_value 81554.02 vs floor_strike 81689.73). With operator approval it was re-booked from `ORPHAN_OPEN_CLEARED_VOID` (0 P&L) to a settled NO loss via the D5 math: gross −666¢, fee 30¢, **−696¢**. The paper balance moves $313.00 → **$306.04**. Rows were backed up first to `data/backups/r2-trade72-2026-09-25T05-07-57-613Z/`, and an audit record was written to `data/audit/ledger-corrections.jsonl`. The tape got an appended `ORPHAN_SETTLED_KALSHI` close; `selectBestTapeClose` now lets that close supersede the earlier void.

## Sep 24 loose-ends pass — operator knobs

- **Desk passcode lock**: Fly secret `DESK_ADMIN_TOKEN` (never commit/echo). When set, all `/api`
  routes need the `desk_session` cookie (POST `/api/auth/login {passcode}`, 5 tries/min/IP) or
  `Authorization: Bearer <passcode|session>`. Open: `/api/healthz`, `/api/public/status`, `/api/auth/*`.
  Rotate the secret to revoke every session.
- **Build identity**: `flyctl deploy --build-arg GIT_SHA=$(git rev-parse --short=12 HEAD)`.
- **Mind calibration versioning**: each record carries `gitSha` + `modelVersion`.
  `MIND_CALIBRATION_MODEL_VERSION` (default `frozen-cc-v1`) = current tag; bump it when the p model
  changes. `MIND_CALIBRATION_VERSION_SCOPE` = `model` (default: reliability n≥30 & ECE≤0.08 counts only
  the current modelVersion) | `gitSha` | `all` (legacy). Untagged legacy rows don't count under model/gitSha.
- **Organ-debug on Fly**: loads organs from the bundle; unit tests are skipped in production
  (`ORGAN_DEBUG_UNIT_TESTS=1` to opt in — they would share the live DB).
- **Trace rotation**: evaluate trace capped 50MB, regime trace 20MB; archives gzipped, keep 3 / 14 days.

## Round 2 (2026-09-25) — D10/D12/D13 + in-app chat agent

- **D10** proactive rollover: at `close_time` the desk derives the next KXBTC15M ticker and adopts it as soon as Kalshi reports it `active` with a strike (no wait for the `status=open` list, which lagged ~30 s). The 180 s entry rule is unchanged.
- **D12** equity band: reduce-only ceiling `floor(equity × pct / entry)` with pct 2–4 % (EV-scaled), never above the 9 % cap or the Kelly size.
- **D13** exact fees: the EV gate charges `kalshiTakerFeeCents(P, C) / C` for the real order size C; EV floor 3¢ unchanged.
- **Chat agent** (`lib/chat-router.ts`, `lib/chat-desk-tools.ts`, `lib/chat-pr.ts`, `lib/chat-agent.ts`): free-model router (Groq gpt-oss-120b → Gemini 3.6-flash → Groq qwen3.8-27b → Gemini 3.5-flash → Groq gpt-oss-20b; OpenRouter `:free` only if a key exists), per-model cooldowns (402 → provider 30 min, 429 honours Retry-After, quota 1 h, 404 6 h), one backoff retry, 30 s timeouts, ~3.8k-token context budget, specific user-facing errors. Read-only desk tools + log tail + code search/read. Conversations restore from `chat_messages` after restarts.
  - `CHAT_PR_GITHUB_TOKEN` (optional, **not set on Fly by default**): fine-grained token with `contents:write` + `pull_requests:write` on the target repo. With it, `propose_fix` opens a **draft** PR on a new `chat/<slug>-<ts>` branch (never master, never merged, never deployed; 1 per 10 min). Without it, the tool returns the validated patch only.
  - `CHAT_PR_REPO` (default `stellarmoonin123/Kalshi-oracle`), `CHAT_PR_BASE` (default `master`).
  - Patches touching hard-lock files/params (EV/Kelly/band/reserve/caps/paperMode/organ locks, hard-locks tests) are always denied. Targeted tests run in a temp copy of the tree first; on Fly the image ships no test files, so it reports "no targeted tests" and PR mode still requires the patch to apply cleanly.
  - Provider responses are not token-streamed (the SSE route chunks the finished answer, as before).
