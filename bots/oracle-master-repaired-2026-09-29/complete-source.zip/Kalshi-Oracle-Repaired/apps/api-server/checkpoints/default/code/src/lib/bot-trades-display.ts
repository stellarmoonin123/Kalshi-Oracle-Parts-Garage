/**
 * bot-trades-display.ts
 *
 * Display-only mapping for GET /bot/trades: attach Kalshi YES/NO settle
 * (official / paper-bar-tape / BTC close vs floor) and a rebuilt story.
 * Never infers expiry YES/NO from paper W/L when a real settle exists.
 * Never paperMode false. Never ENABLE. Never cuts EV/Kelly.
 */
import fs from "node:fs";
import path from "node:path";

import { kalshiSettleFromTruth, type KalshiYesNo } from "./kalshi-settle-label.js";
import { buildTradeStory, settlementPhrase, type TradeStory } from "./trade-story.js";
import { sanitizeTheoCents } from "./brti-theo-sanity.js";

export const LIVE_APPLY = false as const;
export const PAPER_MODE = true as const;


function dataPath(file: string, envKey: string): string {
  if (process.env[envKey]) return path.resolve(process.env[envKey]!);
  return path.resolve(process.cwd(), "data", file);
}

function settlementJsonlPath(): string {
  if (process.env.SETTLEMENT_JSONL_PATH) return process.env.SETTLEMENT_JSONL_PATH;
  const cwd = process.cwd().replace(/\\/g, "/");
  if (cwd.includes("apps/api-server")) {
    return path.resolve(process.cwd(), "../../research/settlement-directions.jsonl");
  }
  return path.resolve(process.cwd(), "research/settlement-directions.jsonl");
}

const PERIOD_MS = 15 * 60_000;

export { kxbtc15mCloseUtcIso } from "./kxbtc15m-ticker.js";
import { kxbtc15mCloseUtcIso } from "./kxbtc15m-ticker.js";

/**
 * D6 — PERIOD-START key (UTC ISO) for a KXBTC15M ticker, matching
 * btc_periods / settlement-directions (keyed by period start,
 * period-recorder.ts). The ticker hhmm is the CLOSE, so start = close − 15m.
 * (Before D6 this returned the close time → looked up the NEXT contract's
 * result: 191130 showed 191145's YES while Kalshi said NO.)
 */
export function kxbct15mPeriodUtcIso(
  ticker: string | null | undefined,
  closeTimeUtc?: string | Date | null,
): string | null {
  const close = kxbtc15mCloseUtcIso(ticker, closeTimeUtc);
  if (!close) return null;
  return new Date(Date.parse(close) - PERIOD_MS).toISOString();
}

function readJsonl(file: string): Record<string, unknown>[] {
  try {
    if (!fs.existsSync(file)) return [];
    const out: Record<string, unknown>[] = [];
    for (const line of fs.readFileSync(file, "utf8").split("\n")) {
      if (!line.trim()) continue;
      try {
        const o = JSON.parse(line) as unknown;
        if (o && typeof o === "object") out.push(o as Record<string, unknown>);
      } catch { /* skip */ }
    }
    return out;
  } catch {
    return [];
  }
}

function asYesNo(v: unknown): KalshiYesNo | null {
  const s = String(v ?? "").trim().toUpperCase();
  if (s === "YES" || s === "NO") return s;
  return null;
}

/**
 * Where the displayed settle side came from (settlement audit Sep 25). The
 * `officialKalshi` display field is filled from the same lookup, which for
 * sold-early paper trades is the desk's own BTC-close-vs-strike recorder, not
 * a Kalshi API read. Expose the basis so the UI/exports never overstate it.
 */
export type SettledSource = "row" | "paper_bar_tape" | "period_recorder" | null;

export type DirSettle = { btcClose: number; floorStrike: number; settledSide: KalshiYesNo };

export function dirSettleFromRow(row: Record<string, unknown>): DirSettle | null {
  const floor = typeof row.floorStrike === "number" ? row.floorStrike : null;
  const px = typeof row.settledPrice === "number" ? row.settledPrice : null;
  const yn = kalshiSettleFromTruth({
    officialKalshi: null,
    btcClose: px,
    floorStrike: floor,
  });
  if (!yn || px == null || floor == null) return null;
  return { btcClose: px, floorStrike: floor, settledSide: yn };
}

type TapeIndex = {
  settleByTicker: Map<string, KalshiYesNo>;
  storyByTradeId: Map<number, TradeStory>;
  dirByPeriod: Map<string, DirSettle>;
};

let cached: { tape: TapeIndex; at: number } | null = null;
const CACHE_MS = 5_000;

export function loadSettleTapeIndex(force = false): TapeIndex {
  const now = Date.now();
  if (!force && cached && now - cached.at < CACHE_MS) return cached.tape;
  const settleByTicker = new Map<string, KalshiYesNo>();
  for (const row of readJsonl(dataPath("paper-bar-tape.jsonl", "PAPER_BAR_TAPE_PATH"))) {
    const ticker = typeof row.ticker === "string" ? row.ticker : null;
    const yn = asYesNo(row.kalshiSettle);
    if (ticker && yn) settleByTicker.set(ticker, yn);
  }
  const storyByTradeId = new Map<number, TradeStory>();
  for (const row of readJsonl(dataPath("trade-stories.jsonl", "TRADE_STORY_JSONL_PATH"))) {
    const id = typeof row.tradeId === "number" ? row.tradeId : null;
    const story = row.story as TradeStory | undefined;
    if (id != null && story && typeof story === "object") storyByTradeId.set(id, story);
  }
  const dirByPeriod = new Map<string, DirSettle>();
  for (const row of readJsonl(settlementJsonlPath())) {
    if (typeof row.periodTime !== "string") continue;
    const d = dirSettleFromRow(row);
    if (d) dirByPeriod.set(row.periodTime, d);
  }
  const tape = { settleByTicker, storyByTradeId, dirByPeriod };
  cached = { tape, at: now };
  return tape;
}

export function lookupKalshiSettleForTrade(
  trade: {
    ticker?: string | null;
    floorStrike?: number | null;
    settledSide?: string | null;
    officialKalshi?: string | null;
    btcClose?: number | null;
    /** D11 — Kalshi UTC close_time when known (preferred over ET ticker text). */
    closeTime?: string | Date | null;
  },
  tape: TapeIndex = loadSettleTapeIndex(),
): { settledSide: KalshiYesNo | null; btcClose: number | null; floorStrike: number | null; settledSource: SettledSource } {
  const official = kalshiSettleFromTruth({
    officialKalshi: trade.officialKalshi ?? trade.settledSide,
    btcClose: trade.btcClose ?? null,
    floorStrike: trade.floorStrike ?? null,
  });
  const fromTape = trade.ticker ? tape.settleByTicker.get(trade.ticker) ?? null : null;
  const period = kxbct15mPeriodUtcIso(trade.ticker ?? null, trade.closeTime ?? null);
  const dir = period ? tape.dirByPeriod.get(period) ?? null : null;
  const settledSide = official ?? fromTape ?? dir?.settledSide ?? null;
  const btcClose = trade.btcClose ?? dir?.btcClose ?? null;
  const floorStrike = trade.floorStrike ?? dir?.floorStrike ?? null;
  const settledSource: SettledSource = official ? "row" : fromTape ? "paper_bar_tape" : dir ? "period_recorder" : null;
  return { settledSide, btcClose, floorStrike, settledSource };
}

export function isPaperTradeRow(t: { orderId?: string | null; isPaper?: boolean | null }): boolean {
  if (t.isPaper === true) return true;
  return typeof t.orderId === "string" && t.orderId.startsWith("paper-");
}


/** Latest FILL entryTheoCents by ticker from frozen-cc-ledger (observe only). */
export function loadFrozenEntryTheoByTicker(): Map<string, { entryTheoCents: number | null; entryTheoMissing: boolean }> {
  const map = new Map<string, { entryTheoCents: number | null; entryTheoMissing: boolean }>();
  const file = dataPath("frozen-cc-ledger.jsonl", "FROZEN_CC_LEDGER_PATH");
  // Single pass: FILL authoritative; CLOSE-propagated entryTheo backfills gaps only.
  for (const row of readJsonl(file)) {
    if (row.kind !== "FILL" && row.kind !== "CLOSE") continue;
    const ticker = typeof row.ticker === "string" ? row.ticker : null;
    if (!ticker) continue;
    const s = sanitizeTheoCents(
      typeof row.entryTheoCents === "number" ? row.entryTheoCents : null,
    );
    const next = {
      entryTheoCents: s.theoCents,
      entryTheoMissing: s.theoMissing || row.entryTheoMissing === true || s.theoCents == null,
    };
    const prev = map.get(ticker);
    if (row.kind === "FILL") {
      map.set(ticker, next);
      continue;
    }
    if (!prev || prev.entryTheoCents == null || prev.entryTheoMissing) {
      if (next.entryTheoCents != null && !next.entryTheoMissing) map.set(ticker, next);
    }
  }
  return map;
}

export function enrichBotTradesForDisplay<T extends Record<string, unknown>>(trades: T[]): T[] {
  const tape = loadSettleTapeIndex();
  const theoByTicker = loadFrozenEntryTheoByTicker();
  return trades.map((raw) => {
    const t = raw as T & {
      id?: number;
      ticker?: string;
      floorStrike?: number | null;
      settledSide?: string | null;
      officialKalshi?: string | null;
      btcClose?: number | null;
      story?: TradeStory | null;
      entryTheoCents?: unknown;
    };
    const looked = lookupKalshiSettleForTrade(t, tape);
    const persisted = t.id != null ? tape.storyByTradeId.get(t.id) : undefined;
    const storyInput = {
      fillOrigin: (t.fillOrigin as string | null) ?? "bot",
      strategyId: (t.strategyId as string | null) ?? null,
      side: String(t.side ?? "yes"),
      signal: (t.signal as string | null) ?? null,
      outcome: (t.outcome as string | null) ?? null,
      pnlCents: (t.pnlCents as number | null) ?? null,
      entryPriceCents: (t.entryPriceCents as number | null) ?? null,
      ask: (t.entryPriceCents as number | null) ?? null,
      exitMktPrice: (t.exitMktPrice as number | null) ?? null,
      confidence: (t.confidence as number | null) ?? null,
      entryReason: (t.entryReason as string | null) ?? null,
      exitReason: (t.exitReason as string | null) ?? null,
      exitReasonText: (t.exitReasonText as string | null) ?? null,
      ticker: t.ticker ?? null,
      contracts: (t.contractsFilled as number | null) ?? (t.contracts as number | null) ?? null,
      filledAt: (t.filledAt as string | null) ?? null,
      settledAt: (t.settledAt as string | null) ?? null,
      createdAt: (t.createdAt as string | null) ?? null,
      cancelledAt: (t.cancelledAt as string | null) ?? null,
      orderPlacedAt: (t.orderPlacedAt as string | null) ?? null,
      expectedPnlCents: (t.expectedPnlCents as number | null) ?? null,
      evCents: (t.expectedPnlCents as number | null) ?? (t.entryExpectedRewardCents as number | null) ?? null,
      p: (t.strategyWinRateAtEntry as number | null) ?? (t.winRateAtPrice as number | null) ?? null,
      winRateAtPrice: (t.strategyWinRateAtEntry as number | null) ?? (t.winRateAtPrice as number | null) ?? null,
      mtf: (t.mtfScoreAtEntry as number | null) ?? null,
      // Never invent valid/river from pathRide or strategyId name — prefer
      // jsonl story stamped at close (exit thesis / riverValid).
      valid: null,
      river: null,
      feeNetCents: (t.pnlCents as number | null) ?? null,
      exitReasonCode: (t.exitReason as string | null) ?? null,
      contractDurationMins: (t.contractDurationMins as number | null) ?? null,
      settledSide: looked.settledSide,
      officialKalshi: looked.settledSide,
      btcClose: looked.btcClose,
      floorStrike: looked.floorStrike,
    };
    // Carry exit-path valid/river from persisted close stamp into rebuild input
    // so settlement honesty rebuild does not wipe teaching fields.
    if (persisted) {
      if (typeof persisted.valid === "boolean") (storyInput as { valid: boolean | null }).valid = persisted.valid;
      if (typeof persisted.river === "boolean") (storyInput as { river: boolean | null }).river = persisted.river;
    }
    const rebuilt = buildTradeStory(storyInput);
    // Persisted close story carries real thesisStatus/riverValid; rebuild alone cannot.
    // But early-exit jsonl often stamps settlement "unknown" before Kalshi resolves —
    // once looked.settledSide is YES/NO, prefer rebuild settlement / whatHappened so
    // Settled YES + LOSS (early dump) never reads as "Kalshi unset".
    const story = mergePersistedStoryWithKnownSettle(persisted, rebuilt, t.story ?? null, looked.settledSide);
    const fromRowSan = sanitizeTheoCents(
      typeof t.entryTheoCents === "number" ? t.entryTheoCents : null,
    );
    const fromLedger = t.ticker ? theoByTicker.get(t.ticker) : undefined;
    const entryTheoCents = !fromRowSan.theoMissing
      ? fromRowSan.theoCents
      : (fromLedger?.entryTheoCents ?? null);
    const entryTheoMissing = !fromRowSan.theoMissing
      ? false
      : (fromLedger?.entryTheoMissing ?? (entryTheoCents == null));
    return {
      ...t,
      settledSide: looked.settledSide,
      officialKalshi: looked.settledSide,
      settledSource: looked.settledSource,
      btcClose: looked.btcClose,
      floorStrike: looked.floorStrike,
      entryTheoCents,
      entryTheoMissing,
      story,
    };
  });
}

/**
 * Rebuild settle clause via settlementPhrase.
 * Early exits + known Kalshi: "sold early · settled YES|NO" (both — not sold-early-only).
 * Early exits + unknown: "sold early". Held: "settled YES|NO".
 * Never fake held-only "settled YES|NO" as the sole slot on PATH_RIDE / HARD_STOP dumps.
 */
export function overlayKnownSettleInWhatHappened(
  whatHappened: string | null | undefined,
  known: KalshiYesNo,
  opts?: {
    soldEarly?: boolean;
    holdToSettlement?: boolean | null;
    exitReason?: string | null;
    outcome?: string | null;
    pnlCents?: number | null;
  },
): string {
  const phrase = settlementPhrase({
    settlement: known,
    soldEarly: opts?.soldEarly,
    holdToSettlement: opts?.holdToSettlement,
    exitReason: opts?.exitReason,
    outcome: opts?.outcome,
    pnlCents: opts?.pnlCents,
  });
  if (typeof whatHappened !== "string" || !whatHappened.trim()) return phrase;
  // Template slot: `), <settlePhrase>, WIN|LOSS|...`
  const slotted = whatHappened.replace(
    /(\)\s*,\s*)(?:sold early\s*·\s*settled\s+(?:YES|NO)|settled\s+(?:YES|NO|unknown)|closed\s*·\s*Kalshi\s+unset|Kalshi\s+unset|unsettle\/unknown|sold early|pending|orphan|closed)(\s*,\s*(?:WIN|LOSS|OPEN|ORPHAN|SKIP_N\/A))/i,
    `$1${phrase}$2`,
  );
  if (slotted !== whatHappened) return slotted;
  // Legacy unset tokens only — never rewrite the how-clause "sold early (Ns)".
  let out = whatHappened
    .replace(/closed\s*·\s*Kalshi\s+unset/gi, phrase)
    .replace(/Kalshi\s+unset/gi, phrase)
    .replace(/unsettle\/unknown/gi, phrase)
    .replace(/settled\s+unknown/gi, phrase);
  // Scrub fake held settle painted onto early exits.
  if (opts?.soldEarly === true || opts?.holdToSettlement === false) {
    out = out.replace(/,\s*settled\s+(?:YES|NO)\s*,/gi, `, ${phrase},`);
  }
  return out;
}

/**
 * Prefer persisted teaching fields (valid/river/lessons); overlay Kalshi YES/NO
 * once known. Early exits: settle slot is "sold early · settled YES|NO" when known
 * (never sold-early-only when Kalshi known; never held-only settled as sole slot).
 * Held-to-expiry: settlementPhrase paints settled YES|NO. W/L for early exits stays PnL.
 */
export function mergePersistedStoryWithKnownSettle(
  persisted: TradeStory | null | undefined,
  rebuilt: TradeStory | null | undefined,
  fallback: TradeStory | null | undefined,
  settledSide: KalshiYesNo | null,
): TradeStory | null {
  const base = persisted ?? rebuilt ?? fallback ?? null;
  if (!base) return null;
  const known = settledSide === "YES" || settledSide === "NO" ? settledSide : null;
  const early = base.soldEarly === true || base.holdToSettlement === false;
  const hold = base.holdToSettlement === true;
  if (!known) {
    // Display honesty while settle still unknown: never leave "Kalshi unset"
    // (reads like still open). "sold early" is correct for closed early exits.
    if (typeof base.whatHappened === "string" && /Kalshi unset|unsettle\/unknown/i.test(base.whatHappened)) {
      return {
        ...base,
        whatHappened: base.whatHappened
          .replace(/closed · Kalshi unset/gi, "sold early")
          .replace(/Kalshi unset/gi, "sold early")
          .replace(/unsettle\/unknown/gi, "sold early"),
      };
    }
    return base;
  }
  const overlayOpts = {
    soldEarly: early,
    holdToSettlement: hold,
    exitReason: base.exitReasonCode ?? base.exitReason ?? null,
    outcome: base.result === "WIN" ? "win" : base.result === "LOSS" ? "loss" : null,
    pnlCents: base.pnlCents,
  };
  // Early exit: paint "sold early · settled YES|NO"; stamp settlement + officialSettle.
  if (early && !hold) {
    const src = rebuilt ?? base;
    return {
      ...src,
      valid: typeof persisted?.valid === "boolean" ? persisted.valid : src.valid,
      river: typeof persisted?.river === "boolean" ? persisted.river : src.river,
      wentRight: persisted?.wentRight ?? src.wentRight,
      wentWrong: persisted?.wentWrong ?? src.wentWrong,
      lessons: persisted?.lessons ?? src.lessons,
      counterfactual: persisted?.counterfactual ?? src.counterfactual,
      soldEarly: true,
      holdToSettlement: false,
      officialSettle: known,
      // Market settle always visible when known (phrase + settlement field).
      settlement: known,
      whatHappened: overlayKnownSettleInWhatHappened(src.whatHappened ?? base.whatHappened, known, overlayOpts),
    };
  }
  const baseSettle = String(base.settlement ?? "").toUpperCase();
  if (baseSettle === "YES" || baseSettle === "NO") {
    // Already honest held settle — keep persisted teaching over rebuild.
    return base;
  }
  // Unknown at close time; Kalshi now known — prefer rebuild settle phrase (held).
  if (rebuilt) {
    const rebuiltKnown =
      rebuilt.settlement === "YES" || rebuilt.settlement === "NO" ? rebuilt.settlement : known;
    const whatFromRebuild =
      rebuilt.settlement === "YES" || rebuilt.settlement === "NO"
        ? rebuilt.whatHappened
        : overlayKnownSettleInWhatHappened(rebuilt.whatHappened ?? base.whatHappened, known, overlayOpts);
    return {
      ...rebuilt,
      valid: typeof persisted?.valid === "boolean" ? persisted.valid : rebuilt.valid,
      river: typeof persisted?.river === "boolean" ? persisted.river : rebuilt.river,
      wentRight: persisted?.wentRight ?? rebuilt.wentRight,
      wentWrong: persisted?.wentWrong ?? rebuilt.wentWrong,
      lessons: persisted?.lessons ?? rebuilt.lessons,
      counterfactual: persisted?.counterfactual ?? rebuilt.counterfactual,
      settlement: rebuiltKnown,
      officialSettle:
        rebuilt.officialSettle === "YES" || rebuilt.officialSettle === "NO"
          ? rebuilt.officialSettle
          : rebuiltKnown,
      whatHappened: whatFromRebuild,
    };
  }
  return {
    ...base,
    settlement: known,
    officialSettle: known,
    whatHappened: overlayKnownSettleInWhatHappened(base.whatHappened, known, overlayOpts),
  };
}
