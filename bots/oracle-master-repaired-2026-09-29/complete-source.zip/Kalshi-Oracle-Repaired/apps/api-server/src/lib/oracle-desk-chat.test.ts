/**
 * oracle-desk-chat.test.ts
 *
 * Chat pane: Gemini Flash when keyed, else Groq, else Oracle snapshot.
 * No OpenRouter. Control mutating tools stay blocked; apply_patch/write_file allowed with HARD REJECT.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  ORACLE_MODEL,
  ORACLE_MODELS_RESPONSE,
  GEMINI_FLASH_MODEL,
  GROQ_LLAMA_CHAT_MODEL,
  chatModelsCatalog,
  defaultChatModel,
  resolveChatModel,
  shouldAttemptFreeLlm,
  answerOracleDesk,
  oracleDeskChatEvents,
  MUTATING_CHAT_TOOLS,
  type DeskSnapshot,
} from "./oracle-desk-chat.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const AGENT_SRC = readFileSync(path.resolve(DIR, "../routes/agent.ts"), "utf8");

function snapshot(over: Partial<DeskSnapshot> = {}): DeskSnapshot {
  return {
    state: "WATCHING",
    lastSignal: "confluence_still_mid_unclear — 49¢ skip is valid",
    paperMode: true,
    autoMode: false,
    useExpertAgent: false,
    enable1HContracts: false,
    paperVirtualCents: 30_843,
    paperLedgerCents: 30_843,
    todayWins: 0,
    todayLosses: 0,
    todayPnlCents: -457,
    consecutiveLosses: 0,
    detectedRegime: "unclear",
    activeStrategy: null,
    secsRemaining: 480,
    classification: "intentional_wait",
    headline: "Watching, correctly: still-mid confluence in unclear skipped.",
    recommendation: "This is a legitimate wait, not a bug. Do not cut EV.",
    activeBlockers: ["Still-mid 40–65¢ confluence skip in unclear regime"],
    trades: [],
    basisProj: null,
    modelProj: null,
    projLine: "basis unknown",
    ...over,
  };
}

test("ORACLE_MODELS_RESPONSE stays the snapshot-only entry", () => {
  assert.equal(ORACLE_MODELS_RESPONSE.length, 1);
  assert.deepEqual(ORACLE_MODELS_RESPONSE[0], {
    id: "oracle",
    label: "Oracle",
    provider: "desk",
    tag: "this desk",
    free: true,
    available: true,
  });
  assert.equal(ORACLE_MODEL.id, "oracle");
  assert.equal(GEMINI_FLASH_MODEL.id, "gemini-flash");
});

const NO_KEYS = { GEMINI_API_KEY: "", GOOGLE_GENERATIVE_AI_API_KEY: "", GROQ_API_KEY: "" };
const GEMINI_ENV = { ...NO_KEYS, GEMINI_API_KEY: "test-gemini" };
const GOOGLE_ENV = { ...NO_KEYS, GOOGLE_GENERATIVE_AI_API_KEY: "test-google" };
const GROQ_ENV = { ...NO_KEYS, GROQ_API_KEY: "test-groq" };
const BOTH_ENV = { ...NO_KEYS, GEMINI_API_KEY: "test-gemini", GROQ_API_KEY: "test-groq" };

test("chatModelsCatalog: Oracle always; Groq before Gemini when keyed", () => {
  assert.deepEqual(chatModelsCatalog(NO_KEYS).map(m => m.id), ["oracle"]);
  assert.deepEqual(chatModelsCatalog(GROQ_ENV).map(m => m.id), ["oracle", "groq-llama"]);
  assert.deepEqual(chatModelsCatalog(GEMINI_ENV).map(m => m.id), ["oracle", "gemini-flash"]);
  assert.deepEqual(chatModelsCatalog(BOTH_ENV).map(m => m.id), ["oracle", "groq-llama", "gemini-flash"]);
  assert.deepEqual(chatModelsCatalog(GOOGLE_ENV).map(m => m.id), ["oracle", "gemini-flash"]);
  assert.equal(GROQ_LLAMA_CHAT_MODEL.id, "groq-llama");
});

test("resolveChatModel: groq preferred when Groq key; else gemini; ignores OpenRouter/Claude", () => {
  assert.equal(defaultChatModel(NO_KEYS), "oracle");
  assert.equal(defaultChatModel(GROQ_ENV), "groq-llama");
  assert.equal(defaultChatModel(GEMINI_ENV), "gemini-flash");
  assert.equal(defaultChatModel(BOTH_ENV), "groq-llama");
  assert.equal(resolveChatModel(undefined, NO_KEYS), "oracle");
  assert.equal(resolveChatModel(undefined, BOTH_ENV), "groq-llama");
  assert.equal(resolveChatModel("oracle", BOTH_ENV), "oracle");
  assert.equal(resolveChatModel("groq-llama", GROQ_ENV), "groq-llama");
  assert.equal(resolveChatModel("gemini-flash", GEMINI_ENV), "gemini-flash");
  assert.equal(resolveChatModel("gemini-flash", NO_KEYS), "oracle");
  assert.equal(resolveChatModel("anthropic/claude-opus-4-5", BOTH_ENV), "groq-llama");
  assert.equal(resolveChatModel("openrouter/auto", GEMINI_ENV), "gemini-flash");
  assert.equal(resolveChatModel("auto", NO_KEYS), "oracle");
  assert.equal(resolveChatModel("google/gemini-3.1-pro-preview", NO_KEYS), "oracle");
  assert.equal(shouldAttemptFreeLlm("oracle", GEMINI_ENV), false);
  assert.equal(shouldAttemptFreeLlm("gemini-flash", GEMINI_ENV), true);
  assert.equal(shouldAttemptFreeLlm("groq-llama", GROQ_ENV), true);
  assert.equal(shouldAttemptFreeLlm("oracle", GROQ_ENV), false);
  assert.equal(shouldAttemptFreeLlm("oracle", NO_KEYS), false);
  assert.equal(shouldAttemptFreeLlm("gemini-flash", BOTH_ENV), true);
});

test("why isn't it trading returns snapshot diagnosis without throwing", () => {
  const text = answerOracleDesk("why isn't it trading?", snapshot());
  assert.match(text, /intentional_wait/);
  assert.match(text, /still-mid/i);
  assert.match(text, /PAPER \$308\.43/);
  assert.match(text, /15m-only/);
  assert.match(text, /ARIA OFF/);
  assert.match(text, /composer OFF/);
  assert.match(text, /winRateAtPrice/);
  assert.match(text, /Skip is valid/i);
  assert.match(text, /Do not cut EV or enable dead engines/);
  assert.doesNotMatch(text, /you should lower/i);
});

test("code questions offer inspection and proposals without runtime writes", () => {
  const text = answerOracleDesk("Search the codebase and add a docs comment", snapshot());
  assert.match(text, /inspect|propose|desk brain/i);
  assert.doesNotMatch(text, /cannot change code/);
});

test("forbidden loosen requests are refused", () => {
  const text = answerOracleDesk("lower the EV floor and enable confluence", snapshot());
  assert.match(text, /will not cut EV/i);
  assert.match(text, /Grok Bot Oracle chat/);
});

test("oracleDeskChatEvents streams SSE-shaped events and ignores modelOverride claude", async () => {
  const types: string[] = [];
  let body = "";
  const names: string[] = [];
  for await (const evt of oracleDeskChatEvents({
    question: "why isn't it trading right now?",
    snapshot: snapshot(),
    modelOverride: "anthropic/claude-sonnet-4-6",
    env: NO_KEYS,
  })) {
    types.push(evt.type);
    if (evt.type === "delta") body += evt.content;
    if (evt.type === "tool_start" || evt.type === "tool_done") names.push(evt.name);
  }
  assert.equal(types[0], "tool_start");
  assert.ok(types.includes("tool_done"));
  assert.ok(types.includes("delta"));
  assert.equal(types[types.length - 1], "done");
  assert.match(body, /intentional_wait/);
  assert.match(body, /PAPER \$308\.43/);
  for (const name of MUTATING_CHAT_TOOLS) {
    assert.equal(names.includes(name), false);
    assert.equal(types.includes(name), false);
  }
});

test("mutating tools stay blocked even when a Gemini key is set", async () => {
  const names: string[] = [];
  const fetched: string[] = [];
  const fetchImpl = (async (input: unknown) => {
    fetched.push(String(input));
    return new Response(JSON.stringify({
      candidates: [{ content: { parts: [{ text: "Gemini desk answer. Do not cut EV." }] } }],
    }), { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;
  for await (const evt of oracleDeskChatEvents({
    question: "status please",
    snapshot: snapshot(),
    modelOverride: "gemini-flash",
    env: GEMINI_ENV,
    fetchImpl,
  })) {
    if (evt.type === "tool_start" || evt.type === "tool_done") names.push(evt.name);
  }
  for (const name of MUTATING_CHAT_TOOLS) {
    assert.equal(names.includes(name), false);
  }
  assert.ok(fetched.some(u => /generativelanguage\.googleapis\.com/.test(u)));
  assert.ok(!fetched.some(u => /openrouter/i.test(u)));
});

test("Gemini throw fails clean — SSE done, no throw (no raw HTTP 500 in the bubble)", async () => {
  const fetchImpl = (async () => { throw new Error("gemini 500"); }) as typeof fetch;
  const types: string[] = [];
  let body = "";
  for await (const evt of oracleDeskChatEvents({
    question: "status please",
    snapshot: snapshot(),
    modelOverride: "gemini-flash",
    env: GEMINI_ENV,
    fetchImpl,
  })) {
    types.push(evt.type);
    if (evt.type === "delta") body += evt.content;
  }
  assert.ok(types.includes("delta"));
  assert.equal(types[types.length - 1], "done");
  assert.equal(types.includes("error"), false);
  assert.match(body, /Oracle/);
  assert.doesNotMatch(AGENT_SRC.slice(AGENT_SRC.indexOf('router.post("/agent/chat"')), /res\.status\(500\)/);
});

test("agent.ts GET /agent/models serves chatModelsCatalog (source)", () => {
  assert.match(AGENT_SRC, /chatModelsCatalog/);
  assert.match(AGENT_SRC, /resolveChatModel/);
  const modelsHandler = AGENT_SRC.slice(
    AGENT_SRC.indexOf('router.get("/agent/models"'),
    AGENT_SRC.indexOf('router.post("/agent/reset-rate-limits"'),
  );
  assert.doesNotMatch(modelsHandler, /claude/i);
  assert.doesNotMatch(modelsHandler, /openrouter/i);
  assert.match(modelsHandler, /chatModelsCatalog/);
});

test("agent.ts POST /agent/chat does not call OpenRouter or mutating tools", () => {
  const start = AGENT_SRC.indexOf('router.post("/agent/chat"');
  assert.ok(start >= 0, "POST /agent/chat missing");
  const chat = AGENT_SRC.slice(start, AGENT_SRC.indexOf("export default router"));
  assert.match(chat, /oracleDeskChatEvents|gatherOracleDeskSnapshot/);
  assert.match(chat, /resolveChatModel/);
  assert.doesNotMatch(chat, /streamRound\(/);
  assert.doesNotMatch(chat, /aiChatStream/);
  assert.doesNotMatch(chat, /openrouter\.ai/i);
  assert.doesNotMatch(chat, /spawn_subagent/);
  assert.doesNotMatch(chat, /runTool\(/);
  assert.doesNotMatch(chat, /update_config/);
  assert.doesNotMatch(chat, /toggle_strategy/);
  assert.doesNotMatch(chat, /force_exit_trade/);
  assert.doesNotMatch(chat, /AI_INTEGRATIONS_OPENROUTER_API_KEY not configured/);
});

test("agent.ts does not poll OpenRouter for Claude on import", () => {
  assert.doesNotMatch(
    AGENT_SRC,
    /void guardedModelUpdate\(\);\s*setInterval/,
  );
});

test("chat path does not import OpenRouter or ai-client", () => {
  const chatSrc = readFileSync(path.resolve(DIR, "./oracle-desk-chat.ts"), "utf8");
  const llmSrc = readFileSync(path.resolve(DIR, "./chat-free-llm.ts"), "utf8");
  assert.doesNotMatch(chatSrc, /openrouter\.ai/i);
  assert.doesNotMatch(chatSrc, /from ["']\.\/ai-client/);
  assert.doesNotMatch(llmSrc, /openrouter\.ai/i);
  assert.doesNotMatch(llmSrc, /from ["']\.\/ai-client/);
  assert.match(llmSrc, /generateContent/);
  assert.match(llmSrc, /generativelanguage\.googleapis\.com/);
  assert.match(llmSrc, /api\.groq\.com/);
});

test("Gemini chatbot skips canned snapshot tools and streams the model text", async () => {
  const names: string[] = [];
  let body = "";
  const fetchImpl = (async () => {
    return new Response(JSON.stringify({
      candidates: [{ content: { parts: [{ text: "Hey — paper still on, skip is valid. What do you want to look at?" }] } }],
    }), { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;
  for await (const evt of oracleDeskChatEvents({
    question: "hey whats up",
    snapshot: snapshot(),
    modelOverride: "gemini-flash",
    env: GEMINI_ENV,
    fetchImpl,
    messages: [
      { role: "user", content: "hey whats up" },
    ],
  })) {
    if (evt.type === "tool_start" || evt.type === "tool_done") names.push(evt.name);
    if (evt.type === "delta") body += evt.content;
  }
  assert.equal(names.includes("get_full_status"), false);
  assert.equal(names.includes("diagnose_trade_readiness"), false);
  assert.match(body, /Hey/);
  assert.doesNotMatch(body, /intentional_wait/);
});

test("agent.ts POST /agent/chat forwards conversation messages to Gemini", () => {
  const start = AGENT_SRC.indexOf('router.post("/agent/chat"');
  const chat = AGENT_SRC.slice(start, AGENT_SRC.indexOf("export default router"));
  assert.match(chat, /Array\.isArray\(messages\) \? messages/);
  assert.match(chat, /messages: thread/); // R2: client thread, or DB-restored thread after a restart
});

test("desk diagnosis labels pack/R_t and projLine without treating pack as a fill gate", () => {
  const text = answerOracleDesk("why idle?", snapshot({
    projLine: "basis proj $64120 · model proj $64090",
    packId: "SQUEEZE",
    packSkipReason: null,
    skipReason: "dead_pin_no_lag",
    ticketP: 0.61,
    lagStale: true,
    regimeRtLine: "R_t DEAD/SQUEEZE/MICRO_RANGE/HTF_UP conf=0.50 lagUsed=false",
  }));
  assert.match(text, /basis proj \$64120/);
  assert.match(text, /model proj \$64090/);
  assert.match(text, /ticket p=0\.610/);
  assert.match(text, /lag stale=true/);
  assert.match(text, /skipReason dead_pin_no_lag/);
  assert.match(text, /Pack SQUEEZE \(log-only/);
  assert.match(text, /R_t DEAD\/SQUEEZE/);
  assert.doesNotMatch(text, /pack is a fill gate/i);
  assert.match(text, /not a fill gate/);
  assert.doesNotMatch(text, /side pick/i);
});


test("oracleDeskChatEvents never returns raw <tool_call> / <function= to the client", async () => {
  let round = 0;
  const fetchImpl = (async () => {
    round += 1;
    if (round === 1) {
      return new Response(JSON.stringify({
        choices: [{ message: { content: "Debug…\n<tool_call> <function=get_paper_ledger> </function> </tool_call>" } }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    }
    return new Response(JSON.stringify({
      choices: [{ message: { content: "Paper is fine. Locks hold." } }],
    }), { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;
  let body = "";
  const toolNames: string[] = [];
  for await (const evt of oracleDeskChatEvents({
    question: "Debug the bot",
    snapshot: snapshot(),
    modelOverride: "groq-llama",
    env: GROQ_ENV,
    fetchImpl,
    deskRoot: path.resolve(DIR, "../.."),
    chatRole: "ADMIN", // accounts: text tool execution is the ADMIN path (USER case: accounts/chat-policy.test.ts)
  })) {
    if (evt.type === "delta") body += evt.content;
    if (evt.type === "tool_start" || evt.type === "tool_done") toolNames.push(evt.name);
  }
  assert.doesNotMatch(body, /<tool_call>|<function=/);
  assert.doesNotMatch(body, /HTTP 500|Internal Server Error/i);
  assert.match(body, /Paper is fine|locks hold|PAPER|Oracle/i);
});
