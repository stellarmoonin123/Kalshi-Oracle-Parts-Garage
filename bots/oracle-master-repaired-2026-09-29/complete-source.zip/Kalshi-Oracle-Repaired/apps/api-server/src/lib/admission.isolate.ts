/**
 * admission.isolate.ts — UNCHANGED admission holes at isolate time:
 *   missing curve → invent 0.65
 *   calibratedWinRate / 0–1 confidence can replace p
 *   87¢ rich ask can clear EV_FLOOR via inflated p
 * Compare-only. Live admission.ts is the rewrite (winner): p=winRateAtPrice,
 * fee-net EV, no confidence-as-p, no 0.65, EV_FLOOR=3 for CC and LAG.
 */
import { computeTradeEV } from "./trade-path.js";
import {
  EV_FLOOR,
  OTM_EV_FLOOR,
  MIN_EDGE_OVER_MARKET,
  type EntryEVGateResult,
} from "./admission.js";

export const ISOLATE_MISSING_CURVE_P = 0.65;

export function pWinFromCurveIsolate(
  winRateAtPrice: ((entryPriceCents: number, minutesLeft: number) => number) | undefined,
  entryPriceCents: number | null | undefined,
  minutesLeft: number,
  fallback?: { expectedWinRate?: number; confidence?: number; calibratedWinRate?: number },
): number | null {
  if (winRateAtPrice && typeof entryPriceCents === "number" && Number.isFinite(entryPriceCents)) {
    const p = winRateAtPrice(entryPriceCents, minutesLeft);
    if (typeof p === "number" && Number.isFinite(p) && p > 0 && p <= 1) return p;
  }
  const cal = fallback?.calibratedWinRate;
  if (typeof cal === "number" && Number.isFinite(cal) && cal > 0 && cal <= 1) return cal;
  const conf = fallback?.confidence;
  if (typeof conf === "number" && Number.isFinite(conf)) {
    if (conf > 0 && conf <= 1) return conf;
    if (conf > 1 && conf <= 100) return conf / 100;
  }
  const prior = fallback?.expectedWinRate;
  if (typeof prior === "number" && Number.isFinite(prior) && prior > 0 && prior <= 1) return prior;
  return ISOLATE_MISSING_CURVE_P;
}

export function evaluateEntryEVGateIsolate(opts: {
  entryPriceCents: number;
  strategyWinRate: number;
  calibratedWinRate?: number;
  strategyId?: string;
  isOTMAsymmetry?: boolean;
  isOTMExpansion?: boolean;
  secsRemaining?: number;
  velocityDolPerMin?: number;
  spreadCents?: number;
  observedSlippageCents?: number;
}): EntryEVGateResult {
  const isOTMStrategy = opts.strategyId === "OTM_ASYMMETRY"
    || opts.strategyId === "OTM_BREAKOUT_EXPANSION"
    || opts.strategyId === "DEEP_OTM_SNIPER";
  const isOTMPlay = Boolean(opts.isOTMAsymmetry || opts.isOTMExpansion || isOTMStrategy);
  // Isolate hole: mass / N(d2) calibratedWR inflates p.
  const modelEstimatedProb = (typeof opts.calibratedWinRate === "number"
    && Number.isFinite(opts.calibratedWinRate))
    ? opts.calibratedWinRate
    : opts.strategyWinRate;
  const marketImpliedProb = isOTMPlay ? opts.entryPriceCents / 100 : null;
  const minEVCents = isOTMPlay ? OTM_EV_FLOOR : EV_FLOOR;
  const modelProbabilityBps = Math.round(modelEstimatedProb * 10_000);
  const minimumOtmProbabilityBps = opts.entryPriceCents * 100 + MIN_EDGE_OVER_MARKET * 10_000;
  if (isOTMPlay && modelProbabilityBps <= minimumOtmProbabilityBps) {
    return {
      passes: false,
      code: "OTM_EV_NO_EDGE",
      isOTMPlay,
      modelEstimatedProb,
      marketImpliedProb,
      minEVCents,
      netEV: null,
      evResult: null,
    };
  }
  const evResult = computeTradeEV({
    entryPriceCents: opts.entryPriceCents,
    winRate: modelEstimatedProb,
    strategyId: opts.strategyId,
    secsRemaining: opts.secsRemaining,
    velocityDolPerMin: opts.velocityDolPerMin,
    spreadCents: opts.spreadCents,
    observedSlippageCents: opts.observedSlippageCents,
    minEVCents,
  });
  return {
    passes: evResult.passes,
    code: evResult.passes ? undefined : (isOTMPlay ? "OTM_EV_FLOOR" : "EV_FLOOR"),
    isOTMPlay,
    modelEstimatedProb,
    marketImpliedProb,
    minEVCents,
    netEV: evResult.netEV,
    evResult,
  };
}
