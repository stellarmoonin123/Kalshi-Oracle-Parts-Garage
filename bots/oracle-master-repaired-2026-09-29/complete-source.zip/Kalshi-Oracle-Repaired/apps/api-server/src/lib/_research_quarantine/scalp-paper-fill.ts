/**
 * QUARANTINE — scalp-paper-fill.ts
 * OFF MONEY PATH. Relocated from lib/ for organ 100% hardening.
 * Research/ops scalp book only — trading-bot must never import this.
 * HARD_NO_FILL / paper-release / PAPER_SCALP denylist still apply on host.
 * DO NOT WIRE into evaluateEntry / placeOrder.
 *
 * --- original module follows ---
 */
/**
 * scalp-paper-fill.ts — ACTION NOW paper fill of the SEPARATE scalp book.
 *
 * Writes kind:paper_scalp into research/trade-debriefs.jsonl and a small
 * scalp-fills.jsonl. Never both sides open. One 9% budget per 15m bar
 * (of $313 start / current if known). Size 1. Budget spent at entry.
 *
 * paper:true. liveApply:false. promoteEnabled stays false.
 * NEVER ENABLE_STRATEGY. NEVER CHANGE_EV_FLOOR. NEVER paperMode false.
 * NEVER imports trading-bot.ts. NEVER calls placeOrder.
 *
 * Ticket velocity: still → skip. unknown → accept, tag velocity:unknown.
 */
import fs from "node:fs";
import path from "node:path";
import { HARD_RISK_LIMITS } from "../admission.js";
import { kalshiFeeCents, kalshiTakerFeeCents } from "../constants.js";
import { isKxbct15mTicker } from "../15m-product.js";
import {
  LIVE_APPLY,
  PAPER,
  PROMOTE_ENABLED,
  RESEARCH_DIR,
  DEFAULT_DEBRIEFS_PATH,
} from "../scalp-book.js";

export const SCALP_BOOK = "scalp" as const;
export const PAPER_SCALP_KIND = "paper_scalp" as const;
export const SCALP_CONTRACTS = 1;
export const DEFAULT_BANKROLL_CENTS = 31_300; // $313 start
export const DEFAULT_FILLS_PATH = path.join(RESEARCH_DIR, "scalp-fills.jsonl");

export type ScalpSide = "yes" | "no";
export type TicketVelocityState = "still" | "moving" | "unknown";

export interface PaperFillInput {
  ticker: unknown;
  side: unknown;
  askCents: unknown;
  reason?: unknown;
  velocity?: unknown;
  ticketVelocity?: unknown;
}

export type PaperFillSkip =
  | "bad-input"
  | "not-15m"
  | "still-ticket"
  | "both-sides-open"
  | "9pct-bar-budget";

export interface PaperFillOk {
  ok: true;
  book: "scalp";
  paper: true;
  liveApply: false;
  promoteEnabled: false;
  fillId: number;
  ticker: string;
  side: ScalpSide;
  askCents: number;
  contracts: 1;
  costCents: number;
  velocity: "moving" | "unknown";
  barBudgetCents: number;
  spentBudgetCents: number;
}

export interface PaperFillSkipped {
  ok: false;
  book: "scalp";
  paper: true;
  liveApply: false;
  promoteEnabled: false;
  skip: PaperFillSkip;
  reason?: string;
}

export type PaperFillResult = PaperFillOk | PaperFillSkipped;

export interface ScalpPaperFillOpts {
  debriefsPath?: string;
  fillsPath?: string;
  bankrollCents?: number;
  now?: () => number;
}

interface BarState {
  openSides: Set<ScalpSide>;
  spentCents: number;
  budgetCents: number;
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  return null;
}

function velocityOf(raw: unknown): TicketVelocityState {
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    const rec = raw as Record<string, unknown>;
    if ("state" in rec) return velocityOf(rec.state);
  }
  const s = String(raw ?? "").toLowerCase().trim();
  if (s === "still") return "still";
  if (s === "moving") return "moving";
  return "unknown";
}

function parseSide(raw: unknown): ScalpSide | null {
  const s = String(raw ?? "").toLowerCase().trim();
  if (s === "yes") return "yes";
  if (s === "no") return "no";
  return null;
}

function parseAsk(raw: unknown): number | null {
  const n = typeof raw === "number" ? raw : typeof raw === "string" ? Number(raw) : NaN;
  if (!Number.isFinite(n)) return null;
  const cents = Math.round(n);
  if (cents < 1 || cents > 99) return null;
  return cents;
}

function parseTicker(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const t = raw.trim();
  return t.length > 0 ? t : null;
}

function formatTsEt(d: Date): string {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).formatToParts(d);
  const get = (type: string) => parts.find(p => p.type === type)?.value ?? "";
  const dayPeriod = (get("dayPeriod") || "PM").toLowerCase().replace(/\./g, "");
  return `${get("year")}-${get("month")}-${get("day")} ${get("hour")}:${get("minute")}${dayPeriod} ET`;
}

function readJsonl(filePath: string): unknown[] {
  try {
    if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) return [];
    const rows: unknown[] = [];
    for (const line of fs.readFileSync(filePath, "utf8").split("\n")) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      try { rows.push(JSON.parse(trimmed)); } catch { /* skip malformed */ }
    }
    return rows;
  } catch {
    return [];
  }
}

function appendJsonl(filePath: string, row: unknown): void {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.appendFileSync(filePath, `${JSON.stringify(row)}\n`, "utf8");
}

function maxFillId(rows: unknown[]): number {
  let max = 0;
  for (const row of rows) {
    const rec = asRecord(row);
    if (!rec) continue;
    const id = rec.fillId;
    if (typeof id === "number" && Number.isFinite(id) && id > max) max = id;
  }
  return max;
}

function lastKnownBankroll(rows: unknown[], fallback: number): number {
  for (let i = rows.length - 1; i >= 0; i--) {
    const rec = asRecord(rows[i]);
    if (!rec) continue;
    const after = asRecord(rec.after);
    const n = after?.paperBalanceCents;
    if (typeof n === "number" && Number.isFinite(n) && n > 0) return n;
  }
  return fallback;
}

function skip(code: PaperFillSkip, reason?: string): PaperFillSkipped {
  return {
    ok: false,
    book: SCALP_BOOK,
    paper: PAPER,
    liveApply: LIVE_APPLY,
    promoteEnabled: PROMOTE_ENABLED,
    skip: code,
    ...(reason ? { reason } : {}),
  };
}

export function createScalpPaperBook(opts: ScalpPaperFillOpts = {}) {
  const debriefsPath = opts.debriefsPath ?? DEFAULT_DEBRIEFS_PATH;
  const fillsPath = opts.fillsPath ?? DEFAULT_FILLS_PATH;
  const nowFn = opts.now ?? Date.now;
  const bars = new Map<string, BarState>();

  function hydrateBar(ticker: string, bankroll: number): BarState {
    const existing = bars.get(ticker);
    if (existing) return existing;
    const budgetCents = Math.floor(bankroll * HARD_RISK_LIMITS.maxRiskPctPerTrade);
    const state: BarState = { openSides: new Set(), spentCents: 0, budgetCents };
    const fills = readJsonl(fillsPath);
    for (const row of fills) {
      const rec = asRecord(row);
      if (!rec) continue;
      if (rec.ticker !== ticker) continue;
      if (rec.kind !== PAPER_SCALP_KIND) continue;
      if (rec.paper !== true) continue;
      const side = parseSide(rec.side);
      const cost = typeof rec.costCents === "number" ? rec.costCents : 0;
      if (side) state.openSides.add(side);
      if (cost > 0) state.spentCents += cost;
    }
    bars.set(ticker, state);
    return state;
  }

  function paperFill(input: PaperFillInput): PaperFillResult {
    const ticker = parseTicker(input.ticker);
    const side = parseSide(input.side);
    const askCents = parseAsk(input.askCents);
    if (!ticker || !side || askCents == null) {
      return skip("bad-input", "Need ticker, side yes|no, askCents 1-99");
    }
    if (!isKxbct15mTicker(ticker)) {
      return skip("not-15m", "Scalp book is KXBTC15M only");
    }

    const velocity = velocityOf(input.velocity ?? input.ticketVelocity);
    if (velocity === "still") {
      return skip("still-ticket", "Intra-scalp skips a still ask");
    }

    const debriefs = readJsonl(debriefsPath);
    const bankroll = opts.bankrollCents ?? lastKnownBankroll(debriefs, DEFAULT_BANKROLL_CENTS);
    const bar = hydrateBar(ticker, bankroll);

    const opposite: ScalpSide = side === "yes" ? "no" : "yes";
    if (bar.openSides.has(opposite)) {
      return skip("both-sides-open", "Never both sides open on the scalp book");
    }

    const costCents = SCALP_CONTRACTS * askCents + kalshiTakerFeeCents(askCents, SCALP_CONTRACTS);
    if (bar.spentCents + costCents > bar.budgetCents) {
      return skip("9pct-bar-budget", "One 9% budget per 15m bar, spent at entry");
    }

    const fillId = Math.max(maxFillId(debriefs), maxFillId(readJsonl(fillsPath))) + 1;
    const tsMs = nowFn();
    const tsDate = new Date(tsMs);
    const reason = typeof input.reason === "string" && input.reason.trim()
      ? input.reason.trim()
      : "ACTION NOW paper scalp";

    bar.openSides.add(side);
    bar.spentCents += costCents;

    const fillRow = {
      ts: tsDate.toISOString(),
      tsEt: formatTsEt(tsDate),
      ticker,
      side,
      askCents,
      contracts: SCALP_CONTRACTS,
      costCents,
      fillId,
      paper: true,
      liveApply: false,
      promoteEnabled: false,
      kind: PAPER_SCALP_KIND,
      book: SCALP_BOOK,
      velocity,
      reason,
      barBudgetCents: bar.budgetCents,
      spentBudgetCents: bar.spentCents,
      never: ["ENABLE_STRATEGY", "CHANGE_EV_FLOOR"] as const,
    };

    const debriefRow = {
      ts: fillRow.ts,
      tsEt: fillRow.tsEt,
      desk: "KXBTC15M",
      paper: true,
      liveApply: false,
      kind: PAPER_SCALP_KIND,
      ticker,
      fillId,
      before: {
        strategyId: "INTRA_SCALP",
        side,
        contracts: SCALP_CONTRACTS,
        entryCents: askCents,
        book: SCALP_BOOK,
        ticketVelocity: { state: velocity },
      },
      reason,
      after: {
        paperBalanceCents: bankroll - costCents,
        flags: { liveApply: false, paperMode: true, autoMode: false, promoteEnabled: false },
      },
      never: ["ENABLE_STRATEGY", "CHANGE_EV_FLOOR"] as const,
    };

    appendJsonl(fillsPath, fillRow);
    appendJsonl(debriefsPath, debriefRow);

    return {
      ok: true,
      book: SCALP_BOOK,
      paper: PAPER,
      liveApply: LIVE_APPLY,
      promoteEnabled: PROMOTE_ENABLED,
      fillId,
      ticker,
      side,
      askCents,
      contracts: SCALP_CONTRACTS,
      costCents,
      velocity,
      barBudgetCents: bar.budgetCents,
      spentBudgetCents: bar.spentCents,
    };
  }

  return { paperFill };
}

const defaultBook = createScalpPaperBook();

export function paperFillScalp(input: PaperFillInput, opts?: ScalpPaperFillOpts): PaperFillResult {
  if (opts) return createScalpPaperBook(opts).paperFill(input);
  return defaultBook.paperFill(input);
}
