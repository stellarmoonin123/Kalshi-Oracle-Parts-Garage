/**
 * Leftover add-to-position evaluate/fill. Paper KXBTC15M never runs it.
 * Host: leftoverAddEvaluateMayRun is the only door into leftover-add-funnel.
 * Not an edge claim. Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
import { paperDeskAddToPositionMayRun } from "./evaluate-15m-scope.js";

export const LEFTOVER_ADD_EVALUATE_LOADED = true as const;
export const LEFTOVER_ADD_EVALUATE_HOST_GUARD =
  "if (!paperDeskAddToPositionMayRun(this.config)) return;";

export const FROZEN_ADD_FUNNEL_MARKERS = [
  "ADD_BLOCKED_LAG_DISAGREE",
  "DISCOUNT-ADD",
  "ADD-TO-POSITION:",
  "STREAK_SATURATION no_size_up",
  "selectBestEnabled(addPool",
  "paperVirtualBalanceCents -= costCents",
  "ADD_TO_POSITION DEPTH_UNAVAILABLE",
] as const;

export function leftoverAddEvaluateMayRun(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return paperDeskAddToPositionMayRun(cfg);
}

export function leftoverAddEvaluateHostDenied(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverAddEvaluateMayRun(cfg) === false;
}

export function leftoverAddEvaluateRun(
  cfg: { paperMode?: boolean; frozenCcMode?: boolean },
  run: () => Promise<void>,
): Promise<void> {
  if (!leftoverAddEvaluateMayRun(cfg)) return Promise.resolve();
  return run();
}
