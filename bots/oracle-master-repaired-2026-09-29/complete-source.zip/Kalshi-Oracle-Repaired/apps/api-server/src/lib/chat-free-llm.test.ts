/**
 * chat-free-llm.test.ts — Gemini generateContent then Groq; never OpenRouter.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  completeChatFreeLlm,
  geminiKeyPresent,
  groqKeyPresent,
  GEMINI_FLASH_API_MODEL,
  GROQ_LLAMA_MODEL,
  containsRawToolCallMarkup,
  parseTextToolCalls,
  stripRawToolCallMarkup,
} from "./chat-free-llm.js";
import type { DeskSnapshot } from "./oracle-desk-chat.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));

function snap(): DeskSnapshot {
  return {
    state: "WATCHING",
    lastSignal: "skip",
    paperMode: true,
    autoMode: false,
    useExpertAgent: false,
    enable1HContracts: false,
    paperVirtualCents: 31_300,
    paperLedgerCents: 31_300,
    todayWins: 0,
    todayLosses: 0,
    todayPnlCents: 0,
    consecutiveLosses: 0,
    detectedRegime: "unclear",
    activeStrategy: null,
    secsRemaining: 400,
    classification: "intentional_wait",
    headline: "Wait.",
    recommendation: "Do not cut EV.",
    activeBlockers: [],
    trades: [],
    basisProj: null,
    modelProj: null,
    projLine: "proj n/a",
  };
}

test("geminiKeyPresent reads GEMINI_API_KEY or GOOGLE_GENERATIVE_AI_API_KEY", () => {
  assert.equal(geminiKeyPresent({}), false);
  assert.equal(geminiKeyPresent({ GEMINI_API_KEY: "x" }), true);
  assert.equal(geminiKeyPresent({ GOOGLE_GENERATIVE_AI_API_KEY: "y" }), true);
  assert.equal(groqKeyPresent({ GROQ_API_KEY: "z" }), true);
  assert.equal(groqKeyPresent({}), false);
});

test("completeChatFreeLlm uses Gemini generateContent and not OpenRouter", async () => {
  const urls: string[] = [];
  const fetchImpl = (async (input: unknown) => {
    urls.push(String(input));
    return new Response(JSON.stringify({
      candidates: [{ content: { parts: [{ text: "Flash says skip is valid." }] } }],
    }), { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;
  const result = await completeChatFreeLlm({
    question: "why idle?",
    snapshot: snap(),
    env: { GEMINI_API_KEY: "gk" },
    fetchImpl,
  });
  assert.equal(result?.provider, "gemini");
  assert.equal(result?.model, GEMINI_FLASH_API_MODEL);
  assert.match(result?.text ?? "", /skip is valid/);
  assert.ok(urls.some(u => u.includes("generativelanguage.googleapis.com")));
  assert.ok(urls.some(u => u.includes("generateContent")));
  assert.ok(!urls.some(u => /openrouter/i.test(u)));
});

test("completeChatFreeLlm falls back to Groq llama-3.3-70b when Gemini fails", async () => {
  const urls: string[] = [];
  const fetchImpl = (async (input: unknown) => {
    const u = String(input);
    urls.push(u);
    if (u.includes("googleapis")) {
      return new Response("nope", { status: 429 });
    }
    return new Response(JSON.stringify({
      choices: [{ message: { content: "Groq llama snapshot." } }],
    }), { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;
  const result = await completeChatFreeLlm({
    question: "status",
    snapshot: snap(),
    env: { GEMINI_API_KEY: "gk", GROQ_API_KEY: "gq" },
    fetchImpl,
  });
  assert.equal(result?.provider, "groq");
  assert.equal(result?.model, GROQ_LLAMA_MODEL);
  assert.match(result?.text ?? "", /Groq llama/);
  assert.ok(urls.some(u => u.includes("api.groq.com")));
  assert.ok(!urls.some(u => /openrouter/i.test(u)));
});

test("completeChatFreeLlm returns null with no keys so snapshot can answer", async () => {
  const result = await completeChatFreeLlm({
    question: "status",
    snapshot: snap(),
    env: {},
    fetchImpl: (async () => { throw new Error("must not fetch"); }) as typeof fetch,
  });
  assert.equal(result, null);
});

test("chat-free-llm.ts has no OpenRouter / ai-client import", () => {
  const src = readFileSync(path.resolve(DIR, "./chat-free-llm.ts"), "utf8");
  assert.doesNotMatch(src, /openrouter\.ai/i);
  assert.doesNotMatch(src, /from ["'].*ai-client/);
  assert.doesNotMatch(src, /from ["'].*evaluate/);
});

test("completeChatFreeLlm sends conversation history to Gemini generateContent", async () => {
  let body = "";
  const fetchImpl = (async (_input: unknown, init?: RequestInit) => {
    body = String(init?.body ?? "");
    return new Response(JSON.stringify({
      candidates: [{ content: { parts: [{ text: "You said your name is Stellar." }] } }],
    }), { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;
  const result = await completeChatFreeLlm({
    question: "what is my name?",
    snapshot: snap(),
    env: { GEMINI_API_KEY: "gk" },
    fetchImpl,
    messages: [
      { role: "user", content: "my name is Stellar" },
      { role: "assistant", content: "Got it." },
      { role: "user", content: "what is my name?" },
    ],
  });
  assert.equal(result?.provider, "gemini");
  assert.match(body, /my name is Stellar/);
  assert.match(body, /what is my name/);
  const parsed = JSON.parse(body) as { contents: { role: string; parts: { text: string }[] }[] };
  assert.equal(parsed.contents.length, 3);
  assert.equal(parsed.contents[1].role, "model");
});


test("strip/parse raw <tool_call>/<function= markup — never leave it for the client", () => {
  const raw = "Checking ledger…\n<tool_call> <function=get_paper_ledger> </function> </tool_call>";
  assert.equal(containsRawToolCallMarkup(raw), true);
  assert.deepEqual(parseTextToolCalls(raw), [{ name: "get_paper_ledger", args: {} }]);
  const cleaned = stripRawToolCallMarkup(raw);
  assert.equal(containsRawToolCallMarkup(cleaned), false);
  assert.match(cleaned, /Checking ledger/);
  assert.doesNotMatch(cleaned, /tool_call|function=/);
});

test("completeChatFreeLlm parses Groq text tool calls, executes, strips markup from client text", async () => {
  let round = 0;
  const fetchImpl = (async () => {
    round += 1;
    if (round === 1) {
      return new Response(JSON.stringify({
        choices: [{ message: { content: "One sec.\n<tool_call>\n<function=get_paper_ledger>\n</function>\n</tool_call>" } }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    }
    return new Response(JSON.stringify({
      choices: [{ message: { content: "Paper ledger is $313.00. Skip is valid." } }],
    }), { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;
  const calls: string[] = [];
  const result = await completeChatFreeLlm({
    question: "Debug the bot",
    snapshot: snap(),
    env: { GROQ_API_KEY: "gq" },
    fetchImpl,
    toolsEnabled: true,
    runTool: (name, args) => {
      calls.push(name);
      return { ok: true, summary: "paper $313.00", virtualCents: 31300 };
    },
  });
  assert.equal(result?.provider, "groq");
  assert.deepEqual(calls, ["get_paper_ledger"]);
  assert.match(result?.text ?? "", /Paper ledger|\$313/);
  assert.equal(containsRawToolCallMarkup(result?.text ?? ""), false);
  assert.doesNotMatch(result?.text ?? "", /<tool_call>|<function=/);
  assert.ok((result?.toolEvents ?? []).some(e => e.type === "tool_start" && e.name === "get_paper_ledger"));
  assert.ok((result?.toolEvents ?? []).some(e => e.type === "tool_done" && e.name === "get_paper_ledger"));
});

test("completeChatFreeLlm strips tool XML even when toolsEnabled is false", async () => {
  const fetchImpl = (async () => new Response(JSON.stringify({
    choices: [{ message: { content: "Hi\n<tool_call><function=get_bot_config></function></tool_call>" } }],
  }), { status: 200, headers: { "content-type": "application/json" } })) as typeof fetch;
  const result = await completeChatFreeLlm({
    question: "hi",
    snapshot: snap(),
    env: { GROQ_API_KEY: "gq" },
    fetchImpl,
    toolsEnabled: false,
  });
  assert.equal(containsRawToolCallMarkup(result?.text ?? ""), false);
  assert.doesNotMatch(result?.text ?? "", /tool_call|function=/);
  assert.match(result?.text ?? "", /Hi/);
});


test("ORACLE_V2 doctrine in chatSystemPrompt", async () => {
  const { chatSystemPrompt } = await import("./chat-free-llm.js");
  const snap = {
    state: "IDLE",
    lastSignal: "",
    paperMode: true,
    autoMode: false,
    useExpertAgent: false,
    enable1HContracts: false,
    paperVirtualCents: 31300,
    paperLedgerCents: 31300,
    todayWins: 0,
    todayLosses: 0,
    todayPnlCents: 0,
    consecutiveLosses: 0,
    detectedRegime: null,
    activeStrategy: null,
    secsRemaining: 600,
    classification: "intentional_wait",
    headline: "waiting",
    recommendation: "wait",
    activeBlockers: [],
    trades: [],
    basisProj: null,
    modelProj: null,
    projLine: "n/a",
  };
  const sys = chatSystemPrompt(snap as never);
  assert.match(sys, /ORACLE_READY/);
  assert.match(sys, /Never invent fills/i);
  assert.match(sys, /kelly_mult=0\.20/);
  assert.match(sys, /LLM-free/);
});
