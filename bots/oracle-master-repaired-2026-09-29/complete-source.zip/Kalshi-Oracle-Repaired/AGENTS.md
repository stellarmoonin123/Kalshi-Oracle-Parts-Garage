# AGENTS.md

Read [docs/PROJECT_STATE.md](docs/PROJECT_STATE.md) and [docs/LANDMINES.md](docs/LANDMINES.md) before editing.

Then read [docs/development/AGENT_INSTRUCTIONS.md](docs/development/AGENT_INSTRUCTIONS.md) and [docs/development/SAFE_CHANGE_PROTOCOL.md](docs/development/SAFE_CHANGE_PROTOCOL.md).

Humans start at [README.md](README.md) and [docs/START_HERE.md](docs/START_HERE.md).

## Authority

1. Executable code
2. Automated tests
3. Configuration and schema
4. Architecture decisions
5. Technical documentation
6. Human-facing documentation
7. Old design notes and `research/`

If prose disagrees with code, flag the prose. Do not rewrite `apps/api-server/src/lib/trading-bot.ts`.

## Operating mode

Code default is paper (`paperMode: true` in `DEFAULT_CONFIG`). Disk persist in `apps/api-server/src/lib/config-persist.ts` also forces `paperMode: true` on load and save. Live money is not a boot path. Never use live trading as the first validation environment. Never set `paperMode: false` to “verify live.”

`frozenCcMode` defaults to `false`.

## Inspect before you change

Inspect → Understand → Plan → Test → Change → Test → Document → Review.

Prefer the smallest safe change. Do not silently alter trading semantics. Do not loosen risk controls without explicit authorization.

## Wired Chat (not the leftover tool catalog)

Dashboard Chat is `POST /api/agent/chat` in `apps/api-server/src/routes/agent.ts`, which calls `oracleDeskChatEvents` in `apps/api-server/src/lib/oracle-desk-chat.ts`. That handler does not invoke leftover `runTool` / `update_config` / `toggle_strategy` / `control_bot`.

The same route file still embeds a header and `runTool` catalog. Do not treat that catalog as the live Chat executor. Do not instruct agents to call `update_config` via leftover `runTool` on `POST /api/agent/chat`.

`apps/api-server/src/lib/agent.ts` is the research-task runner for `/api/tasks`, not the Chat tool catalog.

Desk chat may still patch source through `apps/api-server/src/lib/chat-code-edit.ts` (`apply_patch` / `write_file`). That is a product hazard, not the approved Cursor workflow. See the safe-change protocol.

Operator config changes go through `PUT` / `PATCH /api/bot/config` and `sanitizeConfigPatch`, not Chat file writes of `.bot-config.json`.

## Tests

Default proof for everyday work: `pnpm run test:api`, `pnpm run test:dashboard` when the UI changed, and `pnpm run typecheck`. Release bars live in [docs/PAPER_PRODUCTION_RELEASE_CHECKLIST.md](docs/PAPER_PRODUCTION_RELEASE_CHECKLIST.md). Everyday PR bars: [docs/development/DEFINITION_OF_DONE.md](docs/development/DEFINITION_OF_DONE.md).

## Current work tracking

Empty schemas (do not invent IDs from `research/`):

- [docs/tracking/BUG_TRACKER.md](docs/tracking/BUG_TRACKER.md)
- [docs/tracking/BUG_FIX_LOG.md](docs/tracking/BUG_FIX_LOG.md)
- [docs/tracking/FEATURE_BACKLOG.md](docs/tracking/FEATURE_BACKLOG.md)
- [docs/tracking/DECISION_LOG.md](docs/tracking/DECISION_LOG.md)

`/api/tasks` is a separate research-task writer, not those trackers.
