/**
 * Route-layer PATCH surface. Does not import trading-bot.ts.
 * paperMode true / autoMode false doctrine payloads must pass through.
 */
import assert from "node:assert/strict";
import test from "node:test";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  PATCH_FAIL_CLOSED_DISABLED,
  PATCH_REFUSE_FLOOR_KEYS,
  refuseToggleStrategy,
  sanitizeConfigPatch,
} from "./config-patch-surface.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const SURFACE_SRC = fs.readFileSync(path.join(DIR, "config-patch-surface.ts"), "utf8");
const BOT_ROUTE = fs.readFileSync(path.join(DIR, "../routes/bot.ts"), "utf8");
const AGENT_ROUTE = fs.readFileSync(path.join(DIR, "../routes/agent.ts"), "utf8");

test("module does not import trading-bot", () => {
  assert.equal(/from\s+["'][^"']*trading-bot/.test(SURFACE_SRC), false);
});

test("doctrine dashboard Save (paper, composer off) is a pass-through", () => {
  const r = sanitizeConfigPatch({
    paperMode: true,
    autoMode: false,
    useExpertAgent: false,
    enable1HContracts: false,
    enable1HLive: false,
    paperStartingBalanceCents: 31300,
    cheapSide15mEnabled: false,
    equityCurveResetAt: 1,
  });
  assert.equal(r.refused.length, 0);
  assert.equal(r.accepted.paperMode, true);
  assert.equal(r.accepted.autoMode, false);
  assert.equal(r.accepted.paperStartingBalanceCents, 31300);
  assert.equal(r.accepted.cheapSide15mEnabled, false);
});

test("paperMode false is stripped, not merged", () => {
  const r = sanitizeConfigPatch({ paperMode: false, paperStartingBalanceCents: 31300 });
  assert.equal("paperMode" in r.accepted, false);
  assert.equal(r.accepted.paperStartingBalanceCents, 31300);
  assert.equal(r.refused.length, 1);
  assert.match(r.refused[0].reason, /LIVE REAL MONEY/);
});

test("hostile-only payload (paperMode false) refuses paper/1H live; autoMode true refused without confirm", () => {
  const r = sanitizeConfigPatch({ paperMode: false, autoMode: true, enable1HLive: true });
  assert.equal("autoMode" in r.accepted, false);
  assert.equal("paperMode" in r.accepted, false);
  assert.equal("enable1HLive" in r.accepted, false);
  assert.ok(r.refused.some(x => x.key === "autoMode"));
  assert.ok(r.refused.length >= 3);
});

test("autoMode true refused without CONFIRM AUTO MODE; ExpertAgent true refused", () => {
  const r = sanitizeConfigPatch({ autoMode: true, useExpertAgent: true, ariaModel: "openai/gpt-5" });
  assert.equal("autoMode" in r.accepted, false);
  assert.equal(r.accepted.useExpertAgent, undefined);
  assert.equal(r.accepted.ariaModel, "openai/gpt-5");
  assert.ok(r.refused.some(x => x.key === "autoMode"));
  assert.ok(r.refused.some(x => x.key === "useExpertAgent"));
});

test("autoMode true accepted with confirmAutoMode CONFIRM AUTO MODE", () => {
  const r = sanitizeConfigPatch({ autoMode: true, confirmAutoMode: "CONFIRM AUTO MODE" });
  assert.equal(r.accepted.autoMode, true);
  assert.equal(r.refused.some(x => x.key === "autoMode"), false);
});

test("enable1H + candlestickPatternLive + unproven opt-ins refused", () => {
  const r = sanitizeConfigPatch({
    enable1HContracts: true,
    enable1HLive: true,
    candlestickPatternLiveEnabled: true,
    settlementConsensusVoteEnabled: true,
    topReversalEnabled: true,
    bottomReversalEnabled: true,
    bollingerBandStrategyEnabled: true,
    velocityStallReversalEnabled: true,
    useDailyTarget: true,
    dailyTargetPct: 50,
    specialistPacksMode: "enforce",
    autoModeV2Mode: "bounded_write",
    reservePct: 5,
  });
  assert.deepEqual(r.accepted, {});
  assert.ok(r.refused.some(x => x.key === "enable1HContracts"));
  assert.ok(r.refused.some(x => x.key === "enable1HLive"));
  assert.ok(r.refused.some(x => x.key === "candlestickPatternLiveEnabled"));
  assert.ok(r.refused.some(x => x.key === "dailyTargetPct"));
  assert.ok(r.refused.some(x => x.key === "reservePct"));
  assert.ok(r.refused.some(x => x.key === "specialistPacksMode"));
});

test("empty disabledStrategies still keeps SEV1 + LATE_ENTRY + VSR", () => {
  const r = sanitizeConfigPatch({ disabledStrategies: [] });
  const next = r.accepted.disabledStrategies as string[];
  for (const id of PATCH_FAIL_CLOSED_DISABLED) {
    assert.ok(next.includes(id), `must keep ${id}`);
  }
  assert.match(r.notes.join(" "), /LATE_ENTRY_ANCHOR/);
});

test("cannot pull LATE_ENTRY or OTM out of a list", () => {
  const r = sanitizeConfigPatch({
    disabledStrategies: ["CHANNEL_BOUNCE"],
  });
  const next = r.accepted.disabledStrategies as string[];
  assert.ok(next.includes("CHANNEL_BOUNCE"));
  assert.ok(next.includes("LATE_ENTRY_ANCHOR"));
  assert.ok(next.includes("OTM_ASYMMETRY"));
  // PAPER DESK v2: BRTI / VELOCITY_MOMENTUM unlocked from fail-closed union
  assert.equal(next.includes("BRTI_PROBABILITY"), false);
  assert.equal(next.includes("VELOCITY_MOMENTUM"), false);
  assert.equal(next.includes("CONFLUENCE_CASCADE"), false, "CONFLUENCE is paper-restored, not fail-closed");
});

test("refuseToggleStrategy blocks SEV1/LATE_ENTRY enable, allows disable", () => {
  assert.ok(refuseToggleStrategy("LATE_ENTRY_ANCHOR", true));
  assert.equal(refuseToggleStrategy("BRTI_PROBABILITY", true), null); // desk v2 placeable
  assert.ok(refuseToggleStrategy("VELOCITY_STALL_REVERSAL", true));
  assert.equal(refuseToggleStrategy("LATE_ENTRY_ANCHOR", false), null);
  assert.equal(refuseToggleStrategy("BASIS_LAG_EDGE", true), null);
  assert.equal(refuseToggleStrategy("CHEAP_SIDE_15M", true), null);
  assert.equal(refuseToggleStrategy("VELOCITY_MOMENTUM", true), null);
});

test("bot.ts PUT/PATCH /bot/config is a caller", () => {
  assert.match(BOT_ROUTE, /sanitizeConfigPatch/);
  assert.match(BOT_ROUTE, /from ["']\.\.\/lib\/config-patch-surface\.js["']/);
});

test("agent update_config + toggle_strategy are callers", () => {
  assert.match(AGENT_ROUTE, /sanitizeConfigPatch/);
  assert.match(AGENT_ROUTE, /refuseToggleStrategy/);
  assert.match(AGENT_ROUTE, /from ["']\.\.\/lib\/config-patch-surface\.js["']/);
});

test("SETTLEMENT_PREDICTION stays fail-closed; CONFLUENCE paper-restored", () => {
  const r = sanitizeConfigPatch({ disabledStrategies: [] });
  const next = r.accepted.disabledStrategies as string[];
  assert.ok(next.includes("SETTLEMENT_PREDICTION"));
  assert.equal(next.includes("CONFLUENCE_CASCADE"), false);
  assert.ok(refuseToggleStrategy("SETTLEMENT_PREDICTION", true));
  assert.equal(refuseToggleStrategy("CONFLUENCE_CASCADE", true), null);
});

test("trading-bot updateConfig is a caller of sanitizeConfigPatch", () => {
  const botSrc = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
  assert.match(botSrc, /from ["']\.\/config-patch-surface\.js["']/);
  assert.match(botSrc, /sanitizeConfigPatch\((partial|rawPatch)/);
  assert.equal(/from\s+["'][^"']*trading-bot/.test(SURFACE_SRC), false);
});

test("paperMode false with wrong / missing phrase is refused; paper stays default", () => {
  const missing = sanitizeConfigPatch({ paperMode: false });
  assert.equal("paperMode" in missing.accepted, false);
  assert.ok(missing.refused.some(x => x.key === "paperMode"));

  const wrong = sanitizeConfigPatch({
    paperMode: false,
    confirmLiveRealMoney: "live real money",
  });
  assert.equal("paperMode" in wrong.accepted, false);
  assert.ok(wrong.refused.some(x => x.key === "paperMode"));

  const spaced = sanitizeConfigPatch({
    paperMode: false,
    confirmLiveRealMoney: "LIVE REAL MONEY ",
  });
  assert.equal("paperMode" in spaced.accepted, false);
});

test("paper-only desk: LIVE REAL MONEY does NOT unlock paperMode false; enable1HLive stays fail-closed", () => {
  const r = sanitizeConfigPatch({
    paperMode: false,
    enable1HLive: true,
    paperStartingBalanceCents: 31300,
    confirmLiveRealMoney: "LIVE REAL MONEY",
  });
  assert.equal("paperMode" in r.accepted, false);
  assert.equal("enable1HLive" in r.accepted, false);
  assert.equal(r.accepted.paperStartingBalanceCents, 31300);
  assert.ok(r.refused.some(x => x.key === "paperMode"));
  assert.ok(r.refused.some(x => x.key === "enable1HLive"));
});

test("phrase does not unlock ExpertAgent / enable1H / leftovers; autoMode still needs CONFIRM AUTO MODE", () => {
  const r = sanitizeConfigPatch({
    paperMode: false,
    enable1HLive: true,
    autoMode: true,
    useExpertAgent: true,
    enable1HContracts: true,
    cheapSide15mEnabled: true,
    confirmLiveRealMoney: "LIVE REAL MONEY",
  });
  assert.equal("paperMode" in r.accepted, false);
  assert.equal("enable1HLive" in r.accepted, false);
  assert.equal("autoMode" in r.accepted, false);
  assert.ok(r.refused.some(x => x.key === "autoMode"));
  assert.ok(r.refused.some(x => x.key === "useExpertAgent"));
  assert.ok(r.refused.some(x => x.key === "enable1HContracts"));
  assert.ok(r.refused.some(x => x.key === "enable1HLive"));
  assert.ok(r.refused.some(x => x.key === "cheapSide15mEnabled"));
});

test("enable1HLive true without phrase is refused", () => {
  const r = sanitizeConfigPatch({ enable1HLive: true });
  assert.equal("enable1HLive" in r.accepted, false);
  assert.ok(r.refused.some(x => x.key === "enable1HLive"));
  assert.match(r.refused.find(x => x.key === "enable1HLive")!.reason, /fail-closed|hourly ENABLE|LIVE REAL MONEY/);
});

test("PhD audit fail-closed ids cannot be pulled out; CHEAP_SIDE + BASIS_LAG stay eligible", () => {
  const ids = [
    // VELOCITY_MOMENTUM unlocked PAPER DESK v2
    "CHANNEL_BOUNCE",
    "MEAN_REVERSION_STRETCH",
    "FAKEOUT_FADE",
    "FLOOR_DISTANCE",
    "BREAKOUT_CAPTURE",
    "EXHAUSTION_ANCHOR",
    "SQUEEZE_EXPANSION",
  ];
  const r = sanitizeConfigPatch({ disabledStrategies: [] });
  const next = r.accepted.disabledStrategies as string[];
  for (const id of ids) {
    assert.ok(next.includes(id), `must keep ${id}`);
    assert.ok(refuseToggleStrategy(id, true), `${id} enable must be refused`);
  }
  assert.equal(next.includes("CHEAP_SIDE_15M"), false);
  assert.equal(next.includes("BASIS_LAG_EDGE"), false);
  assert.equal(next.includes("CONFLUENCE_CASCADE"), false);
  assert.equal(refuseToggleStrategy("CHEAP_SIDE_15M", true), null);
  assert.equal(refuseToggleStrategy("BASIS_LAG_EDGE", true), null);
  assert.equal(refuseToggleStrategy("CONFLUENCE_CASCADE", true), null);
});


test("EV/Kelly/9%/18% floor keys are immutable via patch (any value)", () => {
  const hostile: Record<string, unknown> = {};
  for (const key of PATCH_REFUSE_FLOOR_KEYS) hostile[key] = 0;
  hostile.minConfidence = 52;
  const r = sanitizeConfigPatch(hostile);
  assert.equal(r.accepted.minConfidence, 52);
  for (const key of PATCH_REFUSE_FLOOR_KEYS) {
    assert.equal(key in r.accepted, false, `${key} must be refused`);
    assert.ok(r.refused.some(x => x.key === key), `${key} must appear in refused`);
  }
});

test("leftover ENABLE flags (cheapSide/panic/streak/earlyExit) cannot go true via patch", () => {
  const r = sanitizeConfigPatch({
    cheapSide15mEnabled: true,
    cheapEarlyExitEnabled: true,
    panicFadeEnabled: true,
    streakSatFadeEnabled: true,
    paperMode: true,
  });
  assert.equal(r.accepted.paperMode, true);
  assert.equal("cheapSide15mEnabled" in r.accepted, false);
  assert.equal("cheapEarlyExitEnabled" in r.accepted, false);
  assert.equal("panicFadeEnabled" in r.accepted, false);
  assert.equal("streakSatFadeEnabled" in r.accepted, false);
  assert.ok(r.refused.length >= 4);
});

test("frozenCcMode false refused (desk money-machine lock)", () => {
  const r = sanitizeConfigPatch({ frozenCcMode: false, paperMode: true });
  assert.equal("frozenCcMode" in r.accepted, false);
  assert.equal(r.accepted.paperMode, true);
  assert.ok(r.refused.some(x => x.key === "frozenCcMode"));
  assert.match(r.refused.find(x => x.key === "frozenCcMode")!.reason, /money-machine/);
});

test("frozenCcMode true is a pass-through", () => {
  const r = sanitizeConfigPatch({ frozenCcMode: true });
  assert.equal(r.accepted.frozenCcMode, true);
  assert.equal(r.refused.some(x => x.key === "frozenCcMode"), false);
});


test("P0: frozenCcMode never silently dropped from sanitizeConfigPatch", () => {
  const on = sanitizeConfigPatch({ frozenCcMode: true, paperMode: true, minConfidence: 1 });
  assert.equal(on.accepted.frozenCcMode, true);
  assert.equal(on.refused.some(r => r.key === "frozenCcMode"), false);
  assert.equal(on.accepted.paperMode, true);

  // false refused (not merged) — so a true desk cannot be silently flipped off
  const off = sanitizeConfigPatch({ frozenCcMode: false, paperMode: true });
  assert.equal("frozenCcMode" in off.accepted, false);
  assert.ok(off.refused.some(r => r.key === "frozenCcMode"));

  // Non-strict values refused — must not overwrite live true with coerced false
  const loose = sanitizeConfigPatch({ frozenCcMode: "true" as unknown as boolean });
  assert.equal("frozenCcMode" in loose.accepted, false);
  assert.ok(loose.refused.some(r => r.key === "frozenCcMode"));

  const siblings = sanitizeConfigPatch({
    frozenCcMode: true,
    frozenCcFixedContracts: 2,
    frozenCcTakeProfitCents: null,
    frozenCcCatastrophicCents: 5,
  });
  assert.equal(siblings.accepted.frozenCcMode, true);
  assert.equal(siblings.accepted.frozenCcFixedContracts, 2);
  assert.equal(siblings.accepted.frozenCcCatastrophicCents, 5);
});
