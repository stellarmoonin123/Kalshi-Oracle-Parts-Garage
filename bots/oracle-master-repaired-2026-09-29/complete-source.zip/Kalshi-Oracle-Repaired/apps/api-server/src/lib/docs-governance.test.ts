import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(here, "../../../..");

function readRepo(rel: string): string {
  return fs.readFileSync(path.join(repoRoot, rel), "utf8");
}

function existsRepo(rel: string): boolean {
  return fs.existsSync(path.join(repoRoot, rel));
}

function markdownLinks(markdown: string): string[] {
  const out: string[] = [];
  const re = /\[[^\]]*\]\(([^)]+)\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(markdown))) {
    const href = m[1].split(/\s+/)[0];
    if (!href || href.startsWith("http") || href.startsWith("#") || href.startsWith("mailto:")) continue;
    out.push(href);
  }
  return out;
}

function resolveLink(fromRel: string, href: string): string {
  const fromDir = path.dirname(path.join(repoRoot, fromRel));
  return path.normalize(path.join(fromDir, href.split("#")[0]));
}

function strategyIdsFromLibrary(): Set<string> {
  const src = readRepo("apps/api-server/src/lib/strategy-library.ts");
  const block = src.match(/export type StrategyId\s*=\s*([\s\S]*?);/);
  assert.ok(block, "StrategyId union not found");
  const ids = [...block[1].matchAll(/'([A-Z0-9_]+)'/g)].map((x) => x[1]);
  assert.ok(ids.length >= 20, "too few StrategyId members");
  return new Set(ids);
}

function strategyComponentsFromRegistry(markdown: string): string[] {
  const ids: string[] = [];
  for (const line of markdown.split("\n")) {
    if (!line.startsWith("|")) continue;
    const cols = line.split("|").map((c) => c.trim());
    if (cols.length < 5) continue;
    if (cols[3] !== "strategy") continue;
    if (cols[2] === "Component") continue;
    ids.push(cols[2]);
  }
  return ids;
}

const required = [
  "README.md",
  "AGENTS.md",
  "docs/START_HERE.md",
  "docs/PROJECT_STATE.md",
  "docs/LANDMINES.md",
  "docs/03_TRADING_SYSTEM_FOR_BEGINNERS.md",
  "docs/development/AGENT_INSTRUCTIONS.md",
  "docs/development/SAFE_CHANGE_PROTOCOL.md",
  "docs/development/DEFINITION_OF_DONE.md",
  "docs/analysis/ANALYSIS_COMPONENT_REGISTRY.md",
  "docs/analysis/MISSING_ANALYSIS_COMPONENTS.md",
  "docs/tracking/BUG_TRACKER.md",
  "docs/tracking/BUG_FIX_LOG.md",
  "docs/tracking/FEATURE_BACKLOG.md",
  "docs/tracking/DECISION_LOG.md",
];

test("required governance files exist", () => {
  for (const rel of required) {
    assert.ok(existsRepo(rel), `missing ${rel}`);
  }
});

test("README is not the clean-tree cwd lie", () => {
  const readme = readRepo("README.md");
  assert.doesNotMatch(readme, /kalshi-oracle\/clean/);
});

test("START_HERE and AGENTS relative links resolve to files", () => {
  for (const rel of ["docs/START_HERE.md", "AGENTS.md"]) {
    const md = readRepo(rel);
    for (const href of markdownLinks(md)) {
      const abs = resolveLink(rel, href);
      assert.ok(fs.existsSync(abs), `broken link in ${rel}: ${href} -> ${abs}`);
    }
  }
});

test("AGENTS describes wired Chat and forbids leftover runTool update_config", () => {
  const agents = readRepo("AGENTS.md");
  assert.match(agents, /POST \/api\/agent\/chat/);
  assert.match(agents, /routes\/agent\.ts/);
  assert.match(agents, /oracle-desk-chat/);
  assert.match(agents, /do not rewrite/i);
  assert.match(agents, /trading-bot\.ts/);
  assert.match(agents, /Do not instruct agents to call `update_config` via leftover `runTool`/);
});

test("AGENTS links the three development files", () => {
  const agents = readRepo("AGENTS.md");
  for (const p of [
    "docs/development/AGENT_INSTRUCTIONS.md",
    "docs/development/SAFE_CHANGE_PROTOCOL.md",
    "docs/development/DEFINITION_OF_DONE.md",
  ]) {
    assert.match(agents, new RegExp(p.replaceAll(".", "\\.")));
    assert.ok(existsRepo(p), p);
  }
});

test("SAFE_CHANGE_PROTOCOL treats Chat patch as existing and not the Cursor workflow", () => {
  const proto = readRepo("docs/development/SAFE_CHANGE_PROTOCOL.md");
  assert.match(proto, /apply_patch/);
  assert.match(proto, /not\*\* the approved Cursor workflow|not the approved Cursor workflow/i);
  assert.doesNotMatch(proto, /set `paperMode: false` to/i);
});

test("agent instructions never tell an agent to verify live by disabling paper", () => {
  for (const rel of [
    "AGENTS.md",
    "docs/development/AGENT_INSTRUCTIONS.md",
    "docs/development/SAFE_CHANGE_PROTOCOL.md",
    "docs/development/DEFINITION_OF_DONE.md",
  ]) {
    const text = readRepo(rel);
    assert.match(text, /Never set `paperMode: false`|no `paperMode: false`/i);
  }
});

test("DEFINITION_OF_DONE cites default proof commands not a ten-level pyramid", () => {
  const dod = readRepo("docs/development/DEFINITION_OF_DONE.md");
  assert.match(dod, /test:api/);
  assert.match(dod, /test:dashboard/);
  assert.match(dod, /typecheck/);
  assert.match(dod, /ten-level|Not required/i);
});

test("beginners walkthrough follows AE2 and names TradingBot", () => {
  const doc = readRepo("docs/03_TRADING_SYSTEM_FOR_BEGINNERS.md");
  for (const h of [
    "## Observe",
    "## Validate",
    "## Evaluate",
    "## Skip or size",
    "## Paper fill",
    "## Monitor",
    "## Settle",
    "## Learn",
  ]) {
    assert.ok(doc.includes(h), `missing ${h}`);
  }
  assert.match(doc, /TradingBot/);
  assert.match(doc, /SKIP is a successful decision/);
  assert.match(doc, /Golden Egg is a \*\*review method/);
  assert.match(doc, /paper ledger/);
  assert.match(doc, /settlement/i);
  assert.doesNotMatch(doc, /live trading is enabled/i);
  assert.doesNotMatch(doc, /hourly\/perps UI is the product/i);
});

test("registry strategy rows match StrategyId; fake id fails the parser", () => {
  const union = strategyIdsFromLibrary();
  const registry = readRepo("docs/analysis/ANALYSIS_COMPONENT_REGISTRY.md");
  const components = strategyComponentsFromRegistry(registry);
  assert.equal(components.length, union.size, `expected ${union.size} strategy rows, got ${components.length}`);
  for (const id of components) {
    assert.ok(union.has(id), `registry strategy not in StrategyId: ${id}`);
  }
  const fake = strategyComponentsFromRegistry(
    "| ANA-S-99 | NOT_A_REAL_STRATEGY | strategy | wired | x | y | z |\n",
  );
  assert.deepEqual(fake, ["NOT_A_REAL_STRATEGY"]);
  assert.equal(union.has(fake[0]), false);
});

test("registry states last-verified and forbids numeric effectiveness scores", () => {
  const registry = readRepo("docs/analysis/ANALYSIS_COMPONENT_REGISTRY.md");
  assert.match(registry, /Last verified against code/i);
  assert.doesNotMatch(registry, /\b\d+(?:\.\d+)?\/10\b/);
});

test("trackers exist, start empty, and DECISION_LOG can be revisited", () => {
  const bugs = readRepo("docs/tracking/BUG_TRACKER.md");
  const open = bugs.split("## Open")[1] ?? "";
  assert.doesNotMatch(open, /BUG-\d+/);
  const features = readRepo("docs/tracking/FEATURE_BACKLOG.md");
  assert.doesNotMatch(features, /FEATURE-00/);
  assert.doesNotMatch(features, /ENABLE_STRATEGY/);
  const decisions = readRepo("docs/tracking/DECISION_LOG.md");
  assert.match(decisions, /Conditions that would justify revisiting/i);
  assert.match(readRepo("docs/START_HERE.md"), /tracking\/BUG_TRACKER\.md/);
});
