/**
 * FROZEN_CC scoreboard + shadow-gate attribution.
 *
 *   pnpm --filter @workspace/api-server exec tsx scripts/frozen-cc-report.ts [path/to/frozen-cc-ledger.jsonl]
 *
 * Prints the go/no-go summary and, for every shadow flag captured at fill,
 * the fee-net P&L of the trades WITH the flag vs WITHOUT it. This is the only
 * sanctioned way to decide whether a legacy veto (W2, HARVEST, regime block,
 * CC velocity, HTF) earns its way back into the hard funnel: it must improve
 * P&L on >= 200 settled fills, not on a story about one trade.
 */
import {
  readFrozenLedger,
  summarizeFrozenLedger,
  frozenLedgerPath,
  computePromoteVerdict,
  type FrozenLedgerCloseRow,
  type FrozenShadowFlags,
} from "../src/lib/frozen-cc.js";

const file = process.argv[2] ?? frozenLedgerPath();
const rows = readFrozenLedger(file);
const closes = rows.filter((r): r is FrozenLedgerCloseRow => r.kind === "CLOSE");
const s = summarizeFrozenLedger(rows);

const money = (c: number) => `${c >= 0 ? "+" : "-"}$${(Math.abs(c) / 100).toFixed(2)}`;

console.log(`FROZEN_CC report — ${file}`);
console.log(`ruleset ${s.ruleset} · fills ${s.fills} · settled ${s.closes} / target ${s.targetN}`);
console.log(`wins ${s.wins} · losses ${s.losses} · win rate ${s.winRate == null ? "-" : (s.winRate * 100).toFixed(1) + "%"}`);
console.log(`fee-net P&L ${money(s.pnlCents)} · mean/trade ${s.meanPnlPerTradeCents == null ? "-" : s.meanPnlPerTradeCents.toFixed(1) + "¢"}` +
  (s.ci95 ? ` · 95% CI [${s.ci95[0].toFixed(1)}, ${s.ci95[1].toFixed(1)}]¢` : ""));
console.log(`max drawdown ${money(s.maxDrawdownCents)} · second half ${s.secondHalfPnlCents == null ? "-" : money(s.secondHalfPnlCents)}`);
if (s.holdToSettlePnlCents != null) {
  console.log(`hold-to-settle counterfactual ${money(s.holdToSettlePnlCents)} · realised minus hold ${money(s.exitVsHoldCents ?? 0)}`);
}
console.log(`VERDICT: ${s.verdict}${s.reasons.length ? " — " + s.reasons.join("; ") : ""}`);

const promote = computePromoteVerdict(rows);
console.log(`\nPhase C scoreboard: n_unique=${promote.scoreboard.nUnique} · label=${promote.scoreboardLabel}`);
console.log(`  at40=${promote.scoreboard.at40} · at100=${promote.scoreboard.at100} · at200=${promote.scoreboard.at200}`);
console.log(`  readyToPromote=${promote.readyToPromote} · goNoGo=${promote.goNoGo}`);
if (promote.shadowShortlistBlocked) {
  console.log(`\nShadow shortlist: BLOCKED — ${promote.shadowShortlistReason}`);
} else {
  const g = promote.shadowShortlist[0]!;
  console.log(`\nShadow shortlist (1 flag): ${g.gate} · ${g.verdict} · nWith=${g.nWith} nWithout=${g.nWithout}`);
}

if (closes.length === 0) process.exit(0);

console.log("\nExit reasons:");
const byExit = new Map<string, { n: number; pnl: number }>();
for (const c of closes) {
  const k = c.exitReason;
  const e = byExit.get(k) ?? { n: 0, pnl: 0 };
  e.n += 1; e.pnl += c.pnlCents;
  byExit.set(k, e);
}
for (const [k, v] of [...byExit.entries()].sort((a, b) => b[1].n - a[1].n)) {
  console.log(`  ${k.padEnd(26)} n=${String(v.n).padStart(4)}  ${money(v.pnl)}`);
}

const shadowWould = closes.filter((c) => c.shadowExitWouldSell);
if (shadowWould.length) {
  const pnl = shadowWould.reduce((a, c) => a + c.pnlCents, 0);
  console.log(`\nLegacy PATH_RIDE would have sold early on ${shadowWould.length} trades; holding them netted ${money(pnl)}.`);
  const byReason = new Map<string, { n: number; pnl: number; wins: number }>();
  for (const c of shadowWould) {
    const k = c.shadowExitWouldSell!;
    const e = byReason.get(k) ?? { n: 0, pnl: 0, wins: 0 };
    e.n += 1; e.pnl += c.pnlCents; if (c.outcome === "win") e.wins += 1;
    byReason.set(k, e);
  }
  for (const [k, v] of byReason) {
    console.log(`  ${k.padEnd(26)} n=${String(v.n).padStart(4)}  held-to-settle ${money(v.pnl)}  (${v.wins} of ${v.n} settled as wins)`);
  }
}

console.log("\nShadow-gate attribution (fee-net P&L WITH flag vs WITHOUT):");
const boolFlags: (keyof FrozenShadowFlags)[] = [
  "harvestWouldSuppress", "regimeWouldBlock", "htfWouldBlock", "lagProven", "lagStale", "constructedNo",
];
const split = (pred: (sh: FrozenShadowFlags) => boolean | null) => {
  const on = closes.filter((c) => pred(c.shadow) === true);
  const off = closes.filter((c) => pred(c.shadow) === false);
  const sum = (xs: FrozenLedgerCloseRow[]) => xs.reduce((a, c) => a + c.pnlCents, 0);
  const wr = (xs: FrozenLedgerCloseRow[]) => xs.length ? (xs.filter((c) => c.outcome === "win").length / xs.length * 100).toFixed(0) + "%" : "-";
  return `WITH n=${String(on.length).padStart(4)} ${money(sum(on)).padStart(9)} wr ${wr(on).padStart(4)} | WITHOUT n=${String(off.length).padStart(4)} ${money(sum(off)).padStart(9)} wr ${wr(off).padStart(4)}`;
};
for (const f of boolFlags) {
  console.log(`  ${String(f).padEnd(26)} ${split((sh) => (typeof sh[f] === "boolean" ? (sh[f] as boolean) : null))}`);
}
console.log(`  ${"w2 SKIP".padEnd(26)} ${split((sh) => sh.w2Kind == null ? null : sh.w2Kind === "SKIP")}`);
console.log(`  ${"ccVelocityWouldBlock".padEnd(26)} ${split((sh) => sh.ccVelocityWouldBlock == null ? false : true)}`);
console.log(`  ${"sessionMode HARVEST".padEnd(26)} ${split((sh) => sh.sessionMode == null ? null : sh.sessionMode === "HARVEST")}`);

console.log("\nBy ask band:");
const bands: [number, number][] = [[28, 35], [36, 41], [42, 47], [53, 55]];
for (const [lo, hi] of bands) {
  const xs = closes.filter((c) => c.askCents >= lo && c.askCents <= hi);
  const pnl = xs.reduce((a, c) => a + c.pnlCents, 0);
  const wins = xs.filter((c) => c.outcome === "win").length;
  console.log(`  ${`${lo}-${hi}¢`.padEnd(8)} n=${String(xs.length).padStart(4)}  ${money(pnl).padStart(9)}  wr ${xs.length ? (wins / xs.length * 100).toFixed(0) + "%" : "-"}`);
}
console.log("\nBy side:");
for (const side of ["yes", "no"] as const) {
  const xs = closes.filter((c) => c.side === side);
  const pnl = xs.reduce((a, c) => a + c.pnlCents, 0);
  console.log(`  ${side.toUpperCase().padEnd(8)} n=${String(xs.length).padStart(4)}  ${money(pnl).padStart(9)}`);
}
