/**
 * fetch-retry.ts — small bounded retry wrapper for transient network
 * failures on read-only status checks (e.g. polling Kalshi order status).
 *
 * Deliberately conservative: a handful of short-delay attempts, each with its
 * own timeout, so a single dropped packet doesn't leave a trade's fill status
 * unresolved. Never retries on a definitive HTTP response (2xx/4xx/5xx) —
 * only on network-level failures (fetch throwing, e.g. DNS/reset/timeout).
 * Callers still decide what to do with an ok:false response themselves.
 */

export interface RetryOptions {
  attempts?:    number;   // total attempts including the first
  timeoutMs?:   number;   // per-attempt AbortSignal.timeout
  backoffMs?:   number[]; // delay before each retry, indexed by attempt number (0-based, excludes the first)
}

const DEFAULT_BACKOFF = [500, 1_000];

/**
 * Fetch with a bounded number of retries on network-level failure only.
 * Returns the first successful Response (any HTTP status) or throws the last
 * network error if every attempt failed to even get a response.
 */
export async function fetchWithRetry(
  url: string,
  init: RequestInit,
  opts: RetryOptions = {},
): Promise<Response> {
  const attempts  = opts.attempts ?? 3;
  const timeoutMs = opts.timeoutMs ?? 4_000;
  const backoff   = opts.backoffMs ?? DEFAULT_BACKOFF;

  let lastErr: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fetch(url, { ...init, signal: AbortSignal.timeout(timeoutMs) });
    } catch (err) {
      lastErr = err;
      if (i < attempts - 1) {
        const delay = backoff[Math.min(i, backoff.length - 1)] ?? 500;
        await new Promise(r => setTimeout(r, delay));
      }
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error(String(lastErr));
}
