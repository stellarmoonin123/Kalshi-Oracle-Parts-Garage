/**
 * kxbtc15m-specialist — product-specific common sense for KXBTC15M.
 *
 * Pure. No network. No LLM. Never placeOrder. Never cuts floors
 * (EV≥3¢ / Kelly≤0.60 / ask 20–55 / 9% / reserve 15%).
 * CC_VEL soft heave only (n≪40). Compose with phd-trading-education,
 * settle-side, captain, selfDrive, oracleV2, heartbeat — do not rip out.
 *
 * Settlement: short-window average of named real-time index — NOT a
 * single-exchange last tick. Desk live-btc-proxy avg60s is PROXY not
 * official CF BRTI — if proxy/lag missing → heave (do NOT invent BRTI edge;
 * do NOT enable BRTI_PROBABILITY).
 */
import { isKxbct15mTicker } from "../15m-product.js";
import {
  evaluatePhdCommonSense,
  type PhdEducationResult,
} from "./phd-trading-education.js";

export const KXBTC15M_SPECIALIST_LOADED = "KXBTC15M_SPECIALIST_LOADED" as const;

/** Match brain horizon: early >600, mid ≥180, late <180. */
export const KXBTC15M_PHASE_EARLY_SECS = 600 as const;
export const KXBTC15M_PHASE_LATE_SECS = 180 as const;

/** Soft basis heave threshold (¢) when lag unproven. */
export const KXBTC15M_BASIS_RISK_CENTS = 40 as const;

export const KXBTC15M_FLOOR_NOTE =
  "floors intact: EV≥3¢ Kelly≤0.60 ask20–55 9% reserve15% — never cut; CC_VEL soft heave only (n≪40); no BRTI_PROBABILITY" as const;

export type Kxbct15mPhase = "early" | "mid" | "late" | "unknown";

export type Kxbct15mCheckSeverity = "heave" | "warn";

export type Kxbct15mCheckId =
  | "not_15m_product"
  | "late_candle_new_take"
  | "missing_settlement_proxy"
  | "basis_or_lag_stale"
  | "spot_index_basis_risk"
  | "wrong_side_vel_15m"
  | "mtf_bull_red_vel_yes"
  | "settle_disagree"
  | "thin_edge_15m"
  | "open_yes_settle_no";

export type Kxbct15mCheck = {
  id: Kxbct15mCheckId;
  fired: boolean;
  severity: Kxbct15mCheckSeverity;
  detail: string;
};

export type Kxbct15mSpecialistInput = {
  ticker?: string | null;
  /** Candle secs remaining (15m ≈ 900). */
  secsRemaining?: number | null;
  /** Prefer brain horizon.phase when present. */
  horizonPhase?: Kxbct15mPhase | null;
  soleDecision?: string | null;
  side?: "yes" | "no" | null;
  /** CC_VEL_AGAINST_YES / CC_VEL_AGAINST_NO / null */
  ccVel?: string | null;
  mtfBullRed?: boolean | null;
  settleSide?: "yes" | "no" | "skip" | null;
  lagStale?: boolean | null;
  lagProven?: boolean | null;
  /**
   * True when live-btc-proxy / index freshness present.
   * Proxy ≠ official CF BRTI. null + no lag fields → treat as missing.
   */
  settlementProxyPresent?: boolean | null;
  /** |spot − settlementProxy| or path-vs-strike cents. */
  basisCents?: number | null;
  pWin?: number | null;
  askCents?: number | null;
  evCents?: number | null;
  openSide?: "yes" | "no" | null;
  /** Optional precomputed phd education (thin_edge delegates). */
  phdEducation?: Pick<
    PhdEducationResult,
    "heaveTo" | "heaveReasons" | "checks"
  > | null;
};

export type Kxbct15mSpecialistResult = {
  schema: "kxbtc15m_specialist_v1";
  productOk: boolean;
  phase: Kxbct15mPhase;
  checks: Kxbct15mCheck[];
  heaveTo: boolean;
  heaveReasons: string[];
  abandonLean: boolean;
  notes: string[];
  summary: string;
  floorNote: typeof KXBTC15M_FLOOR_NOTE;
};

function finite(n: number | null | undefined): n is number {
  return typeof n === "number" && Number.isFinite(n);
}

function isTakeSole(sole: string | null | undefined): boolean {
  if (!sole) return false;
  const u = String(sole).toUpperCase();
  return (
    u === "TAKE" ||
    u.startsWith("TAKE_") ||
    u === "BUY_YES" ||
    u === "BUY_NO" ||
    u === "SAIL_YES" ||
    u === "SAIL_NO"
  );
}

function isHoldOrExit(sole: string | null | undefined): boolean {
  if (!sole) return false;
  const u = String(sole).toUpperCase();
  return (
    u === "HOLD" ||
    u.startsWith("HOLD") ||
    u === "EXIT" ||
    u.startsWith("EXIT")
  );
}

function parseVelAgainst(ccVel: string | null | undefined): "yes" | "no" | null {
  if (!ccVel) return null;
  if (ccVel === "CC_VEL_AGAINST_YES" || /AGAINST_YES/i.test(ccVel)) return "yes";
  if (ccVel === "CC_VEL_AGAINST_NO" || /AGAINST_NO/i.test(ccVel)) return "no";
  return null;
}

/** Phase from secsRemaining — matches brain buildHorizonPosture. */
export function kxbct15mPhaseFromSecs(
  secsRemaining: number | null | undefined,
): Kxbct15mPhase {
  if (!(typeof secsRemaining === "number" && Number.isFinite(secsRemaining))) {
    return "unknown";
  }
  if (secsRemaining > KXBTC15M_PHASE_EARLY_SECS) return "early";
  if (secsRemaining >= KXBTC15M_PHASE_LATE_SECS) return "mid";
  return "late";
}

/**
 * Evaluate KXBTC15M specialist gates. Soft heave / abandon lean only.
 * Non-15m → heave. Missing settlement proxy → heave (fail-closed).
 */
export function evaluateKxbct15mSpecialist(
  input: Kxbct15mSpecialistInput,
): Kxbct15mSpecialistResult {
  const productOk = isKxbct15mTicker(input.ticker ?? null);
  const phase: Kxbct15mPhase =
    input.horizonPhase === "early" ||
    input.horizonPhase === "mid" ||
    input.horizonPhase === "late" ||
    input.horizonPhase === "unknown"
      ? input.horizonPhase
      : kxbct15mPhaseFromSecs(input.secsRemaining);

  const side = input.side === "yes" || input.side === "no" ? input.side : null;
  const settle =
    input.settleSide === "yes" ||
    input.settleSide === "no" ||
    input.settleSide === "skip"
      ? input.settleSide
      : null;
  const openSide =
    input.openSide === "yes" || input.openSide === "no" ? input.openSide : null;
  const sole = input.soleDecision ?? null;
  const taking = isTakeSole(sole) || (side != null && !isHoldOrExit(sole));
  const against = parseVelAgainst(input.ccVel ?? null);

  const notes: string[] = [
    "settlement = named-index short-window avg (proxy≠official CF BRTI)",
    "PATH_RIDE_TP can mask wrong side — settle outcome trains side skill",
    "ask door 20–55; fee+slip (default 2¢) before edge",
  ];

  const checks: Kxbct15mCheck[] = [];

  // 1. not_15m_product
  {
    const fired = !productOk;
    checks.push({
      id: "not_15m_product",
      fired,
      severity: "heave",
      detail: fired
        ? `ticker=${input.ticker ?? "∅"} not KXBTC15M — refuse / HEAVE`
        : "product KXBTC15M ok",
    });
    if (fired) notes.push("non-15m series refused");
  }

  // 2. late_candle_new_take — late + TAKE → heave (HOLD/EXIT ok)
  {
    const fired =
      productOk && phase === "late" && taking && !isHoldOrExit(sole);
    checks.push({
      id: "late_candle_new_take",
      fired,
      severity: "heave",
      detail: fired
        ? `late candle (tte=${input.secsRemaining ?? "?"}) new TAKE worldview — leftover/misprice or HEAVE; exit liq must exist NOW`
        : phase === "late"
          ? `late candle but sole=${sole ?? "none"} — HOLD/EXIT ok`
          : `phase=${phase} — not late new-take`,
    });
  }

  // 3. missing_settlement_proxy
  {
    const proxyMissing =
      input.settlementProxyPresent === false ||
      (input.settlementProxyPresent == null &&
        input.lagStale == null &&
        input.lagProven == null);
    const fired = productOk && taking && proxyMissing;
    checks.push({
      id: "missing_settlement_proxy",
      fired,
      severity: "heave",
      detail: fired
        ? "no lag/index/proxy freshness — MISSING settlement proxy; raise uncertainty / HEAVE (do not invent BRTI edge)"
        : "settlement proxy / lag fields present or not taking",
    });
  }

  // 4. basis_or_lag_stale
  {
    const fired = productOk && taking && input.lagStale === true;
    checks.push({
      id: "basis_or_lag_stale",
      fired,
      severity: "heave",
      detail: fired
        ? "lagStale — basis/lag fail-closed HEAVE"
        : "lag not stale",
    });
  }

  // 5. spot_index_basis_risk
  {
    const basis = finite(input.basisCents) ? Math.abs(input.basisCents) : null;
    const unproven = input.lagProven !== true;
    const fired =
      productOk &&
      taking &&
      basis != null &&
      basis >= KXBTC15M_BASIS_RISK_CENTS &&
      unproven;
    checks.push({
      id: "spot_index_basis_risk",
      fired,
      severity: "heave",
      detail:
        basis != null
          ? fired
            ? `basis=${basis}¢ ≥ ${KXBTC15M_BASIS_RISK_CENTS}¢ without proven lag — spot vs settlement proxy can erase edge`
            : `basis=${basis}¢ lagProven=${input.lagProven === true}`
          : "basis cents not provided",
    });
  }

  // 6. wrong_side_vel_15m
  {
    const fired =
      productOk && taking && against != null && side != null && against === side;
    checks.push({
      id: "wrong_side_vel_15m",
      fired,
      severity: "heave",
      detail: fired
        ? `CC_VEL against ${side} (${input.ccVel}) — soft heave (n≪40 observe)`
        : against
          ? `vel against ${against} side=${side ?? "none"}`
          : "no CC_VEL_AGAINST on proposed side",
    });
  }

  // 7. mtf_bull_red_vel_yes
  {
    const fired =
      productOk && taking && input.mtfBullRed === true && side === "yes";
    checks.push({
      id: "mtf_bull_red_vel_yes",
      fired,
      severity: "heave",
      detail: fired
        ? "YES + MTF bull into red 1m vel — refuse sail (15m scar)"
        : "no mtf_bull_red_vel_yes on YES",
    });
  }

  // 8. settle_disagree
  {
    const fired =
      productOk &&
      taking &&
      side != null &&
      settle != null &&
      settle !== "skip" &&
      settle !== side;
    checks.push({
      id: "settle_disagree",
      fired,
      severity: "heave",
      detail: fired
        ? `settle pick=${settle} ≠ side=${side} — soft HEAVE`
        : `settle=${settle ?? "n/a"} side=${side ?? "n/a"}`,
    });
  }

  // 9. thin_edge_15m — delegate/mirror phd thinEdgeAfterSlip
  {
    let fired = false;
    let detail = "thin edge not evaluated / inputs missing";
    if (productOk && taking) {
      const phd: Pick<PhdEducationResult, "heaveTo" | "heaveReasons" | "checks"> =
        input.phdEducation ??
        evaluatePhdCommonSense({
          pWin: input.pWin,
          askCents: input.askCents,
          side,
          ccVel: input.ccVel,
          mtfBullRed: input.mtfBullRed,
          settleSide: settle,
          evCents: input.evCents,
          soleDecision: sole,
          slipDefaultCents: 2,
          openSide: openSide,
        });
      const thin = (phd.checks ?? []).find((c) => c.id === "thinEdgeAfterSlip");
      if (thin?.fired) {
        fired = true;
        detail = `phd thinEdgeAfterSlip: ${thin.detail}`;
      } else {
        const hit = (phd.heaveReasons ?? []).find((r) =>
          /thinEdgeAfterSlip/i.test(r),
        );
        if (hit) {
          fired = true;
          detail = hit;
        } else {
          detail = "phd thinEdgeAfterSlip clear or not applicable";
        }
      }
    }
    checks.push({
      id: "thin_edge_15m",
      fired,
      severity: "heave",
      detail,
    });
  }

  // 10. open_yes_settle_no → abandonLean
  {
    const fired =
      productOk &&
      (openSide === "yes" || (side === "yes" && isHoldOrExit(sole))) &&
      settle === "no";
    checks.push({
      id: "open_yes_settle_no",
      fired,
      severity: "warn",
      detail: fired
        ? "open YES + settle lean NO — abandonLean (hold-wrong-side scar)"
        : "no open-YES-into-settle-NO risk",
    });
  }

  const heaveReasons: string[] = [];
  for (const c of checks) {
    if (c.fired && c.severity === "heave") {
      heaveReasons.push(`${c.id}: ${c.detail}`);
    }
  }
  const abandonLean = checks.some(
    (c) => c.id === "open_yes_settle_no" && c.fired,
  );
  const heaveTo = heaveReasons.length > 0;
  const firedIds = checks.filter((c) => c.fired).map((c) => c.id);
  const summary = !productOk
    ? "HEAVE — not KXBTC15M"
    : heaveTo
      ? `HEAVE_TO — ${firedIds.slice(0, 3).join(", ")}${abandonLean ? " (+abandonLean)" : ""}`
      : abandonLean
        ? "ABANDON lean — open_yes_settle_no; sail ok if flat"
        : firedIds.length
          ? `warn — ${firedIds.join(", ")}`
          : `clear — ${phase} KXBTC15M specialist allows sail (floors still bind)`;

  return {
    schema: "kxbtc15m_specialist_v1",
    productOk,
    phase,
    checks,
    heaveTo,
    heaveReasons: heaveReasons.slice(0, 8),
    abandonLean,
    notes,
    summary,
    floorNote: KXBTC15M_FLOOR_NOTE,
  };
}
