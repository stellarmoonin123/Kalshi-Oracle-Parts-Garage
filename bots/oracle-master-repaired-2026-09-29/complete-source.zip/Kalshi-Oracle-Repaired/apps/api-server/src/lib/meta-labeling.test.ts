import assert from "node:assert/strict";
import test from "node:test";
import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import {
  buildMetaFeatures,
  computeMetaLabel,
  computeStrictMetaLabel,
  getMetaExamples,
  JsonlMetaStore,
  recordSkippedMetaExample,
  type MetaExample,
} from "./meta-labeling.js";

const example = (outcome?: MetaExample["outcome"]): MetaExample => ({
  id: "test-example",
  createdAt: 0,
  features: {} as MetaExample["features"],
  outcome,
});

test("unreliable or missing outcomes are not positive training labels", () => {
  assert.deepEqual(computeMetaLabel(example()), {
    label: 0,
    reason: "unreliable or missing outcome",
  });
  assert.deepEqual(computeMetaLabel(example({
    wasTaken: true,
    pnlCents: 10,
    outcomeSource: "HEURISTIC",
    isReliableForLearning: false,
  })), {
    label: 0,
    reason: "unreliable or missing outcome",
  });
});

test("default label uses net PnL and requires strictly positive profit", () => {
  assert.equal(computeMetaLabel(example({
    wasTaken: true,
    pnlCents: 0,
    outcomeSource: "OFFICIAL_SETTLEMENT",
    isReliableForLearning: true,
  })).label, 0);
  assert.deepEqual(computeMetaLabel(example({
    wasTaken: true,
    pnlCents: -1,
    outcomeSource: "OFFICIAL_SETTLEMENT",
    isReliableForLearning: true,
  })), {
    label: 0,
    reason: "non-positive net PnL (-1¢)",
  });
  assert.deepEqual(computeMetaLabel(example({
    wasTaken: true,
    pnlCents: 3,
    pnlAfterAllCosts: 2,
    outcomeSource: "EARLY_EXIT",
    isReliableForLearning: true,
  })), {
    label: 1,
    reason: "positive net PnL (2¢)",
  });
});

test("strict label requires the configured minimum PnL", () => {
  const oneCent = example({
    wasTaken: true,
    pnlCents: 1,
    outcomeSource: "OFFICIAL_SETTLEMENT",
    isReliableForLearning: true,
  });
  assert.deepEqual(computeStrictMetaLabel(oneCent), {
    label: 0,
    reason: "PnL 1¢ below strict threshold",
  });
  assert.deepEqual(computeStrictMetaLabel(oneCent, 1), {
    label: 1,
    reason: "PnL 1¢ ≥ 1¢ threshold",
  });
});

// ── JsonlMetaStore helper ─────────────────────────────────────────────────────

/** Create a temp-file-backed store that is isolated from the live store. */
function tempStore(): { store: JsonlMetaStore; filePath: string } {
  const filePath = path.join(os.tmpdir(), `meta-test-${randomUUID()}.jsonl`);
  const store = new JsonlMetaStore(filePath);
  return { store, filePath };
}

/** Minimal valid MetaExample (parser requires id + features). */
function makeExample(id: string, overrides: Partial<MetaExample> = {}): MetaExample {
  return {
    id,
    createdAt: Date.now(),
    features: {
      timestamp: Date.now(),
      marketTicker: "KXBTC15M-test",
      contractDurationMins: 15,
      secsRemaining: 600,
      path: "HIGH_PROB",
      regime: "range",
      session: "NY_AM",
      dayOfWeek: 1,
      hourOfDay: 10,
      strategyId: "TEST",
      direction: "YES",
      strategyConfidence: 0.65,
      preTradeScore: 70,
      entryPriceCents: 45,
      btcPrice: 100_000,
      floorStrike: 99_900,
      distFromFloorPct: 0.1,
      distFromFloorAbs: 0.1,
      velocity1m: 10,
      velocity3m: 5,
      isStalling: false,
      spreadCents: 3,
      bestBidSize: 10,
      bestAskSize: 10,
      bookImbalance: 0,
      opposingDepth: 10,
      estimatedWinRate: 0.6,
    },
    ...overrides,
  };
}

// ── New tests ─────────────────────────────────────────────────────────────────

test("malformed JSONL rows are silently skipped; valid rows are recovered", () => {
  const { store, filePath } = tempStore();
  const valid1 = makeExample("valid-1");
  const valid2 = makeExample("valid-2");
  // Write two valid rows separated by a corrupt line
  fs.writeFileSync(
    filePath,
    [JSON.stringify(valid1), "{bad json!!", JSON.stringify(valid2), ""].join("\n"),
    "utf8",
  );

  const rows = store.list();
  assert.equal(rows.length, 2, "corrupt row must be skipped, not crash");
  assert.equal(rows[0].id, "valid-1");
  assert.equal(rows[1].id, "valid-2");

  fs.unlinkSync(filePath);
});

test("save() updates an existing row by id (no duplicate created)", () => {
  const { store, filePath } = tempStore();
  const ex = makeExample("dup-test");
  store.save(ex);

  // Update with a new field value — same ID
  store.save({ ...ex, metaLabelReason: "updated" });

  const rows = store.list();
  assert.equal(rows.length, 1, "upsert must not create a second row");
  assert.equal(rows[0].metaLabelReason, "updated");

  fs.unlinkSync(filePath);
});

test("reliableOnly filter keeps only rows with authoritative labels and a labeledAt timestamp", () => {
  // Test the exact filter predicate used by getMetaExamples({ reliableOnly: true }).
  const reliableOutcome = {
    wasTaken: true as const,
    outcomeSource: "OFFICIAL_SETTLEMENT" as const,
    isReliableForLearning: true,
  };
  const unreliableOutcome = {
    wasTaken: true as const,
    outcomeSource: "HEURISTIC" as const,
    isReliableForLearning: false,
  };

  const rows: MetaExample[] = [
    makeExample("r1", { outcome: reliableOutcome, labeledAt: 1_000 }),
    makeExample("r2", { outcome: unreliableOutcome }),                   // not reliable
    makeExample("r3", { outcome: reliableOutcome }),                     // reliable but no labeledAt yet
    makeExample("r4", { outcome: reliableOutcome, labeledAt: 2_000 }),
  ];

  // Apply the same predicate getMetaExamples uses for reliableOnly
  const reliable = rows.filter(r => r.outcome?.isReliableForLearning && r.labeledAt);

  assert.equal(reliable.length, 2);
  assert.ok(reliable.every(r => r.outcome?.isReliableForLearning), "all returned rows must be reliable");
  assert.ok(reliable.every(r => r.labeledAt), "all returned rows must have a label timestamp");
  assert.ok(!reliable.some(r => r.id === "r2"), "heuristic row must be excluded");
  assert.ok(!reliable.some(r => r.id === "r3"), "unlabeled row must be excluded");
});

test("skipped decisions are explicitly unreliable and excluded from reliableOnly results", () => {
  const { store, filePath } = tempStore();
  const features = makeExample("skipped").features;

  const id = recordSkippedMetaExample(features, {
    reasons: ["outside entry window"],
    rejectionCode: "TIME_GATE",
  }, store);

  const all = getMetaExamples(undefined, store);
  const reliableOnly = getMetaExamples({ reliableOnly: true }, store);
  const skipped = all.find(row => row.id === id);

  assert.equal(skipped?.outcome?.isReliableForLearning, false);
  assert.equal(skipped?.outcome?.wasTaken, false);
  assert.equal(reliableOnly.some(row => row.id === id), false);

  fs.unlinkSync(filePath);
});

test("a single fill decision creates exactly one example (no duplicate on repeated save)", () => {
  const { store, filePath } = tempStore();

  // Simulate what the bot does: record decision, then attach outcome
  const ex = makeExample("fill-once");
  store.save(ex);

  // Attaching an outcome is a save() with the same id — must remain one row
  store.save({ ...ex, outcome: {
    wasTaken: true,
    exitReason: "SETTLEMENT",
    outcomeSource: "OFFICIAL_SETTLEMENT",
    isReliableForLearning: true,
    pnlCents: 5,
    pnlAfterAllCosts: 4,
    filledContracts: 1,
  }, metaLabel: 1, labeledAt: Date.now() });

  const rows = store.list();
  assert.equal(rows.length, 1, "outcome attachment must not insert a second row");
  assert.equal(rows[0].outcome?.pnlCents, 5, "outcome data must be persisted");

  fs.unlinkSync(filePath);
});

test("feature builder derives ET session, weekday, and absolute distance", () => {
  // 14:30 UTC is 10:30 ET during daylight saving time on this date.
  const features = buildMetaFeatures({
    timestamp: Date.parse("2026-08-03T14:30:00.000Z"),
    marketTicker: "KXBTC15M-test",
    contractDurationMins: 15,
    secsRemaining: 600,
    path: "HIGH_PROB",
    regime: "range",
    strategyId: "FLOOR_DISTANCE",
    direction: "YES",
    strategyConfidence: 0.65,
    preTradeScore: 70,
    entryPriceCents: 45,
    btcPrice: 100_000,
    floorStrike: 99_900,
    distFromFloorPct: -0.1,
    velocity1m: 20,
    velocity3m: 10,
    isStalling: false,
    spreadCents: 3,
    bestBidSize: 10,
    bestAskSize: 12,
    bookImbalance: -0.09,
    opposingDepth: 12,
    estimatedWinRate: 0.65,
  });
  assert.equal(features.session, "NY_AM");
  assert.equal(features.dayOfWeek, 1); // Monday in America/New_York
  assert.equal(features.hourOfDay, 10);
  assert.equal(features.distFromFloorAbs, 0.1);
});
