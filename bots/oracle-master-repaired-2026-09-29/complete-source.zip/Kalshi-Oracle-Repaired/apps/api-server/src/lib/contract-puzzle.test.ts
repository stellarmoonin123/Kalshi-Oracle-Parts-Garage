/**
 * contract-puzzle.test.ts
 *
 * Label math + stats on a tiny fixture. Shadow only.
 * +EV take cells must surface as OBSERVE (not only skip-correct).
 * Never ENABLE / CHANGE_EV_FLOOR / paperMode false / liveApply true.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  buildContractPuzzle,
  classifyAskBand,
  classifyPathClass,
  classifyTakeCells,
  holdToSettleFeeNetCents,
  puzzleLabels,
  rememberPuzzleSkip,
  rememberPuzzleTake,
  recordPuzzleOnSettlement,
  resetPuzzleForTests,
  logGrowthFromFeeNet,
} from "./contract-puzzle.js";
import { kalshiFeeCents } from "./constants.js";
import {
  aggregatePuzzles,
  wilsonInterval,
  renderPuzzleStatsMd,
  teachStrategyProposals,
  teachShadowLearn,
  type PuzzleStats,
} from "./contract-puzzle-stats.js";
import type { ContractPuzzle, PuzzleFeatures } from "./contract-puzzle.js";

const PUZZLE_HTF: PuzzleFeatures["htfStructure"] = {
  channelPos: "unknown",
  nearestSupport: null,
  nearestResist: null,
  biasFor15m: "UNKNOWN",
  mtfScore: null,
  freshness: "missing",
};

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "contract-puzzle-"));
process.env.KALSHI_RESEARCH_DIR = tmp;
process.env.CONTRACT_PUZZLE_PATH = path.join(tmp, "contract-puzzles.jsonl");
process.env.SKIP_SETTLEMENT_TAPE_PATH = path.join(tmp, "shadow-tape.jsonl");
process.env.CONTRACT_PUZZLE_STATS_PATH = path.join(tmp, "contract-puzzle-stats.json");
process.env.CONTRACT_PUZZLE_STATS_MD_PATH = path.join(tmp, "contract-puzzle-stats.md");

// Satisfy the named import used only to prove we did not invent a 4th fee formula.
test("hold-to-settle fee-net: 20¢ YES win / loss vs skip=0", () => {
  // Official FEE ORGAN: 0.07*C*P*(1-P)*100 → ceil → cents. NOT min(P,1-P)×7%.
  // P=0.20 → raw 1.12¢ → ceil → 2¢.
  const fee = kalshiFeeCents(20);
  assert.equal(fee, 2);
  const win = holdToSettleFeeNetCents(20, "YES", "YES");
  const loss = holdToSettleFeeNetCents(20, "YES", "NO");
  assert.ok(win != null && Math.abs(win - (80 - fee)) < 1e-9);
  assert.ok(loss != null && Math.abs(loss - (-20 - fee)) < 1e-9);
  assert.equal(holdToSettleFeeNetCents(0, "YES", "YES"), null);
  assert.equal(holdToSettleFeeNetCents(100, "YES", "YES"), null);
});

test("labels: skip beat losing take; take beat skip on +EV cheap", () => {
  const lost = puzzleLabels(-21.4, "YES", "NO");
  assert.equal(lost.sideCorrect, false);
  assert.equal(lost.settleSideCorrect, false);
  assert.equal(lost.skipCorrect, true);
  assert.equal(lost.takeCorrect, false);
  assert.equal(lost.earlyExitCorrect, null);

  const won = puzzleLabels(78.6, "YES", "YES");
  assert.equal(won.sideCorrect, true);
  assert.equal(won.settleSideCorrect, true);
  assert.equal(won.skipCorrect, false);
  assert.equal(won.takeCorrect, true);

  const unknown = puzzleLabels(null, null, "YES");
  assert.equal(unknown.sideCorrect, null);
  assert.equal(unknown.settleSideCorrect, null);
  assert.equal(unknown.skipCorrect, null);
  assert.equal(unknown.takeCorrect, null);
  assert.equal(unknown.earlyExitCorrect, null);

  // Wrong settlement side can still be an early-exit WIN. settleCorrect not required.
  const soldGreen = puzzleLabels(-21.4, "YES", "NO", 18.2);
  assert.equal(soldGreen.settleSideCorrect, false);
  assert.equal(soldGreen.takeCorrect, false);
  assert.equal(soldGreen.earlyExitCorrect, true);
});

test("path / ask band / take-cell classification", () => {
  assert.equal(classifyPathClass(20), "MULTIPLIER");
  assert.equal(classifyPathClass(40), "GRAY");
  assert.equal(classifyPathClass(53), "HIGH_PROB");
  assert.equal(classifyAskBand(9, 90), "lottery_7_12");
  assert.equal(classifyAskBand(9, 400), "cheap_7_18");
  assert.equal(classifyAskBand(20, 400), "persist_cheap_19_22");
  assert.equal(classifyAskBand(49, 400), "mid_40_65");
  assert.equal(classifyAskBand(80, 400), "rich_gt65");
  const persist = classifyTakeCells({
    askCents: 20, secsRemaining: 400, askBand: "persist_cheap_19_22",
    lagClass: "agree", ticketMotion: "moving",
  });
  assert.deepEqual(persist, ["persist-cheap", "lag-agree", "moving-ticket", "cheap-early-exit"]);
  const lottery = classifyTakeCells({
    askCents: 9, secsRemaining: 90, askBand: "lottery_7_12",
    lagClass: "stale", ticketMotion: "still",
  });
  assert.deepEqual(lottery, []);
  const htfCheap = classifyTakeCells({
    askCents: 12, secsRemaining: 400, askBand: "cheap_7_18",
    lagClass: "unknown", ticketMotion: "unknown",
    takeSide: "YES",
    htfStructure: {
      channelPos: "upper", nearestSupport: 79000, nearestResist: 81000,
      biasFor15m: "YES", mtfScore: 1, freshness: "fresh",
    },
  });
  assert.deepEqual(htfCheap, ["htf-aligned-cheap", "cheap-early-exit"]);
  const htfUnknown = classifyTakeCells({
    askCents: 12, secsRemaining: 400, askBand: "cheap_7_18",
    lagClass: "unknown", ticketMotion: "unknown",
    takeSide: "YES",
    htfStructure: {
      channelPos: "unknown", nearestSupport: null, nearestResist: null,
      biasFor15m: "UNKNOWN", mtfScore: null, freshness: "missing",
    },
  });
  assert.deepEqual(htfUnknown, ["cheap-early-exit"], "missing HTF must not invent htf-aligned-cheap");
});

test("Wilson CI contains the mean and shrinks with n", () => {
  const small = wilsonInterval(2, 3);
  const big = wilsonInterval(20, 30);
  assert.equal(small.n, 3);
  assert.equal(small.successes, 2);
  assert.ok(small.mean === 2 / 3);
  assert.ok(small.lo! < small.mean! && small.mean! < small.hi!);
  assert.ok(big.hi! - big.lo! < small.hi! - small.lo!);
  const empty = wilsonInterval(0, 0);
  assert.equal(empty.mean, null);
});

function fixturePuzzle(partial: Partial<ContractPuzzle> & { ticker: string; settled: "YES" | "NO"; botAction: "TAKE" | "SKIP" }): ContractPuzzle {
  const ask = partial.counterfactual?.takeAskCents ?? 20;
  const side = partial.counterfactual?.takeSide ?? "YES";
  const feeNet = partial.counterfactual?.takeFeeNetCents
    ?? holdToSettleFeeNetCents(ask, side, partial.settled);
  const lagClass = partial.features?.lagClass ?? "unknown";
  const ticketMotion = partial.features?.ticketMotion ?? "unknown";
  const secs = partial.features?.secsRemaining ?? 400;
  const askBand = partial.features?.askBand ?? classifyAskBand(ask, secs);
  const base: ContractPuzzle = {
    kind: "contract_puzzle",
    ticker: partial.ticker,
    floor: 80000,
    settled: partial.settled,
    botAction: partial.botAction,
    take: null,
    skip: partial.botAction === "SKIP" ? { reasonCodes: ["PATH_GATE"], lastSignal: "PATH_GATE" } : null,
    counterfactual: {
      skipFeeNetCents: 0,
      takeFeeNetCents: feeNet,
      takeAskCents: ask,
      takeSide: side,
      takeContracts: 1,
      quotesKnown: feeNet != null,
      feeCents: kalshiFeeCents(ask),
    },
    features: {
      ticketMotion,
      lagClass,
      lagSeconds: null,
      lagDollars: null,
      pathClass: classifyPathClass(ask),
      askBand,
      minutesLeft: Math.round((secs / 60) * 10) / 10,
      secsRemaining: secs,
      regime: null,
      htfStructure: {
        channelPos: "unknown",
        nearestSupport: null,
        nearestResist: null,
        biasFor15m: "UNKNOWN",
        mtfScore: null,
        freshness: "missing",
      },
      streakSaturation: null,
      takeCells: classifyTakeCells({
        askCents: ask, secsRemaining: secs,
        askBand, lagClass, ticketMotion,
      }),
    },
    earlyExit: {
      entryAsk: ask,
      maxFavorableExcursionCents: null,
      earlyExitPnLAtMfeCents: null,
      earlyExitPnLAtGreenXCents: null,
      greenXCents: 20,
      settleSideCorrect: side === partial.settled,
      quotesAfterEntry: 0,
    },
    labels: puzzleLabels(feeNet, side, partial.settled),
    liveApplyEnabled: false,
    paperMode: true,
    ts: "2026-08-28T00:00:00.000Z",
    periodOpenTs: null,
  };
  return {
    ...base,
    ...partial,
    counterfactual: { ...base.counterfactual, ...partial.counterfactual },
    features: { ...base.features, ...partial.features },
    labels: { ...base.labels, ...partial.labels },
    earlyExit: { ...base.earlyExit, ...partial.earlyExit },
  };
}

test("tiny fixture: persist-cheap +EV surfaces as OBSERVE; still-mid skip is skipCorrect; no ENABLE", () => {
  // Three persist-cheap 20¢ YES that settled YES (would-have-taken beat skip).
  const cheapWins: ContractPuzzle[] = [1, 2, 3].map(i => fixturePuzzle({
    ticker: `KXBTC15M-26AUG28000${i}-00`,
    settled: "YES",
    botAction: "SKIP",
    skip: { reasonCodes: ["EV_FAIL"], lastSignal: "EV_FAIL" },
    counterfactual: {
      skipFeeNetCents: 0,
      takeFeeNetCents: holdToSettleFeeNetCents(20, "YES", "YES"),
      takeAskCents: 20,
      takeSide: "YES",
      takeContracts: 1,
      quotesKnown: true,
      feeCents: kalshiFeeCents(20),
    },
    features: {
      ticketMotion: "unknown",
      lagClass: "agree",
      pathClass: "MULTIPLIER",
      askBand: "persist_cheap_19_22",
      minutesLeft: 6.7,
      secsRemaining: 400,
      regime: null,
      lagSeconds: null,
      lagDollars: null,
      htfStructure: PUZZLE_HTF,
      streakSaturation: null,
      takeCells: ["persist-cheap", "lag-agree"],
    },
    labels: puzzleLabels(holdToSettleFeeNetCents(20, "YES", "YES"), "YES", "YES"),
  }));
  // Two still-mid 50¢ TAKEs that settled against (skip would have been better).
  const stillLosses: ContractPuzzle[] = [4, 5].map(i => fixturePuzzle({
    ticker: `KXBTC15M-26AUG28000${i}-00`,
    settled: "NO",
    botAction: "TAKE",
    take: { strategyId: "CONFLUENCE_CASCADE", side: "YES", askCents: 50 },
    skip: { reasonCodes: ["STILL_MID"], lastSignal: "STILL_MID" },
    counterfactual: {
      skipFeeNetCents: 0,
      takeFeeNetCents: holdToSettleFeeNetCents(50, "YES", "NO"),
      takeAskCents: 50,
      takeSide: "YES",
      takeContracts: 1,
      quotesKnown: true,
      feeCents: kalshiFeeCents(50),
    },
    features: {
      ticketMotion: "still",
      lagClass: "stale",
      pathClass: "HIGH_PROB",
      askBand: "mid_40_65",
      minutesLeft: 8,
      secsRemaining: 480,
      regime: "unclear",
      lagSeconds: null,
      lagDollars: null,
      htfStructure: PUZZLE_HTF,
      streakSaturation: null,
      takeCells: [],
    },
    labels: puzzleLabels(holdToSettleFeeNetCents(50, "YES", "NO"), "YES", "NO"),
  }));

  const stats = aggregatePuzzles([...cheapWins, ...stillLosses]);
  assert.equal(stats.n, 5);
  assert.equal(stats.nTake, 2);
  assert.equal(stats.nSkip, 3);
  assert.equal(stats.liveApplyEnabled, false);
  assert.equal(stats.paperMode, true);

  // Cheap skips were +EV takes: takeCorrect on those 3.
  assert.equal(stats.takeCorrect.successes, 3);
  assert.equal(stats.skipCorrect.successes, 2); // the two still-mid losses

  const persist = stats.plusEvTakeCells.find(c => c.cell === "persist-cheap");
  assert.ok(persist);
  assert.equal(persist!.n, 3);
  assert.equal(persist!.observeCandidate, true);
  assert.equal(persist!.enable, false);
  assert.equal(persist!.liveApplyEnabled, false);
  assert.ok((persist!.meanFeeNetVsSkipCents ?? 0) > 0);

  const lagAgree = stats.plusEvTakeCells.find(c => c.cell === "lag-agree");
  assert.ok(lagAgree);
  assert.equal(lagAgree!.observeCandidate, true);

  const moving = stats.plusEvTakeCells.find(c => c.cell === "moving-ticket");
  assert.ok(moving);
  assert.equal(moving!.observeCandidate, false);

  const htfAligned = stats.plusEvTakeCells.find(c => c.cell === "htf-aligned-cheap");
  assert.ok(htfAligned);
  assert.equal(htfAligned!.n, 0, "unlabeled HTF must not populate htf-aligned-cheap");
  assert.equal(htfAligned!.observeCandidate, false);

  const evFail = stats.skipQuality.byReason["EV_FAIL"];
  assert.ok(evFail);
  assert.equal(evFail.n, 3);
  assert.equal(evFail.successes, 0, "skipping persist-cheap winners is skipIncorrect");

  assert.equal(stats.geometric.kellyF, 0.09);
  assert.equal(stats.geometric.actualSkip.meanG, 0);

  const md = renderPuzzleStatsMd(stats);
  assert.match(md, /OBSERVE/);
  assert.doesNotMatch(md, /ENABLE_STRATEGY of SEV1 as applied/);
  assert.match(md, /Never ENABLE/);
  assert.match(md, /Never cut EV/);
  assert.match(md, /persist-cheap/);
  assert.match(md, /do not claim 9\/10 P&L/);
});

test("live recorder: skip with cheap would-have-taken YES that settled YES is takeCorrect", () => {
  resetPuzzleForTests();
  rememberPuzzleSkip({
    ticker: "KXBTC15M-26AUG281200-00",
    side: "yes",
    strategyId: "CHEAP_SIDE_15M",
    rejectionCode: "EV_FAIL",
    entryPriceCents: 20,
    secsRemaining: 400,
    ts: Date.now(),
    lagClass: "agree",
  });
  const row = buildContractPuzzle({
    ticker: "KXBTC15M-26AUG281200-00",
    settled: "YES",
    quotes: { minCheapAsk: { side: "YES", price: 20 } },
  });
  assert.ok(row);
  assert.equal(row!.botAction, "SKIP");
  assert.equal(row!.liveApplyEnabled, false);
  assert.equal(row!.labels.takeCorrect, true);
  assert.equal(row!.labels.skipCorrect, false);
  assert.equal(row!.features.takeCells.includes("persist-cheap"), true);
  assert.equal(row!.features.takeCells.includes("lag-agree"), true);
});

test("live recorder: TAKE still-mid loser is skipCorrect; does not write ENABLE", () => {
  resetPuzzleForTests();
  rememberPuzzleTake({
    ticker: "KXBTC15M-26AUG281215-15",
    side: "YES",
    strategyId: "CONFLUENCE_CASCADE",
    askCents: 49,
    secsRemaining: 500,
    ts: Date.now(),
    ticketMotion: "still",
  });
  const row = recordPuzzleOnSettlement({
    ticker: "KXBTC15M-26AUG281215-15",
    settled: "NO",
  });
  assert.ok(row);
  assert.equal(row!.botAction, "TAKE");
  assert.equal(row!.labels.takeCorrect, false);
  assert.equal(row!.labels.skipCorrect, true);
  assert.equal(row!.take?.strategyId, "CONFLUENCE_CASCADE");
  const jsonl = fs.readFileSync(path.join(tmp, "contract-puzzles.jsonl"), "utf8");
  assert.match(jsonl, /KXBTC15M-26AUG281215-15/);
  assert.doesNotMatch(jsonl, /"liveApplyEnabled": true/);
});

test("idempotent: second settlement does not duplicate", () => {
  resetPuzzleForTests();
  const T = "KXBTC15M-26AUG281230-30";
  rememberPuzzleSkip({
    ticker: T, side: "no", strategyId: null, rejectionCode: "PATH_GATE",
    entryPriceCents: 40, secsRemaining: 300, ts: Date.now(),
  });
  const a = recordPuzzleOnSettlement({ ticker: T, settled: "YES" });
  const b = recordPuzzleOnSettlement({ ticker: T, settled: "YES" });
  assert.ok(a);
  assert.equal(b, null);
});

test("teach path writes OBSERVE only — no ENABLE / EV cut / paperMode false", () => {
  resetPuzzleForTests();
  const stats: PuzzleStats = aggregatePuzzles([
    fixturePuzzle({
      ticker: "KXBTC15M-26AUG281245-45",
      settled: "YES",
      botAction: "SKIP",
      features: {
        ticketMotion: "moving",
        lagClass: "agree",
        pathClass: "MULTIPLIER",
        askBand: "persist_cheap_19_22",
        minutesLeft: 7,
        secsRemaining: 420,
        regime: null,
        lagSeconds: null,
        lagDollars: null,
        htfStructure: PUZZLE_HTF,
        streakSaturation: null,
        takeCells: ["persist-cheap", "lag-agree", "moving-ticket"],
      },
      labels: puzzleLabels(78.6, "YES", "YES"),
      counterfactual: {
        skipFeeNetCents: 0, takeFeeNetCents: 78.6, takeAskCents: 20, takeSide: "YES",
        takeContracts: 1, quotesKnown: true, feeCents: 1.4,
      },
    }),
    fixturePuzzle({
      ticker: "KXBTC15M-26AUG281300-00",
      settled: "YES",
      botAction: "SKIP",
      features: {
        ticketMotion: "moving",
        lagClass: "agree",
        pathClass: "MULTIPLIER",
        askBand: "persist_cheap_19_22",
        minutesLeft: 7,
        secsRemaining: 420,
        regime: null,
        lagSeconds: null,
        lagDollars: null,
        htfStructure: PUZZLE_HTF,
        streakSaturation: null,
        takeCells: ["persist-cheap", "lag-agree", "moving-ticket"],
      },
      labels: puzzleLabels(78.6, "YES", "YES"),
      counterfactual: {
        skipFeeNetCents: 0, takeFeeNetCents: 78.6, takeAskCents: 20, takeSide: "YES",
        takeContracts: 1, quotesKnown: true, feeCents: 1.4,
      },
    }),
    fixturePuzzle({
      ticker: "KXBTC15M-26AUG281315-15",
      settled: "YES",
      botAction: "SKIP",
      features: {
        ticketMotion: "moving",
        lagClass: "agree",
        pathClass: "MULTIPLIER",
        askBand: "persist_cheap_19_22",
        minutesLeft: 7,
        secsRemaining: 420,
        regime: null,
        lagSeconds: null,
        lagDollars: null,
        htfStructure: PUZZLE_HTF,
        streakSaturation: null,
        takeCells: ["persist-cheap", "lag-agree", "moving-ticket"],
      },
      labels: puzzleLabels(78.6, "YES", "YES"),
      counterfactual: {
        skipFeeNetCents: 0, takeFeeNetCents: 78.6, takeAskCents: 20, takeSide: "YES",
        takeContracts: 1, quotesKnown: true, feeCents: 1.4,
      },
    }),
  ]);
  teachShadowLearn(stats);
  teachStrategyProposals(stats);
  const learn = JSON.parse(fs.readFileSync(path.join(tmp, "shadow-learn.json"), "utf8"));
  assert.equal(learn.liveApplyEnabled, false);
  assert.equal(learn.puzzle.liveApplyEnabled, false);
  assert.match(learn.puzzle.teach, /0\.72–1\.18x/);
  const md = fs.readFileSync(path.join(tmp, "strategy-proposals.md"), "utf8");
  assert.match(md, /OBSERVE only/);
  assert.match(md, /Never ENABLE_STRATEGY/);
  assert.match(md, /Never CHANGE_EV_FLOOR/);
  assert.doesNotMatch(md, /ENABLE_STRATEGY\s*$/m);
  assert.doesNotMatch(md, /paperMode": false/);
});

test("unlabeled lag-agree and htf-aligned-cheap stay empty (n=0, fail-closed)", () => {
  const rows: ContractPuzzle[] = [1, 2, 3].map(i => fixturePuzzle({
    ticker: `KXBTC15M-26AUG28900${i}-00`,
    settled: "YES",
    botAction: "SKIP",
    features: {
      ticketMotion: "unknown",
      lagClass: "unknown",
      lagSeconds: null,
      lagDollars: null,
      pathClass: "MULTIPLIER",
      askBand: "cheap_7_18",
      minutesLeft: 6.7,
      secsRemaining: 400,
      regime: null,
      htfStructure: {
        channelPos: "unknown", nearestSupport: null, nearestResist: null,
        biasFor15m: "UNKNOWN", mtfScore: null, freshness: "missing",
      },
      streakSaturation: null,
      takeCells: [],
    },
  }));
  const stats = aggregatePuzzles(rows);
  const lagAgree = stats.plusEvTakeCells.find(c => c.cell === "lag-agree");
  const htf = stats.plusEvTakeCells.find(c => c.cell === "htf-aligned-cheap");
  assert.ok(lagAgree && htf);
  assert.equal(lagAgree!.n, 0);
  assert.equal(htf!.n, 0);
  assert.equal(lagAgree!.observeCandidate, false);
  assert.equal(htf!.observeCandidate, false);
  assert.match(lagAgree!.note, /unlabeled/);
  assert.equal(stats.liveApplyEnabled, false);
  const md = renderPuzzleStatsMd(stats);
  assert.match(md, /HTF bias/);
  assert.match(md, /Early-exit/);
  assert.match(md, /settle-wrong but early-exit WIN/);
});

test("early-exit MFE WIN is +EV even when settle side is wrong; not ENABLE", () => {
  const rows: ContractPuzzle[] = [1, 2, 3].map(i => fixturePuzzle({
    ticker: `KXBTC15M-26AUG28800${i}-00`,
    settled: "NO",
    botAction: "SKIP",
    counterfactual: {
      skipFeeNetCents: 0,
      takeFeeNetCents: holdToSettleFeeNetCents(12, "YES", "NO"),
      takeAskCents: 12,
      takeSide: "YES",
      takeContracts: 1,
      quotesKnown: true,
      feeCents: kalshiFeeCents(12),
    },
    features: {
      ticketMotion: "unknown",
      lagClass: "unknown",
      lagSeconds: null,
      lagDollars: null,
      pathClass: "MULTIPLIER",
      askBand: "cheap_7_18",
      minutesLeft: 6.7,
      secsRemaining: 400,
      regime: null,
      htfStructure: {
        channelPos: "unknown", nearestSupport: null, nearestResist: null,
        biasFor15m: "UNKNOWN", mtfScore: null, freshness: "missing",
      },
      streakSaturation: null,
      takeCells: ["persist-cheap"],
    },
    earlyExit: {
      entryAsk: 12,
      maxFavorableExcursionCents: 28,
      earlyExitPnLAtMfeCents: 25,
      earlyExitPnLAtGreenXCents: 17,
      greenXCents: 20,
      settleSideCorrect: false,
      quotesAfterEntry: 40,
    },
    labels: puzzleLabels(holdToSettleFeeNetCents(12, "YES", "NO"), "YES", "NO", 25),
  }));
  const stats = aggregatePuzzles(rows);
  const persist = stats.plusEvTakeCells.find(c => c.cell === "persist-cheap");
  assert.ok(persist);
  assert.equal(persist!.n, 3);
  assert.ok((persist!.meanFeeNetVsSkipCents ?? 0) < 0, "hold-to-settle lost");
  assert.ok((persist!.meanEarlyExitPnLCents ?? 0) > 0, "early-exit MFE won");
  assert.equal(persist!.observeCandidate, true, "early-exit +EV is enough; settleCorrect not required");
  assert.equal(persist!.enable, false);
  assert.equal(stats.contingency.earlyExit.nSettleWrongEarlyWin, 3);
  assert.doesNotMatch(persist!.note, /ENABLE_STRATEGY/);
});

test("G of a winning 20¢ take is positive; losing 50¢ is negative", () => {
  const gWin = logGrowthFromFeeNet(20, holdToSettleFeeNetCents(20, "YES", "YES")!);
  const gLoss = logGrowthFromFeeNet(50, holdToSettleFeeNetCents(50, "YES", "NO")!);
  assert.ok(gWin != null && gWin > 0);
  assert.ok(gLoss != null && gLoss < 0);
});

test("puzzle features carry streakSaturation (null if unknown; not a take cell)", () => {
  resetPuzzleForTests();
  rememberPuzzleSkip({
    ticker: "KXBTC15M-26AUG281400-00",
    side: "yes",
    strategyId: "LATE_ENTRY_ANCHOR",
    rejectionCode: "STREAK_SATURATION",
    entryPriceCents: 40,
    secsRemaining: 400,
    ts: Date.now(),
    streakSaturation: 0.82,
  });
  const row = buildContractPuzzle({
    ticker: "KXBTC15M-26AUG281400-00",
    settled: "NO",
  });
  assert.ok(row);
  assert.equal(row!.features.streakSaturation, 0.82);
  assert.ok(row!.skip?.reasonCodes.includes("STREAK_SATURATION"));
  assert.equal(row!.liveApplyEnabled, false);
  assert.equal(row!.paperMode, true);
});
