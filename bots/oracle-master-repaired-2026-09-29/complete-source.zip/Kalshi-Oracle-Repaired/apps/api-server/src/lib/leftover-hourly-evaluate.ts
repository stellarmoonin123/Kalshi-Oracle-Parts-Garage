/**
 * Leftover 1H evaluate. Paper KXBTC15M never runs it.
 * Host: leftoverHourlyEvaluateMayRun is the only door into _evaluateHourlyTickBody.
 * Not an edge claim. Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
import { paperDeskHourlyEvaluateMayRun } from "./15m-product.js";

export const LEFTOVER_HOURLY_EVALUATE_LOADED = true as const;

export const LEFTOVER_HOURLY_HOST_GUARD =
  "if (!leftoverHourlyEvaluateMayRun(this.config)) return;";

/** Markers that must live in leftover-hourly-funnel.ts, not host evaluateHourlyTick. */
export const FROZEN_HOURLY_FUNNEL_MARKERS = [
  "hourlyPoller.setReferencePrice",
  "projectedSettlementPrice: this.lastBasisState?.projectedSettlementPrice",
  "OTM_BREAKOUT_EXPANSION",
] as const;

export function leftoverHourlyEvaluateMayRun(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return paperDeskHourlyEvaluateMayRun(cfg);
}

export function leftoverHourlyEvaluateHostDenied(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverHourlyEvaluateMayRun(cfg) === false;
}

/** Named leftover hourly runner. Paper or frozen config returns without invoking `run`. */
export function leftoverHourlyEvaluateRun(
  cfg: { paperMode?: boolean; frozenCcMode?: boolean },
  run: () => Promise<void>,
): Promise<void> {
  if (!leftoverHourlyEvaluateMayRun(cfg)) return Promise.resolve();
  return run();
}
