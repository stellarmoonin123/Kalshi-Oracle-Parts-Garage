/**
 * Integration tests against the real database: day-row creation, upsert under
 * the unique (date, paper_mode) index, and restart recovery of the target-hit
 * latch + peak equity.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { db, dailyEquityDays } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { loadOrCreateDayRow, updateDayRow, ensureDailyEquitySchema } from "./daily-target.js";

// Fake future date key so we never collide with real trading rows.
const TEST_DATE = "2099-01-01";

async function cleanup() {
  await db.delete(dailyEquityDays).where(eq(dailyEquityDays.date, TEST_DATE));
}

test("daily-equity DB integration", async (t) => {
  await ensureDailyEquitySchema();
  await cleanup();
  t.after(cleanup);

  await t.test("creates the day row with start = peak = current equity", async () => {
    const row = await loadOrCreateDayRow({ date: TEST_DATE, paperMode: true, equityCents: 10_000 });
    assert.equal(row.startEquityCents, 10_000);
    assert.equal(row.peakEquityCents, 10_000);
    assert.equal(row.targetHit, false);
  });

  await t.test("second load (concurrent process / restart) reuses the same base, ignoring new equity", async () => {
    const row = await loadOrCreateDayRow({ date: TEST_DATE, paperMode: true, equityCents: 99_999 });
    assert.equal(row.startEquityCents, 10_000);   // original base preserved
  });

  await t.test("unique index allows one row per (date, paperMode) — live mode gets its own", async () => {
    await loadOrCreateDayRow({ date: TEST_DATE, paperMode: false, equityCents: 5_000 });
    const rows = await db.select().from(dailyEquityDays).where(eq(dailyEquityDays.date, TEST_DATE));
    assert.equal(rows.length, 2);
  });

  await t.test("restart recovery: target-hit latch and peak survive a reload", async () => {
    // Simulate the immediate persist at the target-hit transition…
    await updateDayRow({
      date: TEST_DATE, paperMode: true,
      startEquityCents: 10_000, endEquityCents: 15_200, peakEquityCents: 16_000,
      targetHit: true,
    });
    // …then a process restart: reload with equity now BELOW the target.
    const row = await loadOrCreateDayRow({ date: TEST_DATE, paperMode: true, equityCents: 13_000 });
    assert.equal(row.targetHit, true, "latch must survive restart so protect mode stays active");
    assert.equal(row.peakEquityCents, 16_000, "high-water mark must survive restart for the give-back cap");
    assert.equal(row.startEquityCents, 10_000);
  });

  await t.test("direct duplicate insert is rejected by the unique index", async () => {
    await assert.rejects(
      db.insert(dailyEquityDays).values({
        date: TEST_DATE, paperMode: true, startEquityCents: 1, endEquityCents: 1, pctGain: 0,
      }),
      (err: unknown) => {
        // Drizzle wraps the pg error — the constraint detail lives on `cause`.
        const msg = String((err as Error).message) + String(((err as Error).cause as Error | undefined)?.message ?? "");
        return /duplicate key|unique/i.test(msg);
      },
    );
    // …while the onConflictDoNothing path in loadOrCreateDayRow stays silent.
    const rows = await db.select().from(dailyEquityDays)
      .where(and(eq(dailyEquityDays.date, TEST_DATE), eq(dailyEquityDays.paperMode, true)));
    assert.equal(rows.length, 1);
  });
});
