/**
 * brain-center (goldenEggCortex) — Oracle Mind / special cortex.
 *
 * Pure on the interpret path. No network. Never placeOrder. Never replaces
 * decideFrozenCcEntry / decideMoneyPath. No LLM on evaluateEntry/placeOrder.
 *
 * Three-layer mind stamped every tick:
 *   reflex    — fail-closed rails (stale, !paper, EV floor, size0)
 *   tactical  — six-gate + CC_VEL / MTF_BULL_INTO_RED_VEL / capital vetoes
 *   strategic — regime/session/drawdown/promote context (never overrides reflex)
 *
 * Floors untouched: EV 3¢ / Kelly 0.60 / 9% / ask 20–55 / reserve 15%.
 */
import { existsSync, mkdirSync, appendFileSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  BRAIN_FROZEN_ORGANS_ADVISORY,
  type AdmissionMsg,
  type ExitMonitorStamp,
  type Freshness,
  type SensorMsg,
  type SettleMsg,
  type StructuralRuinShadowStamp,
} from "./brain-stamps.js";
import {
  scoreSettleSide,
  type SettleSideScoreInput,
  type SettleSideScoreResult,
  SETTLE_SIDE_SCORE_LOADED,
} from "./settle-side-score.js";
import {
  calibrationSnapshot,
  type CalibrationReport,
  MIND_CALIBRATION_LOADED,
} from "./mind-calibration.js";
import {
  buildUncertaintyReport,
  type OptionValueSkip,
  type SideConfidenceBand,
  MIND_UNCERTAINTY_LOADED,
} from "./mind-uncertainty.js";
import {
  MIND_CAUSAL_LOADED,
} from "./mind-causal.js";
import {
  empiricalBayesWeightNudges,
  getScarRing,
  type EmpiricalBayesNudge,
} from "./scar-echo-learning.js";
import {
  buildOracleV2Block,
  ORACLE_V2_DOCTRINE_LOADED,
  type OracleV2Block,
} from "./oracle-v2-doctrine.js";
import {
  buildSelfDriveStack,
  peekSelfDriveBrake,
  SELFDRIVE_LOADED,
  type SelfDriveStack,
} from "./self-drive.js";
import {
  buildCaptainBridge,
  peekCaptainHeave,
  CAPTAIN_BRIDGE_LOADED,
  type CaptainBridge,
} from "./captain-bridge.js";
import {
  evaluatePhdCommonSense,
  PHD_TRADING_EDUCATION_LOADED,
  type PhdEducationResult,
} from "./phd-trading-education.js";
import {
  evaluateKxbct15mSpecialist,
  KXBTC15M_SPECIALIST_LOADED,
  type Kxbct15mSpecialistResult,
} from "./kxbtc15m-specialist.js";
import {
  buildMindHeartbeat,
  MIND_HEARTBEAT_LOADED,
  type MindHeartbeat,
} from "./mind-heartbeat.js";
import { deskDataPath } from "../desk-data-dir.js";
import { stampBookDepth, type BookDepthStamp } from "./book-depth-stamp.js";
import type { InMemoryOrderbookSnapshot } from "../orderbook-depth.js";

export const GOLDEN_EGG_CORTEX = "goldenEggCortex" as const;
export { scoreSettleSide, SETTLE_SIDE_SCORE_LOADED } from "./settle-side-score.js";
export type { SettleSideScoreResult, SettleSideScoreInput } from "./settle-side-score.js";
export const BRAIN_CENTER_LOADED = "BRAIN_CENTER_LOADED" as const;
export const ORACLE_MIND = "oracleMind" as const;

/** Epistemic label (GoldenEgg). */
export type GoldenEggLabel =
  | "FACT"
  | "MEASUREMENT"
  | "ESTIMATE"
  | "INFERENCE"
  | "HYPOTHESIS"
  | "ASSUMPTION"
  | "UNKNOWN";

export type BrainCenterRecommendation =
  | "TAKE"
  | "SKIP"
  | "SIT"
  | "HOLD"
  | "EXIT_SHADOW";

/** Autopilot-aligned decision kinds (+ HOLD/EXIT for open-book). */
export type BrainDecisionKind =
  | "TAKE_YES"
  | "TAKE_NO"
  | "SKIP"
  | "HOLD"
  | "EXIT";

export type MindLayerId = "reflex" | "tactical" | "strategic";

export type MindLayerVerdict = "YES" | "NO" | "SKIP" | "HOLD" | "EXIT" | "PASS";

export type MindLayer = {
  id: MindLayerId;
  verdict: MindLayerVerdict;
  why: string;
  /** Reflex hard-block — tactical/strategic cannot override. */
  hard?: boolean;
};

export type BrainMind = {
  layers: MindLayer[];
  winner: MindLayerId;
  winnerWhy: string;
};

export type BrainCenterConflictCode =
  | "CC_VEL_AGAINST_SOLE_TAKE"
  | "MTF_BULL_INTO_RED_VEL"
  | "REGIME_WOULD_BLOCK_SOLE_TAKE"
  | "STALE_FEED_VS_TAKE"
  | "SOLE_TAKE_VS_ORGAN_SKIP"
  | "STRUCTURAL_RUIN_SHADOW_OPEN"
  | "THESIS_UNKNOWN_OPEN"
  | "SETTLE_INCOMPLETE"
  | "EV_FLOOR_REFLEX"
  | "SIZE_ZERO_REFLEX"
  | "NOT_PAPER_REFLEX";

export type BrainCenterEvidence = {
  label: GoldenEggLabel;
  code: string;
  detail: string;
};

export type BrainCenterConflict = {
  code: BrainCenterConflictCode;
  label: GoldenEggLabel;
  detail: string;
};

export type ConfidenceBand = "low" | "mid" | "high";

/** Floors the mind never cuts (mirror AGENT_FLOORS / admission). */
export const MIND_FLOOR_LOCKS = {
  evFloorCents: 3,
  kellyCap: 0.6,
  maxRiskPctPerTrade: 0.09,
  reservePctFloor: 15,
  askMinCents: 20,
  askMaxCents: 55,
} as const;

export type BrainEpisode = {
  atMs: number;
  side: "yes" | "no";
  strategyId: string | null;
  conflictsAtEntry: string[];
  feeNetCents: number;
  decisionKind: string;
  /** Optional short memory title ("vel-against YES veto paid"). */
  title?: string | null;
  /** Causal settle attribution (PhD). */
  sideCorrect?: boolean | null;
  exitSavedWrongSide?: boolean | null;
  settledSide?: "yes" | "no" | null;
  exitReason?: string | null;
  sidePickerWeight?: number | null;
};

/** Deep-dive prior: CC_VEL against mean fee-net (ESTIMATE only; n≪40). */
export const CC_VEL_AGAINST_MEAN_FEE_NET_ESTIMATE_CENTS = -394 as const;

export type CouncilAdvocateId = "bull" | "bear" | "skip";

export type CouncilAdvocate = {
  id: CouncilAdvocateId;
  vote: "TAKE_YES" | "TAKE_NO" | "HOLD" | "SKIP" | "SIT";
  weight: number;
  reasons: string[];
};

export type CouncilDissent = {
  minority: CouncilAdvocateId;
  minorityVote: CouncilAdvocate["vote"];
  resolved: BrainDecisionKind;
  note: string;
};

export type CouncilReport = {
  advocates: CouncilAdvocate[];
  resolved: BrainDecisionKind;
  dissent: CouncilDissent | null;
};

export type AttentionSignal = {
  source: string;
  signal: string;
  salience: number;
  note: string;
};

export type CuriosityGap = {
  code: string;
  ask: string;
};

export type CounterfactualVeto = {
  wouldHave: "TAKE_YES" | "TAKE_NO";
  because: string;
  feeNetVsSkipHint: string;
};

export type ConvictionTick = {
  ts: number;
  decisionKind: BrainDecisionKind;
  confidenceBand: ConfidenceBand;
  topConflict: string | null;
};

export type HorizonPhase = "early" | "mid" | "late" | "unknown";

export type HorizonPosture = {
  phase: HorizonPhase;
  bias: "TAKE_OK" | "CAUTIOUS" | "SKIP_LEAN";
  note: string;
  secsRemaining: number | null;
};

export type SelfCritique = {
  ok: boolean;
  worries: string[];
  wouldChangeNext: string | null;
};

export type ForesightHint = {
  nextLikely: "TAKE_YES" | "TAKE_NO" | "SKIP";
  confidenceBand: ConfidenceBand;
  label: "INFERENCE";
  note: string;
};

export type RhythmPulse = {
  pulseMs: number | null;
  cadenceNote: string;
  coherenceScore: number;
};

/** Deterministic GoldenEgg loop — how the desk programmer agent thinks (no LLM). */
export type GoldenEggDoctrineFlags = {
  skipIsValid: boolean;
  noMoreTradesOptimization: boolean;
  floorsUncut: boolean;
  sampleInsufficient: boolean;
};

export type GoldenEggThought = {
  bottomLine: string;
  evidence: BrainCenterEvidence[];
  diagnosis: string;
  recommendedAction: "TAKE_YES" | "TAKE_NO" | "SKIP" | "SIT" | "HOLD" | "EXIT";
  why: string;
  risks: string[];
  cheapestNextCheck: string;
  successCriteria: string;
  feeNetVsSkip: string;
  doctrine: GoldenEggDoctrineFlags;
};


/** PhD-layer cognition block — research-grade settle/fee-net judgment (no LLM). */
export type PhdThought = {
  calibration: CalibrationReport;
  uncertainty: SideConfidenceBand;
  optionValueSkip: OptionValueSkip;
  causalNote: string;
  empiricalBayes: EmpiricalBayesNudge[];
  references: string[];
};

export type BrainCenterReport = {
  kind: "brainCenter";
  cortex: typeof GOLDEN_EGG_CORTEX;
  mindName: typeof ORACLE_MIND;
  interpretation: string;
  conflicts: BrainCenterConflict[];
  recommendation: BrainCenterRecommendation;
  confidenceBand: ConfidenceBand;
  evidence: BrainCenterEvidence[];
  soleAuthorityRespected: boolean;
  observeOnly: true;
  feeNetNote: string;
  asOf: string;
  advisoryNote: typeof BRAIN_FROZEN_ORGANS_ADVISORY | "OBSERVE_ONLY";
  /** Three-layer mind stamped every tick. */
  mind: BrainMind;
  /** One-paragraph human story. */
  story: string;
  /** Autopilot-aligned kind. */
  decisionKind: BrainDecisionKind;
  /** Episodic fee-net memory annotation. */
  memoryNote: string;
  /** Last few episodes for desk journal tail. */
  journalTail: BrainEpisode[];
  /** Inner council — bull/bear/skip advocates this tick. */
  council: CouncilReport;
  /** Top signals the mind is attending to. */
  attention: AttentionSignal[];
  /** Unknowns that would change the decision. */
  curiosity: CuriosityGap[];
  /** When vetoing a TAKE: labeled ESTIMATE counterfactual (never invent live P&L). */
  counterfactual: CounterfactualVeto | null;
  /** Ring of recent decision ticks for flip observability. */
  convictionTrail: ConvictionTick[];
  /** One-line Oracle Mind voice. */
  thought: string;
  /** Candle-phase posture (early/mid/late). */
  horizon: HorizonPosture;
  /** One-pass self-critique after resolve. */
  critique: SelfCritique;
  /** Advisory one-step foresight (INFERENCE). */
  foresight: ForesightHint;
  /** Tick cadence + layer/council coherence. */
  rhythm: RhythmPulse;
  /** Deterministic GoldenEgg cognition loop (agent-copy; no LLM). */
  goldenEggThought: GoldenEggThought;
  /** Voice identity — desk programmer mode. */
  thinksLike: "goldenEgg-oracle-copy";
  /** Settlement-oriented YES/NO/SKIP score (pure; council uses when inputs present). */
  settleSideScore: SettleSideScoreResult | null;
  /** PhD research layer — calibration / uncertainty / OV-SKIP / causal / EB. */
  phd: PhdThought;
  /** ORACLE v2 desk OS fold — seats/gates/ABSTAIN (deterministic; no LLM). */
  oracleV2: OracleV2Block;
  /** SelfDrive — road=15m candle; planAction + brake (deterministic; no LLM). */
  selfDrive: SelfDriveStack;
  /** Captain Bridge — unify SelfDrive + oracleV2 + PhD into one voyage order. */
  captain: CaptainBridge;
  /** PhD trading-education common-sense (deterministic; soft heave; floors uncut). */
  phdEducation: PhdEducationResult;
  /** KXBTC15M product specialist (deterministic; soft heave; floors uncut). */
  kxbct15m: Kxbct15mSpecialistResult;
  /** Mind heartbeat — cortex vitals (separate from organism 9-system body pulse). */
  heartbeat: MindHeartbeat;
  /** Real L2 depth at/near the ask on the side taken (fail-safe unknown when stale). */
  bookDepth: BookDepthStamp;
};

export type BrainCenterFrozenShadowInput = {
  ccVelocityWouldBlock?: string | null;
  regimeWouldBlock?: boolean | null;
  mtfScore?: number | null;
  velocityDolPerMin?: number | null;
  w2Reason?: string | null;
  /** Sign-safe constructed NO — feeds settle-side-score. */
  constructedNo?: boolean | null;
  lagProven?: boolean | null;
  lagStale?: boolean | null;
};

export type BrainCenterInput = {
  /** Market ticker — KXBTC15M specialist fail-closed when non-15m. */
  ticker?: string | null;
  frozenCcMode: boolean;
  /** Fail-closed when false — reflex hard-blocks new TAKEs. */
  paperMode?: boolean | null;
  /** Proposed size; 0 → reflex SIZE_ZERO. */
  proposedSize?: number | null;
  feedFreshness?: Freshness | null;
  sensorBundle?: SensorMsg | null;
  admission?: AdmissionMsg | null;
  exitMonitor?: ExitMonitorStamp | null;
  settleStamp?: SettleMsg | null;
  structuralRuinShadow?: StructuralRuinShadowStamp | null;
  frozenShadow?: BrainCenterFrozenShadowInput | null;
  /** Optional regime/session/drawdown context for strategic layer. */
  strategicContext?: {
    session?: string | null;
    drawdownPct?: number | null;
    promoteReady?: boolean | null;
    regimeLabel?: string | null;
  } | null;
  /** Episodes for memoryNote (defaults to in-process ring). */
  episodes?: readonly BrainEpisode[] | null;
  /** Candle secs remaining for horizon posture (15m ≈ 900). */
  secsRemaining?: number | null;
  /** Prior tick ms for rhythm pulseMs (optional). */
  lastTickMs?: number | null;
  /** When true, skip mutating conviction trail (unit tests). */
  skipConvictionRecord?: boolean | null;
  nowMs?: number;
  /** Optional echo n / mean for uncertainty band (defaults from scar ring). */
  phdContext?: {
    echoN?: number | null;
    echoMeanFeeNet?: number | null;
    causalNote?: string | null;
  } | null;
  /**
   * Real Kalshi L2 (kalshiWS.getLatestOrderbook()). Stale (>30 s) / missing /
   * wrong-ticker → depthKnown:false (fail safe, thin default kept).
   */
  orderbook?: InMemoryOrderbookSnapshot | null;
  /** Desk balance (¢) for the thin-book threshold (2× max per-trade contracts). */
  balanceCents?: number | null;
  /** checkOrderbookConsistency vs live WS quote; stale → depth unknown. */
  orderbookConsistency?: { stale: boolean; reason: string | null } | null;
};

function settlementProxyFromLag(
  lagProven: boolean | null,
  lagStale: boolean | null,
): boolean {
  if (lagProven === true) return true;
  if (lagStale === false) return true;
  return false;
}

function pushEvidence(
  out: BrainCenterEvidence[],
  label: GoldenEggLabel,
  code: string,
  detail: string,
): void {
  out.push({ label, code, detail });
}

function pushConflict(
  out: BrainCenterConflict[],
  code: BrainCenterConflictCode,
  label: GoldenEggLabel,
  detail: string,
): void {
  out.push({ code, label, detail });
}

// ── Episodic fee-net memory (in-process ring + optional JSONL) ───────────────

const EPISODE_RING_MAX = 64;
const EPISODE_QUERY_DEFAULT = 5;

let episodeRing: BrainEpisode[] = [];

export function resetBrainEpisodesForTests(): void {
  episodeRing = [];
  convictionTrailRing = [];
}

export function getBrainEpisodeRing(): readonly BrainEpisode[] {
  return episodeRing;
}

const CONVICTION_TRAIL_MAX = 20;
let convictionTrailRing: ConvictionTick[] = [];

export function getConvictionTrail(): readonly ConvictionTick[] {
  return convictionTrailRing;
}

/** Pure: append conviction tick into a ring copy. */
export function updateConvictionTrail(
  ring: readonly ConvictionTick[],
  tick: ConvictionTick,
  max = CONVICTION_TRAIL_MAX,
): ConvictionTick[] {
  const next = [...ring, tick];
  if (next.length > max) return next.slice(next.length - max);
  return next;
}

/** Record conviction tick into in-process ring. */
export function recordConvictionTick(tick: ConvictionTick): ConvictionTick {
  convictionTrailRing = updateConvictionTrail(convictionTrailRing, tick);
  return tick;
}

export function resetConvictionTrailForTests(): void {
  convictionTrailRing = [];
}

/** Pure: append episode into a ring copy (max EPISODE_RING_MAX). */
export function updateEpisodeRing(
  ring: readonly BrainEpisode[],
  episode: BrainEpisode,
  max = EPISODE_RING_MAX,
): BrainEpisode[] {
  const next = [...ring, episode];
  if (next.length > max) return next.slice(next.length - max);
  return next;
}

/** Pure: last N episodes (newest last). */
export function queryEpisodes(
  ring: readonly BrainEpisode[],
  n = EPISODE_QUERY_DEFAULT,
): BrainEpisode[] {
  if (n <= 0) return [];
  return ring.slice(-n);
}

/**
 * Annotate memory from recent episodes.
 * Honest UNKNOWN when no data; otherwise fee-net framing for CC_VEL vetoes.
 */
export function annotateMemoryNote(
  episodes: readonly BrainEpisode[],
  n = EPISODE_QUERY_DEFAULT,
): string {
  const tail = queryEpisodes(episodes, n);
  if (tail.length === 0) {
    return "memoryNote=UNKNOWN — no episodic fee-net closes yet";
  }
  const velVetoes = tail.filter((e) =>
    e.conflictsAtEntry.some(
      (c) => c === "CC_VEL_AGAINST_SOLE_TAKE" || c === "MTF_BULL_INTO_RED_VEL",
    ),
  );
  const taken = tail.filter(
    (e) => e.decisionKind === "TAKE_YES" || e.decisionKind === "TAKE_NO",
  );
  const vetoSaved = velVetoes.reduce((s, e) => {
    // If we had vetoed (conflict stamped) but still took, fee-net is the cost of ignoring;
    // if decision was SKIP, "saved" ≈ -feeNet of what would have been (skip≈0, so -feeNet if taken would lose).
    // Honest: sum feeNet of taken-with-vel-conflict as "taken Y"; skip episodes with conflict as "saved X" ≈ 0 - 0.
    return s;
  }, 0);
  void vetoSaved;
  const takenWithVel = taken.filter((e) =>
    e.conflictsAtEntry.some(
      (c) => c === "CC_VEL_AGAINST_SOLE_TAKE" || c === "MTF_BULL_INTO_RED_VEL",
    ),
  );
  const skippedWithVel = tail.filter(
    (e) =>
      e.decisionKind === "SKIP" &&
      e.conflictsAtEntry.some(
        (c) => c === "CC_VEL_AGAINST_SOLE_TAKE" || c === "MTF_BULL_INTO_RED_VEL",
      ),
  );
  const takenY = takenWithVel.reduce((s, e) => s + e.feeNetCents, 0);
  // Skip ≈ 0; "saved" vs taking those is unknown without counterfactual — report count + taken bleed.
  const titled = tail.filter((e) => e.title).map((e) => e.title).slice(-2);
  const titleBit = titled.length ? ` · named: ${titled.join("; ")}` : "";
  if (velVetoes.length === 0) {
    const sum = tail.reduce((s, e) => s + e.feeNetCents, 0);
    return `last ${tail.length} episodes fee-net sum=${sum}¢ (no CC_VEL/MTF veto stamps)${titleBit}`;
  }
  return (
    `last ${tail.length} episodes: ${velVetoes.length} CC_VEL/MTF conflict stamps — ` +
    `taken ${takenWithVel.length} fee-net ${takenY}¢ vs skipped ${skippedWithVel.length} (skip≈0)${titleBit}`
  );
}


/** n≥40 before promote — institutional doctrine. */
export const LEARNING_PROMOTE_N = 40 as const;

export type LearningConflictStats = {
  conflictCode: string;
  n: number;
  meanFeeNet: number;
  wr: number;
  /** mean fee-net when conflict present and taken (ignored veto). */
  meanTakenWithConflict: number | null;
  nTakenWithConflict: number;
  /** Advisory only until authority already vetoes. */
  promoteHint: boolean;
  doctrine: "INSUFFICIENT_DATA" | "PROMOTE_HINT" | "OK";
};

export type LearningSnapshot = {
  episodeCount: number;
  byConflictCode: LearningConflictStats[];
  promoteHints: Array<{ conflictCode: string; reason: string; n: number; meanFeeNet: number }>;
  doctrine: {
    nMinPromote: typeof LEARNING_PROMOTE_N;
    sampleInsufficient: boolean;
    floorsUncut: true;
    noLlmOnTick: true;
  };
  /** Scar-Echo Learning fold-in (optional). */
  scarEcho?: {
    scarCount: number;
    closedCount: number;
    starved: boolean;
    weightDeltas?: unknown[];
  } | null;
};

/**
 * Aggregate episodes → learningSnapshot.
 * If n≥40 AND meanFeeNet clearly worse when conflict ignored vs vetoed → promoteHint.
 * If n<40 → INSUFFICIENT_DATA.
 */
export function buildLearningSnapshot(
  episodes: readonly BrainEpisode[],
  opts?: { scarEcho?: LearningSnapshot["scarEcho"] | null },
): LearningSnapshot {
  const by = new Map<string, BrainEpisode[]>();
  for (const ep of episodes) {
    const codes = ep.conflictsAtEntry?.length ? ep.conflictsAtEntry : ["NONE"];
    for (const c of codes) {
      const arr = by.get(c) ?? [];
      arr.push(ep);
      by.set(c, arr);
    }
  }
  const byConflictCode: LearningConflictStats[] = [];
  const promoteHints: LearningSnapshot["promoteHints"] = [];
  for (const [conflictCode, eps] of by) {
    const n = eps.length;
    const meanFeeNet =
      n > 0
        ? Math.round((eps.reduce((s, e) => s + e.feeNetCents, 0) / n) * 10) / 10
        : 0;
    const wins = eps.filter((e) => e.feeNetCents > 0).length;
    const wr = n > 0 ? Math.round((wins / n) * 100) / 100 : 0;
    const taken = eps.filter(
      (e) => e.decisionKind === "TAKE_YES" || e.decisionKind === "TAKE_NO",
    );
    const meanTaken =
      taken.length > 0
        ? Math.round((taken.reduce((s, e) => s + e.feeNetCents, 0) / taken.length) * 10) / 10
        : null;
    let doctrine: LearningConflictStats["doctrine"] = "OK";
    let promoteHint = false;
    if (n < LEARNING_PROMOTE_N) {
      doctrine = "INSUFFICIENT_DATA";
    } else if (
      conflictCode !== "NONE" &&
      meanTaken != null &&
      meanTaken < -40
    ) {
      // Clearly worse when conflict ignored (taken despite conflict)
      promoteHint = true;
      doctrine = "PROMOTE_HINT";
      promoteHints.push({
        conflictCode,
        reason: `n=${n}≥${LEARNING_PROMOTE_N} meanTakenFeeNet=${meanTaken}¢ clearly worse vs skip`,
        n,
        meanFeeNet: meanTaken,
      });
    }
    byConflictCode.push({
      conflictCode,
      n,
      meanFeeNet,
      wr,
      meanTakenWithConflict: meanTaken,
      nTakenWithConflict: taken.length,
      promoteHint,
      doctrine,
    });
  }
  byConflictCode.sort((a, b) => b.n - a.n);
  return {
    episodeCount: episodes.length,
    byConflictCode,
    promoteHints,
    doctrine: {
      nMinPromote: LEARNING_PROMOTE_N,
      sampleInsufficient: episodes.length < LEARNING_PROMOTE_N,
      floorsUncut: true,
      noLlmOnTick: true,
    },
    scarEcho: opts?.scarEcho ?? null,
  };
}

function defaultEpisodesPath(): string {
  return deskDataPath("brain-episodes.jsonl");
}

/** Record episode into ring; optionally append JSONL (best-effort, never throws). */
export function recordBrainEpisode(
  episode: BrainEpisode,
  opts?: { persist?: boolean; persistPath?: string },
): BrainEpisode {
  const titled: BrainEpisode =
    episode.title != null && String(episode.title).trim()
      ? episode
      : { ...episode, title: nameBrainEpisode(episode) };
  episode = titled;
  episodeRing = updateEpisodeRing(episodeRing, episode);
  if (opts?.persist === true) {
    try {
      const file = opts.persistPath ?? defaultEpisodesPath();
      const dir = path.dirname(file);
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      appendFileSync(file, `${JSON.stringify(episode)}\n`, "utf8");
    } catch {
      /* never block settle on disk */
    }
  }
  return episode;
}

/** Load JSONL into ring (tests / startup). Best-effort. */
export function loadBrainEpisodesFromDisk(filePath?: string): number {
  try {
    const file = filePath ?? defaultEpisodesPath();
    if (!existsSync(file)) return 0;
    const lines = readFileSync(file, "utf8").split("\n").filter(Boolean);
    let n = 0;
    for (const line of lines) {
      try {
        const ep = JSON.parse(line) as BrainEpisode;
        if (ep && typeof ep.atMs === "number") {
          episodeRing = updateEpisodeRing(episodeRing, ep);
          n += 1;
        }
      } catch {
        /* skip bad line */
      }
    }
    return n;
  } catch {
    return 0;
  }
}

// ── Layer helpers ───────────────────────────────────────────────────────────

function isMtfBullIntoRedVel(
  side: "yes" | "no" | null,
  mtfScore: number | null | undefined,
  vel: number | null | undefined,
  ccVelBlock: string | null | undefined,
): boolean {
  if (!ccVelBlock) return false;
  if (!(typeof mtfScore === "number" && mtfScore > 0)) return false;
  if (!(typeof vel === "number" && Number.isFinite(vel))) return false;
  if (side === "yes" && vel <= -40) return true;
  if (side === "no" && vel >= 40) return true;
  return false;
}

function buildReflexLayer(input: {
  stale: boolean;
  paperMode: boolean;
  soleDecision: string;
  evCents: number | null;
  sizeZero: boolean;
  code: string;
}): MindLayer {
  if (!input.paperMode) {
    return {
      id: "reflex",
      verdict: "SKIP",
      why: "fail-closed: paperMode≠true — mind refuses spend",
      hard: true,
    };
  }
  if (input.stale && input.soleDecision === "TAKE") {
    return {
      id: "reflex",
      verdict: "SKIP",
      why: "fail-closed: stale feed vs sole TAKE",
      hard: true,
    };
  }
  if (input.sizeZero) {
    return {
      id: "reflex",
      verdict: "SKIP",
      why: `fail-closed: size0 (${input.code})`,
      hard: true,
    };
  }
  if (
    input.soleDecision === "TAKE" &&
    typeof input.evCents === "number" &&
    input.evCents < MIND_FLOOR_LOCKS.evFloorCents
  ) {
    return {
      id: "reflex",
      verdict: "SKIP",
      why: `fail-closed: EV ${input.evCents}¢ < floor ${MIND_FLOOR_LOCKS.evFloorCents}¢`,
      hard: true,
    };
  }
  return {
    id: "reflex",
    verdict: "PASS",
    why: "rails clear (paper · fresh · EV≥3 · size>0)",
    hard: false,
  };
}

function buildTacticalLayer(input: {
  soleDecision: string;
  side: "yes" | "no" | null;
  ccVel: string | null;
  mtfBullRed: boolean;
  regimeBlock: boolean;
  ruinWouldSell: boolean;
  exitAction: string | null;
  reflexHard: boolean;
  horizon?: HorizonPosture | null;
  evCents?: number | null;
}): MindLayer {
  if (input.reflexHard) {
    return {
      id: "tactical",
      verdict: "SKIP",
      why: "deferred — reflex hard-block owns the tick",
    };
  }
  if (input.ruinWouldSell) {
    return {
      id: "tactical",
      verdict: "EXIT",
      why: "structuralRuinShadow.wouldSell — EXIT_SHADOW observe (PATH_RIDE owns real exit)",
    };
  }
  if (
    input.exitAction &&
    (input.exitAction.includes("HOLD") || input.exitAction.startsWith("PATH_RIDE_HOLD"))
  ) {
    return {
      id: "tactical",
      verdict: "HOLD",
      why: `PATH_RIDE ${input.exitAction} — ride book, no new entry`,
    };
  }
  if (input.soleDecision === "TAKE" && input.mtfBullRed) {
    return {
      id: "tactical",
      verdict: "NO",
      why: "MTF_BULL_INTO_RED_VEL — MTF bull while 1m vel fights side; veto TAKE",
    };
  }
  if (input.soleDecision === "TAKE" && input.ccVel) {
    return {
      id: "tactical",
      verdict: "NO",
      why: `CC_VEL veto ${input.ccVel} — fee-net framing prefers skip (shadow n≪40)`,
    };
  }
  if (input.soleDecision === "TAKE" && input.regimeBlock) {
    return {
      id: "tactical",
      verdict: "NO",
      why: "capital/regime conflict — tactical veto TAKE",
    };
  }
  if (input.soleDecision === "SIT") {
    return { id: "tactical", verdict: "SKIP", why: "six-gate SIT" };
  }
  if (input.soleDecision === "TAKE") {
    const strongEdge =
      !input.ccVel &&
      !input.mtfBullRed &&
      !input.regimeBlock &&
      typeof input.evCents === "number" &&
      input.evCents >= MIND_FLOOR_LOCKS.evFloorCents + 2; // late needs EV≥5
    if (input.horizon?.phase === "late" && !strongEdge) {
      return {
        id: "tactical",
        verdict: "NO",
        why: `late candle (${input.horizon.secsRemaining}s) — SKIP lean unless strong edge (EV≥5 + clear vel)`,
      };
    }
    // YES = approve take (side carried separately into decisionKind TAKE_YES|TAKE_NO)
    const lateNote =
      input.horizon?.phase === "late" ? " · late but strong edge" : "";
    return {
      id: "tactical",
      verdict: "YES",
      why: `six-gate TAKE ${input.side ?? "yes"} — clear vel / no capital veto${lateNote}`,
    };
  }
  return { id: "tactical", verdict: "SKIP", why: "six-gate SKIP" };
}

function buildStrategicLayer(input: {
  regimeBlock: boolean;
  session: string | null;
  drawdownPct: number | null;
  promoteReady: boolean | null;
  regimeLabel: string | null;
  ccVelConflictOpen: boolean;
}): MindLayer {
  const bits: string[] = [];
  if (input.regimeLabel) bits.push(`regime=${input.regimeLabel}`);
  if (input.session) bits.push(`session=${input.session}`);
  if (typeof input.drawdownPct === "number") {
    bits.push(`dd=${input.drawdownPct.toFixed(1)}%`);
  }
  if (input.regimeBlock) bits.push("regimeWouldBlock");
  if (input.ccVelConflictOpen) {
    bits.push(
      input.promoteReady === true
        ? "promote-ready=true (still sample-gated)"
        : "promote-ready=false (n≪40 CC_VEL)",
    );
  } else {
    bits.push("no vel-conflict promote pressure");
  }
  return {
    id: "strategic",
    verdict: "PASS",
    why:
      bits.length > 0
        ? `context: ${bits.join(" · ")} — never overrides reflex`
        : "context thin — never overrides reflex",
  };
}

function pickWinner(
  reflex: MindLayer,
  tactical: MindLayer,
): { winner: MindLayerId; winnerWhy: string } {
  if (reflex.hard === true) {
    return { winner: "reflex", winnerWhy: reflex.why };
  }
  return { winner: "tactical", winnerWhy: tactical.why };
}

function recommendationFromMind(
  winner: MindLayerId,
  reflex: MindLayer,
  tactical: MindLayer,
  soleDecision: string,
): BrainCenterRecommendation {
  if (winner === "reflex" && reflex.hard) return "SKIP";
  switch (tactical.verdict) {
    case "YES":
    case "NO":
      // YES/NO on tactical for TAKE side still maps recommendation TAKE only when YES;
      // NO → SIT (authority vetoes; sole stamp may still say TAKE)
      return tactical.verdict === "YES" ? "TAKE" : "SIT";
    case "HOLD":
      return "HOLD";
    case "EXIT":
      return "EXIT_SHADOW";
    case "SKIP":
      return soleDecision === "SIT" ? "SIT" : "SKIP";
    default:
      return "SKIP";
  }
}

function decisionKindFromMind(
  recommendation: BrainCenterRecommendation,
  side: "yes" | "no" | null,
): BrainDecisionKind {
  if (recommendation === "HOLD") return "HOLD";
  if (recommendation === "EXIT_SHADOW") return "EXIT";
  if (recommendation === "TAKE") {
    return side === "no" ? "TAKE_NO" : "TAKE_YES";
  }
  return "SKIP";
}


// ── Special mind builders (pure; no LLM) ────────────────────────────────────

/** Name a close episode for memory (short, concrete). */
export function nameBrainEpisode(ep: {
  side: "yes" | "no";
  conflictsAtEntry: string[];
  feeNetCents: number;
  decisionKind: string;
}): string {
  const side = ep.side.toUpperCase();
  const vel =
    ep.conflictsAtEntry.includes("CC_VEL_AGAINST_SOLE_TAKE") ||
    ep.conflictsAtEntry.includes("MTF_BULL_INTO_RED_VEL");
  if (vel && ep.feeNetCents < 0) {
    return `vel-against ${side} take bled ${ep.feeNetCents}¢`;
  }
  if (vel && ep.decisionKind === "SKIP") {
    return `vel-against ${side} veto paid (skip≈0)`;
  }
  if (ep.feeNetCents >= 0 && (ep.decisionKind === "TAKE_YES" || ep.decisionKind === "TAKE_NO")) {
    return `clear ${side} take +${ep.feeNetCents}¢`;
  }
  if (ep.feeNetCents < 0) {
    return `${side} take fee-net ${ep.feeNetCents}¢`;
  }
  return `${ep.decisionKind} ${side} ${ep.feeNetCents}¢`;
}

export function buildHorizonPosture(secsRemaining: number | null | undefined): HorizonPosture {
  if (!(typeof secsRemaining === "number" && Number.isFinite(secsRemaining))) {
    return {
      phase: "unknown",
      bias: "CAUTIOUS",
      note: "secsRemaining UNKNOWN — no candle-phase weight",
      secsRemaining: null,
    };
  }
  const s = secsRemaining;
  // 15m candle: early >600, mid 180–600, late <180
  if (s > 600) {
    return {
      phase: "early",
      bias: "TAKE_OK",
      note: `early candle (${Math.round(s)}s) — room for edge to prove`,
      secsRemaining: s,
    };
  }
  if (s >= 180) {
    return {
      phase: "mid",
      bias: "CAUTIOUS",
      note: `mid candle (${Math.round(s)}s) — demand clearer confluence`,
      secsRemaining: s,
    };
  }
  return {
    phase: "late",
    bias: "SKIP_LEAN",
    note: `late candle (${Math.round(s)}s) — lean SKIP unless strong edge`,
    secsRemaining: s,
  };
}

function horizonWeightMul(horizon: HorizonPosture, strongEdge: boolean): number {
  if (horizon.phase === "late" && !strongEdge) return 0.55;
  if (horizon.phase === "late" && strongEdge) return 0.85;
  if (horizon.phase === "mid") return 0.85;
  if (horizon.phase === "early") return 1.0;
  return 0.9;
}

export function buildInnerCouncil(input: {
  soleDecision: string;
  side: "yes" | "no" | null;
  decisionKind: BrainDecisionKind;
  ccVel: string | null;
  mtfBullRed: boolean;
  regimeBlock: boolean;
  reflexHard: boolean;
  ruinWouldSell: boolean;
  exitHold: boolean;
  evCents: number | null;
  horizon: HorizonPosture;
  /** When inputsPresent, bias bull/bear/skip toward settlement pick. */
  settleSide?: SettleSideScoreResult | null;
  /** PhD: calibration skip lean 0..1 (bounded). */
  phdSkipLean?: number | null;
  /** PhD: option-value SKIP prefer. */
  phdPreferSkip?: boolean | null;
  /** PhD: EB council skip delta (clamped upstream). */
  phdEbSkipDelta?: number | null;
  /** SelfDrive: safety.brake → preferSkip lean (advisory; floors uncut). */
  selfDrivePreferSkip?: boolean | null;

  /** Captain heave-to → preferSkip lean (advisory; floors uncut). */
  captainPreferSkip?: boolean | null;
}): CouncilReport {
  const strongEdge =
    input.soleDecision === "TAKE" &&
    !input.ccVel &&
    !input.mtfBullRed &&
    !input.regimeBlock &&
    typeof input.evCents === "number" &&
    input.evCents >= MIND_FLOOR_LOCKS.evFloorCents;
  const wMul = horizonWeightMul(input.horizon, strongEdge);

  const bullReasons: string[] = [];
  const bearReasons: string[] = [];
  const skipReasons: string[] = [];

  let bullVote: CouncilAdvocate["vote"] = "HOLD";
  let bearVote: CouncilAdvocate["vote"] = "HOLD";
  let skipVote: CouncilAdvocate["vote"] = "SIT";
  let bullW = 0.25;
  let bearW = 0.25;
  let skipW = 0.5;

  if (input.reflexHard) {
    skipReasons.push("reflex hard-block owns tick");
    skipVote = "SKIP";
    skipW = 0.9;
    bullW = 0.05;
    bearW = 0.05;
    bullReasons.push("deferred to reflex");
    bearReasons.push("deferred to reflex");
  } else if (input.ruinWouldSell || input.exitHold) {
    bullVote = "HOLD";
    bearVote = "HOLD";
    skipVote = "SIT";
    bullReasons.push(input.ruinWouldSell ? "ruin shadow → ride/exit observe" : "PATH_RIDE HOLD");
    bearReasons.push("open book — no new entry");
    skipReasons.push("open-book posture");
    bullW = 0.35;
    bearW = 0.35;
    skipW = 0.3;
  } else if (input.soleDecision === "TAKE") {
    if (input.side === "no") {
      bearVote = "TAKE_NO";
      bearReasons.push("six-gate sole TAKE_NO");
      if (typeof input.evCents === "number") bearReasons.push(`EV ${input.evCents}¢`);
      bearW = 0.55 * wMul;
      bullVote = "HOLD";
      bullReasons.push("side is NO — bull sits");
      bullW = 0.15;
    } else {
      bullVote = "TAKE_YES";
      bullReasons.push("six-gate sole TAKE_YES");
      if (typeof input.evCents === "number") bullReasons.push(`EV ${input.evCents}¢`);
      bullW = 0.55 * wMul;
      bearVote = "HOLD";
      bearReasons.push("side is YES — bear sits");
      bearW = 0.15;
    }
    if (input.ccVel || input.mtfBullRed || input.regimeBlock) {
      skipVote = "SKIP";
      if (input.ccVel) skipReasons.push(`CC_VEL ${input.ccVel}`);
      if (input.mtfBullRed) skipReasons.push("MTF bull into red vel");
      if (input.regimeBlock) skipReasons.push("regimeWouldBlock");
      skipW = 0.7;
      bullW *= 0.35;
      bearW *= 0.35;
    } else {
      skipVote = "SIT";
      skipReasons.push("no capital veto — skip minority");
      skipW = 0.25;
      if (input.horizon.phase === "late") {
        skipReasons.push("late candle lean");
        skipW = 0.45;
        bullW *= 0.7;
        bearW *= 0.7;
      }
    }
  } else {
    skipVote = input.soleDecision === "SIT" ? "SIT" : "SKIP";
    skipReasons.push(`six-gate ${input.soleDecision}`);
    skipW = 0.7;
    bullVote = "HOLD";
    bearVote = "HOLD";
    bullReasons.push("no sole TAKE");
    bearReasons.push("no sole TAKE");
    bullW = 0.15;
    bearW = 0.15;
  }

  // Settlement side picker — smarter YES/NO/SKIP when sensors present
  const ss = input.settleSide;
  if (ss && ss.factors.inputsPresent) {
    const pick = ss.pick;
    const whyBits = [...ss.penalties, ...ss.reasons].slice(0, 3);
    const why = whyBits.length ? whyBits.join("; ") : `settle-side ${pick}`;
    if (pick === "skip") {
      skipVote = "SKIP";
      skipReasons.push(`settle-side SKIP: ${why}`);
      skipW = Math.max(skipW, 0.72);
      bullW *= 0.4;
      bearW *= 0.4;
      if (ss.factors.velAgainst) {
        skipReasons.push("vel-against hard settle penalty");
      }
      if (ss.factors.mtfVelConflict) {
        skipReasons.push("MTF+vel conflict");
      }
    } else if (pick === "yes") {
      bullVote = "TAKE_YES";
      bullReasons.push(`settle-side YES: ${why}`);
      bullW = Math.max(bullW, 0.5);
      // If sole wanted NO but settle says YES — dissent lean via weights
      if (input.side === "no") {
        bearReasons.push("sole NO vs settle-side YES — settle lean");
        bearW *= 0.5;
        skipW = Math.max(skipW, 0.35);
        skipReasons.push("side conflict settle vs sole");
      } else {
        bearW *= 0.55;
        skipW *= 0.7;
      }
    } else if (pick === "no") {
      bearVote = "TAKE_NO";
      bearReasons.push(`settle-side NO: ${why}`);
      bearW = Math.max(bearW, 0.5);
      if (input.side === "yes") {
        bullReasons.push("sole YES vs settle-side NO — settle lean");
        bullW *= 0.5;
        skipW = Math.max(skipW, 0.35);
        skipReasons.push("side conflict settle vs sole");
      } else {
        bullW *= 0.55;
        skipW *= 0.7;
      }
    }
  }


  // PhD layer — bounded SKIP lean (calibration / OV / EB). Never cuts floors.
  const phdLean =
    (typeof input.phdSkipLean === "number" ? input.phdSkipLean : 0) +
    (input.phdPreferSkip === true ? 0.08 : 0) +
    (typeof input.phdEbSkipDelta === "number" && input.phdEbSkipDelta > 0
      ? input.phdEbSkipDelta
      : 0);
    if (phdLean > 0.02 && !input.reflexHard && !input.ruinWouldSell && !input.exitHold) {
    skipW = Math.min(0.92, skipW + phdLean);
    skipVote = skipVote === "SIT" ? "SKIP" : skipVote;
    skipReasons.push(`phd SKIP lean +${Math.round(phdLean * 1000) / 1000}`);
    bullW *= 1 - Math.min(0.35, phdLean);
    bearW *= 1 - Math.min(0.35, phdLean);
  }
  // SelfDrive safety.brake — advisory preferSkip (same pattern as PhD OV; floors uncut)
  if (
    input.selfDrivePreferSkip === true &&
    !input.reflexHard &&
    !input.ruinWouldSell &&
    !input.exitHold
  ) {
    skipW = Math.min(0.95, skipW + 0.1);
    skipVote = skipVote === "SIT" ? "SKIP" : skipVote;
    skipReasons.push("selfDrive brake → PULL_OVER_SKIP lean");
    bullW *= 0.85;
    bearW *= 0.85;
  }
  // Captain HEAVE_TO — advisory preferSkip (same pattern; floors uncut)
  if (
    input.captainPreferSkip === true &&
    !input.reflexHard &&
    !input.ruinWouldSell &&
    !input.exitHold
  ) {
    skipW = Math.min(0.95, skipW + 0.08);
    skipVote = skipVote === "SIT" ? "SKIP" : skipVote;
    skipReasons.push("captain HEAVE_TO → preferSkip lean");
    bullW *= 0.88;
    bearW *= 0.88;
  }


  // normalize weights
  const sum = bullW + bearW + skipW || 1;
  bullW /= sum;
  bearW /= sum;
  skipW /= sum;

  const advocates: CouncilAdvocate[] = [
    { id: "bull", vote: bullVote, weight: round3(bullW), reasons: bullReasons },
    { id: "bear", vote: bearVote, weight: round3(bearW), reasons: bearReasons },
    { id: "skip", vote: skipVote, weight: round3(skipW), reasons: skipReasons },
  ];

  const resolved = input.decisionKind;
  // dissent when a minority advocate's vote disagrees with resolved tactical kind
  let dissent: CouncilDissent | null = null;
  const sorted = [...advocates].sort((a, b) => b.weight - a.weight);
  const minority = sorted[sorted.length - 1]!;
  const disagrees =
    (resolved === "TAKE_YES" && minority.vote !== "TAKE_YES" && minority.vote !== "HOLD") ||
    (resolved === "TAKE_NO" && minority.vote !== "TAKE_NO" && minority.vote !== "HOLD") ||
    ((resolved === "SKIP" || resolved === "HOLD" || resolved === "EXIT") &&
      (minority.vote === "TAKE_YES" || minority.vote === "TAKE_NO"));
  // Also: when resolved SKIP but bull/bear wanted TAKE
  const takeAdvocate = advocates.find(
    (a) => a.vote === "TAKE_YES" || a.vote === "TAKE_NO",
  );
  if (
    (resolved === "SKIP" || resolved === "HOLD" || resolved === "EXIT") &&
    takeAdvocate &&
    takeAdvocate.weight < 0.5
  ) {
    dissent = {
      minority: takeAdvocate.id,
      minorityVote: takeAdvocate.vote,
      resolved,
      note: `tactical ${resolved} over minority ${takeAdvocate.id}=${takeAdvocate.vote} (w=${takeAdvocate.weight})`,
    };
  } else if (disagrees && minority.weight < 0.4) {
    dissent = {
      minority: minority.id,
      minorityVote: minority.vote,
      resolved,
      note: `resolved ${resolved}; minority ${minority.id}=${minority.vote}`,
    };
  }

  return { advocates, resolved, dissent };
}

function round3(n: number): number {
  return Math.round(n * 1000) / 1000;
}

export function buildAttentionMap(input: {
  freshness: Freshness | null;
  ccVel: string | null;
  vel: number | null;
  mtf: number | null;
  askCents: number | null;
  thesisStatus: string | null;
  regimeBlock: boolean;
  ruinWouldSell: boolean;
  soleDecision: string;
  horizon: HorizonPosture;
  evCents: number | null;
}): AttentionSignal[] {
  const raw: AttentionSignal[] = [];
  if (input.freshness) {
    const stale = input.freshness.stale === true;
    raw.push({
      source: "freshness",
      signal: stale ? "STALE" : "FRESH",
      salience: stale ? 0.95 : Math.min(0.7, 0.2 + (input.freshness.ageMs > 500 ? 0.3 : 0.1)),
      note: `ageMs=${input.freshness.ageMs} src=${input.freshness.source}`,
    });
  }
  if (input.ccVel) {
    raw.push({
      source: "ccVel",
      signal: input.ccVel,
      salience: 0.92,
      note: `vel=${input.vel ?? "n/a"} $/min — against sole`,
    });
  } else {
    raw.push({
      source: "ccVel",
      signal: "SILENT",
      salience: 0.35,
      note: "no CC_VEL fire this tick",
    });
  }
  if (typeof input.mtf === "number") {
    raw.push({
      source: "mtf",
      signal: input.mtf > 0 ? "BULL" : input.mtf < 0 ? "BEAR" : "FLAT",
      salience: Math.min(0.85, 0.4 + Math.abs(input.mtf) / 20),
      note: `mtfScore=${input.mtf}`,
    });
  }
  if (typeof input.askCents === "number") {
    const inBand =
      input.askCents >= MIND_FLOOR_LOCKS.askMinCents &&
      input.askCents <= MIND_FLOOR_LOCKS.askMaxCents;
    raw.push({
      source: "ask",
      signal: inBand ? "IN_BAND" : "OUT_BAND",
      salience: inBand ? 0.45 : 0.8,
      note: `ask=${input.askCents}¢ band ${MIND_FLOOR_LOCKS.askMinCents}–${MIND_FLOOR_LOCKS.askMaxCents}`,
    });
  }
  if (input.thesisStatus) {
    raw.push({
      source: "thesis",
      signal: input.thesisStatus,
      salience: input.thesisStatus === "UNKNOWN" ? 0.75 : input.thesisStatus === "BROKEN" ? 0.9 : 0.4,
      note: `thesis=${input.thesisStatus}`,
    });
  }
  if (input.regimeBlock) {
    raw.push({
      source: "regime",
      signal: "WOULD_BLOCK",
      salience: 0.8,
      note: "regimeWouldBlock on sole path",
    });
  }
  if (input.ruinWouldSell) {
    raw.push({
      source: "ruinShadow",
      signal: "WOULD_SELL",
      salience: 0.88,
      note: "structuralRuinShadow.wouldSell observe",
    });
  }
  raw.push({
    source: "horizon",
    signal: input.horizon.phase.toUpperCase(),
    salience: input.horizon.phase === "late" ? 0.7 : input.horizon.phase === "early" ? 0.35 : 0.5,
    note: input.horizon.note,
  });
  if (typeof input.evCents === "number") {
    raw.push({
      source: "ev",
      signal: input.evCents >= MIND_FLOOR_LOCKS.evFloorCents ? "ABOVE_FLOOR" : "BELOW_FLOOR",
      salience: input.evCents < MIND_FLOOR_LOCKS.evFloorCents ? 0.9 : 0.5,
      note: `EV ${input.evCents}¢ vs floor ${MIND_FLOOR_LOCKS.evFloorCents}¢`,
    });
  }
  raw.sort((a, b) => b.salience - a.salience);
  return raw.slice(0, 5);
}

export function buildCuriosityGaps(input: {
  lagProven: boolean | null;
  thesisStatus: string | null;
  ccVel: string | null;
  soleDecision: string;
  depthKnown: boolean;
  secsRemaining: number | null;
  episodesEmpty: boolean;
}): CuriosityGap[] {
  const gaps: CuriosityGap[] = [];
  if (input.lagProven !== true) {
    gaps.push({
      code: "LAG_UNPROVEN",
      ask: "Is lag meter proven this session, or still unproven/stale?",
    });
  }
  if (input.thesisStatus === "UNKNOWN") {
    gaps.push({
      code: "THESIS_UNKNOWN",
      ask: "What would flip thesis UNKNOWN → VALID or BROKEN?",
    });
  }
  if (!input.ccVel && input.soleDecision === "TAKE") {
    gaps.push({
      code: "NO_CC_FIRE",
      ask: "CC silent on TAKE — would a vel fire change the veto?",
    });
  }
  if (!input.depthKnown) {
    gaps.push({
      code: "DEPTH_UNKNOWN",
      ask: "Book depth unstamped — would thin ask change size/skip?",
    });
  }
  if (input.secsRemaining == null) {
    gaps.push({
      code: "HORIZON_UNKNOWN",
      ask: "secsRemaining missing — candle phase weight unavailable",
    });
  }
  if (input.episodesEmpty) {
    gaps.push({
      code: "MEMORY_EMPTY",
      ask: "No episodic fee-net closes yet — memoryNote stays UNKNOWN",
    });
  }
  return gaps;
}

export function buildCounterfactualOnVeto(input: {
  soleDecision: string;
  side: "yes" | "no" | null;
  recommendation: BrainCenterRecommendation;
  ccVel: string | null;
  mtfBullRed: boolean;
  decisionKind: BrainDecisionKind;
}): CounterfactualVeto | null {
  const vetoingTake =
    input.soleDecision === "TAKE" &&
    (input.recommendation === "SIT" || input.recommendation === "SKIP");
  if (!vetoingTake) return null;
  const wouldHave: "TAKE_YES" | "TAKE_NO" =
    input.side === "no" ? "TAKE_NO" : "TAKE_YES";
  const becauseParts: string[] = [];
  if (input.ccVel) becauseParts.push(`CC_VEL ${input.ccVel}`);
  if (input.mtfBullRed) becauseParts.push("MTF_BULL_INTO_RED_VEL");
  if (becauseParts.length === 0) becauseParts.push("tactical/reflex veto");
  const hint = input.ccVel
    ? `ESTIMATE: CC_VEL against mean ${CC_VEL_AGAINST_MEAN_FEE_NET_ESTIMATE_CENTS}¢ vs skip≈0 (deep-dive n≪40; not live P&L)`
    : `ESTIMATE: fee-net vs skip unknown without CC_VEL prior — skip≈0; no invented live P&L`;
  return {
    wouldHave,
    because: becauseParts.join(" + "),
    feeNetVsSkipHint: hint,
  };
}

export function buildThought(input: {
  decisionKind: BrainDecisionKind;
  council: CouncilReport;
  curiosity: CuriosityGap[];
  horizon: HorizonPosture;
  counterfactual: CounterfactualVeto | null;
  goldenBottomLine?: string | null;
}): string {
  if (input.goldenBottomLine && input.goldenBottomLine.trim()) {
    return input.goldenBottomLine.trim();
  }
  const topAdv = [...input.council.advocates].sort((a, b) => b.weight - a.weight)[0];
  const cur =
    input.curiosity[0]?.code === "NO_CC_FIRE"
      ? "curiosity: CC silent"
      : input.curiosity[0]
        ? `curiosity: ${input.curiosity[0].code}`
        : "curiosity: clear";
  const verb =
    input.decisionKind === "TAKE_YES"
      ? "Take YES"
      : input.decisionKind === "TAKE_NO"
        ? "Take NO"
        : input.decisionKind === "HOLD"
          ? "Hold"
          : input.decisionKind === "EXIT"
            ? "Exit-shadow"
            : "Skip";
  const councilBit = topAdv
    ? `council ${topAdv.id} ${topAdv.vote} (w=${topAdv.weight})`
    : "council thin";
  const late = input.horizon.phase === "late" ? "; late candle" : "";
  const cf = input.counterfactual
    ? `; cf wouldHave ${input.counterfactual.wouldHave}`
    : "";
  return `${verb} — ${councilBit}; ${cur}${late}${cf}.`;
}

/**
 * GoldenEgg cognition loop — deterministic mirror of desk programmer agent voice.
 * No LLM. BOTTOM LINE first. Epistemic labels honest.
 */
export function buildGoldenEggThought(input: {
  decisionKind: BrainDecisionKind;
  recommendation: BrainCenterRecommendation;
  soleDecision: string;
  soleCode: string;
  side: "yes" | "no" | null;
  conflicts: BrainCenterConflict[];
  evidence: BrainCenterEvidence[];
  mind: BrainMind;
  council: CouncilReport;
  curiosity: CuriosityGap[];
  counterfactual: CounterfactualVeto | null;
  horizon: HorizonPosture;
  critique: SelfCritique;
  ccVel: string | null;
  mtfBullRed: boolean;
  reflexHard: boolean;
  episodesEmpty: boolean;
}): GoldenEggThought {
  const recommendedAction: GoldenEggThought["recommendedAction"] =
    input.recommendation === "EXIT_SHADOW"
      ? "EXIT"
      : input.recommendation === "SIT"
        ? "SIT"
        : input.recommendation === "HOLD"
          ? "HOLD"
          : input.recommendation === "TAKE"
            ? input.side === "no"
              ? "TAKE_NO"
              : "TAKE_YES"
            : "SKIP";

  const topConflict = input.conflicts[0]?.code ?? null;
  const whyBits: string[] = [];
  whyBits.push(`sole=${input.soleDecision}/${input.soleCode}`);
  whyBits.push(`winner=${input.mind.winner}`);
  if (topConflict) whyBits.push(`conflict=${topConflict}`);
  if (input.ccVel) whyBits.push(`ccVel=${input.ccVel}`);
  if (input.mtfBullRed) whyBits.push("mtfBullIntoRed");
  if (input.horizon.phase !== "unknown") whyBits.push(`horizon=${input.horizon.phase}`);
  whyBits.push(input.mind.winnerWhy);

  let diagnosis = "none — skip is valid";
  if (input.reflexHard) {
    diagnosis = `highest problem: reflex hard-block (${input.mind.winnerWhy})`;
  } else if (input.ccVel) {
    diagnosis =
      "highest fee-net problem: CC_VEL against sole TAKE (deep-dive mean ESTIMATE −394¢ vs skip≈0; n≪40)";
  } else if (input.mtfBullRed) {
    diagnosis = "highest fee-net problem: MTF bull into red velocity cofactor";
  } else if (input.horizon.phase === "late" && input.soleDecision === "TAKE") {
    diagnosis = "highest problem: late candle TAKE without strong edge";
  } else if (topConflict) {
    diagnosis = `highest problem: ${topConflict}`;
  } else if (input.decisionKind === "TAKE_YES" || input.decisionKind === "TAKE_NO") {
    diagnosis = "none — clear path; fee-net must still beat skip";
  }

  const skipIsValid =
    recommendedAction === "SKIP" ||
    recommendedAction === "SIT" ||
    recommendedAction === "HOLD" ||
    input.reflexHard ||
    Boolean(input.ccVel) ||
    input.horizon.phase === "late";

  const bottomLine =
    recommendedAction === "TAKE_YES"
      ? `BOTTOM LINE: TAKE YES — ${input.mind.winnerWhy}`
      : recommendedAction === "TAKE_NO"
        ? `BOTTOM LINE: TAKE NO — ${input.mind.winnerWhy}`
        : recommendedAction === "HOLD"
          ? `BOTTOM LINE: HOLD — ride book; PATH_RIDE owns exit`
          : recommendedAction === "EXIT"
            ? `BOTTOM LINE: EXIT shadow — observe only; never auto-SELL`
            : recommendedAction === "SIT"
              ? `BOTTOM LINE: SIT — sole TAKE vetoed; skip≈0 beats taking against evidence`
              : `BOTTOM LINE: SKIP — ${input.mind.winnerWhy}`;

  const risks: string[] = [];
  if (recommendedAction === "TAKE_YES" || recommendedAction === "TAKE_NO") {
    risks.push("If CC_VEL fires post-entry, fee-net may bleed vs skip (ESTIMATE −394¢ prior)");
    risks.push("If thesis flips UNKNOWN→BROKEN, PATH_RIDE may hold into ruin");
    if (input.horizon.phase === "late") risks.push("Late candle — little time to recover");
  } else {
    risks.push("False skip: clear edge left on table if vel was noise");
    if (input.curiosity.some((c) => c.code === "NO_CC_FIRE")) {
      risks.push("CC silent — waiting may be fear if six-gate edge is real");
    }
  }
  if (input.critique.worries.length) {
    risks.push(...input.critique.worries.slice(0, 2));
  }

  const cheapestNextCheck =
    input.curiosity[0]?.ask ??
    input.critique.wouldChangeNext ??
    "Re-stamp freshness + CC_VEL on next tick";

  const successCriteria =
    recommendedAction === "SKIP" || recommendedAction === "SIT"
      ? "Right if avoided fee-net bleed vs skip≈0; wrong only if clear TAKE would have printed fee-net > 0 with same stamps"
      : recommendedAction === "HOLD" || recommendedAction === "EXIT"
        ? "Right if PATH_RIDE exit/hold fee-net ≥ forced early exit; incomplete settle ≠ win"
        : "Right if closed fee-net > 0 vs skip≈0 on this identity (±1¢); wrong if vel-against or EV floor break";

  const feeNetVsSkip = input.counterfactual
    ? `fee-net vs skip: ${input.counterfactual.feeNetVsSkipHint}`
    : recommendedAction === "SKIP" || recommendedAction === "SIT"
      ? "fee-net vs skip: skip≈0 — preferred until MEASUREMENT beats sitting"
      : "fee-net vs skip: TAKE only if expected fee-net > 0 after fees; skip≈0 is the baseline";

  // Enrich evidence copy with ESTIMATE/UNKNOWN rows when relevant (do not mutate caller array semantics — append labeled rows)
  const evidence: BrainCenterEvidence[] = [...input.evidence];
  if (input.ccVel) {
    evidence.push({
      label: "ESTIMATE",
      code: "CC_VEL_AGAINST_MEAN_PRIOR",
      detail: `CC_VEL against mean ${CC_VEL_AGAINST_MEAN_FEE_NET_ESTIMATE_CENTS}¢ (deep-dive; n≪40; not live P&L)`,
    });
  }
  if (input.episodesEmpty) {
    evidence.push({
      label: "UNKNOWN",
      code: "EPISODIC_MEMORY_EMPTY",
      detail: "No episodic fee-net closes yet — memoryNote UNKNOWN",
    });
  }
  if (input.horizon.phase === "unknown") {
    evidence.push({
      label: "UNKNOWN",
      code: "HORIZON_SECS_UNKNOWN",
      detail: "secsRemaining missing — candle phase weight unavailable",
    });
  }
  evidence.push({
    label: "ASSUMPTION",
    code: "SKIP_BASELINE",
    detail: "skip≈0 is the fee-net baseline for every TAKE comparison",
  });
  if (input.council.dissent) {
    evidence.push({
      label: "HYPOTHESIS",
      code: "COUNCIL_DISSENT",
      detail: input.council.dissent.note,
    });
  }

  const sampleInsufficient = Boolean(input.ccVel) || input.episodesEmpty;

  return {
    bottomLine,
    evidence,
    diagnosis,
    recommendedAction,
    why: whyBits.join(" → "),
    risks,
    cheapestNextCheck,
    successCriteria,
    feeNetVsSkip,
    doctrine: {
      skipIsValid,
      noMoreTradesOptimization: true,
      floorsUncut: true,
      sampleInsufficient,
    },
  };
}

export function buildSelfCritique(input: {
  decisionKind: BrainDecisionKind;
  council: CouncilReport;
  curiosity: CuriosityGap[];
  ccVel: string | null;
  horizon: HorizonPosture;
  reflexHard: boolean;
}): SelfCritique {
  const worries: string[] = [];
  let wouldChangeNext: string | null = null;
  const skipWins =
    input.decisionKind === "SKIP" || input.decisionKind === "HOLD";
  const ccSilent = !input.ccVel;
  if (skipWins && ccSilent && input.curiosity.some((c) => c.code === "NO_CC_FIRE" || c.code === "MEMORY_EMPTY")) {
    worries.push("council skip but CC silent — waiting not fear");
  }
  if (input.horizon.phase === "late" && (input.decisionKind === "TAKE_YES" || input.decisionKind === "TAKE_NO")) {
    worries.push("late candle TAKE — edge must be strong");
    wouldChangeNext = "If vel flips against side, veto immediately";
  }
  if (input.council.dissent) {
    worries.push(`dissent: ${input.council.dissent.note}`);
  }
  if (input.reflexHard) {
    worries.push("reflex owned tick — rails over opinion");
  }
  if (input.curiosity.some((c) => c.code === "LAG_UNPROVEN")) {
    worries.push("lag unproven — size/skip sensitivity UNKNOWN");
    wouldChangeNext = wouldChangeNext ?? "Re-check lagProven before next TAKE";
  }
  const ok = worries.length === 0;
  if (ok) {
    return { ok: true, worries: [], wouldChangeNext: null };
  }
  return {
    ok: false,
    worries,
    wouldChangeNext: wouldChangeNext ?? "Hold posture unless new MEASUREMENT arrives",
  };
}

export function buildForesight(input: {
  decisionKind: BrainDecisionKind;
  side: "yes" | "no" | null;
  ccVel: string | null;
  soleDecision: string;
  horizon: HorizonPosture;
  reflexHard: boolean;
}): ForesightHint {
  if (input.reflexHard) {
    return {
      nextLikely: "SKIP",
      confidenceBand: "high",
      label: "INFERENCE",
      note: "rails hard — nextLikely SKIP until paper/fresh/EV clear",
    };
  }
  if (input.horizon.phase === "late") {
    return {
      nextLikely: "SKIP",
      confidenceBand: "mid",
      label: "INFERENCE",
      note: "late candle — one-step lean SKIP unless new confluence",
    };
  }
  if (input.soleDecision === "TAKE" && input.ccVel) {
    return {
      nextLikely: "SKIP",
      confidenceBand: "mid",
      label: "INFERENCE",
      note: "if CC_VEL clears, revisit TAKE; else stay SKIP",
    };
  }
  if (input.soleDecision === "TAKE" && !input.ccVel) {
    const next = input.side === "no" ? "TAKE_NO" : "TAKE_YES";
    return {
      nextLikely: next,
      confidenceBand: input.horizon.phase === "early" ? "mid" : "low",
      label: "INFERENCE",
      note: "clear vel path — nextLikely same TAKE if stamps hold",
    };
  }
  return {
    nextLikely: "SKIP",
    confidenceBand: "mid",
    label: "INFERENCE",
    note: "no sole TAKE — nextLikely SKIP",
  };
}

export function buildRhythm(input: {
  nowMs: number;
  lastTickMs: number | null | undefined;
  reflex: MindLayer;
  tactical: MindLayer;
  strategic: MindLayer;
  council: CouncilReport;
  decisionKind: BrainDecisionKind;
}): RhythmPulse {
  const pulseMs =
    typeof input.lastTickMs === "number" && Number.isFinite(input.lastTickMs)
      ? Math.max(0, input.nowMs - input.lastTickMs)
      : null;
  const cadenceNote =
    pulseMs == null
      ? "cadence UNKNOWN — first/isolated tick"
      : pulseMs < 400
        ? `fast tick ${pulseMs}ms`
        : pulseMs < 2000
          ? `steady tick ${pulseMs}ms`
          : `slow tick ${pulseMs}ms`;

  // coherence: reflex PASS aligned with tactical, council majority matches decisionKind
  let score = 0.5;
  if (input.reflex.hard) {
    score = input.decisionKind === "SKIP" ? 0.95 : 0.4;
  } else {
    const tacOk =
      (input.tactical.verdict === "YES" && input.decisionKind === "TAKE_YES") ||
      (input.tactical.verdict === "YES" && input.decisionKind === "TAKE_NO") ||
      (input.tactical.verdict === "NO" && input.decisionKind === "SKIP") ||
      (input.tactical.verdict === "SKIP" && input.decisionKind === "SKIP") ||
      (input.tactical.verdict === "HOLD" && input.decisionKind === "HOLD") ||
      (input.tactical.verdict === "EXIT" && input.decisionKind === "EXIT");
    score = tacOk ? 0.75 : 0.45;
    if (input.strategic.verdict === "PASS") score += 0.05;
    const top = [...input.council.advocates].sort((a, b) => b.weight - a.weight)[0];
    if (top) {
      const councilAlign =
        (top.vote === "TAKE_YES" && input.decisionKind === "TAKE_YES") ||
        (top.vote === "TAKE_NO" && input.decisionKind === "TAKE_NO") ||
        ((top.vote === "SKIP" || top.vote === "SIT") &&
          (input.decisionKind === "SKIP" || input.decisionKind === "HOLD")) ||
        (top.vote === "HOLD" &&
          (input.decisionKind === "HOLD" || input.decisionKind === "EXIT"));
      score += councilAlign ? 0.15 : -0.1;
    }
    if (input.council.dissent) score -= 0.08;
  }
  const coherenceScore = Math.max(0, Math.min(1, Math.round(score * 100) / 100));
  return { pulseMs, cadenceNote, coherenceScore };
}


function buildStory(input: {
  soleDecision: string;
  soleCode: string;
  recommendation: BrainCenterRecommendation;
  decisionKind: BrainDecisionKind;
  conflicts: BrainCenterConflict[];
  mind: BrainMind;
  memoryNote: string;
  feeNetHint: string | null;
  bottomLine?: string | null;
}): string {
  const top =
    input.conflicts[0]?.code ??
    (input.mind.winner === "reflex" ? "REFLEX_CLEAR" : "NONE");
  const lead =
    input.bottomLine && input.bottomLine.trim()
      ? input.bottomLine.trim()
      : `BOTTOM LINE: ${input.decisionKind}`;
  const organs = `Organs stamped sole=${input.soleDecision}/${input.soleCode}.`;
  const mindSaid =
    `Oracle Mind winner=${input.mind.winner} → ${input.decisionKind} ` +
    `(${input.recommendation}): ${input.mind.winnerWhy}.`;
  const conflict =
    input.conflicts.length > 0
      ? `Top conflict ${top}.`
      : "No capital conflicts stamped.";
  const fee =
    input.feeNetHint ??
    "Fee-net vs skip: skip≈0; TAKE only when evidence beats sitting.";
  return `${lead} ${organs} ${mindSaid} ${conflict} ${fee} Memory: ${input.memoryNote}`;
}

/**
 * Interpret stamped organ messages through the three-layer Oracle Mind.
 * Never spends. Reflex hard-blocks cannot be overridden by tactical/strategic.
 */
export function interpretBrainCenter(input: BrainCenterInput): BrainCenterReport {
  const nowMs =
    typeof input.nowMs === "number" && Number.isFinite(input.nowMs)
      ? input.nowMs
      : Date.now();
  const evidence: BrainCenterEvidence[] = [];
  const conflicts: BrainCenterConflict[] = [];
  const frozen = input.frozenCcMode === true;
  const paperMode = input.paperMode !== false; // fail-open missing→true for frozen desk; explicit false hard-blocks
  const admission = input.admission ?? null;
  const sole =
    admission?.soleAuthority ?? (frozen ? "decideFrozenCcEntry" : "none");
  const soleDecision = admission?.decision ?? "SKIP";
  const soleCode = admission?.code ?? "no_admission_stamp";
  const side = admission?.identity?.side ?? null;
  const evCents =
    typeof admission?.identity?.evCents === "number"
      ? admission.identity.evCents
      : null;

  pushEvidence(
    evidence,
    "FACT",
    "SOLE_AUTHORITY",
    `soleAuthority=${sole} decision=${soleDecision} code=${soleCode}`,
  );
  pushEvidence(
    evidence,
    "FACT",
    "FROZEN_MODE",
    frozen
      ? "frozenCcMode=true → Mind HEAVE/preferSkip binds at placeOrder; six-gate sole positive TAKE; soft CC_VEL soft"
      : "frozenCcMode=false → cortex still advisory until proven",
  );
  pushEvidence(
    evidence,
    "FACT",
    "PAPER_MODE",
    `paperMode=${paperMode}`,
  );

  if (admission?.identity) {
    const id = admission.identity;
    pushEvidence(
      evidence,
      "MEASUREMENT",
      "IDENTITY",
      `side=${id.side} ask=${id.askCents} p=${id.p} pSource=${id.pSource} evCents=${id.evCents}`,
    );
    if (id.pSource !== "winRateAtPrice") {
      pushEvidence(
        evidence,
        "INFERENCE",
        "P_SOURCE_WARN",
        "pSource must be winRateAtPrice — confidence never p",
      );
    }
  }

  const freshness = input.feedFreshness ?? input.sensorBundle?.freshness ?? null;
  let stale = false;
  if (freshness) {
    stale = freshness.stale === true;
    pushEvidence(
      evidence,
      "MEASUREMENT",
      "FEED_FRESHNESS",
      `ageMs=${freshness.ageMs} source=${freshness.source} stale=${freshness.stale}`,
    );
    if (stale && soleDecision === "TAKE") {
      pushConflict(
        conflicts,
        "STALE_FEED_VS_TAKE",
        "FACT",
        "Feed freshness stale while sole decision is TAKE — fail-closed expectation",
      );
    }
  }

  if (input.sensorBundle) {
    pushEvidence(
      evidence,
      "FACT",
      "SENSOR_DOCTRINE",
      `advisory=${input.sensorBundle.advisory} fillGate=${input.sensorBundle.fillGate}`,
    );
  }

  const sizeZero =
    (typeof input.proposedSize === "number" && input.proposedSize <= 0) ||
    /SIZE_ZERO|size_zero|SIZING_ZERO/i.test(soleCode);

  if (!paperMode && soleDecision === "TAKE") {
    pushConflict(
      conflicts,
      "NOT_PAPER_REFLEX",
      "FACT",
      "paperMode false — reflex refuses mind-authorized spend",
    );
  }
  if (sizeZero) {
    pushConflict(
      conflicts,
      "SIZE_ZERO_REFLEX",
      "FACT",
      "proposed size 0 / SIZE_ZERO code — reflex SKIP",
    );
  }
  if (
    soleDecision === "TAKE" &&
    typeof evCents === "number" &&
    evCents < MIND_FLOOR_LOCKS.evFloorCents
  ) {
    pushConflict(
      conflicts,
      "EV_FLOOR_REFLEX",
      "MEASUREMENT",
      `evCents=${evCents} < floor ${MIND_FLOOR_LOCKS.evFloorCents}`,
    );
  }

  const shadow = input.frozenShadow ?? null;
  const ccVel = shadow?.ccVelocityWouldBlock ?? null;
  const vel = shadow?.velocityDolPerMin ?? null;
  const mtf = shadow?.mtfScore ?? null;
  const mtfBullRed = isMtfBullIntoRedVel(side, mtf, vel, ccVel);

  if (ccVel) {
    pushEvidence(
      evidence,
      "MEASUREMENT",
      "CC_VEL_AGAINST",
      `ccVelocityWouldBlock=${ccVel} vel=${vel ?? "n/a"} mtf=${mtf ?? "n/a"}`,
    );
    if (soleDecision === "TAKE") {
      pushConflict(
        conflicts,
        "CC_VEL_AGAINST_SOLE_TAKE",
        "MEASUREMENT",
        `Sole TAKE with ${ccVel} stamped — tactical veto; n≪40 → shadow not six-gate hard law`,
      );
    }
  }
  if (mtfBullRed && soleDecision === "TAKE") {
    pushConflict(
      conflicts,
      "MTF_BULL_INTO_RED_VEL",
      "MEASUREMENT",
      `mtfScore=${mtf} vel=${vel} — bull MTF into red velocity (deep-dive cofactor)`,
    );
  }

  if (shadow?.regimeWouldBlock === true && soleDecision === "TAKE") {
    pushEvidence(
      evidence,
      "MEASUREMENT",
      "REGIME_WOULD_BLOCK",
      "regimeWouldBlock=true on sole TAKE",
    );
    pushConflict(
      conflicts,
      "REGIME_WOULD_BLOCK_SOLE_TAKE",
      "MEASUREMENT",
      "Regime sensor would block — tactical capital veto",
    );
  }

  if (
    frozen &&
    soleDecision === "TAKE" &&
    admission?.advisoryParallel?.action === "skip"
  ) {
    pushConflict(
      conflicts,
      "SOLE_TAKE_VS_ORGAN_SKIP",
      "FACT",
      "Frozen sole TAKE vs organ advisory skip — sole stamp stands; organ is FROZEN_ORGANS_ADVISORY",
    );
  }

  const exit = input.exitMonitor ?? null;
  if (exit) {
    pushEvidence(
      evidence,
      "MEASUREMENT",
      "EXIT_MONITOR",
      `action=${exit.action} thesis=${exit.thesisStatus} feeNetTpOk=${exit.feeNetTpOk} step=${exit.firstMatchStep}`,
    );
    if (exit.thesisStatus === "UNKNOWN") {
      const reasons = (exit.thesisReasons ?? []).join(",") || "none";
      pushConflict(
        conflicts,
        "THESIS_UNKNOWN_OPEN",
        "FACT",
        `Open thesis UNKNOWN reasons=[${reasons}] — not BROKEN alone`,
      );
    }
  }

  const ruin =
    input.structuralRuinShadow ?? exit?.structuralRuinShadow ?? null;
  if (ruin?.wouldSell === true) {
    pushConflict(
      conflicts,
      "STRUCTURAL_RUIN_SHADOW_OPEN",
      "INFERENCE",
      `structuralRuinShadow.wouldSell reasons=[${ruin.reasons.join(",")}] observeOnly`,
    );
    pushEvidence(
      evidence,
      "INFERENCE",
      "STRUCTURAL_RUIN_SHADOW",
      "EXIT_SHADOW candidate — never auto-SELL; PATH_RIDE owns exit",
    );
  }

  const settle = input.settleStamp ?? null;
  let feeNetHint: string | null = null;
  if (settle?.stampStatus === "STORY_STAMP_INCOMPLETE") {
    pushConflict(
      conflicts,
      "SETTLE_INCOMPLETE",
      "FACT",
      "Settle stamp incomplete — incomplete ≠ win; fee-net attribution pending",
    );
  }
  if (settle && settle.feeNetVsSkip != null) {
    feeNetHint = `Last settle feeNetVsSkip=${settle.feeNetVsSkip} feeNetCents=${settle.feeNetCents}`;
    pushEvidence(
      evidence,
      "MEASUREMENT",
      "FEE_NET_VS_SKIP",
      feeNetHint,
    );
  }

  const ctx = input.strategicContext ?? null;
  const secsRemainingEarly =
    typeof input.secsRemaining === "number" && Number.isFinite(input.secsRemaining)
      ? input.secsRemaining
      : null;
  const horizonEarly = buildHorizonPosture(secsRemainingEarly);
  const reflex = buildReflexLayer({
    stale,
    paperMode,
    soleDecision,
    evCents,
    sizeZero,
    code: soleCode,
  });
  const tactical = buildTacticalLayer({
    soleDecision,
    side,
    ccVel,
    mtfBullRed,
    regimeBlock: shadow?.regimeWouldBlock === true,
    ruinWouldSell: ruin?.wouldSell === true,
    exitAction: exit?.action ?? null,
    reflexHard: reflex.hard === true,
    horizon: horizonEarly,
    evCents,
  });
  const strategic = buildStrategicLayer({
    regimeBlock: shadow?.regimeWouldBlock === true,
    session: ctx?.session ?? null,
    drawdownPct:
      typeof ctx?.drawdownPct === "number" ? ctx.drawdownPct : null,
    promoteReady:
      typeof ctx?.promoteReady === "boolean" ? ctx.promoteReady : null,
    regimeLabel: ctx?.regimeLabel ?? null,
    ccVelConflictOpen: Boolean(ccVel && soleDecision === "TAKE"),
  });

  const { winner, winnerWhy } = pickWinner(reflex, tactical);
  const mind: BrainMind = {
    layers: [reflex, tactical, strategic],
    winner,
    winnerWhy,
  };

  const recommendation = recommendationFromMind(
    winner,
    reflex,
    tactical,
    soleDecision,
  );
  const decisionKind = decisionKindFromMind(recommendation, side);

  const episodes =
    input.episodes ?? (episodeRing.length > 0 ? episodeRing : []);
  const memoryNote = annotateMemoryNote(episodes);
  const journalTail = queryEpisodes(episodes, EPISODE_QUERY_DEFAULT);

  const confidenceBand: ConfidenceBand =
    conflicts.length === 0
      ? "mid"
      : conflicts.some(
            (c) =>
              c.code === "STALE_FEED_VS_TAKE" ||
              c.code === "EV_FLOOR_REFLEX" ||
              c.code === "NOT_PAPER_REFLEX",
          )
        ? "low"
        : "low";

  const interpretationParts = [
    frozen
      ? "Oracle Mind under frozen: HEAVE/preferSkip binds at placeOrder; six-gate remains sole positive TAKE authority; soft CC_VEL alone stays soft."
      : "Oracle Mind advisory: organTake identity ±1¢ still required for non-frozen place; cortex never bypasses.",
    `Sole=${soleDecision}/${soleCode}.`,
    `Mind winner=${winner}: ${winnerWhy}.`,
    conflicts.length
      ? `Conflicts: ${conflicts.map((c) => c.code).join(", ")}.`
      : "No conflicts stamped.",
    recommendation === "SIT" && soleDecision === "TAKE" && ccVel
      ? "Fee-net framing: vel-against TAKEs bled vs skip (n≪40, INSUFFICIENT for hard six-gate)."
      : "Fee-net framing: prefer skip when evidence does not beat sitting.",
  ];

  const secsRemaining = secsRemainingEarly;
  const horizon = horizonEarly;
  const exitHold =
    Boolean(exit?.action) &&
    (String(exit?.action).includes("HOLD") ||
      String(exit?.action).startsWith("PATH_RIDE_HOLD"));
  const askCents =
    typeof admission?.identity?.askCents === "number"
      ? admission.identity.askCents
      : null;
  // Real depth (was hard-coded depthKnown:false / thinBook:true). Unknown →
  // thinBook stays true downstream (fail safe; raises min_edge, never lowers).
  const bookDepth = stampBookDepth({
    snapshot: input.orderbook ?? null,
    ticker: input.ticker ?? null,
    side: side === "yes" || side === "no" ? side : null,
    askCents,
    balanceCents: input.balanceCents ?? null,
    nowMs,
    consistency: input.orderbookConsistency ?? null,
  });
  const thinBookReal: boolean = bookDepth.depthKnown ? bookDepth.thinBook === true : true;
  pushEvidence(
    evidence,
    bookDepth.depthKnown ? "FACT" : "UNKNOWN",
    "BOOK_DEPTH",
    bookDepth.reason,
  );
  const lagProven =
    input.sensorBundle?.lag?.lagProven === true
      ? true
      : input.sensorBundle?.lag
        ? false
        : null;
  const lagStale =
    input.sensorBundle?.lag?.lagStale === true
      ? true
      : shadow?.lagStale === true
        ? true
        : input.sensorBundle?.lag
          ? false
          : shadow?.lagStale === false
            ? false
            : null;
  const constructedNo =
    shadow?.constructedNo === true
      ? true
      : shadow?.constructedNo === false
        ? false
        : null;
  const settleSideInput: SettleSideScoreInput = {
    side,
    ccVelocityWouldBlock: ccVel,
    velocityDolPerMin: typeof vel === "number" ? vel : null,
    mtfScore: typeof mtf === "number" ? mtf : null,
    lagProven:
      lagProven != null
        ? lagProven
        : shadow?.lagProven != null
          ? shadow.lagProven === true
          : null,
    lagStale,
    askCents,
    constructedNo,
  };
  const settleSideScore: SettleSideScoreResult | null =
    settleSideInput.side != null ||
    settleSideInput.ccVelocityWouldBlock != null ||
    settleSideInput.velocityDolPerMin != null ||
    settleSideInput.mtfScore != null ||
    settleSideInput.lagProven != null ||
    settleSideInput.lagStale != null ||
    settleSideInput.askCents != null ||
    settleSideInput.constructedNo != null
      ? scoreSettleSide(settleSideInput)
      : null;
  if (settleSideScore?.factors.inputsPresent) {
    pushEvidence(
      evidence,
      "INFERENCE",
      SETTLE_SIDE_SCORE_LOADED,
      `pick=${settleSideScore.pick} yes=${settleSideScore.scoreYes} no=${settleSideScore.scoreNo} penalties=${settleSideScore.penalties.slice(0, 2).join("|") || "none"}`,
    );
  }
  // ── PhD layer (pure): calibration · uncertainty · OV-SKIP · EB ───────────
  const calibration = calibrationSnapshot();
  const echoN =
    typeof input.phdContext?.echoN === "number"
      ? input.phdContext.echoN
      : null;
  const echoMean =
    typeof input.phdContext?.echoMeanFeeNet === "number"
      ? input.phdContext.echoMeanFeeNet
      : null;
  const uncertaintyPack = buildUncertaintyReport({
    settleSide: settleSideScore,
    echoN,
    echoMeanFeeNet: echoMean,
    secsRemaining,
    calibrationUnreliable: !calibration.reliable,
  });
  const ebNudges = empiricalBayesWeightNudges(getScarRing());
  const topEb =
    ebNudges.find((e) =>
      conflicts.some((c) => c.code === e.conflictCode),
    ) ?? ebNudges[0] ?? null;
  const phdEbDelta =
    topEb && topEb.councilSkipWeightDelta > 0
      ? topEb.councilSkipWeightDelta
      : 0;
  const phdSkipLean =
    (calibration.reliable ? 0 : calibration.skipLean) +
    (uncertaintyPack.optionValueSkip.preferSkip
      ? uncertaintyPack.optionValueSkip.score * 0.5
      : 0);
  const causalNote =
    (input.phdContext?.causalNote && String(input.phdContext.causalNote)) ||
    (episodes.some((e) => e.exitSavedWrongSide === true)
      ? "recent episodes include exitSavedWrongSide — side-picker weight discounted on TP-saved"
      : episodes.some((e) => e.sideCorrect === false)
        ? "recent episodes include sideCorrect=false settle mistakes — side-picker weight high"
        : "no causal tattoos yet — attribution arms on next closes");
  const phd: PhdThought = {
    calibration,
    uncertainty: uncertaintyPack.sideConfidence,
    optionValueSkip: uncertaintyPack.optionValueSkip,
    causalNote,
    empiricalBayes: ebNudges.slice(0, 5),
    references: [
      MIND_CALIBRATION_LOADED,
      MIND_UNCERTAINTY_LOADED,
      MIND_CAUSAL_LOADED,
      "ECE=Σ|acc−conf|·n_b/N",
      "OV=clamp(0.15·I(secs≥420)+0.25·I(coversBoth)+0.20·I(velMtf)+0.10·I(calibUnrel),0,0.55)",
      "EB: μ_post=(κ·0+n·μ̂)/(κ+n) κ=12",
      "causal: PATH_RIDE_TP∧side≠settle → exitSavedWrongSide weight=0.25; settle-hold wrong → weight=1.0",
    ],
  };
  pushEvidence(
    evidence,
    calibration.label === "MEASUREMENT" ? "MEASUREMENT" : "ESTIMATE",
    MIND_CALIBRATION_LOADED,
    `n=${calibration.n} ece=${calibration.ece} reliable=${calibration.reliable}`,
  );
  pushEvidence(
    evidence,
    uncertaintyPack.sideConfidence.label === "MEASUREMENT"
      ? "MEASUREMENT"
      : uncertaintyPack.sideConfidence.label === "INFERENCE"
        ? "INFERENCE"
        : "ESTIMATE",
    MIND_UNCERTAINTY_LOADED,
    uncertaintyPack.sideConfidence.note,
  );
  if (uncertaintyPack.optionValueSkip.preferSkip) {
    pushEvidence(
      evidence,
      "INFERENCE",
      "OPTION_VALUE_SKIP",
      `OV=${uncertaintyPack.optionValueSkip.score} preferSkip — ${uncertaintyPack.optionValueSkip.reasons.slice(0, 2).join("; ")}`,
    );
  }

  // ── PhD trading-education (pure common-sense) — soft heave; floors uncut ──
  const confBandForEdu = confidenceBand;
  const settlePickForEdu =
    settleSideScore?.pick === "yes" ||
    settleSideScore?.pick === "no" ||
    settleSideScore?.pick === "skip"
      ? settleSideScore.pick
      : null;
  const phdEducation = evaluatePhdCommonSense({
    pWin:
      typeof admission?.identity?.p === "number" &&
      Number.isFinite(admission.identity.p)
        ? admission.identity.p
        : null,
    askCents,
    side,
    ccVel,
    mtfBullRed,
    settleSide: settlePickForEdu,
    evCents,
    soleDecision,
    confidenceBand: confBandForEdu,
    slipDefaultCents: 2,
    openSide: exitHold && (side === "yes" || side === "no") ? side : null,
  });
  pushEvidence(
    evidence,
    "INFERENCE",
    PHD_TRADING_EDUCATION_LOADED,
    `heave=${phdEducation.heaveTo} abandon=${phdEducation.abandonLean} edgeNet=${phdEducation.edgeNetAfterSlip ?? "n/a"} — ${phdEducation.commonSenseSummary}`,
  );
  if (phdEducation.heaveTo) {
    pushEvidence(
      evidence,
      "INFERENCE",
      "PHD_EDUCATION_HEAVE",
      phdEducation.heaveReasons.slice(0, 2).join("; ") || "common-sense heave",
    );
  }
  interpretationParts.push(
    `${PHD_TRADING_EDUCATION_LOADED} heave=${phdEducation.heaveTo} ${phdEducation.commonSenseSummary}`,
  );

  // ── KXBTC15M specialist — product common-sense; soft heave; floors uncut ──
  const kxbct15m = evaluateKxbct15mSpecialist({
    ticker: input.ticker ?? null,
    secsRemaining: secsRemaining,
    horizonPhase: horizon.phase,
    soleDecision: soleDecision,
    side,
    ccVel: ccVel,
    mtfBullRed: mtfBullRed,
    settleSide: settlePickForEdu,
    lagStale: lagStale,
    lagProven: lagProven,
    settlementProxyPresent: settlementProxyFromLag(lagProven, lagStale),
    pWin:
      typeof admission?.identity?.p === "number" &&
      Number.isFinite(admission.identity.p)
        ? admission.identity.p
        : null,
    askCents: askCents,
    evCents: evCents,
    openSide: exitHold && (side === "yes" || side === "no") ? side : null,
    phdEducation: phdEducation,
  });
  pushEvidence(
    evidence,
    "INFERENCE",
    KXBTC15M_SPECIALIST_LOADED,
    `heave=${kxbct15m.heaveTo} abandon=${kxbct15m.abandonLean} phase=${kxbct15m.phase} — ${kxbct15m.summary}`,
  );
  if (kxbct15m.heaveTo) {
    pushEvidence(
      evidence,
      "INFERENCE",
      "KXBTC15M_SPECIALIST_HEAVE",
      kxbct15m.heaveReasons.slice(0, 2).join("; ") || "15m specialist heave",
    );
  }
  interpretationParts.push(
    `${KXBTC15M_SPECIALIST_LOADED} heave=${kxbct15m.heaveTo} ${kxbct15m.summary}`,
  );

  // ── SelfDrive (early) — road=15m candle; brake → council preferSkip ───────
  // Speed ≠ trade frequency; destination = fee-net + survive; braking(SKIP)=success.
  // R4 — sensor truth: a fresh BRTI proxy/exchange price IS an index/proxy,
  // even when the lag meter is stale (short_series / corr_junk). Was reading
  // lag-meter staleness as "no index/proxy" → false blind-intersection brake.
  const indexOrProxyPresent =
    input.sensorBundle?.lag?.indexProxyFresh === true ||
    lagProven === true ||
    (lagProven === false && lagStale === false) ||
    lagStale === false;
  const positionHeldSd: "yes" | "no" | "flat" =
    decisionKind === "HOLD" || exitHold
      ? side === "yes"
        ? "yes"
        : side === "no"
          ? "no"
          : "flat"
      : "flat";
  const selfDriveInputBase = {
    paperMode,
    frozenCcMode: frozen,
    decisionKind,
    soleDecision,
    side,
    askCents,
    secsRemaining,
    stale,
    sizeZero,
    evCents,
    indexOrProxyPresent,
    // Fresh book for the live ticker even without an admitted side (was
    // silently false on every idle tick → PULL_OVER "missing_book").
    bookPresent: bookDepth.depthKnown || bookDepth.reason === "no_side",
    lagProven,
    lagStale,
    velocityDolPerMin: typeof vel === "number" ? vel : null,
    mtfScore: typeof mtf === "number" ? mtf : null,
    ccVelocityWouldBlock: ccVel,
    thinBook: thinBookReal as boolean | null, // real L2; unknown → thin default
    drawdownPct:
      typeof ctx?.drawdownPct === "number" ? ctx.drawdownPct : null,
    positionHeld: positionHeldSd,
    exitHold,
    ruinWouldSell: ruin?.wouldSell === true,
    pInd: null as number | null,
    pYes:
      typeof admission?.identity?.p === "number" &&
      Number.isFinite(admission.identity.p)
        ? admission.identity.p
        : null,
    band80: null as [number | null, number | null] | null,
    settlePick: settleSideScore?.pick ?? null,
    settleInputsPresent: settleSideScore?.factors.inputsPresent === true,
    ovPreferSkip: uncertaintyPack.optionValueSkip.preferSkip,
    ovScore: uncertaintyPack.optionValueSkip.score,
    foresightNext: null as string | null,
    calibReliable: calibration.reliable,
    calibN: calibration.n,
    ece: calibration.ece,
    coversBoth: uncertaintyPack.sideConfidence.coversBoth === true,
    oracleGatesFailed: null as string[] | null,
    oracleMissingInputs: null as string[] | null,
    oracleRiskVeto: null as boolean | null,
    oracleRiskVetoReasons: null as string[] | null,
    councilCoherence: null as number | null,
    scarEchoNote: phd.causalNote ?? null,
    feeScheduleKnown: true,
    horizonPhase: horizon.phase,
  };
  // SelfDrive/Captain early — lean peeks only (brake/heave → council preferSkip).
  // Full stamps once after oracleV2 (efficient: buildsPerTick = 1 each).
  const selfDrivePeek = peekSelfDriveBrake(selfDriveInputBase);
  const captainPeek = peekCaptainHeave({
    decisionKind,
    soleDecision,
    side,
    paperMode,
    frozenCcMode: frozen,
    evCents,
    askCents,
    selfDrive: {
      planAction: selfDrivePeek.planAction,
      safety: {
        brake: selfDrivePeek.brake,
        brakeReasons: selfDrivePeek.reasons,
      },
      brakeReasons: selfDrivePeek.reasons,
      perception: { weather: selfDrivePeek.weather },
      prediction: { ovPreferSkip: selfDrivePeek.ovPreferSkip },
    },
    oracleV2: null,
    phd: {
      optionValueSkip: uncertaintyPack.optionValueSkip,
      uncertainty: uncertaintyPack.sideConfidence,
      calibration,
      education: {
        heaveTo: phdEducation.heaveTo || kxbct15m.heaveTo,
        heaveReasons: [
          ...phdEducation.heaveReasons,
          ...kxbct15m.heaveReasons.map((r) => `kxbct15m: ${r}`),
        ].slice(0, 8),
        abandonLean: phdEducation.abandonLean || kxbct15m.abandonLean,
      },
    },
    kxbct15m: {
      heaveTo: kxbct15m.heaveTo,
      heaveReasons: kxbct15m.heaveReasons,
      abandonLean: kxbct15m.abandonLean,
    },
    exitHold,
    ruinWouldSell: ruin?.wouldSell === true,
    settleLean: settleSideScore?.pick ?? null,
  });

  const council = buildInnerCouncil({
    soleDecision,
    side,
    decisionKind,
    ccVel,
    mtfBullRed,
    regimeBlock: shadow?.regimeWouldBlock === true,
    reflexHard: reflex.hard === true,
    ruinWouldSell: ruin?.wouldSell === true,
    exitHold,
    evCents,
    horizon,
    settleSide: settleSideScore,
    phdSkipLean,
    phdPreferSkip: uncertaintyPack.optionValueSkip.preferSkip,
    phdEbSkipDelta: phdEbDelta,
    selfDrivePreferSkip: selfDrivePeek.brake,
    captainPreferSkip: captainPeek.heaveTo,
  });
  const attention = buildAttentionMap({
    freshness,
    ccVel,
    vel: typeof vel === "number" ? vel : null,
    mtf: typeof mtf === "number" ? mtf : null,
    askCents,
    thesisStatus: exit?.thesisStatus ?? null,
    regimeBlock: shadow?.regimeWouldBlock === true,
    ruinWouldSell: ruin?.wouldSell === true,
    soleDecision,
    horizon,
    evCents,
  });
  const curiosity = buildCuriosityGaps({
    lagProven,
    thesisStatus: exit?.thesisStatus ?? null,
    ccVel,
    soleDecision,
    depthKnown: bookDepth.depthKnown,
    secsRemaining,
    episodesEmpty: episodes.length === 0,
  });
  const counterfactual = buildCounterfactualOnVeto({
    soleDecision,
    side,
    recommendation,
    ccVel,
    mtfBullRed,
    decisionKind,
  });
  const critique = buildSelfCritique({
    decisionKind,
    council,
    curiosity,
    ccVel,
    horizon,
    reflexHard: reflex.hard === true,
  });
  const foresight = buildForesight({
    decisionKind,
    side,
    ccVel,
    soleDecision,
    horizon,
    reflexHard: reflex.hard === true,
  });
  const rhythm = buildRhythm({
    nowMs,
    lastTickMs: input.lastTickMs,
    reflex,
    tactical,
    strategic,
    council,
    decisionKind,
  });
  const goldenEggThought = buildGoldenEggThought({
    decisionKind,
    recommendation,
    soleDecision,
    soleCode,
    side,
    conflicts,
    evidence,
    mind,
    council,
    curiosity,
    counterfactual,
    horizon,
    critique,
    ccVel,
    mtfBullRed,
    reflexHard: reflex.hard === true,
    episodesEmpty: episodes.length === 0,
  });
  const thought = buildThought({
    decisionKind,
    council,
    curiosity,
    horizon,
    counterfactual,
    goldenBottomLine: goldenEggThought.bottomLine,
  });
  const story = buildStory({
    soleDecision,
    soleCode,
    recommendation,
    decisionKind,
    conflicts,
    mind,
    memoryNote,
    feeNetHint,
    bottomLine: goldenEggThought.bottomLine,
  });

  if (input.skipConvictionRecord !== true) {
    recordConvictionTick({
      ts: nowMs,
      decisionKind,
      confidenceBand,
      topConflict: conflicts[0]?.code ?? null,
    });
  }
  const convictionTrail = [...getConvictionTrail()];

  const oracleV2 = buildOracleV2Block({
    decisionKind,
    council,
    phd,
    settleSideScore,
    pWin:
      typeof admission?.identity?.p === "number" && Number.isFinite(admission.identity.p)
        ? admission.identity.p
        : null,
    // L3: winRateAtPrice is independent of mid for this desk (not binary P(YES));
    // mid inferred from ask for shrink-after. pInd left null → derived from pWin.
    pInd: null,
    p0: 0.5,
    // YES mid: askCents is the ask of the side taken (D1 — NO side → 1 − ask).
    midYes: typeof askCents === "number" ? (side === "no" ? (100 - askCents) / 100 : askCents / 100) : null,
    evCents,
    side,
    soleDecision,
    paperMode,
    stale,
    sizeZero,
    askCents,
    secsRemaining,
    confidenceBand,
    curiosityCodes: curiosity.map((c) => c.code),
    thinBook: thinBookReal, // real L2 depth; unknown/stale → thin default (raises min_edge)
    narrative: false,
    clusterId: "KXBTC15M",
  });
  interpretationParts.push(
    `${ORACLE_V2_DOCTRINE_LOADED} action=${oracleV2.action} seats=${oracleV2.seats.map((s) => s.id).join("/")} failed=[${oracleV2.gates_failed.join(",") || "none"}]`,
  );

  // ── SelfDrive (final) — enrich with oracleV2 RISK/gates + foresight ───────
  const selfDrive = buildSelfDriveStack({
    ...selfDriveInputBase,
    pInd: oracleV2.p_ind,
    pYes: oracleV2.p_yes,
    band80: oracleV2.band80,
    foresightNext: foresight?.nextLikely ?? null,
    oracleGatesFailed: oracleV2.gates_failed,
    oracleMissingInputs: oracleV2.missing_inputs,
    oracleRiskVeto: oracleV2.risk_veto,
    oracleRiskVetoReasons: oracleV2.risk_veto_reasons,
    councilCoherence:
      typeof rhythm?.coherenceScore === "number" ? rhythm.coherenceScore : null,
    thinBook: thinBookReal,
  });
  pushEvidence(
    evidence,
    "INFERENCE",
    SELFDRIVE_LOADED,
    `plan=${selfDrive.planAction} brake=${selfDrive.safety.brake} reasons=${selfDrive.brakeReasons.slice(0, 2).join("|") || "none"}`,
  );
  interpretationParts.push(
    `${SELFDRIVE_LOADED} plan=${selfDrive.planAction} brake=${selfDrive.safety.brake}`,
  );

  // ── Captain Bridge (final) — unify SelfDrive + oracleV2 + PhD ─────────────
  const captain = buildCaptainBridge({
    decisionKind,
    soleDecision,
    side,
    paperMode,
    frozenCcMode: frozen,
    evCents,
    askCents,
    selfDrive,
    oracleV2,
    phd: {
      optionValueSkip: uncertaintyPack.optionValueSkip,
      uncertainty: uncertaintyPack.sideConfidence,
      calibration,
      education: {
        heaveTo: phdEducation.heaveTo || kxbct15m.heaveTo,
        heaveReasons: [
          ...phdEducation.heaveReasons,
          ...kxbct15m.heaveReasons.map((r) => `kxbct15m: ${r}`),
        ].slice(0, 8),
        abandonLean: phdEducation.abandonLean || kxbct15m.abandonLean,
      },
    },
    kxbct15m: {
      heaveTo: kxbct15m.heaveTo,
      heaveReasons: kxbct15m.heaveReasons,
      abandonLean: kxbct15m.abandonLean,
    },
    exitHold,
    ruinWouldSell: ruin?.wouldSell === true,
    settleLean: settleSideScore?.pick ?? null,
    pInd: oracleV2.p_ind,
    pYes: oracleV2.p_yes,
    band80: oracleV2.band80,
  });
  pushEvidence(
    evidence,
    "INFERENCE",
    CAPTAIN_BRIDGE_LOADED,
    `voyage=${captain.voyageOrder} heave=${captain.heaveTo} feeNetVsSkip=${captain.feeNetVsSkip}`,
  );
  if (captain.heaveTo) {
    pushEvidence(
      evidence,
      "INFERENCE",
      "CAPTAIN_HEAVE_TO",
      `preferSkip lean — ${captain.heaveReasons.slice(0, 2).join("; ") || "fog"}`,
    );
  }
  interpretationParts.push(
    `${CAPTAIN_BRIDGE_LOADED} voyage=${captain.voyageOrder} heave=${captain.heaveTo}`,
  );
  // Append captain bottom line into goldenEggThought evidence (schema intact)
  const captainBottom = captain.thoughtTrace[0] ?? `BOTTOM LINE: ${captain.voyageOrder}`;
  goldenEggThought.evidence.push({
    label: "INFERENCE",
    code: CAPTAIN_BRIDGE_LOADED,
    detail: captainBottom.slice(0, 200),
  });

  // ── Mind heartbeat — cortex vitals (organism 9-system body pulse is separate)
  const mindLayers = mind?.layers ?? [];
  const heartbeat = buildMindHeartbeat({
    nowMs,
    pulseMs: rhythm?.pulseMs ?? null,
    tickAgeMs: 0,
    layers: {
      reflex: mindLayers.find((l) => l.id === "reflex") ?? null,
      tactical: mindLayers.find((l) => l.id === "tactical") ?? null,
      strategic: mindLayers.find((l) => l.id === "strategic") ?? null,
      phd,
      council,
      oracleV2,
      selfDrive,
      captain,
      goldenEgg: goldenEggThought,
    },
  });
  pushEvidence(
    evidence,
    "INFERENCE",
    MIND_HEARTBEAT_LOADED,
    heartbeat.summary,
  );
  interpretationParts.push(heartbeat.summary);


  return {
    kind: "brainCenter",
    cortex: GOLDEN_EGG_CORTEX,
    mindName: ORACLE_MIND,
    interpretation: interpretationParts.join(" "),
    conflicts,
    recommendation,
    confidenceBand,
    evidence: goldenEggThought.evidence,
    soleAuthorityRespected: true,
    observeOnly: true,
    feeNetNote:
      "Evaluate every TAKE as fee-net vs skip (skip≈0). Shadow conflicts inform promote scoreboard; n≥40 + clear fee-net lift required before hard gate. Floors: EV3/Kelly0.60/9%/ask20–55/reserve15%.",
    asOf: new Date(nowMs).toISOString(),
    advisoryNote: frozen ? BRAIN_FROZEN_ORGANS_ADVISORY : "OBSERVE_ONLY",
    mind,
    story,
    decisionKind,
    memoryNote,
    journalTail,
    council,
    attention,
    curiosity,
    counterfactual,
    convictionTrail,
    thought,
    horizon,
    critique,
    foresight,
    rhythm,
    goldenEggThought,
    thinksLike: "goldenEgg-oracle-copy",
    settleSideScore,
    phd,
    phdEducation,
    kxbct15m,
    oracleV2,
    selfDrive,
    captain,
    heartbeat,
    bookDepth,
  };
}

/** Alias — GoldenEgg tailored name. */
export const interpretGoldenEggCortex = interpretBrainCenter;

/** Cheap scoreboard hook: count CC_VEL_AGAINST_SOLE_TAKE conflicts (observe). */
export function countCcVelAgainstSoleTake(
  reports: readonly BrainCenterReport[],
): number {
  let n = 0;
  for (const r of reports) {
    if (r.conflicts.some((c) => c.code === "CC_VEL_AGAINST_SOLE_TAKE")) n += 1;
  }
  return n;
}

/**
 * Authority action from layered mind. No LLM.
 * Veto = mind rejecting a TAKE (reflex hard, tactical NO, or SKIP/SIT with hard conflicts).
 * Sole-echo SKIP (six-gate SKIP, empty conflicts) is NOT a veto — placeOrder only
 * runs on TAKE, and getStatus may leave a stale SKIP report that must not
 * BRAIN_CENTER_VETO a live sole TAKE.
 * Soft CC_VEL_AGAINST_SOLE_TAKE alone stays soft until n>=40 (not a hard veto).
 * HOLD / EXIT do not block new entries (PATH_RIDE owns open-book exits).
 */
export function decideBrainCenterAction(input: {
  brainCenterAuthority: boolean;
  report: BrainCenterReport | null | undefined;
}): {
  action: "ALLOW" | "VETO" | "PASS";
  reason: string;
  winner?: MindLayerId;
} {
  if (input.brainCenterAuthority !== true) {
    return { action: "PASS", reason: "brainCenterAuthority off — mind advisory only" };
  }
  const report = input.report;
  if (!report) {
    return { action: "ALLOW", reason: "no brain report yet" };
  }
  const reflex = report.mind?.layers?.find((l) => l.id === "reflex");
  if (reflex?.hard === true) {
    return {
      action: "VETO",
      reason: `reflex hard-block: ${reflex.why}`,
      winner: "reflex",
    };
  }
  const tactical = report.mind?.layers?.find((l) => l.id === "tactical");
  const conflicts = report.conflicts ?? [];
  /** Soft CC_VEL alone stays soft until n>=40 — not a hard TAKE veto by itself. */
  const SOFT_CC_VEL = new Set(["CC_VEL_AGAINST_SOLE_TAKE"]);
  const hardConflicts = conflicts.filter((c) => !SOFT_CC_VEL.has(c.code));
  const softCcVelOnly =
    conflicts.length > 0 && hardConflicts.length === 0;
  /** True take-veto signal — not sole-echo SKIP, not soft-CC_VEL-only. */
  const takeVetoSignal =
    hardConflicts.length > 0
    || (tactical != null && tactical.verdict === "NO" && !softCcVelOnly);
  if (
    tactical &&
    (tactical.verdict === "NO" || tactical.verdict === "SKIP") &&
    report.recommendation !== "HOLD" &&
    report.recommendation !== "EXIT_SHADOW" &&
    (report.recommendation === "SKIP" || report.recommendation === "SIT")
  ) {
    if (takeVetoSignal) {
      return {
        action: "VETO",
        reason: `tactical ${tactical.verdict}: ${tactical.why}`,
        winner: "tactical",
      };
    }
    // Sole-echo SKIP (e.g. "six-gate SKIP") — nothing to veto on a TAKE attempt.
    return {
      action: "ALLOW",
      reason: `sole-echo ${report.recommendation} (no take-veto signal) — not BRAIN_CENTER_VETO`,
      winner: "tactical",
    };
  }
  if (report.recommendation === "SKIP" || report.recommendation === "SIT") {
    if (!takeVetoSignal) {
      return {
        action: "ALLOW",
        reason: `sole-echo ${report.recommendation} without conflicts — not a TAKE veto`,
        winner: report.mind?.winner,
      };
    }
    const codes = conflicts.map((c) => c.code).join(",") || "none";
    return {
      action: "VETO",
      reason: `brainCenterAuthority veto recommendation=${report.recommendation} conflicts=[${codes}]`,
      winner: report.mind?.winner,
    };
  }
  return {
    action: "ALLOW",
    reason: `mind allows ${report.decisionKind}`,
    winner: report.mind?.winner,
  };
}

/** Optional extras folded into desk pulse (learning / self-heal / scar echoes). */
export type BrainMindPulseExtras = {
  learning?: LearningSnapshot | null;
  selfHeal?: {
    findings: unknown[];
    goldenEgg: unknown;
    lastSelfHeal: unknown;
    asOfMs: number;
  } | null;
  echoes?: Array<{
    n: number;
    meanFeeNetVsSkip: number;
    wr: number;
    salience: number;
    advice: string;
    matchKey: string;
    conflictCodes: string[];
  }> | null;
};

/** Desk pulse slice — layers + story + memory + special mind fields + learning. */
export function brainMindPulse(
  report: BrainCenterReport | null | undefined,
  extras?: BrainMindPulseExtras | null,
): {
  mindName: typeof ORACLE_MIND;
  layers: MindLayer[];
  winner: MindLayerId | null;
  winnerWhy: string | null;
  story: string | null;
  memoryNote: string | null;
  decisionKind: BrainDecisionKind | null;
  journalTail: BrainEpisode[];
  recommendation: BrainCenterRecommendation | null;
  council: CouncilReport | null;
  attention: AttentionSignal[];
  curiosity: CuriosityGap[];
  counterfactual: CounterfactualVeto | null;
  convictionTrail: ConvictionTick[];
  thought: string | null;
  horizon: HorizonPosture | null;
  critique: SelfCritique | null;
  foresight: ForesightHint | null;
  rhythm: RhythmPulse | null;
  goldenEggThought: GoldenEggThought | null;
  thinksLike: "goldenEgg-oracle-copy";
  settleSideScore: SettleSideScoreResult | null;
  phd: PhdThought | null;
  phdEducation: PhdEducationResult | null;
  kxbct15m: Kxbct15mSpecialistResult | null;
  oracleV2: OracleV2Block | null;
  selfDrive: SelfDriveStack | null;
  captain: CaptainBridge | null;
  heartbeat: MindHeartbeat | null;
  learning: LearningSnapshot | null;
  selfHeal: BrainMindPulseExtras["selfHeal"];
  echoes: BrainMindPulseExtras["echoes"];
} {
  const learning = extras?.learning ?? null;
  const selfHeal = extras?.selfHeal ?? null;
  const echoes = extras?.echoes ?? null;
  if (!report) {
    return {
      mindName: ORACLE_MIND,
      layers: [],
      winner: null,
      winnerWhy: null,
      story: null,
      memoryNote: null,
      decisionKind: null,
      journalTail: [],
      recommendation: null,
      council: null,
      attention: [],
      curiosity: [],
      counterfactual: null,
      convictionTrail: [],
      thought: null,
      horizon: null,
      critique: null,
      foresight: null,
      rhythm: null,
      goldenEggThought: null,
      thinksLike: "goldenEgg-oracle-copy",
      settleSideScore: null,
      phd: null,
      phdEducation: null,
      kxbct15m: null,
      oracleV2: null,
      selfDrive: null,
      captain: null,
      heartbeat: null,
      learning,
      selfHeal,
      echoes,
    };
  }
  return {
    mindName: ORACLE_MIND,
    layers: report.mind?.layers ?? [],
    winner: report.mind?.winner ?? null,
    winnerWhy: report.mind?.winnerWhy ?? null,
    story: report.story ?? null,
    memoryNote: report.memoryNote ?? null,
    decisionKind: report.decisionKind ?? null,
    journalTail: report.journalTail ?? [],
    recommendation: report.recommendation,
    council: report.council ?? null,
    attention: report.attention ?? [],
    curiosity: report.curiosity ?? [],
    counterfactual: report.counterfactual ?? null,
    convictionTrail: report.convictionTrail ?? [],
    thought: report.thought ?? null,
    horizon: report.horizon ?? null,
    critique: report.critique ?? null,
    foresight: report.foresight ?? null,
    rhythm: report.rhythm ?? null,
    goldenEggThought: report.goldenEggThought ?? null,
    thinksLike: "goldenEgg-oracle-copy",
    settleSideScore: report.settleSideScore ?? null,
    phd: report.phd ?? null,
    phdEducation: report.phdEducation ?? null,
    kxbct15m: report.kxbct15m ?? null,
    oracleV2: report.oracleV2 ?? null,
    selfDrive: report.selfDrive ?? null,
    captain: report.captain ?? null,
    heartbeat: report.heartbeat ?? null,
    learning,
    selfHeal,
    echoes,
  };
}

export type BrainMindPulse = ReturnType<typeof brainMindPulse>;
