/**
 * confluence-cascade.ts
 *
 * Extracted CONFLUENCE_CASCADE evaluate. strategy-library.ts is a caller.
 * Proven confluence is IN AN ACTUAL TREND — not a still-mid coinflip.
 *
 * LOCKS (do not loosen, do not rewrite other gates):
 *   - time window 3–15m (fill-power: gold 14–15m must not hard-null evaluate;
 *     strategy-library maxTimeMins must match — evaluateAllStrategies filters
 *     metadata before this evaluate runs)
 *   - factor alignment (≥3 same-sign, mixed-signal refuse; cheap yes-or-no
 *     ask ≤55 money-path: ≥2 — quiet tape zVel_opposeBar rarely counts v1)
 *   - strong-stall refuse
 *   - zVel/opposeBar v1 factor (fallback 40 $/min)
 *   - p = confluenceWinRate (live-calibrated cheap-to-mid curve). Never the
 *     0.75 Bayesian prior. expectedWinRate 0.75 stays metadata only.
 *     FAIL_CLOSED_WITHOUT_WINRATE_CURVE still fail-closes if the curve is
 *     removed. confidence is evidence-strength.
 *
 * P&L gate (fail-closed, not an EV cut):
 *   SKIP still-mid 48–52¢ tickets when regime is unclear (missing counts as
 *   unclear) OR ticketVelocity is passed and still. Today's 6 paper scratches
 *   were still ~49¢ confluence in unclear. strong_uptrend / strong_downtrend
 *   may still fire at 49¢. Do not skip cheap 7–22 (that is CHEAP_SIDE).
 *   Do not skip basis-lag ≤55 with streak (that lives in basis-lag-edge.ts).
 *
 * Does not bypass computeTradeEV / PATH_GATE / Kelly / 9%. Does not
 * ENABLE_STRATEGY. Does not CHANGE_EV_FLOOR. Does not flip paperMode.
 */

import { opposeBar, logFamilyGate } from "./family-policy.js";
import { isStrikePinNoEnter } from "./path-ride.js";
import { isMtfAlignedCheapTake } from "./settlement-side.js";
import type { StrategyObservation, StrategyResult, TradeSignal } from "./strategy-library.js";

export const CONFLUENCE_MIN_TIME_MINS = 3;
export const CONFLUENCE_MAX_TIME_MINS = 15;
export const CONFLUENCE_STRATEGY_ID = "CONFLUENCE_CASCADE" as const;
export const CONFLUENCE_STRATEGY_NAME = "Confluence Cascade";

/** Cheap 2-factor path only. 3+ factors fire immediately. Does not raise EV floor. */
export const CHEAP_TWO_FACTOR_CONFIRM_TICKS = 3;

type TwoFactorConfirm = { ticker: string; signal: TradeSignal; ticks: number };
let cheapTwoConfirm: TwoFactorConfirm | null = null;

export function resetConfluenceTwoFactorConfirm(): void {
  cheapTwoConfirm = null;
}

function confirmCheapTwoFactor(ticker: string | undefined, signal: TradeSignal, aligned: number, minFactors: number): boolean {
  if (minFactors >= 3 || aligned >= 3) {
    cheapTwoConfirm = null;
    return true;
  }
  const t = ticker ?? "";
  if (cheapTwoConfirm && cheapTwoConfirm.ticker === t && cheapTwoConfirm.signal === signal) {
    cheapTwoConfirm.ticks += 1;
  } else {
    cheapTwoConfirm = { ticker: t, signal, ticks: 1 };
  }
  return cheapTwoConfirm.ticks >= CHEAP_TWO_FACTOR_CONFIRM_TICKS;
}

/**
 * Kelly/EV p for CONFLUENCE_CASCADE. Live BOT-only census n=50, 27W, 54% WR,
 * avg 49.7¢, 76% ≤55, 0% ≥70. Not the 0.75 prior. Not confidence (0.66–0.88).
 * Not paper 1W/9L (n=10, skip-starved, TB dumps — do not pretend 9/10).
 * Displayed + PATH p = this curve. Never a blanket 0.60 when census is 0.54.
 * Cheap 36¢ uses census (EV still >> 3¢). Richer asks taper down so EV 3¢
 * honestly skips them. Do not cut EV_FLOOR.
 */
export const CONFLUENCE_CENSUS_WR = 0.54;

export function confluenceWinRate(entryPriceCents: number, minutesLeft: number): number {
  let wr: number;
  if (entryPriceCents <= 40) {
    wr = CONFLUENCE_CENSUS_WR; // 36¢ cheap cell — honest 54%, EV >> 3¢
  } else if (entryPriceCents <= 50) {
    // 40→50: 0.54 → 0.59. 0.59 is the min that still clears EV 3¢ after
    // fee+1¢ sweep at 50. Never a blanket 0.60 vs 54% census.
    const t = (entryPriceCents - 40) / 10;
    wr = CONFLUENCE_CENSUS_WR + t * 0.05;
  } else if (entryPriceCents <= 55) {
    const t = (entryPriceCents - 50) / 5;
    wr = 0.59 - t * 0.08; // 0.59 → 0.51
  } else {
    const t = Math.min(1, (entryPriceCents - 55) / 15);
    wr = 0.51 - t * 0.05; // 0.51 → 0.46
  }
  if (minutesLeft >= 9) wr -= 0.02;
  else if (minutesLeft <= 4) wr -= 0.01;
  return Math.max(0.46, Math.min(0.59, wr));
}

/** Still-mid band. Inclusive. Today's scratches were ~49¢. */
export const CONFLUENCE_STILL_MID_MIN_CENTS = 48;
export const CONFLUENCE_STILL_MID_MAX_CENTS = 52;

/**
 * Exact skip reason string. evaluate() returns null (same as other gates);
 * callers/tests match this token.
 */
export const CONFLUENCE_STILL_MID_UNCLEAR_SKIP = "confluence_still_mid_unclear";

/** Proven confluence regimes — still-mid 48–52¢ may still fire. */
export const CONFLUENCE_TREND_REGIMES = ["strong_uptrend", "strong_downtrend"] as const;
export type ConfluenceTrendRegime = (typeof CONFLUENCE_TREND_REGIMES)[number];

/** Matches intra-scalp TICKET_VEL_MIN_MOVE_CENTS without importing the replay. */
const TICKET_STILL_MOVE_CENTS = 2;

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

export function isConfluenceTrendRegime(regime?: string | null): regime is ConfluenceTrendRegime {
  return regime === "strong_uptrend" || regime === "strong_downtrend";
}

export function isConfluenceStillMidAsk(ask: number): boolean {
  return ask >= CONFLUENCE_STILL_MID_MIN_CENTS && ask <= CONFLUENCE_STILL_MID_MAX_CENTS;
}

/**
 * Fail-closed still detector. Missing ticketVelocity → still.
 * `still: false` is moving. Finite |dMid| below 2¢ is still.
 */
export function isConfluenceTicketStill(obs: StrategyObservation): boolean {
  const tv = obs.ticketVelocity;
  if (tv == null) return true;
  if (tv.still === false) return false;
  if (tv.still === true) return true;
  if (typeof tv.dMidCents === "number" && Number.isFinite(tv.dMidCents)) {
    return Math.abs(tv.dMidCents) < TICKET_STILL_MOVE_CENTS;
  }
  return true;
}

/**
 * P&L gate. Null = do not skip. String = skip reason.
 * Trend (strong_up / strong_down) is never skipped on this gate.
 * Unclear (or missing regime) still-mid is skip.
 * ticketVelocity still, if passed, also skips still-mid outside a trend.
 */
export function confluenceStillMidUnclearReason(
  obs: StrategyObservation,
  sideAsk: number | undefined,
): string | null {
  if (typeof sideAsk !== "number" || !Number.isFinite(sideAsk)) return null;
  if (!isConfluenceStillMidAsk(sideAsk)) return null;
  if (isConfluenceTrendRegime(obs.regime)) return null;

  const regime = obs.regime ?? "unclear";
  const unclear = regime === "unclear";
  const ticketVelPassed = obs.ticketVelocity != null;
  const stillIfPassed = ticketVelPassed && isConfluenceTicketStill(obs);

  // Fail-closed: missing regime is unclear. Missing ticketVelocity on
  // unclear still-mid is still (today's 6 scratches had no ticketVelocity).
  if (unclear || stillIfPassed) {
    return CONFLUENCE_STILL_MID_UNCLEAR_SKIP;
  }
  return null;
}

/**
 * CC factor bias for LAG side-agreement. Null if mixed/empty.
 * Does not apply still-mid / time-window / evaluate skip.
 */
export function confluenceFactorBias(obs: StrategyObservation): "YES" | "NO" | null {
  const { bullish, bearish } = confluenceFactorCounts(obs);
  if (bullish === 0 && bearish === 0) return null;
  if (bullish === bearish) return null;
  return bullish > bearish ? "YES" : "NO";
}

function confluenceFactorCounts(obs: StrategyObservation): { factors: number[]; bullish: number; bearish: number } {
  const v1   = obs.velocityDolPerMin;
  const v3   = obs.threeMinVelocity;
  const dist = obs.fairDistFromFloorPct ?? obs.distFromFloorPct;
  const mass = obs.massAboveFloor;
  const factors: number[] = [];
  // P3 FAMILY POLICY (confluence): zVel_opposeBar_factor is LOG-ONLY for CC
  // money-maker (GG pnl-lift-sep5). Quiet-tape opposeBar FAIL must not starve
  // aligned CC of a factor — factor contribution keeps legacy |v1|>40.
  // Leftovers / observability still log the tape-scaled opposeBar pass/fail.
  // v3's fixed >30 check is left as-is (secondary confirmation leg).
  const legacyVelBar = 40;
  const confluenceVelBar = (obs.velScale !== undefined && !obs.marketStale) ? opposeBar(obs.velScale) : legacyVelBar;
  const v1FactorPass = Math.abs(v1) > legacyVelBar; // carve: do not starve CC
  const policyPass = Math.abs(v1) > confluenceVelBar;
  if (obs.velScale !== undefined && !obs.marketStale) {
    logFamilyGate({
      strategyId: CONFLUENCE_STRATEGY_ID, family: "confluence", gate: "zVel_opposeBar_factor",
      rawValue: v1, policyThreshold: confluenceVelBar,
      velScale: obs.velScale, zVel: obs.zVel ?? 0, rangeScale: obs.rangeScale ?? 0,
      pass: policyPass, // log-only vs policy bar; factor uses legacyVelBar
    });
  }
  if (v1FactorPass) factors.push(Math.sign(v1));
  if (Math.abs(v3) > 30) factors.push(Math.sign(v3));
  if (Math.abs(dist) > 0.08) factors.push(dist > 0 ? 1 : -1);
  if (Math.abs(mass - 50) > 15) factors.push(mass > 50 ? 1 : -1);
  if (obs.recentUpPct !== undefined) {
    if (obs.recentUpPct > 0.57)      factors.push(1);
    else if (obs.recentUpPct < 0.43) factors.push(-1);
  }
  if (obs.channelInfo && obs.channelInfo.confidence > 0.3) {
    if (obs.channelInfo.nearLower) factors.push(1);
    if (obs.channelInfo.nearUpper) factors.push(-1);
  }
  // Compute preliminary direction from factors so far, then use it to
  // interpret psychological level data (which is directional).
  const preBull = factors.filter(f => f > 0).length;
  const preBear = factors.filter(f => f < 0).length;
  const isLong  = preBull >= preBear;

  // Psychological level factors:
  // • Floor strike at a psych level → price magnet → aligned with position
  // • Support below us (isAbove=true, isLong) → bullish confirmation
  // • Resistance above us (!isAbove, isLong) → bearish headwind → penalise
  if (obs.psychLevel) {
    const pl = obs.psychLevel;
    if (pl.floorNearPsych) {
      factors.push(isLong ? 1 : -1); // contract target is a natural stopping point
    }
    if (pl.isNear && !pl.atLevel) {
      if ( pl.isAbove  &&  isLong) factors.push(1);   // support below → bullish
      if (!pl.isAbove  && !isLong) factors.push(-1);  // resistance above → bearish
      if (!pl.isAbove  &&  isLong) factors.push(-1);  // resistance above → headwind for longs
      if ( pl.isAbove  && !isLong) factors.push(1);   // support below → headwind for shorts
    }
  }
  const bullish = factors.filter(f => f > 0).length;
  const bearish = factors.filter(f => f < 0).length;
  return { factors, bullish, bearish };
}

export function evaluateConfluenceCascade(obs: StrategyObservation): StrategyResult | null {
  const minLeft = obs.secsRemaining / 60;
  if (minLeft < CONFLUENCE_MIN_TIME_MINS || minLeft > CONFLUENCE_MAX_TIME_MINS) return null;
  if (isStrikePinNoEnter({ ohlc1m: obs.ohlc1m, ohlc5m: obs.ohlc5m, floor: obs.floorStrike })) return null;

  // Stall: conf penalty lives in trading-bot (-8stall). Hard null here starved
  // CC takes while book was valid — demoted 2026-09-06 (fills).
  // if (obs.isStalling && obs.stallStrength === "strong") return null;


  const { factors, bullish, bearish } = confluenceFactorCounts(obs);

  // Money-path: CHOSEN side ask ≤55 needs 2 aligned factors. Do not let
  // the other leg being cheap unlock a rich/tie YES. Rich book still 3.
  // still-mid/unclear skip stays in confluenceStillMidUnclearReason — not EV.
  const yesAsk = obs.yesAsk;
  const noAsk = obs.noAsk;
  if (bullish === bearish) return null; // mixed / tie — do not default YES
  let finalLong = bullish > bearish;
  // Construct aligned cheap (lock must not only delete opposed YES).
  // MTF short + NO in [28,55] → TAKE NO. Not in band → skip (KEEP MTF_FILTER
  // on opposed cheap YES). p = confluenceWinRate on the constructed side. EV 3c later.
  const alignedTake = isMtfAlignedCheapTake({
    mtfScore: obs.mtfScore,
    yesAsk,
    noAsk,
    minAskCents: 28,
    spot: obs.currentPrice,
    floorStrike: obs.floorStrike,
  });
  if (obs.mtfScore != null && Number.isFinite(obs.mtfScore) && obs.mtfScore !== 0) {
    // Emit aligned side only. 37¢ YES / 8¢ NO = no aligned cheap → null (KEEP skip).
    if (!alignedTake) return null;
    finalLong = alignedTake.side === "yes";
  } else if (alignedTake && ((alignedTake.side === "yes") !== finalLong)) {
    finalLong = alignedTake.side === "yes";
  }
  const sideAskChosen = finalLong ? yesAsk : noAsk;
  const cheapChosen =
    typeof sideAskChosen === "number" && Number.isFinite(sideAskChosen) && sideAskChosen <= 55;
  const minFactors = cheapChosen ? 2 : 3;
  if (factors.length < minFactors) return null;
  if (bullish < minFactors && bearish < minFactors) return null; // mixed signals

  // Final direction from full factor set (includes psych level added above).
  const signal: TradeSignal = finalLong ? "YES" : "NO";
  const aligned = Math.max(bullish, bearish);
  const total   = factors.length;
  const conf = clamp(0.66 + (aligned - 3) * 0.06 + (total >= 5 ? 0.04 : 0), 0.66, 0.88);

  // Extra penalty if alternating — confluence is weakest in choppy markets
  const finalConf = obs.isAlternating ? clamp(conf - 0.05, 0.60, 0.88) : conf;

  // P&L gate: still-mid 48–52¢ in unclear (or ticketVelocity still) is skip.
  // Not an EV cut. Cheap 7–22 and basis-lag ≤55 with streak are other books.
  const sideAsk = finalLong ? obs.yesAsk : obs.noAsk;
  if (!confirmCheapTwoFactor(obs.ticker, signal, aligned, minFactors)) {
    return null;
  }

  const skipReason = confluenceStillMidUnclearReason(obs, sideAsk);
  if (skipReason) {
    console.log(
      `[confluence] ⏸️ SKIP (${skipReason}) · ` +
      `regime=${obs.regime ?? "unclear"} · ask=${sideAsk}c · ` +
      `${aligned}/${total} ${finalLong ? "bullish" : "bearish"}`,
    );
    return null;
  }

  return {
    signal, confidence: finalConf, strategyId: CONFLUENCE_STRATEGY_ID, strategyName: CONFLUENCE_STRATEGY_NAME,
    reason: `${aligned}/${total} factors aligned ${finalLong ? "bullish" : "bearish"}: vel+dist+prob${obs.recentUpPct !== undefined ? "+history" : ""}`,
    earlyExitRule: "Exit if any 2 factors flip — confluence breakdown",
  };
}
