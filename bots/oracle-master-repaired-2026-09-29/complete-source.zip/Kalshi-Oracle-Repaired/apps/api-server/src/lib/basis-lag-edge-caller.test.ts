/** Unquarantined 2026-09-18: BOT_CONFIG_PATH isolation + TDZ literal fix. */
/**
 * basis-lag-edge-caller.test.ts
 *
 * Named-module + caller extract. Does not import TradingBot, does not
 * ENABLE_STRATEGY, does not CHANGE_EV_FLOOR, does not expand SIZE_RESCUE.
 * p for winRateAtPrice is basisLagWinRate, never heuristic confidence.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  evaluateBasisLagEdge,
  basisLagWinRate,
  BASIS_LAG_MIN_TIME_MINS,
  BASIS_LAG_MAX_TIME_MINS,
  BASIS_LAG_MIN_STREAK_TICKS,
  BASIS_LAG_FULLY_PRICED_ASK,
  BASIS_LAG_MIN_EDGE_PTS,
  BASIS_LAG_RICH_ASK_CENTS,
  BASIS_LAG_RICH_MIN_EDGE_PTS,
  BASIS_LAG_PREFERRED_MIN,
  BASIS_LAG_PREFERRED_MAX,
  BASIS_LAG_LARGE_EDGE_PTS,
  BASIS_LAG_STRATEGY_ID,
} from "./basis-lag-edge.js";
import { getStrategy, evaluateAllStrategies, type StrategyObservation } from "./strategy-library.js";
import { activeWinCurveModel, refitWinRate } from "./win-curve-refit.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const LIB_SRC = fs.readFileSync(path.join(DIR, "strategy-library.ts"), "utf8");
const MOD_SRC = fs.readFileSync(path.join(DIR, "basis-lag-edge.ts"), "utf8");
const BOT_SRC = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");

function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60,
    projectedSettlementPrice: 65130,
    rollingBasis: 8,
    basisShort: 8,
    basisStreakCount: 4,
    basisStreakSign: 1,
    lagStale: false,
    lagProven: true,
    lagDollars: 40,
    leaderName: "coinbase",
    leadSeconds: 8,
    leadDollars: 40,
    proofHitRate: 0.8,
    yesAsk: 30,
    yesBid: 28,
    noAsk: 68,
    noBid: 66,
    ...overrides,
  };
}

test("strategy-library is a caller of evaluateBasisLagEdge (source-text)", () => {
  assert.match(LIB_SRC, /evaluateBasisLagEdge/);
  assert.match(LIB_SRC, /BASIS_LAG_MAX_TIME_MINS/);
  assert.match(LIB_SRC, /from '\.\/basis-lag-edge\.js'/);
  assert.match(LIB_SRC, /return evaluateBasisLagEdge\(obs\)/);
  // Literals avoid ESM TDZ (basis-lag-edge → settlement-side → strategy-library).
  assert.match(LIB_SRC, /minTimeMins: 2/);
  assert.match(LIB_SRC, /maxTimeMins: 15/);
  assert.match(LIB_SRC, /MUST match BASIS_LAG_MIN_TIME_MINS=2/);
  assert.match(LIB_SRC, /MUST match BASIS_LAG_MAX_TIME_MINS=15/);
  assert.match(LIB_SRC, /winRateAtPrice: withActiveWinCurve\(basisLagWinRate\)/);
  assert.equal(/function basisLagWinRate/.test(LIB_SRC), false);
  assert.equal(/function logBasisLagEval/.test(LIB_SRC), false);
  assert.equal(/function evaluateBasisLagEdge/.test(LIB_SRC), false);
  // Gates live in the named module, not inlined in the soup.
  assert.match(MOD_SRC, /BASIS_LAG_MIN_STREAK_TICKS = 3/);
  assert.match(MOD_SRC, /BASIS_LAG_MIN_TIME_MINS = 2/);
  assert.match(MOD_SRC, /BASIS_LAG_MAX_TIME_MINS = 15/);
  assert.match(MOD_SRC, /BASIS_LAG_FULLY_PRICED_ASK = 90/);
  assert.match(MOD_SRC, /BASIS_LAG_MIN_EDGE_PTS = 8/);
  assert.match(MOD_SRC, /BASIS_LAG_RICH_MIN_EDGE_PTS = 15/);
  assert.match(MOD_SRC, /BASIS_LAG_LARGE_EDGE_PTS = 18/);
  // Named module does not size, place, or admit around PATH_GATE/Kelly.
  assert.equal(/applyHardRiskLimits|computeKellyContracts|placeOrder/.test(MOD_SRC), false);
});

test("this pass did not rewrite trading-bot.ts (source-text still the god-file caller elsewhere)", () => {
  // Extract stayed outside the god-file. BASIS_LAG evaluate is not duplicated there.
  assert.equal(/evaluateBasisLagEdge/.test(BOT_SRC), false);
  assert.equal(/function basisLagWinRate/.test(BOT_SRC), false);
});

test("named module fires YES on a persistent well-priced lag; library caller agrees", () => {
  const direct = evaluateBasisLagEdge(baseObs());
  const viaLib = getStrategy("BASIS_LAG_EDGE")!.evaluate(baseObs());
  assert.ok(direct, "named evaluate should fire");
  assert.ok(viaLib, "library caller should fire");
  assert.equal(direct!.signal, "YES");
  assert.equal(direct!.strategyId, BASIS_LAG_STRATEGY_ID);
  assert.equal(viaLib!.signal, direct!.signal);
  assert.equal(viaLib!.strategyId, direct!.strategyId);
  assert.equal(viaLib!.confidence, direct!.confidence);
});

test("p = basisLagWinRate (winRateAtPrice), not heuristic confidence", () => {
  const wr = basisLagWinRate(30, 5);
  const fired = evaluateBasisLagEdge(baseObs());
  assert.ok(fired);
  // confidence is evidence-strength (edge/streak/rolling/short), not p.
  assert.notEqual(fired!.confidence, wr);
  assert.equal(/let conf = basisLagWinRate/.test(MOD_SRC), false);
  // The metadata curve used by Kelly/EV is the active win curve
  // (refit table by default; basisLagWinRate under WIN_CURVE_MODEL=legacy-cc-v0).
  const meta = getStrategy("BASIS_LAG_EDGE")!.winRateAtPrice!(30, 5);
  assert.equal(meta, activeWinCurveModel() === "legacy-cc-v0" ? wr : refitWinRate(30, 5));
  assert.notEqual(meta, fired!.confidence);
});

test("fail-closed knobs: 1-tick streak, fully-priced 90c, hard 2-15m window", () => {
  assert.equal(BASIS_LAG_MIN_STREAK_TICKS, 3);
  assert.equal(BASIS_LAG_FULLY_PRICED_ASK, 90);
  assert.equal(BASIS_LAG_MIN_TIME_MINS, 2);
  assert.equal(BASIS_LAG_MAX_TIME_MINS, 15);
  assert.equal(BASIS_LAG_MIN_EDGE_PTS, 8);
  assert.equal(BASIS_LAG_RICH_ASK_CENTS, 80);
  assert.equal(BASIS_LAG_RICH_MIN_EDGE_PTS, 15);
  assert.equal(BASIS_LAG_PREFERRED_MIN, 3);
  assert.equal(BASIS_LAG_PREFERRED_MAX, 10);
  assert.equal(BASIS_LAG_LARGE_EDGE_PTS, 18);

  assert.equal(evaluateBasisLagEdge(baseObs({ basisStreakCount: 1 })), null);
  assert.equal(evaluateBasisLagEdge(baseObs({ yesAsk: 90, yesBid: 88 })), null);
  assert.equal(evaluateBasisLagEdge(baseObs({ secsRemaining: 60 })), null);
  // Above hard max (16m) still null. Exactly 15m / 14m gold window must FIRE
  // (fill-power widen — old 2–13 hard-null starved bar-open gold).
  assert.equal(evaluateBasisLagEdge(baseObs({ secsRemaining: 16 * 60 })), null);
  assert.ok(evaluateBasisLagEdge(baseObs({ secsRemaining: 15 * 60 })), "15m hard max inclusive — gold bar-open");
  assert.ok(evaluateBasisLagEdge(baseObs({ secsRemaining: 14 * 60 })), "14m gold window must not hard-null");

  const meta = getStrategy("BASIS_LAG_EDGE")!;
  assert.equal(meta.minTimeMins, BASIS_LAG_MIN_TIME_MINS);
  assert.equal(meta.maxTimeMins, BASIS_LAG_MAX_TIME_MINS, "library meta max must match module (stale 13 starved evaluateAll)");

  // Live path starve: evaluateAllStrategies filters metadata BEFORE evaluate.
  const gold14 = baseObs({
    secsRemaining: 14 * 60,
    projectedSettlementPrice: 65200,
    ticker: "KXBTC15M-25SEP050000-00",
    contractDurationMins: 15,
  });
  assert.ok(evaluateBasisLagEdge(gold14), "direct evaluate fires at 14m");
  const all14 = evaluateAllStrategies(gold14);
  assert.ok(
    all14.all.some((r) => r.strategyId === "BASIS_LAG_EDGE"),
    "evaluateAllStrategies must include LAG at 14m (not metadata-starve)",
  );
  const gold15 = baseObs({
    secsRemaining: 15 * 60,
    projectedSettlementPrice: 65200,
    ticker: "KXBTC15M-25SEP050000-00",
    contractDurationMins: 15,
  });
  const all15 = evaluateAllStrategies(gold15);
  assert.ok(
    all15.all.some((r) => r.strategyId === "BASIS_LAG_EDGE"),
    "evaluateAllStrategies must include LAG at 15m inclusive",
  );
});

test("winRateAtPrice is monotonically non-increasing in entry price", () => {
  const wrCheap = basisLagWinRate(25, 5);
  const wrMid = basisLagWinRate(60, 5);
  const wrRich = basisLagWinRate(85, 5);
  assert.ok(wrCheap >= wrMid && wrMid >= wrRich, `got ${wrCheap}, ${wrMid}, ${wrRich}`);
  assert.ok(wrCheap <= 0.58 && wrRich >= 0.40 && wrRich < 0.52, "tape-calibrated bounds");
});
