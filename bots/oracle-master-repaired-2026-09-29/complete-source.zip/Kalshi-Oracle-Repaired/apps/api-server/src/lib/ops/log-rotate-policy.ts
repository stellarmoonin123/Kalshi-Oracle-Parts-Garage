/**
 * log-rotate-policy — pure policy for desk log caps.
 * NEVER rotate paper ledger / frozen-cc-ledger.jsonl.
 */
export const BOUNCE_LOG_MAX_BYTES = 32 * 1024 * 1024;
export const TRACE_JSONL_MAX_BYTES = 64 * 1024 * 1024;

const PROTECTED_SUFFIXES = [
  "frozen-cc-ledger.jsonl",
  "paper-ledger.jsonl",
  "paper-blotter.jsonl",
] as const;

export function isProtectedLedgerPath(filePath: string): boolean {
  const base = filePath.replace(/\\/g, "/").split("/").pop() ?? filePath;
  return (PROTECTED_SUFFIXES as readonly string[]).some((s) => base === s || filePath.endsWith("/" + s));
}

export function shouldRotateBySize(bytes: number, maxBytes: number): boolean {
  if (!Number.isFinite(bytes) || bytes < 0) return false;
  if (!Number.isFinite(maxBytes) || maxBytes <= 0) return false;
  return bytes > maxBytes;
}

export function rotateDecision(filePath: string, bytes: number, maxBytes: number): "rotate" | "keep" | "refuse_protected" {
  if (isProtectedLedgerPath(filePath)) return "refuse_protected";
  return shouldRotateBySize(bytes, maxBytes) ? "rotate" : "keep";
}
