/**
 * 15m-product.ts
 *
 * Fail-closed product identity for the KXBTC15M desk.
 * Hourly (KXBTCD / KXBTCH) and perp (KXBTCPERP) tickers must never enter
 * the 15m evaluate path, even when contractDurationMins is missing or
 * hardcoded to 15. Hourly/perp evaluate cannot fire while flags are off.
 *
 * Does NOT: place orders, cut EV/Kelly/9%/15% reserve, flip paperMode false,
 * arm autoMode, enable hourly/perps/SEV1/OTM, or CHANGE_EV_FLOOR.
 * Operator lock: paperMode true, autoMode false on disk. CODE DEFAULTS stay doctrine.
 */

export type ProductDuration = "15M" | "1H" | "PERP";

/**
 * Map a Kalshi ticker (or a ticker-shaped string) to the coarse duration.
 * Unknown / empty → null (caller fail-closes on the 15m desk).
 */
export function seriesDurationFromTicker(
  ticker: string | null | undefined,
): ProductDuration | null {
  if (typeof ticker !== "string" || ticker.length === 0) return null;
  const u = ticker.trim().toUpperCase();
  if (u.length === 0) return null;
  // Perp first: KXBTCPERP contains neither KXBTC15M nor KXBTCD.
  if (u.includes("PERP") || u.includes("KXBTCPERP")) return "PERP";
  // Hourly threshold series. "KXBTCD" is NOT a substring of "KXBTC15M".
  if (u.includes("KXBTCD") || u.includes("KXBTCH")) return "1H";
  if (u.includes("KXBTC15M")) return "15M";
  return null;
}

/** True only for the 15-minute BTC binary series this desk trades. */
export function isKxbct15mTicker(ticker: string | null | undefined): boolean {
  return seriesDurationFromTicker(ticker) === "15M";
}

/** Alias kept for skip-settlement-resolver / existing tests. */
export const isKXBTC15M = isKxbct15mTicker;

/**
 * Coarse product from a minutes/label field. Does not import strategy-library
 * (cycle). PERP/1H labels never fall through to 15M.
 */
export function productDurationFromMinsLabel(
  raw: number | string | null | undefined,
): ProductDuration | null {
  if (raw == null || raw === "") return null;
  if (typeof raw === "number") {
    if (!Number.isFinite(raw)) return null;
    if (raw === 0) return "PERP";
    if (raw >= 45) return "1H";
    if (raw > 0) return "15M";
    return "PERP";
  }
  const u = String(raw).trim().toUpperCase();
  if (u.length === 0) return null;
  if (u.includes("PERP") || u === "0") return "PERP";
  if (
    u === "1H" || u === "HOURLY" || u === "60" || u === "60M" ||
    u.includes("KXBTCD") || u.includes("KXBTCH")
  ) return "1H";
  if (u === "15M" || u === "15") return "15M";
  const n = Number(u);
  if (Number.isFinite(n)) return productDurationFromMinsLabel(n);
  return null;
}

/**
 * Identity for evaluate gates. Ticker wins over a hostile series/"15" minutes
 * so KXBTCD/PERP cannot sneak onto the 15m desk.
 */
export function resolveProductDuration(opts: {
  series?: ProductDuration | string | null;
  ticker?: string | null;
  contractDurationMins?: number | string | null;
}): ProductDuration | null {
  const fromTicker = seriesDurationFromTicker(opts.ticker ?? null);
  if (fromTicker) return fromTicker;
  const fromMins = productDurationFromMinsLabel(opts.contractDurationMins);
  if (fromMins) return fromMins;
  return productDurationFromMinsLabel(opts.series ?? null);
}

export type FifteenMDeskGate = { ok: true; reason: "KXBTC15M" | "LEGACY_NO_TICKER" } | {
  ok: false;
  reason: "HOURLY_TICKER_ON_15M_DESK" | "PERP_TICKER_ON_15M_DESK" | "UNKNOWN_SERIES_ON_15M_DESK";
};

/**
 * 15m evaluateEntry / evaluateStrategiesForBot gate.
 * Missing ticker (backtest/snapshot obs) is allowed — historically 15m-only —
 * unless minutes/label is explicitly hourly or perp.
 * A present ticker that is not KXBTC15M is refused even when 1H flags are on.
 */
export function is15mDeskEvaluateAllowed(opts: {
  ticker?: string | null;
  enable1HContracts?: boolean;
  enable1HLive?: boolean;
  contractDurationMins?: number | string | null;
}): FifteenMDeskGate {
  const series = resolveProductDuration({
    ticker: opts.ticker,
    contractDurationMins: opts.contractDurationMins,
  });
  if (series === "15M") return { ok: true, reason: "KXBTC15M" };
  if (series === "1H" || series === "PERP") {
    // Named flag gate is the hourly/perp evaluate path. Consult it so a
    // flags-on 1H cannot be mistaken for a 15m-desk unlock — this desk
    // still refuses. evaluateHourlyTick is the only 1H evaluate.
    void hourlyOrPerpEvaluateAllowed({
      series,
      ticker: opts.ticker,
      enable1HContracts: opts.enable1HContracts,
      enable1HLive: opts.enable1HLive,
      contractDurationMins: opts.contractDurationMins,
    });
    return {
      ok: false,
      reason: series === "PERP" ? "PERP_TICKER_ON_15M_DESK" : "HOURLY_TICKER_ON_15M_DESK",
    };
  }
  if (opts.ticker) return { ok: false, reason: "UNKNOWN_SERIES_ON_15M_DESK" };
  return { ok: true, reason: "LEGACY_NO_TICKER" };
}

/**
 * Duration input for isStrategyAllowedForDuration.
 * Ticker series wins over a missing/wrong minutes field so a KXBTCD quote
 * cannot sneak into the 15m roster via `contractDurationMins ?? 15`.
 */
export function durationForObservation(opts: {
  ticker?: string | null;
  contractDurationMins?: number | string | null;
}): ProductDuration | number | string {
  const fromTicker = seriesDurationFromTicker(opts.ticker ?? null);
  if (fromTicker) return fromTicker;
  if (opts.contractDurationMins == null || opts.contractDurationMins === "") return 15;
  return opts.contractDurationMins;
}

/**
 * Hourly / perp evaluate may only run when the matching product flag is on.
 * Flags off → fail-closed. PERP has no live flag on this desk → never,
 * even if enable1HContracts / enable1HLive are true.
 * enable1HLive is fills, not evaluate. Does not enable anything.
 * Ticker identity wins over a hostile series:"15M" so KXBTCD cannot evaluate
 * as 15m via this helper (15m desk still has its own refuse).
 */
export function hourlyOrPerpEvaluateAllowed(opts: {
  series?: ProductDuration | string | null;
  ticker?: string | null;
  enable1HContracts?: boolean;
  enable1HLive?: boolean;
  contractDurationMins?: number | string | null;
}): { ok: boolean; reason: string } {
  // enable1HLive never unlocks evaluate — fills-only. Consult so a flags-on
  // live bit cannot be mistaken for evaluate permission.
  void opts.enable1HLive;
  const series = resolveProductDuration({
    series: opts.series,
    ticker: opts.ticker,
    contractDurationMins: opts.contractDurationMins,
  });
  if (series === "PERP") {
    return { ok: false, reason: "PERP_EVALUATE_FLAGS_OFF" };
  }
  if (series === "1H") {
    if (opts.enable1HContracts !== true) {
      return { ok: false, reason: "HOURLY_CONTRACTS_FLAG_OFF" };
    }
    return { ok: true, reason: "HOURLY_CONTRACTS_ON" };
  }
  return { ok: true, reason: "NOT_HOURLY_OR_PERP" };
}

/** Leftover hourly evaluate may run only off paper/frozen. Does not ENABLE. */
export function paperDeskHourlyEvaluateMayRun(cfg: { paperMode?: boolean; frozenCcMode?: boolean }): boolean {
  if (cfg.paperMode === true || cfg.frozenCcMode === true) return false;
  return true;
}
