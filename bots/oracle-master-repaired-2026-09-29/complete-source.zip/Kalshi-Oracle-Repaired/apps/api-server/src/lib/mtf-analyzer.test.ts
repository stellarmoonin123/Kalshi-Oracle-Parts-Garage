/**
 * MTF composite score honesty. LIVE_APPLY not flipped. paperMode true.
 * Missing Coinbase/fast legs are not a fake 0-bull 1h vote.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { compositeMtfScore } from "./mtf-analyzer.js";

test("all fast legs missing → 0, not a lone 1h Kalshi bias", () => {
  assert.equal(compositeMtfScore({ m1: null, m5: null, m15: null, h1: 2 }), 0);
  assert.equal(compositeMtfScore({ m1: null, m5: null, m15: null, h1: -2 }), 0);
  assert.equal(compositeMtfScore({ m1: null, m5: null, m15: null, h1: null }), 0);
});

test("present fast legs are summed; missing legs omitted (not scored as 0 pull? omit=same for sum)", () => {
  const both = compositeMtfScore({ m1: 2, m5: 2, m15: 2, h1: 1 });
  assert.ok(both >= 3);
  const no1m = compositeMtfScore({ m1: null, m5: 2, m15: 2, h1: 1 });
  assert.ok(no1m >= 1);
  assert.ok(no1m <= both);
});

test("slow-leg contract: lone h1 still cannot invent score without fast legs (fallback feeds h1 only)", () => {
  // fetchSlowOHLC may revive h1 via real-exchange OHLC when Kalshi is empty,
  // but compositeMtfScore must still refuse a lone-h1 vote (weight honesty).
  assert.equal(compositeMtfScore({ m1: null, m5: null, m15: null, h1: 1 }), 0);
  // With a live fast leg, h1 half-weight contributes (unchanged).
  const withH1 = compositeMtfScore({ m1: 1, m5: null, m15: null, h1: 2 });
  const withoutH1 = compositeMtfScore({ m1: 1, m5: null, m15: null, h1: null });
  assert.ok(withH1 >= withoutH1);
});
