import fs from "node:fs";
import path from "node:path";
import type { BotLogEvent } from "./trading-bot.js";

// ── Persistent bot log history ─────────────────────────────────────────────
// The Live Log panel used to be purely an in-memory pub/sub: every SSE
// reconnect (page reload, tab switch, network blip, server restart) started
// from a blank slate and only filled in as new events fired — so "history"
// never actually accumulated and the panel routinely showed up empty right
// after connecting. This store keeps a bounded on-disk JSONL history that
// survives reconnects *and* process restarts, plus an in-memory mirror for
// fast reads.

const FILE_PATH   = path.join(process.cwd(), "data", "bot-log.jsonl");
const MAX_LINES   = 2000; // on-disk cap — rewritten (compacted) once exceeded
const MEMORY_CAP  = 500;  // in-memory ring buffer cap for fast SSE backlog sends

let memoryBuffer: BotLogEvent[] = [];

function ensureDir() {
  fs.mkdirSync(path.dirname(FILE_PATH), { recursive: true });
}

/** Load persisted history into the in-memory buffer. Call once at startup. */
export function loadPersistedLogs(): BotLogEvent[] {
  try {
    if (!fs.existsSync(FILE_PATH)) return [];
    const raw = fs.readFileSync(FILE_PATH, "utf8");
    const lines = raw.split("\n").filter(Boolean);
    const entries: BotLogEvent[] = [];
    for (const line of lines) {
      try {
        const e = JSON.parse(line) as BotLogEvent;
        if (typeof e.ts === "number" && typeof e.message === "string") entries.push(e);
      } catch {
        // skip a corrupt line rather than failing the whole load
      }
    }
    memoryBuffer = entries.slice(-MEMORY_CAP);
    return memoryBuffer;
  } catch (err) {
    console.error("[bot-log-store] failed to load persisted logs:", (err as Error).message);
    return [];
  }
}

/** Append one log entry to disk (fire-and-forget-safe) and the in-memory buffer. */
export function appendLog(e: BotLogEvent) {
  memoryBuffer.push(e);
  if (memoryBuffer.length > MEMORY_CAP) memoryBuffer = memoryBuffer.slice(-MEMORY_CAP);

  try {
    ensureDir();
    fs.appendFileSync(FILE_PATH, JSON.stringify(e) + "\n");
    maybeCompact();
  } catch (err) {
    // Never let a logging failure interrupt the bot's tick loop.
    console.error("[bot-log-store] failed to persist log line:", (err as Error).message);
  }
}

let linesSinceCompactCheck = 0;
/** Periodically rewrite the file down to the last MAX_LINES so it can't grow unbounded. */
function maybeCompact() {
  linesSinceCompactCheck++;
  if (linesSinceCompactCheck < 200) return; // avoid stat/read on every single append
  linesSinceCompactCheck = 0;
  try {
    const raw = fs.readFileSync(FILE_PATH, "utf8");
    const lines = raw.split("\n").filter(Boolean);
    if (lines.length > MAX_LINES) {
      fs.writeFileSync(FILE_PATH, lines.slice(-MAX_LINES).join("\n") + "\n");
    }
  } catch (err) {
    console.error("[bot-log-store] compaction failed:", (err as Error).message);
  }
}

/** Most recent N log entries (oldest first), for SSE backlog / REST history. */
export function getRecentLogs(limit = MEMORY_CAP): BotLogEvent[] {
  return memoryBuffer.slice(-limit);
}
