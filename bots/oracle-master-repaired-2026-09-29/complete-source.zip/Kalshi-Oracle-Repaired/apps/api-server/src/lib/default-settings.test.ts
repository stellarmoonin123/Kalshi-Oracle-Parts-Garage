/**
 * `default` chat/API restore: snapshot onto .bot-config.json, ledger 30618¢
 * untouched, paperMode cannot become false.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { readFileSync } from "node:fs";
import {
  isDefaultChatCommand,
  forcePaperModeTrue,
  forceFrozenCcModeTrue,
  restoreDefaultSettings,
  formatDefaultRestoreConfirmation,
  DEFAULT_SETTINGS_FROZEN_AT,
  DEFAULT_CODE_CHECKPOINT_FILES,
} from "./default-settings.js";
import { oracleDeskChatEvents, type DeskSnapshot } from "./oracle-desk-chat.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const AGENT_SRC = readFileSync(path.resolve(DIR, "../routes/agent.ts"), "utf8");
const BOT_SRC = readFileSync(path.resolve(DIR, "../routes/bot.ts"), "utf8");
const CHAT_SRC = readFileSync(path.resolve(DIR, "./oracle-desk-chat.ts"), "utf8");

function tmpDir(): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), "default-settings-"));
}

function writeJson(p: string, v: unknown): void {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(v, null, 2) + "\n", "utf8");
}

function snapDesk(): DeskSnapshot {
  return {
    state: "WATCHING",
    lastSignal: "skip",
    paperMode: true,
    autoMode: false,
    useExpertAgent: false,
    enable1HContracts: false,
    paperVirtualCents: 30_618,
    paperLedgerCents: 30_618,
    todayWins: 1,
    todayLosses: 9,
    todayPnlCents: -215,
    consecutiveLosses: 0,
    detectedRegime: "unclear",
    activeStrategy: null,
    secsRemaining: 400,
    classification: "intentional_wait",
    headline: "Wait.",
    recommendation: "Do not cut EV.",
    activeBlockers: [],
    trades: [],
    basisProj: null,
    modelProj: null,
    projLine: "proj n/a",
  };
}

test("isDefaultChatCommand is exact trimmed default, case-insensitive", () => {
  assert.equal(isDefaultChatCommand("default"), true);
  assert.equal(isDefaultChatCommand("  DEFAULT  "), true);
  assert.equal(isDefaultChatCommand("Default"), true);
  assert.equal(isDefaultChatCommand("default please"), false);
  assert.equal(isDefaultChatCommand("defaults"), false);
  assert.equal(isDefaultChatCommand(""), false);
  assert.equal(isDefaultChatCommand("restore default"), false);
});

test("default restores snapshot onto bot-config", () => {
  const dir = tmpDir();
  const snapshotPath = path.join(dir, "default-settings-snapshot.json");
  const configPath = path.join(dir, ".bot-config.json");
  writeJson(snapshotPath, {
    enabled: true,
    autoMode: true,
    paperMode: true,
    minConfidence: 52,
    useKellySizing: true,
    useKellyFraction: true,
    reservePct: 15,
  });
  writeJson(configPath, {
    enabled: false,
    autoMode: false,
    paperMode: true,
    minConfidence: 90,
    useKellySizing: false,
  });
  const r = restoreDefaultSettings({ snapshotPath, configPath });
  if (!r.ok) throw new Error("restoreDefaultSettings failed");
  assert.equal(r.config.paperMode, true);
  assert.equal(r.config.minConfidence, 52);
  assert.equal(r.config.enabled, true);
  assert.equal(r.config.autoMode, true);
  const disk = JSON.parse(fs.readFileSync(configPath, "utf8"));
  assert.equal(disk.paperMode, true);
  assert.equal(disk.minConfidence, 52);
  assert.match(r.confirmation, /paperMode true/);
  assert.match(r.confirmation, /EV 3¢ \/ Kelly 0\.60 unchanged/);
  assert.ok(r.confirmation.includes(DEFAULT_SETTINGS_FROZEN_AT));
});

test("default does not touch ledger", () => {
  const dir = tmpDir();
  const snapshotPath = path.join(dir, "default-settings-snapshot.json");
  const configPath = path.join(dir, ".bot-config.json");
  const ledgerPath = path.join(dir, "paper-ledger.json");
  writeJson(snapshotPath, { paperMode: true, minConfidence: 52, paperStartingBalanceCents: 31300 });
  writeJson(configPath, { paperMode: true, minConfidence: 99 });
  writeJson(ledgerPath, {
    virtualCents: 30618,
    peakCents: 31300,
    pnlCents: -215,
    wins: 1,
    losses: 9,
    trades: 10,
  });
  const before = fs.readFileSync(ledgerPath, "utf8");
  const r = restoreDefaultSettings({ snapshotPath, configPath });
  assert.equal(r.ok, true);
  assert.equal(fs.readFileSync(ledgerPath, "utf8"), before);
  assert.equal(JSON.parse(before).virtualCents, 30618);
  assert.equal(JSON.parse(fs.readFileSync(configPath, "utf8")).minConfidence, 52);
});

test("default cannot set paperMode false", () => {
  const dir = tmpDir();
  const snapshotPath = path.join(dir, "default-settings-snapshot.json");
  const configPath = path.join(dir, ".bot-config.json");
  writeJson(snapshotPath, { paperMode: false, enabled: true, minConfidence: 52 });
  writeJson(configPath, { paperMode: true, enabled: false });
  const forced = forcePaperModeTrue({ paperMode: false });
  assert.equal(forced.paperMode, true);
  const r = restoreDefaultSettings({ snapshotPath, configPath });
  if (!r.ok) throw new Error("restoreDefaultSettings failed");
  assert.equal(r.config.paperMode, true);
  const disk = JSON.parse(fs.readFileSync(configPath, "utf8"));
  assert.equal(disk.paperMode, true);
  assert.notEqual(disk.paperMode, false);
});

test("restore fails clean when snapshot is missing", () => {
  const dir = tmpDir();
  const snapshotPath = path.join(dir, "missing.json");
  const configPath = path.join(dir, ".bot-config.json");
  writeJson(configPath, { paperMode: true, minConfidence: 52 });
  const r = restoreDefaultSettings({ snapshotPath, configPath });
  assert.equal(r.ok, false);
  if (r.ok) throw new Error("expected fail");
  assert.match(r.confirmation, /Could not restore/);
  assert.equal(JSON.parse(fs.readFileSync(configPath, "utf8")).minConfidence, 52);
});

test("chat `default` skips Gemini and confirms restore", async () => {
  let applied = 0;
  const fetched: string[] = [];
  const fetchImpl = (async (input: unknown) => {
    fetched.push(String(input));
    throw new Error("Gemini must not run for default");
  }) as typeof fetch;
  let body = "";
  const types: string[] = [];
  for await (const evt of oracleDeskChatEvents({
    question: "  DeFaUlT\n",
    snapshot: snapDesk(),
    chatRole: "ADMIN", // accounts: `default` is an ADMIN-only chat command
    modelOverride: "gemini-flash",
    env: { GEMINI_API_KEY: "test-gemini", GROQ_API_KEY: "", GOOGLE_GENERATIVE_AI_API_KEY: "" },
    fetchImpl,
    restoreDefault: () => {
      applied += 1;
      const cfg = { paperMode: true as const, minConfidence: 52 };
      return {
        ok: true,
        config: cfg,
        confirmation: formatDefaultRestoreConfirmation(cfg, {
          codeFilesRestored: ["src/lib/strategy-learner.ts"],
          bounceRequired: true,
        }),
        snapshotPath: "/tmp/snap.json",
        configPath: "/tmp/cfg.json",
        codeFilesRestored: ["src/lib/strategy-learner.ts"],
        bounceRequired: true,
      };
    },
  })) {
    types.push(evt.type);
    if (evt.type === "delta") body += evt.content;
  }
  assert.equal(applied, 1);
  assert.equal(fetched.length, 0);
  assert.match(body, /paperMode true/);
  assert.match(body, /EV 3¢ \/ Kelly 0\.60 unchanged/);
  assert.match(body, /code checkpoint/);
  assert.equal(types[types.length - 1], "done");
  assert.equal(types.includes("error"), false);
});

test("agent chat intercepts default; bot exposes restore-default POST", () => {
  const chat = AGENT_SRC.slice(AGENT_SRC.indexOf('router.post("/agent/chat"'));
  assert.match(chat, /restoreDefaultSettings/);
  assert.match(chat, /restoreDefault:/);
  assert.match(BOT_SRC, /\/bot\/restore-default/);
  assert.match(CHAT_SRC, /isDefaultChatCommand/);
  assert.doesNotMatch(chat, /paperMode:\s*false/);
});

test("default restore copies PATH p code checkpoint files", () => {
  const dir = tmpDir();
  const snapshotPath = path.join(dir, "default-settings-snapshot.json");
  const configPath = path.join(dir, ".bot-config.json");
  const ledgerPath = path.join(dir, "paper-ledger.json");
  const checkpointDir = path.join(dir, "default-code-checkpoint");
  const srcRoot = path.join(dir, "tree");
  const envPath = path.join(dir, ".env");
  writeJson(snapshotPath, { paperMode: false, enabled: true, minConfidence: 52 });
  writeJson(configPath, { paperMode: true, minConfidence: 99 });
  writeJson(ledgerPath, { virtualCents: 30618 });
  fs.writeFileSync(envPath, "SECRET=do-not-touch\n", "utf8");
  const marker = "PATH_P_FREEZE_CHECKPOINT_MARK";
  for (const rel of DEFAULT_CODE_CHECKPOINT_FILES) {
    const from = path.join(checkpointDir, rel);
    fs.mkdirSync(path.dirname(from), { recursive: true });
    fs.writeFileSync(from, `// ${marker}\nexport const X = "${rel}";\n`, "utf8");
    const dest = path.join(srcRoot, rel);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, "// dirty live src — should be overwritten\n", "utf8");
  }
  const ledgerBefore = fs.readFileSync(ledgerPath, "utf8");
  const envBefore = fs.readFileSync(envPath, "utf8");
  const r = restoreDefaultSettings({ snapshotPath, configPath, checkpointDir, srcRoot, restoreCode: true });
  if (!r.ok) throw new Error("restoreDefaultSettings failed");
  assert.equal(r.config.paperMode, true);
  assert.equal(r.bounceRequired, true);
  assert.deepEqual(r.codeFilesRestored, [...DEFAULT_CODE_CHECKPOINT_FILES]);
  assert.match(r.confirmation, /code checkpoint/);
  assert.match(r.confirmation, /Bounce required/);
  assert.match(r.confirmation, /Never ENABLE LATE\/SP\/OTM/);
  assert.equal(JSON.parse(fs.readFileSync(configPath, "utf8")).paperMode, true);
  assert.notEqual(JSON.parse(fs.readFileSync(configPath, "utf8")).paperMode, false);
  assert.equal(fs.readFileSync(ledgerPath, "utf8"), ledgerBefore);
  assert.equal(fs.readFileSync(envPath, "utf8"), envBefore);
  for (const rel of DEFAULT_CODE_CHECKPOINT_FILES) {
    const dest = fs.readFileSync(path.join(srcRoot, rel), "utf8");
    const from = fs.readFileSync(path.join(checkpointDir, rel), "utf8");
    assert.equal(dest, from);
    assert.ok(dest.includes(marker));
  }
});

test("default forces frozenCcMode true even when snapshot omits/falsifies it", () => {
  const dir = tmpDir();
  const snapshotPath = path.join(dir, "default-settings-snapshot.json");
  const configPath = path.join(dir, ".bot-config.json");
  writeJson(snapshotPath, { paperMode: true, frozenCcMode: false, minConfidence: 52 });
  writeJson(configPath, { paperMode: true, frozenCcMode: false, minConfidence: 99 });
  assert.equal(forceFrozenCcModeTrue({ frozenCcMode: false }).frozenCcMode, true);
  const r = restoreDefaultSettings({ snapshotPath, configPath });
  if (!r.ok) throw new Error("restoreDefaultSettings failed");
  assert.equal(r.config.frozenCcMode, true);
  assert.equal(JSON.parse(fs.readFileSync(configPath, "utf8")).frozenCcMode, true);
  assert.match(r.confirmation, /frozenCcMode true/);
});
