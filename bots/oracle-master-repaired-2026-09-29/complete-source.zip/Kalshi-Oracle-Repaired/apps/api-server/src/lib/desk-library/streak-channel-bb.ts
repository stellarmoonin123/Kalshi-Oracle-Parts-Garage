/**
 * desk-library/streak-channel-bb.ts — catalog row only (OBSERVE).
 *
 * LIVE_APPLY false. Not wired into evaluateDeskLibrary take-chain.
 * Not a StrategyId. Helper lives in ../direction-confluence.ts
 * (labels only; TradingBot.evaluate does not skip on it).
 *
 * Verdict: weak as settlement-hold. See research/direction-confluence-verdict.md.
 */
export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;
