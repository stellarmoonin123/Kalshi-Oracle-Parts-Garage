#!/usr/bin/env tsx
/**
 * GO — BACKTEST LAB v5 (2026-08-22): developer entry point for a one-off
 * LEAN vs LEGACY comparison run against real BTC OHLC. Prints the OOS table,
 * verdict, sensitivity sweep, and poison-test result to stdout. Does NOT
 * save a snapshot or write a report file — use `pnpm run runPolicyRegression`
 * for that (this script is the quick/manual "just show me the numbers" path).
 *
 * Usage: pnpm run runLeanVsLegacy [lookbackDays]
 */
import { runLeanVsLegacy } from "../src/lib/backtest-lab-v5/regression-runner.js";

async function main() {
  const lookbackDays = process.argv[2] ? Number(process.argv[2]) : undefined;
  const report = await runLeanVsLegacy({ lookbackDays });

  console.log(`\n=== BACKTEST LAB v5: LEAN vs LEGACY ===`);
  console.log(`fetched=${report.fetchedAt} lookbackDays=${report.lookbackDays} candles=${report.candleCount} source=${report.source}\n`);

  const row = (label: string, m: typeof report.lean.metrics) =>
    `${label.padEnd(8)} trades=${String(m.trades).padStart(4)} winRate=${(m.winRate * 100).toFixed(1)}%  feeNet=${m.feeNetPnlCents.toFixed(0)}c  maxDD=${(m.maxDrawdown * 100).toFixed(1)}%  PF=${m.profitFactor.toFixed(2)}  wrongKit=${(m.wrongKitRate * 100).toFixed(1)}%  winRateCI=[${(m.bootstrap.p5 * 100).toFixed(1)}%,${(m.bootstrap.p95 * 100).toFixed(1)}%]  feeNetCI=[${m.feeNetCI.p5.toFixed(2)}c,${m.feeNetCI.p95.toFixed(2)}c]`;

  console.log(row("LEAN", report.lean.metrics));
  console.log(row("LEGACY", report.legacy.metrics));
  console.log(`\nVERDICT: ${report.verdict.verdict} — ${report.verdict.reason}\n`);

  console.log(`--- Sensitivity ---`);
  for (const s of report.sensitivity) {
    console.log(`${s.label.padEnd(10)} verdict=${s.verdict.verdict.padEnd(14)} LEAN feeNet=${s.lean.feeNetPnlCents.toFixed(0)}c LEGACY feeNet=${s.legacy.feeNetPnlCents.toFixed(0)}c`);
  }

  console.log(`\n--- Poison test ---`);
  console.log(`${report.poisonTest.passed ? "PASSED" : "FAILED"} — ${report.poisonTest.periodsChecked} decision points checked, ${report.poisonTest.mismatches.length} mismatches`);

  console.log(`\n--- Limitations ---`);
  for (const l of report.limitations) console.log(`- ${l}`);

  process.exit(report.poisonTest.passed ? 0 : 1);
}

main().catch(err => {
  console.error("[runLeanVsLegacy] failed:", err);
  process.exit(1);
});
