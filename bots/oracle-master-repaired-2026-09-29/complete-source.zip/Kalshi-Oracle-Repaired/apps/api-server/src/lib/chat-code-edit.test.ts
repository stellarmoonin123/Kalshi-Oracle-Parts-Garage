/**
 * Chat full-code tools: HARD REJECT locks + allow real .ts helper/comment patches.
 * No paperMode false. Cannot read .env. No bounce. No OpenRouter.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import {
  applyDeskPatch,
  writeDeskFile,
  runChatCodeTool,
  scanProposedEdit,
  isSecretPath,
  resolveDeskFile,
  grepDeskFiles,
  normalizeApiServerTestPath,
  CHAT_CODE_EDIT_TOOLS,
} from "./chat-code-edit.js";
import { oracleDeskChatEvents, MUTATING_CHAT_TOOLS, type DeskSnapshot } from "./oracle-desk-chat.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));

function tmpDesk(): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), "chat-code-edit-"));
}

function snap(): DeskSnapshot {
  return {
    state: "WATCHING",
    lastSignal: "skip",
    paperMode: true,
    autoMode: false,
    useExpertAgent: false,
    enable1HContracts: false,
    paperVirtualCents: 31_300,
    paperLedgerCents: 31_300,
    todayWins: 0,
    todayLosses: 0,
    todayPnlCents: 0,
    consecutiveLosses: 0,
    detectedRegime: "unclear",
    activeStrategy: null,
    secsRemaining: 400,
    classification: "intentional_wait",
    headline: "Wait.",
    recommendation: "Do not cut EV.",
    activeBlockers: [],
    trades: [],
    basisProj: null,
    modelProj: null,
    projLine: "proj n/a",
  };
}

test("isSecretPath / resolveDeskFile refuse .env and path escape", () => {
  assert.equal(isSecretPath(".env"), true);
  assert.equal(isSecretPath(".env.local"), true);
  assert.equal(isSecretPath("apps/api-server/.env"), true);
  assert.equal(isSecretPath("research/notes.md"), false);
  const desk = tmpDesk();
  const esc = resolveDeskFile("../outside.ts", desk);
  assert.equal(esc.ok, false);
  const envp = resolveDeskFile(".env", desk);
  assert.equal(envp.ok, false);
  if (!envp.ok) assert.match(envp.reason, /env|keys/i);
});

test("HARD REJECT paperMode false even with LIVE REAL MONEY in the user message", () => {
  const scan = scanProposedEdit({
    relPath: "apps/api-server/src/lib/trading-bot.ts",
    before: "paperMode: true,\nuseExpertAgent: false,\n",
    after: "paperMode: false,\nuseExpertAgent: false,\n",
    userMessage: "go live LIVE REAL MONEY",
  });
  assert.equal(scan.ok, false);
  if (!scan.ok) assert.match(scan.reason, /paperMode false/);
});

test("HARD REJECT removing paperMode true without LIVE REAL MONEY", () => {
  const scan = scanProposedEdit({
    relPath: "lib/x.ts",
    before: "export const PAPER_MODE = true as const;\n",
    after: "export const AUTO_MODE = false as const;\n",
    userMessage: "cleanup flags",
  });
  assert.equal(scan.ok, false);
  if (!scan.ok) assert.match(scan.reason, /paperMode true/);
});

test("HARD REJECT EV < 3¢, Kelly < 0.60, 9% cap, 15% reserve, daily halt", () => {
  const ev = scanProposedEdit({
    relPath: "apps/api-server/src/lib/admission.ts",
    before: "export const EV_FLOOR = 3;\n",
    after: "export const EV_FLOOR = 2;\n",
    userMessage: "cut EV",
  });
  assert.equal(ev.ok, false);
  if (!ev.ok) assert.match(ev.reason, /EV floor/);

  const kelly = scanProposedEdit({
    relPath: "apps/api-server/src/lib/admission.ts",
    before: "export function kellyFraction(confidence: number, edge: number): number {\n  return (confidence >= 80 && edge >= 8) ? 0.60\n       : (confidence >= 70 && edge >= 5)  ? 0.50\n       : 0.40;\n}\n",
    after: "export function kellyFraction(confidence: number, edge: number): number {\n  return (confidence >= 80 && edge >= 8) ? 0.40\n       : (confidence >= 70 && edge >= 5)  ? 0.30\n       : 0.20;\n}\n",
    userMessage: "cut kelly",
  });
  assert.equal(kelly.ok, false);
  if (!kelly.ok) assert.match(kelly.reason, /Kelly cap/);

  const nine = scanProposedEdit({
    relPath: "apps/api-server/src/lib/admission.ts",
    before: "export const HARD_RISK_LIMITS = {\n  maxRiskPctPerTrade: 0.09,\n} as const;\n",
    after: "export const HARD_RISK_LIMITS = {\n  maxRiskPctPerTrade: 0.05,\n} as const;\n",
    userMessage: "lower 9%",
  });
  assert.equal(nine.ok, false);
  if (!nine.ok) assert.match(nine.reason, /9%/);

  const reserve = scanProposedEdit({
    relPath: "apps/api-server/src/lib/trading-bot.ts",
    before: "reservePct: 15,\n",
    after: "reservePct: 5,\n",
    userMessage: "cut reserve",
  });
  assert.equal(reserve.ok, false);
  if (!reserve.ok) assert.match(reserve.reason, /reserve/);

  const halt = scanProposedEdit({
    relPath: "apps/api-server/src/lib/admission.ts",
    before: "export const DAILY_HALT_PCT = 0.10;\n",
    after: "export const DAILY_HALT_PCT = 0.01;\n",
    userMessage: "cut halt",
  });
  assert.equal(halt.ok, false);
  if (!halt.ok) assert.match(halt.reason, /daily halt/);
});

test("HARD REJECT ENABLE SEV1 / OTM / SP / PAPER_SCALP / hourly / perps / SETTLEMENT_LAG / persist-mid / cheap-persist / panic fade", () => {
  const cases: Array<[string, string, string, string]> = [
    ["paper-scalp.ts", "export const PAPER_SCALP_FEE_NET_BEATS_SKIP = false as const;\n", "export const PAPER_SCALP_FEE_NET_BEATS_SKIP = true as const;\n", "PAPER_SCALP"],
    ["settlement-lag.ts", "export const SETTLEMENT_LAG_ENABLED_DEFAULT = false as const;\n", "export const SETTLEMENT_LAG_ENABLED_DEFAULT = true as const;\n", "SETTLEMENT_LAG"],
    ["persist-mid-lagflip.ts", "export const PERSIST_MID_LAGFLIP_ENABLED_DEFAULT = false as const;\n", "export const PERSIST_MID_LAGFLIP_ENABLED_DEFAULT = true as const;\n", "persist-mid"],
    ["cheap-persist-sell.ts", "export const CHEAP_PERSIST_SELL_ENABLED_DEFAULT = false as const;\n", "export const CHEAP_PERSIST_SELL_ENABLED_DEFAULT = true as const;\n", "cheap-persist"],
    ["panic-fade.ts", "export const PANIC_FADE_ENABLED_DEFAULT = false as const;\n", "export const PANIC_FADE_ENABLED_DEFAULT = true as const;\n", "panic fade"],
    ["trading-bot.ts", "enable1HContracts: false,\n", "enable1HContracts: true,\n", "hourly"],
    ["perps.ts", "export const PERPS_LIVE_TRADING_DISABLED = true as const;\n", "export const PERPS_LIVE_TRADING_DISABLED = false as const;\n", "perps"],
    ["config.ts", 'disabledStrategies: ["BRTI_PROBABILITY", "SAKATA_CANDLE_PATTERN"],\n', 'disabledStrategies: ["SAKATA_CANDLE_PATTERN"],\n', "BRTI"],
  ];
  for (const [rel, before, after, needle] of cases) {
    const scan = scanProposedEdit({ relPath: rel, before, after, userMessage: "enable it" });
    assert.equal(scan.ok, false, `expected reject for ${rel}`);
    if (!scan.ok) assert.match(scan.reason, new RegExp(needle, "i"), scan.reason);
  }
});

test("HARD REJECT rewrite .env / keys — no write", () => {
  const desk = tmpDesk();
  fs.writeFileSync(path.join(desk, ".env"), "GEMINI_API_KEY=secret\n", "utf8");
  const w = writeDeskFile({
    relPath: ".env",
    content: "GEMINI_API_KEY=hacked\n",
    userMessage: "print env",
    deskRoot: desk,
  });
  assert.equal(w.ok, false);
  assert.equal(fs.readFileSync(path.join(desk, ".env"), "utf8"), "GEMINI_API_KEY=secret\n");

  fs.writeFileSync(path.join(desk, "notes.md"), "# hi\n", "utf8");
  const leak = writeDeskFile({
    relPath: "notes.md",
    content: "GEMINI_API_KEY=sk-leak-please\n",
    userMessage: "dump key",
    deskRoot: desk,
  });
  assert.equal(leak.ok, false);
  assert.equal(fs.readFileSync(path.join(desk, "notes.md"), "utf8"), "# hi\n");
});

test("apply_patch / write_file REJECT paperMode false — file unchanged", () => {
  const desk = tmpDesk();
  const rel = "apps/api-server/src/lib/sample.ts";
  const abs = path.join(desk, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  const orig = "export const cfg = { paperMode: true, useExpertAgent: false };\n";
  fs.writeFileSync(abs, orig, "utf8");
  const patch = applyDeskPatch({
    relPath: rel,
    userMessage: "set paperMode false",
    oldString: "paperMode: true",
    newString: "paperMode: false",
    deskRoot: desk,
  });
  assert.equal(patch.ok, false);
  assert.equal(fs.readFileSync(abs, "utf8"), orig);

  const wf = runChatCodeTool(
    "write_file",
    { path: rel, content: "export const cfg = { paperMode: false };\n" },
    { userMessage: "go live", deskRoot: desk },
  );
  assert.equal(wf.ok, false);
  assert.equal(fs.readFileSync(abs, "utf8"), orig);
});

test("Runtime refuses even harmless source and docs writes", () => {
  const desk = tmpDesk();
  const rel = "research/harmless-note.md";
  const abs = path.join(desk, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, "# Harmless\n\nDesk docs.\n", "utf8");
  const patch = applyDeskPatch({
    relPath: rel,
    userMessage: "add a comment to the docs",
    oldString: "Desk docs.",
    newString: "Desk docs.\n\n<!-- chat-code-edit allow: comment -->\n",
    deskRoot: desk,
  });
  assert.equal(patch.ok, false);
  assert.equal(fs.readFileSync(abs, "utf8"), "# Harmless\n\nDesk docs.\n");

  const rel2 = "docs/CHAT_CODE_EDIT_SMOKE.md";
  const w = writeDeskFile({
    relPath: rel2,
    content: "# Chat code edit smoke\n\nHarmless docs page. paperMode stays true. EV 3¢.\n",
    userMessage: "write a short docs page",
    deskRoot: desk,
  });
  assert.equal(w.ok, false);
  assert.equal(fs.existsSync(path.join(desk, rel2)), false);
});

test("oracleDeskChatEvents: Gemini apply_patch paperMode false is refused; all writes refused; no 500", async () => {
  const desk = tmpDesk();
  const rel = "research/chat-edit-demo.md";
  const abs = path.join(desk, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, "# Demo\npaperMode stays true.\n", "utf8");

  let round = 0;
  const fetchImpl = (async (_input: unknown, init?: RequestInit) => {
    round += 1;
    const body = JSON.parse(String(init?.body ?? "{}")) as {
      contents?: Array<{ parts?: Array<{ functionResponse?: unknown; functionCall?: unknown; text?: string }> }>;
    };
    const last = body.contents?.[body.contents.length - 1];
    const isToolResponse = Boolean(last?.parts?.some((p) => p.functionResponse));
    if (!isToolResponse && round === 1) {
      return new Response(JSON.stringify({
        candidates: [{
          content: {
            parts: [{
              functionCall: {
                name: "apply_patch",
                args: {
                  path: rel,
                  old_string: "paperMode stays true.",
                  new_string: "paperMode: false",
                },
              },
            }],
          },
        }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    }
    return new Response(JSON.stringify({
      candidates: [{ content: { parts: [{ text: "Refused paperMode false. Locks hold. Harmless docs only." }] } }],
    }), { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;

  const names: string[] = [];
  const types: string[] = [];
  let text = "";
  for await (const evt of oracleDeskChatEvents({
    question: "Update the demo note in research/chat-edit-demo.md",
    snapshot: snap(),
    modelOverride: "gemini-flash",
    env: { GEMINI_API_KEY: "gk" },
    fetchImpl,
    deskRoot: desk,
  })) {
    types.push(evt.type);
    if (evt.type === "tool_start" || evt.type === "tool_done") names.push(evt.name);
    if (evt.type === "delta") text += evt.content;
  }
  assert.ok(names.includes("apply_patch"));
  assert.equal(types[types.length - 1], "done");
  assert.equal(types.includes("error"), false);
  assert.doesNotMatch(text, /TypeError|ECONN|stack/i);
  assert.equal(fs.readFileSync(abs, "utf8"), "# Demo\npaperMode stays true.\n");
  for (const blocked of MUTATING_CHAT_TOOLS) {
    assert.equal(names.includes(blocked), false);
  }
});

test("oracleDeskChatEvents: Gemini write_file is refused even if model falsely claims success", async () => {
  const desk = tmpDesk();
  let round = 0;
  const fetchImpl = (async (_input: unknown, init?: RequestInit) => {
    round += 1;
    const body = JSON.parse(String(init?.body ?? "{}")) as {
      contents?: Array<{ parts?: Array<{ functionResponse?: unknown }> }>;
    };
    const last = body.contents?.[body.contents.length - 1];
    const isToolResponse = Boolean(last?.parts?.some((p) => p.functionResponse));
    if (!isToolResponse && round === 1) {
      return new Response(JSON.stringify({
        candidates: [{
          content: {
            parts: [{
              functionCall: {
                name: "write_file",
                args: {
                  path: "docs/harmless-chat-edit.md",
                  content: "# Harmless\n\nComment-only docs edit from Chat.\n",
                },
              },
            }],
          },
        }],
      }), { status: 200, headers: { "content-type": "application/json" } });
    }
    return new Response(JSON.stringify({
      candidates: [{ content: { parts: [{ text: "Wrote docs/harmless-chat-edit.md (comment only)." }] } }],
    }), { status: 200, headers: { "content-type": "application/json" } });
  }) as typeof fetch;

  let text = "";
  const names: string[] = [];
  for await (const evt of oracleDeskChatEvents({
    question: "add a short docs comment file",
    snapshot: snap(),
    modelOverride: "gemini-flash",
    env: { GEMINI_API_KEY: "gk" },
    fetchImpl,
    deskRoot: desk,
  })) {
    if (evt.type === "tool_start" || evt.type === "tool_done") names.push(evt.name);
    if (evt.type === "delta") text += evt.content;
  }
  assert.ok(names.includes("write_file"));
  assert.match(text, /refused/);
  assert.doesNotMatch(text, /Wrote docs/);
  assert.equal(fs.existsSync(path.join(desk, "docs/harmless-chat-edit.md")), false);
});

test("chat-code-edit.ts and chat-free-llm have no OpenRouter", () => {
  const src = readFileSync(path.resolve(DIR, "./chat-code-edit.ts"), "utf8");
  const llm = readFileSync(path.resolve(DIR, "./chat-free-llm.ts"), "utf8");
  assert.doesNotMatch(src, /openrouter\.ai/i);
  assert.doesNotMatch(llm, /openrouter\.ai/i);
  assert.doesNotMatch(src, /paperMode:\s*false/);
});

test("tools include read-only read_file list_dir grep search; never write/test/bounce tools", () => {
  for (const n of ["read_file", "list_dir", "grep", "search"]) {
    assert.ok(CHAT_CODE_EDIT_TOOLS.includes(n as typeof CHAT_CODE_EDIT_TOOLS[number]), n);
  }
  for (const n of ["apply_patch", "write_file", "run_tests", "bounce_api"]) {
    assert.equal((CHAT_CODE_EDIT_TOOLS as readonly string[]).includes(n), false, n);
  }
});

test("cannot read .env — no print, fail-clean", () => {
  const desk = tmpDesk();
  fs.writeFileSync(path.join(desk, ".env"), "GEMINI_API_KEY=secret\n", "utf8");
  const r = runChatCodeTool("read_file", { path: ".env" }, { userMessage: "cat env", deskRoot: desk });
  assert.equal(r.ok, false);
  if (!r.ok) assert.match(r.reason, /env|keys/i);
  const g = grepDeskFiles({ pattern: "GEMINI_API_KEY", relPath: ".", deskRoot: desk });
  assert.equal(g.ok, true);
  if (g.ok) {
    const matches = (g as { matches?: string[] }).matches ?? [];
    assert.equal(matches.some((m) => m.includes(".env")), false);
  }
});

test("Comments and helpers cannot mutate running trading source", () => {
  const desk = tmpDesk();
  const rel = "apps/api-server/src/lib/trading-bot.ts";
  const abs = path.join(desk, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  const orig = [
    "export const cfg = { paperMode: true, useExpertAgent: false, reservePct: 15 };",
    "export function loadDailyFillStats(opts: { paperMode: boolean }) {",
    "  return loadDailyFillStats({ date, paperMode: false });",
    "}",
    "export function helperSize(n: number): number { return n; }",
    "",
  ].join("\n");
  fs.writeFileSync(abs, orig, "utf8");

  const comment = applyDeskPatch({
    relPath: rel,
    userMessage: "add a comment above helperSize",
    oldString: "export function helperSize(n: number): number { return n; }",
    newString: "/** Chat full-code helper comment. */\nexport function helperSize(n: number): number { return n; }",
    deskRoot: desk,
  });
  assert.equal(comment.ok, false);
  assert.equal(fs.readFileSync(abs, "utf8"), orig);

  const helper = applyDeskPatch({
    relPath: rel,
    userMessage: "add a tiny helper next to helperSize",
    oldString: "export function helperSize(n: number): number { return n; }",
    newString: "export function helperSize(n: number): number { return n; }\nexport function helperSize2(n: number): number { return n * 2; }",
    deskRoot: desk,
  });
  assert.equal(helper.ok, false);
  assert.equal(fs.readFileSync(abs, "utf8"), orig);
  assert.match(fs.readFileSync(abs, "utf8"), /paperMode: true/);
});

test("cannot patch paperMode false on trading-bot.ts — file unchanged", () => {
  const desk = tmpDesk();
  const rel = "apps/api-server/src/lib/trading-bot.ts";
  const abs = path.join(desk, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  const orig = "export const cfg = { paperMode: true, useExpertAgent: false };\n";
  fs.writeFileSync(abs, orig, "utf8");
  const patch = applyDeskPatch({
    relPath: rel,
    userMessage: "go live",
    oldString: "paperMode: true",
    newString: "paperMode: false",
    deskRoot: desk,
  });
  assert.equal(patch.ok, false);
  if (!patch.ok) assert.match(patch.reason, /read\/propose-only/);
  assert.equal(fs.readFileSync(abs, "utf8"), orig);
});

test("grep / list_dir work; write_file refuses non-source", () => {
  const desk = tmpDesk();
  const rel = "apps/api-server/src/lib/helper.ts";
  fs.mkdirSync(path.join(desk, "apps/api-server/src/lib"), { recursive: true });
  fs.writeFileSync(path.join(desk, rel), "export const helperSize = (n: number) => n;\n", "utf8");
  const g = runChatCodeTool("grep", { pattern: "helperSize", path: "apps/api-server/src" }, { userMessage: "search", deskRoot: desk });
  assert.equal(g.ok, true, !g.ok ? g.reason : "");
  if (g.ok) assert.match(String((g as { summary?: string }).summary), /match/i);
  const listed = runChatCodeTool("list_dir", { path: "apps/api-server/src/lib" }, { userMessage: "ls", deskRoot: desk });
  assert.equal(listed.ok, true, !listed.ok ? listed.reason : "");
  const py = writeDeskFile({
    relPath: "research/hack.py",
    content: "print(1)\n",
    userMessage: "write py",
    deskRoot: desk,
  });
  assert.equal(py.ok, false);
});

test("run_tests never spawns even for a valid local fixture path", () => {
  const desk = tmpDesk();
  fs.writeFileSync(path.join(desk, ".env"), "x=1\n", "utf8");
  const envt = runChatCodeTool("run_tests", { path: ".env" }, { userMessage: "test env", deskRoot: desk });
  assert.equal(envt.ok, false);
  const bot = normalizeApiServerTestPath("apps/api-server/src/lib/trading-bot.ts");
  assert.equal(bot.ok, false);
  const shell = runChatCodeTool("run_shell", { command: "rm -rf /" }, { userMessage: "no", deskRoot: desk });
  assert.equal(shell.ok, false);

  const rel = "apps/api-server/src/lib/helper.test.ts";
  const abs = path.join(desk, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, "import { test } from 'node:test';\ntest('ok', () => {});\n", "utf8");
  let spawned = false;
  const ok = runChatCodeTool(
    "run_tests",
    { path: rel },
    {
      userMessage: "run helper tests",
      deskRoot: desk,
      spawn: (cmd, args, options) => {
        spawned = true;
        assert.equal(cmd, process.execPath);
        assert.ok(args.includes("./isolate-strategy-learning-test.mjs"));
        assert.ok(args.includes("--test"));
        assert.ok(String(args[args.length - 1]).endsWith("helper.test.ts"));
        assert.equal(options.env?.BOT_CONFIG_PATH, "/tmp/api-server-test-bot-config.json");
        assert.equal(options.env?.PAPER_LEDGER_PATH, "/tmp/api-server-test-paper-ledger.json");
        return { status: 0, stdout: "ok", stderr: "", pid: 1, output: [], signal: null, error: undefined } as never;
      },
    },
  );
  assert.equal(ok.ok, false);
  assert.equal(spawned, false);
});

test("get_paper_ledger / get_bot_config / tail_tape work; run_shell and force_exit refused", () => {
  // Hermetic: the real data/paper-ledger.json is runtime state (gitignored).
  const desk = tmpDesk();
  fs.mkdirSync(path.join(desk, "apps/api-server/data"), { recursive: true });
  fs.writeFileSync(path.join(desk, "apps/api-server/data/paper-ledger.json"), JSON.stringify({ virtualCents: 30000 }), "utf8");
  const ledger = runChatCodeTool("get_paper_ledger", {}, { userMessage: "status", deskRoot: desk });
  assert.equal(ledger.ok, true, !ledger.ok ? ledger.reason : "");
  const cfg = runChatCodeTool("get_bot_config", {}, { userMessage: "status" });
  assert.equal(cfg.ok, true);
  const tape = runChatCodeTool("tail_tape", { n: 5 }, { userMessage: "status" });
  assert.equal(tape.ok, true);
  const sh = runChatCodeTool("run_shell", { cmd: "ls" }, { userMessage: "status" });
  assert.equal(sh.ok, false);
  const fx = runChatCodeTool("force_exit_trade", {}, { userMessage: "status" });
  assert.equal(fx.ok, false);
});

test("get_bot_config reads the volume config (data/.bot-config.json) when present (PR #11 path move)", () => {
  const desk = tmpDesk();
  fs.mkdirSync(path.join(desk, "apps/api-server/data"), { recursive: true });
  fs.writeFileSync(path.join(desk, "apps/api-server/.bot-config.json"), JSON.stringify({ paperMode: true, marker: "legacy" }), "utf8");
  fs.writeFileSync(path.join(desk, "apps/api-server/data/.bot-config.json"), JSON.stringify({ paperMode: true, marker: "volume" }), "utf8");
  const cfg = runChatCodeTool("get_bot_config", {}, { userMessage: "status", deskRoot: desk });
  assert.equal(cfg.ok, true, !cfg.ok ? cfg.reason : "");
  assert.equal((cfg as { path?: string }).path, "apps/api-server/data/.bot-config.json");
  assert.equal(((cfg as { json?: { marker?: string } }).json)?.marker, "volume");
});
