/**
 * scalp-paper-fill.test.ts — ACTION NOW paper scalp book.
 *
 * settlement bot (trading-bot.ts) is NOT imported.
 * promoteEnabled stays false.
 * both-sides rejected.
 * 9% cap per 15m bar.
 * still-ticket skip; unknown velocity accepted and tagged.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { kalshiFeeCents } from "../constants.js";
import { HARD_RISK_LIMITS } from "../admission.js";
import {
  createScalpPaperBook,
  DEFAULT_BANKROLL_CENTS,
  PAPER_SCALP_KIND,
} from "./scalp-paper-fill.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const TICKER = "KXBTC15M-26AUG272000-00";

function tmpBook(bankrollCents = DEFAULT_BANKROLL_CENTS) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "scalp-paper-"));
  const debriefsPath = path.join(dir, "trade-debriefs.jsonl");
  const fillsPath = path.join(dir, "scalp-fills.jsonl");
  const book = createScalpPaperBook({ debriefsPath, fillsPath, bankrollCents });
  return { dir, debriefsPath, fillsPath, book };
}

function cost(ask: number): number {
  return 1 * ask + Math.round(1 * kalshiFeeCents(ask));
}

test("locks: paper true, liveApply false, promoteEnabled false, settlement bot unused", () => {
  const src = fs.readFileSync(path.join(HERE, "scalp-paper-fill.ts"), "utf8");
  assert.equal(/from ["'].*trading-bot/.test(src), false, "must not import trading-bot");
  assert.equal(/tradingBot\.placeOrder|import\s*\{[^}]*placeOrder/.test(src), false, "must not call placeOrder");
  assert.equal(/require\(["'].*trading-bot/.test(src), false);
  assert.match(src, /NEVER ENABLE_STRATEGY/);
  assert.match(src, /NEVER CHANGE_EV_FLOOR/);
  const { book } = tmpBook();
  const r = book.paperFill({ ticker: TICKER, side: "yes", askCents: 40, reason: "test" });
  assert.equal(r.ok, true);
  if (r.ok) {
    assert.equal(r.paper, true);
    assert.equal(r.liveApply, false);
    assert.equal(r.promoteEnabled, false);
    assert.equal(r.book, "scalp");
  }
});

test("still velocity is skipped; unknown is accepted and tagged", () => {
  const { book } = tmpBook();
  const still = book.paperFill({ ticker: TICKER, side: "yes", askCents: 40, velocity: "still", reason: "x" });
  assert.equal(still.ok, false);
  if (!still.ok) assert.equal(still.skip, "still-ticket");
  assert.equal(still.paper, true);
  assert.equal(still.liveApply, false);
  assert.equal(still.promoteEnabled, false);

  const unknown = book.paperFill({ ticker: TICKER, side: "yes", askCents: 40, reason: "x" });
  assert.equal(unknown.ok, true);
  if (unknown.ok) {
    assert.equal(unknown.velocity, "unknown");
    assert.equal(unknown.book, "scalp");
    assert.equal(unknown.paper, true);
    assert.equal(unknown.liveApply, false);
  }
});

test("both sides open on the same 15m bar are rejected", () => {
  const { book } = tmpBook();
  const yes = book.paperFill({ ticker: TICKER, side: "yes", askCents: 30, velocity: "moving", reason: "yes" });
  assert.equal(yes.ok, true);
  const no = book.paperFill({ ticker: TICKER, side: "no", askCents: 30, velocity: "moving", reason: "no" });
  assert.equal(no.ok, false);
  if (!no.ok) assert.equal(no.skip, "both-sides-open");
  assert.equal(no.paper, true);
  assert.equal(no.liveApply, false);
  assert.equal(no.promoteEnabled, false);
});

test("9% budget per 15m bar is spent at entry and then caps", () => {
  const bankroll = 1_000; // $10 → 9% = 90c
  const { book, fillsPath, debriefsPath } = tmpBook(bankroll);
  const budget = Math.floor(bankroll * HARD_RISK_LIMITS.maxRiskPctPerTrade);
  assert.equal(budget, 90);
  const ask = 50;
  const c = cost(ask);
  assert.ok(c > 50, "fee-net cost exceeds bare ask");
  assert.ok(c <= budget, "first size-1 fill must fit");

  const first = book.paperFill({ ticker: TICKER, side: "yes", askCents: ask, velocity: "moving", reason: "1" });
  assert.equal(first.ok, true);
  if (first.ok) {
    assert.equal(first.costCents, c);
    assert.equal(first.spentBudgetCents, c);
    assert.equal(first.barBudgetCents, budget);
    assert.equal(first.contracts, 1);
  }

  const second = book.paperFill({ ticker: TICKER, side: "yes", askCents: ask, velocity: "moving", reason: "2" });
  assert.equal(second.ok, false);
  if (!second.ok) assert.equal(second.skip, "9pct-bar-budget");
  assert.equal(second.promoteEnabled, false);

  const fills = fs.readFileSync(fillsPath, "utf8").trim().split("\n");
  assert.equal(fills.length, 1);
  const debriefs = fs.readFileSync(debriefsPath, "utf8").trim().split("\n");
  assert.equal(debriefs.length, 1);
  const row = JSON.parse(debriefs[0]) as { kind: string; paper: boolean; liveApply: boolean };
  assert.equal(row.kind, PAPER_SCALP_KIND);
  assert.equal(row.paper, true);
  assert.equal(row.liveApply, false);
});

test("writes paper_scalp debrief + scalp-fills.jsonl; promoteEnabled never true", () => {
  const { book, debriefsPath, fillsPath } = tmpBook();
  const r = book.paperFill({
    ticker: TICKER,
    side: "NO",
    askCents: 22,
    reason: "ACTION NOW",
    ticketVelocity: { state: "moving" },
  });
  assert.equal(r.ok, true);
  if (r.ok) {
    assert.equal(r.side, "no");
    assert.equal(r.velocity, "moving");
    assert.equal(r.promoteEnabled, false);
    assert.equal(r.promoteEnabled, false);
  }
  const debrief = JSON.parse(fs.readFileSync(debriefsPath, "utf8").trim()) as Record<string, unknown>;
  const fill = JSON.parse(fs.readFileSync(fillsPath, "utf8").trim()) as Record<string, unknown>;
  assert.equal(debrief.kind, "paper_scalp");
  assert.equal(debrief.paper, true);
  assert.equal(debrief.liveApply, false);
  assert.equal(fill.book, "scalp");
  assert.equal(fill.promoteEnabled, false);
  assert.deepEqual(debrief.never, ["ENABLE_STRATEGY", "CHANGE_EV_FLOOR"]);
});
