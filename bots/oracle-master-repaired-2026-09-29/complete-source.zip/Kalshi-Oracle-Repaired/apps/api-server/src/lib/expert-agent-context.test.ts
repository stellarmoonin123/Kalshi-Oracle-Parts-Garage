import assert from "node:assert/strict";
import test from "node:test";
import { buildPrompt, deriveAgentContext } from "./expert-agent.js";
import type { MTFSummary } from "./mtf-analyzer.js";
import type { BotStatus } from "./trading-bot.js";

test("deriveAgentContext publishes snapshot-backed ARIA reasoning labels", () => {
  const context = deriveAgentContext({
    secsRemaining: 300,
    currentStreak: 4,
    currentVelocity: 80,
    threeMinVelocity: 45,
  });

  assert.equal(context.volBudget, 0.17);
  assert.equal(context.streakRisk, "ELEVATED");
  assert.equal(context.accelSignal, "ACCELERATING");
});

test("deriveAgentContext handles unknown momentum without inventing direction", () => {
  const context = deriveAgentContext({
    secsRemaining: 0,
    currentStreak: 1,
    currentVelocity: undefined,
    threeMinVelocity: undefined,
  });

  assert.equal(context.volBudget, null);
  assert.equal(context.streakRisk, "LOW");
  assert.equal(context.accelSignal, "UNKNOWN");
});

test("buildPrompt preserves the complete ARIA market context contract", () => {
  const h1: NonNullable<MTFSummary["h1"]> = {
    tf: "1h",
    price: 99_700,
    emaFast: 99_500,
    emaSlow: 99_200,
    rsi14: 68,
    atr14: 125,
    score: 2,
    bias: "strong_bull",
    pctFromEmaSlow: 0.5,
    trend: "accelerating",
  };
  const mtf: MTFSummary = {
    score: 4,
    bias: "strong_bull",
    alignedWith: "LONG",
    stronglyAligned: true,
    m1: null,
    m5: null,
    m15: null,
    h1,
    h4: null,
    atr1h: 125,
    updatedAt: Date.now(),
    dynamicStopCents: 8,
    dynamicProfitCents: 12,
    usedStaleFastCache: false,
    staleFastLegs: [],
    staleFastAgeMs: 0,
  };
  const statusFields = {
    floorStrike: 99_500,
    mtfBias: mtf,
    adaptiveCondition: {
      condition: "strong_uptrend",
      label: "Strong Uptrend",
      emoji: "🚀",
      overlay: {
        minConfidence: 55,
        minVelocity: 20,
        maxContractsPerTrade: 3,
        stopLossCents: 15,
        profitTakeCents: 20,
        tradeWindowMinMin: 2,
        tradeWindowMaxMin: 12,
        minProbEdge: 8,
        suppressStrategies: [],
        boostStrategy: null,
        rationale: "fixture",
        expectedWinRate: 0.6,
      },
      signals: ["higher-timeframe trend"],
      chaosMode: false,
    },
    drawdownFromPeakPct: 2.5,
    openTradePnlCents: 0,
    openTrade: null,
    currentBtcPrice: 100_000,
    distFromFloorPct: 0.5,
    aboveFloor: true,
    currentVelocity: -120,
    threeMinVelocity: -80,
    isStalling: false,
    secsRemaining: 420,
    currentStreak: 1,
    consecutiveLosses: 0,
    todayWins: 0,
    todayLosses: 0,
    todayPnlCents: 0,
    config: {} as BotStatus["config"],
  } satisfies Partial<BotStatus>;
  const prompt = buildPrompt(statusFields as unknown as BotStatus, [], []);

  assert.match(prompt, /Floor strike:\s+\$99500/);
  assert.match(prompt, /1H bias:\s+strong_bull/);
  assert.match(prompt, /Condition:\s+Strong Uptrend/);
  assert.match(prompt, /Accel signal:\s+ACCELERATING \(1m speed 120 vs 3m avg 80 \$\/min\)/);
  assert.match(prompt, /Drawdown:\s+2\.5% from peak/);
  assert.doesNotMatch(prompt, /Floor strike:.*\?/);
  assert.doesNotMatch(prompt, /1H bias:\s+\?/);
  assert.doesNotMatch(prompt, /\[object Object\]/);
});
