import test from "node:test";
import assert from "node:assert/strict";
import {
  KALSHI_EXPECTED_SLIPPAGE_CENTS,
  observedSlippageFloorCents,
} from "./constants.js";
import { computeTradeEV } from "./trade-path.js";
import { TradingBot, tradingBot } from "./trading-bot.js";

// Importing trading-bot creates the application singleton. Keep it stopped so
// this unit test only exercises the execution-quality accumulator.
tradingBot.stop();

test("fill quality needs 10 fills and must be strictly worse than +2.5¢", () => {
  assert.equal(observedSlippageFloorCents({
    slippageSamples: 9,
    averageSlippageCents: 4,
  }), null);
  assert.equal(observedSlippageFloorCents({
    slippageSamples: 10,
    averageSlippageCents: 2.5,
  }), null);
  assert.equal(observedSlippageFloorCents({
    slippageSamples: 10,
    averageSlippageCents: 2.6,
  }), 2.6);
});

test("observed execution cost only makes the EV model more conservative", () => {
  const normal = computeTradeEV({
    entryPriceCents: 50,
    winRate: 0.6,
    secsRemaining: 600,
    velocityDolPerMin: 0,
  });
  const tightened = computeTradeEV({
    entryPriceCents: 50,
    winRate: 0.6,
    secsRemaining: 600,
    velocityDolPerMin: 0,
    observedSlippageCents: 3,
  });

  assert.equal(normal.slippageCents, KALSHI_EXPECTED_SLIPPAGE_CENTS);
  assert.equal(tightened.slippageCents, 3);
  assert.equal(tightened.netEV, normal.netEV - (3 - KALSHI_EXPECTED_SLIPPAGE_CENTS));
});

test("session fill summary exposes best/worst fills and activates tightening above threshold", () => {
  const bot = new TradingBot();
  bot.stop();
  const internal = bot as unknown as {
    persistSessionFillDelta: () => void;
    recordSessionOrderFilled: (strategyId: string, slippage: number) => void;
  };
  // Keep the test isolated from the daily execution ledger; those writes are
  // covered by daily-fill-stats tests and are not part of aggregation logic.
  internal.persistSessionFillDelta = () => {};

  // Average = +2.6¢ over ten price-confirmed live fills; best=-1, worst=+3.
  for (const slippage of [-1, ...Array(9).fill(3)]) {
    internal.recordSessionOrderFilled("FILL_QUALITY_TEST", slippage);
  }

  const summary = bot.getStatus().sessionFillStats;
  assert.equal(summary.slippageSamples, 10);
  assert.equal(summary.avgSlippageCents, 2.6);
  assert.equal(summary.bestSlippageCents, -1);
  assert.equal(summary.worstSlippageCents, 3);
  assert.equal(summary.evTighteningActive, true);
  assert.equal(summary.modeledSlippageCents, 2.6);
  bot.stop();
});