/**
 * hard-no-fill — HARD_NO_FILL / LOCKED denylist (money-path).
 * Never ENABLE leftovers. Fail-closed for OTM_* prefix + LATE_ENTRY.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  HARD_NO_FILL_STRATEGY_IDS,
  LOCKED_DISABLED_STRATEGIES,
  LEFTOVER_PLACEORDER_DENYLIST,
  isHardNoFillStrategy,
} from "./hard-no-fill.js";

test("hard-no-fill: LOCKED + HARD_NO_FILL ids always deny; money-makers allowed", () => {
  assert.ok(LOCKED_DISABLED_STRATEGIES.includes("DEEP_OTM_SNIPER"));
  assert.ok(LOCKED_DISABLED_STRATEGIES.includes("OTM_ASYMMETRY"));
  assert.ok(HARD_NO_FILL_STRATEGY_IDS.includes("PAPER_SCALP"));
  assert.ok(HARD_NO_FILL_STRATEGY_IDS.includes("CHEAP_EARLY_EXIT"));
  assert.equal(isHardNoFillStrategy("CHEAP_SIDE_15M"), false);
  assert.ok(HARD_NO_FILL_STRATEGY_IDS.includes("SETTLEMENT_PREDICTION"));
  for (const id of HARD_NO_FILL_STRATEGY_IDS) {
    assert.equal(isHardNoFillStrategy(id), true, id);
  }
  assert.equal(isHardNoFillStrategy("CONFLUENCE_CASCADE"), false);
  assert.equal(isHardNoFillStrategy("BASIS_LAG_EDGE"), false);
  assert.equal(isHardNoFillStrategy(null), false);
  assert.equal(isHardNoFillStrategy(undefined), false);
});

test("hard-no-fill: OTM_* prefix + LATE_ENTRY always deny (prefix lock)", () => {
  assert.equal(isHardNoFillStrategy("OTM_ANYTHING_NEW"), true);
  assert.equal(isHardNoFillStrategy("LATE_ENTRY"), true);
  assert.equal(LEFTOVER_PLACEORDER_DENYLIST, HARD_NO_FILL_STRATEGY_IDS);
});

test("hard-no-fill: source never ENABLE leftovers / never paperMode false", async () => {
  const fs = await import("node:fs/promises");
  const path = await import("node:path");
  const { fileURLToPath } = await import("node:url");
  const here = path.dirname(fileURLToPath(import.meta.url));
  const src = await fs.readFile(path.join(here, "hard-no-fill.ts"), "utf8");
  assert.equal(/\bENABLE_(?:SEV1|OTM|ARIA|HOURLY|PERPS|LEFTOVER)\b/.test(src), false);
  assert.equal(/paperMode\s*[:=]\s*false\b/.test(src), false);
});

test("hard-no-fill: trading-bot binds isHardNoFillStrategy locally (not export-only)", async () => {
  const fs = await import("node:fs/promises");
  const path = await import("node:path");
  const { fileURLToPath } = await import("node:url");
  const here = path.dirname(fileURLToPath(import.meta.url));
  const bot = await fs.readFile(path.join(here, "trading-bot.ts"), "utf8");
  // export { X } from "mod" does NOT bind X in local scope — placeOrder would throw.
  assert.match(
    bot,
    /import\s*\{[^}]*\bisHardNoFillStrategy\b[^}]*\}\s*from\s*"\.\/hard-no-fill\.js"/,
  );
  assert.equal(
    /export\s*\{[^}]*\bisHardNoFillStrategy\b[^}]*\}\s*from\s*"\.\/hard-no-fill\.js"/.test(bot),
    false,
    "must not be export-from-only (ReferenceError at placeOrder)",
  );
  assert.match(bot, /if\s*\(\s*isHardNoFillStrategy\s*\(\s*params\.strategyId\s*\)\s*\)/);
});
