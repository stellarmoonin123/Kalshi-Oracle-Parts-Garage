import assert from "node:assert/strict";
import test from "node:test";
import { normalizeOrderbookLevels } from "./kalshi-ws.js";

test("empty-string order-book levels are discarded instead of becoming invalid integer fields", () => {
  const yesLevels = normalizeOrderbookLevels([
    ["", "4"],
    [42, 7],
  ]);

  assert.deepEqual(yesLevels, [[42, 7]]);
  assert.equal(yesLevels[0]?.[0], 42);
});

test("a missing side normalizes to an empty array so its top-of-book can be stored as null", () => {
  const yesLevels = normalizeOrderbookLevels([[42, 7]]);
  const noLevels = normalizeOrderbookLevels([["", ""]]);

  const bestYesBid = yesLevels[0]?.[0] ?? null;
  const bestYesAsk = noLevels[0]?.[0] ?? null;

  assert.equal(bestYesBid, 42);
  assert.equal(bestYesAsk, null);
});

test("fixed-point dollar strings are converted to cent-priced levels", () => {
  assert.deepEqual(
    normalizeOrderbookLevels([["0.4200", "7.5"]], true),
    [[42, 7.5]],
  );
});