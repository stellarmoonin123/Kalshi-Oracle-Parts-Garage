import { test } from "node:test";
import assert from "node:assert/strict";
import { kxbtc15mTickerForCloseMs, nextKxbtc15mTicker, adoptableNextMarket, shouldRetryRolloverSoon } from "./kalshi-ws.js";

test("D10: next ticker from close_time (ET, EDT and EST, midnight)", () => {
  assert.equal(nextKxbtc15mTicker("2026-09-25T05:15:00Z"), "KXBTC15M-26SEP250130-30");
  assert.equal(nextKxbtc15mTicker("2026-09-25T05:30:00Z"), "KXBTC15M-26SEP250145-45");
  assert.equal(nextKxbtc15mTicker("2026-09-25T03:45:00Z"), "KXBTC15M-26SEP250000-00"); // 23:45 ET → 00:00 ET next day
  assert.equal(kxbtc15mTickerForCloseMs(Date.parse("2026-12-01T15:30:00Z")), "KXBTC15M-26DEC011030-30"); // EST
  assert.equal(nextKxbtc15mTicker("garbage"), null);
});

test("D10: only adopt an active, struck, future-closing next market", () => {
  const now = Date.parse("2026-09-25T05:15:02Z");
  const t = "KXBTC15M-26SEP250130-30";
  const base = { ticker: t, status: "active", floor_strike: 84182.75, close_time: "2026-09-25T05:30:00Z" };
  assert.deepEqual(adoptableNextMarket(base, t, now), { ticker: t, floorStrike: 84182.75, closeTime: base.close_time });
  assert.equal(adoptableNextMarket({ ...base, status: "initialized" }, t, now), null);
  assert.equal(adoptableNextMarket({ ...base, floor_strike: null }, t, now), null);
  assert.equal(adoptableNextMarket({ ...base, ticker: "KXBTC15M-26SEP250145-45" }, t, now), null);
  assert.equal(adoptableNextMarket({ ...base, close_time: "2026-09-25T05:15:00Z" }, t, now), null);
});

test("D10: retry cadence unchanged — still ~1 s after close while the next is not adoptable", () => {
  const now = Date.parse("2026-09-25T05:15:02Z");
  assert.equal(shouldRetryRolloverSoon(null, "KXBTC15M-26SEP250115-15", "2026-09-25T05:15:00Z", now), true);
});
