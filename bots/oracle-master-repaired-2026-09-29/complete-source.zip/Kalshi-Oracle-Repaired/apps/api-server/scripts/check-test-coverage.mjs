#!/usr/bin/env node
// Task #238: CI guard confirming no test file has been accidentally excluded
// from the suite. The `test` script runs a literal glob ('src/**/*.test.ts');
// this script independently re-derives which files SHOULD match that glob
// (via a plain recursive walk, no extra dependency) and cross-checks it
// against:
//   1. Any test-like file (*.test.*, *.spec.*) anywhere under this package
//      that the glob would NOT pick up (wrong extension, wrong directory,
//      e.g. accidentally placed outside src/, or named *.spec.ts).
//   2. Any file matched by the glob that tsconfig's `exclude` would hide
//      from the TypeScript project — a common way a file silently stops
//      being type-checked even though `tsx --test` might still run it.
//
// Exits non-zero with a clear message on any mismatch so CI fails loudly
// instead of a test file silently going dark.

import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const pkgRoot = join(__dirname, "..");

const IGNORED_DIRS = new Set(["node_modules", "dist", "build", ".git"]);
const TEST_LIKE_RE = /\.(test|spec)\.tsx?$/;
const RUNNABLE_TEST_RE = /\.test\.ts$/;
const EXPECTED_TEST_GLOB = "src/**/*.test.ts";

/** Recursively walk `dir`, returning paths (relative to pkgRoot) matching `re`, skipping ignored dirs. */
function walk(dir, re, out = []) {
  let entries;
  try {
    entries = readdirSync(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const entry of entries) {
    if (entry.isDirectory()) {
      if (IGNORED_DIRS.has(entry.name)) continue;
      walk(join(dir, entry.name), re, out);
    } else if (entry.isFile() && re.test(entry.name)) {
      out.push(relative(pkgRoot, join(dir, entry.name)));
    }
  }
  return out;
}

function main() {
  const errors = [];

  // 1. Keep this guard tied to the actual package command. Without this
  //    assertion, the independent file walk below could pass even after the
  //    test script silently reverted to an explicit file list.
  try {
    const packageJson = JSON.parse(readFileSync(join(pkgRoot, "package.json"), "utf-8"));
    const testScript = packageJson?.scripts?.test;
    if (typeof testScript !== "string" || !testScript.includes(EXPECTED_TEST_GLOB)) {
      errors.push(
        `The package "test" script must include the recursive '${EXPECTED_TEST_GLOB}' glob so new nested tests run automatically.`
      );
    }
  } catch (error) {
    errors.push(`Could not read package.json to verify the test discovery glob: ${error.message}`);
  }

  // 2. Files the real test glob ('src/**/*.test.ts') will run.
  const srcDir = join(pkgRoot, "src");
  const runnable = walk(srcDir, RUNNABLE_TEST_RE).sort();
  const runnableSet = new Set(runnable);

  // 3. Every test-like file anywhere in the package, regardless of
  //    extension or directory (e.g. *.spec.ts, or a *.test.ts sitting
  //    outside src/).
  const allTestLike = walk(pkgRoot, TEST_LIKE_RE).sort();

  for (const f of allTestLike) {
    if (!runnableSet.has(f)) {
      errors.push(
        `Test-like file NOT covered by the 'src/**/*.test.ts' glob: ${f}\n` +
        `    → Either move it under src/ with a .test.ts extension, or update the test script if this exclusion is intentional.`
      );
    }
  }

  // 4. Make sure tsconfig isn't quietly excluding any of the runnable test
  //    files from type-checking (a file can still execute via tsx but never
  //    get type-checked, hiding real breakage).
  const tsconfigPath = join(pkgRoot, "tsconfig.json");
  try {
    const tsconfigRaw = readFileSync(tsconfigPath, "utf-8");
    const tsconfig = JSON.parse(tsconfigRaw.replace(/\/\/.*$/gm, ""));
    const excludes = Array.isArray(tsconfig.exclude) ? tsconfig.exclude : [];
    for (const pattern of excludes) {
      // Only handle simple prefix/substring exclude patterns (this repo's
      // tsconfigs don't use full glob syntax in `exclude`); a matching test
      // file is flagged as silently un-typechecked.
      const needle = pattern.replace(/\*+/g, "");
      if (!needle) continue;
      for (const f of runnable) {
        if (f.includes(needle)) {
          errors.push(`Test file excluded from tsconfig type-checking by 'exclude: "${pattern}"': ${f}`);
        }
      }
    }
  } catch {
    // tsconfig.json missing or unparsable — not this script's concern.
  }

  if (runnable.length === 0) {
    errors.push(`No test files matched 'src/**/*.test.ts' at all — suite may be misconfigured.`);
  }

  if (errors.length > 0) {
    console.error(`\n❌ check-test-coverage found ${errors.length} issue(s):\n`);
    for (const e of errors) console.error(`  - ${e}\n`);
    process.exit(1);
  }

  console.log(`✅ check-test-coverage: ${runnable.length} test file(s) under 'src/**/*.test.ts', all covered.`);
}

main();
