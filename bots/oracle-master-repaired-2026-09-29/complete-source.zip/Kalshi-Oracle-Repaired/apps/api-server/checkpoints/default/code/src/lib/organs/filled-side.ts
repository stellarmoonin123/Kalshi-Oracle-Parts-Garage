/**
 * filled-side organ — single door for SIGN-SAFE filled-side quotes + p (Heavy B#3).
 *
 * Owns the documented YES-p-on-NO kill surface. Implementation stays in
 * sign-safe-no.ts. No new branches. No EXIT / W2 / STORY_STAMP rewrite.
 * No ENABLE. No ENTRY/EV/floor cuts. paperMode true. Bounce N.
 *
 * Single door (strict):
 *   1. bindSideWinRateAtPrice / pFilledSide — winRateAtPrice(side, ask)
 *      Side-bound; refuse YES quote as ask on a NO ticket (SEV0),
 *      including when noAsk is missing — guard must not be dead code.
 *   2. resolveFilledSideQuote / kellyEvAskForSide — filled-side ask/bid
 *      NO → noAsk/noBid; YES → yesAsk/yesBid.
 *   3. ticketGreenFilledSide — green = filled-side bid > fillAsk
 *      Never yesBid on a NO ticket.
 *
 * TradingBot imports bindSideWinRateAtPrice from this surface
 * (same semantics as prior organs/index → sign-safe-no path).
 */
import {
  resolveFilledSideQuote,
  ticketGreenFilledSide,
  kellyEvAskForSide,
  pFilledSide,
  bindSideWinRateAtPrice,
  formatSignSafeNoLoadedLog,
  SIGN_SAFE_NO_LOADED,
  SIGN_SAFE_NO_NOT_LOADED,
  type FilledSide,
  type ResolveFilledSideQuoteInput,
  type ResolveFilledSideQuoteResult,
} from "./sign-safe-no.js";

export const FILLED_SIDE_LOADED = true as const;
/** Durable falsify line when organ is missing from the live wire. */
export const FILLED_SIDE_NOT_LOADED = "[FILLED_SIDE] not loaded";

export function formatFilledSideLoadedLog(): string {
  return "[FILLED_SIDE] loaded";
}

export {
  resolveFilledSideQuote,
  ticketGreenFilledSide,
  kellyEvAskForSide,
  pFilledSide,
  bindSideWinRateAtPrice,
  formatSignSafeNoLoadedLog,
  SIGN_SAFE_NO_LOADED,
  SIGN_SAFE_NO_NOT_LOADED,
};
export type {
  FilledSide,
  ResolveFilledSideQuoteInput,
  ResolveFilledSideQuoteResult,
};
