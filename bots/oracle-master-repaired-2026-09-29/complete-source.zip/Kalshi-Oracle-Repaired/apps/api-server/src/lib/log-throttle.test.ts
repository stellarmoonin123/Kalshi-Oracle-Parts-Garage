import { test } from "node:test";
import assert from "node:assert/strict";
import { LogThrottle, throttleKey, EntryFunnelCounter, blockReasonBucket } from "./log-throttle.js";

test("D14: repeats inside the window are suppressed and counted on next emit", () => {
  const t = new LogThrottle(60_000);
  assert.equal(t.gate("k", "a", 0), "a");
  for (let i = 1; i <= 4; i++) assert.equal(t.gate("k", "a", i * 250), null);
  assert.equal(t.gate("k", "a", 61_000), "a (+4 suppressed in last 60s)");
  assert.equal(t.gate("other", "b", 61_001), "b");
});

test("D14: throttleKey collapses volatile numbers", () => {
  assert.equal(throttleKey("T1", "edge −18.11¢"), throttleKey("T1", "edge -17.9¢"));
  assert.notEqual(throttleKey("T1", "x"), throttleKey("T2", "x"));
});

test("D3: funnel counter buckets block reasons", () => {
  const c = new EntryFunnelCounter();
  c.bump("TAKE_SIGNAL"); c.bump("TAKE_SIGNAL");
  c.bump(blockReasonBucket("MIND_HEAVE_BIND", "edge_net -18.11¢ < min_edge 7¢"));
  c.bump(blockReasonBucket("MIND_HEAVE_BIND", "edge_net -2.5¢ < min_edge 7¢"));
  const s = c.snapshot().counts;
  assert.equal(s.TAKE_SIGNAL, 2);
  assert.equal(s["MIND_HEAVE_BIND:edge_net #¢ < min_edge #¢"], 2);
});
