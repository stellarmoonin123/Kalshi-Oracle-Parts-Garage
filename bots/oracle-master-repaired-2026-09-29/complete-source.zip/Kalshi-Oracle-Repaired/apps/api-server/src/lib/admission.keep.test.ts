/**
 * Isolate-rewrite-compare for admission organ vs PhD bar.
 * Winner = live admission.ts: p=winRateAtPrice only; fee-net EV; EV_FLOOR=3;
 * 87¢ inflated p fails; CC/LAG same floor; no confidence-as-p; no 0.65 missing-curve.
 * Kelly 0.60 uncut. Does not import trading-bot.ts. Does not ENABLE.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import test from "node:test";
import assert from "node:assert/strict";
import {
  EV_FLOOR,
  OTM_EV_FLOOR,
  HARD_RISK_LIMITS,
  evaluateEntryEVGate,
  pWinFromCurve,
  feeNetEVCents,
  kellyFraction,
} from "./admission.js";
import {
  pWinFromCurveIsolate,
  evaluateEntryEVGateIsolate,
  ISOLATE_MISSING_CURVE_P,
} from "./admission.isolate.js";
import { getStrategy } from "./strategy-library.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const ADM = readFileSync(path.join(DIR, "admission.ts"), "utf8");
const BOT = readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const PERSISTED = JSON.parse(
  readFileSync(path.resolve(DIR, "../../.bot-config.json"), "utf8"),
) as { paperMode: boolean };

test("locks: EV_FLOOR=3, Kelly 0.60, 9%, paperMode true, no ENABLE, bot not rewritten this organ", () => {
  assert.equal(EV_FLOOR, 3);
  assert.equal(OTM_EV_FLOOR, 5);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(kellyFraction(80, 8), 0.60);
  assert.equal(kellyFraction(99, 99), 0.60);
  assert.equal(PERSISTED.paperMode, true);
  assert.match(ADM, /export const EV_FLOOR\s*=\s*3/);
  assert.equal(ADM.includes("ENABLE_STRATEGY"), false);
  assert.equal(/\?\?\s*0\.65/.test(ADM), false, "live must not invent 0.65");
  assert.ok(BOT.includes('from "./admission.js"'));
});

test("keep winner vs isolate: 87¢ inflated p fails live, isolate can pass", () => {
  const rich = {
    entryPriceCents: 87,
    strategyWinRate: 0.62,
    calibratedWinRate: 0.97,
    strategyId: "LATE_ENTRY_ANCHOR",
    secsRemaining: 200,
    velocityDolPerMin: 0,
    spreadCents: 2,
  };
  const live = evaluateEntryEVGate(rich);
  const iso = evaluateEntryEVGateIsolate(rich);
  const honest = evaluateEntryEVGate({ ...rich, calibratedWinRate: undefined });
  assert.equal(live.passes, honest.passes);
  assert.equal(live.modelEstimatedProb, 0.62);
  assert.equal(live.passes, false, "an 87¢ ask at 62% WR must not pass EV_FLOOR via mass inflation");
  assert.equal(live.minEVCents, EV_FLOOR);
  assert.equal(iso.modelEstimatedProb, 0.97);
  assert.equal(iso.passes, true, "isolate hole: inflated p clears 3¢ at 87¢");
  assert.notEqual(live.passes, iso.passes, "winner refuses; isolate admits");
});

test("keep winner vs isolate: CC/LAG same EV_FLOOR=3 (fee-net p=winRateAtPrice)", () => {
  const cc = evaluateEntryEVGate({
    entryPriceCents: 49, strategyWinRate: 0.62, strategyId: "CONFLUENCE_CASCADE",
    secsRemaining: 300, velocityDolPerMin: 0, spreadCents: 2,
  });
  const lag = evaluateEntryEVGate({
    entryPriceCents: 49, strategyWinRate: 0.62, strategyId: "BASIS_LAG_EDGE",
    secsRemaining: 300, velocityDolPerMin: 0, spreadCents: 2,
  });
  const isoCc = evaluateEntryEVGateIsolate({
    entryPriceCents: 49, strategyWinRate: 0.62, strategyId: "CONFLUENCE_CASCADE",
    secsRemaining: 300, velocityDolPerMin: 0, spreadCents: 2,
  });
  const isoLag = evaluateEntryEVGateIsolate({
    entryPriceCents: 49, strategyWinRate: 0.62, strategyId: "BASIS_LAG_EDGE",
    secsRemaining: 300, velocityDolPerMin: 0, spreadCents: 2,
  });
  assert.equal(cc.minEVCents, EV_FLOOR);
  assert.equal(lag.minEVCents, EV_FLOOR);
  assert.equal(cc.minEVCents, lag.minEVCents);
  assert.equal(isoCc.minEVCents, isoLag.minEVCents);
  assert.equal(isoCc.minEVCents, EV_FLOOR);
  assert.equal(cc.modelEstimatedProb, 0.62);
  assert.equal(lag.modelEstimatedProb, 0.62);
  const evCc = feeNetEVCents({ entryPriceCents: 49, pWin: 0.62, strategyId: "CONFLUENCE_CASCADE", secsRemaining: 300 });
  const evLag = feeNetEVCents({ entryPriceCents: 49, pWin: 0.62, strategyId: "BASIS_LAG_EDGE", secsRemaining: 300 });
  assert.equal(evCc, cc.netEV);
  assert.equal(evLag, lag.netEV);
});

test("keep winner vs isolate: missing curve is null (not 0.65); confidence is not p", () => {
  const iso = pWinFromCurveIsolate(undefined, 49, 5, {
    expectedWinRate: 0.75, confidence: 90, calibratedWinRate: 0.97,
  });
  const live = pWinFromCurve(undefined, 49, 5, {
    expectedWinRate: 0.75, confidence: 90, calibratedWinRate: 0.97,
  });
  assert.equal(ISOLATE_MISSING_CURVE_P, 0.65);
  assert.equal(iso, 0.97, "isolate prefers inflated calibratedWR / else 0.65");
  assert.equal(live, null, "winner skip — never invent 0.65 or copy confidence");
  const isoMissing = pWinFromCurveIsolate(undefined, 40, 8);
  assert.equal(isoMissing, 0.65);
  assert.equal(pWinFromCurve(undefined, 40, 8), null);
});

test("keep winner: real CC/LAG curves are p, not 0.65 sentinel, not confidence", () => {
  const ccCurve = getStrategy("CONFLUENCE_CASCADE")!.winRateAtPrice;
  const lagCurve = getStrategy("BASIS_LAG_EDGE")!.winRateAtPrice;
  const cc = pWinFromCurve(ccCurve, 49, 5);
  const lag = pWinFromCurve(lagCurve, 40, 8);
  assert.ok(cc != null && cc > 0 && cc <= 1);
  assert.ok(lag != null && lag > 0 && lag <= 1);
  assert.equal(pWinFromCurve(ccCurve, 49, 5), pWinFromCurveIsolate(ccCurve, 49, 5));
  assert.equal(pWinFromCurve(lagCurve, 40, 8), pWinFromCurveIsolate(lagCurve, 40, 8));
  const src = ADM;
  assert.equal(/modelEstimatedProb\s*=\s*opts\.calibratedWinRate/.test(src), false);
  assert.equal(/confidence\s*=\s*pWin/.test(src), false);
});
