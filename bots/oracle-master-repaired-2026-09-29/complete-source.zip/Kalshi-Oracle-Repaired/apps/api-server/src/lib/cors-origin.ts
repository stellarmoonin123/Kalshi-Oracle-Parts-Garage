/**
 * CORS origin allowlist helper.
 *
 * Exact match against env / FLY_APP_NAME allowlist, plus:
 *   - http(s)://localhost and 127.0.0.1 with any port (Vite)
 *   - https://*.trycloudflare.com (quick tunnels rotate names)
 *
 * Deny by returning false. Callers MUST use `callback(null, false)` — never
 * `callback(new Error(...))`, which express-cors turns into HTTP 500.
 */
const LOCAL_DEV = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i;

function isTrycloudflareOrigin(origin: string): boolean {
  try {
    const u = new URL(origin);
    if (u.protocol !== "https:") return false;
    const host = u.hostname.toLowerCase();
    return host === "trycloudflare.com" || host.endsWith(".trycloudflare.com");
  } catch {
    return false;
  }
}

export function isAllowedOrigin(
  origin: string | undefined,
  allowedOrigins: ReadonlySet<string>,
): boolean {
  if (!origin) return true;
  if (allowedOrigins.has(origin)) return true;
  if (LOCAL_DEV.test(origin)) return true;
  if (isTrycloudflareOrigin(origin)) return true;
  return false;
}
