/**
 * #384 / #385 — 15m contract rollover in seconds, not 60s.
 * Pure helpers + order-book identity. Does not start a live socket.
 */
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import test from "node:test";
import {
  kalshiWS,
  orderbookMatchesActiveTicker,
  rolloverCheckDelayMs,
  shouldRetryRolloverSoon,
  ROLLOVER_CLOSE_BUFFER_MS,
  ROLLOVER_INTERVAL_MS,
  ROLLOVER_MIN_DELAY_MS,
  ROLLOVER_RETRY_MS,
} from "./kalshi-ws.js";

test("#384 rolloverCheckDelayMs is seconds after close, never 60s", () => {
  const close = "2026-08-28T03:15:00.000Z";
  const closeMs = Date.parse(close);
  assert.equal(rolloverCheckDelayMs("", closeMs), null);
  assert.equal(rolloverCheckDelayMs("not-a-date", closeMs), null);

  const wellBefore = rolloverCheckDelayMs(close, closeMs - 5 * 60_000);
  assert.ok(wellBefore != null && wellBefore > 60_000);

  const atClose = rolloverCheckDelayMs(close, closeMs);
  assert.equal(atClose, ROLLOVER_CLOSE_BUFFER_MS);
  assert.ok(atClose! < ROLLOVER_INTERVAL_MS);

  const afterClose = rolloverCheckDelayMs(close, closeMs + 10_000);
  assert.equal(afterClose, ROLLOVER_MIN_DELAY_MS);
  assert.ok(afterClose! < 2_000);
  assert.equal(ROLLOVER_RETRY_MS, 1_000);
  assert.equal(ROLLOVER_INTERVAL_MS, 60_000);
});

test("#384 shouldRetryRolloverSoon when next 15m is not listed yet", () => {
  const close = "2026-08-28T03:15:00.000Z";
  const closeMs = Date.parse(close);
  const ticker = "KXBTC15M-OLD";
  assert.equal(shouldRetryRolloverSoon(null, ticker, close, closeMs + 2_000), true);
  assert.equal(shouldRetryRolloverSoon({ ticker }, ticker, close, closeMs + 2_000), true);
  assert.equal(shouldRetryRolloverSoon({ ticker: "KXBTC15M-NEW" }, ticker, close, closeMs + 2_000), false);
  assert.equal(shouldRetryRolloverSoon(null, ticker, close, closeMs - 60_000), false);
});

test("#385 orderbookMatchesActiveTicker never serves the previous book", () => {
  assert.equal(orderbookMatchesActiveTicker(null, "KXBTC15M-NEW"), false);
  assert.equal(orderbookMatchesActiveTicker({ ticker: "KXBTC15M-OLD" }, "KXBTC15M-NEW"), false);
  assert.equal(orderbookMatchesActiveTicker({ ticker: "KXBTC15M-NEW" }, "KXBTC15M-NEW"), true);
  assert.equal(orderbookMatchesActiveTicker({ ticker: "" }, "KXBTC15M-NEW"), false);
});

test("#385 getLatestOrderbook returns null when stored book ticker mismatches active", () => {
  type WsInternals = {
    active: { ticker: string; floorStrike: number; closeTime: string };
    _latestOrderbook: { ticker: string; yesBids: [number, number][]; yesAsks: [number, number][]; ts: number } | null;
  };
  const internals = kalshiWS as unknown as WsInternals;
  const origActive = internals.active;
  const origBook = internals._latestOrderbook;
  try {
    internals.active = {
      ticker: "KXBTC15M-NEW",
      floorStrike: 65_000,
      closeTime: new Date(Date.now() + 10 * 60_000).toISOString(),
    };
    internals._latestOrderbook = {
      ticker: "KXBTC15M-OLD",
      yesBids: [[40, 5]],
      yesAsks: [[42, 5]],
      ts: Date.now(),
    };
    assert.equal(kalshiWS.getLatestOrderbook(), null);

    internals._latestOrderbook = {
      ticker: "KXBTC15M-NEW",
      yesBids: [[41, 3]],
      yesAsks: [[43, 4]],
      ts: Date.now(),
    };
    const matched = kalshiWS.getLatestOrderbook();
    assert.ok(matched);
    assert.equal(matched!.ticker, "KXBTC15M-NEW");
  } finally {
    internals.active = origActive;
    internals._latestOrderbook = origBook;
  }
});

test("WS timers void async work; refreshMarket swallows rejections", () => {
  const ws = readFileSync(fileURLToPath(new URL("./kalshi-ws.ts", import.meta.url)), "utf8");
  assert.ok(ws.includes("void this.refreshMarket()"));
  assert.ok(ws.includes("void this.captureL2Snapshot()"));
  assert.ok(ws.includes("void this.fetchMarketTrades()"));
  assert.ok(ws.includes('[kalshi-ws] refreshMarket:'));
  assert.equal(ws.includes("setInterval(() => this.refreshMarket()"), false);
});
