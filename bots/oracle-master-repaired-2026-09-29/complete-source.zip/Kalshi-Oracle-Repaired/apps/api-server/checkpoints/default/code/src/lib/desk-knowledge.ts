/**
 * desk-knowledge.ts: dated standing knowledge for the desk chat / Brain Center.
 *
 * Maintained by hand after each release batch. Ships inside the image (docs/
 * is dockerignored), so the chat can read it on Fly. The chat must PREFER LIVE
 * TOOL DATA (get_status, get_healthz, get_recent_trades, ...) over anything
 * here; this note is historical context, not current state.
 *
 * To update: bump DESK_KNOWLEDGE_AS_OF, edit sections, keep the summary short
 * (it rides in the system prompt, whose budget is ~3.8k tokens).
 */

export const DESK_KNOWLEDGE_AS_OF = "2026-09-26 4:00 AM ET";

/** Short block injected into every desk-agent system prompt (keep < ~700 chars). */
export const DESK_KNOWLEDGE_SUMMARY = [
  `Standing knowledge as of ${DESK_KNOWLEDGE_AS_OF} (historical; live tools win if they disagree):`,
  "Sep 25 releases: PR #7 charts, #9 trade card/chat/charts polish, #10 committed 'default' checkpoint (hash in /api/healthz build.defaultCheckpoint), #11 settlement audit (phantom post-close exits blocked, idempotent settle, restart tape check, reserve persisted, config on volume; Fly v33), #12 config readers on the volume path (Fly v34). Sep 26: PR #13 paper daily loss halt back ON (same cap as live); PR #14 frozen-CC lockSide PASS required, EV/band re-checked at paper fill, bootstrap calibration gate; PR #16 Fly VM 1.5 GB + ~1 GB heap + swap; PR #17 OV-SKIP/coversBoth/calibration heave terms advisory (tagged advisoryVetoes; review after n>=40, see [heave_advisory]).",
  "Paper ledger Sep 25: 3 closed trades (#72 -696, #73 +63, #74 +265) = -368¢; cash 30883 + reserve 49 = 30932.",
  "Calibration gate (PR #14): one sample per window; unreliable if n<30 or bootstrap shows ECE>0.08 is significant (p<0.05). Live Sep 26: n=84, ECE 0.084, p=0.44 -> reliable (not proof of edge).",
  "For details call get_desk_knowledge (sections: releases, checkpoint, locks, calibration, settlement, open_issues, reporting_rules).",
].join("\n");

export const DESK_KNOWLEDGE_SECTIONS: Record<string, string> = {
  releases: [
    "Sep 25 2026 (all merged to master, deployed to Fly app kalshi-oracle-desk):",
    "- PR #7: TradingView market chart with symbol search (BTC default).",
    "- PR #9: bot trade card (signal vs fill wording, sold-early header, summary labels, reserve shown), chat agent fixes (healthz/calibration tools, richer recent trades, model shown), chart retry; repo .bot-config minEntryPrice 28->20 (live was already 20). Fly v31.",
    "- PR #10: committed chat 'default' checkpoint. Fly v32.",
    "- PR #11 (settlement audit + full-sweep fixes): exit guard (no exits against another ticker's quote or after contract close; after close only settlement), recordSettlement idempotent, tape ignores early closes stamped after close, restart does not revive a fill the tape already closed (repairs PG instead), startup recovery also books the tape close, failed settle DB writes retried every 30s, reserve pool persisted + no double subtraction in paper sizing, .bot-config.json moved onto the Fly volume (data/) with frozenCcMode default true, stored expected P&L uses the final EV gate's full-order fee, cash-flow list follows the desk mode, shadow cells cached, settledSource on trade rows. Fly v33 (image deployment-01M3D6CJDA5B4B9233WV5K4KAS).",
    "- PR #12: organ-debug paperMode lock, chat get_bot_config and the promote script read the volume config (v33 organ-debug showed 0/19 WARN 'could not read .bot-config.json'; trading unaffected). Fly v34 (image deployment-01M3D6SSWPW9BFGSFE5KDVB7MD), organs 19/19.",
    "Sep 26 2026 (Stellar approved 1:18 AM ET):",
    "- PR #14: see [pr14].",
    "- PR #16 Fly 1.5 GB/heap/swap; PR #17 [heave_advisory].",
    "- PR #13: paper daily loss halt turned back ON, reversing the Sep 7 paper carve-out. Paper halts exactly like live: cap = max($30 dailyLossCapCents, 10% dailyLossCapPct of the sizing bankroll; ~$30.88 at 30883¢); P&L basis = bot fills only, fee-net realized, current ET calendar day (todayStats; lifetime session P&L does NOT count). At the cap the bot SUSPENDS (no new entries). Counter resets at ET midnight; a suspended bot needs Start (or a restart) on the new ET day. Paper re-seeds today's P&L from the tape on start so a restart cannot clear a same-day halt. Cap values unchanged. Visible in /api/bot/status dailyLossHalt {halted, dayPnlCents, capCents, etDay} and state SUSPENDED on the dashboard.",
  ].join("\n"),
  pr14: [
    "PR #14 (Stellar: 'Go with what you think is the best', 2:38 AM ET): (2) frozen-CC takes now need lockSide PASS (result PASS, mtf == fill side) before placeOrder, same LOCKSIDE_SKIP_NO_FILL gate as other CC|LAG paths; the frozen tick stamps a fresh lockSide result each tick. (3) paper fills re-check EV>=3¢ and the 20-55¢ band at the fill price (quote + slippage) before debit; failures skip as FILL_PRICE_EV_FAIL / FILL_PRICE_BAND_FAIL. (4) calibration gate rewritten (see [calibration]). (5) equity band 2-4% of paper equity verified, still under Kelly<=0.60 and the 9% cap (no code change). Min entry stays 20, band 20-55.",
  ].join("\n"),
  heave_advisory: [
    "PR #17 option B (Stellar delegated judgment, Sep 26): since F1 (Sep 19 12:15 ET) any fresh captain HEAVE_TO at placeOrder blocked the order (MIND_HEAVE_BIND), ~93 unique window/side opportunities a day. Now three terms are ADVISORY at placeOrder and the agent entry gate: OV-SKIP score, coversBoth, calibration unreliable. They no longer block; the trade is tagged advisoryVetoes [OV_SKIP|COVERS_BOTH|CALIBRATION] plus mindHeave (key ticker|side, voyage, OV score, reasons) on the paper entry and close tape rows, and a MIND_HEAVE_ADVISORY decision trace is logged per window|side. advisoryVetoes [] = unflagged.",
    "Still BLOCKING: oracle risk vetoes (7¢ min edge, hard EV floor 3¢, thin book, gates_failed, MISSING_INPUTS, settle-side SKIP), blind/no index, stale feed, vel_against, thin_book, storm, missing inputs or band (fog from gates/missing), captain FACT floors, PhD education and KXBTC15M specialist heaves, officers-lean-skip, any unrecognised heave reason. Unchanged: EV 3¢ lock, fill-price EV/band re-check, lockSide PASS, daily halt, Kelly<=0.60, caps, band 20-55, paperMode true.",
    "Review rule: after n>=40 closed trades, compare fee-net per contract for flagged vs unflagged (per term) with a day-block bootstrap CI. If flagged trades are significantly worse (CI of flagged minus unflagged entirely below 0), restore blocking for that term. Do not claim an edge from this: it is an experiment.",
    "History (historical, not verified-current): pre-F1 busy period +9.2¢/contract, CI [-2.4, +20.0], profit mostly from early exits; the no-coversBoth blocked subset held to settlement +4.9¢, CI [-10.7, +20.7], n=39. Both CIs include 0.",
  ].join("\n"),
  checkpoint: [
    "Typing `default` in Chat restores the frozen SETTINGS snapshot (paperMode forced true) and the api-server src files listed in DEFAULT_CODE_CHECKPOINT_FILES.",
    "It lives in apps/api-server/checkpoints/default/ (committed, ships in the image). Only api-server src/ is restored; dashboard/charts files are not part of it.",
    "Never includes the paper ledger, .env or secrets. /api/healthz build.defaultCheckpoint shows {frozenAt, fileCount, hash}; compare the hash with master before trusting it.",
  ].join("\n"),
  locks: [
    "Hard locks (never changed by chat, learner or agents): paperMode true; EV floor 3¢ after fees; Kelly <=0.60; 9% per trade / 18% day caps; 15% reserve; entry band as configured (live 20-55, band decision pending with Stellar: 20 vs 28); frozenCcMode true; disabled engines stay disabled; THESIS_BREAK only on BROKEN; lockSide PASS before placeOrder on every CC|LAG path including frozen-CC (PR #14); Mind heave still blocks on hard terms (only OV-SKIP/coversBoth/calibration are advisory, PR #17); EV>=3¢ and band re-checked at the paper fill price (PR #14); no force-push; no secrets.",
  ].join("\n"),
  calibration: [
    "PR #14 gate (Sep 26): sample = one per 15m window (the first qualifying decision; paired YES+NO shadows no longer both count), scoped to the current model version. Includes early-exit fills: a fill sold before settle is parked and scored against the market's settled result for the side it bought (source fill). p is the filled side's p (pFilledSide).",
    "Rule: n<30 -> unreliable (as before). n>=30 -> B=2000 bootstrap resamples (fixed seed 0x5eed14), bias-corrected one-sided 95% lower bound L = 2*ECE - q95(ECE*). Trip (unreliable, OV-SKIP lean +0.12) only if L > 0.08, i.e. bootstrap p<0.05. Only the brake moves; EV, Kelly and sizing are untouched.",
    "Live shadow sample (Fly volume snapshot Sep 26 ~2:43 AM ET): before = fixed rule on 102 rows, ECE 0.107 -> unreliable. After = 84 windows (18 duplicate-window rows dropped), all p in 0.52-0.58 (one bin), mean p 0.536 vs hit rate 0.452, ECE 0.084, L95 -0.003, p=0.44 -> reliable. Earlier note (ECE 0.12, n=63, p~0.059) was a smaller, non-deduped sample.",
    "Caveats: a pass means miscalibration >0.08 is NOT statistically shown at this n; it is not evidence of good calibration or of edge. The point estimate still says p overstates the hit rate by ~8pp. Power is modest (true gap 0.12 trips ~20% at n~60-100). At n=30 with widely spread p the rule false-trips ~12%.",
    "History: the pre-PR #14 fixed rule (n>=30 AND ECE<=0.08 on shadow-only samples, paired windows counted twice) flipped reliable then unreliable on Sep 25 (ECE 0.097, n=39).",
  ].join("\n"),
  settlement: [
    "Settlement audit Sep 25 (3 closed paper trades, all verified against Kalshi public market results):",
    "- #72 YES 18@37 KXBTC15M-26SEP191130-30, Kalshi NO, held to settlement, -696¢ (fee 30). Re-booked from a 0-pnl void by the approved R2 audit; tape keeps the void + correction, ledger counts it once. Its paper fill (37¢) was ~10¢ above Kalshi prints at that second (24-27¢): stale quote in a fast drop; simulation fidelity, not a ledger error.",
    "- #73 NO 22@31 sold early PATH_RIDE_TP @37 (market later settled YES), +63¢ (fees 33+36), reserve 9.",
    "- #74 NO 17@39 sold early PATH_RIDE_TP @58 at 10:53 ET for the 11:00 ET contract (exit price matches Kalshi prints for the same ticker), +265¢ (fees 29+29), reserve 40. Stored expected P&L 162 used the C=1 fee at the signal price; the trace shows 9¢/contract at the 39¢ ask.",
    "- Fees follow Kalshi ceil(0.07*C*P*(1-P)) per order; no duplicate or phantom settlements on Fly; no orphaned pending rows.",
    "- Ledger: 31300 - 368 = 30932 = cash 30883 + reserve 49 (reserve now persisted; before PR #11 it read 0 after restarts).",
    "- /api/bot/cash-flow is the deposits/withdrawals ledger; empty is correct (no deposits).",
  ].join("\n"),
  open_issues: [
    "Open (as of this note): PR #5 NOT merged: it is not type-only, it changes trading behaviour (exit/entry gates, settlement parsing). Workspace typecheck still red (~233 errors in trading-path src and lock tests). api-server suite has pre-existing failures (config-guard/frozen-CC restore/composer lock/README cwd/registry paths/diagnostics runner). Locks CI workflow waits in ops/ci/locks.yml (token lacks workflow scope; Stellar installs). PR #8 research is parked (do not merge).",
    "Policy questions for Stellar (report only): min entry 20 vs 28 (PR #14 kept 20). Decided in PR #14: EV/band re-check at the fill price, bootstrap calibration gate, frozen-CC lockSide required; equity band 2% floor kept (it can lift size above the Kelly-0.60 suggestion but stays <=4% and <=9%). (Paper daily-halt carve-out: decided Sep 26, halt back on.) Live todayStats is not persisted, so a live restart zeroes the day counter (report only).",
    "DB was marked degraded ~35x and the vol feed ~16x in 24h (self-healed). Heavy desk GETs (decision traces ~30s) can contend with the DB pool.",
  ].join("\n"),
  reporting_rules: [
    "Reporting rules: count raw checks separately from unique opportunities; label hypothetical/shadow results vs realized fills; quotes are not fills (paper fills add modeled slippage); state lag only 'at the meter's lower bound'; give n and confidence intervals for any rate; say whether a number is verified-current (from a live tool now) or historical (from this note or old logs).",
  ].join("\n"),
};

export function deskKnowledgeText(section?: string | null): string {
  const key = (section ?? "").trim().toLowerCase();
  const head = `Desk knowledge as of ${DESK_KNOWLEDGE_AS_OF} (historical; prefer live tool data).`;
  if (key && DESK_KNOWLEDGE_SECTIONS[key]) return `${head}\n\n[${key}]\n${DESK_KNOWLEDGE_SECTIONS[key]}`;
  if (key === "all") return [head, ...Object.entries(DESK_KNOWLEDGE_SECTIONS).map(([k, v]) => `[${k}]\n${v}`)].join("\n\n");
  // Tool results are truncated (~2k chars); return the summary + section index.
  return `${head}\n\n${DESK_KNOWLEDGE_SUMMARY}\n\nSections: ${Object.keys(DESK_KNOWLEDGE_SECTIONS).join(", ")}. Call again with {section}.`;
}
