/**
 * lag-side-agree.ts — LAG admission: proj side must agree with HA river OR CC factors
 * OR MTF lean (when lag+MTF actually agree).
 *
 * SKIP unless lag proj AND (HA river OR CC factors OR MTF) same sign.
 * Fail-closed SKIP if HA missing AND CC missing AND MTF missing/flat.
 * Never invents 5–15s tau. LAG ≤55 only when this agree holds.
 * corr_junk is a caller skip — no fill.
 *
 * 2026-09-07: MTF same-sign counts as confirmation so LAG_SIDE_DISAGREE does
 * not over-veto when lag proj and MTF already agree (HA/CC sensor lie / missing).
 *
 * Public contract the director / evaluateBasisLagEdge needs.
 */
export type LagSide = "YES" | "NO";
export type LagSideOrMissing = LagSide | null | undefined;

export type LagSideAgreeInput = {
  projSide: LagSideOrMissing;
  haRiverSide: LagSideOrMissing;
  ccFactorSide: LagSideOrMissing;
  /** Optional MTF lean — same sign as proj counts as confirmation. */
  mtfSide?: LagSideOrMissing;
};

export type LagSideAdmit = {
  ok: boolean;
  reasonCode: "LAG_SIDE_AGREE" | "LAG_SIDE_DISAGREE" | "LAG_SIDE_MISSING";
  reason: string;
};

function isSide(s: LagSideOrMissing): s is LagSide {
  return s === "YES" || s === "NO";
}

/** True iff proj is YES/NO and HA river or CC factors or MTF matches that sign. */
export function lagSideConfirmationAgrees(opts: LagSideAgreeInput): boolean {
  return admitLagSide(opts).ok;
}

/**
 * Fail-closed: missing proj, or HA+CC+MTF all missing, or neither matches.
 * HA NO vs LAG YES is SKIP unless CC or MTF is also YES (OR, not AND).
 */
export function admitLagSide(opts: LagSideAgreeInput): LagSideAdmit {
  if (!isSide(opts.projSide)) {
    return {
      ok: false,
      reasonCode: "LAG_SIDE_MISSING",
      reason: "lag proj side missing — fail-closed SKIP",
    };
  }
  const haOk = isSide(opts.haRiverSide);
  const ccOk = isSide(opts.ccFactorSide);
  const mtfOk = isSide(opts.mtfSide);
  if (!haOk && !ccOk && !mtfOk) {
    return {
      ok: false,
      reasonCode: "LAG_SIDE_MISSING",
      reason: "HA missing AND CC missing AND MTF flat — fail-closed SKIP (not fake tau 5–15s)",
    };
  }
  const haAgree = haOk && opts.haRiverSide === opts.projSide;
  const ccAgree = ccOk && opts.ccFactorSide === opts.projSide;
  const mtfAgree = mtfOk && opts.mtfSide === opts.projSide;
  if (haAgree || ccAgree || mtfAgree) {
    return {
      ok: true,
      reasonCode: "LAG_SIDE_AGREE",
      reason: `proj ${opts.projSide} agrees with HA ${opts.haRiverSide ?? "none"} / CC ${opts.ccFactorSide ?? "none"} / MTF ${opts.mtfSide ?? "none"}`,
    };
  }
  return {
    ok: false,
    reasonCode: "LAG_SIDE_DISAGREE",
    reason: `proj ${opts.projSide} vs HA ${opts.haRiverSide ?? "none"} / CC ${opts.ccFactorSide ?? "none"} / MTF ${opts.mtfSide ?? "none"} — SKIP`,
  };
}
