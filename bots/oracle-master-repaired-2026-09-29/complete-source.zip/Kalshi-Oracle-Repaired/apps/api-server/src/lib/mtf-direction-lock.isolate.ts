/**
 * mtf-direction-lock.isolate.ts — UNCHANGED copy of applyStrongMTFDirectionLock
 * from trading-bot.ts at isolate time (pre CC exemption).
 * Compare-only. Not a live lock.
 */
export function applyStrongMTFDirectionLockIsolate<T extends { strategyId: string; signal: string }>(
  pool: T[],
  mtfScore: number,
  enabled: boolean,
  log: (msg: string) => void,
): T[] {
  if (!enabled || !Number.isFinite(mtfScore) || Math.abs(mtfScore) < 3) return pool;
  const mtfBias = mtfScore <= -3 ? 'strong_bear' : 'strong_bull';
  const allowedSignal = mtfBias === 'strong_bear' ? 'NO' : 'YES';
  const filtered = pool.filter(r => {
    return (r.signal !== 'YES' && r.signal !== 'NO') || r.signal === allowedSignal;
  });
  for (const result of pool) {
    if (result.signal !== 'YES' && result.signal !== 'NO') continue;
    if (result.signal !== allowedSignal) {
      log(
        `🧭 Direction lock: MTF ${mtfBias} — ${allowedSignal} only, ` +
        `skipping ${result.signal} signal (${result.strategyId})`,
      );
    }
  }
  return filtered;
}
