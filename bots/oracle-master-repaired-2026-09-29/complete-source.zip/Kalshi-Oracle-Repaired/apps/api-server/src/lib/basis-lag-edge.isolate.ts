/**
 * basis-lag-edge.isolate.ts — UNCHANGED LAG unproven gate at isolate time
 * (REMAKE_OVERLAY / PAPER_ORIG_PROJ cheap proceed; corr_junk + same-sign lead$ fill).
 * Compare-only. Live rewrite: LAG ≤55 only when proven (HA/CC same sign in evaluate);
 * unproven skip; corr_junk no fill. Never fake 5–15s.
 */
export const LAG_CHEAP_ASK_CENTS_ISOLATE = 55;

export type LagUnprovenGateKind = "PROVEN" | "REMAKE_OVERLAY" | "ORIGINAL_LOCK" | "PAPER_ORIG_PROJ";

export interface LagUnprovenGateResult {
  kind: LagUnprovenGateKind;
  proceed: boolean;
  reasonCode: string;
  reason: string;
}

function finiteNonZeroDollarIsolate(d: number | null | undefined): number | null {
  return typeof d === "number" && Number.isFinite(d) && d !== 0 ? d : null;
}

function dollarsAgreeWithSideIsolate(side: "yes" | "no" | undefined, d: number): boolean {
  if (side !== "yes" && side !== "no") return true;
  return side === "yes" ? d > 0 : d < 0;
}

/**
 * Paper=live LAG_UNPROVEN classifier. Never invents 5–15s (tau stays null).
 * PROVEN: lagProven===true and the chosen side is not fought by the only
 *   available $. Opposite-sign catch-up lead is not PROVEN for YES.
 *   Agreeing Coinbase lag$ still proceeds (remake lead junk is ignored).
 *   lagStale / corr_junk alone do not ORIGINAL_LOCK when proven or when
 *   Coinbase lagDollars / catch-up leadDollars is finite and SAME SIGN as
 *   the cheap side.
 * REMAKE_OVERLAY: warming (!proven) with finite same-sign Coinbase/lead $.
 *   leadSeconds may be null — do not require a clock, do not fake seconds.
 *   Cheap ≤55 once sideAsk is known; omit sideAsk (lagGate0) defers cheap.
 * ORIGINAL_LOCK: !proven AND no finite same-sign lead (Coinbase or lead$).
 */
export function classifyLagUnprovenGateIsolate(opts: {
  lagProven?: boolean;
  lagStale?: boolean;
  leadSeconds?: number | null;
  leadDollars?: number | null;
  proofHitRate?: number | null;
  sideAsk?: number;
  /** Traded side. When set, finite leadDollars of the opposite sign is not PROVEN. */
  side?: "yes" | "no";
  /** Coinbase tau $. May be null on corr_junk; then leadDollars is the lead. */
  lagDollars?: number | null;
  lagReason?: string | null;
  paperMode?: boolean;
}): LagUnprovenGateResult {
  const leadSec = opts.leadSeconds;
  const fromLead = finiteNonZeroDollarIsolate(opts.leadDollars);
  const fromCb = finiteNonZeroDollarIsolate(opts.lagDollars);
  const stale = opts.lagStale !== false;
  const leadDisagreesWithSide = fromLead != null && !dollarsAgreeWithSideIsolate(opts.side, fromLead);
  const agreeing =
    (fromLead != null && dollarsAgreeWithSideIsolate(opts.side, fromLead) ? fromLead : null)
    ?? (fromCb != null && dollarsAgreeWithSideIsolate(opts.side, fromCb) ? fromCb : null);
  const hasLead = agreeing != null;

  // Opposite-sign lead is never PROVEN for the chosen side. Fail-closed only
  // when no agreeing Coinbase lag$ remains — remake lead vs agreeing tau is
  // junk, not a skip. Missing $ is not disagree.
  if (leadDisagreesWithSide && !hasLead) {
    return {
      kind: "ORIGINAL_LOCK",
      proceed: false,
      reasonCode: "LAG_DISAGREES",
      reason: `lead/lag$ disagrees with ${opts.side} — fail-closed (never invent 5–15s)`,
    };
  }
  if (opts.lagProven === true) {
    return {
      kind: "PROVEN",
      proceed: true,
      reasonCode: "LAG_PROVEN",
      reason: stale
        ? "lag catch-up proven (lagStale does not ORIGINAL_LOCK when proven)"
        : "lag catch-up proven, Coinbase present",
    };
  }

  if (hasLead) {
    const ask = opts.sideAsk;
    const askKnown = typeof ask === "number" && Number.isFinite(ask);
    const hit = opts.proofHitRate;
    const hitBit = typeof hit === "number" && Number.isFinite(hit) ? ` hit=${hit}` : "";
    const junkBit = opts.lagReason === "corr_junk" ? " corr_junk" : "";
    const clockBit = typeof leadSec === "number" && leadSec > 0
      ? `${leadSec}s / $${agreeing}`
      : `tau null / $${agreeing}${junkBit}`;
    if (!askKnown) {
      return {
        kind: "REMAKE_OVERLAY",
        proceed: true,
        reasonCode: "REMAKE_OVERLAY",
        reason: `REMAKE_OVERLAY warming hit/lead ${clockBit}${hitBit} sideAsk deferred — paper=live proceed (never fake 5–15s)`,
      };
    }
    const cheap = ask <= LAG_CHEAP_ASK_CENTS_ISOLATE;
    if (cheap) {
      return {
        kind: "REMAKE_OVERLAY",
        proceed: true,
        reasonCode: "REMAKE_OVERLAY",
        reason: `REMAKE_OVERLAY warming hit/lead ${clockBit}${hitBit} ask ${ask}c <=${LAG_CHEAP_ASK_CENTS_ISOLATE} — paper=live proceed (never fake 5–15s)`,
      };
    }
    return {
      kind: "REMAKE_OVERLAY",
      proceed: false,
      reasonCode: "LAG_UNPROVEN",
      reason: `LAG_UNPROVEN REMAKE_OVERLAY not cheap (ask ${ask} not <=${LAG_CHEAP_ASK_CENTS_ISOLATE}) warming ${clockBit}${hitBit} — fail-closed paper=live (never fake 5–15s)`,
    };
  }

  if (opts.paperMode === true) {
    const ask = opts.sideAsk;
    const askKnown = typeof ask === "number" && Number.isFinite(ask);
    if (!askKnown) {
      return {
        kind: "PAPER_ORIG_PROJ",
        proceed: true,
        reasonCode: "PAPER_ORIG_PROJ",
        reason: "paper orig proj — LAG_UNPROVEN/lagStale do not skip aligned cheap (never invent 5–15s)",
      };
    }
    if (ask <= LAG_CHEAP_ASK_CENTS_ISOLATE) {
      return {
        kind: "PAPER_ORIG_PROJ",
        proceed: true,
        reasonCode: "PAPER_ORIG_PROJ",
        reason: `paper orig proj ask ${ask}c <=${LAG_CHEAP_ASK_CENTS_ISOLATE} — LAG_UNPROVEN/lagStale do not skip (never invent 5–15s)`,
      };
    }
    return {
      kind: "PAPER_ORIG_PROJ",
      proceed: false,
      reasonCode: "LAG_UNPROVEN",
      reason: `LAG_UNPROVEN paper orig not cheap (ask ${ask} not <=${LAG_CHEAP_ASK_CENTS_ISOLATE}) — fail-closed (never fake 5–15s)`,
    };
  }
  const pred = stale
    ? `ORIGINAL_LOCK Coinbase missing/lagStale lagProven=${opts.lagProven} leadSeconds=${opts.leadSeconds} leadDollars=${opts.leadDollars} (never fake 5–15s)`
    : `ORIGINAL_LOCK no lead/hit yet lagProven=${opts.lagProven} lagStale=${opts.lagStale} leadSeconds=${opts.leadSeconds} leadDollars=${opts.leadDollars} (inventing 5–15s)`;
  return {
    kind: "ORIGINAL_LOCK",
    proceed: false,
    reasonCode: "LAG_UNPROVEN",
    reason: pred,
  };
}

