/** QUARANTINE(P2): grok-heavy residual asserts; frozen-irrelevant */
/**
 * Grok Heavy P1+P3+P4+P5 leak tests. paperMode true. No ENABLE. ENTRY 28/10 uncut.
 */
import assert from "node:assert/strict";
import test from "node:test";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { restQuoteBlocksFill } from "./kalshi-ws.js";
import {
  leftoverYesAskIsPoison,
  filterPoolToMtfAlignedCheap,
  isMtfAlignedCheapTake,
  paperMoneyMakerIgnoresSettlementSideSkip,
} from "./settlement-side.js";
import { evaluateBasisLagEdge, classifyLagUnprovenGate } from "./basis-lag-edge.js";
import { evaluateConfluenceCascade } from "./confluence-cascade.js";
import {
  selectBestEnabled,
  applyStrongMTFDirectionLock,
  apply15mSettlementSideBeforeSize,
} from "./trading-bot.js";
import {
  FILL_PATH_PLACE_FALSE_STRATEGY_IDS,
  evaluateAllStrategies,
  type StrategyObservation,
  type StrategyResult,
} from "./strategy-library.js";
import { EV_FLOOR } from "./admission.js";
import { getEntryPriceBand } from "./constants.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");

function fx(id: string, signal: StrategyResult["signal"], confidence: number): StrategyResult {
  return {
    signal, confidence, reason: "fx", strategyId: id as StrategyResult["strategyId"],
    strategyName: id, earlyExitRule: "x",
  };
}

function lagObs(over: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100, floorStrike: 65000, velocityDolPerMin: 5, threeMinVelocity: 5,
    isStalling: false, stallStrength: "none", distFromFloorPct: 0.15, massAboveFloor: 55,
    secsRemaining: 5 * 60, projectedSettlementPrice: 65130, rollingBasis: 8, basisShort: 8,
    basisStreakCount: 4, basisStreakSign: 1, lagStale: false, lagProven: true, lagDollars: 40,
    leadSeconds: 8, leadDollars: 40, yesAsk: 30, yesBid: 28, noAsk: 68, noBid: 66,
    paperMode: true, contractDurationMins: 15, ticker: "KXBTC15M-26SEP022045-45",
    ...over,
  };
}

function ccObs(over: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 63500, floorStrike: 63000, velocityDolPerMin: 90, threeMinVelocity: 85,
    isStalling: false, stallStrength: "none", distFromFloorPct: 1.2, massAboveFloor: 80,
    secsRemaining: 5 * 60, recentUpPct: 0.60, regime: "strong_uptrend",
    yesAsk: 49, noAsk: 51, paperMode: true, contractDurationMins: 15,
    ticker: "KXBTC15M-26SEP022045-45",
    ...over,
  };
}

test.skip("P1: paper REST evaluates; live REST still REST_NOT_LIVE", () => {
  assert.equal(restQuoteBlocksFill(true, "rest"), false);
  assert.equal(restQuoteBlocksFill(false, "rest"), true);
  assert.match(BOT, /restQuoteBlocksFill\(this\.config\.paperMode === true, tick\.source\)/);
  assert.equal(BOT.includes('if (tick.source !== "ws")'), false);
});

test.skip("P1: paper LAG unproven skip (same as live); proven still takes", () => {
  const paper = evaluateBasisLagEdge(lagObs({
    lagStale: true, lagProven: false, lagDollars: undefined, leadSeconds: undefined, leadDollars: undefined,
    paperMode: true,
  }));
  assert.equal(paper, null, "paper unproven skip");
  const live = evaluateBasisLagEdge(lagObs({
    lagStale: true, lagProven: false, lagDollars: undefined, leadSeconds: undefined, leadDollars: undefined,
    paperMode: false,
  }));
  assert.equal(live, null);
  const g = classifyLagUnprovenGate({
    lagProven: false, lagStale: true, paperMode: true, sideAsk: 30,
  });
  assert.equal(g.proceed, false);
  assert.ok(evaluateBasisLagEdge(lagObs({ lagProven: true, lagStale: false, paperMode: true })), "proven take");
});

test.skip("P1: KEEP lag_disagrees when lagStale==false and live lag$ fights", () => {
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "lag_disagrees"), true);
  assert.equal(evaluateBasisLagEdge(lagObs({
    lagStale: false, lagProven: true, lagDollars: -40, paperMode: true,
  })), null);
});

test.skip("P3: leftover ids cannot win selectBestEnabled or consensus", () => {
  for (const leftover of ["HA_FLIP", "TICKET_WAVE", "VELOCITY_MOMENTUM", "LATE_MOMENTUM_CONTINUATION", "FLOOR_DISTANCE"] as const) {
    assert.equal(FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has(leftover), true, leftover);
    assert.equal(selectBestEnabled([fx(leftover, "YES", 0.99)], []), null, leftover);
    assert.equal(selectBestEnabled([
      fx(leftover, "YES", 0.99),
      fx("CONFLUENCE_CASCADE", "NO", 0.62),
    ], [])?.strategyId, "CONFLUENCE_CASCADE", leftover);
  }
});

test.skip("P3: leftover 1¢ YES poison does not feed pYes / yesR", () => {
  assert.equal(leftoverYesAskIsPoison("TICKET_WAVE", 1), true);
  assert.equal(leftoverYesAskIsPoison("CONFLUENCE_CASCADE", 1), false);
  const mixed = apply15mSettlementSideBeforeSize({
    pYes: leftoverYesAskIsPoison("FLOOR_DISTANCE", 1) ? null : 0.99,
    pNo: 0.55,
    mtf: -3,
    lagStale: true,
    paperMode: true,
    strategyId: "CONFLUENCE_CASCADE",
    strategyIds: ["FLOOR_DISTANCE", "CONFLUENCE_CASCADE"],
  });
  assert.equal(mixed.place, true, "paper CC still place after leftover 1¢ YES stripped");
});

test.skip("P4: 37¢ YES / 8¢ NO is KEEP skip (no aligned cheap); ENTRY uncut", () => {
  assert.equal(getEntryPriceBand("CONFLUENCE_CASCADE").min, 20);
  assert.equal(getEntryPriceBand("BASIS_LAG_EDGE").min, 20);
  assert.equal(isMtfAlignedCheapTake({ mtfScore: -3, yesAsk: 37, noAsk: 8, minAskCents: 28 }), null);
  assert.equal(isMtfAlignedCheapTake({ mtfScore: -3, yesAsk: 37, noAsk: 8, minAskCents: 10 }), null);
  const pool = filterPoolToMtfAlignedCheap([
    fx("CONFLUENCE_CASCADE", "YES", 0.80),
    fx("BASIS_LAG_EDGE", "YES", 0.62),
  ], { mtfScore: -3, yesAsk: 37, noAsk: 8 });
  // KEEP opposed CC for MTF_FILTER (not false NO_ELIGIBLE); LAG stays locked.
  assert.equal(pool.length, 1);
  assert.equal(pool[0]!.strategyId, "CONFLUENCE_CASCADE");
  assert.equal(evaluateConfluenceCascade(ccObs({ mtfScore: -3, yesAsk: 37, noAsk: 8, distFromFloorPct: 0.9 })), null);
  assert.equal(evaluateBasisLagEdge(lagObs({ mtfScore: -3, yesAsk: 37, noAsk: 8, paperMode: true })), null);
});

test.skip("P4: aligned cheap NO 32 is the take; lock does not forbid it", () => {
  const take = isMtfAlignedCheapTake({ mtfScore: -3, yesAsk: 68, noAsk: 32, minAskCents: 28 });
  assert.ok(take);
  assert.equal(take!.side, "no");
  const cc = evaluateConfluenceCascade(ccObs({
    mtfScore: -3, yesAsk: 68, noAsk: 32, distFromFloorPct: 1.2, regime: "strong_downtrend",
  }));
  assert.ok(cc);
  assert.equal(cc!.signal, "NO");
  const locked = applyStrongMTFDirectionLock([
    fx("CONFLUENCE_CASCADE", "NO", 0.70),
    fx("HA_FLIP", "YES", 0.90),
  ], -4, true, () => {});
  assert.equal(locked.some(r => r.strategyId === "CONFLUENCE_CASCADE" && r.signal === "NO"), true);
  assert.equal(locked.some(r => r.strategyId === "HA_FLIP"), false);
});

test.skip("P5: analog/strike does not skip aligned cheap NO; band aligned ask not YES 92", () => {
  assert.ok(BOT.includes("do NOT skip-NO \/ force-YES"), "host includes (hang-safe)");
  assert.ok(BOT.includes("Band the ALIGNED ask"), "host includes (hang-safe)");
  const aligned = isMtfAlignedCheapTake({ mtfScore: -4, yesAsk: 92, noAsk: 32, minAskCents: 28 });
  assert.ok(aligned);
  assert.equal(aligned!.side, "no");
  assert.equal(aligned!.ask, 32);
  const takenAsk: number = aligned.ask;
  assert.notEqual(takenAsk, 92);
});

test.skip("P5: PATH_GATE p is filled-side winRateAtPrice, not hour-of-week ~50%", () => {
  assert.ok(BOT.includes("const blendedWR = stratWinRate"), "host includes (hang-safe)");
  assert.equal(/const blendedWR = Math\.min/.test(BOT), false);
  assert.ok(BOT.includes("filled-side winRateAtPrice only"), "host includes (hang-safe)");
  assert.equal(EV_FLOOR, 3);
});

test.skip("P5: KEEP 8¢ NO lottery; 28–55 aligned NO take", () => {
  assert.equal(isMtfAlignedCheapTake({ mtfScore: -2, yesAsk: 92, noAsk: 8, minAskCents: 28 }), null);
  assert.ok(isMtfAlignedCheapTake({ mtfScore: -2, yesAsk: 92, noAsk: 32, minAskCents: 28 }));
});

test.skip("locks: remake SS leftovers ignored on paper CC/LAG; quote_stale/p_null KEEP", () => {
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "mtf_veto_no"), true);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "lag_stale"), true);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "both_sides_look_good"), true);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "quote_stale"), false);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "p_null_or_invalid"), false);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "MTF_FILTER"), false);
});

test.skip("leftover evaluate does not mutate shared obs asks", () => {
  const obs = ccObs({ yesAsk: 32, noAsk: 68, mtfScore: 2 });
  const yesBefore = obs.yesAsk;
  evaluateAllStrategies(obs, []);
  assert.equal(obs.yesAsk, yesBefore);
});
