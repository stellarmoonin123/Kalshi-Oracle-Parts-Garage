import { guardedQuoteValueLag } from "./quote-value-guard.js";
/** trading-bot.ts — Kalshi BTC 15-min binary auto-trader (v6 + Grok upgrades) */

import { db, botTrades, botTradeSkips, btcPeriods, exitOrderAttempts } from "@workspace/db";
import { desc, eq, and, or, lt, gt, gte, lte, sql } from "drizzle-orm";
import { exitQuoteGuard, resolveTradeCloseMs } from "./exit-quote-guard.js";
import { paperEffectiveBalanceCents, paperBotDayPnlFromTape } from "./paper-ledger.js";
import { enqueueSettlePersistRetry, drainSettlePersistRetry, isSettleRetryQueued, SETTLE_RETRY_INTERVAL_MS } from "./settle-persist-retry.js";
import {
  VOLUME_HIGH_RATIO, VOLUME_LOW_RATIO, ADD_POSITION_MIN_PROFIT_CENTS,
  ACCEL_CONF_BONUS, ACCEL_CONF_PENALTY,
  STREAK_FADE_THRESH, STREAK_CONF_PENALTY, STREAK_CONF_BONUS, ALTERNATING_FADE_BONUS,
  REGIME_TREND_CONF_BONUS, REGIME_UNCLEAR_CONF_PENALTY,
  KALSHI_TAKER_FEE,
  KALSHI_API_DOMAIN,
  KALSHI_PATH_PORTFOLIO_BALANCE, KALSHI_PATH_PORTFOLIO_POSITIONS, KALSHI_PATH_PORTFOLIO_FILLS,
  KALSHI_PATH_PORTFOLIO_ORDERS, kalshiEventsOrderPath, kalshiOrderStatusPath, kalshiSettlementsPath,
  getEntryPriceBand, getUniversalPriceBandTier, PRICE_BAND_HALF_MAX_CENTS,
  RICH_ASK_EXTRA_EV_MARGIN_CENTS,
  HARVEST_SIZE_MULT, HARVEST_ASK_MAX_CENTS,
  PRICE_BAND_LATE_EXCEPTION_STRATEGIES, PRICE_BAND_EXTREME_DISPLACEMENT_PCT, PRICE_BAND_LATE_MAX_MINS_LEFT,
  PRICE_BAND_STANDARD_MAX_CENTS, computeStackTier, STACK_PRESS_COOLDOWN_MS, type SizeTier,
  SETTLEMENT_UNRESOLVED_TIMEOUT_MS, KALSHI_EXPECTED_SLIPPAGE_CENTS, expectedSlippageCents,
  observedSlippageFloorCents,
  ASIAN_HOURS_SIZE_MULT, applyTimeOfDaySizeMultiplier, capContractsToLiquidityLimit, getTimeOfDayRegime, type TimeOfDayRegime,
  MAX_DEPTH_FRACTION,
} from "./constants.js";
import { applyTightenOnly, reportIfLoosened, capEntryFloorToManual, capToManualBoundary } from "./tighten-only.js";
import { applyComposerLocks } from "./composer-lock.js";

import {
  recordClose as recordShadowSitClose,
  recordCatastrophicExit,
  recordWickSurvived5cUnder20s,
} from "./shadow-sit-watch.js";
import {
  FROZEN_CC_DEFAULT_CATASTROPHIC_CENTS,
  FROZEN_CC_CATASTROPHIC_SUSTAIN_MS,
  FROZEN_CC_RULESET_VERSION,
  FROZEN_CC_STRATEGY_ID,
  appendFrozenLedgerRow,
  buildFrozenShadowPreDecision,
  enrichFrozenShadowPostTake,
  formatFrozenCcTakeDesc,
  decideFrozenCcEntry,
  decideFrozenCcExit,
  emptyShadowFlags,
  holdToSettlementPnlCents,
  runningGitSha,
  readFrozenLedger,
  maybeWritePromoteArtifacts,
  shouldBlockPlaceOrderWithoutFrozenDecision,
  type FrozenShadowFlags,
} from "./frozen-cc.js";
import {
  classifyFrozenCcEntryShadow,
  maybeAppendEntryShadowDecision,
  appendEntryShadowClose,
  YES_40_55_PIN_SHADOW_V1,
} from "./frozen-cc-entry-shadow.js";
import { sanitizeConfigPatch } from "./config-patch-surface.js";
import type { AgentEntryFilters } from "./expert-agent.js";
import { detectConfigDrift, snapshotManualFloors, configGuardRestorePatch, type ManualFloorSnapshot } from "./config-guard.js";
import { normalisePem as kalshiNormalisePem, signKalshi, kalshiAuthHeadersAsync } from "./kalshi-auth.js";
import { buildKalshiV2Body, buildKalshiV2ExitBody, isValidKalshiPrice, stableClientOrderId } from "./kalshi-order-body.js";
import { kalshiWS, restQuoteBlocksFill,
  hasExecutableKalshiAsk,
} from "./kalshi-ws.js";
import { inferBtcPrice, fetchKalshiSettlements } from "./kalshi-price.js";
import { recordShadowTake, recordEarlyExitFillForCalibration } from "./organs/shadow-calibration.js";
import { checkOrderbookConsistency } from "./orderbook-consistency.js";

type KalshiTickLike = NonNullable<ReturnType<typeof kalshiWS.getLatest>>;
/** D9 — real WS-quote staleness (timestamp + value lag vs a newer L2 book). */
function liveQuoteValueLag(tick?: KalshiTickLike | null): { stale: boolean; reason: string | null } {
  return guardedQuoteValueLag(() => ({
    tick: (tick === undefined ? kalshiWS.getLatest() : tick) ?? null,
    ob: kalshiWS.getLatestOrderbook() ?? null,
  }));
}

/** L2 vs live WS top consistency for the brain's depth stamp (stale → depth unknown). */
function brainOrderbookConsistency(): { stale: boolean; reason: string | null } | null {
  try {
    const ob = kalshiWS.getLatestOrderbook();
    if (!ob) return null;
    const c = checkOrderbookConsistency(ob, kalshiWS.getLatest() ?? null);
    return { stale: c.stale, reason: c.reason };
  } catch {
    return { stale: true, reason: "consistency check failed" };
  }
}
import { sweepShadowCalibration } from "./shadow-calibration-sweep.js";
import { mtfAnalyzer, getMtfOhlcBars } from "./mtf-analyzer.js";
import {
  applyHtfStructureToSide,
  computeLiveHtfStructure,
  velocitySideFromDollarsPerMin,
  type HtfStructureSnapshot,
} from "./mtf-structure.js";
import {
  evaluateStreakSaturation,
  liveStreakSatInput,
  type StreakSatDecision,
} from "./streak-saturation.js";
import { collectAdviceShadow, formatAdviceDeskLine, type AdviceShadowLabel } from "./advice-shadow.js";
import { ticketDeltasFromHistory } from "./intra-scalp-replay.js";
import { candlePatternAnalyzer, isPatternReversalAgainstSide } from "./candlestick-patterns.js";
import {
  evaluateAllStrategies,
  FILL_PATH_PLACE_FALSE_STRATEGY_IDS,
  placeableWithoutHaWhenMoneyMakerFires,
  classifyRegimeFromBuffer,
  getAllStrategyMeta,
  computePsychLevel,
  isStrategyAllowedForDuration,
  drainOtmConfluenceSkipEvents,
  getStrategyFamily,
  type OtmConfluenceSkipEvent,
  type StrategyResult as LibStrategyResult,
  type StrategyObservation,
  type TradeSignal,
} from "./strategy-library.js";

function isTradeSignal(signal: string): signal is TradeSignal {
  return signal === "YES" || signal === "NO" || signal === "STAY_OUT";
}
import { stampEntryTheoFromBrti, sanitizeTheoCents } from "./brti-theo-sanity.js";
import {
  binaryCallFairValueCents,
  complementaryFairValueCents,
  fairValueEdgeCents,
} from "./binary-pricing.js";
import { getBotFillLearningWeights, pathPWinFromCurveOrLearner, getLearnerPathWinRateSample } from "./strategy-learner.js";
import { isDecisionSafe, recordSuccess, recordFailure } from "./decision-safety.js";
import { getDbDisabledStrategies, getStrategyMultipliersSync, getLiveTradeStatsSync, computePSizeForKelly, computeSizeUncertaintyMult, onTradeSettled as onTradeSettledForPerformance, ensureFillOriginColumn } from "./strategy-performance.js";
import { adaptiveTuningLog } from "./adaptive-tuning-log.js";
import { getEmpiricalRegimeAdjustment, refreshRegimeEVStats } from "./regime-ev-stats.js";
import { getPatternBoost, fingerprintObs } from "./pattern-learner.js";
import {
  computeMarketIntelligenceObs, computeMIAdjustment,
  getCurrentSessionMode, type SessionMode,
  type MarketIntelligenceData,
} from "./market-intelligence.js";
import {
  canReusePreTradeAdmissionForRequote,
  doesPreTradeVerdictMatchEntryPrice,
  getPreTradeEntryPath,
  runPreTradeSim,
} from "./pre-trade-sim.js";
import { fetchWithRetry } from "./fetch-retry.js";
import { basisTracker, projectSettlementPrice } from "./basis-tracker.js";
import { getLagMeterStatus, type LagMeterStatusFields } from "./lag-meter.js";
import {
  canonicalLagProjectedSettlement,
  emptyOrigLagProjStreak,
  updateOrigLagProjStreak,
  liveOrigLagStreakOnObs,
} from "./basis-lag-edge.js";
import { shouldSkipConfidenceFloor, resolveMoneyMakerConfFloorSideAgree, ticketEVCentsFromP } from "./confidence-floor.js";
import type { BasisState } from "./basis-tracker.js";
import { recordShadowTick } from "./research-shadow-log.js";
import { persistBasisSample } from "./basis-persistence.js";
import { incidentStore } from "./incident-store.js";
import { computeBinarySettlementPnl, computeEarlyExitFeeNetPnl, markTradeUnresolved, feedLearningPipelines, paperFillCostCents, paperSettlementCreditCents, paperEarlyExitCreditCents, countsTowardStrategyWinRate, STARTUP_RECOVERY_EXIT_REASON, startupRecoveryLearningExitReason } from "./settlement-helpers.js";
import { loadPaperLedger, peekPaperLedgerSessionStartTs, savePaperLedger, appendPaperTrade, appendPaperTradeClose, appendPaperTradeCloseOnce, paperLedgerFromBotTrades, paperLedgerFromSessionTape, loadPaperTrades, lookupPaperTapeCloseForRecovery, lookupPaperTapeOpenPending, findTapeCloseForPendingFill, reconcileIdlePaperLedgerCents, inspectPaperRecovery } from "./paper-ledger.js";
import { appendOpenTradeChartPoint, buildTradeChartSnapshot } from "./trade-chart-snapshot.js";

import {
  notePaperBarEvaluate,
  notePaperBarExit,
  notePaperBarFill,
  flushPaperBar,
  flushPaperBarsExcept,
} from "./paper-bar-tape.js";
import {
  FILL_ORIGIN_BOT,
  FILL_ORIGIN_MANUAL,
  accountStatusForPaperEntry,
  applyKalshiBalancePoll,
  classifyExitClass,
  includeInBotWinRate,
  includeInStrategyWinRate,
  isMoneyMakerThesisHold,
  kalshiPositionToManualIntent,
  pendingCountsForRestartHold,
  shouldFeedLearner,
  trackedKalshiTradeForAudit,
  type FillOrigin,
} from "./fill-origin.js";
import { rememberSkip, resolveSkipsForTicker } from "./skip-settlement-resolver.js";
import { rememberPuzzleTake } from "./contract-puzzle.js";
import { stampFromLive, type LiveTapeStamp } from "./tick-tape-labels.js";
import { shouldLagFlipExit, LAG_FLIP_MIN_HOLD_MS, LAG_FLIP_MIN_SAMPLES, LAG_FLIP_CONSECUTIVE_BOTH_AGAINST, leadAgainstSide, projAgainstSide, projAgreesWithSide as projAgreesWithSideFn, nextLagFlipBothAgainstStreak } from "./lag-flip.js";
import { ccVelocityAgainstGate } from "./cc-velocity-gate.js";
export { shouldLagFlipExit, LAG_FLIP_MIN_HOLD_MS, LAG_FLIP_MIN_SAMPLES };
import { ticketAdverseThesisBreakOk, pathRideAntiFlickerExitOk, THESIS_BREAK_MIN_HOLD_MS } from "./timing-clock.js";
import { checkPaperFillPrice } from "./paper-fill-price-gate.js";
import {
  assertLockSideAllowsFill,
  clampContractsToEquityBand,
  frozenCcLockSideAdmission,
  frozenLockSideStamp,
  LOCKSIDE_SKIP_NO_FILL,
} from "./organs/lockside-fill-gate.js";
import {
  assertLagAllowsMoneyMakerFill,
  LAG_UNPROVEN_NO_FILL,
} from "./organs/lag-unproven-fill-gate.js";
import {
  findMoneyCandSelectMiss,
  meterLagSideForW2,
} from "./select-miss-recover.js";
import {
  timeGateLast60s,
  dailyLossHaltBlock,
  feedStaleBlock,
  restNotLiveBlock,
} from "./organs/entry-guards.js";
import {
  entryPathAndSize,
  type EntryPathAndSizeResult,
} from "./organs/entry-path-size.js";
import {
  leftoverTbNoOp,
  leftoverFrMayFire,
  leftoverStructureFailOk,
} from "./organs/exit-leftover.js";
export { ticketAdverseThesisBreakOk, pathRideAntiFlickerExitOk, THESIS_BREAK_MIN_HOLD_MS };
import {
  thesisState,
  shouldDiscountAdd,
  pctStopAllowed,
  hardStructuralStopAllowed,
  CATASTROPHIC_MARK_CENTS,
  type ThesisStatus,
  type ThesisState,
} from "./thesis-state.js";
export { thesisState, shouldDiscountAdd, pctStopAllowed, hardStructuralStopAllowed, CATASTROPHIC_MARK_CENTS };
import { decideHoldOrSell } from "./hold-sell.js";
export { decideHoldOrSell };
import {
  PATH_RIDE_EXIT_BOOK,
  distanceIsFat,
  haFromRaw,
  isPathRideKellyBook,
  isPathRideFlickerBook,
  isPathRideOpenTrade,
  isPathRideStrategyId,
  PATH_RIDE_RUIN_CENTS,
  PATH_RIDE_CATASTROPHIC_CENTS,
  PATH_RIDE_CATASTROPHIC_SUSTAIN_MS,
  SECONDARY_EXIT_CLUSTER_OBSERVE,
  holdHardFloorMaySell,
  isStrikePin,
  isGammaGetout,
  last1mRangeDollars,
  pathRidePlus50TargetCents,
  pathRideTwoXTargetCents,
  remainingVolDollars,
  tagPathRideFill,
} from "./path-ride.js";
import {
  decideExit,
  decidePathRideExit,
  classifyExitDecision,
  leftoverExitStackMayRun,
  leftoverExitStackMayRunOnPathRide,
  leftoverExitStackRun,
} from "./organs/exit-policy.js";
export {
  PATH_RIDE_EXIT_BOOK,
  decidePathRideExit,
  isPathRideOpenTrade,
  pathRidePlus50TargetCents,
  pathRideTwoXTargetCents,
  tagPathRideFill,
};
import { is15mDeskEvaluateAllowed, hourlyOrPerpEvaluateAllowed } from "./15m-product.js";
import { decideSettlementSideLogged, paperMoneyMakerLagMinAbsDollars, paperMoneyMakerHarvestExempt, isHarvestSessionFamilyAllowed, paperMoneyMakerIgnoresSettlementSideSkip, /* F4_REMAKE_UNSTARVE */ paperPathRidePreservesThroughSettlementSkip, isPathRideKellyStrategyId, isMoneyMakerStrategyId, isRemakeSettlementSideSkip, isOriginalSettlementSideLock, moneyMakerIgnoresOverpayGate, leftoverYesAskIsPoison, leftoverRegimeBlockPlacesMoneyMaker, filterPoolToMtfAlignedCheap, isMtfAlignedCheapTake, mtfAlignedCheapWantSignal } from "./settlement-side.js";
export { paperPathRidePreservesThroughSettlementSkip, paperMoneyMakerIgnoresSettlementSideSkip, isRemakeSettlementSideSkip, isOriginalSettlementSideLock, moneyMakerIgnoresOverpayGate };
import {
  // buildMoneyGateCard / moneyMakerIgnoresPathGateSkip calls live in admit15m + entryPathAndSize;
  // names kept imported for BOT-string freezes + demoteMoneyGateCardToSit use.
  buildMoneyGateCard,
  demoteMoneyGateCardToSit,
  sessionClockLabel,
  type MoneyGateCard,
  evaluatePathDecision,
  getPathConfig,
  computeTradeEV,
  moneyMakerIgnoresPathGateSkip,
  evaluateEntryEVGate,
} from "./organs/path-gate.js";
void buildMoneyGateCard;
void moneyMakerIgnoresPathGateSkip;
import {
  // admit15m owns alignedTakeGate / overlay / direction_w2 compose (15m + hourly).
  formatConstructedNoLog,
  formatDirectionW2Log,
  snapshotLastW2Log,
  shouldEmitDirectionW2Log,
  createDirectionW2LogThrottleState,
} from "./organs/side-lock.js";
import {
  alignedTakeGate,
  inStillMidCoinFlip,
  sweptFillHitsStillMid,
  STILL_MID_UNCLEAR_SKIP,
} from "./aligned-take-gate.js";
import {
  PAPER_SCALP_STRATEGY_ID,
  PAPER_SCALP_FEE_NET_BEATS_SKIP,
  applyPaperScalpAfterSettlement,
  decidePaperScalp,
  obsToTickQuote,
  type PaperScalpEvalResult,
  type TickQuote as PaperScalpTickQuote,
} from "./paper-scalp.js";

import {
  HARD_RISK_LIMITS,
  EV_FLOOR,
  applyHardRiskLimits,
  canScaleIntoPosition,
  computeContracts as computeKellyContracts,
  kellyPayoutRatio,
  computeKellyEdge,
} from "./organs/size.js";
import {
  OTM_EV_FLOOR,
  MIN_EDGE_OVER_MARKET,
  scoreStrategyEV,
  estimateTradeEV,
  pWinFromCurve,
} from "./admission.js";
import {
  isPaperDeskV2Placeable,
  selectDeskWinner,
  preferInBandCheapWing,
  inDeskAskBand,
  passesDeskDoor,
  DESK_SIGNAL_STACK_BONUS,
  PAPER_DESK_V2_PLACEABLE_IDS,
} from "./paper-desk-v2.js";
export {
  HARD_RISK_LIMITS,
  EV_FLOOR,
  OTM_EV_FLOOR,
  applyHardRiskLimits,
  canScaleIntoPosition,
  kellyPayoutRatio,
  computeKellyEdge,
};
export { computeContracts } from "./organs/size.js";
export { evaluateEntryEVGate } from "./organs/path-gate.js";
export type { EntryEVGateResult, EntryEVGateCode } from "./organs/path-gate.js";

import { frozenSixGateIsOnlyEvaluatePath, leftover15mEvaluateMayRun } from "./frozen-six-gate-evaluate.js";
import { leftoverHourlyEvaluateMayRun, leftoverHourlyEvaluateRun } from "./leftover-hourly-evaluate.js";
import { leftoverHourlyEvaluateFunnel } from "./leftover-hourly-funnel.js";
import { leftoverAddEvaluateMayRun, leftoverAddEvaluateRun } from "./leftover-add-evaluate.js";
import { leftoverAddEvaluateFunnel } from "./leftover-add-funnel.js";
import { leftover15mEvaluateFunnel } from "./leftover-15m-funnel.js";
import { leftover15mEvaluateRun } from "./leftover-15m-evaluate.js";
import { leftoverLiveOrderMayRun, leftoverLiveOrderRun } from "./leftover-live-order.js";
import { leftoverLivePlaceFunnel, leftoverLiveExitFunnel } from "./leftover-live-order-funnel.js";
import { leftoverLiveUnfilledFunnel } from "./leftover-live-unfilled-funnel.js";
import { leftoverLiveUnfilledHelpers } from "./leftover-live-unfilled.js";
import {
  leftoverLivePollOrderFillStatus,
  leftoverLiveFetchEntryOrderStatus,
  leftoverLiveCancelPartialEntryRemainder,
} from "./leftover-live-fill-status-funnel.js";
import { leftoverExitStackFunnel } from "./leftover-exit-funnel.js";
import {
  isPaperReleaseStrategyAllowed,
  paperReleaseOrderBlockReason,
  applyPaperReleaseConfigShape,
} from "./paper-release-policy.js";
import {
  paperDeskSizeMult,
  paperDeskConvictionMult,
  paperDeskMakerFillMayRun,
} from "./paper-size-lock.js";
import { evaluate15mAdmissionEnvelope } from "./decision-envelope.js";
import { directorSkipAbortsEvaluate, classifyDirectorSkipTaxonomy } from "./organs/director-skip.js";
import {
  unionMain15mEvaluateDisabled,
  paperScalpRunsOnMain15mEvaluate,
  paperScalpOffMainEvaluateReason,
  paperDeskAddToPositionMayRun,
} from "./evaluate-15m-scope.js";
import { unionFrozenEvaluateDisabled } from "./frozen-cc.js";
import { lockSide } from "./organs/lock-side-context.js";

import {
  LOCKED_DISABLED_STRATEGIES,
  HARD_NO_FILL_STRATEGY_IDS,
  isHardNoFillStrategy,
  LEFTOVER_PLACEORDER_DENYLIST,
} from "./hard-no-fill.js";
export {
  LOCKED_DISABLED_STRATEGIES,
  HARD_NO_FILL_STRATEGY_IDS,
  isHardNoFillStrategy,
  LEFTOVER_PLACEORDER_DENYLIST,
};
import {
  selectBestEnabled,
  selectPaperDeskWinnerFromPool,
} from "./select-best-enabled.js";
export {
  selectBestEnabled,
  selectPaperDeskWinnerFromPool,
} from "./select-best-enabled.js";

// How often a basis-tracker sample is written to durable storage for offline
// lag/basis analysis. Matches basis-tracker.ts's own console-log cadence so
// this stays far below the 500ms tick rate.
const BASIS_PERSIST_INTERVAL_MS = 45_000;

// ── External-close reconciliation ───────────────────────────────────────────
// How often (while a real, non-paper trade is open) we poll Kalshi's own
// portfolio/positions for the true contract count on that ticker. Guards
// against the bot continuing to manage a position the user already closed
// by hand in the Kalshi app/mobile UI.
const POSITION_RECONCILE_INTERVAL_MS = 10_000;
// Account-wide polling is intentionally slower than the ticker-specific
// external-close check. It catches positions that have no corresponding
// openTrade, including exposure left behind by an interrupted re-quote.
export const ACCOUNT_POSITION_RECONCILE_INTERVAL_MS = 15_000;
// A mismatch must be confirmed on this many consecutive reconcile cycles
// before we act on it — a single sample could be a timing race (e.g. our
// own fill landing between reads), not a real external close.
const POSITION_MISMATCH_CONFIRM_STRIKES = 2;
// Task (2026-08-14 bug investigation): a DB audit found ~39 trades force-
// closed within 13-20s of opening via the EXTERNAL_CLOSE_BALANCE_INFERRED
// path — almost exactly POSITION_RECONCILE_INTERVAL_MS × POSITION_MISMATCH_
// CONFIRM_STRIKES after entry, with no actual manual close involved. Root
// cause: Kalshi's portfolio/positions endpoint can lag a few seconds behind
// a just-filled entry order, and reconciliation could start checking a trade
// the instant it opened (the throttle is keyed off the LAST check overall,
// not this trade's age), so a brand-new position could read as "missing" for
// two consecutive polls before Kalshi's own ledger caught up. Most of these
// were harmless $0 no-ops, but a handful produced real losses (-$8.30 on
// 2026-08-13 alone). This grace period blocks reconciliation from acting on
// a trade until it's had time to settle in Kalshi's own position record —
// genuine manual closes are still caught, just ~30s slower to detect, which
// is immaterial for that use case.
const ENTRY_RECONCILE_GRACE_MS = 30_000;

import {
  kalshiSameSidePosition,
  computeBalanceInferredOutcome,
  isBalanceInferredPnlPlausible,
  computeGuardedBalanceAfterCents,
  isPositionMismatch,
  classifyAccountPositionState,
  computeExternalCloseClosedContracts,
  computeExternalCloseExitPriceCents,
  hasKalshiOpeningFill,
  computeOpeningFillStats,
  estimatePaperSlippageCents,
  fetchKalshiOpeningFillData,
} from "./account-position.js";
import type { KalshiFill } from "./account-position.js";
export {
  kalshiSameSidePosition,
  computeBalanceInferredOutcome,
  isBalanceInferredPnlPlausible,
  computeGuardedBalanceAfterCents,
  isPositionMismatch,
  classifyAccountPositionState,
  computeExternalCloseClosedContracts,
  computeExternalCloseExitPriceCents,
  hasKalshiOpeningFill,
  computeOpeningFillStats,
  estimatePaperSlippageCents,
  fetchKalshiOpeningFillData,
} from "./account-position.js";
export type { KalshiFill } from "./account-position.js";

import { predictionLearner } from "./prediction-learner.js";
import { buildMetaFeatures, recordMetaDecision, recordSkippedMetaExample, resolveTakenMetaExample } from "./meta-labeling.js";
import {
  classifyDetailedCondition,
  getConditionOverrides,
  CONDITION_META,
  type DetailedCondition,
  type AdaptiveConditionResult,
} from "./condition-adapter.js";
import type { PreTradeVerdict } from "./pre-trade-sim.js";
import { periodRecorder, currentPeriodOpenTs } from "./period-recorder.js";
import { recordMarketObservation } from "./market-learning.js";
import type { ChannelInfo, StrategyId } from "./strategy-library.js";
import { getStrategy } from "./strategy-library.js";
import {
  updateRegime, getRegime, getGrokRegimeFromDetailed, getRegimeDebug, getRegimeHeldBy,
  type GrokRegime, type RegimeId,
} from "./regime-engine.js";
import { generateTraceId, mapToClosedCode, persistDecisionTrace, persistDecisionTraceEvent, clearAriaCoalesceCache, type ClosedSkipCode, type DecisionTraceEvent } from "./decision-trace.js";
import {
  AGENT_FLOORS,
  applyDirectiveToState,
  consumeSkipNext,
  decideAgentEntryGate,
  emptyDirectiveState,
  isPendingExpired,
  newPendingAgentEntry,
  refuseAgentAuthorityWhenNotPaper,
  validatePendingApprove,
  type AgentDirective,
  type DirectiveState,
  type PendingAgentEntry,
} from "./agent-control.js";
import {
  applyBestPaperAutopilotSettings,
  decisionKindFromSide,
  refuseAutopilotWhenNotPaper,
  stampAutopilotDecision,
  type AutopilotDecisionStamp,
} from "./paper-autopilot.js";
import {
  evaluateSpecialistPackShadow, type ShadowPackEvaluation, type SpecialistPacksMode,
  getPack, computeWouldEligible, type SpecialistPack, type PackId,
  filterPoolByPack, computePackConfFloor, computePackCombinedMult,
  computeConsensusDisabledIds,
} from "./specialist-packs.js";
import { computeAutoModeV2Suggestion, type AutoModeV2Suggestion } from "./automode-v2.js";
import { computeAdaptation, echoOperatorFloors, applyBotFillLearning, freshLagDisagreeSkip, type AdaptationResult } from "./automode-adapter.js";
import { lagAgreesWithSide } from "./lag-meter.js";
import { VelocityReversalDetector } from "./velocity-reversal-detector.js";
import { recordBounceTick, getBounceInfo, getBounceConfidenceBonus } from "./bounce-level-tracker.js";
import { updateStructureReversal } from "./structure-reversal.js";
import { computeBollingerBands, BollingerSqueezeTracker } from "./bollinger-bands.js";
import { settlementPredictor } from "./settlement-predictor.js";
import { expertAgent } from "./expert-agent.js";
import type { AgentAssessment, AgentSetupControls } from "./expert-agent.js";
import { appendLog, getRecentLogs, loadPersistedLogs } from "./bot-log-store.js";
import { botUptimeLog } from "./bot-uptime-log.js";
import { hourlyPoller } from "./kalshi-1h-poll.js";
import type { Hourly1HTick } from "./kalshi-1h-poll.js";
import { loadPersistedConfig, savePersistedConfig, mergeDiskFrozenCcMode } from "./config-persist.js";
import { buildEntryReason, buildExitReasonText, generateTradePostmortem } from "./trade-narrative.js";
import { persistSettledBotStory } from "./trade-story.js";
import { storyStampFromCloseState, STORY_STAMP_INCOMPLETE, type StoryStampPayload } from "./organs/story-stamp.js";
import {
  decideFrozenCcMindBind,
  MIND_HEAVE_ADVISORY,
  admissionMatchesPlaceOrder,
  settleHonestyTags,
} from "./organs/mind-place-bind.js";
import { kalshiSettleFromTruth, isExpirySettleReason, labeledCanonicalAndModel } from "./kalshi-settle-label.js";
import {
  decideMoneyPath,
  snapshotTape,
  tagPaperFill,
  pathRideMonitorDisposition,
  pForStrategyAtAsk,
  observeAdaptiveRegime,
  fillPathRegimeTraceFields,
  planMakerEntry,
  bookImbGate,
  direction_lock,
  overlayDirectionLock,
  formatDirectionLockLog,
  shouldBlockPlaceOrderWithoutOrganTake,
  stampOrganTakeFromReport,
  pathRideOrganSkipBlocksEvaluate,
  shouldWriteOrganTakeModelProb,
  resolveOrganBestOrMismatch,
  DIRECTOR_TAKE_REQUIRED,
  ORGAN_BEST_MISMATCH,
  FROZEN_ORGANS_ADVISORY,
  formatDirectorTakeRequiredDesc,
  withExitMonitorFields,
  demoteTakeIfStale,
  stampSensorMsg,
  stampAdmissionMsg,
  stampSettleMsg,
  evaluateStructuralRuinShadow,
  toStructuralRuinShadowStamp,
  recordStructuralRuinShadowObservation,
  emptyStructuralRuinShadowCounters,
  interpretBrainCenter,
  recordBrainEpisode,
  brainMindPulse,
  buildLearningSnapshot,
  getBrainEpisodeRing,
  diagnoseMind,
  applyMindHeal,
  pickHealTarget,
  SELF_HEAL_THROTTLE_MS,
  recordScar,
  stampScarFillHonesty,
  closeScar,
  matchEchoes,
  persistScar,
  getScarRing,
  scarEchoLearningSnapshot,
  askBandFromCents,
  attributeSettleCausal,
  recordCalibrationObs,
  type BrainCenterReport,
  type LastSelfHealStamp,
  type ScarEntryBind,
  type AdaptiveRegimeSnapshot,
  type OrganReport,
  type TapeSnapshot,
  type AdmissionMsg,
  type Freshness,
  type ExitMonitorStamp,
  type StructuralRuinShadowStamp,
  type StructuralRuinShadowCounters,
  type SensorMsg,
  type SettleMsg,
  type GovernanceMsg,
} from "./organs/index.js";
import { bindSideWinRateAtPrice } from "./organs/filled-side.js";
import { honestPWin } from "./evaluate-decision-tape.js";
import {
  applyPathAwareContracts, applyAsianHoursMoneyMakerFloor, applyAriaPathRules, isAriaDangerVeto,
  buildModeState, applyRiskProfileSizing,
  evaluateEntryGuards, evaluateRichAskBlock, isPathBlockedForTimeOfDay,
} from "./trade-path.js";
import type { AriaAssessment, ModeState, RiskProfile } from "./trade-path.js";
import {
  kalshiFeeCents, kalshiTakerFeeCents, kalshiMakerFeeCents, kalshiBreakevenWinRate, expectedRoundTripFeeCents, kalshiFeePctOfCost, kalshiNetWinCents, kalshiNetCostCents,
  KALSHI_MAKER_FEE,
  THIN_BOOK_CUTOFF_SECS, BTC_FLOOR_FALLBACK,
} from "./constants.js";
import {
  computeTargetEngine, etDateKey, loadOrCreateDayRow, updateDayRow,
  dailyTargetEntryBlock, persistLatchDurably, computeCashFlowReconciliation,
  type DailyTargetStatus, type ProtectBehavior,
} from "./daily-target.js";
import { insertAutoCashFlowEvent } from "./cash-flow.js";
import { computeVolumeScore, getVolumeSizeMult, VOLUME_BUCKET_POLICY, warmVolumeRiskCache, recordVolumeBucketSettlement } from "./volume-risk.js";
import type { VolumeBucket } from "./volume-risk.js";
import { incrementDailyFillStats, loadDailyFillStats } from "./daily-fill-stats.js";
import { computeMarketState, updateVelocityEma, type MarketState } from "./market-state.js";
import { getFamilyPolicy } from "./family-policy.js";
import { buildBookSnap, evaluateLiquidity, logLiquidityDecision } from "./liquidity-policy.js";
import type { StopRewardPlan } from "./stop-reward.js";
import {
  evaluateAriaGuardianPolicy, parseAriaDecision, isAriaExitAllowed, shouldEvaluateAriaGuardian,
  clampTighten, logAriaGuardianDecision, ARIA_HARD_STOP_PROXIMITY_CENTS,
  type AriaContext, type AriaDecision, type AriaTighten, type BookClass, type LiqAction,
} from "./aria-guardian.js";

// ── Realized-outcome confidence calibration: DISABLED (money-safety gate) ────
// A "realized-outcome confidence calibration" (predictionLearner
// .getConfidenceCorrection) was wired into the live sizing path here and on the
// 1h path. It is INVALID as built and must NOT move money:
//   - The number it produced was a GLOBAL settlement-direction ARROW accuracy,
//     not the per-strategy pre-trade confidence it was scaling. It is not
//     strategy-conditioned, not duration-conditioned, not price-conditioned,
//     and did not even measure the same quantity that it corrected.
//   - It fed Kelly SIZING, and it self-reinforces: correcting confidence changes
//     which trades fire, which changes the population being measured.
// The ±12pt clamp and n>=50 floor bounded the damage but did not make it valid.
//
// It stays OFF behind this flag. The measurement KEEPS running and is logged
// (prediction-learner now accumulates the RIGHT data: emitted sim_verdicts
// confidence vs each verdict's REALIZED outcome, stratified by strategyId AND
// duration bucket) so a future, properly-conditioned correction can be built.
//
// DO NOT flip this to true until a per-(strategy,duration[,price]) calibration
// has been PROVEN out-of-sample to improve realized P&L, on the sim_verdicts
// data (not settlement-arrow accuracy). Global un-conditioned correction is
// never acceptable on live money.
//
// Exported ONLY so a unit test can prove it is off; nothing should read it as a
// mutable switch.
export const CONFIDENCE_CALIBRATION_ENABLED = false;

// ── Types (extracted to trading-bot-types.ts) ────────────────────────────────
export type {
  AccountPositionSnapshot,
  BotState,
  BotConfig,
  EntryFilterKey,
  EffectiveEntryFilterValues,
  AgentFilterOverrideStatus,
  BotLogEvent,
  KalshiTick,
  BotStatus,
  AutoDecision,
  OpenTrade,
  MindHeaveTag,
  ExitPriceBreakdown,
} from "./trading-bot-types.js";
import { decidePaperSettleSource } from "./paper-settle-source.js";
import { resolveOrphanResult, orphanSettlement, ORPHAN_SETTLED_KALSHI, ORPHAN_RESULT_UNKNOWN } from "./orphan-settle.js";
import { fetchMarketResultPublic } from "./shadow-calibration-sweep.js";
import { LogThrottle, throttleKey, EntryFunnelCounter, blockReasonBucket } from "./log-throttle.js";
import { appendEntryShadowVeto } from "./frozen-cc-entry-shadow.js";
import type {
  AccountPositionSnapshot,
  BotState,
  BotConfig,
  EntryFilterKey,
  EffectiveEntryFilterValues,
  AgentFilterOverrideStatus,
  BotLogEvent,
  KalshiTick,
  BotStatus,
  AutoDecision,
  OpenTrade,
  MindHeaveTag,
  ExitPriceBreakdown,
} from "./trading-bot-types.js";

import {
  isVolBufferRecovery,
  resolveEffectiveAgentEntryFilters,
  LIVE_CORE_STRATEGY_IDS,
  PAPER_TIER_A_STRATEGY_IDS,
  effectiveDisabledStrategies,
  placeOrderStrategyHardBlockReason,
  isStrategyOverrideDisabled,
  disabledStrategyOverrideWarning,
  getKalshiRejectionDetail,
  nextInvalidKalshiPriceTicks,
  getExitAttemptBackoffMs,
} from "./strategy-gates.js";
export {
  isVolBufferRecovery,
  resolveEffectiveAgentEntryFilters,
  LIVE_CORE_STRATEGY_IDS,
  PAPER_TIER_A_STRATEGY_IDS,
  effectiveDisabledStrategies,
  placeOrderStrategyHardBlockReason,
  isStrategyOverrideDisabled,
  disabledStrategyOverrideWarning,
  getKalshiRejectionDetail,
  nextInvalidKalshiPriceTicks,
  getExitAttemptBackoffMs,
} from "./strategy-gates.js";

/** Breakdown of prices used to detect a stop/profit exit. */

// ── Constants ──────────────────────────────────────────────────────────────────

// BTC price is now inferred from Kalshi WS (Black-Scholes inversion of YES probability)

// ── Fast-market execution constants ────────────────────────────────────────────
// FAST_VEL:      1-min velocity threshold ($/min) that triggers fast-market mode.
// SUSTAINED_V3:  3-min velocity that must agree before we treat a move as sustained.
//                If only the 1-min spike exists, it's a "fresh spike" — we block entry.
// SWEEP_PREMIUM: Extra cents above ask we pay so our limit sweeps through the book
//                rather than resting below the current offer depth.
//                Normal markets: 1¢ over ask to cross the spread.
//                Sustained fast markets: SWEEP_PREMIUM (2¢) to stay ahead of a moving book.
// MAX_CHASE:     How far (¢) the ask can move from our original price before we
//                give up on a re-quote after the 12-s cancel check.
//                Set > 0 to enable one re-quote attempt when the price moved but
//                not enough to make the trade unattractive.
const FAST_VEL      = 80;   // $/min
const SUSTAINED_V3  = 40;   // $/min 3-min avg
const SWEEP_PREMIUM = 2;    // ¢ above ask in sustained fast markets (was 1 — too tight; BTC can move 2-3¢ in the ~300ms between price read and order arrival)
const MAX_CHASE: number = 5;    // ¢ re-quote ceiling — allow chasing up to 5¢ of price movement on re-quote
const QUOTE_FRESHNESS_TOL_CENTS = 1; // post-sim ask-drift tol (¢)    // ¢ — max ask drift vs. decision-time quote tolerated after the pre-trade sim await, before placeOrder

/** ARIA input adapter → applyAriaPathRules shape. */
function buildAriaInput(a: AgentAssessment | null): AriaAssessment | null {
  if (!a) return null;
  return {
    confAdj:           a.confAdj,
    riskLevel:         a.riskLevel,
    reasoning:         a.reasoning,
    signal:            a.signal,
    sustainedHighRisk: expertAgent.isSustainedHighRisk(),
  };
}

// Auth: kalshi-auth.ts (DB-aware resolver).
export async function kalshiAuthHeaders(method: string, apiPath: string): Promise<Record<string, string>> {
  return kalshiAuthHeadersAsync(method, apiPath);
}

import {
  resolveEntryFillOutcome,
  isTerminalEntryOrderStatus,
  applyOrderbookDepthCap,
  resolveDepthAwareSizing,
  normalizeOrderbookLevels,
  fetchOrderbookDepthAtEntry,
  getVisibleDepthAtEntry,
  depthFromInMemoryOrderbook,
} from "./orderbook-depth.js";
import type {
  OrderbookDepthResult,
  OrderbookLevel,
  EntryFillDecision,
  EntryOrderStatusSnapshot,
  InMemoryOrderbookSnapshot,
} from "./orderbook-depth.js";
export {
  resolveEntryFillOutcome,
  isTerminalEntryOrderStatus,
  applyOrderbookDepthCap,
  resolveDepthAwareSizing,
  normalizeOrderbookLevels,
  fetchOrderbookDepthAtEntry,
  getVisibleDepthAtEntry,
  depthFromInMemoryOrderbook,
} from "./orderbook-depth.js";
export type {
  OrderbookDepthResult,
  OrderbookLevel,
  EntryFillDecision,
  EntryOrderStatusSnapshot,
  InMemoryOrderbookSnapshot,
} from "./orderbook-depth.js";

import {
  normCDF,
  realizedVolFromBuffer,
  resolveAddPositionVolatility,
  probabilityEdge,
  detectStallInfo,
  computeVolumeState,
  linReg,
  computePriceChannel,
} from "./tick-sensors.js";
export {
  resolveAddPositionVolatility,
  probabilityEdge,
} from "./tick-sensors.js";

import {
  MIN_REWARD_RISK_RATIO,
  computeStopRewardPlan,
  computeNormalTargetProfitCents,
  shouldEnforceNormalTradeStop,
  preserveEntryTargetFloor,
  evaluateHardStopDecision,
  evaluateStopLossDecision
} from "./stop-reward.js";
export {
  MIN_REWARD_RISK_RATIO,
  computeStopRewardPlan,
  computeNormalTargetProfitCents,
  shouldEnforceNormalTradeStop,
  preserveEntryTargetFloor,
  evaluateHardStopDecision,
  evaluateStopLossDecision
} from "./stop-reward.js";

export { isMoneyMakerThesisHold } from "./fill-origin.js";

/** position-admission organ — bodies in organs/position-admission.ts (Arch peel #3). */
import {
  POSITION_ADMISSION_LOADED,
  POSITION_ADMISSION_NOT_LOADED,
  formatPositionAdmissionLoadedLog,
  evaluateUnmanagedPositionCheck,
  shouldRecheckPositionIncidentInPaperMode,
  evaluateAutoStartDecision,
  shouldBlockSecondPosition,
  shouldBlockSameTickerPaperFill,
  shouldFailClosedOnPaperPendingQueryError,
  PAPER_PENDING_QUERY_MAX_ATTEMPTS,
  shouldRetryPaperPendingQueryBeforeLatch,
  shouldClearHeldPendingAfterEmptySelect,
  shouldReproveHeldPendingViaSelect,
  ORPHAN_OPEN_CLEARED_VOID,
  STARTUP_ORPHAN_VOID,
  shouldVoidStartupOrphan,
  shouldRehydratePaperOpenTrade,
  shouldKeepOpenTradeAfterSettlePersistFail,
  shouldVoidOrphanOpenCleared,
  isPendingStillLive,
  isAuthSigningFailed,
  makeTraceScopedSkip,
} from "./organs/position-admission.js";
export {
  POSITION_ADMISSION_LOADED,
  POSITION_ADMISSION_NOT_LOADED,
  formatPositionAdmissionLoadedLog,
  evaluateUnmanagedPositionCheck,
  shouldRecheckPositionIncidentInPaperMode,
  evaluateAutoStartDecision,
  shouldBlockSecondPosition,
  shouldBlockSameTickerPaperFill,
  shouldFailClosedOnPaperPendingQueryError,
  PAPER_PENDING_QUERY_MAX_ATTEMPTS,
  shouldRetryPaperPendingQueryBeforeLatch,
  shouldClearHeldPendingAfterEmptySelect,
  shouldReproveHeldPendingViaSelect,
  ORPHAN_OPEN_CLEARED_VOID,
  STARTUP_ORPHAN_VOID,
  shouldVoidStartupOrphan,
  shouldRehydratePaperOpenTrade,
  shouldKeepOpenTradeAfterSettlePersistFail,
  shouldVoidOrphanOpenCleared,
  isPendingStillLive,
  isAuthSigningFailed,
  makeTraceScopedSkip,
};

// Feed-stale predicates live in feed-stale.ts (re-export back-compat).
import {
  FEED_STALE_TICK_MS,
  FEED_STALE_QUOTE_MS,
  MAX_QUOTE_AGE_MS,
  isFeedStaleForEntry,
  isQuoteStaleForExit,
} from "./feed-stale.js";
export {
  FEED_STALE_TICK_MS,
  FEED_STALE_QUOTE_MS,
  MAX_QUOTE_AGE_MS,
  isFeedStaleForEntry,
  isQuoteStaleForExit,
};

/** Remove DB-before-API intent after definitive order rejection. */
export async function deleteTradeIntent(dbId: number): Promise<void> {
  await db.delete(botTrades).where(eq(botTrades.id, dbId));
}

// Uppity R3 peel re-exports (admission / entry-guards / position-admission)
import {
  resolve15mCloseTimeMs,
  paperSettlementRefPrice,
  blendedEntryPriceCents,
  pWinAtPrice,
  pWinAtPriceRejectingThinLearner,
  fillPathPWin,
  mtfCompositeLockAllowsSide,
  apply15mSettlementSideBeforeSize,
  isProtectiveShrinkActive,
  applyPackSizeCap,
  evaluatePortfolioRiskBand,
  detectGrokRegime,
  passesHardFilters,
  detectBreakoutFakeout,
  otmAwareMTFThresholds,
  settlementHoldOverrideEligible,
  settlementHoldEVEligible,
  isHoldToSettlementExempt as holdToSettlementExemptFromAdmission,
  isStrategyAllowedInRegime,
  passesStrategyRegimeFilter,
  isReversalCapable,
  applyStrongMTFDirectionLock,
  warnOnOrphanedStrategiesAtStartup,
  resolveTradeRegimeForPersistence,
  basisLagRegimeGateOk,
  settlementVetoOpposes,
  metaLabelConfidence,
  getETParts,
  getSecsRemaining,
  getPeriodKey,
  tradeSecsRemaining,
  type SizingResult,
} from "./admission.js";
export {
  resolve15mCloseTimeMs,
  paperSettlementRefPrice,
  blendedEntryPriceCents,
  pWinAtPrice,
  pWinAtPriceRejectingThinLearner,
  fillPathPWin,
  mtfCompositeLockAllowsSide,
  apply15mSettlementSideBeforeSize,
  isProtectiveShrinkActive,
  applyPackSizeCap,
  evaluatePortfolioRiskBand,
  detectGrokRegime,
  passesHardFilters,
  detectBreakoutFakeout,
  otmAwareMTFThresholds,
  settlementHoldOverrideEligible,
  settlementHoldEVEligible,
  isStrategyAllowedInRegime,
  passesStrategyRegimeFilter,
  isReversalCapable,
  applyStrongMTFDirectionLock,
  resolveTradeRegimeForPersistence,
  basisLagRegimeGateOk,
  settlementVetoOpposes,
};
import {
  evaluatePostSimQuoteFreshness,
  evaluateDailyLossHalt,
  TICK_IDLE_INTERVAL_MS,
  TICK_MIN_INTERVAL_MS,
  BALANCE_STALE_MS,
} from "./organs/entry-guards.js";
export {
  evaluatePostSimQuoteFreshness,
  evaluateDailyLossHalt,
  TICK_IDLE_INTERVAL_MS,
  TICK_MIN_INTERVAL_MS,
};

import type {
  ExitFillDecision,
  SettlementFallbackDecision,
} from "./organs/position-admission.js";
import {
  resolveExitLegOutcome,
  resolveAddFillOutcome,
  computePartialExitLegEconomics,
  combineSettlementWithPriorPartial,
  resolveSettlementFallbackOutcome,
} from "./organs/position-admission.js";
export type {
  ExitFillDecision,
  SettlementFallbackDecision,
};

/** Hold-to-settlement exempt — body in admission; wrapper keeps BOT_SRC freeze. */
export function isHoldToSettlementExempt(trade: { isOTMAsymmetry?: boolean; strategyId?: string | null }): boolean {
  // CHEAP_SIDE_15M | PAPER_SCALP | CHEAP_EARLY_EXIT | PANIC_FADE | STREAK_SAT_FADE | TICKET_WAVE
  return holdToSettlementExemptFromAdmission(trade);
}

export {
  resolveExitLegOutcome,
  resolveAddFillOutcome,
  computePartialExitLegEconomics,
  combineSettlementWithPriorPartial,
  resolveSettlementFallbackOutcome,
};


export class TradingBot {
  state: BotState = "IDLE";

  config: BotConfig = {
    enabled:               false,
    autoMode:              false, // default off in class field; disk may persist true as ADAPTATION. Desk on = enabled + paper. Aria is useExpertAgent.
    autoModeV2Mode:        'suggest', // GO — STEP 5 PHASE A (2026-08-22): suggest-only, no live gate writes.
    maxContractsPerTrade:  60,
    maxDepthFraction:      MAX_DEPTH_FRACTION,
    dailyLossCapCents:     3000, // $30 floor — live desk halt is max(this, 10% of balance); 150 was a toy
    dailyLossCapPct:       10,   // see effectiveDailyLossCapCents() — 2026-08-11
    minConfidence:         1,    // PAPER DESK v2: demoted — not a gate for the six
    minVelocity:           0,    // PAPER DESK v2: demoted
    tradeWindowMinMin:     0.2,  // discretionary entry-window timer removed per user request 2026-08-05 —
                                  // only the 10s physical HARD_CUTOFF_SECS floor remains (see computeEffectiveWindow)
    tradeWindowMaxMin:     15,   // entries allowed from the start of the 15-min contract onward
    maxEntryPrice:         55,
    minEntryPrice:         20,   // desk door floor YES/NO ≥20 (side-aware band same)
    useProbEdge:           false, // PAPER DESK v2 demoted
    minProbEdge:           0,    // PAPER DESK v2 demoted
    useStallFilter:        false,
    useAcceleration:       false,
    useLossCooldown:       false, // Stellar 2026-09-10: 2-loss cool-down removed
    cooldownMultiplier:    1.5,
    paperMode:             true,
    useKellySizing:        true,
    useMultiTfConfluence:  true,
    paperStartingBalanceCents: 31_300, // operator paper desk starting equity; must survive a deleted .bot-config.json
    // v5
    useMTFFilter:           true,
    useStrongMTFDirectionLock: false, // PATH_RIDE force OFF
    minMTFScoreForLong:     0,   // was 1, before that 2 (2026-08-03: neutral-or-better is enough for a YES entry)
    maxMTFScoreForShort:    0,  // was -1, before that -2 (2026-08-03: neutral-or-better is enough for a NO entry)
    useStopLoss:            false, // PATH_RIDE force OFF
    stopLossCents:          22,  // was 15 — wider to ride volatility
    hardStopCents:          38,  // was 28
    minRewardRiskRatio:     0,    // PAPER DESK v2 demoted
    useDynamicStop:         false, // PATH_RIDE force OFF
    useProfitTake:          false, // PATH_RIDE force OFF
    profitTakeCents:        20,  // was 12 — higher initial target
    trailingProfitCents:    12,  // was 8 — wider trailing band
    useDynamicProfit:       false, // PATH_RIDE force OFF
    useTimeDecayExit:       false, // PATH_RIDE force OFF
    useAddToPosition:       false, // PAPER DESK v2
    addConfidenceThreshold: 80,
    useKellyFraction:       true,
    useDrawdownGuard:       true,
    drawdownGuardPct:       20,
    reservePct:             15,
    useCompoundMode:        true,
    // v6 — Grok
    usePctStops:            false, // PATH_RIDE force OFF
    softStopPct:            55,  // was 40 — allow more adverse movement before soft stop
    hardStopPct:            72,  // was 55 — hard stop further out for volatile binary options
    useTimeStop:            false, // PATH_RIDE force OFF
    timeStopMinutes:        2.5,
    timeStopMinGainCents:   8,
    useTieredSizing:        false,
    baseRiskPct:            4,
    usePortfolioRisk:       true,
    portfolioRiskPct:       6,   // was 5 — recalibrated 2026-08-11 so typical qualifying
                                  // trades (see confMult tiers below) realize ~5-7% effective
                                  // risk per trade, per explicit target. Still bounded well
                                  // under the 9%-of-equity HARD_RISK_LIMITS ceiling, which is
                                  // untouched.
    useSignalStackSizing:      true,
    signalStackBonusMult:      1.00, // PAPER DESK v2
    signalStackBasisThreshold: 5,
    // Legacy persisted values. The mandatory Eastern time-of-day regime now owns
    // liquidity-hour controls and does not read these values.
    useSessionLiquiditySizing: true,
    sessionLiquidityMult:      1.0,  // PAPER DESK v2
    configSchemaVersion:    3,
    // P&L Track reset
    equityCurveResetAt:     0,
    // Per-strategy toggles — VELOCITY_STALL_REVERSAL (Task #338) ships disabled:
    // it's an unproven manual pattern and must be explicitly re-enabled after review.
    //
    // 2026-08-27 paper fail-close: LATE_ENTRY_ANCHOR joined this list after a
    // third wrong-side paper fill (YES 1x@65¢, thesis-broke −7¢, settled NO).
    // Same family as SETTLEMENT_PREDICTION: paper-disabled via this default
    // list, NOT a SEV1 lock (not in LOCKED_DISABLED_STRATEGIES) and no new
    // enable* flag. The existing size-rescue map may still name LATE_ENTRY as
    // rescue-eligible; that only matters if it fills, and selectBestEnabled
    // cannot pick a disabled strategy.
    //
    // 2026-08-02 investigation note: an isolated historical backtest (4,000
    // scenarios/strategy, real 2021-2025 BTC data) found FLOOR_DISTANCE and
    // LATE_ENTRY_ANCHOR average slightly negative P&L (-1.6 to -1.8¢/trade)
    // blended across ALL their entries, including ones priced above the
    // existing maxEntryPrice (55¢) ceiling — entries the live bot already
    // refuses to take. Disabling them outright was tried and reverted at the
    // time: they were the ONLY strategies on the 'ranging'/'low_vol' regime
    // allowlist besides the already-quarantined BRTI_PROBABILITY. LATE_ENTRY
    // is fail-closed on paper (this list). 2026-08-27 PhD audit: VELOCITY_MOMENTUM,
    // CHANNEL_BOUNCE, MEAN_REVERSION_STRETCH, FAKEOUT_FADE, FLOOR_DISTANCE,
    // BREAKOUT_CAPTURE, EXHAUSTION_ANCHOR, SQUEEZE_EXPANSION join the same
    // family (PATCH_FAIL_CLOSED_DISABLED). Not SEV1. CHEAP_SIDE_15M +
    // BASIS_LAG_EDGE + CONFLUENCE_CASCADE stay paper-eligible.
    // MTF_ALIGNED (Task: master bot upgrade, step 1A) manually quarantined —
    // known toxic live record (~37.5% WR, negative P&L) well before the DB
    // performance gate's minimum-sample threshold would auto-disable it.
    // Do not remove until a separate retune + walk-forward review clears it.
    disabledStrategies:     [
      'VELOCITY_STALL_REVERSAL',
      'MTF_ALIGNED',
      'LATE_ENTRY_ANCHOR',
      // PAPER DESK v2: VELOCITY_MOMENTUM + BRTI placeable — not default-disabled
      'CHANNEL_BOUNCE',
      'MEAN_REVERSION_STRETCH',
      'FAKEOUT_FADE',
      'FLOOR_DISTANCE',
      'BREAKOUT_CAPTURE',
      'EXHAUSTION_ANCHOR',
      'SQUEEZE_EXPANSION',
    ],
    // Expert Agent
    useExpertAgent:         false, // HARD LOCK: never default-enable ARIA live. Operator opts in.
    // '' = auto-select the strongest confirmed-live model each cycle (see
    // model-updater.ts getStrongestConfirmedModel + expert-agent.ts analyze()).
    // Set to a specific OpenRouter slug to pin ARIA to one model instead.
    ariaModel:              '',
    ariaIntervalSecs:       45,
    // Hold-to-settlement — suppress noise-driven exits, ride to expiry
    holdToSettlement:              false, // 15m doctrine: sell before expiry. CHEAP_SIDE especially must not ride.

    frozenCcMode:                  true,  // sweep K1: the locked desk runs frozen-CC; a missing config must not boot it off
    frozenCcFixedContracts:        null,
    frozenCcTakeProfitCents:       null,
    frozenCcCatastrophicCents:     FROZEN_CC_DEFAULT_CATASTROPHIC_CENTS,
    // LIVE AND sit: default false historically; live desk arms via .bot-config.json.
    frozenCcAndSit:                false,
    // Settlement hold
    // Research Factory (Step 7) shadow logger — OFF by default. When true, an
    // observational-only hook appends a line to data/research-shadow-log.jsonl
    // whenever the current tick's (ask, minutes-left) matches one of the
    // Research Factory's ranked candidate tiers. It never gates an entry,
    // never places an order, and never reads live decision state — flipping
    // this flag cannot change trading behavior, only whether this log grows.
    researchShadowLoggingEnabled: false,
    useSettlementHold:             false, // PATH_RIDE force OFF
    settlementHoldSecsThreshold:   540,   // engage within last 9 min — prefer riding to settlement
    settlementHoldMinProb:         0.58,  // was 0.65 — engage hold with moderate conviction
    settlementHoldMinGainCents:    0,     // must be at/above breakeven — never hold a red position on high modelProb alone
    // 1-hour OTM Breakout strategy — paper-only until proven live
    enable1HContracts:             false,
    enable1HLive:                  false,
    hourlyMaxContracts:            10,
    // Strategy override — null = auto-select best each tick
    strategyOverride:              null,
    maxContractVolatility:         8,    // skip entry when YES price has ranged >8¢ in last 2 min
    manualRiskProfile:             null, // null = auto-select from account health
    // Daily target engine — OFF by default. dailyTargetPct must never silently be 50
    // (that stand-down latch would halt a paper desk that didn't ask for it).
    useDailyTarget:                false,
    dailyTargetPct:                8,
    protectModeBehavior:           'stand_down',
    giveBackCapPct:                10,
    // Velocity Stall Reversal (Task #338) — small dedicated budget, strategy off by default.
    // velocityStallReversalEnabled is the independent safety gate (see effectiveDisabledStrategies) —
    // it must be explicitly flipped true; disabledStrategies alone is not sufficient.
    velocityStallReversalRiskBudgetCents: 250,
    velocityStallReversalEnabled:         false,
    // Task #445 — settlement prediction consensus/veto + Bollinger Band
    // strategy. settlementVetoEnabled/candlestickPatternLiveEnabled remain
    // OFF pending their own explicit review.
    // Unproven engines FAIL CLOSED (2026-08-27): SETTLEMENT_PREDICTION filled
    // paper NO 2x@48¢ on KXBTC15M-26AUG271500-00 and thesis-broke −14¢. Opt-in
    // gates stay in STRATEGY_OPT_IN_GATES so they cannot fire until explicitly
    // flipped true. NOT added to LOCKED_DISABLED_STRATEGIES (that's SEV1).
    // This is P&L protection, not an EV-floor cut. Proven book
    // (CONFLUENCE_CASCADE, BASIS_LAG_EDGE, CHEAP_SIDE_15M) is paper-eligible.
    settlementConsensusVoteEnabled:       false,
    settlementVetoEnabled:                false,
    settlementVetoMinConfidence:          80,
    bollingerBandStrategyEnabled:         false,
    candlestickPatternLiveEnabled:        false,
    // TOP_REVERSAL / BOTTOM_REVERSAL — same fail-closed opt-in as above.
    // RANGE/relevant packs still list them; they cannot fire until the gate
    // is explicitly true.
    topReversalEnabled:                   false,
    bottomReversalEnabled:                false,
    cheapSide15mEnabled:                  false,
    cheapEarlyExitEnabled:                false,
    panicFadeEnabled:                     false,
    streakSatFadeEnabled:                 false,
    // Packs stay OFF in code defaults so a deleted .bot-config.json cannot
    // silently re-arm enforce. Operator persisted config may opt in.
    specialistPacksMode:                  'off',
    // Agent control plane — defaults off in class; paper desk arms via .bot-config.json
    agentControlMode:                     false,
    requireAgentEntryApproval:            false,
    brainCenterAuthority:                 false,
    autopilotMode:                        false,
  };

  private prices:             { price: number; ts: number }[] = [];
  /** Rolling Kalshi ticket quotes for PAPER_SCALP ticket-velocity (dAsk/dMid, ~8s lookback). */
  private paperScalpQuotes:   PaperScalpTickQuote[] = [];
  // Task #338 — stateful multi-tick detector for VELOCITY_STALL_REVERSAL.
  // Owned by the bot (like fastReversalTicks etc.) because the pattern spans
  // many ticks; strategy-library.ts stays stateless by reading its verdict
  // off StrategyObservation.velocityReversal.
  private velocityReversalDetector = new VelocityReversalDetector();
  // Bollinger Band squeeze tracker — self-calibrating, needs continuous
  // per-tick history like velocityReversalDetector above; owned by the bot
  // for the same reason (spans many ticks, strategy-library.ts stays stateless).
  private bbSqueezeTracker = new BollingerSqueezeTracker();
  private openTrade:          OpenTrade | null = null;
  /** Agent control: parked TAKE awaiting approve (paper, requireAgentEntryApproval). */
  private pendingAgentEntry: PendingAgentEntry | null = null;
  /** Sticky agent directives (HALT / SKIP_NEXT / SIT_UNTIL). */
  private agentDirectives: DirectiveState = emptyDirectiveState();
  /** Latest autopilot YES/NO/SKIP stamp (paper, autopilotMode). */
  private lastAutopilotDecision: AutopilotDecisionStamp | null = null;
  /** Latest cortex report (updated in getStatus) for agent veto gate. */
  private lastBrainCenter: import("./organs/brain-center.js").BrainCenterReport | null = null;
  private lastBrainTickMs: number | null = null;
  /** Oracle Mind self-heal throttle + last stamp. */
  private lastSelfHealAtMs = 0;
  private lastSelfHeal: LastSelfHealStamp | null = null;
  private haltArmedAtMs: number | null = null;
  private feedStaleSinceMs: number | null = null;

  // Single-source-of-truth tracking for `openTrade`: when it was last
  // actually confirmed against Kalshi's own position record, distinct from
  // `lastPositionReconcileAt` below (which tracks the last reconcile
  // *attempt*, including failed/skipped ones). Reset to null whenever the
  // trade reference itself changes (opened/cleared) via setOpenTrade() —
  // every mutation of `openTrade` must go through that method, not a bare
  // assignment, or this tracking silently goes stale.
  private positionLastConfirmedAt: number | null = null;
  private tradedThisPeriod    = false;
  private lastPeriodKey       = "";
  private tickTimer:          NodeJS.Timeout | null = null;
  private balanceTimer:       NodeJS.Timeout | null = null;
  /** Slow account-wide live-position audit; separate from the fast tracked-ticker check. */
  private accountPositionReconcileTimer: NodeJS.Timeout | null = null;
  // ── Event-driven tick scheduling state ──────────────────────────────────────
  /** Unsubscribe from WS executable-quote wakes; null when not subscribed. */
  private _unsubQuoteWake:    (() => void) | null = null;
  /** Epoch ms when the most recent tick STARTED — used to enforce the min-interval floor. */
  private _lastTickStartTs    = 0;
  /** Pending coalesced-wake timer (fires the deferred tick after the floor elapses). */
  private _coalesceTimer:     NodeJS.Timeout | null = null;
  /** Keeps live balance fresh while the bot is OFF/idle — see ensureIdleBalancePolling(). */
  private idleBalanceTimer:   NodeJS.Timeout | null = null;
  private hourlyCheckTimer:   NodeJS.Timeout | null = null;
  private listeners           = new Set<(e: BotLogEvent) => void>();
  private lastSignalDesc      = "Waiting…";
  private lastSignalKey       = "";  // dedup: stratId:direction:entryBucket — same signal each tick
  private lastBlockKey        = "";  // dedup: path:blockReason — same block reason each tick
  private tickRunning         = false; // mutex: prevents concurrent 500ms ticks overlapping
  private lastPaperSettleResultFetchMs = 0; // GE_001: throttle Kalshi result reads (10s)
  private settlementCheckInFlight = false; // mutex: detectSettlement() can be entered from the tick loop AND forceSettleCheck() concurrently — see detectSettlement() (Task #301)
  // Settlement-fallback fix: timestamp of the FIRST tick where a live trade's
  // Kalshi settlement lookup failed/had no match. Reset (to null) whenever
  // openTrade changes via setOpenTrade() so a new trade always starts clean.
  // Used only to bound how long we retry before giving up as "unresolved" —
  // never used to infer a win/loss.
  private settlementUnresolvedSinceTs: number | null = null;
  private currentVelocity     = 0;
  private threeMinVelocity    = 0;
  private prevVelocity        = 0;   // velocity from the previous tick (for acceleration)
  private velocityAccel       = 0;   // $/min per tick: positive = momentum building
  /** Rolling sample history of currentVelocity, sampled every ~10s (not every 500ms tick) so the
   *  payload stays small (~1440 points over the full 4h retention) while still giving a real
   *  1h/30m/15m/5m/1m trend view AND (P3) enough depth for market-state.ts's 30m/2h/session
   *  velScale medians — the old 1h-only retention couldn't support the 2h window at all. */
  private velocityHistory:    { t: number; v: number }[] = [];
  private lastVelocitySampleTs = 0;
  /** P3 MARKETSTATE: EMA-smoothed velocity feeding zVel (market-state.ts computeZVel/updateVelocityEma).
   *  null until the first sample warms it up — computeMarketState falls back to raw v1 until then. */
  private velocityEma: number | null = null;
  /** P3 MARKETSTATE: last computed snapshot (either duration path), exposed on BotStatus/health. */
  private lastMarketState: MarketState | null = null;
  private todayStats          = { pnlCents: 0, wins: 0, losses: 0, date: "" };
  private otmStats            = { wins: 0, losses: 0, pnlCents: 0, totalPaidCents: 0, avgWinMultiple: null as number | null, _winMultipleSum: 0, _winCount: 0 };
  // Bot-owned OTM confluence telemetry. Keep this separate from the
  // strategy-library module counter because pre-trade simulations and
  // historical backtests evaluate the same pure functions in this process.
  private otmConfluenceSkips = { count: 0, lastSkipAt: null as number | null, byStrategy: {} as Record<string, number> };
  // Session-only telemetry for the strategy-level regime filter. This is kept
  // bot-owned rather than inferred from logs because operators need the exact
  // count on the current status snapshot, including repeated hot-loop blocks.
  private strategyRegimeBlocks = {
    count: 0,
    lastBlockAt: null as number | null,
    byRegime: {} as Record<string, number>,
    byStrategy: {} as Record<string, number>,
  };
  // A live tick can run as often as every 150 ms. Count every gate rejection,
  // but persist only a new factor signature or one periodic heartbeat per
  // signature so OTM telemetry cannot evict useful operational logs.
  private otmConfluenceLogDedup = new Map<string, { lastLoggedAt: number; suppressed: number }>();
  private consecutiveLosses   = 0;
  private paperSessionStartTs = 0;   // epoch ms of last paper reset — used to filter trade history for ARIA
  private currentStreak       = 0;
  private lastEdge            = 0;
  private lastModelProb       = 0.5;
  /** Director money-path report for PATH_RIDE (CC/LAG/HA). TradingBot places using these numbers. */
  private lastOrganReport: OrganReport | null = null;
  private lastExitMonitorStamp: ExitMonitorStamp | null = null;
  /** Observe-only STRUCTURAL_RUIN_SHADOW (PATH_RIDE) — never SELL. */
  private lastStructuralRuinShadow: StructuralRuinShadowStamp | null = null;
  private structuralRuinShadowCounters: StructuralRuinShadowCounters =
    emptyStructuralRuinShadowCounters();
  /** Last close settle brain stamp (OK | STORY_STAMP_INCOMPLETE). */
  private lastSettleStamp: SettleMsg | null = null;
  /** Last director-skip taxonomy (abortEvaluate vs sizeRescueContinue). */
  private lastDirectorGovernance: GovernanceMsg | null = null;
  /** Paper book vs local ledger mismatch — blocks 15m admit until cleared. */
  private paperReconcileHalt = false;
  /** entryPathAndSize result from evaluateEntry PATH door — placeOrder PATH_RIDE consumes size/ev. */
  private lastPathSized: EntryPathAndSizeResult | null = null;
  /** One tape organ snapshot per evaluate. getStatus reuses if fresh. */
  private lastTapeOrgan: TapeSnapshot | null = null;

  /** SEV2 fix (2026-08-19 follow-up): live-recomputed model probability while
   *  a trade is open, written every monitorOpenTrade() tick (same value the
   *  settlement-hold decision itself now uses — see `liveModelProb` local in
   *  monitorOpenTrade). Exists so BotStatus/chat consumers can also see the
   *  in-hold live view instead of only the frozen at-entry `lastModelProb` —
   *  getStatus() picks whichever of the two is actually current. */
  private liveModelProb       = 0.5;
  private lastStalling        = false;
  /** Consecutive ticks with no valid YES or NO Kalshi ask (0¢/100¢ feed stall). */
  private consecutiveInvalidKalshiPriceTicks = 0;
  private accountBalance:     number | null = null;
  /** Epoch ms of the last successful live balance read. Null = never fetched successfully this session. */
  private balanceUpdatedAt:   number | null = null;
  /** Consecutive failed balance-refresh attempts (network/non-OK). Reset to 0 on success. */
  private balanceFetchFailures = 0;
  /** Human-readable reason for the most recent balance-refresh failure (null once a refresh succeeds). */
  private lastBalanceError:   string | null = null;
  /** One-shot fast-retry timer scheduled after a failed refresh so an outage doesn't have to wait out the full 15s cadence. */
  private balanceRetryTimer:  NodeJS.Timeout | null = null;
  private lastStrategyResult: LibStrategyResult | null = null;
  // Task #445 — real per-tick strategy consensus, exposed via getStatus() so
  // the dashboard can show the bot's ACTUAL decision instead of a disconnected
  // client-side heuristic (the old "N/8 aligned" ReversalHunter system).
  private lastStrategyConsensus: {
    decision: 'LONG' | 'SHORT' | 'STAY_OUT';
    confidencePct: number; // 0-100
    consensus: 'LONG' | 'SHORT' | 'MIXED' | 'NONE';
    totalCount: number;
    longCount: number;
    shortCount: number;
    topReason: string | null;
    ts: number;
  } | null = null;
  private lastDetectedRegime: string | null = null;
  private lastAdaptiveRegime: AdaptiveRegimeSnapshot | null = null;
  private paperVirtualBalanceCents = 31_300;
  private paperStats          = { pnlCents: 0, wins: 0, losses: 0 };
  /** Throttle getStatus paperStats heal (jsonl read) — ms epoch of last heal attempt. */
  private paperStatsHealedAt = 0;
  /** Combined bot+manual settled P&L. todayStats remains BOT-only for WR/gates. */
  private overallStats        = { pnlCents: 0, wins: 0, losses: 0 };
  // v5 state
  private peakBalanceCents    = 0;
  private reservePoolCents    = 0;
  private openTradePnlCents   = 0;   // unrealized, updated each tick
  private openTradeMaxGain    = 0;   // peak unrealized gain for trailing stop
  // v7 learning state
  private lastObservation:      StrategyObservation | null = null;
  // pre-trade sim
  private lastPreTradeVerdict:  PreTradeVerdict | null = null;
  /** Real money-gate EVALUATING snapshot (alignedTake + W2). Not composite. */
  private lastMoneyGateCard: MoneyGateCard | null = null;

  /** FROZEN_CC: shadow flags + p/EV for the fill currently being placed (set by evaluateEntry, consumed by _placeOrderBody). */
  private pendingFrozenFill: { shadow: FrozenShadowFlags; p: number; ev: number; entryShadowDecisionId?: string | null; shadowSit?: boolean; protectedCheapNo?: boolean; protectedCheapYes?: boolean } | null = null;
  private lastFrozenTickShadow: { shadow: FrozenShadowFlags; atMs: number } | null = null;
  /** Last evaluate tick's frozen shadow if ≤30s old (sensor input only; never a gate). */
  private freshFrozenTickShadow(): FrozenShadowFlags | null {
    const s = this.lastFrozenTickShadow;
    return s && Date.now() - s.atMs <= 30_000 ? s.shadow : null;
  }
  /** Last direction_w2 log (15m/hourly) — STORY_STAMP lockSide source at fill. */
  /** Throttle identical [W2] SKIP info lines (disk/CPU). Law unchanged. */
  private w2LogThrottle = createDirectionW2LogThrottleState();
  private lastW2Log: {
    mtf_side: string | null;
    ha_side: string | null;
    analog_side: string | null;
    lag_proven: boolean;
    lock_result: string;
    lockSide?: import("./organs/lock-side-context.js").LockSideTags | null;
    lockSide_why?: string | null;
  } | null = null;
  // Task: "trade approved but nothing happened" — backgroundPreTrade() (below)
  // reruns runPreTradeSim() every 500ms purely to keep the dashboard's verdict
  // warm, on its OWN timer, independent of tick()'s real evaluateEntry() timer
  // (also 500ms). Only evaluateEntry() knows about the post-approval gates
  // (regime filter, ARIA veto, path gate) and annotates verdict.blockedAfterApproval
  // when one fires — but backgroundPreTrade() then overwrites lastPreTradeVerdict
  // with a brand-new, un-annotated "approved" verdict on its very next run,
  // erasing that annotation almost immediately. The UI ends up showing a clean
  // "TRADE APPROVED" card while the bot is, in reality, rejecting the same
  // setup tick after tick downstream.
  // Task #402 (root cause of the above, not just the blockedAfterApproval
  // symptom): tickTimer's real evaluateEntry() and pretradeTimer's
  // backgroundPreTrade() are two independent 500ms setIntervals writing the
  // same this.lastPreTradeVerdict field with no ordering guarantee. Rather
  // than special-casing one field (blockedAfterApproval) forever, give the
  // REAL pipeline's verdict a short precedence window: whenever evaluateEntry()
  // itself produces a verdict, it stamps direction+ts here. backgroundPreTrade()
  // checks this before overwriting lastPreTradeVerdict — if the real pipeline
  // just decided on the same direction a moment ago, the background loop's
  // independently-recomputed (and downstream-unaware) verdict yields to it for
  // *every* field, not only blockedAfterApproval. This is a display-only
  // precedence rule; live order placement always goes through evaluateEntry()
  // itself and is unaffected.
  private lastRealVerdictDirection: "LONG" | "SHORT" | null = null;
  private lastRealVerdictTs = 0;
  private lastModeState:        ModeState | null = null;
  private modeHistory:          ModeState[] = [];
  // Daily compounding target engine state
  private dailyTargetDay: {
    date:             string;
    paper:            boolean;
    startEquityCents: number;
    peakEquityCents:  number;
    targetHitToday:   boolean;
    loading:          boolean;
    lastPersistTs:    number;
    lastPersistedPeak?: number;
    // Cash-flow reconciliation: last balance we checked, and when. Any gap
    // between actual balance movement and realized trade P&L since that
    // point is an external deposit/withdrawal, not a trading gain — see
    // reconciliation block in refreshDailyTarget(). Reset on every (re)load,
    // so it only ever detects NEW flows from this session forward; the
    // persisted startEquityCents/peakEquityCents already reflect anything
    // reconciled in a prior session.
    lastReconciledBalanceCents: number;
    lastReconcileAt:  Date;
  } | null = null;
  private lastDailyTarget: DailyTargetStatus | null = null;
  private dailyTargetRetryTs = 0;   // throttle snapshot retries when DB is unreachable
  /**
   * Fail-closed guard: true while the target-hit latch has NOT been durably
   * persisted. While set, all new entries are blocked — otherwise a DB outage
   * at the transition (or a restart right after) would let the bot keep
   * trading through protect mode.
   */
  private dailyTargetLatchDirty = false;
  /**
   * Fail-closed guard: true while useDailyTarget is on but today's snapshot
   * row has never successfully loaded (e.g. a DB outage at day-roll or
   * bot startup). Before this flag existed, a load failure left
   * `lastDailyTarget` at its previous value (null on first run), so
   * dailyTargetEntryBlock() saw no block and orders proceeded with the
   * compounding-target/protect-mode layer silently absent for the whole
   * outage. Mirrors dailyTargetLatchDirty's fail-closed pattern.
   */
  private dailyTargetLoadFailed = false;
  // exit price driver — records which signal last drove a stop/profit exit
  private lastExitDriver:          'theoretical' | 'market' | null = null;
  private lastExitPriceBreakdown:  ExitPriceBreakdown | null = null;
  // live price breakdown for the currently open trade (updated each monitor tick)
  private livePriceBreakdown:      ExitPriceBreakdown | null = null;
  // background pre-trade sim loop
  private pretradeTimer:        NodeJS.Timeout | null = null;
  private lastObsTs:            number = 0;   // unix ms when lastObservation was built
  // GO — STEP 5 autoMode v2 PHASE A (2026-08-22): last computed suggestion +
  // rate-limit state. Recomputed on regime change or every
  // AUTOMODE_V2_MIN_RECOMPUTE_MS, never every tick — see the call site in
  // evaluateEntry(). Suggest-only: read by nothing on the live entry path.
  private lastAutoModeV2Suggestion: AutoModeV2Suggestion | null = null;
  private lastAutoModeV2Regime:     RegimeId | null = null;
  private lastAutoModeV2ComputeTs:  number = 0;
  private cachedVerdict: {
    verdict:     PreTradeVerdict;
    direction:   'LONG' | 'SHORT';
    strategyId:  string;
    ts:          number;
    /** quoteTs of the executable quote this verdict was computed against.
     *  evaluateEntry() rejects the cache if the quote it is deciding on is
     *  newer than this — a verdict must never be applied to a fresher quote
     *  than it was simulated against. */
    quoteTs:     number;
  } | null = null;
  // AI auto mode — lastAutoSettings echoes operator floors + adaptation (never a gate cut)
  private lastAutoSettings:     AutoDecision | null = null;
  private lastAdaptation:       AdaptationResult | null = null;
  // CONFIG_GUARD (Phase 1, 2026-08-15): last {autoMode, minConfidence, minVelocity}
  // an operator actually set via updateConfig(). Re-synced on every updateConfig()
  // call; used by runConfigGuard() to detect config that changed WITHOUT going
  // through that path. Null until the first updateConfig() call or runConfigGuard()
  // tick, whichever comes first — see runConfigGuard() for the bootstrap case.
  private lastGoodManual:       ManualFloorSnapshot | null = null;
  private configGuardTimer:     NodeJS.Timeout | null = null;
  // Adaptive condition classifier
  private lastAdaptiveCondition: AdaptiveConditionResult | null = null;
  // CONSENSUS MEASUREMENT PURITY (2026-08-16): the 15m main entry path's own
  // condEff.disabledStrategies (user + condition-suppression + DB quarantine),
  // cached the instant it's computed in evaluateEntry() so backgroundPreTrade()
  // — which runs on its own independent timer with no condEff of its own, yet
  // whose verdict can become the live cached verdict evaluateEntry() approves
  // off of — passes the IDENTICAL effective disabled set into its own
  // runPreTradeSim() call rather than inventing a second, narrower one.
  private lastEffectiveDisabledSet: string[] = [];
  // GO — APPLY PACKS ENFORCE (2026-08-18): this tick's real (not shadow)
  // pack + eligible set, set by evaluateEntry() right after computing them.
  // logSkippedDecision() and placeOrder()'s DecisionTrace calls read these
  // directly when specialistPacksMode==='enforce' instead of re-deriving via
  // evaluateSpecialistPackShadow() — guarantees the trace always agrees with
  // what actually gated this tick, never a second independent computation.
  private lastEnforcedPack: SpecialistPack | null = null;
  private lastPackEligibleIds: StrategyId[] | null = null;
  private lastAgentExitPolicy: import("./expert-agent.js").AgentExitPolicy | null = null;
  private lastAgentSizeMultiplier: number | null = null;
  /** Currently active tighten-only ARIA overrides for MTF bar / settlement-hold / add-to-position (null = static config in effect for all three). */
  private lastAgentSetupControls: AgentSetupControls | null = null;
  /** Cross-exchange → BRTI basis + projected settlement price (see basis-tracker.ts). */
  private lastBasisState: BasisState | null = null;
  /** R4 — SelfDrive sensor: fresh BRTI proxy + exchange price (≤5 s). */
  private indexProxyFresh(nowMs = Date.now()): boolean {
    const b = this.lastBasisState;
    if (!b) return false;
    const proxyOk = typeof b.brtiProxy === "number" && Number.isFinite(b.brtiProxy) && b.brtiProxy > 0;
    const exOk = typeof b.exchangePrice === "number" && Number.isFinite(b.exchangePrice) && b.exchangePrice > 0;
    const fresh = typeof b.lastUpdated === "number" && nowMs - b.lastUpdated <= 5_000;
    return proxyOk && exOk && fresh;
  }
  /** Orig-LAG proj-vs-floor persist analog for live evaluate obs. Reset per ticker. */
  private origLagProjStreak = emptyOrigLagProjStreak();
  private origLagProjStreakTicker: string | null = null;
  private lastBasisPersistedAt = 0;
  // External-close reconciliation throttle/persistence-guard state.
  private lastPositionReconcileAt = 0;
  private positionMismatchStreak  = 0;
  /** Prevent a slow account-wide Kalshi read from stacking on the next interval. */
  private accountPositionReconcileInFlight = false;
  /** Most recent account-wide audit, exposed through BotStatus for operators. */
  private accountPositionAudit: {
    checkedAt: number | null;
    status: "never" | "unknown" | "flat" | "managed" | "tracked-mismatch" | "unmanaged";
    positions: AccountPositionSnapshot[];
  } = { checkedAt: null, status: "never", positions: [] };
  // Task #604: a still-live pending/unresolved bot_trades row from a prior
  // process (openTrade is in-memory and null after restart). Blocks placeOrder
  // until the row is stale-recovered or this process adopts it. Paper=live.
  private heldPendingFromRestart = false;

  /**
   * The only place `openTrade` should be assigned. Consolidates ~40
   * previously-scattered `this.openTrade = ...` call sites so every state
   * transition (open / clear) resets the confirmation clock the same way —
   * a stale confirmation from a PREVIOUS trade must never leak onto a new
   * one. Does not change reconciliation cadence or logic, only who's
   * allowed to write the field.
   */
  private setOpenTrade(trade: OpenTrade | null): void {
    if (trade && isPathRideOpenTrade(trade)) {
      const tagged = tagPaperFill(trade.strategyId);
      trade = { ...trade, pathRide: true, exitBook: tagged.exitBook ?? "PATH_RIDE" };
    }
    this.openTrade = trade;
    this.positionLastConfirmedAt = null;
    this.settlementUnresolvedSinceTs = null;
    this.addPositionStaleStreak = 0;
    this.pathRideBrokenSinceMs = null;
    this.pathRideBrokenTicks = 0;
    // Cat sustain clock is per-openTrade. Reset on every set/clear so EXTERNAL_CLOSE,
    // unresolved, cancel-unfilled, and a fresh fill never inherit a prior below-since.
    this.frozenCatastrophicBelowSinceMs = null;
  }

  /**
   * Evaluate strategies for a real bot decision and collect only the OTM
   * confluence events produced by that pass. This prevents background
   * simulations from inflating the session metric while preserving the pure
   * strategy evaluate() contract.
   */
  private evaluateStrategiesForBot(
    obs: StrategyObservation,
    disabledIds?: ReadonlySet<string> | readonly string[],
  ): ReturnType<typeof evaluateAllStrategies> | PaperScalpEvalResult {
    // 15m desk: a KXBTCD/PERP ticker must not run the 15m roster even if
    // contractDurationMins is missing or hardcoded to 15. Hourly lives in
    // evaluateHourlyTick (already no-op when !enable1HContracts).
    const productGate = is15mDeskEvaluateAllowed({
      ticker: obs.ticker,
      enable1HContracts: this.config.enable1HContracts,
      enable1HLive: this.config.enable1HLive,
    });
    if (!productGate.ok) {
      drainOtmConfluenceSkipEvents();
      return { best: null, all: [], consensus: "NONE", consensusConf: 0 };
    }
    // Discard events produced by non-bot callers since the previous live pass.
    drainOtmConfluenceSkipEvents();
    this.lastOrganReport = null;
    this.lastPathSized = null;
    // Dual-gate false → do not invoke CHEAP_SIDE evaluate (evaluateAllStrategies skips disabled).
    const gatedDisabled = new Set<string>(
      unionMain15mEvaluateDisabled(
        disabledIds
          ? (disabledIds instanceof Set ? [...disabledIds] : [...disabledIds])
          : [],
        this.config,
      ),
    );
    // Host-scan: unionFrozenEvaluateDisabled is the frozen denylist source.
    void unionFrozenEvaluateDisabled;
    if (this.config.cheapSide15mEnabled !== true) gatedDisabled.add("CHEAP_SIDE_15M");
    let result = evaluateAllStrategies(obs, gatedDisabled);
    // Paper release: selection default-denies strategies outside the release.
    {
      const metas = getAllStrategyMeta().filter(m => isPaperReleaseStrategyAllowed(m.id) || m.id === FROZEN_CC_STRATEGY_ID);
      void metas;
    }
    for (const event of drainOtmConfluenceSkipEvents()) {
      this.recordOtmConfluenceSkip(event);
    }
    // Record Kalshi ticket quotes for PAPER_SCALP velocity only when scope permits.
    const scalpMayRun = paperScalpRunsOnMain15mEvaluate({
      paperMode: this.config.paperMode === true,
      frozenCcMode: this.config.frozenCcMode === true,
      feeNetBeatsSkip: PAPER_SCALP_FEE_NET_BEATS_SKIP,
    });
    const scalpOffReason = paperScalpOffMainEvaluateReason({
      paperMode: this.config.paperMode === true,
      frozenCcMode: this.config.frozenCcMode === true,
      feeNetBeatsSkip: PAPER_SCALP_FEE_NET_BEATS_SKIP,
    });
    // frozen_cc_no_scalp / fee_net_does_not_beat_skip — module stays, main tick denied.
    void scalpOffReason;
    const scalpTick = scalpMayRun ? obsToTickQuote({
      ticker: obs.ticker,
      yesAsk: obs.yesAsk,
      noAsk: obs.noAsk,
      yesBid: obs.yesBid,
      noBid: obs.noBid,
      floorStrike: obs.floorStrike,
      projectedSettlementPrice: obs.projectedSettlementPrice,
      secsRemaining: obs.secsRemaining,
    }) : null;
    if (scalpTick) {
      this.paperScalpQuotes.push(scalpTick);
      const cutoff = scalpTick.ts - 16_000;
      while (this.paperScalpQuotes.length > 0 && this.paperScalpQuotes[0]!.ts < cutoff) {
        this.paperScalpQuotes.shift();
      }
      if (this.paperScalpQuotes.length > 40) this.paperScalpQuotes.splice(0, this.paperScalpQuotes.length - 40);
    }

    // Same quote age for settlement-side AND paper scalp. Missing quoteTs →
    // Infinity → quote_stale (fail-closed, paper=live). Never boost pWin.
    const quoteTs = kalshiWS.getLatest()?.quoteTs;
    const quoteAgeMs = typeof quoteTs === "number" && quoteTs > 0 ? Date.now() - quoteTs : Number.POSITIVE_INFINITY;

    const tryPaperScalp = (settlementPlace: boolean) => {
      // Halt place path until fee-net > skip. Velocity replay −179¢.
      // Module stays; LIVE_APPLY stays false. Paper=live (same evaluate).
      if (!PAPER_SCALP_FEE_NET_BEATS_SKIP) {
        return applyPaperScalpAfterSettlement({
          settlementPlace,
          result,
          scalp: { take: false, side: null, reason: "fee_net_does_not_beat_skip" },
        });
      }
      const nowTick = scalpTick ?? this.paperScalpQuotes[this.paperScalpQuotes.length - 1] ?? null;
      const scalp = decidePaperScalp({
        ticker: obs.ticker ?? nowTick?.ticker,
        yesAsk: obs.yesAsk,
        noAsk: obs.noAsk,
        yesBid: obs.yesBid,
        noBid: obs.noBid,
        secsRemaining: obs.secsRemaining,
        mtf: obs.mtfScore ?? 0,
        alreadyOpen: this.openTrade != null,
        history: this.paperScalpQuotes,
        now: nowTick ?? undefined,
        remainingBudgetCents: Math.floor(this.effectiveBalance() * HARD_RISK_LIMITS.maxRiskPctPerTrade),
        bankrollCents: this.effectiveBalance(),
        projectedSettlement: obs.projectedSettlementPrice ?? null,
        floor: obs.floorStrike,
        // Same Coinbase→Kalshi meter as settlement-side. Fail-closed: missing → stale.
        // Scalp is not an escape hatch around lag_stale / lag_disagrees / too-small / quote_stale.
        lagStale: this.lastBasisState?.lagStale ?? true,
        lagDollars: this.lastBasisState?.lagDollars ?? null,
        quoteAgeMs,
      });
      if (scalp.take) {
        this.log("info",
          `[paper_scalp] take side=${scalp.side} reason=${scalp.reason} strategyId=${PAPER_SCALP_STRATEGY_ID}`,
        );
      }
      return applyPaperScalpAfterSettlement({
        settlementPlace,
        result,
        scalp,
      });
    };

    // organs director CALL SITE for evaluate's money path (CC/LAG/HA).
    // Driver decides. Organs never ENABLE leftover or cut EV/Kelly/9%.
    // GG#2/P0#2: ANY decideMoneyPath skip on PATH_RIDE hard-returns (not only
    // ev_below_floor) — no SETTLEMENT_SIDE / evaluateEntry fall-through.
    // TAKE still flows; F2 organTake identity at placeOrder stays.
    // F-B1: frozenCcMode → do not write lastModelProb from organ take.
    // GG#3/P0#3: on take, force best to organ strategyId/side/ask±1¢ or
    // ORGAN_BEST_MISMATCH empty. WATCHING is not flipped.
    if (result.best && isPathRideKellyBook(result.best.strategyId)) {
      const report = decideMoneyPath({
        obs,
        results: result.all,
        paperMode: this.config.paperMode === true,
        equityCents: this.paperVirtualBalanceCents,
        todayPnlCents: this.todayStats.pnlCents,
        frozenCcMode: this.config.frozenCcMode === true,
      });
      this.lastOrganReport = report;
        if (report.action === "skip") {
          // Literacy stamp: abortEvaluate vs sizeRescueContinue (SIZE_RESCUE ≠ organs ignored).
          this.lastDirectorGovernance = classifyDirectorSkipTaxonomy(
            report.reason,
            this.config.frozenCcMode === true,
          );
          if (directorSkipAbortsEvaluate(report.reason, this.config.frozenCcMode === true)) {
            // SIZE_RESCUE continues; EV/p/no_side abort evaluate for non-six-gate.
            if (!(this.config.frozenCcMode === true)) {
              this.log("info", `[organs] directorSkipAbortsEvaluate(report.reason=${report.reason}) taxonomy=${this.lastDirectorGovernance.taxonomy} — abort evaluate`);
              return { best: null, all: [], consensus: "NONE", consensusConf: 0 };
            }
          } else if (this.lastDirectorGovernance.taxonomy === "sizeRescueContinue") {
            this.log("info", `[organs] sizeRescueContinue reason=${report.reason} — organs not ignored; host may continue`);
          }
        }

      {
        const frozenAdvisory = this.config.frozenCcMode === true && report.action === "take";
        // D14 — per action+side+reason+strategy 60s throttle (was 2–5 lines/s).
        const organMsg = this.logThrottle.gate(
          throttleKey(String(report.strategyId ?? ""), "organs", String(report.action), String(report.side), String(report.reason)),
          `[organs] action=${report.action}${frozenAdvisory ? " (advisory; frozen sole=decideFrozenCcEntry)" : ""} side=${report.side} p=${report.p} ev=${report.ev} size=${report.size} reason=${report.reason} strategyId=${report.strategyId}`,
        );
        if (organMsg) this.log("info", organMsg);
      }
      if (report.action === "take" && report.p != null) {
        // Fill p = winRateAtPrice at traded ask — never N(d2).
        if (shouldWriteOrganTakeModelProb({
          frozenCcMode: this.config.frozenCcMode,
          action: report.action,
        })) {
          this.lastModelProb = report.p;
        } else if (this.config.frozenCcMode === true) {
          const advMsg = this.logThrottle.gate(throttleKey("", "organs-advisory"), `[organs] ${FROZEN_ORGANS_ADVISORY} p=${report.p} — not writing lastModelProb (frozen sole = decideFrozenCcEntry)`);
          if (advMsg) this.log("info", advMsg);
        }
      }
      const organSkip = pathRideOrganSkipBlocksEvaluate(report);
      if (organSkip.block) {
        // Hard skip any reason (ev_below_floor, both_sides, ask_out_of_band, …).
        // Empty eval → evaluateEntry cannot placeOrder. Reason preserved on report.
        const hardSkipMsg = this.logThrottle.gate(
          throttleKey("", "organs-hard-skip", String(organSkip.reason)),
          `[organs] PATH_RIDE hard-skip reason=${organSkip.reason} — no SETTLEMENT_SIDE fall-through`,
        );
        if (hardSkipMsg) this.log("info", hardSkipMsg);
        return tryPaperScalp(false);
      }
      if (report.action === "take") {
        const organBest = resolveOrganBestOrMismatch({
          report,
          best: result.best,
          all: result.all,
          yesAsk: obs.yesAsk,
          noAsk: obs.noAsk,
        });
        if (!organBest.ok) {
          this.log("info",
            `[organs] ${ORGAN_BEST_MISMATCH} strategyId=${report.strategyId} side=${report.side} ask=${report.askCents} — blocking place funnel`,
          );
          return tryPaperScalp(false);
        }
        if (organBest.best !== result.best) {
          result = { ...result, best: organBest.best };
          this.log("info",
            `[organs] forced best → ${organBest.best.strategyId} ${organBest.best.signal} (organ take identity)`,
          );
        }
      }
    }

    // Settlement SIDE before Kelly/size/placeOrder. p = winRateAtPrice, never
    // confidence. Skip is valid. Never both sides of the same 15m bar.
    // Settlement skip does NOT kill the paper scalp book (still-mid skip is
    // not sit-on-hands) unless the Coinbase lag meter fails closed — stale,
    // disagree, |lagDollars| < $16, or quote stale. Scalp uses the same meter.
    if (result.all.length === 0) {
      return tryPaperScalp(false);
    }
    {
      const moneyDirectional = result.all.filter(r =>
        isMoneyMakerStrategyId(r.strategyId) && (r.signal === "YES" || r.signal === "NO"));
      const pathRideFired = result.all.filter(r =>
        isPathRideKellyStrategyId(r.strategyId) && (r.signal === "YES" || r.signal === "NO"));
      // Money-maker p first. Leftover YES (VM/FLOOR/TW) + CC NO used to feed
      // both_sides and log SETTLEMENT_SIDE on CC (7 last-3k rows).
      const leftoverPoison = leftoverYesAskIsPoison;
      const yesR = moneyDirectional.find(r => r.signal === "YES")
        ?? pathRideFired.find(r => r.signal === "YES" && !leftoverPoison(r.strategyId, obs.yesAsk))
        ?? result.all.find(r => r.signal === "YES" && isPathRideKellyStrategyId(r.strategyId) && !leftoverPoison(r.strategyId, obs.yesAsk));
      const noR = moneyDirectional.find(r => r.signal === "NO")
        ?? pathRideFired.find(r => r.signal === "NO")
        ?? result.all.find(r => r.signal === "NO" && isPathRideKellyStrategyId(r.strategyId));
      const minutesLeft = obs.secsRemaining / 60;
      const metas = getAllStrategyMeta();
      const pOf = (r: { strategyId: string } | undefined, ask: number | undefined): number | null => {
        if (!r) return null;
        const meta = metas.find(s => s.id === r.strategyId);
        return pWinAtPriceRejectingThinLearner(meta?.winRateAtPrice, meta?.expectedWinRate, ask, minutesLeft, {
          strategyId: r.strategyId,
          paperMode: this.config.paperMode === true,
        });
      };
      const preserveIds = [
        result.best?.strategyId ?? null,
        ...moneyDirectional.map(r => r.strategyId),
        ...pathRideFired.map(r => r.strategyId),
      ];
      const { place, decision, log } = apply15mSettlementSideBeforeSize({
        pYes: pOf(yesR, obs.yesAsk),
        pNo: pOf(noR, obs.noAsk),
        mtf: obs.mtfScore ?? 0,
        signalConfidence: result.best?.confidence ?? null,
        // Fail-closed: missing basis → lagStale true. pWin stays winRateAtPrice.
        lagStale: this.lastBasisState?.lagStale ?? true,
        lagDollars: this.lastBasisState?.lagDollars ?? null,
        quoteAgeMs,
        // Paper CONFLUENCE/LAG: sign-only |lag$| (original +$50). Else $16.
        paperMode: this.config.paperMode === true,
        strategyId: result.best?.strategyId ?? moneyDirectional[0]?.strategyId ?? pathRideFired[0]?.strategyId ?? null,
        strategyIds: preserveIds,
      });
      this.log("info",
        `[settlement_side] event=${log.event} side=${log.side} reason=${log.reason} pWin=${log.pWin} signalConfidence=${log.signalConfidence} lagStale=${log.lagStale} lagDollars=${log.lagDollars}`,
      );
      const ignoreLater = paperPathRidePreservesThroughSettlementSkip(
        this.config.paperMode === true,
        preserveIds,
        decision.reason,
      );
      if (ignoreLater) {
        // Rematch even when place=true from strategyIds (best may still be leftover).
        const prefer = pathRideFired.find(r => r.strategyId === result.best?.strategyId)
          ?? moneyDirectional.find(r => r.strategyId === result.best?.strategyId)
          ?? pathRideFired[0]
          ?? moneyDirectional[0]
          ?? result.best;
        if (prefer && prefer !== result.best) {
          result = { ...result, best: prefer };
        }
        this.log("info",
          `[settlement_side] later-preserver ${decision.reason} not applied to ${result.best?.strategyId} (paper=live remake-preserve)`,
        );
      }
      if (!place && !ignoreLater) {
        // quote_stale / lag_disagrees / p_null KEEP. Remake reasons never
        // reach here for CC/LAG because ignoreLater is true.
        const ticker = obs.ticker ?? "UNKNOWN";
        if (yesR) {
          this.logSkippedDecision("SETTLEMENT_SIDE", [decision.reason], {
            ticker, side: "yes", strategyId: yesR.strategyId,
            entryPriceCents: typeof obs.yesAsk === "number" ? obs.yesAsk : 0,
            confidence: yesR.confidence, secsRemaining: obs.secsRemaining, floorStrike: obs.floorStrike,
          });
        }
        if (noR) {
          this.logSkippedDecision("SETTLEMENT_SIDE", [decision.reason], {
            ticker, side: "no", strategyId: noR.strategyId,
            entryPriceCents: typeof obs.noAsk === "number" ? obs.noAsk : 0,
            confidence: noR.confidence, secsRemaining: obs.secsRemaining, floorStrike: obs.floorStrike,
          });
        }
        // Settlement-side is an ENTRY gate. An already-open scale-in must not
        // be emptied by lag_stale / p_null (that would be a stricter skip).
        // Missing lag never blocks add (isLagAgainstSide); thesis VALID is
        // required separately in considerAddingToPosition.
        if (this.openTrade && result.all.length > 0) {
          return result;
        }
        return tryPaperScalp(false);
      }
      if (result.best) return result;
    }
    return tryPaperScalp(false);
  }

  /**
   * Count every marginal OTM setup, while bounding persistent logs to one line
   * per strategy/factor signature per minute. A changed set of missing factors
   * is always logged immediately; the next periodic line reports duplicates
   * suppressed during its prior window.
   */
  private recordOtmConfluenceSkip(event: OtmConfluenceSkipEvent): void {
    this.otmConfluenceSkips.count++;
    this.otmConfluenceSkips.lastSkipAt = event.ts;
    this.otmConfluenceSkips.byStrategy[event.strategyId] =
      (this.otmConfluenceSkips.byStrategy[event.strategyId] ?? 0) + 1;

    const signature = `${event.strategyId}:${event.missingFactors.join("|")}`;
    const prior = this.otmConfluenceLogDedup.get(signature);
    const logIntervalMs = 60_000;
    if (prior && event.ts - prior.lastLoggedAt < logIntervalMs) {
      prior.suppressed++;
      return;
    }

    const suppressedSuffix = prior?.suppressed
      ? ` · ${prior.suppressed} identical rejection(s) suppressed in prior 60s`
      : "";
    this.otmConfluenceLogDedup.set(signature, { lastLoggedAt: event.ts, suppressed: 0 });
    this.log("info", `${event.message}${suppressedSuffix}`);
  }

  /** Reset OTM outcome and confluence telemetry at a paper-session boundary. */
  private resetOtmSessionStats(): void {
    this.otmStats = {
      wins: 0, losses: 0, pnlCents: 0, totalPaidCents: 0,
      avgWinMultiple: null, _winMultipleSum: 0, _winCount: 0,
    };
    this.otmConfluenceSkips = { count: 0, lastSkipAt: null, byStrategy: {} };
    this.otmConfluenceLogDedup.clear();
  }

  /** Return the mutable session accumulator for a strategy, creating it once. */
  private getSessionFillStatsForStrategy(strategyId: string | null | undefined) {
    const key = strategyId || "UNKNOWN";
    const existing = this.sessionFillStats.byStrategy[key];
    if (existing) return existing;
    const created = {
      placed: 0,
      filled: 0,
      cancelled: 0,
      totalSlippageCents: 0,
      slippageSamples: 0,
    };
    this.sessionFillStats.byStrategy[key] = created;
    return created;
  }

  /**
   * Persist a single live-order lifecycle event without delaying execution.
   * The database operation is an atomic increment, so a fill and cancellation
   * callback cannot lose each other's updates if they complete out of order.
   */
  private persistSessionFillDelta(delta: {
    placed?: number;
    filled?: number;
    cancelled?: number;
    totalSlippageCents?: number;
    slippageSamples?: number;
  }): void {
    void incrementDailyFillStats({
      date: this.sessionFillStatsDate || etDateKey(),
      paperMode: false,
      delta,
    }).catch((err) => this.log("warn", `Daily fill stats persistence failed: ${(err as Error).message}`));
  }

  /**
   * Restore the current ET day's aggregate on boot and at the ET day boundary.
   * Per-strategy counters remain process-local; the dashboard's all-time
   * strategy breakdown continues to come from the durable bot_trades records.
   */
  private async ensureSessionFillStatsLoaded(date: string): Promise<void> {
    if (this.sessionFillStatsDate === date) return;
    if (this.sessionFillStatsHydration) {
      await this.sessionFillStatsHydration;
      if (this.sessionFillStatsDate === date) return;
    }

    const hydration = (async () => {
      try {
        const [persisted, rangeRows] = await Promise.all([
          loadDailyFillStats({ date, paperMode: false }),
          db.select({
            bestSlippageCents: sql<number | null>`min(${botTrades.slippageCents})::int`,
            worstSlippageCents: sql<number | null>`max(${botTrades.slippageCents})::int`,
          }).from(botTrades).where(and(
            eq(botTrades.isPaper, false),
            sql`to_char(${botTrades.filledAt} AT TIME ZONE 'America/New_York', 'YYYY-MM-DD') = ${date}`,
          )),
        ]);
        const range = rangeRows[0];
        this.sessionFillStats = {
          placed: persisted.placed,
          filled: persisted.filled,
          cancelled: persisted.cancelled,
          totalSlippageCents: persisted.totalSlippageCents,
          slippageSamples: persisted.slippageSamples,
          bestSlippageCents: range?.bestSlippageCents ?? null,
          worstSlippageCents: range?.worstSlippageCents ?? null,
          byStrategy: {},
        };
      } catch (err) {
        // Box/paper desk may have no Postgres — do not abort the tick loop
        // (that starved currentBtcPrice / BRTI pin). Mark date loaded with zeros.
        this.sessionFillStats = {
          placed: 0,
          filled: 0,
          cancelled: 0,
          totalSlippageCents: 0,
          slippageSamples: 0,
          bestSlippageCents: null,
          worstSlippageCents: null,
          byStrategy: {},
        };
        this.log("warn",
          `daily_fill_stats hydrate soft-failed (continuing tick): ${(err as Error).message?.slice(0, 120) ?? err}`,
        );
      }
      this.sessionFillStatsDate = date;
      this.refreshFillQualityEvTightening();
    })();
    this.sessionFillStatsHydration = hydration;
    try {
      await hydration;
    } finally {
      if (this.sessionFillStatsHydration === hydration) this.sessionFillStatsHydration = null;
    }
  }

  /** Startup hook used by the singleton before the bot is enabled. */
  async hydrateSessionFillStats(): Promise<void> {
    await this.ensureSessionFillStatsLoaded(etDateKey());
  }

  private recordSessionOrderPlaced(strategyId: string | null | undefined): void {
    this.sessionFillStats.placed++;
    this.getSessionFillStatsForStrategy(strategyId).placed++;
    this.persistSessionFillDelta({ placed: 1 });
  }

  private recordSessionOrderFilled(
    strategyId: string | null | undefined,
    slippageCents: number | null,
  ): void {
    this.sessionFillStats.filled++;
    const stats = this.getSessionFillStatsForStrategy(strategyId);
    stats.filled++;
    if (slippageCents != null && Number.isFinite(slippageCents)) {
      this.sessionFillStats.totalSlippageCents += slippageCents;
      this.sessionFillStats.slippageSamples++;
      this.sessionFillStats.bestSlippageCents = this.sessionFillStats.bestSlippageCents === null
        ? slippageCents
        : Math.min(this.sessionFillStats.bestSlippageCents, slippageCents);
      this.sessionFillStats.worstSlippageCents = this.sessionFillStats.worstSlippageCents === null
        ? slippageCents
        : Math.max(this.sessionFillStats.worstSlippageCents, slippageCents);
      stats.totalSlippageCents += slippageCents;
      stats.slippageSamples++;
    }
    this.refreshFillQualityEvTightening();
    this.persistSessionFillDelta({
      filled: 1,
      ...(slippageCents != null && Number.isFinite(slippageCents)
        ? { totalSlippageCents: slippageCents, slippageSamples: 1 }
        : {}),
    });
  }

  private recordSessionOrderCancelled(strategyId: string | null | undefined): void {
    this.sessionFillStats.cancelled++;
    this.getSessionFillStatsForStrategy(strategyId).cancelled++;
    this.persistSessionFillDelta({ cancelled: 1 });
  }

  /**
   * The observed average becomes an EV-friction floor only after a meaningful
   * live sample. This never modifies config and never reduces the static 1.5¢
   * model, so it cannot loosen admission after a few favorable fills.
   */
  private getObservedSessionSlippageFloorCents(): number | null {
    const averageSlippageCents = this.sessionFillStats.slippageSamples > 0
      ? this.sessionFillStats.totalSlippageCents / this.sessionFillStats.slippageSamples
      : null;
    return observedSlippageFloorCents({
      slippageSamples: this.sessionFillStats.slippageSamples,
      averageSlippageCents,
    });
  }

  private refreshFillQualityEvTightening(): void {
    const floor = this.getObservedSessionSlippageFloorCents();
    const average = this.sessionFillStats.slippageSamples > 0
      ? this.sessionFillStats.totalSlippageCents / this.sessionFillStats.slippageSamples
      : null;
    const active = floor !== null;
    if (active && !this.fillQualityEvTighteningActive) {
      this.log(
        "warn",
        `⚠️ Fill quality warning: ${this.sessionFillStats.slippageSamples} live fills average ` +
        `+${average!.toFixed(1)}¢ slippage (>2.5¢). Entry EV gates now model at least ` +
        `${floor!.toFixed(1)}¢ instead of the 1.5¢ baseline.`,
      );
    } else if (!active && this.fillQualityEvTighteningActive) {
      this.log(
        "info",
        "✅ Fill quality recovered below the auto-tightening threshold; entry EV gates returned to the normal dynamic slippage model.",
      );
    }
    this.fillQualityEvTighteningActive = active;
  }

  private getSessionFillStatsSummary(): BotStatus["sessionFillStats"] {
    const summarise = (stats: {
      placed: number;
      filled: number;
      cancelled: number;
      totalSlippageCents: number;
      slippageSamples: number;
    }) => ({
      placed: stats.placed,
      filled: stats.filled,
      cancelled: stats.cancelled,
      slippageSamples: stats.slippageSamples,
      avgSlippageCents: stats.slippageSamples > 0
        ? +(stats.totalSlippageCents / stats.slippageSamples).toFixed(1)
        : null,
      fillRate: stats.placed > 0
        ? +(stats.filled / stats.placed).toFixed(3)
        : null,
    });

    const observedFloor = this.getObservedSessionSlippageFloorCents();
    return {
      ...summarise(this.sessionFillStats),
      bestSlippageCents: this.sessionFillStats.bestSlippageCents,
      worstSlippageCents: this.sessionFillStats.worstSlippageCents,
      evTighteningActive: observedFloor !== null,
      modeledSlippageCents: +(Math.max(KALSHI_EXPECTED_SLIPPAGE_CENTS, observedFloor ?? 0)).toFixed(1),
      byStrategy: Object.fromEntries(
        Object.entries(this.sessionFillStats.byStrategy)
          .map(([strategyId, stats]) => [strategyId, summarise(stats)]),
      ),
    };
  }

  /** Called by reconcilePositionWithKalshi() when Kalshi confirms the tracked position still matches. */
  private markPositionReconciled(): void {
    this.positionLastConfirmedAt = Date.now();
  }
  // Auth failure flag — set when kalshiAuthHeaders() returns {} on a live order attempt
  private authFailed            = false;
  // Why the last auth failure occurred: 'signing' = local PEM error; 'server' = Kalshi 401/403
  private authFailedReason: 'signing' | 'server' | null = null;
  // Task #204: exact Kalshi rejection reason for the most recent declined live
  // order. Kept briefly so a fast retry cannot clear it before SSE/poll clients
  // receive the event.
  private lastOrderRejection: { ts: number; ticker: string; side: string; reason: string } | null = null;
  // Task #376: set at startup when the persisted config says the bot was
  // running before this restart (saved.enabled === true) but auto-start was
  // blocked (e.g. an unmanaged live position was detected) — so the bot
  // silently stays idle instead of resuming. Cleared by the next manual
  // start() so it never lingers past the operator actually addressing it.
  // Not private: set from the module-level startup IIFE below, outside the class.
  didNotResumeAfterRestart = false;
  didNotResumeReason: string | null = null;
  // Throttle for the server-side re-probe (at most once per 10 s to avoid spamming Kalshi)
  private lastServerAuthProbeTs = 0;
  // WS degraded circuit-breaker state
  private wsDegraded            = false;
  private _unsubWsDegraded:     (() => void) | null = null;
  // Vol-staleness fallback tracking — reset each time a new trade opens
  private volStaleFallbackLogged = false;
  private invalidQuoteLogged = false;
  private staleQuoteExitLogged = false;
  // Vol-staleness tracking for the entry path — reset when the buffer becomes fresh again
  private volStaleEntryLogged = false;
  // Task #222: the watchdog only force-reconnects a stale WS after 60s (its own
  // poll interval + threshold), but the entry gate below already blocks trading
  // at 5s (msg) / 15s (quote) staleness — leaving a ~45-55s dead zone where the
  // bot sits blocked with nothing actively trying to fix the feed. Reacting here,
  // on the very tick staleness is first observed, closes that gap; the cooldown
  // stops every subsequent tick from re-triggering forceReconnect() while a
  // reconnect is already in flight.
  private lastStaleForceReconnectAt = 0;
  // Vol-staleness tracking for the add-to-position path — reset when the buffer becomes fresh again
  private volStaleAddLogged = false;
  // A single stale add cycle can use the conservative vol fallback, but a
  // second consecutive stale cycle fails closed before strategy evaluation.
  private addPositionStaleStreak = 0;
  // Task #143: consecutive-stale-cycle counter for the shared (hourly) admission
  // path. A single stale cycle still gets pre-trade-sim's conservative-vol
  // fallback (soft), but staleness persisting into a SECOND consecutive cycle
  // means the feed is genuinely down, not a one-tick blip — hard-block instead
  // of letting the sim silently approve on a synthetic vol estimate.
  private sharedGateStaleStreak = 0;
  // Settlement hold state — true while riding a deep-ITM contract to expiry
  private settlementHoldActive  = false;
  // Fill-rate and slippage tracking. The current ET day's aggregate is
  // hydrated from daily_fill_stats, so a process restart does not erase it.
  private sessionFillStatsDate = "";
  private sessionFillStatsHydration: Promise<void> | null = null;
  private sessionFillStats = {
    placed:            0,   // live (non-paper) orders submitted
    filled:            0,   // orders confirmed filled
    cancelled:         0,   // orders cancelled unfilled
    totalSlippageCents: 0,  // sum of (fillPrice − expectedPrice) across filled orders
    slippageSamples:   0,   // number of fills with a known avg_price
    bestSlippageCents: null as number | null,
    worstSlippageCents: null as number | null,
    byStrategy: {} as Record<string, {
      placed: number;
      filled: number;
      cancelled: number;
      totalSlippageCents: number;
      slippageSamples: number;
    }>,
  };
  /** Prevent a high-slippage session from emitting the same warning every tick. */
  private fillQualityEvTighteningActive = false;
  // Background pre-trade sim guard — prevents concurrent executions from piling up
  private bgPreTradeRunning     = false;
  private balanceRefreshing     = false;  // in-flight guard — 15s timer must never overlap a slow balance call
  // Fast-market execution state
  private fastReversalTicks     = 0;   // consecutive ticks where velocity is strongly against position (>120 $/min)
  private strikeCrossTicks      = 0;   // consecutive ticks where BTC is decisively through the strike against the position
  private structureFailTicks    = 0;   // consecutive ticks where velocity is moderately against position (>100 $/min)
  private holdModeHardFloorTicks = 0;  // Task #303: consecutive ticks the LIVE MARKET price (not our own BTC-vs-strike computation) has sat at/below the hold-mode hard floor
  /** FROZEN_CC money-machine: wall-clock when mark first dipped ≤ catastrophic; null when above. */
  private frozenCatastrophicBelowSinceMs: number | null = null;
  // Thesis-break persistence counters (2026-08-14 unification): each backs
  // one of the three independent THESIS_BREAK_EXIT rules. All three require
  // sustained evidence — never a single tick/blip — before the exit fires.
  // strikeCrossTicks (declared above) is reused for the FLOOR_CROSS_AGAINST
  // rule so the ~20-tick/~10s persistence window stays a single source of
  // truth shared with the pre-existing hold-mode thesis-break logic.
  private thesisVelocityAgainstTicks = 0; // VELOCITY_FLIP_AGAINST: consecutive ticks velocity has run ≥40 $/min against the position
  private basisFlipAgainstTicks      = 0; // BASIS_FLIP_AGAINST: consecutive ticks the projected settlement price has sat on the wrong side of the floor for our side
  /** PATH_RIDE #725: consecutive 1s buckets where BOTH Coinbase lead AND BRTI proj are against fill. */
  private lagFlipBothAgainstSecStreak = 0;
  private lagFlipLastSampleSec = -1;
  /** PATH_RIDE BROKEN clock. Must not reset every tick while still broken. */
  private pathRideBrokenSinceMs: number | null = null;
  private pathRideBrokenTicks = 0;
  // P5 ARIA GUARDIAN (Task #427): per-open-trade Guardian state. Rate-limit
  // timestamp + the current tighten multipliers (re-derived fresh each real
  // evaluation, never ratcheted) + the last decision for BotStatus/log
  // visibility. All reset on every trade open/close alongside the counters
  // above — same dangling-state class, same fix pattern.
  private lastAriaGuardianEvalTs: number | null = null;
  private ariaGuardianTighten: AriaTighten | null = null;
  private lastAriaGuardianDecision: (AriaDecision & { ts: number }) | null = null;
  /** Last evaluate streak-sat CONTEXT (skip/bias). Display + hold-sell early-exit. */
  private lastStreakSatDecision: StreakSatDecision | null = null;
  /** Friend anti-pattern guard: last fade-against-streak entry. Cleared when the streak breaks. */
  private lastFadeAgainstStreak: { dir: 1 | -1; abs: number } | null = null;
  /** SHADOW would-fire labels. Never APPROVED. ENABLE stays false. */
  private lastAdviceShadow: AdviceShadowLabel[] = [];
  // 60s same-ticker re-entry cooldown after a THESIS_BREAK_EXIT — prevents
  // immediately re-opening a position the bot just decided the thesis broke on.
  private thesisBreakCooldownTicker: string | null = null;
  private thesisBreakCooldownUntil  = 0;
  // P-FILL LIVE, Part A (2026-08-26): rate limiter for the SETTLEMENT_PREDICTION
  // hostile-regime tick-preemption SKIP trace (see the selection-pool prune
  // right before selectBestEnabled) — caps that specific log line at <=1/min
  // instead of firing every tick it's the dominant blocker.
  private lastSPHostilePreemptLoggedAt = 0;
  // Master bot upgrade step 4: same-ticker PRESS-tier sizing cooldown after a
  // losing exit or a THESIS_BREAK_EXIT/LAG_FLIP_EXIT close. Unlike
  // thesisBreakCooldownUntil above, this never blocks re-entry — it only
  // caps the next same-ticker trade below PRESS tier (see computeStackTier()).
  private pressCooldownTicker: string | null = null;
  private pressCooldownUntil  = 0;
  private requeueContext: {            // set by placeOrder; consumed by cancelUnfilledOrder for re-quote
    side:        'yes' | 'no';
    signal:      'LONG' | 'SHORT';
    originalAsk: number;
    params:      Parameters<TradingBot['placeOrder']>[0];
  } | null = null;

  // ── Watchdog API ──────────────────────────────────────────────────────────

  /** Milliseconds since the last observation was processed (Infinity if never).
   *  Returns 0 when IN_TRADE — the bot is in monitorOpenTrade(), which is healthy;
   *  lastObsTs only advances during entry evaluation so it looks stale mid-trade. */
  getLastObsAge(): number {
    if (this.state === 'IN_TRADE') return 0;  // actively managing a position — not frozen
    return this.lastObsTs > 0 ? Date.now() - this.lastObsTs : Infinity;
  }

  /** Milliseconds since the last successful live balance read, or Infinity if never fetched. */
  getBalanceAgeMs(): number {
    return this.balanceUpdatedAt !== null ? Date.now() - this.balanceUpdatedAt : Infinity;
  }

  /** True when the bot does not have a recent, trustworthy read on live account equity.
   *  Paper mode is never stale — its balance is locally computed, not fetched. */
  isBalanceStale(): boolean {
    if (this.config.paperMode) return false;
    return this.accountBalance === null || this.getBalanceAgeMs() > BALANCE_STALE_MS;
  }

  /**
   * Force an immediate tick evaluation without waiting for the 2-s timer.
   * Used by the watchdog when the tick loop appears frozen.
   */
  nudgeTick() {
    if (this.state === "WATCHING" || this.state === "IN_TRADE") {
      console.info("[bot] nudgeTick() called by watchdog");
      void this.tick();
    }
  }

  /**
   * Event-driven wake: called when the WS delivers a NEW executable quote.
   * Fires the decision tick immediately if the min-interval floor has elapsed;
   * otherwise coalesces the wake into a single deferred tick at the floor
   * boundary so a burst of quotes results in at most one tick per
   * TICK_MIN_INTERVAL_MS. The in-flight re-entrancy guard inside tick() still
   * prevents any overlap — this only decides WHEN to attempt a tick.
   */
  private scheduleWakeTick() {
    if (this.state !== "WATCHING" && this.state !== "IN_TRADE") return;
    const now     = Date.now();
    const sinceLast = now - this._lastTickStartTs;
    if (sinceLast >= TICK_MIN_INTERVAL_MS) {
      // Floor satisfied — run now (tick()'s mutex no-ops if one is in flight).
      if (this._coalesceTimer) { clearTimeout(this._coalesceTimer); this._coalesceTimer = null; }
      void this.tick();
      return;
    }
    // Within the floor — coalesce: defer a single tick to the floor boundary.
    if (this._coalesceTimer) return;   // already scheduled — absorb this quote
    this._coalesceTimer = setTimeout(() => {
      this._coalesceTimer = null;
      void this.tick();
    }, TICK_MIN_INTERVAL_MS - sinceLast);
  }

  /**
   * Returns the age of the current open trade in ms, or null if no open trade.
   */
  getOpenTradeAge(): number | null {
    if (!this.openTrade) return null;
    return Date.now() - this.openTrade.openedAt;
  }

  /**
   * Task #604: if a pending/unresolved bot_trades row is still inside its
   * contract window, hold new entries. Called at start() so a restart with
   * openTrade=null cannot double-fill. Tests may call this with a stub.
   */
  private adoptRestartInFlight: Promise<void> | null = null;

  async adoptRestartPendingGuard(): Promise<void> {
    // SEV1 (sweep S3): boot IIFE and start() both call this; never run two
    // rehydrates concurrently (double openTrade / double void).
    if (this.adoptRestartInFlight) return this.adoptRestartInFlight;
    this.adoptRestartInFlight = this.adoptRestartPendingGuardBody().finally(() => { this.adoptRestartInFlight = null; });
    return this.adoptRestartInFlight;
  }

  private async adoptRestartPendingGuardBody(): Promise<void> {
    // Confirmed live pending ONLY after a successful DB read. start() fail-closes
    // with heldPendingFromRestart=true for the await window; soft PG/null failures
    // must clear that latch or paper placeOrder deadlocks forever.
    let confirmedLivePending = false;
    try {
      const now = Date.now();
      // NOTE: do NOT select botTrades.periodKey — column is not in schema/DB.
      // Selecting undefined drizzle columns throws ("Cannot convert undefined or
      // null to object"), soft-caught below, which skipped SEV0 rehydrate and
      // left openTrade=null with PG pending (orphan #11 class).
      const rows = await db.select({
        id: botTrades.id,
        createdAt: botTrades.createdAt,
        contractDurationMins: botTrades.contractDurationMins,
        outcome: botTrades.outcome,
        ticker: botTrades.ticker,
        isPaper: botTrades.isPaper,
        side: botTrades.side,
        contracts: botTrades.contracts,
        contractsFilled: botTrades.contractsFilled,
        entryPriceCents: botTrades.entryPriceCents,
        fillPriceCents: botTrades.fillPriceCents,
        floorStrike: botTrades.floorStrike,
        strategyId: botTrades.strategyId,
        orderId: botTrades.orderId,
        balanceBeforeCents: botTrades.balanceBeforeCents,
      }).from(botTrades).where(
        or(eq(botTrades.outcome, "pending"), eq(botTrades.outcome, "unresolved")),
      );
      const live = rows.filter(r =>
        isPendingStillLive(r, now) &&
        pendingCountsForRestartHold({ paperMode: this.config.paperMode, isPaper: r.isPaper }));
      confirmedLivePending = live.length > 0;
      this.heldPendingFromRestart = confirmedLivePending;
      if (this.heldPendingFromRestart) {
        this.log("warn",
          `⛔ Restart hold: ${live.length} pending/unresolved trade(s) still live` +
          `${live[0]?.ticker ? ` (e.g. ${live[0].ticker})` : ""} — new entries blocked`,
        );
      }

      // SEV0 mid-trade bounce: rehydrate paper openTrade from tape-first pending
      // so PATH_RIDE continues — never leave a ghost that STARTUP_RECOVERY can
      // wrong-side wipe / re-inject day loss.
      const livePaperPending = live.filter(r => r.isPaper === true);
      if (shouldRehydratePaperOpenTrade({
        paperMode: this.config.paperMode === true,
        openTradeNull: this.openTrade == null,
        hasLivePaperPending: livePaperPending.length > 0,
      }) || (this.config.paperMode === true && this.openTrade == null)) {
        const tapeRows = loadPaperTrades();
        const tapePending = lookupPaperTapeOpenPending(tapeRows, {
          sessionStartTs: this.paperSessionStartTs > 0 ? this.paperSessionStartTs : 0,
        });
        let dbPending: (typeof livePaperPending)[number] | null = livePaperPending[0] ?? null;
        // SEV1 (sweep S3): a PG-pending row whose fill the tape already closed
        // (settle DB write failed) must NOT come back as an open trade — that
        // re-exits / re-credits it. Repair PG from the tape close instead
        // (retry queue only updates rows still "pending").
        if (dbPending?.ticker) {
          const tapeClose = findTapeCloseForPendingFill(tapeRows, {
            tradeId: dbPending.id,
            ticker: dbPending.ticker,
            side: dbPending.side,
            contracts: dbPending.contractsFilled ?? dbPending.contracts,
            openedAtMs: dbPending.createdAt instanceof Date ? dbPending.createdAt.getTime() : null,
          });
          if (tapeClose && (tapeClose.outcome === "win" || tapeClose.outcome === "loss")) {
            const pnl = Math.round(Number(tapeClose.pnlCents ?? 0));
            const settledMs = typeof tapeClose.settledAt === "number" ? tapeClose.settledAt : (tapeClose.ts ?? now);
            try {
              enqueueSettlePersistRetry({
                dbId: dbPending.id,
                ticker: dbPending.ticker,
                patch: {
                  outcome: tapeClose.outcome, pnlCents: pnl, pnlDollars: pnl / 100,
                  settledAt: new Date(settledMs), exitReason: String(tapeClose.exitReason ?? "SETTLEMENT"),
                },
                error: "restart: PG pending but tape already closed",
              });
            } catch { /* best-effort */ }
            this.log("warn", `♻️ Restart: ${dbPending.ticker} #${dbPending.id} is PG-pending but the tape already closed it (${tapeClose.exitReason} ${pnl}¢) — not rehydrating; PG repair queued`);
            dbPending = null;
          }
        }
        const tapePendingUsable = tapePending
          && findTapeCloseForPendingFill(tapeRows, { ticker: tapePending.ticker, side: tapePending.side, contracts: tapePending.contracts, openedAtMs: tapePending.openedAtMs }) == null
          ? tapePending : null;
        const side = (dbPending?.side === "yes" || dbPending?.side === "no")
          ? dbPending.side
          : tapePendingUsable?.side ?? null;
        const ticker = dbPending?.ticker ?? tapePendingUsable?.ticker ?? null;
        const contracts = Math.round(
          (dbPending?.contractsFilled ?? dbPending?.contracts ?? tapePendingUsable?.contracts ?? 0) as number,
        );
        const entry = Math.round(
          (dbPending?.fillPriceCents ?? dbPending?.entryPriceCents ?? tapePendingUsable?.entryPriceCents ?? 0) as number,
        );
        const strategyId = String(
          dbPending?.strategyId ?? tapePendingUsable?.strategyId ?? "CONFLUENCE_CASCADE",
        );
        if (ticker && side && contracts > 0 && entry > 0) {
          const band = getEntryPriceBand(strategyId, { contractDurationMins: 15 });
          const openedAt = dbPending?.createdAt instanceof Date
            ? dbPending.createdAt.getTime()
            : (tapePendingUsable?.openedAtMs ?? now);
          this.setOpenTrade({
            ticker,
            side,
            contracts,
            entryPriceCents: entry,
            floorStrike: dbPending?.floorStrike ?? 0,
            signal: side === "yes" ? "LONG" : "SHORT",
            confidence: 0,
            velocity: 0,
            openedAt,
            dbId: dbPending?.id ?? null,
            orderId: dbPending?.orderId ?? null,
            periodKey: ticker, // no bot_trades.period_key column — ticker is the period key
            paper: true,
            fillOrigin: FILL_ORIGIN_BOT,
            addedContracts: false,
            maxGainCents: 0,
            strategyId,
            isOTMAsymmetry: false,
            pathRide: tapePendingUsable?.pathRide === true || isPathRideStrategyId(strategyId),
            entryBandMin: band.min,
            entryBandMax: band.max,
            contractDurationMins: dbPending?.contractDurationMins ?? 15,
            balanceBeforeCents: dbPending?.balanceBeforeCents ?? null,
            chartPoints: [],
            // SEV1 (sweep S3): carry the contract close so the exit guard and
            // rollover settlement know when this contract ended.
            closeTimeMs: resolveTradeCloseMs({ ticker }) ?? undefined,
          });
          this.state = "IN_TRADE";
          this.heldPendingFromRestart = true;
          this.log("warn",
            `♻️ SEV0 mid-trade rehydrate: paper ${side.toUpperCase()} ${contracts}× ${ticker} @${entry}¢` +
            ` (${strategyId}) — openTrade restored; no phantom STARTUP_RECOVERY wipe`,
          );
        }
      }

      // Fail-closed orphan void (prefer cancel): after rehydrate attempt, ANY
      // paper pending still without openTrade → STARTUP_ORPHAN_VOID (0 pnl).
      // Covers live #11-class ghosts and stale rows recoverStale did not close.
      // Never invent win/loss. Clears heldPending when all voids succeed.
      if (this.config.paperMode === true && this.openTrade == null) {
        const orphanPaper = rows.filter(r =>
          r.isPaper === true
          && (r.outcome === "pending" || r.outcome === "unresolved"),
        );
        if (shouldVoidStartupOrphan({
          paperMode: true,
          openTradeNull: true,
          hasPaperPending: orphanPaper.length > 0,
          rehydrateAttempted: true,
        })) {
          let voidFailed = false;
          const orphanTapeRows = loadPaperTrades();
          for (const orphan of orphanPaper) {
            // SEV1 (sweep S3): the tape already booked this fill's close (a settle
            // DB write failed). Repair PG from the tape instead of re-scoring it
            // from the Kalshi binary result or voiding it (the #72 class).
            const tapeClosed = findTapeCloseForPendingFill(orphanTapeRows, {
              tradeId: orphan.id,
              ticker: orphan.ticker,
              side: orphan.side,
              contracts: orphan.contractsFilled ?? orphan.contracts,
              openedAtMs: orphan.createdAt instanceof Date ? orphan.createdAt.getTime() : null,
            });
            if (tapeClosed && (tapeClosed.outcome === "win" || tapeClosed.outcome === "loss")) {
              const pnl = Math.round(Number(tapeClosed.pnlCents ?? 0));
              const settledMs = typeof tapeClosed.settledAt === "number" ? tapeClosed.settledAt : (tapeClosed.ts ?? now);
              try {
                await db.update(botTrades).set({
                  outcome: tapeClosed.outcome, pnlCents: pnl, pnlDollars: pnl / 100,
                  settledAt: new Date(settledMs), exitReason: String(tapeClosed.exitReason ?? "SETTLEMENT"),
                }).where(and(eq(botTrades.id, orphan.id), or(eq(botTrades.outcome, "pending"), eq(botTrades.outcome, "unresolved"))));
                this.log("warn", `🧾 Restart: #${orphan.id} ${orphan.ticker} PG repaired from tape close (${tapeClosed.exitReason} ${pnl}¢) — not voided / not re-scored`);
              } catch (repairErr) {
                voidFailed = true;
                this.log("error", `Failed to repair #${orphan.id} from tape: ${(repairErr as Error).message}`);
              }
              continue;
            }
            const stillLive = isPendingStillLive(orphan, now);
            const reason = stillLive
              ? STARTUP_ORPHAN_VOID
              : (shouldVoidOrphanOpenCleared({
                  paperMode: true,
                  openTradeNull: true,
                  hasPaperPending: true,
                  pendingStillLive: false,
                }) ? ORPHAN_OPEN_CLEARED_VOID : STARTUP_ORPHAN_VOID);
            // D5 — contract closed during downtime: settle from Kalshi's result
            // for this exact ticker instead of a 0-pnl void (which erased real
            // losses and let the idle reconcile release the debit). Unknown
            // after retries → unresolved (debit held), never cancelled.
            if (!stillLive) {
              try {
                const side: "yes" | "no" = orphan.side === "no" ? "no" : "yes";
                const contracts = orphan.contractsFilled ?? orphan.contracts ?? 0;
                const entryPx = orphan.fillPriceCents ?? orphan.entryPriceCents ?? 0;
                const result = contracts > 0 && entryPx > 0
                  ? await resolveOrphanResult({ ticker: orphan.ticker, fetcher: fetchMarketResultPublic, attempts: 3 })
                  : null;
                if (result == null) {
                  await markTradeUnresolved(orphan.id, ORPHAN_RESULT_UNKNOWN,
                    `Contract closed during downtime; Kalshi result for ${orphan.ticker} not available after retries. Held (debit kept) — not voided; startup recovery retries.`);
                  this.log("warn", `🧹 ${ORPHAN_RESULT_UNKNOWN} #${orphan.id} ${orphan.ticker} — Kalshi result unknown; marked unresolved (debit held, no void)`);
                  continue;
                }
                const st = orphanSettlement({ side, contracts, entryPriceCents: entryPx, result });
                await db.update(botTrades).set({
                  outcome: st.outcome,
                  pnlCents: st.pnlCents,
                  pnlDollars: st.pnlCents / 100,
                  feeCents: st.feeCents,
                  settledAt: new Date(),
                  exitReason: ORPHAN_SETTLED_KALSHI,
                  exitReasonText: `Contract closed during downtime; settled from Kalshi result=${result} for ${orphan.ticker} (was ${reason} 0-pnl void before D5).`,
                }).where(eq(botTrades.id, orphan.id));
                try {
                  // R4 — idempotent per trade id (restart/retry must not add a 2nd settle row).
                  appendPaperTradeCloseOnce({
                    ts: Date.now(),
                    ticker: orphan.ticker,
                    tradeId: orphan.id,
                    side,
                    contracts,
                    entryPriceCents: entryPx,
                    strategyId: orphan.strategyId ?? null,
                    fillOrigin: "bot",
                    outcome: st.outcome,
                    pnlCents: st.pnlCents,
                    exitReason: ORPHAN_SETTLED_KALSHI,
                    settledAt: Date.now(),
                  });
                } catch { /* tape best-effort */ }
                this.log("warn", `🧾 ${ORPHAN_SETTLED_KALSHI} #${orphan.id} ${orphan.ticker} ${side.toUpperCase()} ${contracts}@${entryPx}¢ — Kalshi result=${result} → ${st.outcome.toUpperCase()} ${st.pnlCents >= 0 ? "+" : ""}${st.pnlCents}¢`);
                continue;
              } catch (settleErr) {
                voidFailed = true;
                this.log("error", `Failed to settle closed orphan #${orphan.id}: ${(settleErr as Error).message}`);
                continue;
              }
            }
            try {
              await db.update(botTrades).set({
                outcome: "cancelled",
                exitReason: reason,
                cancelReason: reason,
                pnlCents: 0,
                pnlDollars: 0,
                cancelledAt: new Date(),
                settledAt: new Date(),
                exitReasonText:
                  reason === STARTUP_ORPHAN_VOID
                    ? "Voided at startup/bounce: paper pending without openTrade (STARTUP_ORPHAN_VOID). 0 pnl — fail-closed prefer cancel over ghost hold."
                    : "Voided: openTrade cleared while PG pending remained (ORPHAN_OPEN_CLEARED_VOID). 0 pnl — do not invent win/loss.",
              }).where(eq(botTrades.id, orphan.id));
              try {
                // SEV1 (sweep S3): idempotent per trade id (boot race / retry).
                appendPaperTradeCloseOnce({
                  ts: Date.now(),
                  ticker: orphan.ticker,
                  tradeId: orphan.id,
                  side: (orphan.side === "yes" || orphan.side === "no") ? orphan.side : "yes",
                  contracts: orphan.contractsFilled ?? orphan.contracts ?? 0,
                  entryPriceCents: orphan.fillPriceCents ?? orphan.entryPriceCents ?? 0,
                  strategyId: orphan.strategyId ?? null,
                  fillOrigin: "bot",
                  outcome: "cancelled",
                  pnlCents: 0,
                  exitReason: reason,
                  settledAt: Date.now(),
                });
              } catch { /* tape best-effort */ }
              this.log("warn",
                `🧹 ${reason} #${orphan.id} ${orphan.ticker} — 0 pnl (openTrade was null; live=${stillLive})`,
              );
            } catch (voidErr) {
              voidFailed = true;
              this.log("error",
                `Failed to void orphan pending #${orphan.id}: ${(voidErr as Error).message}`,
              );
            }
          }
          // Cleared ghosts → drop restart latch; void failure keeps block.
          this.heldPendingFromRestart = voidFailed;
          // Voided fills must release their cost+fee debit from the paper book.
          void this.restorePaperLedgerFromBotTrades();
        }
      }
    } catch (err) {
      // PG-down / null tape must not freeze the paper desk forever.
      // Hold ONLY when we already confirmed live pending before the failure
      // (e.g. rehydrate threw). start() pre-sets true for the await window —
      // that fail-closed latch MUST clear here when the select never confirmed.
      const msg = (err as Error).message ?? String(err);
      this.log("error",
        `Restart pending-exposure check failed — not blocking (soft): ${msg}`,
      );
      this.heldPendingFromRestart = confirmedLivePending;
    }
  }

  /**
   * Force a settlement check for the current open trade.
   * Used by the watchdog when the open trade is unusually old.
   */
  forceSettleCheck() {
    if (this.openTrade && (this.state === "WATCHING" || this.state === "IN_TRADE")) {
      console.info("[bot] forceSettleCheck() called by watchdog");
      void this.detectSettlement();
    }
  }

  // ── Public API ──────────────────────────────────────────────────────────────

  /** Persist ON/OFF transition for the 24/7 uptime log (transitions only). */
  private reportUptime(reason?: string) {
    try {
      botUptimeLog.recordTransition({
        state: this.state,
        enabled: this.config.enabled === true,
        paperMode: this.config.paperMode === true,
        reason,
      });
    } catch (err) {
      console.error("[bot] uptime log failed:", (err as Error).message);
    }
  }

  /** Optional ≤1/hour heartbeat while armed — never spam ticks. */
  private maybeUptimeHeartbeat() {
    try {
      botUptimeLog.maybeHeartbeat({
        state: this.state,
        enabled: this.config.enabled === true,
        paperMode: this.config.paperMode === true,
      });
    } catch {
      /* non-fatal */
    }
  }

  /** GE_013 — last paper-history preflight result (status / ops). */
  lastPaperRecoveryInspection: { ok: boolean; code: string; rows: number; enforced: boolean; atMs: number } | null = null;

  start() {
    if (this.state === "WATCHING" || this.state === "IN_TRADE") return;
    // GE_013 (safe port): read-only integrity preflight of the local paper
    // ledger/tape BEFORE enabling. Default = warn only (legacy histories can
    // legitimately fail strict checks); PAPER_RECOVERY_ENFORCE=1 refuses start.
    if (this.config.paperMode) {
      try {
        const recovery = inspectPaperRecovery(this.config.paperStartingBalanceCents);
        const enforced = process.env.PAPER_RECOVERY_ENFORCE === "1";
        this.paperReconcileHalt = enforced && !recovery.ok;
        this.lastPaperRecoveryInspection = { ok: recovery.ok, code: recovery.code, rows: recovery.rows, enforced, atMs: Date.now() };
        if (!recovery.ok) {
          if (enforced) {
            this.config.enabled = false;
            this.didNotResumeAfterRestart = true;
            this.didNotResumeReason = recovery.code;
            this.log("error", `PAPER_RECOVERY_BLOCKED: ${recovery.code}; preserve files and reconcile; no reset.`);
            return;
          }
          this.log("warn", `PAPER_RECOVERY_WARN (GE_013, not enforced): ${recovery.code} — local paper history failed the strict integrity preflight; reconcile before enabling PAPER_RECOVERY_ENFORCE.`);
        }
      } catch {
        if (process.env.PAPER_RECOVERY_ENFORCE === "1") {
          this.paperReconcileHalt = true;
          this.config.enabled = false;
          this.didNotResumeAfterRestart = true;
          this.didNotResumeReason = "PAPER_RECOVERY_CHECK_FAILED";
          this.log("error", "PAPER_RECOVERY_CHECK_FAILED: enforced preflight unavailable; no start.");
          return;
        }
        this.log("warn", "PAPER_RECOVERY_CHECK_FAILED: advisory preflight unavailable");
      }
    }
    this.config.enabled = true;
    savePersistedConfig(this.config);
    // Post-init: strategy-library STRATEGIES is fully initialized (admission
    // must not call this at module load — TDZ circular import).
    try { warnOnOrphanedStrategiesAtStartup(); } catch { /* observatory only */ }
    // Task #604: fail-closed until the pending-row check completes so a tick
    // cannot place a second position during the await window after restart.
    this.heldPendingFromRestart = true;
    void this.adoptRestartPendingGuard();
    this.startSettlePersistRetryLoop();
    // A real manual/auto-start resolves any earlier "didn't resume after
    // restart" alert — whatever blocked it is no longer true right now.
    this.didNotResumeAfterRestart = false;
    this.didNotResumeReason = null;
    this.state          = "WATCHING";
    const paper         = this.config.paperMode ? " [PAPER]" : "";
    this.log("info", `Bot started v5${paper}`);
    this.reportUptime("start");

    if (this.config.paperMode) {
      // Paper cash lives in data/paper-ledger.json. Load a sane session
      // instead of snapping to paperStartingBalanceCents ($313). The pin
      // remains the fallback when the file is missing or rejected (including
      // the stale $1000 / 100_000¢ field default).
      const startCents = this.config.paperStartingBalanceCents;
      const loaded = loadPaperLedger(startCents);
      if (loaded) {
        this.paperVirtualBalanceCents = loaded.virtualCents;
        this.peakBalanceCents = loaded.peakCents;
        this.paperStats = { pnlCents: loaded.pnlCents, wins: loaded.wins, losses: loaded.losses };
        this.paperSessionStartTs = loaded.sessionStartTs ?? 0;
        // Reserve pool is locked out of virtualCents — restore it too so
        // cash + reserve still equals start + fee-net P&L after a restart.
        this.reservePoolCents = loaded.reserveCents ?? 0;
        // Halt / WR stay on todayStats (bot-only). Never copy combined paper
        // ledger into todayStats — manuals and stale session tape must not
        // re-trip DAILY_LOSS_HALT after bounce.
        if (this.todayStats.date !== etDateKey()) {
          // Daily-loss halt (paper, 2026-09-26): seed today's bot-only fee-net
          // P&L from the tape so a restart cannot clear a same-day halt.
          const day = etDateKey();
          let seed = { pnlCents: 0, wins: 0, losses: 0 };
          try { seed = paperBotDayPnlFromTape(loadPaperTrades(), day, this.paperSessionStartTs); } catch { /* seed 0 */ }
          this.todayStats = { pnlCents: seed.pnlCents, wins: seed.wins, losses: seed.losses, date: day };
        }
        this.log("info", `📄 Paper sim: restored ledger $${(this.paperVirtualBalanceCents / 100).toFixed(2)} (display ${loaded.pnlCents}¢; daily halt uses ET-day bot todayStats ${this.todayStats.pnlCents}¢, paper and live)`);
      } else {
        this.paperVirtualBalanceCents = this.config.paperStartingBalanceCents;
        this.peakBalanceCents = this.paperVirtualBalanceCents;
        // Dual-ledger SEV1: even if virtual is outside 50–150% sanity band,
        // preserve sessionStartTs watermark so a bounce does not reopen the
        // pre-reset bot_trades window.
        const watermark = peekPaperLedgerSessionStartTs();
        if (watermark != null && watermark > 0) {
          this.paperSessionStartTs = watermark;
          this.log("info", `📄 Paper sim: virtual pin $${(this.paperVirtualBalanceCents / 100).toFixed(2)} (kept sessionStartTs=${watermark})`);
        } else {
          this.log("info", `📄 Paper sim: virtual balance $${(this.paperVirtualBalanceCents / 100).toFixed(2)}`);
        }
      }
      // Overlay from bot_trades (paper rows only). Never copy Kalshi cash.
      void this.restorePaperLedgerFromBotTrades();
    } else {
      // Probe auth immediately so the warning appears before any trade attempt.
      void this.probeAuth();
    }

    mtfAnalyzer.start();
    // Idle-fallback timer: keeps the loop ticking when quotes are quiet, and is
    // the ONLY driver when the WS is down. Event-driven wakes (below) fire the
    // tick sooner when a real quote arrives; if the WS never delivers, behavior
    // is identical to the old fixed-interval loop.
    this.tickTimer      = setInterval(() => this.tick(), TICK_IDLE_INTERVAL_MS);
    // Wake the decision tick the instant a NEW executable quote arrives, instead
    // of waiting out the idle interval. Coalesced to at most one tick per
    // TICK_MIN_INTERVAL_MS so a burst of quotes can't spin the loop.
    this._unsubQuoteWake = kalshiWS.onExecutableQuote(() => this.scheduleWakeTick());
    this.balanceTimer   = setInterval(() => this.refreshBalance(), 15_000);
    // Paper and live: poll Kalshi positions so a MANUAL fill blocks a second
    // bot position. Paper openTrade is not Kalshi-tracked (see trackedKalshiTradeForAudit).
    if (this.accountPositionReconcileTimer) {
      clearInterval(this.accountPositionReconcileTimer);
      this.accountPositionReconcileTimer = null;
    }
    this.accountPositionReconcileTimer = setInterval(
      () => { void this.reconcileAccountPositionsWithKalshi(); },
      ACCOUNT_POSITION_RECONCILE_INTERVAL_MS,
    );
    void this.reconcileAccountPositionsWithKalshi();
    void ensureFillOriginColumn().catch(() => { /* non-fatal; insert uses DB default */ });
    // Background pre-trade sim: runs every 500 ms so a verdict is ready the moment
    // entry conditions pass, eliminating the inline DB/Monte-Carlo latency.
    this.pretradeTimer  = setInterval(() => { void this.backgroundPreTrade(); }, 250);
    // 1-hour OTM Breakout poller — starts REST polling, evaluates every 30 s
    if (this.config.enable1HContracts) {
      hourlyPoller.start();
      // Aligned with the 30s REST poll cadence — evaluating every 10s wasted
      // two of every three runs on identical (stale) data.
      this.hourlyCheckTimer = setInterval(() => { void this.evaluateHourlyTick(); }, 30_000);
      this.log("info", "🕐 1H contract poller started (OTM_BREAKOUT_EXPANSION)");
    }

    // Subscribe to WS degraded events — pause entries (paper and live) on consecutive failures
    this.wsDegraded = kalshiWS.isDegraded();  // sync initial state
    this._unsubWsDegraded = kalshiWS.onDegraded((degraded) => {
      this.wsDegraded = degraded;
      if (degraded) {
        this.log("warn", "⚡ WS degraded — entries paused until connection recovers");
      } else {
        this.log("info", "✅ WS recovered — entries resumed");
      }
    });

    this.tick();
    this.refreshBalance();

    // ── Expert Agent ─────────────────────────────────────────────────────────
    if (this.config.useExpertAgent) {
      expertAgent.start();
      expertAgent.on("assessment", (a: import("./expert-agent.js").AgentAssessment) => {
        const adjLabel = a.confAdj > 0 ? `+${a.confAdj}` : String(a.confAdj);
        this.log("agent",
          `🤖 Agent: ${a.signal} (${a.confidence}%) ${a.riskLevel} risk · conf${adjLabel}pts · ${a.reasoning}` +
          (a.observations.length ? ` · ${a.observations.join(" · ")}` : "")
        );
      });
    }
  }

  stop(reason = "user stop") {
    this.config.enabled = false;
    savePersistedConfig(this.config);
    if (this.tickTimer)          clearInterval(this.tickTimer);
    if (this.balanceTimer)       clearInterval(this.balanceTimer);
    if (this.accountPositionReconcileTimer) {
      clearInterval(this.accountPositionReconcileTimer);
      this.accountPositionReconcileTimer = null;
    }
    if (this.pretradeTimer)      clearInterval(this.pretradeTimer);
    if (this.hourlyCheckTimer)   { clearInterval(this.hourlyCheckTimer); this.hourlyCheckTimer = null; }
    if (this._unsubWsDegraded)   { this._unsubWsDegraded(); this._unsubWsDegraded = null; }
    if (this._unsubQuoteWake)    { this._unsubQuoteWake(); this._unsubQuoteWake = null; }
    if (this._coalesceTimer)     { clearTimeout(this._coalesceTimer); this._coalesceTimer = null; }
    this.pretradeTimer = null;
    hourlyPoller.stop();
    this.state = "STOPPED";
    expertAgent.stop();
    expertAgent.removeAllListeners("assessment");
    this.log("warn", "Bot stopped");
    this.reportUptime(reason);
  }

  updateConfig(partial: Partial<BotConfig> & { confirmLiveRealMoney?: string }) {
    // Fail-closed PATCH surface: same strip HTTP/agent use, so a direct
    // updateConfig({ enable1HLive:true }) / ExpertAgent-with-key / empty
    // disabledStrategies cannot merge past composer-lock alone.
    const rawPatch = partial as Record<string, unknown>;
    const liveConfirm = typeof rawPatch.confirmLiveRealMoney === "string"
      ? rawPatch.confirmLiveRealMoney
      : undefined;
    const autoModeConfirm = typeof rawPatch.confirmAutoMode === "string"
      ? rawPatch.confirmAutoMode
      : undefined;
    const sanitized = sanitizeConfigPatch(rawPatch, this.config);
    for (const r of sanitized.refused) {
      this.log("warn",
        `PATCH_REFUSED ${r.key}=${JSON.stringify(r.value)} — ${r.reason}`);
    }
    for (const note of sanitized.notes) {
      this.log("warn", `PATCH_NOTE ${note}`);
    }
    const accepted = { ...sanitized.accepted };
    delete accepted.confirmLiveRealMoney;
    delete accepted.confirmAutoMode;
    // Agent control + autopilot flags: paper-only. Refuse arming when resulting paperMode is false.
    {
      const nextPaper = Object.prototype.hasOwnProperty.call(accepted, "paperMode")
        ? accepted.paperMode === true
        : this.config.paperMode === true;
      const gate = refuseAgentAuthorityWhenNotPaper(
        {
          agentControlMode: accepted.agentControlMode as boolean | undefined,
          requireAgentEntryApproval: accepted.requireAgentEntryApproval as boolean | undefined,
          brainCenterAuthority: accepted.brainCenterAuthority as boolean | undefined,
          paperMode: nextPaper,
        },
        this.config.paperMode === true,
      );
      if (!gate.ok) {
        delete accepted.agentControlMode;
        delete accepted.requireAgentEntryApproval;
        delete accepted.brainCenterAuthority;
        this.log("warn", `PATCH_REFUSED agent authority — ${gate.reason}`);
      }
      const apGate = refuseAutopilotWhenNotPaper(
        {
          autopilotMode: accepted.autopilotMode as boolean | undefined,
          paperMode: nextPaper,
        },
        this.config.paperMode === true,
      );
      if (!apGate.ok) {
        delete accepted.autopilotMode;
        this.log("warn", `PATCH_REFUSED autopilotMode — ${apGate.reason}`);
      }
      // Autopilot ON → expand accepted with best paper bundle (still paper-forced).
      if (accepted.autopilotMode === true && nextPaper === true) {
        const best = applyBestPaperAutopilotSettings();
        Object.assign(accepted, best);
        accepted.paperMode = true;
        accepted.requireAgentEntryApproval = false;
      }
    }
    partial = accepted as Partial<BotConfig>;
    const wasInPaper        = this.config.paperMode;
    const oldPaperStarting  = this.config.paperStartingBalanceCents;
    const oldDisabled       = new Set(this.config.disabledStrategies ?? []);
    const prevMinConfidence = this.config.minConfidence;
    // P0: never silently drop frozenCcMode on a patch that omits the key
    // (full UI Save / agent partial must not bounce-leak constructor false).
    const prevFrozenCc = this.config.frozenCcMode === true;
    const patchSetsFrozenCc = Object.prototype.hasOwnProperty.call(accepted, "frozenCcMode");
    const prevAutopilot = this.config.autopilotMode === true;
    const flippingDailyTargetOn = partial.useDailyTarget === true && !this.config.useDailyTarget;
    this.config             = { ...this.config, ...partial };
    const locked = applyComposerLocks(this.config, {
      openRouterKey: process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY ?? "",
      confirmLiveRealMoney: liveConfirm,
      confirmAutoMode: autoModeConfirm,
    });
    this.config = locked.config;
    if (patchSetsFrozenCc) {
      this.config.frozenCcMode = accepted.frozenCcMode === true;
    } else if (prevFrozenCc) {
      this.config.frozenCcMode = true;
    }
    for (const note of locked.notes) this.log("warn", `LOCK: ${note}`);
    // Stellar 2026-09-10: 2-loss cool-down removed completely — refuse re-arm via UI/patch.
    if (this.config.useLossCooldown) {
      this.log("warn", "LOCK: useLossCooldown forced false (2-loss cool-down removed)");
      this.config.useLossCooldown = false;
    }
    // Agent control plane + autopilot are paper-only.
    if (this.config.paperMode !== true) {
      if (this.config.agentControlMode || this.config.requireAgentEntryApproval || this.config.brainCenterAuthority) {
        this.log("warn", "LOCK: agentControlMode forced false (!paperMode)");
      }
      if (this.config.autopilotMode) {
        this.log("warn", "LOCK: autopilotMode forced false (!paperMode)");
      }
      this.config.agentControlMode = false;
      this.config.requireAgentEntryApproval = false;
      this.config.brainCenterAuthority = false;
      this.config.autopilotMode = false;
    }
    // Autopilot newly armed (false→true): clear sticky halt + ensure bot running.
    // While already on, do not wipe operator directives on unrelated patches.
    if (
      this.config.autopilotMode === true &&
      this.config.paperMode === true &&
      !prevAutopilot
    ) {
      this.clearAgentHaltDirectives("autopilotMode armed");
      this.config.requireAgentEntryApproval = false;
      if (!this.config.enabled || this.state === "STOPPED" || this.state === "IDLE") {
        try {
          this.start();
        } catch (err) {
          this.log("warn", `autopilot start failed: ${err instanceof Error ? err.message : String(err)}`);
        }
      }
    } else if (this.config.autopilotMode === true && this.config.paperMode === true) {
      // Keep unattended: never re-arm requireAgentEntryApproval under autopilot.
      this.config.requireAgentEntryApproval = false;
    }
    // Fail closed: enabling the daily-target engine must not cut admission
    // floors. PATH_GATE / EV / minConfidence stay independent of dailyTargetPct.
    if (flippingDailyTargetOn && this.config.minConfidence < prevMinConfidence) {
      this.log("warn",
        `useDailyTarget=true refused to cut minConfidence ${prevMinConfidence}→${this.config.minConfidence}`);
      this.config.minConfidence = prevMinConfidence;
    }
    // The UI/API may present this as configurable, but economic parity is a
    // hard floor: accepting a value below 1 would re-enable the exact
    // risk-more-than-reward outcome the final admission gate prevents.
    this.config.minRewardRiskRatio = Math.max(
      MIN_REWARD_RISK_RATIO,
      Number.isFinite(this.config.minRewardRiskRatio)
        ? this.config.minRewardRiskRatio
        : MIN_REWARD_RISK_RATIO,
    );
    savePersistedConfig(this.config);
    // CONFIG_GUARD bookkeeping: this is the ONLY place lastGoodManual moves,
    // so runConfigGuard() can tell "changed via updateConfig()" apart from
    // "config mutated some other way" — see config-guard.ts.
    this.lastGoodManual = snapshotManualFloors({
      autoMode:      this.config.autoMode,
      paperMode:     this.config.paperMode,
      enabled:       this.config.enabled,
      minConfidence: this.config.minConfidence,
      minVelocity:   this.config.minVelocity,
      minEntryPrice: this.config.minEntryPrice,
      maxEntryPrice: this.config.maxEntryPrice,
      minProbEdge:   this.config.minProbEdge,
    });

    // NEVER wipe the paper ledger from a bulk UI/config save.
    // paperStartingBalanceCents may change on PUT /bot/config (94-field saves);
    // that must NOT call resetPaperSim(). Only POST /bot/paper/reset with confirm
    // "RESET PAPER" may wipe. Prefer not wiping PnL on paperMode false→true either.
    const balChanged = this.config.paperMode
      && partial.paperStartingBalanceCents !== undefined
      && partial.paperStartingBalanceCents !== oldPaperStarting;
    if (balChanged) {
      this.log("warn",
        `REFUSE_PAPER_RESET paperStartingBalanceCents ${oldPaperStarting}→${this.config.paperStartingBalanceCents} ` +
        `on updateConfig — ledger untouched; use POST /bot/paper/reset with confirm "RESET PAPER"`);
    }
    if (!wasInPaper && this.config.paperMode) {
      this.log("warn",
        `REFUSE_PAPER_RESET paperMode false→true on updateConfig — ledger untouched; ` +
        `use POST /bot/paper/reset with confirm "RESET PAPER" if a fresh book is required`);
    }

    // Live balance must stay fresh (or start being fetched) the instant paper
    // mode is toggled off, without waiting for the bot to be started.
    if (partial.paperMode !== undefined && partial.paperMode !== wasInPaper) {
      this.ensureIdleBalancePolling();
    }

    // ── Hourly horizon runtime toggle ────────────────────────────────────────
    // Start/stop the hourly poller + evaluation timer immediately when the
    // enable1HContracts flag flips while the bot is running — no restart needed.
    if (partial.enable1HContracts !== undefined && this.config.enabled &&
        (this.state === "WATCHING" || this.state === "IN_TRADE")) {
      if (this.config.enable1HContracts && !this.hourlyCheckTimer) {
        hourlyPoller.start();
        this.hourlyCheckTimer = setInterval(() => { void this.evaluateHourlyTick(); }, 30_000);
        this.log("info", "🕐 1H contracts enabled — hourly poller started (no restart needed)");
      } else if (!this.config.enable1HContracts && this.hourlyCheckTimer) {
        clearInterval(this.hourlyCheckTimer);
        this.hourlyCheckTimer = null;
        // Keep the poller alive only if a live hourly trade still needs marks.
        if (!(this.openTrade && this.openTrade.contractDurationMins === 60)) hourlyPoller.stop();
        this.log("info", "🕐 1H contracts disabled — hourly evaluation stopped (no restart needed)");
      }
    }

    // Emit a clear per-strategy log line when the disabled list changes so users
    // can confirm the toggle takes effect on the very next tick without restarting.
    if (partial.disabledStrategies !== undefined) {
      const newDisabled = new Set(partial.disabledStrategies);
      for (const id of oldDisabled) {
        if (!newDisabled.has(id))
          this.log("info", `✅ Strategy re-enabled: ${id} — active on next tick`);
      }
      for (const id of newDisabled) {
        if (!oldDisabled.has(id))
          this.log("info", `⛔ Strategy disabled: ${id} — skipped from next tick`);
      }
    }

    // Log only the keys that changed (not the full config blob — saves like config updates
    // send the entire 40-field object which spams the live log as unreadable JSON).
    const keys = Object.keys(partial).filter(k => k !== "disabledStrategies");
    if (keys.length > 0) {
      const summary = keys.length <= 4
        ? keys.map(k => `${k}=${JSON.stringify((partial as Record<string, unknown>)[k])}`).join(', ')
        : `${keys.length} fields updated`;
      this.log("info", `✓ Config saved — ${summary}`);
    } else if (partial.disabledStrategies === undefined) {
      this.log("info", `✓ Config saved`);
    }
  }

  /**
   * CONFIG_GUARD (Phase 1, 2026-08-15 SYSTEM QUALITY UPGRADE): periodic
   * self-check that (a) logs the live entry-floor config for visibility and
   * (b) detects config that changed WITHOUT going through updateConfig() —
   * the exact failure mode that silently left autoMode=true/minConfidence=72
   * live earlier this session, with no record of how it got there. Runs on
   * its own timer independent of start()/enabled (see the singleton wiring
   * below) — a stopped bot's config can still drift and should still be
   * checked. On drift, restores the last known-good manual values via the
   * normal updateConfig() persist path; never writes .bot-config.json
   * directly.
   */
  runConfigGuard() {
    // Adapt may stay ON. Do not snap autoMode true→false.
    // paperMode must stay true until LIVE REAL MONEY. Restore in-memory + persist
    // via updateConfig on drift; never persist a floor-cutting composer.
    {
      const shaped = applyPaperReleaseConfigShape(this.config);
      this.config = shaped.config as typeof this.config;
      for (const n of shaped.notes) this.log("info", `[paper-release] ${n}`);
    }
    if (this.config.paperMode === false) {
      this.config.paperMode = true;
      this.log("error", "CONFIG_GUARD restored paperMode=true (until LIVE REAL MONEY)");
    }
    const disabledN = (this.config.disabledStrategies ?? []).length;
    this.log("info",
      `CONFIG_GUARD autoMode=${this.config.autoMode} minConfidence=${this.config.minConfidence} ` +
      `minVelocity=${this.config.minVelocity} minEntryPrice=${this.config.minEntryPrice} ` +
      `maxEntryPrice=${this.config.maxEntryPrice} minProbEdge=${this.config.minProbEdge} ` +
      `paperMode=${this.config.paperMode} disabled=${disabledN}`);

    // First run (or a run before any updateConfig() call this process
    // lifetime): nothing to compare against yet — adopt the current config
    // as the known-good baseline rather than flag day-one config as drift.
    if (this.lastGoodManual === null) {
      this.lastGoodManual = snapshotManualFloors({
        autoMode:      this.config.autoMode,
        paperMode:     this.config.paperMode,
        enabled:       this.config.enabled,
        minConfidence: this.config.minConfidence,
        minVelocity:   this.config.minVelocity,
        minEntryPrice: this.config.minEntryPrice,
        maxEntryPrice: this.config.maxEntryPrice,
        minProbEdge:   this.config.minProbEdge,
      });
      return;
    }

    const current: ManualFloorSnapshot = snapshotManualFloors({
      autoMode:      this.config.autoMode,
      paperMode:     this.config.paperMode,
      enabled:       this.config.enabled,
      minConfidence: this.config.minConfidence,
      minVelocity:   this.config.minVelocity,
      minEntryPrice: this.config.minEntryPrice,
      maxEntryPrice: this.config.maxEntryPrice,
      minProbEdge:   this.config.minProbEdge,
    });
    const result = detectConfigDrift(current, this.lastGoodManual);
    if (!result.drifted) return;

    const restore = configGuardRestorePatch(this.lastGoodManual);
    this.log("error",
      `CONFIG_DRIFT_ALERT ${result.reasons.join("; ")} — restoring last known-good floors ` +
      `(autoMode kept ${this.config.autoMode}, minConfidence=${restore.minConfidence}, minVelocity=${restore.minVelocity}, paperMode=${restore.paperMode})`);
    this.updateConfig(restore);
  }

  resetPaperSim() {
    this.paperVirtualBalanceCents = this.config.paperStartingBalanceCents;
    this.paperStats               = { pnlCents: 0, wins: 0, losses: 0 };
    this.resetOtmSessionStats();
    this.peakBalanceCents         = this.config.paperStartingBalanceCents;
    this.reservePoolCents         = 0;
    this.openTradeMaxGain         = 0;
    this.paperSessionStartTs      = Date.now();
    // Dual-ledger SEV1: reset day counters with the paper session so todayStats
    // cannot disagree with paperStats after a reset (no UTC/en-US date skew).
    this.todayStats               = { pnlCents: 0, wins: 0, losses: 0, date: etDateKey() };
    this.consecutiveLosses        = 0;
    this.currentStreak            = 0;
    this.persistPaperLedger();
    this.log("info", `📄 Paper sim reset — virtual balance $${(this.paperVirtualBalanceCents / 100).toFixed(2)}`);
  }

  private persistPaperLedger(): void {
    if (!this.config.paperMode) return;
    savePaperLedger({
      virtualCents: Math.round(this.paperVirtualBalanceCents),
      peakCents: Math.round(this.peakBalanceCents),
      pnlCents: Math.round(this.paperStats.pnlCents),
      wins: this.paperStats.wins,
      losses: this.paperStats.losses,
      trades: this.paperStats.wins + this.paperStats.losses,
      sessionStartTs: this.paperSessionStartTs > 0 ? this.paperSessionStartTs : undefined,
      reserveCents: Math.max(0, Math.round(this.reservePoolCents)),
    });
  }

  /** Public hook: re-run the tape-first paper ledger rebuild (after a recovery tape close). */
  async reloadPaperLedgerFromTape(): Promise<void> {
    await this.restorePaperLedgerFromBotTrades();
  }

  /** Rebuild paper virtualCents from bot_trades. Never snaps Kalshi cash. */
  private async restorePaperLedgerFromBotTrades(): Promise<void> {
    if (!this.config.paperMode) return;
    try {
      // SEV0: prefer session paper-trades.jsonl closes over stale bot_trades
      // "pending". A PATH_RIDE_TP close that already credited virt + paperStats
      // must not be clobbered back to open-cost-only (virt↓, pnl/wins=0).
      const sessionStart = this.paperSessionStartTs;
      const tapeAll = loadPaperTrades();
      const tapeSession = sessionStart > 0
        ? tapeAll.filter((r) => typeof r.ts === "number" && r.ts >= sessionStart)
        : tapeAll;
      if (tapeSession.length > 0) {
        const next = paperLedgerFromSessionTape({
          startCents: this.config.paperStartingBalanceCents,
          sessionStartTs: sessionStart > 0 ? sessionStart : 0,
          rows: tapeSession,
          peakCents: this.peakBalanceCents,
          reservePct: this.config.reservePct ?? 0,
        });
        if (next.trades > 0 || (next.virtualCents !== Math.round(this.config.paperStartingBalanceCents))) {
          this.paperVirtualBalanceCents = next.virtualCents;
          this.peakBalanceCents = Math.max(this.peakBalanceCents, next.peakCents);
          this.paperStats = { pnlCents: next.pnlCents, wins: next.wins, losses: next.losses };
          // Tape virtualCents is net of the reserve lock; restore the pool so
          // cash + reserve == start + fee-net P&L (was reset to 0 on restart).
          this.reservePoolCents = next.reserveCents ?? 0;
          // Display book only. Do not overwrite bot-only todayStats (halt/WR).
          this.persistPaperLedger();
          this.log("info", `📄 Paper sim: ledger follows session tape $${(next.virtualCents / 100).toFixed(2)} (pnl ${next.pnlCents}¢ W${next.wins}/L${next.losses}; not Kalshi cash)`);
          return;
        }
      }

      const rows = await db.select({
        outcome: botTrades.outcome,
        pnlCents: botTrades.pnlCents,
        entryPriceCents: botTrades.entryPriceCents,
        contracts: botTrades.contracts,
        feeCents: botTrades.feeCents,
        contractsFilled: botTrades.contractsFilled,
        createdAt: botTrades.createdAt,
        settledAt: botTrades.settledAt,
      }).from(botTrades).where(eq(botTrades.isPaper, true));
      let settledPnl = 0;
      let wins = 0;
      let losses = 0;
      let openCost = 0;
      for (const r of rows) {
        // After paper reset, only count trades from this session so historical
        // bot_trades cannot re-inject pre-reset PnL and re-trigger day halt.
        if (sessionStart > 0) {
          const tsRaw = r.settledAt ?? r.createdAt;
          const ts = tsRaw instanceof Date ? tsRaw.getTime() : Number(tsRaw);
          if (!Number.isFinite(ts) || ts < sessionStart) continue;
        }
        if (r.outcome === "win") {
          wins++;
          settledPnl += r.pnlCents ?? 0;
        } else if (r.outcome === "loss") {
          losses++;
          settledPnl += r.pnlCents ?? 0;
        } else if (r.outcome === "pending" || r.outcome === "unresolved") {
          // D5 — unresolved (result unknown) keeps its debit; never released as idle.
          const n = r.contractsFilled ?? r.contracts ?? 0;
          const px = r.entryPriceCents ?? 0;
          openCost += paperFillCostCents(n, px);
        }
      }
      if (wins + losses === 0 && openCost === 0) {
        // Voided/cancelled paper fills leave no W/L and no open cost, but the
        // file ledger may still carry their fill debit (Sep 19
        // ORPHAN_OPEN_CLEARED_VOID left $313.00 -> $306.04 with 0 pnl).
        // An idle book must equal the starting balance: release the debit.
        const fixed = reconcileIdlePaperLedgerCents({
          startCents: this.config.paperStartingBalanceCents,
          virtualCents: this.paperVirtualBalanceCents,
          wins: this.paperStats.wins,
          losses: this.paperStats.losses,
          pnlCents: this.paperStats.pnlCents,
          openTradeNull: this.openTrade == null,
          openCostCents: 0,
        });
        if (fixed != null) {
          const released = fixed - this.paperVirtualBalanceCents;
          this.paperVirtualBalanceCents = fixed;
          this.peakBalanceCents = Math.max(this.peakBalanceCents, fixed);
          this.persistPaperLedger();
          this.log("info", `📄 Paper sim: idle book reconciled to start $${(fixed / 100).toFixed(2)} (released ${released}¢ held by voided/cancelled fills; not Kalshi cash)`);
        }
        if (sessionStart > 0) {
          this.log("info", `📄 Paper sim: session filter kept reset ledger (no post-reset bot_trades; sessionStartTs=${sessionStart})`);
        }
        return;
      }
      const next = paperLedgerFromBotTrades({
        startCents: this.config.paperStartingBalanceCents,
        settledPnlCents: settledPnl,
        openCostCents: openCost,
        wins,
        losses,
        peakCents: this.peakBalanceCents,
      });
      this.paperVirtualBalanceCents = next.virtualCents;
      this.peakBalanceCents = next.peakCents;
      this.paperStats = { pnlCents: next.pnlCents, wins: next.wins, losses: next.losses };
      // bot_trades rebuild does NOT subtract a reserve lock from virtualCents,
      // so the pool must be 0 here or cash + reserve would double-count it.
      this.reservePoolCents = 0;
      this.persistPaperLedger();
      this.log("info", `📄 Paper sim: ledger follows bot_trades $${(next.virtualCents / 100).toFixed(2)} (display ${next.pnlCents}¢; halt stays bot-only todayStats)`);
    } catch {
      // Non-fatal: keep file/in-memory ledger.
    }
  }

  applyBacktestConfig(params: {
    minVelocity?: number; minProbEdge?: number; useProbEdge?: boolean;
    useStallFilter?: boolean; useAcceleration?: boolean;
    useLossCooldown?: boolean; cooldownMultiplier?: number;
    drawdownGuardPct?: number;
  }) {
    this.config = { ...this.config, ...params, useLossCooldown: false };
    this.log("info",
      `🧪 Backtest config applied: vel≥$${this.config.minVelocity}/min edge≥${this.config.minProbEdge}% ` +
      `stall=${this.config.useStallFilter} guard=${this.config.drawdownGuardPct}%`
    );
  }

  subscribe(fn: (e: BotLogEvent) => void) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private recordModeState(modeState: ModeState): void {
    this.lastModeState = modeState;
    const previous = this.modeHistory[0];
    const key = (state: ModeState) => [
      state.riskProfile,
      state.path,
      state.regime,
      state.autoSwitched,
      state.reason,
    ].join("|");

    if (previous && key(previous) === key(modeState)) return;
    this.modeHistory = [modeState, ...this.modeHistory].slice(0, 5);
  }

  getStatus(): BotStatus {
    // Display honesty (no bounce): if paperStats W/L were inflated by CLOSE spam,
    // rebuild wins/losses/pnl from unique fill→best-close pairs. Session virtual
    // cash stays on paperVirtualBalanceCents — never mix Kalshi cash in.
    if (this.config.paperMode === true && Date.now() - this.paperStatsHealedAt > 10_000) {
      this.paperStatsHealedAt = Date.now();
      try {
        const healed = paperLedgerFromSessionTape({
          startCents: this.config.paperStartingBalanceCents,
          sessionStartTs: this.paperSessionStartTs > 0 ? this.paperSessionStartTs : 0,
          rows: loadPaperTrades(),
          peakCents: this.peakBalanceCents,
          reservePct: this.config.reservePct,
        });
        const hw = healed.wins ?? 0;
        const hl = healed.losses ?? 0;
        const hp = Math.round(healed.pnlCents ?? 0);
        if (hw !== this.paperStats.wins || hl !== this.paperStats.losses || hp !== this.paperStats.pnlCents) {
          this.paperStats = { pnlCents: hp, wins: hw, losses: hl };
          // Persist healed W/L/pnl; keep live virtual/peak (session cash book).
          this.persistPaperLedger();
        }
      } catch { /* display heal must never break status */ }
    }
    const paperTotal = this.paperStats.wins + this.paperStats.losses;
    // Paper desk P&L is the paper ledger / bot_trades paper rows (paperStats).
    // paperStats still drive this display P&L (session book). The daily-loss
    // halt uses ET-day bot todayStats in both modes (Stellar 2026-09-26);
    // see status.dailyLossHalt.
    // Never map Kalshi cash onto these.
    const displayTodayPnl = this.config.paperMode ? this.paperStats.pnlCents : this.todayStats.pnlCents;
    const displayTodayWins = this.config.paperMode ? this.paperStats.wins : this.todayStats.wins;
    const displayTodayLosses = this.config.paperMode ? this.paperStats.losses : this.todayStats.losses;
    const totalToday = displayTodayWins + displayTodayLosses;
    const s   = this.lastStrategyResult;
    const bal = this.config.paperMode ? this.paperVirtualBalanceCents : (this.accountBalance ?? 0);
    const ddPct = this.peakBalanceCents > 0 ? Math.max(0, (this.peakBalanceCents - bal) / this.peakBalanceCents * 100) : 0;
    const cp  = this.prices.length > 0 ? this.prices[this.prices.length - 1].price : 0;
    const latestKalshiTick = kalshiWS.getLatest();
    // Never latch STALLED in UI/SSE after the live book already has a 1–99¢ ask.
    if (hasExecutableKalshiAsk(latestKalshiTick)) {
      this.consecutiveInvalidKalshiPriceTicks = 0;
    }
    // Prefer the current feed tick, but retain the last evaluated observation
    // during a brief feed transition so status/ARIA do not lose a known floor.
    const fs  = latestKalshiTick?.floorStrike ?? this.lastObservation?.floorStrike ?? 0;
    const secondsRemaining = latestKalshiTick?.closeTime
      ? Math.max(0, (new Date(latestKalshiTick.closeTime).getTime() - Date.now()) / 1_000)
      : 0;
    // BASIS LEAD (not settlement pin): estimatedFairBRTI = Coinbase±basis proxy
    // feeding the lag meter / desk proj. CF Benchmarks BRTI (getFreshBrtiUsd) is
    // the G/A_hat/W2/theo identity. DEFERRED: do not swap this lag proj onto
    // BRTI mid-session — would change money-path lag/hold semantics.
    const liveLagProj = (this.lastBasisState?.estimatedFairBRTI != null && Number.isFinite(this.lastBasisState.estimatedFairBRTI) && secondsRemaining > 0)
      ? projectSettlementPrice(this.lastBasisState.estimatedFairBRTI, this.currentVelocity, secondsRemaining)
      : null;
    const canonDesk = canonicalLagProjectedSettlement({
      liveProj: liveLagProj,
      snapshotProj: this.lastBasisState?.projectedSettlementPrice,
      floor: fs,
    });
    const modelSettle = settlementPredictor.getCurrent()?.predictedSettle ?? null;
    const deskProj = labeledCanonicalAndModel(canonDesk, modelSettle);
    const fairSpot = latestKalshiTick && (latestKalshiTick.yesBid > 0 || latestKalshiTick.yesAsk > 0)
      ? inferBtcPrice(latestKalshiTick)
      : 0;
    const fairValueCents = binaryCallFairValueCents(fairSpot, fs, secondsRemaining);
    const noFairValueCents = complementaryFairValueCents(fairValueCents);
    const yesMarketPrice = latestKalshiTick?.yesPrice ?? 0;
    const noMarketPrice = latestKalshiTick?.noPrice ?? 0;
    const positionState = ((): BotStatus["positionState"] => {
      if (!this.openTrade) return { source: "none", lastConfirmedAt: null, staleSecs: null };
      if (this.openTrade.paper) return { source: "paper", lastConfirmedAt: null, staleSecs: null };
      if (this.positionLastConfirmedAt == null) return { source: "kalshi-unconfirmed", lastConfirmedAt: null, staleSecs: null };
      return {
        source: "kalshi-confirmed",
        lastConfirmedAt: this.positionLastConfirmedAt,
        staleSecs: Math.round((Date.now() - this.positionLastConfirmedAt) / 1000),
      };
    })();

    const htfOnce = computeLiveHtfStructure(cp);
    const tapeOnce = (this.lastTapeOrgan && (Date.now() - this.lastObsTs) < 5_000)
      ? this.lastTapeOrgan
      : snapshotTape({
          quotes: {
            yesAsk: latestKalshiTick?.yesAsk,
            noAsk: latestKalshiTick?.noAsk,
            yesBid: latestKalshiTick?.yesBid,
            noBid: latestKalshiTick?.noBid,
          },
          floor: fs,
          velocity: this.currentVelocity,
          ohlc1m: getMtfOhlcBars(1)?.bars ?? null,
          ohlc5m: getMtfOhlcBars(5)?.bars ?? null,
          mtf: mtfAnalyzer.getSummary()?.score ?? null,
          lag: this.lastBasisState,
          htf: htfOnce,
          streakSaturation: this.lastObservation?.streakSaturation ?? null,
          settlementStreak: this.lastObservation?.settlementStreak ?? null,
          quoteAgeMs: typeof latestKalshiTick?.quoteTs === "number" && latestKalshiTick.quoteTs > 0
            ? Date.now() - latestKalshiTick.quoteTs
            : null,
          quoteSource: (latestKalshiTick as { source?: "ws" | "rest" } | null)?.source ?? "ws",
          quoteAsOfMs: typeof latestKalshiTick?.quoteTs === "number" && latestKalshiTick.quoteTs > 0
            ? latestKalshiTick.quoteTs
            : null,
        });
    const lagMeterStatus = getLagMeterStatus(basisTracker.getLagMeter());
    return {
      tickPerf:           { lastTickMs: this.lastTickMs, slowTicks: this.slowTickCount },
      hourlyTick:         this.config.enable1HContracts ? hourlyPoller.getFreshLatest() : null,
      hourlySkipReason:   this.config.enable1HContracts ? this.lastHourlySkipReason : null,
      state:              this.state,
      authFailed:         this.authFailed,
      authFailedReason:   this.authFailedReason,
      lastOrderRejection: this.lastOrderRejection,
      wsDegraded:         this.wsDegraded,
      config:             this.config,
      lockedStrategyDisabled: isStrategyOverrideDisabled(this.config.strategyOverride, this.config),
      todayPnlCents:      displayTodayPnl,
      todayWins:          displayTodayWins,
      todayLosses:        displayTodayLosses,
      openTrade:          this.openTrade,
      positionState,
      accountPositionState: this.accountPositionAudit,
      lastSignal:         this.lastSignalDesc,
      entryFunnel:        this.entryFunnel.snapshot(),
      // R3 — build identity on status (was only on /bot/frozen-cc + boot log).
      gitSha:             runningGitSha(),
      paperRecoveryInspection: this.lastPaperRecoveryInspection,
      autopilot:          this.config.autopilotMode === true,
      decisionKind:       this.config.autopilotMode === true
        ? (this.lastAutopilotDecision?.decisionKind ?? null)
        : null,
      lastAutopilotDecision: this.config.autopilotMode === true
        ? this.lastAutopilotDecision
        : null,
      priceBuffer:        this.prices.length,
      currentVelocity:    this.currentVelocity,
      threeMinVelocity:   this.threeMinVelocity,
      velocityHistory:    this.velocityHistory,
      velocityAverages:   this.getVelocityAverages(),
      secsRemaining:      getSecsRemaining(),
      consecutiveLosses:  this.consecutiveLosses,
      currentStreak:      this.currentStreak,
      strategyConsensus:  this.lastStrategyConsensus,
      winRateToday:       totalToday > 0 ? displayTodayWins / totalToday : 0,
      lastEdge:           this.lastEdge,
      lastModelProb:      fillPathPWin(this.openTrade?.strategyWinRateAtEntry)
        ?? fillPathPWin(this.lastOrganReport?.p)
        ?? fillPathPWin(this.lastModelProb)
        ?? this.lastModelProb,
      // Ticket p is winRateAtPrice at the traded ask. Binary P(YES) from
      // probabilityEdge is not p — never show it as p, never 1-p swap.
      liveModelProb:      this.openTrade
        ? (fillPathPWin(this.liveModelProb)
          ?? fillPathPWin(this.openTrade.strategyWinRateAtEntry)
          ?? this.lastModelProb)
        : (fillPathPWin(this.lastOrganReport?.p) ?? fillPathPWin(this.lastModelProb) ?? this.lastModelProb),
      isStalling:         this.lastStalling,
      accountBalance:     this.accountBalance,
      accountBalanceUpdatedAt: this.balanceUpdatedAt,
      accountBalanceStale: this.isBalanceStale(),
      lastBalanceError:   this.lastBalanceError,
      kalshiTick:         latestKalshiTick,
      activeStrategy:     s?.strategyName ?? null,
      activeStrategyId:   s?.strategyId ?? null,
      activeStrategyReason: s?.reason ?? null,
      activeStrategyConf:   s?.confidence ?? null,
      detectedRegime:     this.lastDetectedRegime,
      quarantinedStrategies: getDbDisabledStrategies(),
      paperVirtualBalanceCents: this.paperVirtualBalanceCents,
      kalshiCashCents:    this.accountBalance,
      overallPnlCents:    this.config.paperMode ? this.paperStats.pnlCents : this.overallStats.pnlCents,
      paperPnlCents:      this.paperStats.pnlCents,
      paperWins:          this.paperStats.wins,
      paperLosses:        this.paperStats.losses,
      paperTrades:        paperTotal,
      paperWinRate:       paperTotal > 0 ? this.paperStats.wins / paperTotal : 0,
      // v5 — tape organ once (htfOnce / tapeOnce above); lagMeter = getLagMeterStatus
      mtfBias:            mtfAnalyzer.getSummary(),
      htfStructure:       htfOnce,
      tapeLabels:         tapeOnce.stamp,
      regimePack:         this.lastAdaptiveRegime
        ? {
            packId: this.lastAdaptiveRegime.packId,
            eligibleIds: this.lastAdaptiveRegime.pack.eligibleIds,
            sizeCap: this.lastAdaptiveRegime.pack.sizeCap,
            forbidden: this.lastAdaptiveRegime.pack.forbidden,
            skipReason: this.lastAdaptiveRegime.skipReason,
          }
        : null,
      regimeRt:           this.lastAdaptiveRegime?.rt ?? null,
      streakSat:          this.lastStreakSatDecision ?? this.evaluateLiveStreakSat(this.openTrade?.side ?? null),
      adviceShadow:       this.lastAdviceShadow,
      adviceShadowLine:   formatAdviceDeskLine(this.lastObservation, this.lastAdviceShadow),
      openTradePnlCents:  this.openTradePnlCents,
      openTradePnlTotal:  this.openTrade ? this.openTradePnlCents * this.openTrade.contracts : 0,
      openTradeMaxGain:   this.openTradeMaxGain,
      drawdownFromPeakPct: ddPct,
      peakBalanceCents:   this.peakBalanceCents,
      reservePoolCents:   this.reservePoolCents,
      dailyLossHalt:      this.getDailyLossHaltStatus(),
      lastObservation:    this.lastObservation,
      lastPreTradeVerdict: this.lastPreTradeVerdict,
      lastMoneyGateCard:  this.lastMoneyGateCard,
      heldPendingFromRestart: this.heldPendingFromRestart,
      currentBtcPrice:  cp,
      distFromFloorPct: cp > 0 && fs > 0 ? ((cp - fs) / fs) * 100 : 0,
      aboveFloor:       cp > 0 && fs > 0 && cp >= fs,
      autoSettings:        this.lastAutoSettings,
      adaptiveCondition:   this.lastAdaptiveCondition,
      sessionMode:         this.lastSessionMode,
      marketState:         this.lastMarketState
        ? { velScale: this.lastMarketState.velScale, zVel: this.lastMarketState.zVel,
            rangeScale: this.lastMarketState.rangeScale, volScale: this.lastMarketState.volScale,
            tau: this.lastMarketState.tau, stale: this.lastMarketState.stale }
        : null,
      timeOfDayRegime:     getTimeOfDayRegime(),
      // Refresh ages via getState(): lastBasisState is a tick snapshot and would
      // keep lagStale=false / lagProven=true after Coinbase ages if ticks pause.
      // desk/now reads this — never invent live lag flags from a frozen snapshot.
      basisState:          this.lastBasisState ? basisTracker.getState() : null,
      effectiveWindow:     this.computeEffectiveWindow(),
      agentFilterOverrides: this.getEffectiveAgentFilterOverrideStatus(),
      agentExitPolicy:      this.lastAgentExitPolicy,
      agentSizeMultiplier:  this.lastAgentSizeMultiplier,
      agentSetupControls:   this.lastAgentSetupControls,
      equityCurveResetAt:  this.config.equityCurveResetAt,
      paperSessionStartTs: this.paperSessionStartTs,
      agentAssessment:  expertAgent.lastAssessment,
      ariaGuardianDecision: this.lastAriaGuardianDecision,
      lastExitDriver:   this.lastExitDriver,
      lastExitPriceBreakdown: this.lastExitPriceBreakdown,
      livePriceBreakdown: this.livePriceBreakdown,
      settlementHoldActive: this.settlementHoldActive,
      modeState:            this.lastModeState,
      modeHistory:          [...this.modeHistory],
      strategyRegimeBlocks: {
        count:       this.strategyRegimeBlocks.count,
        lastBlockAt: this.strategyRegimeBlocks.lastBlockAt,
        byRegime:    { ...this.strategyRegimeBlocks.byRegime },
        byStrategy:  { ...this.strategyRegimeBlocks.byStrategy },
      },
      dailyTarget:          this.lastDailyTarget,
      volBufferStaleSecs: this.prices.length > 0
        ? Math.max(0, (Date.now() - this.prices[this.prices.length - 1].ts) / 1000)
        : 0,
      consecutiveInvalidKalshiPriceTicks: this.consecutiveInvalidKalshiPriceTicks,
      sessionFillStats: this.getSessionFillStatsSummary(),
      otmStats: {
        wins:           this.otmStats.wins,
        losses:         this.otmStats.losses,
        pnlCents:       this.otmStats.pnlCents,
        totalPaidCents: this.otmStats.totalPaidCents,
        avgWinMultiple: this.otmStats.avgWinMultiple,
      },
      otmConfluenceSkips: {
        count:      this.otmConfluenceSkips.count,
        lastSkipAt: this.otmConfluenceSkips.lastSkipAt,
        byStrategy: { ...this.otmConfluenceSkips.byStrategy },
      },
      floorStrike: fs,
      contractFairValueYes: fairValueCents,
      fairValueCents,
      noFairValueCents,
      yesEdgeCents: fairValueEdgeCents(fairValueCents, yesMarketPrice),
      noEdgeCents: fairValueEdgeCents(noFairValueCents, noMarketPrice),
      minimumFairValueEdgeCents: this.config.minProbEdge,
      lastSettlementPrediction: (() => {
        const call = settlementPredictor.getCurrent();
        return call
          ? { arrow: call.arrow, confidence: call.confidence, predictedDirection: call.predictedDirection, predictedSettle: call.predictedSettle }
          : null;
      })(),
      canonicalLagProj: canonDesk.proj ?? null,
      projSplitBrain: canonDesk.splitBrain,
      projLine: deskProj.line,
      lagMeter: lagMeterStatus,
      // Brain stamps (observability) — AdmissionMsg / freshness / exit monitor.
      organAdmission: demoteTakeIfStale(this.lastOrganReport?.admission ?? null, tapeOnce.freshness ?? null),
      feedFreshness: tapeOnce.freshness ?? null,
      exitMonitor: this.openTrade ? (this.lastExitMonitorStamp ?? null) : null,
      structuralRuinShadow: this.openTrade
        ? (this.lastStructuralRuinShadow ?? null)
        : null,
      sensorBundle: stampSensorMsg({
        freshness: tapeOnce.freshness ?? null,
        regime: this.lastAdaptiveRegime?.rt
          ? {
              vol: this.lastAdaptiveRegime.rt.vol,
              shape: this.lastAdaptiveRegime.rt.shape,
              confidence: this.lastAdaptiveRegime.rt.confidence,
            }
          : null,
        lag: {
          lagSeconds: lagMeterStatus.lagSeconds ?? null,
          lagProven: lagMeterStatus.proven === true,
          lagStale: lagMeterStatus.stale === true,
          indexProxyFresh: this.indexProxyFresh(),
        },
        // Doctrine tag always present — never a fill gate / TAKE veto.
        gold: { cellId: null, nSample: null },
      }),
      brainCenter: (this.lastBrainCenter = interpretBrainCenter({
        ticker: kalshiWS.getLatest()?.ticker ?? null,
        orderbook: kalshiWS.getLatestOrderbook(),
        orderbookConsistency: brainOrderbookConsistency(),
        balanceCents: this.config.paperMode ? this.paperVirtualBalanceCents : (this.accountBalance ?? null),
        frozenCcMode: this.config.frozenCcMode === true,
        paperMode: this.config.paperMode === true,
        secsRemaining: (() => { try { return getSecsRemaining(); } catch { return null; } })(),
        lastTickMs: this.lastBrainTickMs,
        // size0 via admission SIZE_ZERO code; do not confuse open contracts with proposed size
        proposedSize: null,
        admission: demoteTakeIfStale(this.lastOrganReport?.admission ?? null, tapeOnce.freshness ?? null),
        feedFreshness: tapeOnce.freshness ?? null,
        sensorBundle: stampSensorMsg({
          freshness: tapeOnce.freshness ?? null,
          regime: this.lastAdaptiveRegime?.rt
            ? {
                vol: this.lastAdaptiveRegime.rt.vol,
                shape: this.lastAdaptiveRegime.rt.shape,
                confidence: this.lastAdaptiveRegime.rt.confidence,
              }
            : null,
          lag: {
            lagSeconds: lagMeterStatus.lagSeconds ?? null,
            lagProven: lagMeterStatus.proven === true,
            lagStale: lagMeterStatus.stale === true,
            indexProxyFresh: this.indexProxyFresh(),
          },
          gold: { cellId: null, nSample: null },
        }),
        exitMonitor: this.openTrade ? (this.lastExitMonitorStamp ?? null) : null,
        settleStamp: this.lastSettleStamp,
        structuralRuinShadow: this.openTrade
          ? (this.lastStructuralRuinShadow ?? null)
          : null,
        frozenShadow: (this.openTrade?.frozenShadow ?? this.pendingFrozenFill?.shadow ?? this.freshFrozenTickShadow())
          ? {
              ccVelocityWouldBlock:
                (this.openTrade?.frozenShadow ?? this.pendingFrozenFill?.shadow ?? this.freshFrozenTickShadow())?.ccVelocityWouldBlock ?? null,
              regimeWouldBlock:
                (this.openTrade?.frozenShadow ?? this.pendingFrozenFill?.shadow ?? this.freshFrozenTickShadow())?.regimeWouldBlock ?? null,
              mtfScore:
                (this.openTrade?.frozenShadow ?? this.pendingFrozenFill?.shadow ?? this.freshFrozenTickShadow())?.mtfScore ?? null,
              velocityDolPerMin:
                (this.openTrade?.frozenShadow ?? this.pendingFrozenFill?.shadow ?? this.freshFrozenTickShadow())?.velocityDolPerMin ?? null,
              w2Reason:
                (this.openTrade?.frozenShadow ?? this.pendingFrozenFill?.shadow ?? this.freshFrozenTickShadow())?.w2Reason ?? null,
              constructedNo:
                (this.openTrade?.frozenShadow ?? this.pendingFrozenFill?.shadow ?? this.freshFrozenTickShadow())?.constructedNo ?? null,
              lagProven:
                (this.openTrade?.frozenShadow ?? this.pendingFrozenFill?.shadow ?? this.freshFrozenTickShadow())?.lagProven ?? null,
              lagStale:
                (this.openTrade?.frozenShadow ?? this.pendingFrozenFill?.shadow ?? this.freshFrozenTickShadow())?.lagStale ?? null,
            }
          : null,
        strategicContext: {
          session: this.lastMarketState?.session != null ? String(this.lastMarketState.session) : null,
          regimeLabel: this.lastAdaptiveCondition?.condition
            ?? (this.lastAdaptiveRegime?.rt?.shape != null
              ? String(this.lastAdaptiveRegime.rt.shape)
              : null),
          drawdownPct: this.peakBalanceCents > 0
            ? Math.max(0, (1 - this.paperVirtualBalanceCents / this.peakBalanceCents) * 100)
            : null,
          promoteReady: false,
        },
      })),
      settleStamp: this.lastSettleStamp,
      directorGovernance: this.lastDirectorGovernance,
      brainMind: (() => {
        this.lastBrainTickMs = Date.now();
        const report = this.lastBrainCenter;
        const freshness = tapeOnce.freshness ?? null;
        const feedStale = freshness?.stale === true;
        if (feedStale) {
          if (this.feedStaleSinceMs == null) this.feedStaleSinceMs = Date.now();
        } else {
          this.feedStaleSinceMs = null;
        }
        const ddPct = this.peakBalanceCents > 0
          ? Math.max(0, (1 - this.paperVirtualBalanceCents / this.peakBalanceCents) * 100)
          : 0;
        const episodes = getBrainEpisodeRing();
        const scars = getScarRing();
        const scarSnap = scarEchoLearningSnapshot(scars);
        const learning = buildLearningSnapshot(episodes, {
          scarEcho: {
            scarCount: scarSnap.scarCount,
            closedCount: scarSnap.closedCount,
            starved: scarSnap.starved,
            weightDeltas: scarSnap.weightDeltas,
          },
        });
        // Self-heal throttle (allowlisted only)
        let selfHealPulse: {
          findings: unknown[];
          goldenEgg: unknown;
          lastSelfHeal: LastSelfHealStamp | null;
          asOfMs: number;
        } | null = null;
        try {
          const now = Date.now();
          const diag = diagnoseMind({
            paperMode: this.config.paperMode === true,
            autopilotMode: this.config.autopilotMode === true,
            enabled: this.config.enabled === true,
            requireAgentEntryApproval: this.config.requireAgentEntryApproval === true,
            brainCenterAuthority: this.config.brainCenterAuthority === true,
            haltEntries: this.agentDirectives.haltEntries === true,
            haltArmedAtMs: this.haltArmedAtMs,
            feedStale,
            feedStaleForMs: this.feedStaleSinceMs != null ? now - this.feedStaleSinceMs : null,
            drawdownPct: ddPct,
            drawdownGuardPct: this.config.drawdownGuardPct ?? 20,
            useDrawdownGuard: this.config.useDrawdownGuard === true,
            lagProven: lagMeterStatus.proven === true,
            lagStale: lagMeterStatus.stale === true,
            thesisBroken: this.openTrade?.exitThesisStatus === "BROKEN",
            coherenceScore: report?.rhythm?.coherenceScore ?? null,
            episodes,
            scars,
            brainReport: report,
            nowMs: now,
          });
          if (now - this.lastSelfHealAtMs >= SELF_HEAL_THROTTLE_MS) {
            this.lastSelfHealAtMs = now;
            const target = pickHealTarget(diag.findings);
            if (target) {
              const result = applyMindHeal(target, {
                paperMode: this.config.paperMode === true,
                autopilotMode: this.config.autopilotMode === true,
                requireAgentEntryApproval: this.config.requireAgentEntryApproval === true,
                clearHaltDirectives: () => { this.clearAgentHaltDirectives("self-heal"); },
                rearmAutopilot: () => {
                  const r = this.enablePaperAutopilot();
                  return r.ok ? { ok: true } : { ok: false, reason: r.reason };
                },
                clearRequireApprove: () => {
                  this.config.requireAgentEntryApproval = false;
                },
                refreshBrainStamp: () => {
                  this.lastBrainTickMs = null;
                },
                log: (msg) => this.log("info", msg),
              });
              this.lastSelfHeal = {
                atMs: now,
                action: result.action,
                code: target.code,
                ok: result.ok,
                detail: result.detail,
              };
            }
          }
          selfHealPulse = {
            findings: diag.findings,
            goldenEgg: diag.goldenEgg,
            lastSelfHeal: this.lastSelfHeal,
            asOfMs: diag.asOfMs,
          };
        } catch { /* never break getStatus */ }
        const echoes = matchEchoes({
          conflicts: report?.conflicts?.map((c) => c.code) ?? [],
          side: (report?.decisionKind === "TAKE_NO" ? "no" : "yes"),
          horizonPhase: report?.horizon?.phase ?? null,
        }, scars);
        return brainMindPulse(report, {
          learning,
          selfHeal: selfHealPulse,
          echoes,
        });
      })(),
    };
  }

  // offset enables real pagination through the FULL permanent history (every
  // trade ever recorded in bot_trades — nothing is auto-deleted, see
  // getTradeCount() below) instead of the UI being stuck looking at only the
  // newest `limit` rows with no way to reach older ones.
  // Previously swallowed any DB error into `[]` / `0` here, so a real outage
  // was indistinguishable from "no trades exist yet" to every caller (the
  // /bot/trades route, chat.ts, agent.ts, expert-agent.ts) — a 200 response
  // with an empty list rather than a 500. Now these let the error propagate;
  // each caller is responsible for surfacing it as a failure, not a fact.
  async getRecentTrades(limit = 50, offset = 0) {
    return db.select().from(botTrades).orderBy(desc(botTrades.createdAt)).limit(limit).offset(offset);
  }

  /** Total row count in bot_trades — lets the UI show "X of Y" and know when it has reached the end. */
  async getTradeCount(): Promise<number> {
    const rows = await db.select({ count: sql<number>`count(*)` }).from(botTrades);
    return Number(rows[0]?.count ?? 0);
  }

  // ── 1-Hour contract evaluation (KXBTCD threshold markets) ────────────────────
  // Runs every 30 s while enable1HContracts is true.
  // Evaluates the FULL strategy library on a 60-minute observation. Strategies
  // with explicit duration gates self-select (OTM_BREAKOUT_EXPANSION is 60-only;
  // OTM_ASYMMETRY / DEEP_OTM_SNIPER are 15-only); the rest apply their normal
  // minutes-left windows, which carry over to the hourly clock directly.

  /** Why the last hourly evaluation skipped (null = evaluated or disabled). */
  private lastHourlySkipReason: string | null = null;
  /** Master bot upgrade step 3 — HUNT/HARVEST as of the most recent tick (either path); exposed for BotStatus/logging. */
  private lastSessionMode: SessionMode = 'HUNT';
  /** Only used to avoid spamming an info log every tick — logs once per mode transition, not every tick. */
  private lastLoggedSessionMode: SessionMode | null = null;

  private lastTickMs = 0;      // duration of the most recent tick (perf visibility)
  private slowTickCount = 0;   // session count of ticks that exceeded 1.5s

  private hourlyEvalRunning = false;  // mutex — a slow placeOrder must never overlap the next 30s evaluation (duplicate-order risk)

  private async evaluateHourlyTick() {
    // Paper/frozen release: hourly desk is off. Keep body for leftover funnel only.
    if (this.config.frozenCcMode === true) return;
    if (!leftoverHourlyEvaluateMayRun(this.config)) return;
    // 15m-purity fail-closed: when hourly is disabled this method is a complete
    // no-op — it must never reach placeOrder (or even build an observation).
    // Named flag gate first so this path cannot bypass hourlyOrPerpEvaluateAllowed.
    if (!hourlyOrPerpEvaluateAllowed({
      series: "1H",
      enable1HContracts: this.config.enable1HContracts,
      enable1HLive: this.config.enable1HLive,
    }).ok) return;
    if (!this.config.enable1HContracts) return;
    if (this.hourlyEvalRunning) return;
    this.hourlyEvalRunning = true;
    try {
      await this._evaluateHourlyTickBody();
    } catch (err) {
      this.log("error", `[hourly-tick] uncaught error: ${(err as Error).message}`);
    } finally {
      this.hourlyEvalRunning = false;
    }
  }

  /**
   * A strategy override narrows selection to one strategy, while
   * disabledStrategies removes strategies from that same pool. If both config
   * fields contain the override, selection is intentionally empty but the
   * conflict used to be invisible. Emit this on every selection pass so a
   * programmatic config update cannot leave the operator with a silent no-trade.
   */
  private warnIfDisabledStrategyOverride(path: "15m" | "1h" | "add"): void {
    const warning = disabledStrategyOverrideWarning(
      this.config.strategyOverride,
      this.config.disabledStrategies,
    );
    if (warning) this.log("warn", `[${path}] ${warning}`);
  }

  // ── Shared pre-trade admission gates ────────────────────────────────────────
  // Single admission pipeline used by BOTH the 15-minute and hourly entry paths
  // so no horizon can bypass the core safety gates: regime-conditional EV,
  // protect-mode A+ bar, hard entry filters, fee-aware EV floor, and the
  // fail-closed pre-trade Monte-Carlo simulation. Returns the verdict and a
  // risk-profile ModeState for profile-aware sizing in placeOrder.
  // Exposed as `runSharedAdmissionGates` (private semantics) — tests may drive
  // it directly to prove each gate blocks an order.
  //
  // Profit Doctrine Phase 4 (2026-08-25) — 15m-path duplication audit: only
  // the HOURLY path calls this function directly. The 15-MINUTE path (see
  // evaluateEntry()'s inline gates, search "ARIA DANGER hard veto —
  // unconditional", "Hard entry filters (Grok)", "EV floor gate", "Protect
  // mode", and "Pre-trade simulation" within the same file) does NOT call
  // this function — it re-implements the identical 5 checks inline using
  // the SAME underlying functions/thresholds (isAriaDangerVeto,
  // scoreStrategyEV<0, protectActive&&conf<75, passesHardFilters,
  // estimateTradeEV<0.03, runPreTradeSim), interleaved with 15m-only gates
  // (SPREAD_GATE, entry price bands, EV_PRE_CHECK, OVERPAY_GATE, MTF_FILTER,
  // pack-aware CONFIDENCE_FLOOR, STRATEGY_REGIME_BLOCK, SETTLEMENT_VETO,
  // PATH_GATE) that this shared function does not know about.
  //
  // A literal single-call-site merge was evaluated and INTENTIONALLY
  // DEFERRED (not implemented): the 15m path's ordering is load-bearing —
  // cheap gates (spread/price-band) must reject before the expensive
  // pretrade-sim/ARIA-assessment calls run, and several of these checks
  // depend on values (entryPrice after sweep, conf after pack-aware bonuses)
  // that are only finalized partway through the 15m sequence, not available
  // at a single insertion point. Forcibly restructuring 20+ interleaved,
  // order-dependent gates in the single most safety-critical live-order path
  // — for a purely structural (DRY) benefit, since a full read confirmed
  // NO threshold or logic drift currently exists between the two paths — was
  // judged higher-risk than the problem it would solve. If you change a
  // threshold or add a check in ONE of the 5 shared checks above, you MUST
  // make the identical change in the 15m path's inline equivalent (and vice
  // versa) or this will silently drift, exactly the failure mode Phase 4
  // exists to prevent.
  async runSharedAdmissionGates(args: {
    obs: import("./strategy-library.js").StrategyObservation;
    stratResult: LibStrategyResult;
    signal: "LONG" | "SHORT";
    entryPrice: number;      // cents
    conf: number;            // integer 0–100
    secs: number;
    grokRegime: GrokRegime;
    regime: string;          // buffer regime label
    // Task #397: calibrated win-rate estimate (winRateAtPrice()/expectedWinRate)
    // for this exact strategy/price/time combo — the same number placeOrder's
    // EV_FLOOR gate and Kelly sizing use downstream. Required so the EV floor
    // check below no longer derives a win-rate proxy from raw signal confidence.
    strategyWinRate: number;
    // CONSENSUS MEASUREMENT PURITY (2026-08-16): the caller's own effective-
    // disabled strategy set (same expression already passed to its own
    // evaluateAllStrategies() selection call) — threaded into the pre-trade
    // sim's consensus check so disabled strategies contribute no vote there.
    disabledIds?: string[] | Set<string>;
  }): Promise<{ ok: false; reason: string } | { ok: true; verdict: PreTradeVerdict; modeState: ModeState }> {
    const { obs, stratResult, signal, entryPrice, conf, secs, grokRegime, regime, strategyWinRate, disabledIds } = args;

    // 0. ARIA DANGER hard veto — this is the hourly path's only route to
    // placeOrder(), so it must consult the same unconditional DANGER gate as
    // the 15-min path's own inline check. Previously this admission pipeline
    // never called getFreshAssessment()/isAriaDangerVeto() at all, so a fresh
    // DANGER read had no effect on hourly trades — a real live-money gap.
    const hourlyDangerAssmt = expertAgent.getFreshAssessment();
    if (isAriaDangerVeto(hourlyDangerAssmt)) {
      return {
        ok: false,
        reason: `ARIA DANGER — hard veto${hourlyDangerAssmt?.reasoning ? `: ${hourlyDangerAssmt.reasoning}` : ''}`,
      };
    }

    // 1. Regime-conditional EV filter — same as the 15-min path's scoreStrategyEV gate.
    if (scoreStrategyEV(stratResult, obs, entryPrice, strategyWinRate) <= 0) {
      return { ok: false, reason: `regime-EV filter: ${stratResult.strategyId} negative EV in ${regime}` };
    }

    // 2. Protect mode ('reduced' behavior after daily target hit): A+ setups only.
    if (this.lastDailyTarget?.protectActive && conf < 75) {
      return { ok: false, reason: `protect mode — conf ${Math.round(conf)}% below A+ bar (75%)` };
    }

    // 3. Hard entry filters (time-to-expiry × distance, strategy/regime combos).
    if (!passesHardFilters(secs, obs, stratResult, obs.channelInfo ?? null, grokRegime)) {
      return { ok: false, reason: `blocked by hard entry filter [${grokRegime}]` };
    }

    // 4. Fee-and-slippage-aware EV floor (≥ 0.03 — was 0.05, temporary relaxation 2026-08-03).
    // Task #397: uses the caller's calibrated winRateAtPrice/expectedWinRate
    // estimate (same number placeOrder's EV_FLOOR gate and Kelly sizing use
    // for this trade), not raw signal confidence.
    const tradeEV = estimateTradeEV(strategyWinRate, entryPrice, stratResult.strategyId);
    if (tradeEV < 0.03) {
      return { ok: false, reason: `EV ${tradeEV.toFixed(2)} < 0.03 floor` };
    }
    const pathConfig = getPathConfig(entryPrice);
    const pathEV = computeTradeEV({
      entryPriceCents: entryPrice,
      winRate: strategyWinRate,
      minEVCents: pathConfig.minEVCents,
    });
    if (!pathEV.passes) {
      return {
        ok: false,
        reason: `EV ${pathEV.netEV.toFixed(1)}¢ < ${pathConfig.minEVCents}¢ ${pathConfig.path} floor`,
      };
    }

    // 5. Pre-trade Monte-Carlo simulation — FAIL CLOSED on error, no overrides.
    // Task #143: tell the sim when the price buffer is stale (>30s since last
    // tick) so its Monte Carlo path doesn't silently derive a misleading vol
    // estimate from those stale ticks with no indication in the verdict.
    const entryBufferStale = this.prices.length === 0
      || (Date.now() - this.prices[this.prices.length - 1].ts) > 30_000;
    if (entryBufferStale) {
      this.sharedGateStaleStreak++;
    } else {
      this.sharedGateStaleStreak = 0;
    }
    // Task #143: one stale cycle still gets the sim's conservative-vol
    // fallback below, but a SECOND consecutive stale cycle means the feed is
    // genuinely down (not a one-tick blip) — hard-block rather than let the
    // sim silently approve a trade off a synthetic vol estimate again.
    if (this.sharedGateStaleStreak > 1) {
      return {
        ok: false,
        reason: `vol buffer stale for ${this.sharedGateStaleStreak} consecutive cycles — blocked (fail-closed, not just fallback-vol)`,
      };
    }
    let verdict: PreTradeVerdict;
    try {
      verdict = await runPreTradeSim({
        obs, direction: signal, priceBuffer: this.prices, secsRemaining: secs,
        entryPriceCents: entryPrice,
        volStale: entryBufferStale, disabledIds,
      });
    } catch (simErr) {
      return { ok: false, reason: `pre-trade sim error — blocked (fail-closed): ${(simErr as Error).message}` };
    }
    this.lastPreTradeVerdict = verdict;
    if (!verdict.approved) {
      return { ok: false, reason: `pre-trade sim rejected: score ${verdict.overallScore}/${verdict.scoreThreshold} — ${verdict.rejectionReason ?? 'below threshold'}` };
    }

    // 6. Risk-profile mode state for profile-aware sizing in placeOrder.
    const modeState = buildModeState({
      entryPriceCents:   entryPrice,
      regime:            (obs.regime ?? regime ?? 'unclear') as string,
      balanceCents:      this.effectiveBalance(),
      peakBalanceCents:  this.peakBalanceCents,
      todayPnlCents:     this.dayPnlForHalt(),
      consecutiveLosses: this.consecutiveLosses,
      currentStreak:     this.currentStreak,
      manualRiskProfile: this.config.manualRiskProfile ?? null,
    });
    this.recordModeState(modeState);

    return { ok: true, verdict, modeState };
  }

  private async _evaluateHourlyTickBody() {
    // Leftover 1H body lives in leftover-hourly-funnel (mayRun-gated).
    await leftoverHourlyEvaluateRun(this.config, () =>
      leftoverHourlyEvaluateFunnel.call(this),
    );
  }


  private async tick() {
    if (!this.config.enabled) return;
    this.maybeUptimeHeartbeat();
    // Mutex: if the previous tick is still awaiting an async operation (balance
    // refresh, DB write, Kalshi API call), skip this tick entirely rather than
    // overlapping. Overlapping ticks are the primary cause of duplicate orders.
    if (this.tickRunning) return;
    this.tickRunning = true;
    const t0 = Date.now();
    // Record the START of this tick so the event-driven wake scheduler can
    // enforce TICK_MIN_INTERVAL_MS between consecutive tick starts (coalescing).
    this._lastTickStartTs = t0;
    try { await this._tickBody(); } catch (err) {
      // _tickBody() had no catch of its own, so a throw here used to become a
      // silent unhandled rejection (only visible via the generic process-level
      // handler in index.ts) — invisible in the bot's own log feed/UI. Route it
      // through this.log() so operators can actually see tick failures.
      this.log("error", `[tick] uncaught error: ${(err as Error).message}\n${(err as Error).stack ?? ''}`);
    } finally {
      this.tickRunning = false;
      // Per-tick latency visibility: a 500ms-cadence tick that takes >1.5s is
      // dropping cycles (mutex skips them) and making stale decisions. Log it
      // so future lag has a measurable trail instead of being invisible.
      const elapsed = Date.now() - t0;
      this.lastTickMs = elapsed;
      if (elapsed > 1_500) {
        this.slowTickCount++;
        this.log("warn", `[perf] slow tick: ${elapsed}ms (500ms cadence — cycles were skipped)`);
      }
    }
  }

  private async _tickBody() {

    // Hydrate the current ET day's durable execution counters before any live
    // status or order event can be processed. A day rollover loads the new
    // row, while same-day ticks leave the in-memory counters untouched.
    await this.ensureSessionFillStatsLoaded(etDateKey());

    // ── Auth-recovery probe ────────────────────────────────────────────────────
    // When authFailed is true, probe on every tick so the warning banner clears
    // within ~2 s of the user fixing their key, without waiting for a live trade.
    //
    // Two distinct recovery paths based on why the failure was flagged.
    // Both are throttled to at most once per 60 s to avoid log spam when the
    // key is misconfigured — the user will see the banner and fix it in their
    // own time; we don't need to hammer the log every 5 s.
    //   'signing' — PEM parsing / RSA sign threw locally.  A pure in-process
    //               re-sign is enough; no network call needed.
    //   'server'  — Kalshi returned 401/403.  Signing works, but the key/id
    //               pair is wrong.  We must do a real /portfolio/balance probe
    //               to confirm recovery.
    if (this.authFailed && !this.config.paperMode) {
      const now = Date.now();
      if (now - this.lastServerAuthProbeTs >= 60_000) {
        this.lastServerAuthProbeTs = now;
        if (this.authFailedReason === "signing") {
          // Cheap in-process probe — no network call required.
          try {
            const probe = await kalshiAuthHeaders("GET", KALSHI_PATH_PORTFOLIO_BALANCE);
            if (probe["KALSHI-ACCESS-KEY"]) {
              this.authFailed = false;
              this.authFailedReason = null;
              this.log("info", "✅ Auth signing probe passed — auth failure cleared.");
            }
            // If it returned {} the key is still invalid — silently wait for next probe.
          } catch {
            // Key still invalid — try again in 60 s.
          }
        } else if (this.authFailedReason === "server") {
          // probeAuth() sets authFailed/authFailedReason and logs the result
          void this.probeAuth();
        }
      }
    }

    this.rollTodayStatsIfNewEtDay(etDateKey());

    // ── Daily compounding target — day-roll snapshot + periodic persist ──────
    await this.refreshDailyTarget();

    const key = getPeriodKey();
    if (key !== this.lastPeriodKey && this.lastPeriodKey !== "") {
      // New period — reset traded flag
      this.tradedThisPeriod  = false;
      this.log("info", `New 15-min period: ${key}`);
      try {
        if (this.config.paperMode === true) {
          flushPaperBarsExcept(kalshiWS.getLatest()?.ticker ?? null, {
            virtualCents: this.paperVirtualBalanceCents,
            wins: this.paperStats.wins,
            losses: this.paperStats.losses,
            pnlCents: this.paperStats.pnlCents,
          });
        }
      } catch { /* observational paper-bar-tape */ }
      // Settlement is only due when the TRADE's own contract has expired.
      // An hourly trade must not be settled at the :15/:30/:45 boundaries —
      // tradeSecsRemaining() uses its stored close time, so this fires only
      // once its hour is actually over.
      if (this.openTrade && tradeSecsRemaining(this.openTrade) <= 0.5) await this.detectSettlement();
    }
    this.lastPeriodKey = key;

    // Hourly trades expire mid-period from the 15-min clock's perspective:
    // check their own expiry every tick, not just on period rollover.
    if (this.openTrade && this.openTrade.contractDurationMins === 60 &&
        tradeSecsRemaining(this.openTrade) <= 0.5) {
      await this.detectSettlement();
    }

    // proxyPrice = Black-Scholes inversion of Kalshi's own YES/NO book
    // (kalshi-price.ts). Documented as ±$150 mid-period noisy — it is ONLY
    // used as (a) the basis tracker's reference point and (b) a fallback
    // when no cross-exchange feed is available yet. It must never be pushed
    // to this.prices directly — that field drives currentBtcPrice, velocity,
    // distFromFloorPct, and every strategy's entry/exit decision, and the
    // Kalshi Oracle mobile app's displayed BTC price should match Kalshi's
    // own market page, not our noisy option-implied estimate.
    const proxyPrice = await this.fetchBtcPrice();

    // Update MTF floor strike so ATR-based stops are calibrated
    const tick = kalshiWS.getLatest();
    this.consecutiveInvalidKalshiPriceTicks = nextInvalidKalshiPriceTicks(
      this.consecutiveInvalidKalshiPriceTicks,
      tick,
    );
    if (tick?.floorStrike) mtfAnalyzer.setFloorStrike(tick.floorStrike);

    // ── Cross-exchange → BRTI basis tracking (de-noised spot + settlement
    // projection) ─────────────────────────────────────────────────────────
    // Runs every tick regardless of trade state so strategies always see a
    // fresh fairBRTI/projectedSettlementPrice, independent of whether we're
    // currently in a trade or between periods. Internally throttled/cached —
    // safe at this 500ms cadence. See basis-tracker.ts for the full model.
    if (tick?.floorStrike && proxyPrice > 0) {
      const secsRemainingNow = getSecsRemaining();
      this.lastBasisState = await basisTracker.tick({
        brtiProxy:     proxyPrice,
        floorStrike:   tick.floorStrike,
        velocityPerMin: this.currentVelocity,
        secsRemaining: secsRemainingNow,
        paperMode:     this.config.paperMode === true,
        // Book quoteTs, not heartbeat ts — lagProven only vs a fresh Kalshi book.
        quoteTs:       typeof tick.quoteTs === "number" && tick.quoteTs > 0 ? tick.quoteTs : tick.ts,
      });
      if (tick.ticker && tick.ticker !== this.origLagProjStreakTicker) {
        this.origLagProjStreak = emptyOrigLagProjStreak();
        this.origLagProjStreakTicker = tick.ticker;
      }
      this.origLagProjStreak = updateOrigLagProjStreak(this.origLagProjStreak, {
        projectedSettlement: this.lastBasisState?.projectedSettlementPrice,
        floor: tick.floorStrike,
      });

      // Durable history for offline lag/basis analysis (Task: basis-tracker
      // persistence). Throttled to the same ~45s cadence as the tracker's own
      // console log so this never approaches 500ms-tick write volume.
      // Fire-and-forget — never awaited into the tick loop, and
      // persistBasisSample() itself swallows/logs its own failures.
      const now = Date.now();
      if (now - this.lastBasisPersistedAt >= BASIS_PERSIST_INTERVAL_MS) {
        this.lastBasisPersistedAt = now;
        void persistBasisSample({
          ticker:        tick.ticker ?? null,
          floorStrike:   tick.floorStrike,
          secsRemaining: secsRemainingNow,
          state:         this.lastBasisState,
        });
      }

      // ── Market-wide learning (Plane R) ──────────────────────────────────
      // Studies EVERY 15m KXBTC contract, not just ones the bot trades —
      // runs unconditionally, independent of enabled/paperMode/open-trade
      // state. Throttled internally to ~30s/ticker. See market-learning.ts.
      if (tick?.ticker) {
        recordMarketObservation({
          ticker:        tick.ticker,
          periodOpenTs:  currentPeriodOpenTs(),
          secsRemaining: secsRemainingNow,
          floorStrike:   tick.floorStrike,
          fairPrice:     this.lastBasisState?.estimatedFairBRTI ?? null,
          mtf:           mtfAnalyzer.getSummaryRaw(),
          basis:         this.lastBasisState,
          candlePattern: candlePatternAnalyzer.getLatest(),
          yesAskCents:   typeof tick.yesAsk === "number" ? tick.yesAsk : null,
          noAskCents:    typeof tick.noAsk === "number" ? tick.noAsk : null,
          // v4.1 additions (GO — MARKET-LEARNING v4.1, 2026-08-24): already-
          // live, already-fetched fields, purely additive — no branch, gate,
          // or timing in this tick loop is touched by adding them.
          yesBidCents:   typeof tick.yesBid === "number" ? tick.yesBid : null,
          noBidCents:    typeof tick.noBid === "number" ? tick.noBid : null,
          liveVolumeInputs: { prices: this.prices, velocityDolPerMin: this.currentVelocity },
        });
      }
    }

    // ── Research Factory shadow logger (Step 7, opt-in, OFF by default) ─────
    // Purely observational: does not read openTrade/tradedThisPeriod state,
    // does not gate anything, cannot place an order. Only appends a line to
    // data/research-shadow-log.jsonl when this tick's (ask, minutes-left)
    // falls inside a ranked Research Factory candidate tier, for both sides
    // independently. See research-shadow-log.ts for the full rationale.
    if (this.config.researchShadowLoggingEnabled && tick?.ticker) {
      const secsLeftForShadow = getSecsRemaining();
      if (typeof tick.yesAsk === "number" && tick.yesAsk > 0) {
        recordShadowTick({ ticker: tick.ticker, askCents: tick.yesAsk, secsRemaining: secsLeftForShadow, side: "yes" });
      }
      if (typeof tick.noAsk === "number" && tick.noAsk > 0) {
        recordShadowTick({ ticker: tick.ticker, askCents: tick.noAsk, secsRemaining: secsLeftForShadow, side: "no" });
      }
    }

    // effectivePrice: use the raw live exchange price (Coinbase, same source
    // family as the Markets tab's Bitstamp+Coinbase average) rather than the
    // basis-corrected fairBRTI. Confirmed against a live Kalshi comparison
    // that the RAW exchange tick tracks Kalshi's own displayed price more
    // closely than the smoothed/basis-subtracted estimate — the correction
    // was actually pulling it further away. estimatedFairBRTI/rollingBasis
    // are kept as basisState fields for settlement projection only, not for
    // the bot's live price. Sanity-guarded against a >5% gap from the
    // option-implied proxy (would indicate a bad exchange tick) and against
    // having no exchange sample yet (startup / all feeds down) — both fall
    // back to the proxy price unchanged.
    const rawExchangePrice = this.lastBasisState?.exchangePrice ?? null;
    const effectivePrice =
      rawExchangePrice !== null && rawExchangePrice > 0 && proxyPrice > 0 &&
      Math.abs(rawExchangePrice - proxyPrice) / proxyPrice < 0.05
        ? rawExchangePrice
        : proxyPrice;

    if (effectivePrice > 0) {
      this.prices.push({ price: effectivePrice, ts: Date.now() });
      if (this.prices.length > 60) this.prices.shift();
    }

    this.computeVelocity();

    // Task #145: track vol-feed-dark periods as discrete incidents in the
    // health panel, not just an ephemeral in-trade badge. Runs every tick
    // (not just around order decisions) so the health panel's incident count
    // reflects the true duration/frequency of the feed going dark, matching
    // the same >30s threshold used by the pre-trade sim (#143) and dashboard
    // badges (#144).
    const volFeedStale = this.prices.length === 0
      || (Date.now() - this.prices[this.prices.length - 1].ts) > 30_000;
    // Read the store rather than a process-local boolean. This preserves the
    // lifecycle across restarts: init() may restore an open incident from the
    // database, and the first fresh tick must still resolve it.
    const volFeedIncidentOpen = incidentStore.getDegradedSince("volfeed") !== null;
    if (volFeedStale && !volFeedIncidentOpen) {
      incidentStore.enterDegraded("volfeed").catch(() => {});
    } else if (!volFeedStale && volFeedIncidentOpen) {
      incidentStore.exitDegraded("volfeed").catch(() => {});
    }

    // If in a trade: first confirm the position still actually exists on
    // Kalshi (the user may have closed it by hand in the app/mobile UI) —
    // must run BEFORE monitorOpenTrade()/considerAddingToPosition() so a
    // confirmed external close short-circuits the rest of this tick instead
    // of managing/adding to a position that's already gone.
    if (this.openTrade) {
      await this.reconcilePositionWithKalshi();
      if (!this.openTrade) {
        // Position was confirmed externally closed and cleared above.
        // Falling through to evaluateEntry() is intentionally NOT done here —
        // the normal end-of-tick flow below (lastObsTs/tradedThisPeriod) will
        // pick entries back up on the next tick, same as any other trade end.
        this.lastObsTs = Date.now();
        return;
      }
      await this.monitorOpenTrade();
      if (this.openTrade && !this.openTrade.addedContracts) {
        await this.considerAddingToPosition();
      }
      return;
    }

    // Advance observation timestamp even when waiting for the next period.
    // Without this, the watchdog sees lastObsTs frozen for up to 15 min after
    // a completed trade (tradedThisPeriod=true) and fires unnecessary heals.
    this.lastObsTs = Date.now();
    if (this.tradedThisPeriod) {
      // evaluateEntry is skipped after a fill this period; refresh lastSignalDesc
      // so a prior "Quote stale …" does not stick while WS ages keep updating.
      this.lastSignalDesc = "Already traded this period — waiting for next contract";
      return;
    }
    await this.evaluateEntry();
  }

  // ── External-close reconciliation ─────────────────────────────────────────
  // Detects when the user manually closes a position via the Kalshi app/
  // mobile UI while the bot still believes it's open, so the bot never
  // manages, adds to, or re-enters against a position that's already gone.

  /**
   * Fetches Kalshi's own net position for a ticker. Returns null on ANY
   * failure (auth, network, non-2xx, unexpected shape) — callers MUST treat
   * null as "couldn't confirm" and fail closed (no state change), never as
   * "flat". This endpoint has no prior working call site in this codebase,
   * so the response shape is defensive/best-effort per Kalshi's documented
   * portfolio/positions contract, not cross-checked against existing code.
   */
  // opts lets a time-critical caller (SHUTDOWN_GRACEFUL_CLOSE) trade a little
  // confirmation certainty for a hard bound on how long this check can take.
  // Default {attempts:2, timeoutMs:4000} (up to 8s worst case) is unchanged
  // for every other caller — this check already fails OPEN on no read (see
  // call site comment), so shortening it only affects how quickly it gives up
  // and proceeds with the originally-tracked size, never correctness.
  private async fetchKalshiPosition(
    ticker: string,
    opts: { attempts?: number; timeoutMs?: number } = {},
  ): Promise<{ position: number } | null> {
    try {
      const apiPath = KALSHI_PATH_PORTFOLIO_POSITIONS;
      const headers = await kalshiAuthHeaders("GET", apiPath);
      if (!headers["KALSHI-ACCESS-KEY"]) return null; // auth signing failed — can't confirm
      const url = `${KALSHI_API_DOMAIN}${apiPath}?ticker=${encodeURIComponent(ticker)}&settlement_status=unsettled`;
      const r = await fetchWithRetry(url, { headers: { ...headers, Accept: "application/json" } }, { attempts: opts.attempts ?? 2, timeoutMs: opts.timeoutMs ?? 4_000 });
      if (!r.ok) return null;
      const data = (await r.json()) as { market_positions?: Array<{ ticker?: string; position?: number }> };
      const rows = Array.isArray(data.market_positions) ? data.market_positions : null;
      if (!rows) return null;
      const row = rows.find(p => p.ticker === ticker);
      // No row for this ticker at all means Kalshi has no open position on it — flat.
      const position = row ? row.position : 0;
      if (typeof position !== "number" || !Number.isFinite(position)) return null;
      return { position };
    } catch (err) {
      this.log("warn", `[position-reconcile] fetchKalshiPosition(${ticker}) errored: ${(err as Error).message}`);
      return null;
    }
  }

  /**
   * Account-wide version of fetchKalshiPosition() for startup use, when there
   * is no single tracked ticker to check yet (openTrade is always null right
   * after a process restart). Returns every unsettled market position with a
   * nonzero contract count, or null on ANY failure (auth, network, bad
   * shape) — callers MUST treat null as "couldn't confirm", never as "flat".
   */
  /**
   * Pure decision extracted from checkForUnmanagedLivePositions() for direct
   * regression testing (Operational Resilience design item #4) of the
   * fail-closed startup gate: `null` (couldn't confirm) and a non-empty list
   * (confirmed unmanaged position) must BOTH block auto-start; only a
   * confirmed-empty list is safe to proceed on. See
   * docs/startup-reconciliation-deliberate-design-2026-08-12.md before
   * changing either failure branch.
   */
  private async fetchAllKalshiPositions(): Promise<AccountPositionSnapshot[] | null> {
    try {
      const apiPath = KALSHI_PATH_PORTFOLIO_POSITIONS;
      const headers = await kalshiAuthHeaders("GET", apiPath);
      if (isAuthSigningFailed(headers)) return null; // auth signing failed — can't confirm
      const url = `${KALSHI_API_DOMAIN}${apiPath}?settlement_status=unsettled`;
      const r = await fetchWithRetry(url, { headers: { ...headers, Accept: "application/json" } }, { attempts: 2, timeoutMs: 4_000 });
      if (!r.ok) return null;
      const data = (await r.json()) as { market_positions?: Array<{ ticker?: string; position?: number }> };
      const rows = Array.isArray(data.market_positions) ? data.market_positions : null;
      if (!rows) return null;
      return rows
        .filter((p): p is AccountPositionSnapshot =>
          typeof p.ticker === "string" && typeof p.position === "number" && Number.isFinite(p.position) && p.position !== 0)
        .map(p => ({ ticker: p.ticker, position: p.position }));
    } catch (err) {
      this.log("warn", `[startup-reconcile] fetchAllKalshiPositions() errored: ${(err as Error).message}`);
      return null;
    }
  }

  /**
   * One-shot startup safety check (live mode only): confirms Kalshi's account
   * doesn't show a real open position that this process has no record of
   * managing. `openTrade` is always null immediately after a restart, so
   * without this check the bot would happily start evaluating new entries
   * while a real, unmonitored position (no stop-loss, no exit logic watching
   * it) sits live on the exchange — a "ghost position" from the bot's own
   * perspective even though it's very real to the account balance.
   *
   * Fails safe in both directions:
   *  - Can't confirm either way (auth/network error) → block auto-start. An
   *    unconfirmed "maybe" must never be treated as "definitely flat."
   *  - Confirmed a live position exists → block auto-start and raise a
   *    "position" incident so it's visible in /healthz and the health panel.
   *    This intentionally does NOT try to reconstruct and resume managing the
   *    position (stop levels, thesis, etc. can't be safely inferred from a
   *    bare position row) — an operator must investigate and manually
   *    restart once it's resolved.
   *
   * This fail-closed shape is a deliberate design decision, not an oversight
   * to "fix" — see docs/startup-reconciliation-deliberate-design-2026-08-12.md
   * before changing either failure branch below.
   *
   * Returns true if auto-start should be blocked.
   */
  /** See evaluateUnmanagedPositionCheck() below — this method is now a thin
   * wrapper around that pure decision function plus the actual fetch/log/
   * incident side effects, so the fail-closed decision itself is directly
   * unit-testable without mocking the Kalshi HTTP call. */
  async checkForUnmanagedLivePositions(): Promise<boolean> {
    const positions = await this.fetchAllKalshiPositions();
    const decision  = evaluateUnmanagedPositionCheck(positions);

    if (decision.block) {
      this.log("warn", decision.logMessage!);
      await incidentStore.enterDegraded("position");
      return true;
    }

    // This is the one-time post-requote audit when the process starts: a
    // confirmed-empty unsettled position list proves no duplicate contracts
    // from a prior re-quote are still live. Do not infer this from botTrades;
    // Kalshi's portfolio state is the only authoritative source.
    this.log("info", "✅ [position-audit] Kalshi confirms no unsettled positions — no residual duplicate contracts found");
    // Confirmed flat — clear any previously-open "position" incident so the
    // health panel doesn't keep showing a stale warning past the point where
    // it was actually resolved (e.g. an operator closed the position and
    // restarted the process).
    await incidentStore.exitDegraded("position");
    return false;
  }

  /**
   * Account-wide reconciliation while the bot is running. The existing
   * per-ticker check below detects a manual close of the one trade we track;
   * this slower check is intentionally broader so it also catches an orphan
   * while `openTrade` is null, an opposite-side position, or a live count
   * greater than the bot's record after a failed re-quote.
   *
   * An unexpected position is never silently adopted or flattened here. A
   * bare position row cannot provide the entry thesis, stop policy, or a safe
   * executable quote. The bot keeps the incident open and stops new entry
   * decisions until an operator resolves it through Kalshi, matching the
   * deliberate fail-closed/manual-review policy already used at startup.
   */
  private async reconcileAccountPositionsWithKalshi(): Promise<void> {
    if (this.accountPositionReconcileInFlight) return;
    this.accountPositionReconcileInFlight = true;
    try {
      const positions = await this.fetchAllKalshiPositions();
      // Paper without readable Kalshi (no keys / network): do not fail-close
      // paper entries. "never" does not block shouldBlockSecondPosition.
      if (this.config.paperMode && positions === null) {
        this.accountPositionAudit = { checkedAt: Date.now(), status: "never", positions: [] };
        return;
      }
      const tracked = trackedKalshiTradeForAudit(this.openTrade);
      const summary = classifyAccountPositionState(positions, tracked);
      this.accountPositionAudit = {
        checkedAt: Date.now(),
        status: summary.status,
        positions: positions ?? [],
      };

      if (summary.status === "unknown") {
        this.log("warn",
          "🚨 [position-audit] Could not confirm live Kalshi positions (auth/network/malformed response) — " +
          "keeping position incident open and blocking new entries");
        await incidentStore.enterDegraded(
          "position",
          "Could not confirm live Kalshi positions during periodic account-wide reconciliation",
        );
        return;
      }

      if (summary.status === "unmanaged") {
        const detail = summary.unmanaged.map(p => `${p.ticker}:${p.position}`).join(", ");
        this.log("warn",
          `🚨 [position-audit] Unmanaged live Kalshi position(s): ${detail}. ` +
          "Bot remains fail-closed; a MANUAL fill blocks a second bot position.");
        await this.ingestManualKalshiPositions(summary.unmanaged);
        await incidentStore.enterDegraded("position", `Unmanaged live position(s): ${detail}`);
        return;
      }

      if (summary.status === "tracked-mismatch") {
        const trade = this.openTrade;
        this.log("warn",
          `🚨 [position-audit] Tracked ${trade?.ticker ?? "position"} differs from Kalshi: ` +
          `bot=${summary.expectedContracts} contracts, Kalshi=${summary.trackedContracts}. ` +
          "Keeping the position incident open; the fast reconciler will require confirmation before changing trade state.");
        await incidentStore.enterDegraded(
          "position",
          `Tracked count ${summary.expectedContracts} differs from Kalshi ${summary.trackedContracts}`,
        );
        return;
      }

      // A confirmed empty account or exact tracked match resolves a previous
      // account-wide warning. No assumption is made on a failed read above.
      await incidentStore.exitDegraded("position");
    } catch (err) {
      // The fetch helper already normalizes request failures to null, but keep
      // the timer callback fail-closed even if a future refactor throws — except
      // paper, where an unreadable Kalshi must not block the sim.
      if (this.config.paperMode) {
        this.accountPositionAudit = { checkedAt: Date.now(), status: "never", positions: [] };
        this.log("warn", `[position-audit] Paper recon failed (not blocking paper): ${(err as Error).message}`);
      } else {
        this.accountPositionAudit = { checkedAt: Date.now(), status: "unknown", positions: [] };
        this.log("warn", `🚨 [position-audit] Unexpected reconciliation failure: ${(err as Error).message}`);
        await incidentStore.enterDegraded("position", "Unexpected account-wide position reconciliation failure");
      }
    } finally {
      this.accountPositionReconcileInFlight = false;
    }
  }

  /**
   * Persist unmanaged Kalshi positions as MANUAL fills (idempotent per ticker
   * while pending). They count toward overall P&L once settled; they never
   * feed learner / WR / Kelly. Presence already blocks a second bot position
   * via accountStatus=unmanaged.
   */
  private async ingestManualKalshiPositions(unmanaged: AccountPositionSnapshot[]): Promise<void> {
    try {
      await ensureFillOriginColumn();
    } catch (err) {
      this.log("warn", `[manual-fill] fill_origin column ensure failed: ${(err as Error).message}`);
    }
    for (const pos of unmanaged) {
      if (!pos.ticker || pos.position === 0) continue;
      const intent = kalshiPositionToManualIntent(pos);
      if (intent.contracts <= 0) continue;
      try {
        const existing = await db.select({ id: botTrades.id }).from(botTrades).where(and(
          eq(botTrades.ticker, intent.ticker),
          eq(botTrades.fillOrigin, FILL_ORIGIN_MANUAL),
          sql`${botTrades.outcome} in ('pending', 'unresolved')`,
        )).limit(1);
        if (existing.length > 0) continue;
        await db.insert(botTrades).values({
          ticker: intent.ticker,
          side: intent.side,
          contracts: intent.contracts,
          entryPriceCents: 1,
          signal: intent.signal,
          strategyId: intent.strategyId,
          orderId: `manual-${intent.ticker}`,
          outcome: "pending",
          isPaper: false,
          fillOrigin: FILL_ORIGIN_MANUAL,
          entryReason: "MANUAL Kalshi-app fill — ingested by position recon; not a bot entry",
        });
        this.log("info", `📥 MANUAL fill tagged ${intent.ticker} ${intent.side} x${intent.contracts} (blocks second bot position; excluded from bot WR/learner)`);
      } catch (err) {
        this.log("warn", `[manual-fill] ingest ${pos.ticker} failed: ${(err as Error).message}`);
      }
    }
  }

  /**
   * Best-effort lookup of the fill(s) that closed a position externally, to
   * infer a realized exit price. Returns null on anything unexpected rather
   * than guessing a price. The caller falls back to an "unresolved" outcome
   * when this fails.
   */
  private async fetchExternalCloseExitPrice(trade: OpenTrade): Promise<number | null> {
    try {
      const apiPath = KALSHI_PATH_PORTFOLIO_FILLS;
      const headers = await kalshiAuthHeaders("GET", apiPath);
      if (!headers["KALSHI-ACCESS-KEY"]) return null;
      const minTs = Math.floor(trade.openedAt / 1000);
      const url = `${KALSHI_API_DOMAIN}${apiPath}?ticker=${encodeURIComponent(trade.ticker)}&min_ts=${minTs}&limit=100`;
      const r = await fetchWithRetry(url, { headers: { ...headers, Accept: "application/json" } }, { attempts: 2, timeoutMs: 4_000 });
      if (!r.ok) return null;
      const data = (await r.json()) as { fills?: KalshiFill[] };
      const fills = Array.isArray(data.fills) ? data.fills : null;
      if (!fills || fills.length === 0) return null;
      return computeExternalCloseExitPriceCents(fills, trade.ticker, trade.side);
    } catch (err) {
      this.log("warn", `[position-reconcile] fetchExternalCloseExitPrice(${trade.ticker}) errored: ${(err as Error).message}`);
      return null;
    }
  }

  /**
   * Periodically (while a real, non-paper trade is open) confirms our
   * tracked position still matches Kalshi's own record. Requires
   * POSITION_MISMATCH_CONFIRM_STRIKES consecutive confirmed mismatches
   * before acting, to avoid a single flaky/lagged read wrongly clearing a
   * real position.
   */
  private async reconcilePositionWithKalshi(): Promise<void> {
    const trade = this.openTrade;
    if (!trade || trade.paper) return; // nothing to reconcile for paper trades

    const now = Date.now();
    if (now - trade.openedAt < ENTRY_RECONCILE_GRACE_MS) return; // too fresh — Kalshi's own ledger may not have caught up yet
    if (now - this.lastPositionReconcileAt < POSITION_RECONCILE_INTERVAL_MS) return;
    this.lastPositionReconcileAt = now;

    const result = await this.fetchKalshiPosition(trade.ticker);
    if (result === null) {
      // Fail closed — could not confirm either way. Do not clear state, do
      // not reset the mismatch streak (an in-progress confirmation window
      // shouldn't be reset just because one poll happened to fail).
      this.log("warn", `[position-reconcile] could not confirm ${trade.ticker} (Kalshi unreachable/auth failed) — skipping this cycle`);
      return;
    }

    // Kalshi's position field is signed: positive = net long YES, negative =
    // net long NO. Read off whichever side matches our tracked trade.
    const kalshiSameSideContracts = kalshiSameSidePosition(result.position, trade.side);

    if (!isPositionMismatch(kalshiSameSideContracts, trade.contracts)) {
      if (this.positionMismatchStreak > 0) {
        this.log("info", `[position-reconcile] ${trade.ticker} back in sync (Kalshi confirms ${kalshiSameSideContracts} ${trade.side})`);
      }
      this.positionMismatchStreak = 0;
      this.markPositionReconciled();
      return;
    }

    this.positionMismatchStreak++;
    this.log("warn",
      `[position-reconcile] MISMATCH (${this.positionMismatchStreak}/${POSITION_MISMATCH_CONFIRM_STRIKES}) ${trade.ticker} ${trade.side} · ` +
      `bot tracks ${trade.contracts} · Kalshi shows ${kalshiSameSideContracts}`
    );
    if (this.positionMismatchStreak < POSITION_MISMATCH_CONFIRM_STRIKES) return;

    // Profit Doctrine Phase 6: RECON row for a confirmed external-close
    // mismatch (label provenance — this row exists so the desk can tell
    // "the bot detected this was closed outside its own order flow" apart
    // from a normal SETTLE, which handleExternalClose()'s own
    // recordSettlement() call still writes moments later for the economics).
    void persistDecisionTraceEvent({
      eventType: "RECON", ticker: trade.ticker, side: trade.side, strategyId: trade.strategyId,
      chain: [`EXTERNAL_CLOSE_MISMATCH`, `bot_tracked=${trade.contracts}`, `kalshi_shows=${kalshiSameSideContracts}`],
    });

    await this.handleExternalClose(trade, kalshiSameSideContracts);
    this.positionMismatchStreak = 0;
  }

  /**
   * Confirmed external close: the user closed this position outside the bot
   * (manually in the Kalshi app/mobile UI, or by any means other than the
   * bot's own order flow). Any mismatch magnitude — partial or full — makes
   * the bot stop managing/adding-to/re-entering this position entirely: it
   * can no longer trust its own contract count against Kalshi's, and
   * reconstructing what's left to manage safely isn't worth the risk. That
   * "stop managing" decision applies to the full tracked size either way,
   * but the REALIZED P&L recorded for this trade must reflect only the
   * contracts Kalshi confirms actually closed (trade.contracts -
   * kalshiContracts) — not the full original size — or a partial close
   * silently overstates the win/loss by the fraction that's still open.
   */
  private async handleExternalClose(trade: OpenTrade, kalshiContracts: number): Promise<void> {
    let exitPriceCents = await this.fetchExternalCloseExitPrice(trade);
    if (exitPriceCents === null) {
      // Fills can lag the position update by a few seconds — one short
      // retry before falling back to balance-inference/unresolved avoids
      // manufacturing an "unresolved" trade just because we asked too soon.
      await new Promise(resolve => setTimeout(resolve, 2_500));
      exitPriceCents = await this.fetchExternalCloseExitPrice(trade);
    }
    // kalshiContracts is what Kalshi still shows open on this side; anything
    // less than trade.contracts must have been closed for this trade's P&L
    // to be attributable.
    const closedContracts = computeExternalCloseClosedContracts(trade.contracts, kalshiContracts);
    const isPartial = kalshiContracts > 0;

    if (exitPriceCents !== null) {
      // FEE ORGAN: early sell = entry fee + exit (second) fee.
      const { pnlCents, exitFeeCents } = computeEarlyExitFeeNetPnl(
        closedContracts, trade.entryPriceCents, exitPriceCents,
      );
      const outcome       = pnlCents >= 0 ? "win" : "loss";
      this.log("settle",
        `🔔 EXTERNAL_CLOSE ${trade.ticker} ${trade.side.toUpperCase()} tracked ×${trade.contracts} @${trade.entryPriceCents}¢ → ` +
        `Kalshi shows ${kalshiContracts} contracts remaining (${isPartial ? `PARTIAL close, ${closedContracts} closed` : "full close"}) · inferred exit ${exitPriceCents}¢ · ` +
        `${pnlCents >= 0 ? "+" : "-"}$${(Math.abs(pnlCents) / 100).toFixed(2)} on the closed portion` +
        (isPartial ? ` · ${kalshiContracts} contracts left unmanaged on Kalshi (bot stops tracking this position)` : "") +
        ` · openTrade cleared`
      );
      this.openTradeMaxGain = 0;
      // authoritative=false: a human-driven exit isn't a signal about the
      // strategy's own edge, so this must not feed strategy-learning stats —
      // mirrors how the existing heuristic-settlement fallback is treated.
      await this.recordSettlement(trade, outcome, pnlCents, Math.round(exitPriceCents * closedContracts), undefined, "EXTERNAL_CLOSE", false);
    } else {
      // No matching closing fill could be found to price the exit directly.
      // Fall back to inferring the outcome from the account balance itself —
      // refresh first so this isn't working off a stale poll (balance can be
      // up to 15s old otherwise). This is the same balanceAfterCents snapshot
      // recordSettlement() already treats as an honest (if not perfectly
      // isolated) read of what the account looked like at that moment.
      await this.refreshBalance();
      let balanceAfterCents   = this.accountBalance != null ? Math.round(this.accountBalance) : null;
      const balanceBeforeCents = trade.balanceBeforeCents ?? null;
      let inferred = computeBalanceInferredOutcome({ balanceBeforeCents, balanceAfterCents });

      // Bug found 2026-08-16: a real manual close (nonzero contracts bought
      // at a real entry price) should essentially never net to EXACTLY 0
      // cents — but Kalshi's balance ledger can lag the actual fill by a
      // few seconds (the same lag fetchExternalCloseExitPrice already
      // retries once for above). Trusting an exact-zero delta at face value
      // was silently recording every one of these as a "win +$0.00" (34/34
      // win-outcome EXTERNAL_CLOSE_BALANCE_INFERRED rows were exactly 0,
      // while loss-outcome rows showed real nonzero deltas) — understating
      // the true combined bot+manual P&L shown on the dashboard. Give the
      // ledger one more chance to catch up; if it's STILL exactly zero,
      // don't fabricate a $0 win — fall through to the unresolved branch
      // below so it's surfaced via the incident pipeline instead of quietly
      // poisoning todayPnlCents and the settled-trade analytics with a
      // number we don't actually believe.
      if (inferred != null && inferred.pnlCents === 0) {
        await new Promise(resolve => setTimeout(resolve, 4_000));
        await this.refreshBalance();
        balanceAfterCents = this.accountBalance != null ? Math.round(this.accountBalance) : null;
        const retried = computeBalanceInferredOutcome({ balanceBeforeCents, balanceAfterCents });
        inferred = retried != null && retried.pnlCents !== 0 ? retried : null;
      }

      // Bug found 2026-08-16: balance-inference blindly trusted whatever
      // delta it saw, with nothing to catch a delta caused by something
      // other than this trade closing (a second concurrent balance-moving
      // event, or a stale/wrong snapshot). A Kalshi binary contract can
      // never produce a P&L outside what its own entry price and closed
      // size make physically possible — so bound the inferred number
      // against that ground truth before trusting it, the same way the
      // STARTUP_RECOVERY path now verifies a fill exists before scoring one.
      let balanceInferenceImplausible = false;
      if (inferred != null && !isBalanceInferredPnlPlausible(inferred.pnlCents, closedContracts, trade.entryPriceCents)) {
        balanceInferenceImplausible = true;
        inferred = null;
      }

      if (inferred != null) {
        const { outcome, pnlCents } = inferred;
        this.log("settle",
          `🔔 EXTERNAL_CLOSE ${trade.ticker} ${trade.side.toUpperCase()} ×${trade.contracts} @${trade.entryPriceCents}¢ → ` +
          `Kalshi shows ${kalshiContracts} contracts (manual exit detected) · no matching fill found · inferred from balance ` +
          `$${(balanceBeforeCents! / 100).toFixed(2)} → $${(balanceAfterCents! / 100).toFixed(2)} · ` +
          `${pnlCents >= 0 ? "+" : "-"}$${(Math.abs(pnlCents) / 100).toFixed(2)} · openTrade cleared`
        );
        this.openTradeMaxGain = 0;
        // Balance-inferred, not fill-priced — same authoritative=false
        // treatment as the fill-priced EXTERNAL_CLOSE branch above; a
        // human-driven exit still isn't a signal about the strategy's edge.
        // affectsRiskCounters=false: an unattributed balance-inferred delta
        // must not gate the daily loss cap or consecutive-loss cooldown —
        // see recordSettlement's affectsRiskCounters doc comment.
        await this.recordSettlement(trade, outcome, pnlCents, 0, undefined, "EXTERNAL_CLOSE_BALANCE_INFERRED", false, false);
      } else {
        // Genuinely can't tell — either no fill AND no usable balance
        // snapshot (balance poll unreachable, or this trade predates the
        // balanceBeforeCents field), or a balance snapshot existed but its
        // delta was outside what this position's own entry price and size
        // could ever produce (contamination/stale-snapshot suspected — see
        // isBalanceInferredPnlPlausible). Either way this is left unresolved
        // rather than recording a number that isn't trustworthy.
        const unresolvedDetail = balanceInferenceImplausible
          ? "no matching fill, and the balance delta was outside this position's physically possible P&L range (contamination or stale snapshot suspected) — not trusted"
          : "no matching fill, no balance snapshot";
        this.log("settle",
          `🔔 EXTERNAL_CLOSE ${trade.ticker} ${trade.side.toUpperCase()} ×${trade.contracts} @${trade.entryPriceCents}¢ → ` +
          `Kalshi shows ${kalshiContracts} contracts (manual exit detected) · exit price unresolved (${unresolvedDetail}) · ` +
          `marked unresolved · openTrade cleared`
        );
        this.openTradeMaxGain = 0;
        if (trade.dbId != null) {
          try {
            await markTradeUnresolved(
              trade.dbId,
              "EXTERNAL_CLOSE_UNRESOLVED",
              "Position closed externally (outside the bot) — Kalshi shows fewer contracts than tracked, but no matching closing fill or balance snapshot was found to price the exit.",
            );
          } catch (err) {
            this.log("warn", `[position-reconcile] failed to persist EXTERNAL_CLOSE_UNRESOLVED for trade #${trade.dbId}: ${(err as Error).message}`);
          }
        }
        // Genuinely unresolved P&L is a real operator-visibility gap (money
        // moved and this bookkeeping can't say how much) — surface it via
        // the same incident pipeline the health panel already reads, rather
        // than leaving it as a log line + DB row nobody is looking at.
        // enterDegraded+exitDegraded back-to-back records a discrete,
        // already-resolved incident (this isn't an ongoing degraded state
        // like the "unmanaged position" use of this subsystem family) —
        // it just needs to land in getIncidentCount24h("settlement")/
        // getIncidentTimestamps24h("settlement") for the health panel.
        incidentStore.enterDegraded("settlement")
          .then(() => incidentStore.exitDegraded("settlement"))
          .catch(() => {});
      }
    }

    this.setOpenTrade(null);
  }

  // ── Open trade monitoring — stop-loss, profit-take ────────────────────────────

  /**
   * Open-position thesis (VALID / BROKEN / UNKNOWN). Pure thesisState() is
   * the decision; this only gathers already-computed bot fields. paper=live.
   */
  /**
   * Tick lag/floor persistence BEFORE evaluateOpenThesis.
   * PATH_RIDE early-returns before checkLagFlip/checkThesisBreak, so without
   * this counters stay 0 forever → lagAgainstSustained/floorCross never set →
   * thesis never BROKEN → TB/HA_FLIP/fuse dead after LEAK A / FLOOR demote.
   * Non-PATH_RIDE checkLagFlip/checkThesisBreak must NOT double-increment.
   */
  private tickOpenThesisPersistence(
    trade: OpenTrade,
    btcPrice: number,
    floorStrike: number,
    vel: number,
    secs: number,
  ): void {
    const brtiAgainst = this.isLagAgainstSide(trade.side, floorStrike, vel, secs);
    this.basisFlipAgainstTicks = brtiAgainst ? this.basisFlipAgainstTicks + 1 : 0;
    // #725: 1s consecutive BOTH Coinbase lead-against AND BRTI/proj-against.
    const leadAgainst = leadAgainstSide({
      tradeSide: trade.side,
      lagDollars: this.lastBasisState?.lagDollars,
    });
    const both = nextLagFlipBothAgainstStreak({
      prevStreak: this.lagFlipBothAgainstSecStreak,
      lastSampleSec: this.lagFlipLastSampleSec,
      nowMs: Date.now(),
      leadAgainst,
      brtiAgainst,
    });
    this.lagFlipBothAgainstSecStreak = both.streak;
    this.lagFlipLastSampleSec = both.lastSampleSec;
    const strikeBuffer = floorStrike * 0.0005;
    const throughStrike = btcPrice > 0 && floorStrike > 0 && (
      trade.side === "yes" ? btcPrice < floorStrike - strikeBuffer
                            : btcPrice > floorStrike + strikeBuffer);
    this.strikeCrossTicks = throughStrike ? this.strikeCrossTicks + 1 : 0;
  }

  private evaluateOpenThesis(
    trade: OpenTrade,
    opts: {
      markCents: number;
      askCents?: number;
      quoteSource?: "ws" | "rest";
      quoteStale?: boolean;
      secs: number;
      vel: number;
      floorStrike: number;
      nowMs?: number;
    },
  ): ThesisState {
    const nowMs = opts.nowMs ?? Date.now();
    // BASIS LEAD for lag/thesis proj — NOT CF BRTI settlement pin (see getFreshBrtiUsd).
    // Lag meter money path left on estimatedFairBRTI deliberately (mid-session swap deferred).
    const fair = this.lastBasisState?.estimatedFairBRTI;
    const live = (fair != null && Number.isFinite(fair))
      ? projectSettlementPrice(fair, opts.vel, opts.secs)
      : null;
    const canon = canonicalLagProjectedSettlement({
      liveProj: live,
      snapshotProj: this.lastBasisState?.projectedSettlementPrice,
      floor: opts.floorStrike,
    });
    const projected = canon.splitBrain ? null : (canon.proj ?? null);
    const lagAgrees = projected == null ? null : projAgreesWithSideFn({
      tradeSide: trade.side,
      projected,
      floorStrike: opts.floorStrike,
    });
    const lagStale = basisTracker.isFairValueStale()
      || this.lastBasisState == null
      || this.lastBasisState.lagStale === true;
    const lagAgainstSustained = shouldLagFlipExit({
      consecutiveBothAgainst: this.lagFlipBothAgainstSecStreak,
      samplesAgainstLead: this.lagFlipBothAgainstSecStreak,
      samplesAgainstBrti: this.lagFlipBothAgainstSecStreak,
      samplesAgainst: this.basisFlipAgainstTicks,
      msSinceFill: nowMs - trade.openedAt,
      lagProven: this.lastBasisState?.lagProven === true ? true
        : this.lastBasisState?.lagProven === false ? false
        : undefined,
    });
    const reversalPattern = candlePatternAnalyzer.getLatest();
    const signalReverseConfirmed = this.config.candlestickPatternLiveEnabled === true
      && isPatternReversalAgainstSide(reversalPattern, trade.side, trade.openedAt);
    return thesisState(
      {
        side: trade.side,
        entryPriceCents: trade.entryPriceCents,
        openedAt: trade.openedAt,
        signal: trade.signal,
      },
      {
        nowMs,
        markCents: opts.markCents,
        askCents: opts.askCents,
        quoteSource: opts.quoteSource,
        quoteStale: opts.quoteStale === true,
        lagAgrees,
        lagStale,
        lagAgainstSustained,
        mtfScore: mtfAnalyzer.getScore(),
        ticketAdverseCents: trade.entryPriceCents - opts.markCents,
        projFlickerOnly: false,
        floorCrossAgainst: this.strikeCrossTicks >= 20,
        signalReverseConfirmed,
        secsRemaining: opts.secs,
      },
    );
  }

  /**
   * Hard stop — catastrophic mark ≤ 5¢ sustained ≥20s, or ruin ≤12 while
   * thesis BROKEN sustained ≥20s. Never on VALID/omit/UNKNOWN or ticketGreen
   * for ruin/vol dumps (evaluateHardStopDecision). PATH_RIDE open trades
   * fail-closed here — decidePathRideExit owns those exits. OTM asymmetry exempt.
   */
  private async checkHardStop(
    trade: OpenTrade, currentSidePrice: number, perContractPnl: number, secs: number,
    priceBreakdown?: ExitPriceBreakdown,
    thesisStatus?: ThesisStatus,
  ): Promise<boolean> {
    // Fail-closed: PATH_RIDE books are owned by decidePathRideExit only.
    // Never let leftover HARD_STOP_EXIT bypass HOLD_TRAIL / cat-sustain law.
    if (isPathRideOpenTrade(trade)) {
      this.log("warn",
        `HARD_STOP_EXIT blocked on PATH_RIDE book (decidePathRideExit owns exits) ` +
        `${trade.side.toUpperCase()} ${trade.ticker} thesis=${thesisStatus ?? "omit"}`);
      return false;
    }
    const decision = evaluateHardStopDecision({
      useStopLoss: this.config.useStopLoss,
      isOTMAsymmetry: trade.isOTMAsymmetry,
      usePctStops: this.config.usePctStops,
      entryPriceCents: trade.entryPriceCents,
      currentSidePrice,
      perContractPnl,
      hardStopPct: this.config.hardStopPct,
      hardStopCents: this.config.hardStopCents,
      entryStopCents: trade.entryStopCents,
      thesisStatus,
      holdMs: Date.now() - trade.openedAt,
      catastrophicBelowMs: this.frozenCatastrophicBelowSinceMs != null
        ? Date.now() - this.frozenCatastrophicBelowSinceMs
        : 0,
      brokenPersistedMs: this.pathRideBrokenSinceMs != null
        ? Date.now() - this.pathRideBrokenSinceMs
        : 0,
      ticketGreen: Number.isFinite(currentSidePrice) && Number.isFinite(trade.entryPriceCents)
        && currentSidePrice > trade.entryPriceCents,
      entryAsk: trade.entryPriceCents,
      markAsk: currentSidePrice,
      strategyId: trade.strategyId,
    });
    if (!decision) return false;
    const catastrophic = Number.isFinite(currentSidePrice) && currentSidePrice <= CATASTROPHIC_MARK_CENTS;
    if (!catastrophic && isPathRideFlickerBook(trade)) {
      const holdMs = Date.now() - trade.openedAt;
      const ticketAdverseCents = trade.entryPriceCents - currentSidePrice;
      if (!pathRideAntiFlickerExitOk({ holdMs, ticketAdverseCents })) return false;
    }
    const entryStopCeiling = trade.entryStopCents ?? this.config.hardStopCents;
    const effectiveHardStopCents = Math.min(this.config.hardStopCents, entryStopCeiling);
    const effectiveHardStopPct = trade.entryPriceCents > 0
      ? Math.min(this.config.hardStopPct, entryStopCeiling / trade.entryPriceCents * 100)
      : this.config.hardStopPct;
    const marketLossPct = trade.entryPriceCents > 0
      ? (trade.entryPriceCents - currentSidePrice) / trade.entryPriceCents * 100
      : 0;
    const detail = this.config.usePctStops && marketLossPct >= effectiveHardStopPct
      ? `hardStopPct ${effectiveHardStopPct.toFixed(1)}% breached (loss ${marketLossPct.toFixed(1)}%)`
      : `hardStopCents ${effectiveHardStopCents}¢ breached`;

    this.log("warn",
      `🛑 HARD_STOP_EXIT (catastrophic/thesis-BROKEN): ${trade.side.toUpperCase()} entry=${trade.entryPriceCents}¢ ` +
      `contracts=${trade.contracts} · ${detail} · current=${currentSidePrice.toFixed(0)}¢ ` +
      `pnl=${perContractPnl.toFixed(1)}¢/contract · secsLeft=${secs} · ` +
      `holdToSettlement=${this.config.holdToSettlement} settlementHoldActive=${this.settlementHoldActive}`
    );
    await this.exitEarly("HARD_STOP_EXIT", currentSidePrice, priceBreakdown);
    return true;
  }

  /**
   * Thesis-break exit — persistence-gated, runs regardless of holdToSettlement
   * mode/settlement-hold state (only checkHardStop, called just before this,
   * outranks it). Never fires on a single tick/blip — each of the two
   * independent rules requires sustained evidence against the position:
   *
   *   1. VELOCITY_FLIP_AGAINST — ≥3 consecutive ticks (~1.5s) with velocity
   *      ≥40 $/min against the position (weaker noise doesn't count).
   *      Money-maker (CONFLUENCE_CASCADE / BASIS_LAG_EDGE) also requires
   *      holdMs ≥ THESIS_BREAK_MIN_HOLD_MS (15s) before this rule may exit.
   *      PATH_RIDE/CC/LAG also 15s-gate FLOOR_CROSS / PATTERN / FAST_REVERSAL.
   *      Catastrophic mark ≤5¢ and STOP remain immediate.
   *      Do not enable the global timing-clock live flag (would extra-gate every strategy).
   *   2. FLOOR_CROSS is EVIDENCE only (Stellar 2026-09-04) — spot wick through
   *      strike is NOT solo BROKEN and NOT solo THESIS_BREAK_EXIT (BRTI 60s avg).
   *      strikeCrossTicks still feed UNKNOWN evidence via evaluateOpenThesis.
   *   3. PATTERN_REVERSAL_AGAINST (added 2026-08-18) — the live candlestick
   *      scanner (candlestick-patterns.ts) confirms a bottom-reversal shape
   *      against an open "no" position, or a top-reversal shape against an
   *      open "yes" position (see BOTTOM_REVERSAL_PATTERNS/TOP_REVERSAL_
   *      PATTERNS). No extra tick-persistence counter here — the pattern
   *      itself is already computed from one fully-formed 60s candle, not
   *      raw tick noise — but `isPatternReversalAgainstSide` requires the
   *      pattern to have been detected strictly after entry, so a shape
   *      already on the chart (and evidently not disqualifying) at entry
   *      time can't immediately stop the trade back out. This is a
   *      defensive/exit-only addition — it never opens or sizes a trade,
   *      only closes one early when the chart itself confirms the reversal
   *      the position is betting against.
   *
   * The former Rule 3 (basis/lag projection flip) was split out 2026-08-14
   * into its own dedicated `checkLagFlip()` exit (LAG_FLIP_EXIT) so lag
   * disagreement gets its own named reason code instead of being folded into
   * THESIS_BREAK_EXIT — see that function's doc comment.
   *
   * Any one rule fully satisfied AND thesisStatus===BROKEN fires exit. On fire:
   * logs full context, clears both persistence counters, and starts a
   * 60s same-ticker re-entry cooldown (checked in evaluateEntry).
   * VALID|UNKNOWN + velocity alone → HOLD (Goose LEAK A).
   */
  private async checkThesisBreak(
    trade: OpenTrade, currentSidePrice: number, perContractPnl: number, secs: number,
    vel: number, btcPrice: number, floorStrike: number, priceBreakdown?: ExitPriceBreakdown,
    thesisStatus?: ThesisStatus,
  ): Promise<boolean> {
    // Goose LEAK A: VELOCITY_FLIP + 15s+3¢ must NOT sell while thesis still VALID/UNKNOWN.
    // BROKEN only = lag sustained and/or signal reverse (FLOOR_CROSS is UNKNOWN evidence, not solo kill).
    // Velocity alone is flicker — update counters below; gate sell on status===BROKEN after counters.

    // Rule 1 — VELOCITY_FLIP_AGAINST
    const velocityAgainst = (trade.side === "yes" && vel <= -40) ||
                            (trade.side === "no"  && vel >=  40);
    this.thesisVelocityAgainstTicks = velocityAgainst ? this.thesisVelocityAgainstTicks + 1 : 0;
    let velocityRuleFired = this.thesisVelocityAgainstTicks >= 3;

    // Rule 2 — FLOOR_CROSS_AGAINST (strikeCrossTicks ticked in tickOpenThesisPersistence)
    const floorCrossRuleFired = this.strikeCrossTicks >= 20;

    // Rule 3 — PATTERN_REVERSAL_AGAINST (2026-08-18)
    // candlestickPatternLiveEnabled=false must also disable this rule, or the
    // flag is a lie: PATTERN_REVERSAL would still force THESIS_BREAK_EXIT.
    const reversalPattern = candlePatternAnalyzer.getLatest();
    const patternRuleFired = this.config.candlestickPatternLiveEnabled === true
      && isPatternReversalAgainstSide(reversalPattern, trade.side, trade.openedAt);

    // Paper 1W/9L + #507/#508: ALL TB on CC/LAG/PATH_RIDE/HA_* need hold>=15s
    // AND ticket adverse >=3¢. Catastrophic ≤5¢ immediate. Green coupon never TB.
    const pathRideThesis = isPathRideFlickerBook(trade);
    const holdMs = Date.now() - trade.openedAt;
    const catastrophic = Number.isFinite(currentSidePrice) && currentSidePrice <= CATASTROPHIC_MARK_CENTS;
    const ticketAdverseCents = trade.entryPriceCents - currentSidePrice;
    // SEV0 leftover TB belt (organs/exit-leftover): PATH_RIDE VALID|green never TB (non-cat).
    {
      const ticketGreen = Number.isFinite(currentSidePrice)
        && Number.isFinite(trade.entryPriceCents)
        && currentSidePrice > trade.entryPriceCents;
      const statusHint = thesisStatus ?? null;
      if (leftoverTbNoOp({
        pathRideThesis,
        catastrophic,
        ticketGreen,
        thesisStatus: statusHint,
      })) {
        this.log("info",
          `[thesis] leftover TB no-op on pathRide VALID/green (status=${statusHint ?? "n/a"} green=${ticketGreen})`
        );
        return false;
      }
    }
    let floorEvidence = floorCrossRuleFired; // wick evidence only — never solo TB
    let patternFired = patternRuleFired;
    if (pathRideThesis && !catastrophic && !pathRideAntiFlickerExitOk({ holdMs, ticketAdverseCents })) {
      velocityRuleFired = false;
      floorEvidence = false;
      patternFired = false;
    }

    // Stellar 2026-09-04: FLOOR_CROSS alone is NOT a TB rule (BRTI 60s ≠ spot wick).
    // Real TB fire rules: VELOCITY_FLIP (needs BROKEN) / PATTERN_REVERSAL (needs BROKEN).
    // Lag sustained exits via checkLagFlip / PATH_RIDE decideExit, not floor.
    if (!velocityRuleFired && !patternFired) return false;

    // Non-PATH_RIDE leftover still AND ticket-adverse ≥3¢. Green never TB.
    if (!ticketAdverseThesisBreakOk(ticketAdverseCents)) return false;

    // LEAK A gate: re-evaluate AFTER counter updates so SIGNAL_REVERSE
    // that just crossed persistence set BROKEN same-tick. Optional thesisStatus===BROKEN
    // override lets tests force BROKEN+velocity without lag setup.
    const evaluated = this.evaluateOpenThesis(trade, {
      markCents: currentSidePrice,
      secs,
      vel,
      floorStrike,
    });
    const status: ThesisStatus =
      thesisStatus === "BROKEN" || evaluated.status === "BROKEN"
        ? "BROKEN"
        : (thesisStatus ?? evaluated.status);
    if (status !== "BROKEN") {
      trade.exitThesisStatus = status;
      trade.exitThesisReasons = evaluated.reasons.slice();
      trade.exitTicketGreen = Number.isFinite(currentSidePrice)
        && Number.isFinite(trade.entryPriceCents)
        && currentSidePrice > trade.entryPriceCents;
      this.log("info",
        `[thesis] TB rules lit (${velocityRuleFired ? "VELOCITY" : "PATTERN"}` +
        `${floorEvidence ? "+FLOOR_EVIDENCE" : ""}) ` +
        `but thesisStatus=${status} reasons=${evaluated.reasons.join(",")} — HOLD (need BROKEN)`
      );
      return false;
    }

    // Floor is evidence only — never preferred as ruleFired over velocity/pattern.
    const ruleFired = velocityRuleFired ? "VELOCITY_FLIP_AGAINST"
      : "PATTERN_REVERSAL_AGAINST";
    const persistenceCount = velocityRuleFired ? this.thesisVelocityAgainstTicks
      : 1; // pattern read is already a 60s-candle-confirmed signal, not raw tick noise

    this.log("warn",
      `☠️ THESIS_BREAK_EXIT: rule=${ruleFired} persistence=${persistenceCount} · thesis=${status} · ` +
      `side=${trade.side.toUpperCase()} entry=${trade.entryPriceCents}¢ contracts=${trade.contracts} · ` +
      `secsLeft=${secs} unrealized=${perContractPnl.toFixed(1)}¢ · ` +
      `btc=${btcPrice.toFixed(0)} floor=${floorStrike.toFixed(0)} vel=${vel.toFixed(0)}$/min` +
      (patternRuleFired && reversalPattern ? ` · pattern=${reversalPattern.pattern} strength=${reversalPattern.strength.toFixed(2)}` : '')
    );

    trade.exitThesisStatus = status;
    trade.exitThesisReasons = evaluated.reasons.slice();
    trade.exitThesisRuleFired = ruleFired;
    trade.exitTicketGreen = Number.isFinite(currentSidePrice)
      && Number.isFinite(trade.entryPriceCents)
      && currentSidePrice > trade.entryPriceCents;
    trade.exitHoldMs = holdMs;

    this.strikeCrossTicks              = 0;
    this.thesisVelocityAgainstTicks    = 0;
    this.thesisBreakCooldownTicker     = trade.ticker;
    this.thesisBreakCooldownUntil      = Date.now() + 60_000;

    await this.exitEarly("THESIS_BREAK_EXIT", currentSidePrice, priceBreakdown);
    return true;
  }

  /**
   * Single-tick check: does the exchange-led settlement projection currently
   * sit on the wrong side of the floor for `trade.side`? No persistence here
   * — callers that need a confirmed/sustained read (checkLagFlip) track their
   * own counter across calls; callers that just need "is it against right
   * now" (settlement-hold eligibility, add-to-position) use this directly.
   * Missing/stale lag data always returns false — never treated as "against".
   */
  private isLagAgainstSide(
    tradeSide: "yes" | "no", floorStrike: number, vel: number, secs: number,
  ): boolean {
    // 1s projectedSettlement vs floor from BASIS LEAD (estimatedFairBRTI =
    // Coinbase±basis). NOT settlement-pin BRTI — lag meter must stay on this
    // series; swapping onto getFreshBrtiUsd deferred (would change exits mid-session).
    // Missing/stale lag data always returns false — never treated as "against".
    if (basisTracker.isFairValueStale() || this.lastBasisState?.estimatedFairBRTI == null || floorStrike <= 0) {
      return false;
    }
    const live = projectSettlementPrice(this.lastBasisState.estimatedFairBRTI, vel, secs);
    const canon = canonicalLagProjectedSettlement({
      liveProj: live,
      snapshotProj: this.lastBasisState.projectedSettlementPrice,
      floor: floorStrike,
    });
    if (canon.splitBrain || canon.proj == null) return false; // fail-closed
    return projAgainstSide({ tradeSide, projected: canon.proj, floorStrike });
  }

  /**
   * Lag-flip exit — Coinbase lead AND BRTI/proj both against fill.
   * Persistence-gated via shouldLagFlipExit: ≥15s since open AND ≥3 consecutive
   * 1s samples of BOTH lead-against AND BRTI-against (#725). lagProven false → HOLD.
   * Missing/stale lag is never "against". Same priority as thesis-break; shares
   * the 60s same-ticker cooldown.
   */
  private async checkLagFlip(
    trade: OpenTrade, currentSidePrice: number, perContractPnl: number, secs: number,
    vel: number, floorStrike: number, priceBreakdown?: ExitPriceBreakdown,
  ): Promise<boolean> {
    // 1s both-against streak already ticked in tickOpenThesisPersistence this monitor pass.
    const msSinceFill = Date.now() - trade.openedAt;
    const lagProven = this.lastBasisState?.lagProven === true ? true
      : this.lastBasisState?.lagProven === false ? false
      : undefined;
    if (!shouldLagFlipExit({
      consecutiveBothAgainst: this.lagFlipBothAgainstSecStreak,
      msSinceFill,
      lagProven,
    })) return false;

    // Never dump a green coupon / flicker VALID|UNKNOWN via leftover LAG_FLIP.
    // PATH_RIDE: unproven lag cannot authorize LAG_FLIP (correct-side overnight dumps).
    if (isPathRideFlickerBook(trade) && this.lastBasisState?.lagProven !== true) {
      this.log("info",
        `[thesis] LAG_FLIP no-op — lag unproven (PATH_RIDE hold; do not dump correct-side coupon)`
      );
      return false;
    }
    const ticketGreen = Number.isFinite(currentSidePrice)
      && Number.isFinite(trade.entryPriceCents)
      && currentSidePrice > trade.entryPriceCents;
    const ticketAdverseCents = trade.entryPriceCents - currentSidePrice;
    if (ticketGreen || !ticketAdverseThesisBreakOk(ticketAdverseCents)) return false;
    const evaluated = this.evaluateOpenThesis(trade, {
      markCents: currentSidePrice,
      secs,
      vel,
      floorStrike,
    });
    if (evaluated.status !== "BROKEN") {
      trade.exitThesisStatus = evaluated.status;
      trade.exitThesisReasons = evaluated.reasons.slice();
      trade.exitTicketGreen = ticketGreen;
      trade.exitHoldMs = msSinceFill;
      this.log("info",
        `[thesis] LAG_FLIP samples met but thesisStatus=${evaluated.status} ` +
        `reasons=${evaluated.reasons.join(",")} — HOLD (need BROKEN)`
      );
      return false;
    }

    const persistenceCount = this.lagFlipBothAgainstSecStreak;
    this.log("warn",
      `⚡ LAG_FLIP_EXIT: side=${trade.side.toUpperCase()} entry=${trade.entryPriceCents}¢ ` +
      `contracts=${trade.contracts} secsLeft=${secs} unrealizedCents=${perContractPnl.toFixed(1)} ` +
      `persistenceCount=${persistenceCount} (1s both lead+BRTI) floor=${floorStrike.toFixed(0)} · thesis=BROKEN`
    );

    trade.exitThesisStatus = "BROKEN";
    trade.exitThesisReasons = evaluated.reasons.slice();
    trade.exitThesisRuleFired = "LAG_AGAINST_SUSTAINED";
    trade.exitTicketGreen = ticketGreen;
    trade.exitHoldMs = msSinceFill;

    this.basisFlipAgainstTicks     = 0;
    this.lagFlipBothAgainstSecStreak = 0;
    this.lagFlipLastSampleSec = -1;
    this.thesisBreakCooldownTicker = trade.ticker;
    this.thesisBreakCooldownUntil  = Date.now() + 60_000;

    await this.exitEarly("LAG_FLIP_EXIT", currentSidePrice, priceBreakdown);
    return true;
  }

  /**
   * P5 ARIA GUARDIAN (Task #427) — the new deterministic Guardian tier. Builds
   * an AriaContext from state this class already tracks (never invents new
   * inputs), rate-limits real evaluations per ARIA_RATE_LIMIT_SECS (bypassed
   * near the hard stop), and only ever applies an EXIT through the same
   * exitEarly() every other exit path uses. TIGHTEN never widens an existing
   * stop/trail — see its consumption in the stop/trail calc block below,
   * which multiplies by this.ariaGuardianTighten's mult (≤1) on top of the
   * existing agentExit tighten-only overrides, never past entryStopCeiling.
   * Consume-only: never touches EV/PATH_GATE/RICH_ASK/9%/SEV1/size-0/pack
   * membership, never recomputes MarketState/LiquidityPolicy/basisTracker —
   * it only reads their outputs.
   */
  private async checkAriaGuardian(
    trade: OpenTrade, currentSidePrice: number, perContractPnl: number, secs: number,
    vel: number, floorStrike: number, priceBreakdown?: ExitPriceBreakdown,
  ): Promise<boolean> {
    const ms = this.lastMarketState;
    // Fail-closed like every other consumer of this state: no MarketState yet
    // (very early after startup) means no Guardian evaluation this tick —
    // never invent a synthetic "calm" reading.
    if (!ms) return false;

    const distanceToHardStopCents = trade.entryStopCents != null
      ? Math.abs(perContractPnl - (-trade.entryStopCents))
      : null;

    if (!shouldEvaluateAriaGuardian(this.lastAriaGuardianEvalTs, Date.now(), distanceToHardStopCents)) {
      return false; // rate-limited — keep whatever tighten multiplier is already in effect
    }
    this.lastAriaGuardianEvalTs = Date.now();

    // ── Tri-state 1s-projection agreement (NOT Coinbase lag-meter) ──────────
    // Name: projAgreesWithSide. The real lagAgreesWithSide lives in lag-meter.ts
    // and reads BasisState.lagDollars. 1s projectedSettlement flicker is how
    // 1600/1745 dumped winners — never pass this boolean into settlement-side p.
    // estimatedFairBRTI here is BASIS LEAD (not CF BRTI pin); lag path unchanged.
    let projAgreesWithSide: boolean | null = null;
    let projectedSettlement: number | null = null;
    if (!basisTracker.isFairValueStale() && this.lastBasisState?.estimatedFairBRTI != null && floorStrike > 0) {
      const live = projectSettlementPrice(this.lastBasisState.estimatedFairBRTI, vel, secs);
      const canon = canonicalLagProjectedSettlement({
        liveProj: live,
        snapshotProj: this.lastBasisState.projectedSettlementPrice,
        floor: floorStrike,
      });
      if (!canon.splitBrain && canon.proj != null) {
        projectedSettlement = canon.proj;
        projAgreesWithSide = projAgreesWithSideFn({ tradeSide: trade.side, projected: projectedSettlement, floorStrike });
      }
    }

    // ── Book snapshot (same buildBookSnap/evaluateLiquidity already used by
    // entry admission and considerAddingToPosition — consume-only reuse). ──
    const isHourlyTrade = trade.contractDurationMins === 60;
    const ob = isHourlyTrade ? null : kalshiWS.getLatestOrderbook();
    const liqSide: "YES" | "NO" = trade.side === "yes" ? "YES" : "NO";
    let bookClass: BookClass = "BOOK_MISSING";
    let liqAction: LiqAction | null = null;
    let spreadCents: number | null = null;
    let depthAtAsk: number | null = null;
    let imbalance: number | null = null;
    if (!isHourlyTrade) {
      const tickNow = kalshiWS.getLatest();
      const quote = tickNow ? { yesBid: tickNow.yesBid, yesAsk: tickNow.yesAsk, noBid: tickNow.noBid, noAsk: tickNow.noAsk } : {};
      const snap = buildBookSnap({ side: liqSide, currentTicker: trade.ticker, quote, latestOrderbook: ob });
      spreadCents = snap.spreadCents;
      depthAtAsk = snap.depthAtAsk;
      imbalance = snap.imbalance;
      bookClass = snap.noQuote ? "BOOK_MISSING" : snap.bookStale ? "BOOK_STALE" : snap.depthAtAsk === null ? "DEPTH_NULL" : "FULL";
      const liqFamily = getFamilyPolicy(trade.strategyId as StrategyId) ?? "momentum";
      const verdict = evaluateLiquidity({ family: liqFamily, book: snap, volScale: ms.volScale });
      liqAction = verdict.action;
    }
    // Hourly trades have no L2/ask feed to evaluate against — book stays
    // BOOK_MISSING/liqAction null (never fabricated), same fail-closed
    // stance as the rest of this method.

    const ctx: AriaContext = {
      trade: {
        side: trade.side,
        strategyId: trade.strategyId,
        family: getStrategyFamily(trade.strategyId as StrategyId),
        entryAsk: trade.entryPriceCents,
        contracts: trade.contracts,
        floorStrike,
        secsRemaining: secs,
        entryThesis: `${trade.signal} via ${trade.strategyId}`,
      },
      market: {
        velScale: ms.velScale,
        zVel: ms.zVel,
        rangeScale: ms.rangeScale,
        volScale: ms.volScale,
        regime: this.lastAdaptiveCondition?.condition ?? String(ms.regime),
        session: String(ms.session),
        tau: ms.tau,
        stale: ms.stale,
      },
      book: { spreadCents, depthAtAsk, imbalance, liqAction, bookClass },
      lag: { projectedSettlement, rollingBasis: this.lastBasisState?.rollingBasis ?? null, projAgreesWithSide },
      position: {
        unrealizedCents: perContractPnl,
        distanceToHardStopCents,
        thesisBreakTicksRising: this.thesisVelocityAgainstTicks > 0 || this.strikeCrossTicks > 0,
        lagFlipTicks: this.basisFlipAgainstTicks,
        peakUnrealizedCents: this.openTradeMaxGain,
        markCents: currentSidePrice,
      },
      gates: { netEVAtEntry: trade.entryExpectedRewardCents ?? null, primaryBlocker: null },
      secsSinceEntry: Math.max(0, (Date.now() - trade.openedAt) / 1000),
    };

    const decision = parseAriaDecision(evaluateAriaGuardianPolicy(ctx));
    this.lastAriaGuardianDecision = { ...decision, ts: Date.now() };

    // Profit Doctrine Phase 6: one ARIA/TIGHTEN decision-trace row per real
    // (rate-limited-through) Guardian evaluation, reusing the exact rate
    // limit above — never a second, independent throttle. Fire-and-forget
    // (never awaited) so a DB hiccup can't add latency to this tick.
    const traceEvent = (eventType: DecisionTraceEvent["eventType"], applied: boolean): void => {
      void persistDecisionTraceEvent({
        eventType, tradeId: String(trade.dbId ?? trade.openedAt), ticker: trade.ticker, side: trade.side, strategyId: trade.strategyId,
        family: ctx.trade.family, secsLeft: secs,
        market: ctx.market, book: ctx.book, lag: { ...ctx.lag, projAgrees: ctx.lag.projAgreesWithSide ?? undefined },
        gates: ctx.gates,
        aria: { action: decision.action, confidence: decision.confidence, reasons: decision.reasons, applied },
        chain: decision.reasons,
      });
    };

    if (decision.action === "EXIT") {
      const gate = isAriaExitAllowed(ctx, decision, { hardStopImminent: distanceToHardStopCents !== null && distanceToHardStopCents <= ARIA_HARD_STOP_PROXIMITY_CENTS });
      if (gate.allowed) {
        logAriaGuardianDecision({ tradeId: String(trade.dbId ?? trade.openedAt), ticker: trade.ticker, side: trade.side, decision, applied: true, applyReason: gate.reason });
        this.log("warn", `🛡️ ARIA_GUARDIAN_EXIT [${decision.exitCode ?? "ARIA_OTHER"}]: ${decision.reasons.join(", ")} (confidence=${decision.confidence.toFixed(2)})`);
        this.ariaGuardianTighten = null;
        traceEvent("ARIA", true);
        await this.exitEarly(`ARIA_GUARDIAN_${decision.exitCode ?? "ARIA_OTHER"}`, currentSidePrice, priceBreakdown);
        return true;
      }
      logAriaGuardianDecision({ tradeId: String(trade.dbId ?? trade.openedAt), ticker: trade.ticker, side: trade.side, decision, applied: false, applyReason: gate.reason });
      this.ariaGuardianTighten = null;
      traceEvent("ARIA", false);
      return false;
    }

    if (decision.action === "TIGHTEN") {
      this.ariaGuardianTighten = clampTighten(decision.tighten) ?? null;
      logAriaGuardianDecision({ tradeId: String(trade.dbId ?? trade.openedAt), ticker: trade.ticker, side: trade.side, decision, applied: !!this.ariaGuardianTighten, applyReason: "TIGHTEN_APPLIED" });
      traceEvent("TIGHTEN", !!this.ariaGuardianTighten);
      return false;
    }

    // SETTLE_HOLD: applied (no longer log-only). Same flag settlement-hold uses.
    // Hard stop already ran above Guardian in monitorOpenTrade — we never
    // suppress it. Cheap-side / OTM never SETTLE_HOLD (sell-before-expiry).
    if (decision.action === "SETTLE_HOLD") {
      if (isHoldToSettlementExempt(trade)) {
        this.ariaGuardianTighten = null;
        logAriaGuardianDecision({ tradeId: String(trade.dbId ?? trade.openedAt), ticker: trade.ticker, side: trade.side, decision, applied: false, applyReason: "CHEAP_SIDE_NO_SETTLE_HOLD" });
        traceEvent("ARIA", false);
        return false;
      }
      this.settlementHoldActive = true;
      this.ariaGuardianTighten = null;
      logAriaGuardianDecision({ tradeId: String(trade.dbId ?? trade.openedAt), ticker: trade.ticker, side: trade.side, decision, applied: true, applyReason: "SETTLE_HOLD_LOCKED_ITM" });
      this.log("info",
        `🏁 ARIA_GUARDIAN_SETTLE_HOLD [${decision.reasons.join(",")}]: ` +
        `confidence=${decision.confidence.toFixed(2)} mark=${currentSidePrice}¢ — ` +
        `suppressing trailing this tick (hard stop remains unconditional)`
      );
      traceEvent("ARIA", true);
      return true; // suppress trailing/time-stop this tick; do not exit
    }

    // HOLD: log-only. Clear any prior tighten since the evidence that
    // produced it is no longer present (re-derived fresh each real eval, not
    // ratcheted forever).
    this.ariaGuardianTighten = null;
    logAriaGuardianDecision({ tradeId: String(trade.dbId ?? trade.openedAt), ticker: trade.ticker, side: trade.side, decision, applied: false, applyReason: "NO_ACTION" });
    traceEvent("ARIA", false);
    return false;
  }

  private async monitorOpenTrade() {
    if (!this.openTrade) return;
    // Advance the observation timestamp so the watchdog doesn't mistake an
    // active in-trade monitoring loop for a frozen tick (lastObsTs only
    // advances in evaluateEntry, so any trade > BOT_FROZEN_MS triggers heals).
    this.lastObsTs = Date.now();
    const trade = this.openTrade;
    // Hourly trades must be marked against the HOURLY market's book and strike,
    // not the 15-minute feed — the 15M contract is a different market entirely.
    const isHourlyTrade = trade.contractDurationMins === 60;
    type OpenTradeMark = {
      yesBid: number;
      noBid: number;
      floorStrike: number;
      yesPrice?: number;
      yesAsk?: number;
      quoteTs?: number;
    };
    const tick: OpenTradeMark | null = isHourlyTrade
      ? (() => {
          const h = hourlyPoller.getLatest();
          return h ? { yesBid: h.yesBid, noBid: h.noBid, floorStrike: trade.floorStrike } : null;
        })()
      : kalshiWS.getLatest();
    if (!tick) return;

    // SEV0 (sweep S1): never exit-evaluate a 15m trade against another market's
    // quote, and never "exit" after its contract closed (the WS rolls to the
    // next ticker at close). After close the only valid path is settlement.
    if (!isHourlyTrade) {
      const verdict = exitQuoteGuard({
        tradeTicker: trade.ticker,
        tradeCloseMs: resolveTradeCloseMs(trade),
        quoteTicker: (tick as { ticker?: string }).ticker ?? null,
        nowMs: Date.now(),
      });
      if (!verdict.ok) {
        if (verdict.reason === "AFTER_CLOSE") {
          if (Date.now() - this.lastPostCloseSettleNudgeMs >= 5_000) {
            this.lastPostCloseSettleNudgeMs = Date.now();
            void this.detectSettlement();
          }
        } else if (!this.exitQuoteMismatchLogged) {
          this.log("warn", `[EXIT_QUOTE_GUARD] ${verdict.reason}: open ${trade.ticker} vs quote ${(tick as { ticker?: string }).ticker ?? "?"} — exit checks skipped`);
          this.exitQuoteMismatchLogged = true;
        }
        return;
      }
      this.exitQuoteMismatchLogged = false;
    }

    // ── STALE-QUOTE EXIT GUARD (Task, 2026-08-19, SEV2) ───────────────────────
    // 15m trades only — hourly's tick above is a REST-polled snapshot with no
    // quoteTs/WS-heartbeat concept to be stale against. A WS heartbeat re-stamps
    // `ts` on every message while carrying the SAME bid/ask forward during a
    // book outage; `tick.ts` alone would look perfectly fresh. Every reduce/
    // exit/hold decision below this point (hard stop, thesis-break, lag-flip,
    // hold-to-settlement's profit-lock/hard-floor) shares this one check, so a
    // stale quote can't reach any of them through a separate path — this
    // deliberately matches the entry gate's isFeedStaleForEntry() intent ("same
    // feed, same answer to how-old-is-too-old") rather than giving exits their
    // own, possibly looser, threshold. We do NOT invent a price when stale:
    // skip this tick's exit checks entirely and re-evaluate next tick, exactly
    // like the invalid-quote guard just below.
    if (!isHourlyTrade) {
      const exitQuoteAgeMs = Date.now() - (tick.quoteTs ?? 0);
      if (isQuoteStaleForExit(exitQuoteAgeMs)) {
        if (!this.staleQuoteExitLogged) {
          this.log("warn",
            `[STALE_QUOTE_EXIT_BLOCKED] Quote unchanged for ${(exitQuoteAgeMs / 1000).toFixed(1)}s ` +
            `(heartbeat-only, no real book update) for open ${trade.side.toUpperCase()} trade — ` +
            `blocking reduce/exit this tick, will re-evaluate next tick.`);
          this.staleQuoteExitLogged = true;
        }
        return;
      }
      this.staleQuoteExitLogged = false;
    }

    // Use the BID for exit evaluation — this is what a sell order actually receives.
    // Using the mid (yesPrice) overstates exit proceeds; the bid is the real fill price.
    const currentSidePrice = trade.side === "yes" ? tick.yesBid : tick.noBid;

    // Degenerate/no-bid tick guard (mirrors exitEarly's Task #221 (0,100) exit-price
    // guard, but applied BEFORE any decision logic runs, not just at order placement).
    // Without this, a transient WS glitch or empty order book (bid 0, or a stale
    // >=100 tick) fed straight into checkHardStop's marketLossPct math looks like an
    // instant ~100% loss and fires a HARD_STOP_EXIT decision — exitEarly's own guard
    // does stop the order from actually placing at that bogus price, but every other
    // decision this tick (thesis-break, time-stop, add-to-position, HOLD_HARD_FLOOR's
    // tick counter) still ran against the same invalid quote. Skip the whole
    // monitoring tick instead so nothing downstream sees a fabricated price.
    if (!(currentSidePrice > 0 && currentSidePrice < 100)) {
      if (!this.invalidQuoteLogged) {
        this.log("warn",
          `[monitor] Invalid/no-bid quote (${currentSidePrice}¢) for open ${trade.side.toUpperCase()} trade — ` +
          `skipping this tick's exit checks, will re-evaluate next tick.`);
        this.invalidQuoteLogged = true;
      }
      return;
    }
    this.invalidQuoteLogged = false;

    // ── Theoretical binary option price ────────────────────────────────────────
    // Kalshi market prices can lag 5–15¢ vs fair value when liquidity is thin.
    // We compute the theoretical N(d₁) binary price and blend it 60/40 with the
    // market price for stop/profit decisions. Falls back to market price alone if
    // we don't have enough BTC price history to estimate vol.
    const btcPrice    = this.prices.length > 0 ? this.prices[this.prices.length - 1].price : 0;
    // Trade-log chart: sample BTC (and yes mid when cheap) while IN_TRADE.
    if (btcPrice > 0 && this.openTrade) {
      const yesMid =
        typeof tick.yesPrice === "number"
          ? tick.yesPrice
          : (typeof tick.yesBid === "number" && typeof tick.yesAsk === "number"
            ? (tick.yesBid + tick.yesAsk) / 2
            : undefined);
      this.openTrade.chartPoints = appendOpenTradeChartPoint(this.openTrade.chartPoints, {
        t: Date.now(),
        btc: btcPrice,
        yesMid,
      });
    }
    const annualVol   = realizedVolFromBuffer(this.prices);
    const minsLeft    = tradeSecsRemaining(trade) / 60;

    // ── Buffer staleness guard ─────────────────────────────────────────────────
    // If the most recent BTC price tick is older than 30 s (e.g. Kalshi WS
    // failures) the realized-vol estimate may be misleading. Force a market-only
    // fallback and log once per trade so the deviation is visible in the bot log.
    const lastTickAgeMs = this.prices.length > 0
      ? Date.now() - this.prices[this.prices.length - 1].ts
      : Infinity;
    const bufferStale = lastTickAgeMs > 30_000;
    if (bufferStale && !this.volStaleFallbackLogged) {
      this.log("warn",
        `[monitor] Vol buffer stale (last tick ${(lastTickAgeMs / 1000).toFixed(1)}s ago) — ` +
        `falling back to market price for exit decisions`
      );
      this.volStaleFallbackLogged = true;
    }

    const hasVolData  = !bufferStale && btcPrice > 0 && tick.floorStrike > 0 && annualVol > 0 && this.prices.length >= 4;

    // evalSidePrice — blended price used ONLY for settlement-hold EV comparison,
    // where theoretical guidance about true win probability is genuinely valuable.
    // All exit P&L decisions use raw currentSidePrice so they fire on real executable
    // prices, not model conviction: the theory can swing 1↔99 intra-period while the
    // market maintains uncertainty, causing premature stops AND premature profit-takes
    // when 60% weight is applied to a model that has already reached conviction.
    let evalSidePrice: number;
    let priceBreakdown: ExitPriceBreakdown | undefined;
    if (hasVolData) {
      // Live theo: binaryCallFairValueCents (N(d2), no Math.max(1) invent) + [10,90] sanitize.
      // Out-of-band / null → market-only blend (never stamp 1¢ garbage into exitBreakdown).
      const theorYesFair = binaryCallFairValueCents(
        btcPrice, tick.floorStrike, Math.max(0, minsLeft * 60), annualVol,
      );
      const theorSideFair = trade.side === "yes"
        ? theorYesFair
        : complementaryFairValueCents(theorYesFair);
      const theoBelt = sanitizeTheoCents(theorSideFair);
      if (theoBelt.theoCents != null && theorSideFair != null) {
        const theorSidePrice = theorSideFair;
        evalSidePrice = theorSidePrice * 0.6 + currentSidePrice * 0.4;
        priceBreakdown = {
          theo:    Math.round(theorSidePrice * 10) / 10,
          mkt:     Math.round(currentSidePrice * 10) / 10,
          blend:   Math.round(evalSidePrice    * 10) / 10,
          theoLed: Math.abs(theorSidePrice - currentSidePrice) >= 3,
        };
      } else {
        evalSidePrice = currentSidePrice;
      }
    } else {
      evalSidePrice = currentSidePrice;
    }

    // SEV2 fix (2026-08-19): settlement-hold's win-probability used to reuse
    // `this.lastModelProb` — a field ONLY written inside evaluateEntry(),
    // which tick() never calls while `this.openTrade` is set (see tick():
    // in-trade ticks call monitorOpenTrade() and return before reaching
    // evaluateEntry()). So every settlement-hold eligibility check for the
    // life of a trade re-used the single probability snapshot from the
    // moment BEFORE entry — a genuine price/vol move minutes into a hold
    // (the exact window this feature engages in) was invisible to it. This
    // recomputes from the SAME model (probabilityEdge) and the SAME live
    // inputs monitorOpenTrade already derived just above (btcPrice, annualVol,
    // minsLeft) — identical math to evaluateEntry(), just re-run against
    // current data instead of stale entry-time data. Deliberately does NOT
    // overwrite `this.lastModelProb` itself (BotStatus/UI consumers of that
    // field expect "model view at last entry evaluation", not a live value).
    // Falls back to the stale entry-time value only when hasVolData is false
    // (buffer stale / no floor strike / <4 samples) — same fail-closed
    // philosophy as evalSidePrice's own hasVolData branch just above: don't
    // invent a fresher-looking number from data too thin to trust.
    // In-hold p = winRateAtPrice at the live traded-side ask, never N(d2).
    const holdAsk = trade.side === "yes"
      ? (tick as { yesAsk?: number }).yesAsk
      : (tick as { noAsk?: number }).noAsk;
    const liveAsk = typeof holdAsk === "number" && Number.isFinite(holdAsk)
      ? holdAsk
      : currentSidePrice;
    const wrLiveCurve = pForStrategyAtAsk(trade.strategyId, liveAsk, minsLeft);
    const wrLiveSample = trade.strategyId ? getLearnerPathWinRateSample(trade.strategyId) : { n: 0, winRate: 0 };
    const wrLive = pathPWinFromCurveOrLearner({
      curveP: wrLiveCurve,
      learnerWR: wrLiveSample.winRate,
      learnerN: wrLiveSample.n,
      paperMode: this.config.paperMode === true,
      realBotSettlesN: trade.strategyId ? getLiveTradeStatsSync(trade.strategyId, 15).n : 0,
    });
    const liveModelProb = fillPathPWin(wrLive)
      ?? fillPathPWin(trade.strategyWinRateAtEntry)
      ?? this.lastModelProb;
    this.liveModelProb = liveModelProb;

    // Store the live breakdown so the UI can show theo/mkt/blend while trade is open
    this.livePriceBreakdown = priceBreakdown ?? null;

    // perContractPnl uses raw market price — NOT the blended price.
    // Using the blend for P&L caused stops and profit-takes to fire on model
    // conviction alone: a 1¢ theoretical price × 0.6 weight could trigger a
    // 60%+ "loss" while the actual exit price hadn't moved at all.
    const perContractPnl   = currentSidePrice - trade.entryPriceCents;
    this.openTradePnlCents = perContractPnl;

    // Track peak gain for trailing stop
    if (perContractPnl > this.openTradeMaxGain) {
      this.openTradeMaxGain   = perContractPnl;
      trade.maxGainCents      = perContractPnl;
    }

    const secs          = tradeSecsRemaining(trade);
    const { isStalling: stalling } = detectStallInfo(this.prices);
    const vel           = this.currentVelocity;

    const tickSource = (tick as { source?: "ws" | "rest" }).source ?? "ws";
    const tickAsk = trade.side === "yes"
      ? (tick as { yesAsk?: number }).yesAsk
      : (tick as { noAsk?: number }).noAsk;
    // Persist lag/floor samples even when PATH_RIDE never reaches checkLagFlip.
    this.tickOpenThesisPersistence(trade, btcPrice, tick.floorStrike, vel, secs);
    const openThesis = this.evaluateOpenThesis(trade, {
      markCents: currentSidePrice,
      askCents: tickAsk,
      quoteSource: tickSource,
      // D9 — timestamp-stale quotes returned above; this adds WS-vs-L2 value lag.
      quoteStale: liveQuoteValueLag().stale,
      secs,
      vel,
      floorStrike: tick.floorStrike,
    });
    // Story wire: last-seen thesis / ticket green / hold (settlement + non-PATH exits).
    // PATH_RIDE block below overwrites with the same values decideExit saw.
    trade.exitThesisStatus = openThesis.status;
    trade.exitThesisReasons = openThesis.reasons.slice();
    trade.exitTicketGreen = Number.isFinite(currentSidePrice)
      && Number.isFinite(trade.entryPriceCents)
      && currentSidePrice > trade.entryPriceCents;
    trade.exitHoldMs = Date.now() - trade.openedAt;

    // ── PATH_RIDE (CC/LAG/HA_* tagged fills): decidePathRideExit is the only
    // SELL / HOLD_TRAIL / HOLD_SETTLE. Isolated in organs/exit.ts
    // (pathRideMonitorDisposition). Not cheapEarlyExitEnabled. TIMING_CLOCK_LIVE
    // stays false. Do not default hold-to-settle.
    // HOLD_TRAIL: do not also TB / leftover FAST_REVERSAL / HARD_STOP.
    // Catastrophic ≤5¢ is sustained ≥20s inside decidePathRideExit (not first-tick).
    if (isPathRideOpenTrade(trade)) {
      const strongReversal = (trade.side === "yes" && vel < -120) ||
                             (trade.side === "no"  && vel >  120);
      if (strongReversal) this.fastReversalTicks++;
      else this.fastReversalTicks = 0;
      const ohlc1m = getMtfOhlcBars(1)?.bars ?? null;
      const ohlc5m = getMtfOhlcBars(5)?.bars ?? null;
      const ha1m = haFromRaw(ohlc1m);
      const ha5m = haFromRaw(ohlc5m);
      const haOk = ha1m != null && ha5m != null;
      const remainingVol = remainingVolDollars(ohlc1m, secs);
      const volHonest = remainingVol != null && remainingVol > 0;
      const fat = distanceIsFat({
        spot: btcPrice,
        floor: tick.floorStrike,
        secsRemaining: secs,
        remainingVol,
      });
      const wantColor = trade.side === "yes" ? "green" : "red";
      const riverAgrees = haOk
        && ha1m![ha1m!.length - 1]!.color === wantColor
        && ha5m![ha5m!.length - 1]!.color === wantColor;
      const last1mRange = last1mRangeDollars(ohlc1m);
      const strikePin = isStrikePin({
        ohlc1m,
        floor: tick.floorStrike,
        ha1m,
        ha5m,
        haOk,
      });
      const gammaGetout = isGammaGetout({
        secsRemaining: secs,
        spot: btcPrice,
        floor: tick.floorStrike,
        last1mRange,
        markCents: currentSidePrice,
        entryCents: trade.entryPriceCents,
      });
      const ageMs = Date.now() - trade.openedAt;
      const ticketGreen = Number.isFinite(currentSidePrice)
        && Number.isFinite(trade.entryPriceCents)
        && currentSidePrice > trade.entryPriceCents;
      const riverValid = haOk === true && riverAgrees === true;
      // PATH_RIDE hard-stop demotes BROKEN before 15s so leftover TB cannot race HOLD.
      const thesisStatus = ageMs < THESIS_BREAK_MIN_HOLD_MS && openThesis.status === "BROKEN" ? "UNKNOWN" : openThesis.status;
      const lagFlip = openThesis.reasons.includes("LAG_AGAINST_SUSTAINED");
      const thesisBreak = thesisStatus === "BROKEN";
      // Persistence clock: start once, do not reset every tick while still broken.
      // Empty/UNKNOWN thesis is not river death.
      const brokenNow = (thesisBreak || lagFlip) && riverValid === false && !(ticketGreen && riverValid);
      const nowMs = Date.now();
      if (brokenNow) {
        if (this.pathRideBrokenSinceMs == null) this.pathRideBrokenSinceMs = nowMs;
        this.pathRideBrokenTicks += 1;
      } else {
        this.pathRideBrokenSinceMs = null;
        this.pathRideBrokenTicks = 0;
      }
      const brokenPersistedMs = this.pathRideBrokenSinceMs != null
        ? nowMs - this.pathRideBrokenSinceMs
        : 0;
      const fuseOk = !ticketGreen && !riverValid;
      // Sustained ≤5¢ clock BEFORE decideExit so PATH_RIDE_CATASTROPHIC cannot
      // fire on a single tick (frozen DEFER used to fall through to instant cat).
      const pathCatCents = PATH_RIDE_CATASTROPHIC_CENTS;
      if (Number.isFinite(currentSidePrice) && currentSidePrice <= pathCatCents) {
        if (this.frozenCatastrophicBelowSinceMs == null) {
          this.frozenCatastrophicBelowSinceMs = nowMs;
        }
      } else {
        if (this.frozenCatastrophicBelowSinceMs != null) {
          const belowMsRecovered = nowMs - this.frozenCatastrophicBelowSinceMs;
          if (belowMsRecovered > 0 && belowMsRecovered < PATH_RIDE_CATASTROPHIC_SUSTAIN_MS) {
            try {
              recordWickSurvived5cUnder20s({
                ticker: trade.ticker,
                side: trade.side,
                markCents: currentSidePrice,
                belowMs: belowMsRecovered,
                entryCents: trade.entryPriceCents,
              });
            } catch { /* sit-WATCH observe */ }
          }
        }
        this.frozenCatastrophicBelowSinceMs = null;
      }
      const catastrophicBelowMs = this.frozenCatastrophicBelowSinceMs != null
        ? nowMs - this.frozenCatastrophicBelowSinceMs
        : 0;
      const ride = decideExit({
        strategyId: trade.strategyId,
        side: trade.side,
        entryCents: trade.entryPriceCents,
        markCents: currentSidePrice,
        entryAsk: trade.entryPriceCents,
        markAsk: currentSidePrice,
        holdMs: ageMs,
        ageMs,
        secsRemaining: secs,
        ha1m,
        ha5m,
        haOk,
        riverAgrees,
        riverValid,
        ticketGreen,
        thesisStatus,
        thesisBreak,
        lagFlip,
        lagProven: this.lastBasisState?.lagProven === true,
        brokenPersistedMs,
        thesisBreakTicks: this.pathRideBrokenTicks,
        tickMs: TICK_IDLE_INTERVAL_MS,
        fuseOk,
        volHonest,
        remainingVol,
        distanceFat: fat,
        fastReversalReady: this.fastReversalTicks >= 2,
        contracts: trade.contracts,
        halfRideTaken: trade.halfRideTaken === true,
        strikePin,
        gammaGetout,
        floor: tick.floorStrike,
        brtiSpot: btcPrice,
        peakUnrealizedCents: this.openTradeMaxGain,
        catastrophicBelowMs,
        catastrophicSustainMs: PATH_RIDE_CATASTROPHIC_SUSTAIN_MS,
      });
      // Same values decideExit saw — persistSettledBotStory must not fake these.
      trade.exitThesisStatus = thesisStatus;
      trade.exitThesisReasons = openThesis.reasons.slice();
      trade.exitRiverValid = riverValid;
      trade.exitTicketGreen = ticketGreen;
      trade.exitHoldMs = ageMs;
      // B) STRUCTURAL_RUIN_SHADOW — observe-only; never exitEarly / SELL.
      const shadowResult = evaluateStructuralRuinShadow({
        markCents: currentSidePrice,
        catastrophicBelowMs,
        floorCross: openThesis.reasons.includes("FLOOR_CROSS_EVIDENCE")
          || this.strikeCrossTicks >= 20,
        riverValid,
        lagProven: this.lastBasisState?.lagProven === true ? true
          : this.lastBasisState?.lagProven === false ? false
          : null,
        thesisReasons: openThesis.reasons,
      });
      recordStructuralRuinShadowObservation(
        this.structuralRuinShadowCounters,
        shadowResult,
        nowMs,
      );
      const shadowStamp = toStructuralRuinShadowStamp(shadowResult);
      this.lastStructuralRuinShadow = shadowStamp;
      trade.structuralRuinShadow = shadowStamp;
      if (shadowResult.wouldSell) {
        this.log("info",
          `[shadow] STRUCTURAL_RUIN_SHADOW wouldSell observeOnly ` +
          `mark=${currentSidePrice.toFixed(0)}¢ belowMs=${catastrophicBelowMs} ` +
          `reasons=${shadowResult.reasons.join(",")}`,
        );
      }
      // Brain stamp: firstMatchStep + feeNetTpOk + thesisReasons (observability; does not change law).
      const stampedRide = withExitMonitorFields(ride, {
        entryCents: trade.entryPriceCents,
        markCents: currentSidePrice,
        contracts: trade.contracts,
        thesisStatus,
        thesisReasons: openThesis.reasons,
        secsRemaining: secs,
        structuralRuinShadow: shadowStamp,
      });
      if (stampedRide) {
        trade.exitFirstMatchStep = stampedRide.firstMatchStep ?? null;
        trade.exitFeeNetTpOk = stampedRide.feeNetTpOk ?? null;
        this.lastExitMonitorStamp = {
          kind: "exit",
          book: "PATH_RIDE",
          action: stampedRide.reason,
          thesisStatus,
          thesisReasons: openThesis.reasons.slice(),
          feeNetTpOk: stampedRide.feeNetTpOk === true,
          firstMatchStep: stampedRide.firstMatchStep ?? null,
          structuralRuinShadow: shadowStamp,
        };
      }
      // Log-only exit classification (does not change PATH_RIDE disposition).
      void classifyExitDecision(ride);
      const disp = pathRideMonitorDisposition(ride, currentSidePrice);

      // ── FROZEN_CC money-machine exit (C-money ask 20–55) ──
      // Real PATH_RIDE owns green TP / soft giveback / thesis. Catastrophic is a
      // sustained ≤N¢ failsafe only (clock updated above before decideExit).
      if (trade.frozenCc === true || this.config.frozenCcMode === true) {
        const catCents = this.config.frozenCcCatastrophicCents ?? FROZEN_CC_DEFAULT_CATASTROPHIC_CENTS;
        const frozenExit = decideFrozenCcExit({
          entryCents: trade.entryPriceCents,
          markCents: currentSidePrice,
          secsRemaining: secs,
          catastrophicCents: catCents,
          takeProfitCents: this.config.frozenCcTakeProfitCents ?? null,
          shadowRideKind: disp.kind,
          shadowRideReason: disp.kind === "SELL" ? disp.reason : null,
          moneyMachinePathRide: true,
          catastrophicBelowMs,
          catastrophicSustainMs: FROZEN_CC_CATASTROPHIC_SUSTAIN_MS,
        });
        if (frozenExit.action === "SELL") {
          trade.exitThesisRuleFired = frozenExit.reason;
          this.log("info",
            `🧊 [FROZEN_CC] exit ${frozenExit.reason}: ${trade.side.toUpperCase()} entry=${trade.entryPriceCents}¢ ` +
            `mark=${currentSidePrice.toFixed(0)}¢ holdMs=${ageMs}` +
            (frozenExit.reason === "PATH_RIDE_CATASTROPHIC"
              ? ` sustainedBelowMs=${catastrophicBelowMs}`
              : ""));
          if (frozenExit.reason === "PATH_RIDE_CATASTROPHIC") {
            try {
              recordCatastrophicExit({
                ticker: trade.ticker,
                side: trade.side,
                markCents: currentSidePrice,
                belowMs: catastrophicBelowMs,
                entryCents: trade.entryPriceCents,
              });
            } catch { /* sit-WATCH observe */ }
          }
          this.frozenCatastrophicBelowSinceMs = null;
          await this.exitEarly(frozenExit.reason, currentSidePrice, priceBreakdown);
          return;
        }
        if (frozenExit.action === "HOLD") {
          if (frozenExit.shadowWouldSell && trade.frozenShadowExitWouldSell == null) {
            trade.frozenShadowExitWouldSell = frozenExit.shadowWouldSell;
            trade.frozenShadowExitFirstAtMs = ageMs;
            // Attack F3: money-machine PATH_RIDE / holdToSettlement OFF must not
            // claim settlement-hold speech. Unsustained cat → FROZEN_CAT_WAIT.
            const holdSpeech =
              frozenExit.shadowWouldSell === "PATH_RIDE_CATASTROPHIC"
                ? "FROZEN_CAT_WAIT"
                : "HOLD_TRAIL";
            this.log("info",
              `🧊 [FROZEN_CC] shadow exit ${frozenExit.shadowWouldSell} at +${Math.round(ageMs / 1000)}s ` +
              `mark=${currentSidePrice.toFixed(0)}¢ entry=${trade.entryPriceCents}¢ — ${holdSpeech}`);
          }
          return;
        }
        // DEFER_PATH_RIDE: fall through to real PATH_RIDE SELL / HOLD_SETTLE / HOLD_TRAIL.
        // Never re-admit unsustained PATH_RIDE_CATASTROPHIC on the same tick.
        if (
          disp.kind === "SELL"
          && disp.reason === "PATH_RIDE_CATASTROPHIC"
          && catastrophicBelowMs < FROZEN_CC_CATASTROPHIC_SUSTAIN_MS
        ) {
          this.log("info",
            `🧊 [FROZEN_CC] DEFER blocked unsustained cat mark=${currentSidePrice.toFixed(0)}¢ ` +
            `belowMs=${catastrophicBelowMs} — HOLD`);
          return;
        }
        if (disp.kind === "SELL" && trade.frozenShadowExitWouldSell == null) {
          // Record first PATH_RIDE signal for ledger CF even when we take it live.
          trade.frozenShadowExitWouldSell = disp.reason;
          trade.frozenShadowExitFirstAtMs = ageMs;
        }
      }

      // HALF_RIDE killed (#725): decidePathRideExit no longer returns SELL_PARTIAL.
      // If a stale disposition still claims HALF_RIDE, HOLD — do not fake a partial.
      if (disp.kind === "SELL_PARTIAL" && disp.reason === "HALF_RIDE") {
        this.log("info",
          `PATH_RIDE HALF_RIDE ignored (no live half-sell): ${trade.side.toUpperCase()} ` +
          `entry=${trade.entryPriceCents}¢ mark=${currentSidePrice.toFixed(0)}¢ — HOLD until PATH_RIDE_TP / giveback`
        );
        return;
      }
      if (disp.kind === "SELL") {
        if (disp.reason === "FAST_REVERSAL") {
          this.fastReversalTicks = 0;
          this.structureFailTicks = 0;
        }
        // Story honesty: stamp ruleFired for TB/LAG/HA_FLIP (persistSettledBotStory).
        if (disp.reason === "THESIS_BREAK") trade.exitThesisRuleFired = "THESIS_BREAK";
        else if (disp.reason === "LAG_FLIP") trade.exitThesisRuleFired = "LAG_AGAINST_SUSTAINED";
        else if (disp.reason === "PATH_RIDE_HA_FLIP") trade.exitThesisRuleFired = "PATH_RIDE_HA_FLIP";
        else if (disp.reason === "PATH_RIDE_90S_FUSE") trade.exitThesisRuleFired = "PATH_RIDE_90S_FUSE";
        else trade.exitThesisRuleFired = disp.reason;
        this.log("info",
          `PATH_RIDE exit ${disp.reason}: ${trade.side.toUpperCase()} entry=${trade.entryPriceCents}¢ ` +
          `mark=${currentSidePrice.toFixed(0)}¢ holdMs=${Date.now() - trade.openedAt} ` +
          `thesis=${thesisStatus} plus50=${pathRidePlus50TargetCents(trade.entryPriceCents)} twoX=${pathRideTwoXTargetCents(trade.entryPriceCents)}`
        );
        await this.exitEarly(disp.reason, currentSidePrice, priceBreakdown);
        return;
      }
      if (disp.kind === "HOLD_SETTLE") {
        this.log("info",
          `PATH_RIDE hold-to-settle (last 2m + HA river + fat remaining vol): mark=${currentSidePrice.toFixed(0)}¢ secs=${secs}`
        );
        return;
      }
      return; // HOLD_TRAIL: no leftover checkThesisBreak / FAST_REVERSAL / HARD_STOP
    }

    // Leftover TB/ARIA/hold/trail — denied on paper/frozen; PATH_RIDE is sole booked exit.
    void leftoverExitStackMayRunOnPathRide(); // always false
    if (!leftoverExitStackMayRun(this.config)) {
      this.log("info", "[frozen-cc] leftover exit stack skipped — PATH_RIDE only");
      return;
    }
    await leftoverExitStackRun(this.config, () => leftoverExitStackFunnel.call(this, {
      trade,
      currentSidePrice,
      perContractPnl,
      secs,
      vel,
      btcPrice,
      tick,
      priceBreakdown,
      openThesis,
      stalling,
      liveModelProb: this.liveModelProb,
      evalSidePrice: currentSidePrice,
      isHoldToSettlementExempt: (t: any) => isHoldToSettlementExempt(t),
      computeNormalTargetProfitCents: (...args: any[]) => (this as any).computeNormalTargetProfitCents?.(...args) ?? 0,
      preserveEntryTargetFloor: (...args: any[]) => (this as any).preserveEntryTargetFloor?.(...args) ?? 0,
      shouldEnforceNormalTradeStop: (opts: any) => (this as any).shouldEnforceNormalTradeStop?.(opts) ?? false,
      evaluateStopLossDecision: (params: any) => (this as any).evaluateStopLossDecision?.(params) ?? null,
    }));
    return;
  }

  // ── Early exit (stop-loss or profit-take) ─────────────────────────────────────

  // Public manual-exit entry point for the Oracle Agent's `force_exit_trade`
  // tool (and any future "emergency exit" UI control). Previously that tool
  // called stop()+start(), which neither of those methods actually clears
  // `openTrade` for — the position silently stayed open in memory while the
  // tool told the operator "force-exited". This reuses the same tick lookup
  // and exitEarly() accounting path as every automatic stop/profit exit, so
  // paper balance and the trade record are updated correctly.
  async forceExitOpenTrade(reason = "MANUAL_FORCE_EXIT"): Promise<{ ok: boolean; exitPriceCents?: number; error?: string }> {
    if (!this.openTrade) return { ok: false, error: "No open trade" };
    const trade = this.openTrade;
    const isHourlyTrade = trade.contractDurationMins === 60;
    const tick = isHourlyTrade
      ? (() => {
          const h = hourlyPoller.getLatest();
          return h ? { yesBid: h.yesBid, noBid: h.noBid } : null;
        })()
      : kalshiWS.getLatest();
    if (!tick) return { ok: false, error: "No live quote available to price the exit" };
    const currentSidePrice = trade.side === "yes" ? tick.yesBid : tick.noBid;
    if (!(currentSidePrice > 0)) return { ok: false, error: "No executable quote to exit against" };
    await this.exitEarly(reason, currentSidePrice);
    return { ok: true, exitPriceCents: currentSidePrice };
  }

  /** Operator snapshot for GET /api/bot/agent/status — no LLM. */
  getAgentControlSnapshot(): Record<string, unknown> {
    const status = this.getStatus();
    if (this.pendingAgentEntry && isPendingExpired(this.pendingAgentEntry)) {
      this.pendingAgentEntry = null;
    }
    return {
      config: {
        agentControlMode: this.config.agentControlMode === true,
        requireAgentEntryApproval: this.config.requireAgentEntryApproval === true,
        brainCenterAuthority: this.config.brainCenterAuthority === true,
        autopilotMode: this.config.autopilotMode === true,
        paperMode: this.config.paperMode === true,
        enabled: this.config.enabled === true,
        frozenCcMode: this.config.frozenCcMode === true,
        frozenCcAndSit: this.config.frozenCcAndSit === true,
        holdToSettlement: this.config.holdToSettlement === true,
        autoMode: this.config.autoMode === true,
        useDrawdownGuard: this.config.useDrawdownGuard === true,
        strategyOverride: this.config.strategyOverride,
        minEntryPrice: this.config.minEntryPrice,
        maxEntryPrice: this.config.maxEntryPrice,
        reservePct: this.config.reservePct,
      },
      state: this.state,
      openTrade: status.openTrade,
      brainCenter: status.brainCenter ?? null,
      brainMind: (status as { brainMind?: unknown }).brainMind
        ?? brainMindPulse(status.brainCenter ?? null),
      pendingAgentEntry: this.pendingAgentEntry,
      directives: this.agentDirectives,
      lastSignal: status.lastSignal,
      autopilot: this.config.autopilotMode === true,
      decisionKind: status.decisionKind ?? null,
      lastAutopilotDecision: status.lastAutopilotDecision ?? null,
      floors: AGENT_FLOORS,
      lastSelfHeal: this.lastSelfHeal,
      doctrine: "Chat agent=operator; bot=executor; no LLM on fill hot path; autopilot=YES/NO/SKIP unattended",
    };
  }

  applyAgentDirective(directive: AgentDirective): DirectiveState {
    this.agentDirectives = applyDirectiveToState(this.agentDirectives, directive);
    if (directive.type === "HALT_ENTRIES") {
      this.haltArmedAtMs = Date.now();
    } else if (directive.type === "RESUME_ENTRIES") {
      this.haltArmedAtMs = null;
    }
    this.log("info", `agent directive ${directive.type} id=${directive.id}`);
    return { ...this.agentDirectives };
  }

  /** Clear HALT_ENTRIES / SKIP_NEXT / SIT sticky directives (autopilot arm / RESUME). */
  clearAgentHaltDirectives(reason = "clear"): DirectiveState {
    this.agentDirectives = emptyDirectiveState();
    this.haltArmedAtMs = null;
    this.log("info", `agent directives cleared (${reason})`);
    return { ...this.agentDirectives };
  }

  /**
   * Arm built-in paper autopilot: best settings + start + clear halt.
   * Refuses when resulting desk would not be paper.
   */
  enablePaperAutopilot(): { ok: true; config: Record<string, unknown>; state: string } | { ok: false; reason: string } {
    if (this.config.paperMode !== true) {
      return { ok: false, reason: "autopilotMode requires paperMode true — refuse live" };
    }
    const best = applyBestPaperAutopilotSettings();
    // Force transition semantics even if already armed: clear halt + re-apply bundle.
    if (this.config.autopilotMode === true) {
      this.config.autopilotMode = false;
    }
    this.updateConfig({ ...best, paperMode: true } as Partial<BotConfig>);
    return this.finishPaperAutopilotArm();
  }

  /** Separate method so control-flow narrowing from the pre-arm false flip does not leak. */
  private finishPaperAutopilotArm(): { ok: true; config: Record<string, unknown>; state: string } | { ok: false; reason: string } {
    if (this.config.autopilotMode !== true || this.config.paperMode !== true) {
      return { ok: false, reason: "autopilotMode failed to arm (paper lock?)" };
    }
    this.clearAgentHaltDirectives("enablePaperAutopilot");
    if (this.state === "STOPPED" || this.state === "IDLE" || !this.config.enabled) {
      try { this.start(); } catch { /* logged in start */ }
    }
    return {
      ok: true,
      state: this.state,
      config: {
        autopilotMode: true,
        paperMode: true,
        enabled: this.config.enabled === true,
        frozenCcMode: this.config.frozenCcMode === true,
        brainCenterAuthority: this.config.brainCenterAuthority === true,
        agentControlMode: this.config.agentControlMode === true,
        requireAgentEntryApproval: this.config.requireAgentEntryApproval === true,
        autoMode: this.config.autoMode === true,
        minEntryPrice: this.config.minEntryPrice,
        maxEntryPrice: this.config.maxEntryPrice,
        reservePct: this.config.reservePct,
        useDrawdownGuard: this.config.useDrawdownGuard === true,
      },
    };
  }

  disablePaperAutopilot(): { ok: true; autopilotMode: false } {
    this.updateConfig({ autopilotMode: false } as Partial<BotConfig>);
    return { ok: true, autopilotMode: false };
  }

  private recordAutopilotDecision(
    kind: "TAKE" | "SKIP",
    side: "yes" | "no" | null | undefined,
    signal: string,
  ): void {
    if (this.config.autopilotMode !== true) return;
    const decisionKind = decisionKindFromSide(kind, side);
    this.lastAutopilotDecision = stampAutopilotDecision({ decisionKind, signal });
  }

  rejectAgentEntry(id: string, reason?: string): { ok: boolean; stamp?: string; error?: string } {
    const pending = this.pendingAgentEntry;
    if (!pending || pending.id !== id) {
      return { ok: false, error: "pendingAgentEntry not found or id mismatch" };
    }
    this.pendingAgentEntry = null;
    this.lastSignalDesc = `AGENT_REJECTED ${id}${reason ? `: ${reason}` : ""}`;
    this.log("info", this.lastSignalDesc);
    void persistDecisionTraceEvent({
      eventType: "SKIP",
      ticker: pending.ticker,
      side: pending.side,
      strategyId: pending.strategyId,
      chain: ["AGENT_REJECTED", reason ?? "agent reject", id],
      skipChain: ["AGENT_REJECTED"],
      gates: { agentStamp: "AGENT_REJECTED" },
      traceId: pending.traceId,
    });
    return { ok: true, stamp: "AGENT_REJECTED" };
  }

  async approveAgentEntry(id: string): Promise<{ ok: boolean; stamp?: string; error?: string }> {
    const pending = this.pendingAgentEntry;
    if (!pending || pending.id !== id) {
      return { ok: false, error: "pendingAgentEntry not found or id mismatch" };
    }
    if (this.config.paperMode !== true) {
      return { ok: false, error: "approve requires paperMode true" };
    }
    const tick = kalshiWS.getLatest();
    const liveAsk = tick
      ? (pending.side === "yes" ? tick.yesAsk : tick.noAsk)
      : null;
    const liveTicker = tick?.ticker ?? null;
    const check = validatePendingApprove({
      pending,
      liveTicker,
      liveAsk: typeof liveAsk === "number" ? liveAsk : null,
      askMin: this.config.minEntryPrice,
      askMax: this.config.maxEntryPrice,
    });
    if (!check.ok) {
      this.pendingAgentEntry = null;
      this.lastSignalDesc = `${check.stamp}: ${check.reason}`;
      void persistDecisionTraceEvent({
        eventType: "SKIP",
        ticker: pending.ticker,
        side: pending.side,
        strategyId: pending.strategyId,
        chain: [check.stamp, check.reason],
        skipChain: [check.stamp],
        gates: { agentStamp: check.stamp },
        traceId: pending.traceId,
      });
      return { ok: false, stamp: check.stamp, error: check.reason };
    }
    // Clear pending before place to avoid re-park loops; temporarily disarm require flag for this place
    this.pendingAgentEntry = null;
    const savedRequire = this.config.requireAgentEntryApproval;
    this.config.requireAgentEntryApproval = false;
    try {
      const proposal = pending.proposal as Parameters<TradingBot["_placeOrderBody"]>[0];
      // Refresh ask from live while keeping identity
      const refreshed = {
        ...proposal,
        entryPrice: typeof liveAsk === "number" && liveAsk > 0 ? liveAsk : proposal.entryPrice,
        decisionAskCents: typeof liveAsk === "number" && liveAsk > 0 ? liveAsk : proposal.decisionAskCents,
      };
      this.log("info", `AGENT_APPROVED ${id} → placeOrder ${pending.strategyId} ${pending.side}`);
      void persistDecisionTraceEvent({
        eventType: "ENTRY",
        ticker: pending.ticker,
        side: pending.side,
        strategyId: pending.strategyId,
        chain: ["AGENT_APPROVED", id],
        gates: { agentStamp: "AGENT_APPROVED" },
        traceId: pending.traceId,
      });
      await this.placeOrder(refreshed);
      this.lastSignalDesc = `AGENT_APPROVED ${id}`;
      return { ok: true, stamp: "AGENT_APPROVED" };
    } finally {
      this.config.requireAgentEntryApproval = savedRequire;
    }
  }

  private async exitEarly(reason: string, exitPriceCents: number, breakdown?: ExitPriceBreakdown) {
    if (!this.openTrade) return;
    const trade = this.openTrade;
    // Honesty: once recordSettlement has booked this fill, never re-enter exit
    // accounting (persist-fail KEEP + PATH_RIDE still green was spamming CLOSE).
    if (trade.settlementFinalized === true) {
      this.setOpenTrade(null);
      return;
    }
    // Task #221: a 0¢ or 100¢ quote almost always means "no executable bid"
    // or a degenerate/stale tick, not a real market price. Check the raw quote
    // before buildKalshiV2ExitBody can clamp it into a seemingly valid order;
    // otherwise a bad tick can close a position at a bogus price silently.
    // The position stays open and is re-evaluated next tick against a fresh
    // quote.
    if (!isValidKalshiPrice(exitPriceCents)) {
      this.log("warn",
        `Bot exit skipped — price ${exitPriceCents}¢ outside 1–99¢ range`);
      return;
    }

    // SEV0 (sweep S1): tick-driven exits must never fire after the contract
    // closed or against another ticker's book. Operator/shutdown exits exempt.
    if (trade.contractDurationMins !== 60 && reason !== "MANUAL_FORCE_EXIT" && reason !== "SHUTDOWN_GRACEFUL_CLOSE") {
      const verdict = exitQuoteGuard({
        tradeTicker: trade.ticker,
        tradeCloseMs: resolveTradeCloseMs(trade),
        quoteTicker: kalshiWS.getLatest()?.ticker ?? null,
        nowMs: Date.now(),
      });
      if (!verdict.ok) {
        this.log("warn", `[EXIT_QUOTE_GUARD] ${reason} blocked for ${trade.ticker}: ${verdict.reason}${verdict.reason === "AFTER_CLOSE" ? " — settling instead" : ""}`);
        if (verdict.reason === "AFTER_CLOSE") void this.detectSettlement();
        return;
      }
    }

    // 2026-08-17 exit-order-storm fix: once a real exit attempt has failed to
    // confirm a close, require an escalating cooldown before firing ANOTHER
    // real order. Without this, a Kalshi confirmation outage turns "retry
    // until closed" (by design — see the A1 comment below) into a real order
    // every ~500ms tick for as long as the outage lasts: one incident placed
    // 14 real, fee-charging exit orders on a single 11-contract position in
    // under 4 minutes, none of which were ever confirmed or persisted.
    // MANUAL_FORCE_EXIT and SHUTDOWN_GRACEFUL_CLOSE are deliberate one-shot
    // operator/process actions, not tick-driven re-evaluation, so they are
    // exempt — blocking those would defeat their purpose in an emergency.
    if (!trade.paper && reason !== "MANUAL_FORCE_EXIT" && reason !== "SHUTDOWN_GRACEFUL_CLOSE") {
      const backoffMs = getExitAttemptBackoffMs(trade.consecutiveExitFailures ?? 0);
      const sinceLastAttempt = trade.lastExitAttemptAt ? Date.now() - trade.lastExitAttemptAt : Infinity;
      if (backoffMs > 0 && sinceLastAttempt < backoffMs) {
        this.log("warn",
          `⏳ Exit BLOCKED (${reason}) — backing off ${backoffMs}ms after ${trade.consecutiveExitFailures} ` +
          `consecutive unconfirmed exit attempt(s) on ${trade.ticker} (last attempt ${sinceLastAttempt}ms ago). ` +
          `Holding position; will re-evaluate once the cooldown elapses.`);
        return;
      }
    }

    // Compute sweep buffer up front so PnL calculation (below) can use it.
    // Hard stops (price moving fast against us): 4¢ sweep to guarantee fill
    //   on an adverse move without giving up too much PnL.
    // Soft stops / trailing / time exits: 2¢ — still crosses the spread but
    //   doesn't convert a profitable or breakeven trade into a loss on Kalshi.
    //   (Previously 6¢ for all stops caused the exit order to fill 6¢ worse
    //    than market, turning a +4¢ position into a −2¢ Kalshi fill.)
    // Profit exits / paper trades: 0¢ — market moving in our favour, or no
    //   real order placed, so no sweep cost.
    // SHUTDOWN_GRACEFUL_CLOSE is treated as hard-stop urgency: there is no
    // "next tick" to retry on if it doesn't fill (the process is about to
    // exit), so it needs the same guaranteed-fill sweep as a hard stop rather
    // than the smaller PnL-preserving sweep used for a routine soft exit.
    const _isHardStop = reason === "HARD_STOP" || reason === "HARD_STOP_EXIT" || reason === "HARD_STOP_PCT" || reason === "FAST_REVERSAL" || reason === "SHUTDOWN_GRACEFUL_CLOSE";
    const _isStop     = _isHardStop || reason.includes("STOP") || reason === "MTF_REVERSAL";
    // Mutable: a failed stop-type exit retries with a wider sweep below, and
    // the PnL calc after the retry block must reflect whichever sweep the
    // order actually filled at, not the original pre-retry value.
    let sweepBuf      = trade.paper ? 0 : _isHardStop ? 4 : _isStop ? 2 : 0;
    // GO EXECUTION INTEGRITY BATCH — A1: confirmed Kalshi fill price, when
    // available, overrides the quote-based effectiveExitCents estimate below.
    // Stays null for paper trades (no real fill exists).
    let confirmedExitCents: number | null = null;

    if (!trade.paper) {
      // Leftover live Kalshi exit POST — paper/frozen never run it.
      if (!leftoverLiveOrderMayRun(this.config)) {
        this.log("warn", "leftover live exit POST skipped (paper/frozen desk)");
        return;
      }
      const liveExit = await leftoverLiveOrderRun(this.config, () =>
        leftoverLiveExitFunnel.call(this, {
          trade,
          reason,
          exitPriceCents,
          sweepBuf,
          _isStop: reason.includes("STOP") || reason.includes("CATASTROPHIC") || reason.includes("HARD_STOP"),
          kalshiAuthHeaders,
          getKalshiRejectionDetail,
          kalshiSameSidePosition,
          isAuthSigningFailed,
          deleteTradeIntent,
        }),
      );
      if (!liveExit || liveExit.kind === "abort") {
        return;
      }
      confirmedExitCents = liveExit.confirmedExitCents;
    }

    // Use the CONFIRMED Kalshi fill price when available (A1); otherwise fall
    // back to the quote-based estimate (market − sweep) — paper trades (no
    // real fill exists) or the rare case where Kalshi's status response
    // omitted avg_price. Without this fallback the UI showed the trade "in
    // the green" while the Kalshi account recorded a loss.
    const effectiveExitCents = confirmedExitCents ?? Math.max(0, exitPriceCents - sweepBuf);
    // FEE ORGAN: early sell = entry fee + SECOND fee at exit. Settlement has
    // no second fee (computeBinarySettlementPnl). Fee-net must match paper cash.
    const { entryFeeCents, exitFeeCents, pnlCents } = computeEarlyExitFeeNetPnl(
      trade.contracts, trade.entryPriceCents, effectiveExitCents,
    );
    const outcome  = pnlCents >= 0 ? "win" : "loss";

    // Master bot upgrade step 4: same-ticker PRESS-sizing cooldown after a
    // loss or a THESIS_BREAK_EXIT/LAG_FLIP_EXIT close (the latter two even on
    // a rare breakeven/win, since both mean the thesis we traded on just
    // proved wrong). Does not block re-entry — only caps the next same-ticker
    // trade below PRESS tier (see computeStackTier()).
    if (outcome === "loss" || reason === "THESIS_BREAK_EXIT" || reason === "LAG_FLIP_EXIT") {
      this.pressCooldownTicker = trade.ticker;
      this.pressCooldownUntil  = Date.now() + STACK_PRESS_COOLDOWN_MS;
    }

    const emoji    = reason === "HARD_STOP" || reason === "HARD_STOP_PCT" ? "💀"
                 : reason.startsWith("STOP") || reason === "SOFT_STOP_PCT" || reason === "MTF_REVERSAL" || reason === "TIME_STOP" ? "🛑"
                 : "💰";

    // Determine and record which signal drove the exit decision
    const driver: 'theoretical' | 'market' = (breakdown?.theoLed) ? 'theoretical' : 'market';
    this.lastExitDriver         = driver;
    this.lastExitPriceBreakdown = breakdown ?? null;
    this.livePriceBreakdown     = null;  // trade is closing — clear the live breakdown

    const priceNote = breakdown
      ? ` (theo: ${breakdown.theo.toFixed(0)}¢ mkt: ${breakdown.mkt.toFixed(0)}¢ blend: ${breakdown.blend.toFixed(0)}¢ · ${breakdown.theoLed ? 'theo-led' : 'mkt-led'})`
      : '';
    const feeTotal = entryFeeCents + exitFeeCents;
    const feeNote = feeTotal > 0
      ? ` fees -$${(feeTotal / 100).toFixed(2)} (entry $${(entryFeeCents / 100).toFixed(2)}+exit $${(exitFeeCents / 100).toFixed(2)})`
      : '';
    const sweepNote = sweepBuf > 0 ? ` sweep-${sweepBuf}¢` : '';

    this.log("settle",
      `${emoji} EARLY EXIT [${reason}] · mkt ${exitPriceCents}¢${sweepNote} → fill ${effectiveExitCents}¢ (was ${trade.entryPriceCents}¢) · ` +
      `${pnlCents >= 0 ? '+' : ''}$${(pnlCents / 100).toFixed(2)}${feeNote} · ${trade.paper ? '[PAPER] ' : ''}` +
      `maxGain was ${trade.maxGainCents}¢/contract${priceNote}`
    );

    this.openTradeMaxGain = 0;

    // Profit Doctrine Phase 6: EXIT decision-trace row — captures WHY the
    // bot chose to close early (reasonCode = the same `reason` string every
    // one of exitEarly()'s ~20 call sites already passes in) and the realized
    // economics for this leg. Fire-and-forget; recordSettlement() below
    // separately writes the SETTLE row for every terminal path (this one
    // included), so EXIT and SETTLE are complementary, not duplicates.
    const ms6 = this.lastMarketState;
    void persistDecisionTraceEvent({
      eventType: "EXIT", ticker: trade.ticker, side: trade.side, strategyId: trade.strategyId,
      family: getStrategyFamily(trade.strategyId as StrategyId), secsLeft: getSecsRemaining(),
      market: ms6 ? {
        velScale: ms6.velScale, zVel: ms6.zVel, rangeScale: ms6.rangeScale, volScale: ms6.volScale,
        regime: this.lastAdaptiveCondition?.condition ?? String(ms6.regime), session: String(ms6.session),
        tau: ms6.tau, stale: ms6.stale,
      } : undefined,
      exit: { reasonCode: reason, pnlCents, outcome },
      chain: [reason],
    });

    // Pass exit proceeds for paper credit AND so feeCents can book the second fee (live too).
    const exitProceedsCents = Math.round(effectiveExitCents * trade.contracts);
    await this.recordSettlement(trade, outcome, pnlCents, exitProceedsCents, breakdown, reason);
  }

  /**
   * Called from index.ts's SIGTERM/SIGINT handler before the process exits.
   *
   * Root-cause finding: a live position open at the moment of a restart (a
   * deploy, a crash-loop respawn, or simply this session's own dev-verification
   * restarts) had NO shutdown handler at all — the process just died and the
   * position rode blind to settlement with every active risk control (stop-
   * loss, thesis-break, ARIA gated exit, trailing stop) disabled for however
   * long the process was down. A DB audit found this ("STARTUP_RECOVERY" exit
   * reason) behind roughly half of all recent losing trades — not a strategy
   * or learning failure, an operational gap that was silently generating real
   * losses and polluting the learning stats those very losses are judged by.
   *
   * This makes ONE best-effort attempt to close any open LIVE position (paper
   * trades have no real exposure, left alone) at the current bid before the
   * process exits, reusing exitEarly()'s existing order-placement/PnL/
   * settlement/postmortem pipeline so a graceful-close is bookkept identically
   * to any other early exit. Bounded to index.ts's own race deadline (see its
   * comment for the current value and margin) — hanging past that would just
   * mean the position holds to settlement anyway (the original, unchanged
   * behavior), never anything worse.
   *
   * 2026-08-16: added start/elapsed logging on every branch (including the
   * early-return ones) because a DB audit found 0 SHUTDOWN_GRACEFUL_CLOSE
   * rows ever, against 70+ STARTUP_RECOVERY rows, with no way to tell from
   * the DB alone *which* branch was losing — no open trade at the exact
   * shutdown instant, no live quote, or a timed-out exitEarly() attempt.
   * These logs land in the per-restart console/crash-forensics capture even
   * though they can't land in bot-log.jsonl's rotation window by the time
   * anyone looks, so the next occurrence is diagnosable from workflow logs.
   */
  public async attemptGracefulShutdownClose(): Promise<void> {
    const startedAt = Date.now();
    const trade = this.openTrade;
    if (!trade) {
      this.log("info", "[shutdown] No open trade at shutdown — nothing to close.");
      return;
    }
    if (trade.paper) {
      this.log("info", "[shutdown] Open trade is paper-only — no real exposure, leaving as-is.");
      return;
    }
    try {
      const isHourlyTrade = trade.contractDurationMins === 60;
      const tick = isHourlyTrade
        ? (() => {
            const h = hourlyPoller.getLatest();
            return h ? { yesBid: h.yesBid, noBid: h.noBid } : null;
          })()
        : kalshiWS.getLatest();
      if (!tick) {
        this.log("warn", `[shutdown] No live quote available (elapsed ${Date.now() - startedAt}ms) — cannot attempt graceful close, position will hold to settlement.`);
        return;
      }
      const currentSidePrice = trade.side === "yes" ? tick.yesBid : tick.noBid;
      this.log("warn", `[shutdown] Restart requested with an open live position (${trade.ticker} ${trade.side} ×${trade.contracts}) — attempting graceful close before exit.`);
      await this.exitEarly("SHUTDOWN_GRACEFUL_CLOSE", currentSidePrice);
      this.log("warn", `[shutdown] Graceful close attempt finished in ${Date.now() - startedAt}ms (openTrade now ${this.openTrade ? "still open — exitEarly did not clear it" : "cleared"}).`);
    } catch (err) {
      // Never let a shutdown-close failure delay or crash process exit — the
      // fallback (hold to settlement) is exactly today's pre-fix behavior.
      this.log("warn", `[shutdown] Graceful close attempt errored after ${Date.now() - startedAt}ms: ${(err as Error).message} — position will hold to settlement.`);
    }
  }

  // ── Streak-sat live CONTEXT (soft prior + confluence) ────────────────────────

  private priorFadeFailedAgainst(streak?: number | null): boolean {
    const rec = this.lastFadeAgainstStreak;
    if (!rec || streak == null || streak === 0) return false;
    const dir: 1 | -1 = streak > 0 ? 1 : -1;
    if (dir !== rec.dir) {
      this.lastFadeAgainstStreak = null;
      return false;
    }
    return Math.abs(streak) > rec.abs;
  }

  private evaluateLiveStreakSat(
    proposedSide: "yes" | "no" | null,
    obs = this.lastObservation,
    spot?: number,
  ): StreakSatDecision {
    const cp = spot ?? (this.prices.length > 0 ? this.prices[this.prices.length - 1].price : 0);
    const htf = typeof cp === "number" && Number.isFinite(cp) && cp > 0
      ? computeLiveHtfStructure(cp)
      : null;
    return evaluateStreakSaturation(liveStreakSatInput({
      obs,
      proposedSide,
      htf,
      priorFadeFailed: this.priorFadeFailedAgainst(obs?.settlementStreak),
    }));
  }

  private rememberFadeAgainstStreak(): void {
    if (this.lastStreakSatDecision?.takeFade !== true) return;
    const s = this.lastObservation?.settlementStreak ?? 0;
    if (s === 0) return;
    this.lastFadeAgainstStreak = { dir: s > 0 ? 1 : -1, abs: Math.abs(s) };
  }

  // ── Add-to-position (scale in when extremely confident) ───────────────────────

  private async considerAddingToPosition() {
    // Leftover add-to-position body lives in leftover-add-funnel (mayRun-gated).
    if (!leftoverAddEvaluateMayRun(this.config)) return;
    await leftoverAddEvaluateRun(this.config, () =>
      leftoverAddEvaluateFunnel.call(this, {
        detectStallInfo,
        resolveAddPositionVolatility,
        isVolBufferRecovery,
        probabilityEdge,
        selectBestEnabled,
        effectiveDisabledStrategies,
        makeTraceScopedSkip,
        blendedEntryPriceCents,
        resolveAddFillOutcome,
        getKalshiRejectionDetail,
        kalshiAuthHeaders,
        tradeSecsRemaining,
        fetchOrderbookDepthAtEntry,
        resolveDepthAwareSizing,
      }),
    );
  }


  private async addToPosition(tick: KalshiTick, traceId?: string) {
    if (!this.openTrade) return;
    const trade     = this.openTrade;
    const addPrice  = trade.side === "yes" ? tick.yesAsk : tick.noAsk;  // ask → immediate fill
    const addContracts = 1;
    const costCents = paperFillCostCents(addContracts, addPrice);
    // GO — SPECIALIST REGIME SYSTEM Phase 0: addToPosition never creates a new
    // bot_trades row (it scales an existing open trade), so there's no
    // traceId column to attach here — but a successful add is still a real
    // ORDER outcome and gets its own DecisionTrace row, referencing the
    // existing open trade's dbId rather than a new one.
    const addTraceId = traceId ?? generateTraceId();

    if (trade.paper) {
      if (this.paperVirtualBalanceCents < costCents) return;
      this.paperVirtualBalanceCents -= costCents;
      this.persistPaperLedger();
      this.openTrade.contracts    += addContracts;
      this.openTrade.addedContracts = true;
      this.log("order", `➕ ADDED 1 contract [PAPER] · now ${this.openTrade.contracts}× ${trade.side.toUpperCase()} @ ${addPrice}¢`);
      void persistDecisionTrace({
        traceId: addTraceId, ts: Date.now(), ticker: trade.ticker, side: trade.side,
        contracts: this.openTrade.contracts, ask: addPrice, outcome: "ORDER",
        // Phase 1 (SPECIALIST REGIME SYSTEM): wire the sticky committed
        // regime + its current hold reason, per spec.
        regime: getRegime(), regimeHeldBy: getRegimeHeldBy() ?? undefined,
        chain: ["ADD_TO_POSITION", "paper"], botTradeId: trade.dbId ?? undefined,
      });
      return;
    }

    // 2026-08-25 PhD audit fix: a scale-in add used to skip every admission
    // check a fresh entry gets. Refresh balance and re-check daily-target /
    // circuit-breaker / cumulative-9%-cap here, exactly like a new entry
    // would, before this add is allowed to place a real order.
    await this.refreshBalance();
    if (this.isBalanceStale()) {
      this.log("warn",
        `⛔ Add-to-position BLOCKED — balance ${this.accountBalance === null ? "never fetched" : "stale"}` +
        (this.lastBalanceError ? ` (${this.lastBalanceError})` : ""));
      return;
    }
    const addBalanceCents = this.effectiveBalance();
    const addDailyBlock = dailyTargetEntryBlock(this.lastDailyTarget, this.dailyTargetLatchDirty, this.dailyTargetLoadFailed);
    if (addDailyBlock) {
      this.log("warn", `⛔ Add-to-position BLOCKED — ${addDailyBlock}`);
      return;
    }
    if (!canScaleIntoPosition({
      balanceCents: addBalanceCents,
      todayPnlCents: this.dayPnlForHardRiskLimits(),
      existingContracts: trade.contracts,
      existingEntryPriceCents: trade.entryPriceCents,
      addContracts, addPriceCents: addPrice,
    })) {
      this.log("warn",
        `⛔ Add-to-position BLOCKED — cumulative exposure (${trade.contracts + addContracts}× ${trade.side.toUpperCase()}) ` +
        `would exceed the ${(HARD_RISK_LIMITS.maxRiskPctPerTrade * 100).toFixed(0)}% equity cap.`);
      return;
    }

    // A scale-in is still a live entry order. It must use the same fresh,
    // fail-closed depth admission as a new position so a one-contract add
    // cannot consume all of a thin book or bypass the configured cap.
    const addDepthResult = await fetchOrderbookDepthAtEntry(
      trade.ticker,
      trade.side,
      addPrice,
    );
    const addDepthSizing = resolveDepthAwareSizing(
      addContracts,
      addDepthResult,
      this.config.maxDepthFraction,
    );
    if (!addDepthResult.available) {
      this.log("warn",
        `[depth] ADD_TO_POSITION DEPTH_UNAVAILABLE: ${addDepthResult.warning}; blocking live add`
      );
      return;
    }
    if (addDepthSizing.contracts < addContracts) {
      this.log("info",
        `depth cap: sized down ${addContracts}→${addDepthSizing.contracts} ` +
        `(${addDepthSizing.visibleDepth} contracts visible at price)`
      );
      this.log("warn",
        `[depth] ADD_TO_POSITION DEPTH_SIZE_ZERO: visible depth is too small ` +
        `for the configured ${this.config.maxDepthFraction * 100}% cap; blocking live add`
      );
      return;
    }

    // Buy more of trade.side using Kalshi V2 API
    // Buy YES → bid at yes ask price; Buy NO → ask at (100 - no_ask) = yes bid price
    let orderId: string | null = null;
    try {
      const apiPath    = KALSHI_PATH_PORTFOLIO_ORDERS;
      const addHeaders = await kalshiAuthHeaders("POST", apiPath);

      // Auth guard — same as entry and exit order paths.
      if (!addHeaders["KALSHI-ACCESS-KEY"]) {
        this.log("warn",
          `⚠️ CRITICAL: Add-to-position BLOCKED — auth signing failed. ` +
          `Check your API key in Settings.`);
        return;
      }

      // D7 — same trade + same pre-add size + same add → same client_order_id (retry-safe).
      const body = buildKalshiV2Body(trade.ticker, trade.side, addContracts, addPrice,
        stableClientOrderId("add", trade.dbId ?? trade.ticker, trade.contracts, addContracts, addPrice));
      // Task #158/#161: log the base URL used for every live order so
      // endpoint routing can be audited from logs alone.
      this.log("order", `POST ${KALSHI_API_DOMAIN}${apiPath} · ticker=${trade.ticker} side=${body.side} reason=ADD_TO_POSITION`);
      const r = await fetch(`${KALSHI_API_DOMAIN}${apiPath}`, {
        method: "POST", headers: addHeaders,
        body: JSON.stringify(body), signal: AbortSignal.timeout(4_000),
      });
      if (!r.ok) {
        recordFailure("kalshi-api");
        const errBody = await r.json().catch(() => ({})) as Record<string, unknown>;
        const detail = getKalshiRejectionDetail(errBody, r.status);
        this.log("warn", `Add-to-position FAILED [HTTP ${r.status}]: ${detail}`);
        // Task #204: surface the exact rejection reason on BotStatus.
        this.publishOrderRejection(trade.ticker, trade.side, detail);
        return;
      }
      recordSuccess("kalshi-api");
      const data = await r.json().catch(() => ({})) as { order_id?: string; order?: { order_id?: string } };
      orderId = data.order_id ?? data.order?.order_id ?? null;
    } catch (err) {
      recordFailure("kalshi-api");
      this.log("warn", `Add-to-position ERROR: ${(err as Error).message}`);
      return;
    }

    // GO EXECUTION INTEGRITY BATCH — A1: a 2xx accept is not a fill. This
    // used to increment openTrade.contracts unconditionally right after a
    // successful POST, regardless of whether Kalshi actually filled the
    // order — an unconfirmed or unfilled add would silently inflate the
    // tracked position size (and, on a rejected/expired resting order,
    // create a phantom contract the account never held). Confirm the real
    // fill first; an unconfirmed poll (network failure throughout the
    // window) is treated as "unknown", not as filled, and leaves the
    // position size unchanged.
    if (!orderId) {
      this.log("warn", `⚠️ Add-to-position accepted but no order_id returned — cannot confirm fill; NOT increasing position size.`);
      return;
    }
    // The confirm/don't-confirm branching lives in the pure, independently
    // tested resolveAddFillOutcome() so it can't silently drift.
    const fill    = await this.pollOrderFillStatus(orderId, { attempts: 3, intervalMs: 700, expectedContracts: addContracts });
    const outcome = resolveAddFillOutcome(fill);
    if (outcome === "hold-unconfirmed") {
      this.log("warn",
        `⚠️ Add-to-position order ${orderId} fill UNCONFIRMED after poll (no definitive Kalshi read) — ` +
        `cancelling and leaving position size unchanged.`);
      const cancelPath = kalshiEventsOrderPath(orderId);
      await fetch(`${KALSHI_API_DOMAIN}${cancelPath}`, {
        method: "DELETE",
        headers: { ...await kalshiAuthHeaders("DELETE", cancelPath), Accept: "application/json" },
        signal:  AbortSignal.timeout(4_000),
      }).catch(() => {});
      return;
    }
    if (outcome === "hold-unfilled") {
      this.log("info", `Add-to-position order ${orderId} did not fill (status=${fill.status}) — position size unchanged.`);
      return;
    }

    // Update the open trade record — only now that a real fill is confirmed.
    this.openTrade.contracts    += addContracts;
    this.openTrade.addedContracts = true;

    this.log("order",
      `➕ ADDED 1 contract (confirmed fill @ ${fill.avgPriceCents ?? addPrice}¢) · ` +
      `now ${this.openTrade.contracts}× ${trade.side.toUpperCase()} @ ${addPrice}¢`);
    void persistDecisionTrace({
      traceId: addTraceId, ts: Date.now(), ticker: trade.ticker, side: trade.side,
      contracts: this.openTrade.contracts, ask: fill.avgPriceCents ?? addPrice, outcome: "ORDER",
      regime: getRegime(), regimeHeldBy: getRegimeHeldBy() ?? undefined,
      chain: ["ADD_TO_POSITION", "live", "fill_confirmed"], botTradeId: trade.dbId ?? undefined,
    });
  }

  // ── Price feed ────────────────────────────────────────────────────────────────
  // 1-second micro-cache: tick runs every 2s but two rapid calls in one cycle
  // (e.g. monitorOpenTrade + evaluateEntry) would otherwise double-infer.
  //
  // Price is now inferred from the live Kalshi WS tick using Black-Scholes
  // inversion: given YES probability P, floor K, time-to-close T, and
  // annualised vol σ → spot S = K · exp(N⁻¹(P)·σ·√T + 0.5·σ²·T).
  // This is Kalshi-native: the same BRTI that settles the contracts.

  private _priceCache: { val: number; ts: number } | null = null;

  private fetchBtcPrice(): Promise<number> {
    const now = Date.now();
    if (this._priceCache && now - this._priceCache.ts < 1_000) {
      return Promise.resolve(this._priceCache.val);
    }
    // Prefer official CF Benchmarks BRTI (5Hz WS) — identity pin for G/A_hat/settlement.
    // FILL entryTheo stamps via getFreshBrtiUsd + stampEntryTheoFromBrti directly
    // (fail-closed to null) — never route theo through the book-infer fallback below.
    const brti = kalshiWS.getFreshBrtiUsd(2_500);
    if (brti != null && brti > 0) {
      this._priceCache = { val: brti, ts: now };
      return Promise.resolve(brti);
    }
    const tick = kalshiWS.getLatest();
    // BRTI proxy must age on quoteTs, not heartbeat-refreshed ts (WS vs last book).
    const quoteTs = tick
      ? (typeof tick.quoteTs === "number" && tick.quoteTs > 0 ? tick.quoteTs : tick.ts)
      : null;
    if (tick && quoteTs != null && now - quoteTs < 5_000) {
      const val = inferBtcPrice(tick);
      if (val > 0) {
        this._priceCache = { val, ts: now };
        return Promise.resolve(val);
      }
    }
    // Sep 9 #21: never invent floorStrike / 97000 into the velocity buffer.
    // Return 0 ("no price") until a real oracle or strike-bearing tick exists.
    const fallback = this._priceCache?.val ?? 0;
    return Promise.resolve(fallback > 0 ? fallback : 0);
  }

  private computeVelocity() {
    if (this.prices.length < 4) { this.currentVelocity = 0; this.threeMinVelocity = 0; this.velocityAccel = 0; return; }
    const shortW   = this.prices.slice(-12);
    const elShort  = (shortW[shortW.length - 1].ts - shortW[0].ts) / 60_000;
    // Admission Hazard Audit follow-up (2026-08-25): least-squares slope across
    // every sample in the window, NOT a naive endpoint-to-endpoint difference —
    // same fix already applied in settlement-predictor.ts's computeRecentVelocity()
    // for the identical root cause (2026-08-06): a single noisy price sample at
    // either edge of the window can flip a 2-point slope's sign/size on one tick.
    // This `currentVelocity` is the SAME value BASIS_LAG_EDGE's entry-time
    // projectSettlementPrice() edge relies on AND the value checkThesisBreak's
    // VELOCITY_FLIP_AGAINST rule and checkLagFlip's projectSettlementPrice()
    // exit check consume a few ticks later — with a noisy 2-point read, an
    // entry taken on a thin (near-zero) lag edge could see that same edge
    // "flip" from pure sampling noise within 2-3 ticks, tripping the ≥3-tick
    // persistence gate and force-exiting a still-good position. Live trades
    // over the 7 days after LAG_FLIP_EXIT shipped (2026-08-14) showed the
    // majority of live losses were LAG_FLIP_EXIT/THESIS_BREAK_EXIT firing
    // within single-digit seconds of entry — consistent with this mechanism.
    // Regressing over all 12 points in the window averages out that per-
    // sample noise instead of trusting just its two endpoints.
    let newVelocity = 0;
    if (elShort > 0) {
      const t0 = shortW[0].ts;
      const n  = shortW.length;
      let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
      for (const p of shortW) {
        const x = (p.ts - t0) / 60_000;
        sumX += x; sumY += p.price; sumXY += x * p.price; sumXX += x * x;
      }
      const denom = n * sumXX - sumX * sumX;
      newVelocity = Math.abs(denom) > 1e-9 ? (n * sumXY - sumX * sumY) / denom : 0;
    }

    // ── Velocity acceleration ──────────────────────────────────────────────────
    // Measures whether momentum is building (positive) or fading (negative).
    // Only meaningful after the first compute; zero on first call.
    // A large positive accel → trend is strengthening → higher success rate.
    // A negative accel on a fast move → momentum is exhausting → danger zone.
    this.velocityAccel   = this.prevVelocity !== 0 ? newVelocity - this.prevVelocity : 0;
    this.prevVelocity    = newVelocity;
    this.currentVelocity = newVelocity;
    // P3 MARKETSTATE: EMA-smooth v1 for zVel (market-state.ts) — separate from
    // velocityAccel above (a raw tick-to-tick diff, not a smoothed average).
    this.velocityEma = updateVelocityEma(this.velocityEma, newVelocity);

    const longW    = this.prices;
    const elLong   = (longW[longW.length - 1].ts - longW[0].ts) / 60_000;
    this.threeMinVelocity = elLong > 0 ? (longW[longW.length - 1].price - longW[0].price) / elLong : 0;

    // Sample into the 1h velocity history ring buffer every ~10s (not every
    // 500ms tick — would be 7200 points/hr for no extra signal). Powers the
    // dashboard's rolling-average chips and toggleable momentum chart.
    const now = Date.now();
    if (now - this.lastVelocitySampleTs >= 10_000) {
      this.lastVelocitySampleTs = now;
      this.velocityHistory.push({ t: now, v: this.currentVelocity });
      // P3 MARKETSTATE: retention extended from 1h→4h so computeVelScale's 2h
      // window (and its "session" proxy, the full retained history) has real
      // data instead of being silently truncated to the old 1h window.
      const cutoff = now - 4 * 60 * 60_000;
      while (this.velocityHistory.length > 0 && this.velocityHistory[0].t < cutoff) {
        this.velocityHistory.shift();
      }
    }
  }

  /** Trailing average of sampled velocity over the last N minutes (falls back to the live reading if no samples fall in-window yet, e.g. right after startup). */
  private velocityAvgOverMinutes(mins: number): number {
    const cutoff = Date.now() - mins * 60_000;
    const window = this.velocityHistory.filter(p => p.t >= cutoff);
    if (window.length === 0) return this.currentVelocity;
    return window.reduce((sum, p) => sum + p.v, 0) / window.length;
  }

  private getVelocityAverages() {
    return {
      m1:  this.velocityAvgOverMinutes(1),
      m5:  this.velocityAvgOverMinutes(5),
      m15: this.velocityAvgOverMinutes(15),
      m30: this.velocityAvgOverMinutes(30),
      h1:  this.velocityAvgOverMinutes(60),
    };
  }

  // ── Position sizing ────────────────────────────────────────────────────────────

  /**
   * True half-Kelly formula:
   *   Kelly fraction fk = p - (1-p)/b
   *   where p = strategy win rate, b = payout-to-risk ratio = (100 - entryPrice) / entryPrice
   *   Use half-Kelly (fk / 2) for safety.
   *   Contracts = max(1, min(maxContracts, floor(halfKelly * balance / entryPrice)))
   */
  private computeContracts(confidence: number, entryPriceCents: number, strategyWinRate?: number, edge = 0, regime: GrokRegime = 'transitioning', strategyId?: string, durationMins?: number, volumeSizeMult = 1, packSizeCapMult = 1): SizingResult {
    const max = this.effectiveMaxContracts();

    // PAPER_SCALP: size is 1 contract. 9% is a CAP not a target. Do not Kelly-up
    // a scalp. Task #391: SIZE_RESCUE_MIN1 must not turn Kelly-zero into 1×
    // for BASIS_LAG or any other path.
    if (strategyId === "PAPER_SCALP") {
      return {
        contracts: 1,
        limiter: "PAPER_SCALP_SIZE_1",
        detail: "PAPER_SCALP max 1 contract (9% is a CAP not a target; do not Kelly-up a scalp)",
      };
    }

    // ── Kelly p = winRateAtPrice; Wilson/uMult shrink size only ──────────────
    // Kelly f* uses the SAME strategyWinRate / winRateAtPrice PATH_GATE and
    // evaluateEntryEVGate used for this ticket. computePSizeForKelly (Wilson
    // clamp [0.50,0.65], paper n=0 → 0.55) is NOT replacement p — it feeds
    // logs / uMult. uMult (computeSizeUncertaintyMult) shrinks contract COUNT
    // only. Prefer not inventing a 0.50 floor on p.
    //
    // n/wins come from getLiveTradeStatsSync — the EXACT SAME live-only
    // (is_paper=false, outcome IN win/loss), this-duration-bucket sample
    // quarantine's evaluateQuarantine() already judges the strategy on
    // (strategy-performance.ts), not a separately-reinvented count.
    //
    //   p_hat = wins / n
    //   p_lb  = wilsonLowerBound(wins, n)      // existing helper, same one quarantine uses
    //   n = 0          -> p_size = P_PRIOR_CAP           (0.55 — documented static prior)
    //   0 < n < N_MIN  -> p_size = 0.5 + (p_lb - 0.5) * (n / N_MIN)   // shrink toward 0.5 as n->0
    //   n >= N_MIN     -> p_size = p_lb
    //   then clamp p_size into [0.50, 0.65] (v1 safety band, documented)
    //
    // N_MIN=20 matches QUARANTINE_MIN_TRADES (strategy-performance.ts) so the
    // same sample size that lets quarantine trust a bucket's own evidence is
    // also where sizing stops shrinking toward the conservative prior.
    // Formula/constants live in computePSizeForKelly (strategy-performance.ts)
    // — a pure, DB-free function, extracted so it's unit-testable without
    // mocking the live cache (same pattern as this file's other fail-closed
    // predicates).
    const { n: liveN, wins: liveWins } = strategyId ? getLiveTradeStatsSync(strategyId, durationMins) : { n: 0, wins: 0 };
    const { pSize: pSizeClamped, detail: pSizeDetail } = computePSizeForKelly(liveN, liveWins);

    // NOTE: this used to hard-floor to exactly 1 contract whenever live equity
    // was under $25, which disabled Kelly/tiered/portfolio-% sizing entirely
    // for small accounts (every account under $25 got the same 1 contract
    // regardless of win rate, edge, or confidence). That floor is gone —
    // liveEquity is guaranteed fresh and non-null here because the caller
    // (_placeOrderBody) already ran the balance-staleness gate before this is
    // invoked, so every branch below runs its real percentage-of-equity math
    // at any balance and naturally produces 0/1/2/... contracts proportional
    // to that balance, then gets re-clamped by applyHardRiskLimits()'s single
    // 9%-of-equity cap regardless of path.

    // ── Portfolio-% sizing (highest priority when enabled) ────────────────────
    // Risk a % of current balance per trade — the % itself scales with edge/
    // confidence (like Kelly does) rather than being flat, and a genuinely
    // negative-EV trade still sizes to 0. A flat % regardless of edge would
    // undo the very thing that kept marginal-edge strategies (e.g.
    // FLOOR_DISTANCE, LATE_ENTRY_ANCHOR) from being oversized (Task #368).
    // Contracts = floor(balance × effectivePct% / fee-inclusive cost), capped
    // by maxContracts.
    if (this.config.usePortfolioRisk && this.config.portfolioRiskPct > 0) {
      // Fee-adjusted payout ratio b, same formula as the Kelly branch below —
      // used only as an EV sanity gate here, not to size the position.
      const netCost = kalshiNetCostCents(entryPriceCents);
      const b       = kellyPayoutRatio(entryPriceCents);
      // Live-active Portfolio-% branch. Kelly f* p = strategyWinRate
      // (winRateAtPrice). Wilson/uMult shrink size only — never replace p.
      const p = (typeof strategyWinRate === "number" && Number.isFinite(strategyWinRate))
        ? strategyWinRate
        : pSizeClamped;
      const kellyEdge = computeKellyEdge(p, b);
      if (kellyEdge <= 0) {
        // Task #391: SIZE_RESCUE_MIN1 used to turn this Kelly-zero into 1×
        // for BASIS_LAG_EDGE / LATE_ENTRY_ANCHOR when computeTradeEV netEV>0.
        // That silently overrode risk-safety sizing (paper would take a size
        // Kelly refused). Kelly-zero stays 0 on every path, paper=live.
        return {
          contracts: 0, limiter: "PORTFOLIO_RISK_KELLY_EDGE",
          detail: `fee-adjusted kellyEdge=${kellyEdge.toFixed(3)} <= 0 (p_size=${(p * 100).toFixed(1)}% [${pSizeDetail}], rawWinRate=${strategyWinRate !== undefined ? (strategyWinRate * 100).toFixed(0) + '%' : 'n/a'}, payoutRatio=${b.toFixed(2)}x)`,
        };
      }

      // Scale the risked % by conviction: full pct only at high confidence
      // AND real edge; smaller allocations when either is marginal.
      // Tiers recalibrated 2026-08-11: the previous floor (0.35 at the
      // qualifying minimum confidence, ~52-59) crushed effective risk for a
      // large share of live trades down to ~1.5-2% instead of the intended
      // 5-7%, which is the main reason many trades sized to just 1 contract.
      // New tiers keep the same shape (more conviction -> more size) but
      // raise every floor so a typical qualifying-to-strong trade lands in
      // the 5-7% band; combined with edgeMult (0.5-1.15x) the top tier tops
      // out under 8%, still comfortably inside the 9% hard cap.
      const confMult = confidence >= 78 ? 1.15 : confidence >= 68 ? 1.0 : confidence >= 60 ? 0.85 : 0.7;
      const edgeMult = Math.max(0.5, Math.min(1.15, 0.5 + Math.max(edge, 0) / 16));
      const basePct = this.config.portfolioRiskPct * confMult * edgeMult;

      // ── GO PHASE 1B — uMult cuts contract COUNT on estimation uncertainty ──
      // Phase 1A's p_size only gated whether to trade at all (kellyEdge sign,
      // above); it never reduced contract count, since this branch's count is
      // basePct-driven, not p-driven. uMult is a second, independent
      // multiplier on basePct so a 0-trade strategy and a well-established
      // strategy no longer size identically once both clear the entry gate.
      const { uMult, pHat, pLb } = computeSizeUncertaintyMult(liveN, liveWins);
      // GO — VOLUME AS RISK SCALAR (2026-08-18): applies strictly AFTER uMult
      // per LOCKS. Pure size scalar — never touches p/kellyEdge/EV above, so
      // it can't affect whether a trade clears the EV gate, only how big it
      // is once it has.
      // GO — VOLUME AS RISK SCALAR (2026-08-18): applies strictly AFTER uMult
      // per LOCKS — combined here via computePackCombinedMult's [0.15,1.15]
      // safety clamp, same as before. packSizeCapMult is now applied
      // SEPARATELY at the end via applyPackSizeCap (PACK-CAP-ON-ALL-BRANCHES
      // FIX, 2026-08-19) — a single helper call shared by every sizing
      // branch, rather than folded into this pre-floor combine — see that
      // helper's doc comment for the full rationale.
      const combinedMult = computePackCombinedMult(uMult, volumeSizeMult, 1);
      const effectivePct = basePct * combinedMult;

      const bal       = this.effectiveBalance();                    // cents
      const riskCents = bal * (effectivePct / 100);                 // cents to spend
      // Divide by fee-inclusive cost so the risked % reflects true capital at risk
      const netCostCeil = Math.ceil(netCost);
      const preClamp  = Math.floor(riskCents / netCostCeil);
      const preCapContracts = Math.max(0, Math.min(max, preClamp));
      const contracts = applyPackSizeCap(preCapContracts, packSizeCapMult);
      if (contracts < preCapContracts) {
        this.log("info", `[pack-cap] portfolio-risk branch: packSizeCapMult=${packSizeCapMult.toFixed(3)} reduced contracts ${preCapContracts} -> ${contracts}`);
      }
      this.log("info", `[size-u] ${strategyId ?? 'unknown'} n=${liveN} pHat=${Number.isFinite(pHat) ? pHat.toFixed(3) : 'n/a'} pLb=${Number.isFinite(pLb) ? pLb.toFixed(3) : 'n/a'} pSize=${pSizeClamped.toFixed(3)} uMult=${uMult.toFixed(3)} volumeSizeMult=${volumeSizeMult.toFixed(3)} packSizeCapMult=${packSizeCapMult.toFixed(3)} combinedMult=${combinedMult.toFixed(3)} basePct=${basePct.toFixed(3)}% effectivePct=${effectivePct.toFixed(3)}% preCapContracts=${preCapContracts} contracts=${contracts}`);
      let limiter = "NONE";
      let detail  = `bal=${bal}¢ portfolioRiskPct=${this.config.portfolioRiskPct}% confMult=${confMult} edgeMult=${edgeMult.toFixed(2)}(edge=${edge.toFixed(1)}) ` +
        `basePct=${basePct.toFixed(2)}% uMult=${uMult.toFixed(3)}(n=${liveN}) volumeSizeMult=${volumeSizeMult.toFixed(3)} combinedMult=${combinedMult.toFixed(3)} effectivePct=${effectivePct.toFixed(2)}% riskCents=${riskCents.toFixed(1)}¢ netCost=${netCostCeil}¢ preCapContracts=${preCapContracts} packSizeCapMult=${packSizeCapMult.toFixed(3)} contracts=${contracts} max=${max}`;
      if (preClamp <= 0) {
        // Small-balance rescue: the % allocation rounds to 0, but the trade
        // already cleared the fee-adjusted EV gate above (kellyEdge > 0,
        // checked earlier in this function — untouched) and the account can
        // literally afford 1 contract. Don't skip a positive-EV trade purely
        // because the % math is too fine-grained for a small balance.
        // Does not touch PATH_GATE or any EV floor — only runs after both
        // have already passed. Still subject to the pack size cap below
        // (an enforced pack's cap applies even to the rescue floor).
        if (bal >= netCostCeil && max >= 1) {
          const rescued = applyPackSizeCap(1, packSizeCapMult);
          detail = `${effectivePct.toFixed(2)}% of $${(bal / 100).toFixed(2)} balance = ${riskCents.toFixed(1)}¢ can't afford 1 contract (${netCostCeil}¢), ` +
            `but fee-adjusted EV is positive (kellyEdge=${kellyEdge.toFixed(3)}) and balance covers it — sizing 1x ` +
            `(packSizeCapMult=${packSizeCapMult.toFixed(3)} -> ${rescued}x)`;
          if (rescued < 1) {
            this.log("info", `[pack-cap] portfolio-risk MIN_1_RESCUE: packSizeCapMult=${packSizeCapMult.toFixed(3)} reduced rescue contracts 1 -> ${rescued}`);
          }
          return { contracts: rescued, limiter: "PORTFOLIO_RISK_MIN_1_RESCUE", detail, uMult };
        }
        limiter = "PORTFOLIO_RISK_PCT_TOO_SMALL";
        detail  = `${effectivePct.toFixed(2)}% of $${(bal / 100).toFixed(2)} balance = ${riskCents.toFixed(1)}¢, but 1 contract costs ${netCostCeil}¢ ` +
          `(need ≥${((netCostCeil / bal) * 100).toFixed(2)}% effective risk pct; confMult=${confMult} edgeMult=${edgeMult.toFixed(2)} from edge=${edge.toFixed(1)}%, uMult=${uMult.toFixed(3)})`;
      } else if (contracts < preCapContracts) {
        limiter = "PACK_SIZE_CAP";
        detail  = `sized ${preCapContracts}x by portfolio risk %, capped to ${contracts}x by enforced pack (packSizeCapMult=${packSizeCapMult.toFixed(3)})`;
      } else if (preCapContracts < preClamp) {
        limiter = "MAX_CONTRACTS_CAP";
        detail  = `sized ${preClamp}x by portfolio risk %, capped to ${preCapContracts}x by maxContractsPerTrade=${max}`;
      }
      return { contracts, limiter, detail, uMult };
    }

    // ── Grok regime-aware tiered sizing (v6 + Grok upgrade #5) ───────────────
    if (this.config.useTieredSizing) {
      const bal = this.effectiveBalance();

      // Regime-aware base risk % (Grok): trending → more, high_vol → less
      const REGIME_RISK: Record<GrokRegime, number> = { trending: 0.045, ranging: 0.028, high_vol: 0.022, transitioning: 0.018, low_vol: 0.025 };
      const riskPct  = Math.min(this.config.baseRiskPct / 100, REGIME_RISK[regime] ?? 0.018);
      const baseRisk = bal * riskPct;
      const confMult = confidence >= 78 ? 1.0 : confidence >= 68 ? 0.75 : confidence >= 60 ? 0.50 : 0.35;
      const edgeMult = Math.min(1.15, 0.70 + Math.max(edge, 0) / 18);
      const guardMult = this.config.useDrawdownGuard ? this.drawdownGuardFactor() : 1;
      const riskBudget = baseRisk * confMult * edgeMult * guardMult;
      // Fee-inclusive cost per contract — dividing by bare entry price
      // systematically exceeded the intended risk %, worst at low prices.
      const netCostCeil = Math.ceil(kalshiNetCostCents(entryPriceCents));
      const preClamp    = Math.floor(riskBudget / netCostCeil);
      // Honest sizing: when the risk budget can't afford one contract, size is 0
      // (caller skips the trade) — never force capital in that the math rejects.
      const preCapContracts = Math.max(0, Math.min(max, preClamp));
      // PACK-CAP-ON-ALL-BRANCHES FIX (2026-08-19, SEV2): packSizeCapMult was
      // accepted as a parameter but never consumed by this branch, so an
      // enforced specialist pack's size cap (e.g. TRANSITION pack's 0.5x) was
      // silently bypassed whenever useTieredSizing was the active mode — the
      // cap only ever reached the usePortfolioRisk branch above. Applied here
      // via the shared applyPackSizeCap helper, AFTER contracts are computed
      // (same application point as every other branch), not folded into
      // riskBudget — packSizeCapMult<=1 always, so this can only shrink the
      // final count, never grow it.
      const contracts = applyPackSizeCap(preCapContracts, packSizeCapMult);
      if (contracts < preCapContracts) {
        this.log("info", `[pack-cap] tiered branch: packSizeCapMult=${packSizeCapMult.toFixed(3)} reduced contracts ${preCapContracts} -> ${contracts}`);
      }
      let limiter = "NONE";
      let detail  = `bal=${bal}¢ riskPct=${(riskPct * 100).toFixed(2)}% baseRisk=${baseRisk.toFixed(1)}¢ confMult=${confMult} edgeMult=${edgeMult.toFixed(2)} ` +
        `guardMult=${guardMult.toFixed(2)} riskBudget=${riskBudget.toFixed(1)}¢ netCost=${netCostCeil}¢ preCapContracts=${preCapContracts} packSizeCapMult=${packSizeCapMult.toFixed(3)} contracts=${contracts} max=${max}`;
      if (preClamp <= 0) {
        limiter = "TIERED_RISK_BUDGET_TOO_SMALL";
        detail  = `risk budget ${riskBudget.toFixed(1)}¢ can't afford 1 contract at ${netCostCeil}¢ ` +
          `(guardMult=${guardMult.toFixed(2)} — drawdown guard may be throttling)`;
      } else if (contracts < preCapContracts) {
        limiter = "PACK_SIZE_CAP";
        detail  = `sized ${preCapContracts}x by tiered risk budget, capped to ${contracts}x by enforced pack (packSizeCapMult=${packSizeCapMult.toFixed(3)})`;
      } else if (preCapContracts < preClamp) {
        limiter = "MAX_CONTRACTS_CAP";
        detail  = `sized ${preClamp}x by tiered risk budget, capped to ${preCapContracts}x by maxContractsPerTrade=${max}`;
      }
      return { contracts, limiter, detail };
    }

    // ── True half-Kelly (v5) — pure math in admission.computeContracts ────────
    if (!this.config.useKellyFraction) {
      // Legacy tier
      if (confidence >= 80) return { contracts: max, limiter: "NONE", detail: "legacy tier: conf>=80 -> max" };
      if (confidence >= 70) return { contracts: Math.max(0, Math.round(max * 0.67)), limiter: "NONE", detail: "legacy tier: conf>=70 -> 67% of max" };
      return { contracts: 0, limiter: "LEGACY_ECONOMICS", detail: "legacy tier: confidence does not justify a position" };
    }

    // GO PHASE 1B: uMult still computed here (needs liveN/liveWins); formula
    // (fractional Kelly 0.60 cap, b from fee-net, p = pWin/winRateAtPrice)
    // lives in admission.ts. TradingBot calls it — does not reimplement.
    const { uMult: kellyUMult, pHat: kellyPHat, pLb: kellyPLb } = computeSizeUncertaintyMult(liveN, liveWins);
    this.log("info", `[size-u] ${strategyId ?? 'unknown'} (dormant-Kelly-branch) n=${liveN} pHat=${Number.isFinite(kellyPHat) ? kellyPHat.toFixed(3) : 'n/a'} pLb=${Number.isFinite(kellyPLb) ? kellyPLb.toFixed(3) : 'n/a'} pSize=${pSizeClamped.toFixed(3)} uMult=${kellyUMult.toFixed(3)}`);
    const guardfactor = this.config.useDrawdownGuard ? this.drawdownGuardFactor() : 1;
    const kellyResult = computeKellyContracts({
      pWin: (typeof strategyWinRate === "number" && Number.isFinite(strategyWinRate))
        ? strategyWinRate
        : undefined,
      pSizeClamped,
      entryPriceCents,
      confidence,
      edge,
      balanceCents: this.effectiveBalance(),
      maxContracts: max,
      uMult: kellyUMult,
      volumeSizeMult,
      packSizeCapMult,
      guardfactor,
    });
    if (kellyResult.limiter === "PACK_SIZE_CAP") {
      this.log("info", `[pack-cap] dormant-Kelly branch: packSizeCapMult=${packSizeCapMult.toFixed(3)} reduced contracts`);
    }
    return kellyResult;
  }

  private effectiveMaxContracts(): number {
    if (!this.config.useCompoundMode) return this.config.maxContractsPerTrade;
    // Portfolio-% sizing (usePortfolioRisk, the default/primary sizing mode —
    // see computeContracts) already scales the contract count with account
    // size via portfolioRiskPct × balance; that IS the compounding mechanism.
    // The ratio-to-paperStartingBalanceCents scaling below predates
    // portfolio-risk mode and was calibrated for the legacy fixed-Kelly-count
    // sizing model. Layered on top of portfolio-risk sizing as a MIN-clamp
    // ceiling, it silently overrides the user's configured risk % with a
    // ceiling based on a $1,000 PAPER-MODE reference constant that has
    // nothing to do with real live capital: a live account under $1,000
    // (e.g. $103) got ceil'd to ~1-2 contracts no matter what 5%-of-balance
    // actually computed (confirmed live 2026-08-08 — 69/126 live trades sized
    // to exactly 1 contract despite portfolioRiskPct=5). Use the raw
    // configured ceiling instead so portfolioRiskPct is the only thing
    // controlling size; maxContractsPerTrade remains a safety ceiling and the
    // 9%-equity hard risk cap downstream still bounds worst-case exposure.
    if (this.config.usePortfolioRisk) return this.config.maxContractsPerTrade;
    const start = this.config.paperStartingBalanceCents;
    const bal   = this.config.paperMode ? this.paperVirtualBalanceCents : (this.accountBalance ?? start);
    const ratio = start > 0 ? bal / start : 1;
    const scaled = Math.min(20, Math.round(this.config.maxContractsPerTrade * ratio));
    // Floor at 1 whenever the base cap is configured positive. Compound mode's
    // balance-ratio scaling is meant to GROW the cap as equity compounds up —
    // not to silently disable trading. A live balance much smaller than
    // paperStartingBalanceCents (a paper-mode reference constant, unrelated to
    // real live capital) used to round this to 0, capping every trade to 0
    // contracts regardless of edge/confidence/win-rate (confirmed live 2026-08-06).
    return this.config.maxContractsPerTrade > 0 ? Math.max(0, scaled) : scaled;
  }

  /** Balance available to risk: total balance minus reserve pool */
  private effectiveBalance(): number {
    if (this.config.paperMode) {
      // Sweep S4/item 8: paper virtualCents is ALREADY net of the reserve lock
      // (recordSettlement debits it on each win), so subtracting the pool again
      // double-counted it and made size depend on uptime (pool reset to 0 on
      // restart). Reserve rate (15%) unchanged; only the double count removed.
      return Math.max(100, paperEffectiveBalanceCents(this.paperVirtualBalanceCents));
    }
    // Fallback to 0 (not paper starting balance) so live orders are blocked
    // rather than sized against fake paper money when balance is unresolved.
    return Math.max(100, (this.accountBalance ?? 0) - this.reservePoolCents);
  }

  /**
   * Daily loss circuit-breaker threshold, in cents. Added 2026-08-11: the cap
   * used to be a flat dailyLossCapCents value, which doesn't scale with
   * account size or position sizing. Now uses the LARGER of the flat cents
   * floor and a % of current effective balance, so the breaker stays
   * proportionate as the account grows (or as per-trade sizing is raised
   * toward the 5-7%-of-portfolio target) instead of tripping after a single
   * ordinary loss. Never smaller than the configured flat cents value, so
   * this can only loosen — never tighten — the previous behavior.
   */
  private effectiveDailyLossCapCents(): number {
    const pctCents = Math.round(this.effectiveBalance() * (this.config.dailyLossCapPct / 100));
    return Math.max(this.config.dailyLossCapCents, pctCents);
  }

  /**
   * DAILY-LOSS HALT COVERAGE FIX: single shared halt predicate for ALL
   * callers (15m evaluator, hourly evaluator, and the shared _placeOrderBody
   * admission point) — reads the same todayStats.pnlCents / dailyLossCapCents
   * / dailyLossCapPct semantics the 15m path and post-settlement path already
   * used, via the pure evaluateDailyLossHalt() so the comparison itself is
   * unit-testable without instantiating the bot class. `now` is accepted (not
   * currently used inside the comparison — todayStats' own date-rollover in
   * tick() already handles the day boundary) so every call site evaluates
   * against a single, explicit instant rather than an implicit `Date.now()`
   * buried in the predicate, keeping this and any future time-based logic
   * here consistent across all call sites.
   */
  /**
   * Daily halt is BOT fills only (todayStats). Manual Kalshi / fillOrigin=manual
   * never moves todayStats and must never trip DAILY_LOSS_HALT.
   * paperStats / overall stay the combined display book (bot + manual).
   * Do not copy paperStats into todayStats on bounce/restore — that re-imported
   * manuals (and stale session tape) into the halt.
   */
  private dayPnlForHalt(): number {
    // Paper desk: halt must follow paperStats (persisted across bounce). Using
    // todayStats alone zeroed the halt on restart while the ledger stayed deep
    // red (display −4911¢ vs cap 3000¢) — freeze/book lie. Live stays bot-only
    // todayStats so manuals never trip DAILY_LOSS_HALT.
    return this.config.paperMode ? this.paperStats.pnlCents : this.todayStats.pnlCents;
  }

  /**
   * P&L the daily-loss halt compares against the cap: bot fills only, fee-net,
   * current ET day (todayStats; rolls at ET midnight in tick). Paper and live
   * use the same basis. Paper re-seeds todayStats from the tape on start() so a
   * restart cannot clear a same-day halt. (dayPnlForHalt() is unchanged and
   * still feeds modeState/sizing: paperStats in paper, todayStats live.)
   */
  private haltDayPnlCents(): number {
    return this.todayStats.pnlCents;
  }

  private isDailyLossHalted(now: number = Date.now()): boolean {
    void now;
    // Stellar 2026-09-26 (reverses the 2026-09-07 paper carve-out): paper halts
    // at the same daily cap as live. Cap values unchanged.
    return evaluateDailyLossHalt(this.haltDayPnlCents(), this.effectiveDailyLossCapCents());
  }

  /** ET-midnight rollover of the daily counters (daily-loss halt resets here). */
  private rollTodayStatsIfNewEtDay(today: string): void {
    if (this.todayStats.date !== today) {
      this.todayStats = { pnlCents: 0, wins: 0, losses: 0, date: today };
      // Reset OTM stats daily alongside todayStats so expectancy figures stay fresh
      this.otmStats = { wins: 0, losses: 0, pnlCents: 0, totalPaidCents: 0, avgWinMultiple: null, _winMultipleSum: 0, _winCount: 0 };
    }
  }

  /** Status surface for the daily-loss halt (dashboard / chat / verification). */
  getDailyLossHaltStatus(): { halted: boolean; dayPnlCents: number; capCents: number; etDay: string; basis: string; resets: string } {
    return {
      halted: this.isDailyLossHalted(),
      dayPnlCents: this.haltDayPnlCents(),
      capCents: this.effectiveDailyLossCapCents(),
      etDay: this.todayStats.date || etDateKey(),
      basis: "bot fills only, fee-net realized, ET calendar day",
      resets: "counter resets at ET midnight; a halt suspends the bot, which needs Start (or a restart) on the new ET day",
    };
  }

  /**
   * PnL fed into applyHardRiskLimits / canScaleIntoPosition / entryPathAndSize /
   * applyRiskProfileSizing 18% circuits for NEW entry sizing.
   * Paper: use ET-day todayStats (not lifetime paperStats) so deep lifetime red
   * cannot SIZING_ZERO the hunt (the daily halt itself uses haltDayPnlCents()).
   * Live: identical to dayPnlForHalt() → todayStats. Do not change maxDailyLossPct
   * (0.18) or maxRiskPctPerTrade (0.09). dayPnlForHalt() still returns paperStats
   * in paperMode for display.
   */
  private dayPnlForHardRiskLimits(): number {
    if (this.config.paperMode) return this.todayStats.pnlCents;
    return this.dayPnlForHalt();
  }

  /**
   * Continuous drawdown scaler — returns a multiplier (0–1) for position sizing.
   *
   * Replaces the old binary 3-step function with a smooth linear taper so that
   * exposure reduces *gradually* as losses accumulate rather than snapping to
   * fixed fractions. This is consistent with continuous-time Kelly theory and
   * avoids the "cliff" effect where a single loss crosses a threshold and cuts
   * size in half immediately.
   *
   *   0% → onset:  factor = 1.0   (full size)
   *   onset → guard: linearly tapers to 0 (onset = guard / 4, e.g. 5% when guard=20%)
   *   ≥ guard:     factor = 0.0   (hard stop — no new entries)
   */
  private drawdownGuardFactor(): number {
    const bal  = this.effectiveBalance();
    const peak = this.peakBalanceCents;
    if (peak <= 0) return 1;
    const ddPct = (peak - bal) / peak * 100;
    const guard = this.config.drawdownGuardPct;  // e.g. 20
    const onset = guard / 4;                     // e.g.  5 — taper begins here
    if (ddPct <= onset) return 1;                               // full size
    if (ddPct >= guard) return 0;                               // hard stop
    return 1 - (ddPct - onset) / (guard - onset);              // smooth linear
  }

  // ── Daily compounding target engine ──────────────────────────────────────────
  // Called once per tick. Loads/creates today's snapshot row, recomputes the
  // engine state, and persists end-of-day equity at most once per 60 s.
  private async refreshDailyTarget(now = new Date()) {
    if (!this.config.useDailyTarget) { this.lastDailyTarget = null; return; }
    const nowMs = now.getTime();
    const date  = etDateKey(now);
    const paper = this.config.paperMode;
    // Live mode: wait for a real balance fetch. effectiveBalance() floors at
    // 100¢ even when accountBalance is null, which would latch a bogus $1.00
    // compounding base for the whole day.
    if (!paper && this.accountBalance === null) return;
    const bal = this.effectiveBalance();
    if (bal <= 100) return;   // unresolved/dust balance — never snapshot it as the day's base

    // Day roll / paper-mode switch → (re)load the snapshot row
    if (!this.dailyTargetDay || this.dailyTargetDay.date !== date || this.dailyTargetDay.paper !== paper) {
      if (this.dailyTargetDay?.loading) return;   // load already in flight
      // Throttle retries to once per 60 s when the DB is unreachable, so a
      // down database doesn't produce a warn log on every 500 ms tick.
      if (nowMs - this.dailyTargetRetryTs < 60_000) return;
      this.dailyTargetRetryTs = nowMs;
      this.dailyTargetDay = { date, paper, startEquityCents: bal, peakEquityCents: bal, targetHitToday: false, loading: true, lastPersistTs: 0, lastReconciledBalanceCents: bal, lastReconcileAt: new Date(now) };
      try {
        const row = await loadOrCreateDayRow({ date, paperMode: paper, equityCents: bal });
        this.dailyTargetDay = {
          date, paper, startEquityCents: row.startEquityCents,
          peakEquityCents: Math.max(row.peakEquityCents, bal),
          targetHitToday: row.targetHit, loading: false, lastPersistTs: nowMs,
          lastPersistedPeak: row.peakEquityCents,
          // Start reconciling from the CURRENT balance, not the historical
          // startEquityCents — this session should only flag cash flows that
          // happen from now on, not re-litigate the whole day's trading P&L.
          lastReconciledBalanceCents: bal, lastReconcileAt: new Date(now),
        };
        // A successful row load is the authoritative boundary for both the
        // date and paper/live mode. Do not let a prior failed-load retry
        // throttle block an immediate mode switch or ET day roll, and never
        // carry yesterday's unpersisted latch into a fresh row.
        this.dailyTargetRetryTs = 0;
        this.dailyTargetLatchDirty = false;
        if (this.dailyTargetLoadFailed) {
          this.log("info", "✅ Daily target snapshot loaded after retry — entries unblocked.");
        }
        this.dailyTargetLoadFailed = false;
        this.log("info",
          `🎯 Daily target: base $${(row.startEquityCents / 100).toFixed(2)} → ` +
          `goal $${(row.startEquityCents * (1 + this.config.dailyTargetPct / 100) / 100).toFixed(2)} (+${this.config.dailyTargetPct}%)`
        );
      } catch (err) {
        // DB unreachable — clear so we retry (throttled); engine stays inactive.
        // Fail CLOSED while useDailyTarget is on: without this flag,
        // lastDailyTarget stayed at its previous value (null on first run)
        // and dailyTargetEntryBlock() saw no block, letting orders proceed
        // with the daily-target/protect-mode layer silently absent for the
        // whole outage.
        this.dailyTargetDay = null;
        this.dailyTargetLoadFailed = true;
        this.log("warn", `Daily target snapshot failed: ${(err as Error).message} — blocking entries until it loads (fail-closed).`);
        return;
      }
    }
    const day = this.dailyTargetDay;
    if (!day || day.loading) return;

    // ── Cash-flow reconciliation ────────────────────────────────────────────
    // A deposit or withdrawal moves `bal` without any trade settling, which
    // used to read as a trading gain/loss and could falsely trip the target
    // latch (confirmed live 2026-08-10: an $88 deposit registered as an 82%
    // daily gain and stood the bot down). Compare the balance move since the
    // last check against realized P&L from trades that settled in between —
    // any unexplained gap is an external cash flow, so fold it straight into
    // the baseline (and peak) instead of letting it count toward the target.
    if (bal !== day.lastReconciledBalanceCents) {
      try {
        const settledRows = await db.select({ pnl: botTrades.pnlCents })
          .from(botTrades)
          .where(and(eq(botTrades.isPaper, paper), gt(botTrades.settledAt, day.lastReconcileAt)));
        const realizedSinceLastCheck = settledRows.reduce((sum, r) => sum + (r.pnl ?? 0), 0);
        const reconcile = computeCashFlowReconciliation({
          balanceCents:                bal,
          lastReconciledBalanceCents:  day.lastReconciledBalanceCents,
          realizedSinceLastCheckCents: realizedSinceLastCheck,
          startEquityCents:            day.startEquityCents,
          peakEquityCents:             day.peakEquityCents,
        });
        if (reconcile.isExternalFlow) {
          const kind = reconcile.externalFlowCents > 0 ? "deposit" : "withdrawal";
          this.log("info",
            `💵 Detected external ${kind} of $${(Math.abs(reconcile.externalFlowCents) / 100).toFixed(2)} — ` +
            `re-baselining daily target so it isn't counted as a trading gain/loss.`
          );
          day.startEquityCents = reconcile.newStartEquityCents;
          day.peakEquityCents  = reconcile.newPeakEquityCents;
          // Ledger entry for the ROI/reporting side (separate from the
          // instant re-baseline above, which already happened synchronously
          // and must not wait on this). This used to be fire-and-forget with
          // only a warn log on failure — a transient DB hiccup meant the
          // detected flow was silently lost from the ledger forever (the
          // re-baseline still happened, but nothing recorded why). Now
          // awaited with one retry; a still-failing insert is logged loudly
          // (error, not warn) with enough detail to hand-enter the row later.
          try {
            await insertAutoCashFlowEvent({
              ts:                 day.lastReconcileAt,
              paperMode:          paper,
              amountCents:        reconcile.externalFlowCents,
              balanceBeforeCents: day.lastReconciledBalanceCents,
              balanceAfterCents:  bal,
            });
          } catch (firstErr) {
            try {
              await insertAutoCashFlowEvent({
                ts:                 day.lastReconcileAt,
                paperMode:          paper,
                amountCents:        reconcile.externalFlowCents,
                balanceBeforeCents: day.lastReconciledBalanceCents,
                balanceAfterCents:  bal,
              });
            } catch (secondErr) {
              this.log("error",
                `Cash-flow ledger insert failed twice — flow NOT recorded (ts=${day.lastReconcileAt.toISOString()}, ` +
                `amountCents=${reconcile.externalFlowCents}, paper=${paper}): ${(secondErr as Error).message} ` +
                `(first attempt: ${(firstErr as Error).message})`
              );
            }
          }
        }
      } catch (err) {
        this.log("warn", `Daily target cash-flow reconcile failed: ${(err as Error).message}`);
      }
      day.lastReconciledBalanceCents = bal;
      day.lastReconcileAt = new Date(now);
    }

    // Track today's high-water mark — give-back cap is measured from here.
    if (bal > day.peakEquityCents) day.peakEquityCents = bal;

    const engine = computeTargetEngine({
      startEquityCents:   day.startEquityCents,
      currentEquityCents: bal,
      peakEquityCents:    day.peakEquityCents,
      targetPct:          this.config.dailyTargetPct,
      targetHitToday:     day.targetHitToday,
      protectBehavior:    this.config.protectModeBehavior,
      giveBackCapPct:     this.config.giveBackCapPct,
      riskProfile:        this.lastModeState?.riskProfile ?? 'BALANCED',
    });
    const justHitTarget = engine.targetHitToday && !day.targetHitToday;
    if (justHitTarget) {
      day.targetHitToday = true;
      this.log("settle",
        `🏆 DAILY TARGET HIT — +${this.config.dailyTargetPct}% reached ` +
        `($${(day.startEquityCents / 100).toFixed(2)} → $${(bal / 100).toFixed(2)}). ` +
        (this.config.protectModeBehavior === 'stand_down'
          ? 'Standing down for the rest of the day to protect gains.'
          : 'Protect mode: A+ setups only at 0.3× size.')
      );
    }
    this.lastDailyTarget = { date: day.date, ...engine };

    // ── Persistence ───────────────────────────────────────────────────────────
    // The target-hit latch and post-hit peaks MUST be written durably right
    // away: a restart before a deferred write would reload targetHit=false and
    // resume trading, bypassing protect mode entirely (and losing the
    // high-water mark the give-back cap is measured from).
    const peakGrewPostHit = day.targetHitToday && day.peakEquityCents > (day.lastPersistedPeak ?? 0);
    const latchRetry      = this.dailyTargetLatchDirty;   // previous latch write failed — keep retrying
    if (justHitTarget || latchRetry || peakGrewPostHit || nowMs - day.lastPersistTs > 60_000) {
      day.lastPersistTs      = nowMs;
      day.lastPersistedPeak  = day.peakEquityCents;
      const write = updateDayRow({
        date: day.date, paperMode: day.paper, endEquityCents: bal,
        startEquityCents: day.startEquityCents, peakEquityCents: day.peakEquityCents,
        targetHit: day.targetHitToday,
      });
      if (justHitTarget || latchRetry) {
        // Block the tick on the latch write — this is the one persistence
        // moment that must not be lost to a crash/restart. On failure, fail
        // CLOSED: set the dirty flag (blocks all entries) and retry next tick.
        const stillDirty = await persistLatchDurably(write);
        if (!stillDirty && this.dailyTargetLatchDirty) {
          this.log("info", "✅ Daily target latch persisted after retry — entries unblocked.");
        }
        if (stillDirty) {
          this.log("warn", "Daily target latch persist FAILED — blocking entries until durable.");
        }
        this.dailyTargetLatchDirty = stillDirty;
      } else {
        void write.catch(() => { /* transient DB error — retried next cycle */ });
      }
    }
  }

  // ── Signal evaluation ─────────────────────────────────────────────────────────

  /**
   * Single source of truth for the effective (tighten-only) settlement-hold
   * policy at this instant: the static config value, or ARIA's fresh
   * override if it is stricter. Every settlement-hold consumer — the entry
   * EV/pre-trade-sim gates in evaluateEntry()/_placeOrderBody(), and the
   * open-position hold engagement in monitorOpenTrade() — must call this
   * instead of reading `this.config.settlementHold*` directly, so an
   * ARIA-shrunk window can never be "seen" by one consumer (e.g. an EV gate
   * that assumes a hold will happen) while another consumer (the actual hold
   * engagement) uses a different, unshrunk window.
   */
  private getEffectiveSettlementHold(): { secsThreshold: number; minProb: number } {
    const setupAi = this.config.useExpertAgent ? expertAgent.getSetupControlOverrides() : null;
    if (setupAi) this.lastAgentSetupControls = setupAi;
    const secsResult = applyTightenOnly(
      this.config.settlementHoldSecsThreshold, setupAi?.settlementHoldSecsThreshold, "lower-is-tighter",
    );
    reportIfLoosened("settlementHoldSecsThreshold", "ARIA", this.config.settlementHoldSecsThreshold,
      setupAi?.settlementHoldSecsThreshold ?? this.config.settlementHoldSecsThreshold, secsResult);
    const minProbResult = applyTightenOnly(
      this.config.settlementHoldMinProb, setupAi?.settlementHoldMinProb, "higher-is-tighter",
    );
    reportIfLoosened("settlementHoldMinProb", "ARIA", this.config.settlementHoldMinProb,
      setupAi?.settlementHoldMinProb ?? this.config.settlementHoldMinProb, minProbResult);
    const minProbCap = capToManualBoundary(minProbResult.value, this.config.settlementHoldMinProb, this.config.autoMode, "higher-is-tighter");
    if (minProbCap.capped) {
      console.warn(`[manual-floor-guard] ARIA tightened settlementHoldMinProb to ${minProbResult.value} while autoMode=false — capped to manual ${this.config.settlementHoldMinProb}`);
    }
    return { secsThreshold: secsResult.value, minProb: minProbCap.value };
  }

  /**
   * Single source of truth for the effective (tighten-only) entry-window
   * bounds: static config, narrowed by autoMode's per-tick auto-tuner, then
   * narrowed further by the adaptive-condition classifier's overlay (the
   * same two inputs evaluateEntry() merges into `eff`/`condEff`). Both the
   * live entry gate and any external diagnostic (agent tools, chat) must
   * call this instead of reading tradeWindowMinMin/MaxMin off config or
   * autoSettings directly, or they will drift from whichever tightening is
   * actually active this tick.
   */
  private computeEffectiveWindow(): { minMin: number; maxMin: number; tightenedByCondition: boolean } {
    // autoMode is ADAPTATION — never take the window from lastAutoSettings
    // (old composer used to cut the operator window). Condition overlay may
    // still tighten below.
    let minMin = this.config.tradeWindowMinMin;
    let maxMin = this.config.tradeWindowMaxMin;
    const overlay = this.lastAdaptiveCondition?.overlay;
    let tightenedByCondition = false;
    if (overlay) {
      const minR = applyTightenOnly(minMin, overlay.tradeWindowMinMin, "higher-is-tighter");
      reportIfLoosened("tradeWindowMinMin", "condition-adapter", minMin, overlay.tradeWindowMinMin, minR);
      const maxR = applyTightenOnly(maxMin, overlay.tradeWindowMaxMin, "lower-is-tighter");
      reportIfLoosened("tradeWindowMaxMin", "condition-adapter", maxMin, overlay.tradeWindowMaxMin, maxR);
      tightenedByCondition = minR.value !== minMin || maxR.value !== maxMin;
      minMin = minR.value;
      maxMin = maxR.value;
    }
    return { minMin, maxMin, tightenedByCondition };
  }

  /** The auto-mode baseline that the next entry evaluation starts from.
   *  autoMode is ADAPTATION — never spread lastAutoSettings over operator floors. */
  private getEntryFilterBaseline(): BotConfig {
    return this.config;
  }

  /**
   * Derive dashboard state from a fresh ARIA read, rather than from a value
   * cached by one branch of evaluateEntry(). This keeps status correct while
   * the bot is disabled, in a position, or returns before the agent block.
   */
  private getEffectiveAgentFilterOverrideStatus(): AgentFilterOverrideStatus | null {
    const baseline = this.getEntryFilterBaseline();
    const ai = this.config.useExpertAgent ? expertAgent.getEntryFilterOverrides() : null;
    const resolved = resolveEffectiveAgentEntryFilters(baseline, this.config, ai);

    // minProbEdge is additionally tightened by the most recently committed
    // condition overlay. Reflect that final gate before deciding whether ARIA
    // has an observable effect on this row.
    const conditionMinProbEdge = this.lastAdaptiveCondition?.overlay.minProbEdge;
    const baselineMinProbEdge = conditionMinProbEdge === undefined
      ? baseline.minProbEdge
      : Math.max(baseline.minProbEdge, conditionMinProbEdge);
    const effectiveMinProbEdge = conditionMinProbEdge === undefined
      ? resolved.values.minProbEdge
      : Math.max(resolved.values.minProbEdge, conditionMinProbEdge);
    const values = { ...resolved.values, minProbEdge: effectiveMinProbEdge };
    const ariaControlled = {
      ...resolved.ariaControlled,
      minProbEdge: effectiveMinProbEdge !== baselineMinProbEdge,
    };

    return Object.values(ariaControlled).some(Boolean)
      ? { values, ariaControlled }
      : null;
  }

  private async evaluateEntry() {
    // GO — SPECIALIST REGIME SYSTEM Phase 0 (DecisionTrace): see
    // _evaluateHourlyTickBody() for why this is a local const + closure
    // rather than a shared mutable field (mutual exclusion with the hourly
    // path isn't guaranteed across the awaits inside this function).
    const traceId = generateTraceId();
    const skip = makeTraceScopedSkip(this.logSkippedDecision.bind(this), { traceId });
    // autoMode is ADAPTATION — baseline is always operator config (composer fail-closed).
    let eff = this.getEntryFilterBaseline();
    // Capture the market before any pre-selection gate. These gates can reject
    // a live decision before strategy selection, so every return emits either
    // a directional market candidate or an explicit non-tradable SYSTEM row.
    // R4 — freshest valid same-ticker source (WS, or newer L2 top when WS lags >2¢).
    const tick = kalshiWS.getLatestForEntry();
    if (tick && kalshiWS.getEntryQuoteStats().lastOrigin === "l2") {
      const m = this.logThrottle.gate(`${tick.ticker}|ENTRY_QUOTE_L2`, `📗 entry_quote_l2: judged on L2 top ${tick.yesBid}/${tick.yesAsk}¢ (WS quote lagged)`);
      if (m) this.log("info", m);
    }
    const secs = getSecsRemaining();
    const systemSkipContext = {
      ticker: "SYSTEM:FEED_UNAVAILABLE",
      // bot_trade_skips has a legacy binary side column. decisionScope=SYSTEM
      // below makes it explicit that this is not a synthetic YES candidate.
      side: "yes" as const,
      strategyId: "SYSTEM:FEED_UNAVAILABLE",
      entryPriceCents: 0,
      confidence: 0,
      secsRemaining: secs,
      scope: "system" as const,
    };
    const logEarlySkip = (code: string, reason: string): void => {
      // A feed-unavailable gate still belongs in the decision distribution.
      // Record it as an explicit system event rather than fabricating a market
      // ticker, price, or directional candidate.
      if (!tick) {
        skip(code, [reason], systemSkipContext);
        return;
      }
      // Before strategy selection neither side is more honest than the other.
      // Record both real directional candidates from the current market.
      for (const candidate of [
        { side: "yes" as const, ask: tick.yesAsk },
        { side: "no" as const, ask: tick.noAsk },
      ]) {
        skip(code, [reason], {
          ticker: tick.ticker,
          side: candidate.side,
          entryPriceCents: Number.isFinite(candidate.ask) ? candidate.ask : 0,
          confidence: 0,
          secsRemaining: secs,
          floorStrike: tick.floorStrike,
        });
      }
    };

    // A persisted strategyOverride and disabledStrategies entry can survive
    // independently across a restart. Stop before the rest of the entry
    // pipeline and surface the exact conflict rather than reporting a generic
    // regime/no-signal result.
    if (isStrategyOverrideDisabled(this.config.strategyOverride, this.config)) {
      this.lastSignalDesc =
        `Locked strategy ${this.config.strategyOverride} is disabled — re-enable it or unlock the bot`;
      logEarlySkip("STRATEGY_OVERRIDE_DISABLED", this.lastSignalDesc);
      return;
    }

    // ── Expert Agent entry-filter control ─────────────────────────────────────
    // The same resolver supplies the dashboard status. A raw ARIA proposal is
    // never treated as active until it survives every tighten-only/manual cap.
    const agentEntryFilters = resolveEffectiveAgentEntryFilters(
      eff,
      this.config,
      this.config.useExpertAgent ? expertAgent.getEntryFilterOverrides() : null,
    );
    eff = { ...eff, ...agentEntryFilters.values };

    // ── Expert Agent setup-control overrides (tighten-only) ───────────────────
    // MTF confluence bar and the settlement-hold window used by this tick's
    // entry gates. Each field is only ever moved TOWARD the safer direction
    // versus the static config — Math.max for the long-side MTF floor, Math.min
    // for the short-side MTF ceiling and the hold window — so a fresh AI read
    // can only make entry gating stricter, never looser, than the operator's
    // own settings. A stale/absent assessment leaves `eff` at its static value.
    // settlementHoldSecsThreshold comes from getEffectiveSettlementHold() — the
    // same single source _placeOrderBody() and monitorOpenTrade() use — so an
    // ARIA-shrunk hold window can never be assumed by the entry EV gate while a
    // different (unshrunk) window governs whether the hold actually engages.
    if (this.config.useExpertAgent) {
      const setupAi = expertAgent.getSetupControlOverrides();
      if (setupAi) {
        const mtfLongR = applyTightenOnly(eff.minMTFScoreForLong, setupAi.minMTFScoreForLong, "higher-is-tighter");
        reportIfLoosened("minMTFScoreForLong", "ARIA", eff.minMTFScoreForLong,
          setupAi.minMTFScoreForLong ?? eff.minMTFScoreForLong, mtfLongR);
        const mtfLongCap = capToManualBoundary(mtfLongR.value, this.config.minMTFScoreForLong, this.config.autoMode, "higher-is-tighter");
        if (mtfLongCap.capped) {
          console.warn(`[manual-floor-guard] ARIA tightened minMTFScoreForLong to ${mtfLongR.value} while autoMode=false — capped to manual ${this.config.minMTFScoreForLong}`);
        }
        mtfLongR.value = mtfLongCap.value;
        const mtfShortR = applyTightenOnly(eff.maxMTFScoreForShort, setupAi.maxMTFScoreForShort, "lower-is-tighter");
        reportIfLoosened("maxMTFScoreForShort", "ARIA", eff.maxMTFScoreForShort,
          setupAi.maxMTFScoreForShort ?? eff.maxMTFScoreForShort, mtfShortR);
        const mtfShortCap = capToManualBoundary(mtfShortR.value, this.config.maxMTFScoreForShort, this.config.autoMode, "lower-is-tighter");
        if (mtfShortCap.capped) {
          console.warn(`[manual-floor-guard] ARIA tightened maxMTFScoreForShort to ${mtfShortR.value} while autoMode=false — capped to manual ${this.config.maxMTFScoreForShort}`);
        }
        mtfShortR.value = mtfShortCap.value;
        eff = { ...eff, minMTFScoreForLong: mtfLongR.value, maxMTFScoreForShort: mtfShortR.value };
        this.lastAgentSetupControls = setupAi;
      } else {
        this.lastAgentSetupControls = null;
      }
    }
    {
      const effHold = this.getEffectiveSettlementHold();
      eff = { ...eff, settlementHoldSecsThreshold: effHold.secsThreshold, settlementHoldMinProb: effHold.minProb };
    }

    // computeEffectiveWindow() folds in BOTH auto-tuning and the adaptive
    // condition classifier's overlay (from last tick — the same one-tick
    // staleness `eff` above already tolerates for autoSettings). Gating here
    // on the raw eff.tradeWindow* would silently ignore any window the
    // condition classifier has tightened, so this is the only window check —
    // do not reintroduce a second one elsewhere using eff/condEff directly.
    const window = this.computeEffectiveWindow();
    const minS = window.minMin * 60;
    const maxS = window.maxMin * 60;
    void minS; void maxS; void window; // window retained for status/telemetry only

    // entry-guards organ predicates (TIME_GATE / DAILY_LOSS / STALE / REST).
    // DAILY_TARGET / FEED_UNAVAILABLE / WS_DEGRADED stay here (side-effect order).
    {
      const tg = timeGateLast60s(secs);
      if (tg) {
        this.lastSignalDesc = tg.reason;
        logEarlySkip(tg.code, tg.reason);
        return;
      }
    }

    {
      // Stellar 2026-09-26: paper halts like live (2026-09-07 carve-out reversed).
      const halt = dailyLossHaltBlock(this.haltDayPnlCents(), this.effectiveDailyLossCapCents());
      if (halt) {
        this.lastSignalDesc = halt.reason;
        this.log("warn", "🛑 Daily loss cap reached — auto-suspending bot");
        this.suspend();
        logEarlySkip(halt.code, halt.reason);
        return;
      }
    }

    // ── Daily target engine — protect-mode entry block ────────────────────────
    // Runs AFTER the loss-cap circuit breaker (precedence: breakers > profile >
    // target engine). sizeMult === 0 means stand-down or give-back cap breached.
    const dailyBlock = dailyTargetEntryBlock(this.lastDailyTarget, this.dailyTargetLatchDirty, this.dailyTargetLoadFailed);
    if (dailyBlock) {
      this.lastSignalDesc = dailyBlock;
      logEarlySkip("DAILY_TARGET_BLOCK", dailyBlock);
      return;
    }
    // Fail-closed initialization: when the engine is enabled but today's base
    // row could not be loaded/created (DB outage, balance unresolved), we do
    // NOT know whether the target was already hit today — a restart during a
    // DB outage must not bypass protect mode. Block entries until it loads.
    if (this.config.useDailyTarget && (!this.dailyTargetDay || this.dailyTargetDay.loading)) {
      this.lastSignalDesc = "Daily target base not loaded — entries paused (fail-closed)";
      logEarlySkip("DAILY_TARGET_UNINITIALIZED", this.lastSignalDesc);
      return;
    }

    if (!tick) {
      this.lastSignalDesc = "No Kalshi data";
      skip("FEED_UNAVAILABLE", [this.lastSignalDesc], systemSkipContext);
      return;
    }

    // Pause entries when WS is persistently failing. Paper proves live:
    // evidence must not be built on a dead book. Stale-quote gate is already
    // identical (isFeedStaleForEntry ignores paperMode).
    if (this.wsDegraded) {
      this.lastSignalDesc = "WS degraded — entries paused";
      logEarlySkip("WS_DEGRADED", this.lastSignalDesc);
      return;
    }

    // Stale-tick / REST gates via entry-guards organ. Side effects stay here.
    const tickAgeMs  = Date.now() - tick.ts;
    const quoteAgeMs = Date.now() - (tick.quoteTs || 0);
    {
      const stale = feedStaleBlock(tickAgeMs, quoteAgeMs, this.config.paperMode === true);
      if (stale) {
        this.lastSignalDesc = stale.reason;
        if (Date.now() - this.lastStaleForceReconnectAt > 10_000) {
          this.lastStaleForceReconnectAt = Date.now();
          // Quote-only stale (fresh msg / quiet book / rollover gap): REST +
          // refreshMarket heal — do NOT thrash WS. Msg silence: REST heal + reconnect.
          const msgDead = tickAgeMs > FEED_STALE_TICK_MS;
          this.log(
            "warn",
            `⚡ Entry gate saw stale feed (msg ${(tickAgeMs/1000).toFixed(1)}s, quote ${(quoteAgeMs/1000).toFixed(1)}s) — ` +
              (msgDead ? "REST heal + WS reconnect" : "REST/rollover heal (quote-only)"),
          );
          kalshiWS.kickQuoteRecovery({ reconnectWs: msgDead });
        }
        logEarlySkip(stale.code, stale.reason);
        return;
      }
    }
    // Feed passed STALE_QUOTE — clear leftover UI so a prior "Quote stale …"
    // cannot stick while evaluateEntry continues (later skips overwrite).
    if (typeof this.lastSignalDesc === "string" && this.lastSignalDesc.startsWith("Quote stale")) {
      this.lastSignalDesc = "Feed fresh — evaluating…";
    }
    {
      const rest = restNotLiveBlock(this.config.paperMode === true, (tick as { source?: string }).source);
      if (rest) {
        this.lastSignalDesc = rest.reason;
        logEarlySkip(rest.code, rest.reason);
        return;
      }
    }

    // Keep mid prices for display / probability checks; use ask for order pricing.
    const { yesPrice, noPrice, yesBid, yesAsk, noBid, noAsk, floorStrike, ticker } = tick;
    const v  = this.currentVelocity;
    const v3 = this.threeMinVelocity;

    // 15m product completeness: this path is KXBTC15M only. Hourly KXBTCD
    // and perps must not evaluate here even if duration is missing/15.
    // enable1HContracts does not unlock this path — hourly has its own tick.
    {
      const productGate = is15mDeskEvaluateAllowed({
        ticker,
        enable1HContracts: this.config.enable1HContracts,
        enable1HLive: this.config.enable1HLive,
      });
      if (!productGate.ok) {
        this.lastSignalDesc = `15m desk refuses ${ticker} (${productGate.reason})`;
        logEarlySkip("NOT_15M_PRODUCT", this.lastSignalDesc);
        return;
      }
    }

    if (this.prices.length < 4) {
      this.lastSignalDesc = "Building price buffer…";
      logEarlySkip("PRICE_BUFFER_WARMUP", this.lastSignalDesc);
      return;
    }
    const currentPrice = this.prices[this.prices.length - 1].price;

    const { isStalling: stalling, stallStrength } = detectStallInfo(this.prices);
    this.lastStalling = stalling;

    // ── Buffer staleness guard (entry) ────────────────────────────────────────
    // If the most recent BTC price tick is older than 30 s the realized-vol
    // estimate may be misleading — potentially allowing an entry that should be
    // blocked. Fall back to a conservative neutral vol (same default used when
    // the buffer is too short) and log once per stale period.
    const entryLastTickAgeMs = this.prices.length > 0
      ? Date.now() - this.prices[this.prices.length - 1].ts
      : Infinity;
    const entryBufStale = entryLastTickAgeMs > 30_000;
    if (entryBufStale) {
      // FAIL CLOSED: a stale price buffer means the realized-vol estimate and
      // the probability model are built on old data. Substituting a synthetic
      // low vol makes the model MORE confident exactly when data is worst —
      // block new entries instead. Open-trade management continues elsewhere.
      if (!this.volStaleEntryLogged) {
        this.log("warn",
          `[entry] Vol buffer stale (last tick ${(entryLastTickAgeMs / 1000).toFixed(1)}s ago) — ` +
          `entries blocked until fresh BTC data arrives (fail-closed)`
        );
        this.volStaleEntryLogged = true;
      }
      this.lastSignalDesc = `BTC price buffer stale (${(entryLastTickAgeMs / 1000).toFixed(0)}s) — entries paused (fail-closed)`;
      logEarlySkip("STALE_PRICE_BUFFER", this.lastSignalDesc);
      return;
    } else {
      this.volStaleEntryLogged = false;
    }
    const annualVol      = realizedVolFromBuffer(this.prices);
    const minsLeft       = secs / 60;
    const { prob, edge } = probabilityEdge(currentPrice, floorStrike, annualVol, minsLeft);
    this.lastEdge        = edge;
    // lastModelProb is winRateAtPrice at the traded ask — never N(d2) `prob`.
    // Assigned from organ report.p / stratWinRate on the money path.

    const distFromFloorPct = floorStrike > 0 ? ((currentPrice - floorStrike) / floorStrike) * 100 : 0;
    // GO — HYSTERETIC REGIME ENGINE: shadowInstantRegime is the old
    // memoryless classifier, computed only for logging/comparison — it never
    // gates anything. `regime` itself is assigned from the committed R_t a
    // little further down, right after this tick's `obs` is fully built (see
    // the updateRegime() call there), so the earlier variable declaration
    // pattern here doesn't need to change even though the value now comes
    // from the engine.
    const shadowInstantRegime = classifyRegimeFromBuffer({
      velocityDolPerMin: v, threeMinVelocity: v3,
      isStalling: stalling, stallStrength, distFromFloorPct,
    });

    // ── MTF bias filter ────────────────────────────────────────────────────────
    if (mtfAnalyzer.isStale()) {
      this.log("warn", `[mtf] MTF data is stale (${Math.round(mtfAnalyzer.ageSecs() / 60)}m old) — treating as neutral for this tick`);
    }
    const mtfScore = mtfAnalyzer.getScore();
    const mtf      = mtfAnalyzer.getSummary();

    // ── Enrichments: volume state, breakout/fakeout, period history ─────────────
    const volumeState                      = computeVolumeState(this.prices);
    const { recentlyBrokeLevel, quickReclaim } = detectBreakoutFakeout(this.prices, floorStrike);
    const periodStats                      = periodRecorder.getStats();
    const channelInfo                      = computePriceChannel(this.prices) ?? undefined;

    // ── Market intelligence: session bias, RSI, VWAP deviation, ATR ──────────
    // Computed from the same price buffer used everywhere else so there's no
    // additional network call.  All fields are optional in StrategyObservation
    // so this is additive and backward-compatible with all existing strategies.
    const miData: MarketIntelligenceData = computeMarketIntelligenceObs(this.prices);

    // ── Velocity stall-reversal detector (Task #338) ─────────────────────────
    // Fed every tick regardless of whether the strategy is enabled — the state
    // machine needs continuous observation to detect the sequence; gating on
    // disabledStrategies happens later like every other strategy.
    const velocityReversal = this.velocityReversalDetector.update({
      ticker, price: currentPrice, ts: Date.now(), floorStrike,
    });

    // ── Bounce-level tracker (Task #341) ─────────────────────────────────────
    // Fed every tick off the same raw price everything else here uses, same
    // "always feed regardless of strategy enablement" rule as the velocity
    // detector above — the zigzag leg state needs continuous observation to
    // stay accurate. Consumed later, in the confidence-bonus step, only for
    // reversal-capable strategies.
    const bounceTs = Date.now();
    recordBounceTick(currentPrice, bounceTs);
    // STRUCTURE_REVERSAL — feed only. LIVE_APPLY false. Not a StrategyId.
    // Never placeOrder from this snapshot. Do not clone VELOCITY_STALL_REVERSAL.
    const bounceInfo = getBounceInfo(currentPrice, bounceTs);
    updateStructureReversal({
      ticker,
      ts: bounceTs,
      spot: currentPrice,
      floor: floorStrike,
      projectedSettlement: this.lastBasisState?.projectedSettlementPrice
        ?? this.lastBasisState?.estimatedFairBRTI
        ?? null,
      yesAsk,
      noAsk,
      yesBid,
      noBid,
      secsRemaining: secs,
      bounceDominant: bounceInfo?.dominant ?? null,
    });

    // ── Bollinger Bands (Task #445) ──────────────────────────────────────────
    // Fed every tick off the same price buffer everything else here uses — no
    // additional network call. Populated regardless of whether the new
    // BOLLINGER_BAND strategy is enabled, mirroring the velocity-reversal
    // detector above, so the squeeze tracker's rolling history is always warm
    // and condition-adapter.ts's squeeze classifier can use it immediately
    // once bollingerBandStrategyEnabled is flipped on.
    const bb = computeBollingerBands(this.prices.map(p => p.price), 20, 2);
    const bbSqueezeStrong = bb ? this.bbSqueezeTracker.update(bb.bandwidthPct) : undefined;
    const bbRecentSqueezeExpansion = bb ? this.bbSqueezeTracker.recentlyExpanded() : undefined;

    // ── Settlement prediction (Task #445) ────────────────────────────────────
    // Read fresh at obs-build time so the consensus vote and the dedicated
    // hard veto (below) never disagree about "the current prediction".
    const settlementCall = settlementPredictor.getCurrent();
    const settlementPrediction = settlementCall
      ? { direction: settlementCall.predictedDirection, confidence: settlementCall.confidence }
      : undefined;

    const obs: StrategyObservation = {
      currentPrice, floorStrike,
      ticker,
      contractDurationMins: 15, // 15m evaluateEntry; hourly uses evaluateHourlyTick
      cheapSide15mEnabled: this.config.cheapSide15mEnabled === true, // paper≡live: no paperMode OR-unlock
      cheapEarlyExitEnabled: this.config.cheapEarlyExitEnabled === true,
      panicFadeEnabled: this.config.panicFadeEnabled === true, // paper≡live: no paperMode OR-unlock
      streakSatFadeEnabled: this.config.streakSatFadeEnabled === true,
      // 2026-08-07: yesBid/yesAsk/noBid/noAsk were destructured from `tick`
      // above but never copied into `obs` — every strategy that reads a live
      // ask (BASIS_LAG_EDGE, LATE_MOMENTUM_CONTINUATION) saw `undefined` on
      // every tick regardless of the real order book, permanently blocking
      // on NO_QUOTE. Restored here from the same tick data everything else
      // in this function already uses.
      yesBid, yesAsk, noBid, noAsk,
      velocityDolPerMin: v, threeMinVelocity: v3,
      isStalling: stalling, stallStrength,
      distFromFloorPct, massAboveFloor: prob * 100,
      secsRemaining: secs,
      velocityReversal,
      shortTrend:  v  >  20 ? 'up' : v  < -20 ? 'down' : 'sideways',
      mediumTrend: v3 >  15 ? 'up' : v3 < -15 ? 'down' : 'sideways',
      mtfScore,
      // regime: filled in immediately below via updateRegime() — obs must be
      // fully built first since propose() reads volumeState/recentlyBrokeLevel/
      // quickReclaim/bbSqueezeStrong etc. off it (see regime-engine.ts).
      // ── Previously always-undefined enrichments — now fully populated ────────
      volumeState,
      recentlyBrokeLevel,
      quickReclaim,
      // ── 24h settlement history ───────────────────────────────────────────────
      recentUpPct:       periodStats.sampleSize >= 10 ? periodStats.recentUpPct       : undefined,
      settlementStreak:  periodStats.sampleSize >= 10 ? periodStats.settlementStreak  : undefined,
      isAlternating:     periodStats.sampleSize >= 10 ? periodStats.isAlternating     : undefined,
      streakSaturation:  periodStats.sampleSize >= 10 ? periodStats.streakSaturation  : undefined,
      allTimeMaxUpStreak:   periodStats.sampleSize >= 10 ? periodStats.allTimeMaxUpStreak   : undefined,
      allTimeMaxDownStreak: periodStats.sampleSize >= 10 ? periodStats.allTimeMaxDownStreak : undefined,
      // ── Velocity acceleration ─────────────────────────────────────────────────
      velocityAccel: this.config.useAcceleration ? this.velocityAccel : undefined,
      // ── Price Channel ─────────────────────────────────────────────────────────
      channelInfo,
      // ── Psychological levels ──────────────────────────────────────────────────
      psychLevel: computePsychLevel(currentPrice, floorStrike),
      // ── Market intelligence enrichments ────────────────────────────────────────
      rsi14:        miData.rsi14,
      vwapDevPct:   miData.vwapDevPct,
      atrPct:       miData.atrPct,
      sessionLabel: miData.sessionLabel,
      candlePattern: candlePatternAnalyzer.getLatest() ?? undefined,
      // ── Cross-exchange BRTI basis / settlement projection ───────────────────
      rollingBasis:             this.lastBasisState?.rollingBasis ?? undefined,
      estimatedFairBRTI:        this.lastBasisState?.estimatedFairBRTI ?? undefined,
      basisLeadUsd:            this.lastBasisState?.basisLeadUsd ?? this.lastBasisState?.estimatedFairBRTI ?? undefined,
      projectedSettlementPrice: this.lastBasisState?.projectedSettlementPrice ?? undefined,
      basisShort:               this.lastBasisState?.shortBasis ?? undefined,
      basisExchangePrice:       this.lastBasisState?.exchangePrice ?? undefined,
      basisProxyPrice:          this.lastBasisState?.brtiProxy ?? undefined,
      basisStreakCount: liveOrigLagStreakOnObs({
        analog: this.origLagProjStreak,
        lagDollars: this.lastBasisState?.lagDollars,
        lagStale: this.lastBasisState?.lagStale,
      }).basisStreakCount,
      basisStreakSign: liveOrigLagStreakOnObs({
        analog: this.origLagProjStreak,
        lagDollars: this.lastBasisState?.lagDollars,
        lagStale: this.lastBasisState?.lagStale,
      }).basisStreakSign,
      lagSeconds:               this.lastBasisState?.lagSeconds ?? null,
      lagDollars:               this.lastBasisState?.lagDollars ?? null,
      lagCorr:                  this.lastBasisState?.lagCorr ?? null,
      lagStale:                 this.lastBasisState?.lagStale ?? true,
      lagReason:                this.lastBasisState?.lagReason,
      lagResidualDollars:       this.lastBasisState?.lagResidualDollars ?? null,
      leaderName:               this.lastBasisState?.leaderName ?? null,
      leadSeconds:              this.lastBasisState?.leadSeconds ?? null,
      leadDollars:              this.lastBasisState?.leadDollars ?? null,
      proofHitRate:             this.lastBasisState?.proofHitRate ?? null,
      lagProven:                this.lastBasisState?.lagProven === true,
      paperMode:                this.config.paperMode === true,
      ohlc1m:                   getMtfOhlcBars(1)?.bars,
      ohlc5m:                   getMtfOhlcBars(5)?.bars,
      openStrategyId:           this.openTrade?.strategyId ?? null,
      // fairDistFromFloorPct: additive only, gated on the new staleness guard.
      // Not read by any strategy yet — see StrategyObservation's field comment.
      fairDistFromFloorPct: (!basisTracker.isFairValueStale() && this.lastBasisState?.estimatedFairBRTI != null && floorStrike > 0)
        ? ((this.lastBasisState.estimatedFairBRTI - floorStrike) / floorStrike) * 100
        : undefined,
      // ── Bollinger Bands ──────────────────────────────────────────────────────
      bbPercentB:               bb?.percentB,
      bbBandwidthPct:           bb?.bandwidthPct,
      bbSqueezeStrong,
      bbRecentSqueezeExpansion,
      // ── Settlement prediction model ─────────────────────────────────────────
      settlementPrediction,
    };

    // P4 LIQUIDITY POLICY: per-side book snapshots for BASIS_LAG_EDGE's
    // Part C net-edge carve-out (the general haircut/skip for every other
    // strategy applies downstream in _placeOrderBody, not here).
    {
      const ob = kalshiWS.getLatestOrderbook();
      obs.liquidityBook = {
        YES: buildBookSnap({ side: 'YES', currentTicker: ticker, quote: { yesBid, yesAsk, noBid, noAsk }, latestOrderbook: ob }),
        NO:  buildBookSnap({ side: 'NO',  currentTicker: ticker, quote: { yesBid, yesAsk, noBid, noAsk }, latestOrderbook: ob }),
      };
    }

    // P3 MARKETSTATE: computed once obs has currentPrice/atrPct/velocityDolPerMin/
    // volumeState/etc. populated above, so computeVolumeScore(obs).V (feeding
    // volScale) reads the same enrichments the rest of this tick's obs uses —
    // not a second, possibly-stale copy of them.
    {
      const ms = computeMarketState({
        velocityHistory: this.velocityHistory, velocityEma: this.velocityEma,
        obs, periodSecs: 15 * 60,
      });
      obs.velScale = ms.velScale; obs.zVel = ms.zVel; obs.rangeScale = ms.rangeScale;
      obs.volScale = ms.volScale; obs.marketStale = ms.stale;
      this.lastMarketState = ms;
    }

    // GO — HYSTERETIC REGIME ENGINE: this is the primary tick-cadence WRITER
    // (mutually exclusive per tick with considerAddingToPosition() above,
    // since this function only runs when this.openTrade is unset). obs is
    // fully built at this point, so propose()'s reads of volumeState/
    // recentlyBrokeLevel/quickReclaim/bbSqueezeStrong etc. see real values,
    // not placeholders. shadowInstantRegime (declared earlier, pre-obs) is
    // the old memoryless classifier kept only for comparison logging below.
    const regime = updateRegime(obs, Date.now());
    obs.regime = regime;
    this.lastDetectedRegime = regime;
    if (shadowInstantRegime !== regime) {
      const regimeMsg = this.logThrottle.gate(
        `regime|${shadowInstantRegime}|${regime}`,
        `[regime] shadow instant classifier disagrees with committed R_t: shadow=${shadowInstantRegime} committed=${regime}`,
      );
      if (regimeMsg) this.log("info", regimeMsg);
    }

    this.lastObservation = obs;
    this.lastObsTs       = Date.now();
    {
      const qTs = kalshiWS.getLatest()?.quoteTs;
      const qAge = typeof qTs === "number" && qTs > 0 ? Date.now() - qTs : null;
      const qSrc = (kalshiWS.getLatest() as { source?: "ws" | "rest" } | null)?.source ?? "ws";
      this.lastTapeOrgan = snapshotTape({
        quotes: { yesAsk: obs.yesAsk, noAsk: obs.noAsk, yesBid: obs.yesBid, noBid: obs.noBid },
        floor: obs.floorStrike,
        velocity: obs.velocityDolPerMin,
        ohlc1m: obs.ohlc1m ?? null,
        ohlc5m: obs.ohlc5m ?? null,
        mtf: obs.mtfScore ?? null,
        lag: this.lastBasisState,
        htf: computeLiveHtfStructure(currentPrice),
        streakSaturation: obs.streakSaturation ?? null,
        settlementStreak: obs.settlementStreak ?? null,
        quoteAgeMs: qAge,
        quoteSource: qSrc,
        quoteAsOfMs: typeof qTs === "number" && qTs > 0 ? qTs : null,
      });
    }
    try {
      this.lastAdaptiveRegime = observeAdaptiveRegime({
        obs,
        now: this.lastObsTs,
        ...fillPathRegimeTraceFields({
          yesAsk: obs.yesAsk, noAsk: obs.noAsk,
          side: this.lastStrategyResult?.signal === "YES" ? "yes"
            : this.lastStrategyResult?.signal === "NO" ? "no" : null,
          strategyId: this.lastStrategyResult?.strategyId ?? null,
          pWinAtEntry: null,
          minutesLeft: (obs.secsRemaining ?? 0) / 60,
          secsRemaining: obs.secsRemaining,
        }),
      });
    } catch { /* log-only organ */ }

    // SHADOW would-fire (ENABLE stays false). Never APPROVED. Deltas from
    // ticket history so PANIC_FADE can label a later-window jump.
    {
      const nowQ = obsToTickQuote({
        ticker: obs.ticker,
        yesAsk: obs.yesAsk,
        noAsk: obs.noAsk,
        yesBid: obs.yesBid,
        noBid: obs.noBid,
        floorStrike: obs.floorStrike,
        projectedSettlementPrice: obs.projectedSettlementPrice,
        secsRemaining: obs.secsRemaining,
      });
      if (nowQ) {
        const d = ticketDeltasFromHistory(nowQ, this.paperScalpQuotes);
        obs.yesAskDeltaCents = d.yesAskDeltaCents ?? undefined;
        obs.noAskDeltaCents = d.noAskDeltaCents ?? undefined;
        obs.yesMidDeltaCents = d.yesMidDeltaCents ?? undefined;
        obs.noMidDeltaCents = d.noMidDeltaCents ?? undefined;
      }
      this.lastAdviceShadow = collectAdviceShadow(obs);
    }


    // ── FROZEN SIX-GATE early jump (after lastObservation; leftover stays below) ──
    // Organ is sole evaluate path when frozenCcMode. Leftover classify/packs/HARVEST
    // do not run the money path. Shadow/advisory organs above remain OK.
    if (frozenSixGateIsOnlyEvaluatePath(this.config)) {
      const grokRegimeEarly = getGrokRegimeFromDetailed(regime);
      const { all: earlyAll } = this.evaluateStrategiesForBot(
        obs,
        unionMain15mEvaluateDisabled(effectiveDisabledStrategies(this.config), this.config),
      );
      const ccResult = earlyAll.find(r => r.strategyId === FROZEN_CC_STRATEGY_ID) ?? null;
      const frozenQuoteLag = liveQuoteValueLag(tick);
      if (frozenQuoteLag.stale) {
        const m = this.logThrottle.gate(`${ticker}|QUOTE_VALUE_LAG`, `⏳ quote_stale (D9): ${frozenQuoteLag.reason ?? "stale"}`);
        if (m) this.log("info", m);
      }
      const alignedGate = alignedTakeGate({
        mtfSign: mtfScore,
        yesAsk,
        noAsk,
        lagProven: obs.lagProven === true,
        quoteStale: frozenQuoteLag.stale, // D9 — WS-vs-L2 value lag (was hard-coded false)
        secsRemaining: secs,
        spot: currentPrice,
        floorStrike,
        // CC-only: without strategyId, gold-copy/lag can return BASIS_LAG_EDGE →
        // decideFrozenCcEntry FROZEN_ALIGNED_NOT_CC. considerLag must stay false.
        strategyId: FROZEN_CC_STRATEGY_ID,
        winRateAtPrice: bindSideWinRateAtPrice({
          yesAsk,
          noAsk,
          minutesLeft: secs / 60,
          curveFor: (strategyId) => {
            const id = strategyId === "BASIS_LAG_EDGE" ? "BASIS_LAG_EDGE" : "CONFLUENCE_CASCADE";
            const meta = getAllStrategyMeta().find(s => s.id === id);
            return meta?.winRateAtPrice ?? null;
          },
        }),
      });
      // 015 lockSide + direction_w2 tags. PR #14: lockSide PASS is now REQUIRED
      // before placeOrder on the frozen-CC path too (same LOCKSIDE_FILL_GATE as
      // CC|LAG elsewhere) — the full result is stamped on lastW2Log each tick.
      let lockSideKind: string | null = null;
      let lockSideWhy: string | null = null;
      let lockSideMtf: number | null = null;
      let frozenLs: ReturnType<typeof lockSide> | null = null;
      try {
        const ls = lockSide({
          mtfSign: mtfScore > 0 ? "long" : mtfScore < 0 ? "short" : null,
          yesAsk,
          noAsk,
          secsRemaining: secs,
          brtiPx: null, // Exchange spot is not authoritative BRTI.
          floorStrike,
          lagProven: obs.lagProven === true,
          ohlc1m: obs.ohlc1m ?? null,
        });
        frozenLs = ls;
        lockSideKind = ls.side === "skip" ? "SKIP" : "TAKE";
        lockSideWhy = ls.why ?? null;
        lockSideMtf = typeof mtfScore === "number" && Number.isFinite(mtfScore) ? mtfScore : null;
      } catch { frozenLs = null; /* organ threw → stamp null → fill gate fails closed */ }
      // Fresh per-tick stamp (never carries a stale PASS from an earlier tick).
      const frozenStamp = {
        ha_side: this.lastW2Log?.ha_side ?? null,
        analog_side: this.lastW2Log?.analog_side ?? null,
        lag_proven: this.lastW2Log?.lag_proven === true,
        ...frozenLockSideStamp(frozenLs),
      };
      this.lastW2Log = {
        mtf_side: frozenStamp.mtf_side,
        ha_side: frozenStamp.ha_side,
        analog_side: frozenStamp.analog_side,
        lag_proven: frozenStamp.lag_proven,
        lock_result: frozenStamp.lock_result ?? "",
        lockSide: frozenLs?.tags ?? null,
        lockSide_why: frozenStamp.lockSide_why,
      };

      let regimeWouldBlock: boolean | null = null;
      try {
        regimeWouldBlock = !passesStrategyRegimeFilter({
          strategyId: FROZEN_CC_STRATEGY_ID, currentRegime: regime, grokRegime: grokRegimeEarly,
        });
      } catch { regimeWouldBlock = null; }
      let shadow: FrozenShadowFlags = buildFrozenShadowPreDecision({
        w2Kind: lockSideKind === "SKIP" ? "SKIP" : "TAKE",
        w2Reason: lockSideWhy,
        sessionMode: getCurrentSessionMode(),
        harvestWouldSuppress: getCurrentSessionMode() === "HARVEST"
          && !isHarvestSessionFamilyAllowed(false, FROZEN_CC_STRATEGY_ID),
        regime: String(regime ?? "unclear"),
        grokRegime: String(grokRegimeEarly ?? ""),
        regimeWouldBlock,
        mtfScore: Number.isFinite(mtfScore) ? mtfScore : null,
        lagProven: obs.lagProven === true,
        lagStale: this.lastBasisState?.lagStale ?? null,
        lagDollars: this.lastBasisState?.lagDollars ?? obs.lagDollars ?? null,
        velocityDolPerMin: Number.isFinite(this.currentVelocity) ? this.currentVelocity : null,
        consecutiveLosses: this.consecutiveLosses,
        ccConfidence: ccResult?.confidence ?? null,
        ccReason: ccResult?.reason ?? null,
        aligned: alignedGate,
      });
      shadow = { ...shadow, lockSideKind, lockSideWhy, lockSideMtf };
      // Sensor feed for the status-time brain build when flat (vel/mtf/lag
      // were only wired from an open/pending trade's shadow). Observe-only.
      this.lastFrozenTickShadow = { shadow, atMs: Date.now() };

      const frozen = decideFrozenCcEntry({
        secsRemaining: secs,
        yesAsk,
        noAsk,
        cc: ccResult && isTradeSignal(ccResult.signal)
          ? { signal: ccResult.signal, confidence: ccResult.confidence, reason: ccResult.reason }
          : null,
        aligned: alignedGate,
        shadow,
        andSitArmed: this.config.frozenCcAndSit === true,
      });
      this.lastStrategyResult =
        ccResult &&
        isTradeSignal(ccResult.signal) &&
        ccResult.signal !== "STAY_OUT" &&
        typeof ccResult.confidence === "number" &&
        typeof ccResult.reason === "string" &&
        typeof ccResult.strategyName === "string" &&
        typeof ccResult.earlyExitRule === "string"
          ? {
              signal: ccResult.signal,
              confidence: ccResult.confidence,
              reason: ccResult.reason,
              strategyId: FROZEN_CC_STRATEGY_ID,
              strategyName: ccResult.strategyName,
              earlyExitRule: ccResult.earlyExitRule,
            }
          : null;
      if (frozen.kind === "SKIP") {
        this.lastSignalDesc = `[FROZEN_CC] ${frozen.code}: ${frozen.reason}`;
        this.recordAutopilotDecision("SKIP", frozen.side ?? null, this.lastSignalDesc);
        // R2 — aligned-gate skips carry their gate reason (e.g. quote_stale) so
        // D9 staleness is countable from status.entryFunnel.
        this.entryFunnel.bump(frozen.code === "FROZEN_ALIGNED_SKIP"
          ? `SKIP:${frozen.code}:${String(alignedGate.kind === "SKIP" ? alignedGate.reason : "other").slice(0, 40)}`
          : `SKIP:${frozen.code}`);
        // D3 — FROZEN_CC_NOT_FIRED ("strategy didn't fire") used to be dropped
        // entirely, hiding the in-window blocker. Persist it sampled: one row
        // per ticker+code per 60s. Other frozen codes keep per-tick rows.
        const sampleOk = frozen.code !== "FROZEN_CC_NOT_FIRED"
          || this.traceThrottle.gate(`${ticker}|${frozen.code}`, "1") != null;
        if (sampleOk) {
          skip(frozen.code, [frozen.reason], {
            ticker,
            side: frozen.side ?? (mtfScore < 0 ? "no" : "yes"),
            strategyId: FROZEN_CC_STRATEGY_ID,
            entryPriceCents: frozen.ask ?? 0,
            confidence: ccResult?.confidence ?? 0,
            secsRemaining: secs,
            floorStrike,
            yesAsk,
            noAsk,
          });
        }
        return;
      }
      const ccVel = ccVelocityAgainstGate({
        strategyId: FROZEN_CC_STRATEGY_ID, side: frozen.side, velocityDolPerMin: this.currentVelocity,
      });
      let htfBias: string | null = null;
      try { htfBias = computeLiveHtfStructure(currentPrice).sideBias; } catch { htfBias = null; }
      const rawBidFrozen = frozen.side === "yes" ? yesBid : noBid;
      shadow = enrichFrozenShadowPostTake({
        shadow,
        side: frozen.side,
        ask: frozen.ask,
        ccVelocityWouldBlock: ccVel.block ? (ccVel.reason ?? "CC_VEL_AGAINST") : null,
        htfSideBias: htfBias,
        bidCents: typeof rawBidFrozen === "number" && Number.isFinite(rawBidFrozen) ? rawBidFrozen : null,
      });
      shadow = { ...shadow, lockSideKind, lockSideWhy, lockSideMtf };
      this.lastSignalDesc = formatFrozenCcTakeDesc({
        side: frozen.side, ask: frozen.ask, p: frozen.p, ev: frozen.ev,
        secs, mtfScore, shadow,
      });
      this.recordAutopilotDecision("TAKE", frozen.side, this.lastSignalDesc);
      this.entryFunnel.bump("TAKE_SIGNAL");
      {
        const takeMsg = this.logThrottle.gate(throttleKey(ticker, "TAKE", frozen.side), `🧊 ${this.lastSignalDesc}`);
        if (takeMsg) this.log("info", takeMsg);
      }
      // YES_40_55_PIN_SHADOW_V1 — OBSERVE ONLY. Never changes TAKE/SIT.
      let entryShadowDecisionId: string | null = null;
      let entryShadowSit = false;
      let entryShadowProtectedCheapNo = false;
      let entryShadowProtectedCheapYes = false;
      try {
        const sideForShadow: "yes" | "no" = frozen.side;
        const askForShadow = frozen.ask;
        const feeNetEv = frozen.ev;
        const shadowClass = classifyFrozenCcEntryShadow({
          paperMode: this.config.paperMode === true,
          frozenCcMode: this.config.frozenCcMode === true,
          market: ticker.startsWith("KXBTC15M") ? "KXBTC15M" : (ticker.split("-")[0] ?? ticker),
          quoteFresh: true,
          secsRemaining: secs,
          side: sideForShadow,
          ask: askForShadow,
          feeNetEvCents: feeNetEv,
          kellyFrac: 0.60,
          positionAndPendingClear: this.openTrade == null && !(this as any).heldPendingFromRestart,
          w2Reason: (shadow as any).w2Reason,
          regimeWouldBlock: (shadow as any).regimeWouldBlock === true,
          brtiSign: (this as any).lastW2Log?.lockSide?.brtiSign ?? null,
          decision: frozen,
        });
        entryShadowSit = shadowClass.shadowSit;
        entryShadowProtectedCheapNo = shadowClass.protectedCheapNo;
        entryShadowProtectedCheapYes = shadowClass.protectedCheapYes;
        entryShadowDecisionId = maybeAppendEntryShadowDecision({
          ticker,
          paperMode: this.config.paperMode === true,
          frozenCcMode: this.config.frozenCcMode === true,
          side: sideForShadow,
          ask: askForShadow,
          secsRemaining: secs,
          feeNetEv,
          kellyFrac: 0.60,
          w2Reason: (shadow as any).w2Reason ?? null,
          regimeWouldBlock: (shadow as any).regimeWouldBlock === true,
          haDisagree: (shadow as any).w2Reason === "ha_disagree",
          pinReachable: (shadow as any).w2Reason === "pin_reachable",
          strikeDisagree: (shadow as any).w2Reason === "strike_disagree",
          brtiSign: shadowClass.brtiSign,
          realDecision: "TAKE",
          shadowSit: shadowClass.shadowSit,
          protectedCheapNo: shadowClass.protectedCheapNo,
          protectedCheapYes: shadowClass.protectedCheapYes,
          baseEligible: shadowClass.baseEligible,
          quoteFresh: true,
          spread: (shadow as any).spreadCents ?? null,
          reason: shadowClass.reason,
        });
        void YES_40_55_PIN_SHADOW_V1;
      } catch { /* observe-only */ }
      // PR #14 — frozen-CC must hold lockSide PASS (mtf == fill side) before
      // placeOrder, same LOCKSIDE_FILL_GATE as every other CC|LAG path.
      {
        const lsGate = frozenCcLockSideAdmission(this.lastW2Log, frozen.side);
        if (!lsGate.ok) {
          this.lastSignalDesc = `[FROZEN_CC] ${LOCKSIDE_SKIP_NO_FILL}: ${lsGate.reason}`;
          this.recordAutopilotDecision("SKIP", frozen.side, this.lastSignalDesc);
          this.entryFunnel.bump(`SKIP:${LOCKSIDE_SKIP_NO_FILL}`);
          {
            const m = this.logThrottle.gate(`${ticker}|FROZEN_LOCKSIDE`, `⛔ ${this.lastSignalDesc}`);
            if (m) this.log("warn", m);
          }
          skip(LOCKSIDE_SKIP_NO_FILL, [lsGate.reason], {
            ticker,
            side: frozen.side,
            strategyId: FROZEN_CC_STRATEGY_ID,
            entryPriceCents: frozen.ask,
            confidence: ccResult?.confidence ?? 0,
            secsRemaining: secs,
            floorStrike,
            yesAsk,
            noAsk,
          });
          return;
        }
      }
      this.pendingFrozenFill = { shadow, p: frozen.p, ev: frozen.ev, entryShadowDecisionId, shadowSit: entryShadowSit, protectedCheapNo: entryShadowProtectedCheapNo, protectedCheapYes: entryShadowProtectedCheapYes };
      await this.placeOrder({
        signal: frozen.side === "yes" ? "LONG" : "SHORT",
        side: frozen.side,
        entryPrice: frozen.ask,
        floorStrike,
        ticker,
        confidence: Math.round(frozen.confidence * 100),
        secs,
        strategyWinRate: frozen.p,
        strategyId: FROZEN_CC_STRATEGY_ID,
        grokRegime: grokRegimeEarly,
        detailedRegime: regime,
        velocityDolPerMin: obs.velocityDolPerMin,
        spreadCents: shadow.spreadCents ?? undefined,
        decisionAskCents: frozen.ask,
        traceId,
        frozenCc: true,
      });
      this.pendingFrozenFill = null;
      return;
    }
    // Leftover 15m funnel door — frozen already returned above.
    if (!leftover15mEvaluateMayRun(this.config)) return;
    await leftover15mEvaluateRun(this.config, () =>
      leftover15mEvaluateFunnel.call(this, {
        annualVol,
        channelInfo,
        currentPrice,
        distFromFloorPct,
        edge,
        eff,
        floorStrike,
        logEarlySkip,
        miData,
        minsLeft,
        mtf,
        mtfScore,
        noAsk,
        noBid,
        obs,
        prob,
        quoteAgeMs,
        regime,
        secs,
        skip,
        stalling,
        tick,
        ticker,
        traceId,
        v,
        v3,
        volumeState,
        window,
        yesAsk,
        yesBid,
      }),
    );
}

  // ── Order placement ──────────────────────────────────────────────────────────

  // ── Decision logger (research) ───────────────────────────────────────────
  // Records evaluated-but-rejected entries so the meta-model can study the
  // full decision distribution, not just the survivor set of filled trades.
  // Pre-selection gates use distinct codes: STRATEGY_OVERRIDE_DISABLED,
  // TIME_GATE, DAILY_LOSS_HALT, DAILY_TARGET_BLOCK,
  // DAILY_TARGET_UNINITIALIZED, WS_DEGRADED, STALE_QUOTE,
  // PRICE_BUFFER_WARMUP, STALE_PRICE_BUFFER, SAFETY_GATE, SESSION_FILTER,
  // NO_ELIGIBLE_STRATEGY, and FRESH_SPIKE. Missing market data uses
  // FEED_UNAVAILABLE or a gate-specific SYSTEM row with
  // ticker=SYSTEM:FEED_UNAVAILABLE and decisionScope=SYSTEM, so the feature
  // store records feed failure without fabricating a tradable candidate.
  // Deduped per ticker|strategy|direction|code for 60s so repeated background
  // evaluations of the same standing rejection don't flood the store.
  private skippedDecisionLog = new Map<string, number>();
  // Separate, much tighter throttle (1s) for the durable bot_trade_skips audit
  // table — the 60s skippedDecisionLog above exists for the JSONL research
  // feature store and would hide sustained skip conditions from an operator
  // trying to see "how often, and why, are we skipping trades?"
  private skipAuditThrottle = new Map<string, number>();

  // ── Break-even observability — every strategy, every PATH_GATE outcome ─────
  // Originally a LATE_ENTRY_ANCHOR-only diagnostic (budgeted to 10 events) to
  // verify the price-conditioned winRateAtPrice curve against the live gate.
  // Confirmed working, then extended to fire unconditionally for every
  // strategy that reaches PATH_GATE — this is the single place to see, for
  // any pass OR reject, exactly what fee/slippage/breakeven-WR/EV PATH_GATE
  // computed, which makes strategy-vs-gate mismatches visible immediately
  // instead of requiring a DB query after the fact.
  //
  // Computed via the same computeTradeEV() PATH_GATE itself calls (no
  // strategyId passed, matching passesPathEVGate exactly) so this log can
  // never silently drift from what the gate actually decided. slip reflects
  // the real dynamic slippage used (see expectedSlippageCents in constants.ts),
  // not a fixed number.
  private logBreakEvenEval(
    strategyId: string,
    entryPriceCents: number,
    stratWR: number,
    secsRemaining: number,
    velocityDolPerMin: number | undefined,
    spreadCents: number | undefined,
    passed: boolean,
    gateReason?: string,
  ) {
    const evResult = computeTradeEV({
      entryPriceCents,
      winRate:            stratWR,
      secsRemaining,
      velocityDolPerMin,
      spreadCents,
    });
    const breakEvenWR = evResult.breakevenWinRate * 100;
    const feePct = kalshiFeePctOfCost(entryPriceCents, 1);
    const beOrgan = kalshiBreakevenWinRate(entryPriceCents, 1) * 100;
    this.log("info",
      `📐 [path-gate-eval] ${strategyId} entry ${entryPriceCents}¢ | fee ${evResult.feeCents.toFixed(1)}¢ | ` +
      `feePctOfCost ${feePct.toFixed(2)}% | slip ${evResult.slippageCents.toFixed(1)}¢ | ` +
      `breakeven WR ${breakEvenWR.toFixed(0)}% (fee-only BE ${beOrgan.toFixed(0)}%) | ` +
      `strategy WR ${(stratWR * 100).toFixed(0)}% | ` +
      `EV ${evResult.netEV >= 0 ? '+' : ''}${evResult.netEV.toFixed(1)}¢ → ${passed ? 'PATH_GATE PASSED' : `PATH_GATE REJECTED (${gateReason})`}`
    );
  }
  private logSkippedDecision(code: string, reasons: string[], ctx: {
    ticker: string;
    side: "yes" | "no";
    strategyId?: string;
    entryPriceCents: number;
    confidence: number;
    secsRemaining: number;
    proposedContracts?: number;
    floorStrike?: number;
    traceId?: string;
    // Profit Doctrine Phase 3 (2026-08-24): fee/slippage-adjusted net EV in
    // cents (computeTradeEV().netEV), when the caller already computed one
    // for this decision. Threaded through to decision_traces.ev_cents below
    // — observability only, never read back to affect the skip itself.
    // Populated at the REGIME_EV_FILTER/EV_PRE_CHECK/PATH_GATE/MTF_FILTER call sites.
    netEVcents?: number;
    /** Honest p = winRateAtPrice. Never confidence. Null if curve missing (fail-closed log). */
    pWin?: number | null;
    // Profit Doctrine Phase 3: computeVolumeScore(obs) result for this same
    // tick's observation, threaded to decision_traces.v/v_bucket — those
    // columns existed since Phase 0 but were never populated on SKIP rows.
    volumeScoreV?: number;
    volumeBucket?: string;
    /** SYSTEM marks a pre-market-data gate; it is never a tradable candidate. */
    scope?: "market" | "system";
    /** D4 — top-of-book asks at decision time; falls back to the live quote for this ticker. */
    yesAsk?: number | null;
    noAsk?: number | null;
  }): void {
    // Real paper path: persist the p/EV skip() passed from evaluate. No second
    // curve lookup. Missing → honest null (fail-closed log, still skip).
    const skipPWin = honestPWin(ctx.pWin);
    const skipEv = ctx.netEVcents;
    // Card honesty: never leave TAKE painted after fill path refuses.
    if (this.lastMoneyGateCard?.approved === true) {
      this.lastMoneyGateCard = demoteMoneyGateCardToSit(this.lastMoneyGateCard, code);
    }

    // GO — SPECIALIST REGIME SYSTEM, Phase 0 (DecisionTrace). Classification +
    // persistence happen before the dedupe/throttle below on purpose: the
    // spec requires every EV_FAIL/SIZE_ZERO to be persisted unconditionally,
    // and the 60s in-memory dedupe further down would otherwise silently
    // swallow a sustained skip after its first occurrence. This block is
    // pure observation — it never returns early and never changes `code`/
    // `reasons`, so the existing skip/audit behavior below is untouched.
    try {
      const closedCode: ClosedSkipCode = mapToClosedCode(code, reasons);
      if (true) {
        // GO — APPLY PACKS ENFORCE: when enforce mode is live, use the
        // REAL per-tick pack state evaluateEntry() computed and cached on
        // `this` — never re-derive via the shadow evaluator, which would be
        // a second independent computation that could disagree with what
        // actually gated this tick. shadow/off modes keep the prior
        // observation-only best-effort re-derivation (ctx doesn't carry
        // edgePct/contractDurationMins, so that path remains an
        // approximation — acceptable since shadow mode never gates).
        let skipPackShadow: ShadowPackEvaluation | null = null;
        let realPack: SpecialistPack | null = null;
        let realEligible: StrategyId[] | null = null;
        if (this.config.specialistPacksMode === 'enforce') {
          realPack = this.lastEnforcedPack;
          realEligible = this.lastPackEligibleIds;
        } else if (this.config.specialistPacksMode !== 'off') {
          try {
            const regimeDebug = getRegimeDebug();
            // GO — WIRE LOW_VOL PACK FROM V_bucket: ctx doesn't carry a
            // volume bucket (see the surrounding best-effort note above), so
            // recompute from this.lastObservation the same way the ORDER
            // path's own volume-risk block does at evaluateEntry() time —
            // falls back to 'NORMAL' (never LOW_VOL) if no observation yet.
            const skipVBucket: VolumeBucket = this.lastObservation
              ? computeVolumeScore(this.lastObservation).bucket
              : 'NORMAL';
            skipPackShadow = evaluateSpecialistPackShadow({
              regime: regimeDebug.current,
              vBucket: skipVBucket,
              disabledSet: [...effectiveDisabledStrategies(this.config), ...getDbDisabledStrategies(15)],
              dwellMs: Date.now() - regimeDebug.sinceMs,
              candidate: ctx.strategyId ? { strategyId: ctx.strategyId as StrategyId, askCents: ctx.entryPriceCents } : null,
            });
          } catch {
            // Shadow compute must never affect a real skip.
          }
        }
        const tracePackId = realPack ? realPack.id : (skipPackShadow?.packId ?? undefined);
        const traceEligible = realPack ? (realEligible ?? []) : skipPackShadow?.wouldEligible;
        const tracePackCap = realPack ? realPack.sizeCapMult : (skipPackShadow?.wouldSizeCap ?? undefined);
        void persistDecisionTrace({
          traceId: ctx.traceId ?? generateTraceId(),
          ts: Date.now(),
          ticker: ctx.ticker,
          side: ctx.side,
          secsLeft: ctx.secsRemaining,
          strategyId: ctx.strategyId,
          ask: ctx.entryPriceCents,
          ...(() => {
            if (ctx.yesAsk !== undefined || ctx.noAsk !== undefined) {
              return { yesAsk: ctx.yesAsk ?? null, noAsk: ctx.noAsk ?? null };
            }
            try {
              const q = kalshiWS.getLatest();
              if (q && q.ticker === ctx.ticker) return { yesAsk: q.yesAsk, noAsk: q.noAsk };
            } catch { /* unknown */ }
            return {};
          })(),
          pWin: skipPWin,
          pSize: ctx.proposedContracts ?? null,
          feeCents: kalshiTakerFeeCents(ctx.entryPriceCents, Math.max(1, ctx.proposedContracts ?? 1)),
          breakevenWR: kalshiBreakevenWinRate(ctx.entryPriceCents, Math.max(1, ctx.proposedContracts ?? 1)),
          evCents: skipEv,
          V: ctx.volumeScoreV,
          V_bucket: ctx.volumeBucket,
          outcome: "SKIP",
          code: closedCode,
          rawCode: code,
          // Phase 1 (SPECIALIST REGIME SYSTEM): wire the sticky committed
          // regime + its current hold reason, per spec. Safe to read here —
          // getRegime()/getRegimeHeldBy() are synchronous module-state reads
          // with no side effects, called from the same tick that produced
          // this skip.
          regime: getRegime(), regimeHeldBy: getRegimeHeldBy() ?? undefined,
          chain: [
            ...reasons,
            ...(realPack ? [`PACK:${realPack.id}:confBump=${realPack.confBump}:cap=${realPack.sizeCapMult}:enforce`] : []),
            ...(!realPack && skipPackShadow?.packId ? [`SHADOW_PACK:${skipPackShadow.packId}:confBump=${skipPackShadow.wouldConfBump}:cap=${skipPackShadow.wouldSizeCap}:outcome=${skipPackShadow.wouldOutcome}`] : []),
          ],
          pack: this.lastAdaptiveRegime?.packId ?? tracePackId,
          eligible: this.lastAdaptiveRegime?.pack.eligibleIds
            ? [...this.lastAdaptiveRegime.pack.eligibleIds]
            : traceEligible,
          packCap: tracePackCap,
        });
      }
    } catch {
      // Trace classification/persistence must never affect trading.
    }
    try {
      const key = `${ctx.ticker}|${ctx.strategyId ?? "?"}|${ctx.side}|${code}`;
      const now = Date.now();
      const last = this.skippedDecisionLog.get(key);
      if (last && now - last < 60_000) return;
      this.skippedDecisionLog.set(key, now);
      // Opportunistic sweep so the map never grows unbounded across tickers.
      if (this.skippedDecisionLog.size > 200) {
        for (const [k, t] of this.skippedDecisionLog) {
          if (now - t > 10 * 60_000) this.skippedDecisionLog.delete(k);
        }
      }

      // Durable audit log (bot_trade_skips) — throttled to 1 write/sec per
      // key so a hot skip loop can't flood the DB, but unlike the 60s JSONL
      // dedupe above, a sustained skip condition still gets a steady trickle
      // of rows instead of vanishing after the first occurrence.
      const auditLast = this.skipAuditThrottle.get(key);
      if (!auditLast || now - auditLast >= 1_000) {
        this.skipAuditThrottle.set(key, now);
        if (this.skipAuditThrottle.size > 200) {
          for (const [k, t] of this.skipAuditThrottle) {
            if (now - t > 10 * 60_000) this.skipAuditThrottle.delete(k);
          }
        }
        // Master bot upgrade step 3: tag every skip decision with the session
        // mode in effect. No dedicated schema column, so — consistent with
        // this table's existing free-text `reasons` field — it's appended
        // here once, rather than threading a sessionMode param through every
        // one of this method's ~20 call sites.
        db.insert(botTradeSkips).values({
          ticker: ctx.ticker, side: ctx.side, strategyId: ctx.strategyId ?? null,
          rejectionCode: code, reasons: `${reasons.join(" | ")} [session=${this.lastSessionMode}]`,
          entryPriceCents: ctx.entryPriceCents, confidence: ctx.confidence,
          secsRemaining: ctx.secsRemaining, isPaper: this.config.paperMode,
        }).catch(() => {
          // Audit logging must never affect trading.
        });
        // Shadow-only in-memory copy so ticker close can stamp ITM/OTM even
        // if Postgres is down. Does not change the skip or any gate.
        try {
          {
            const spot = this.prices.at(-1)?.price ?? 0;
            const tape = stampFromLive({
              side: ctx.side,
              lag: this.lastBasisState,
              htf: computeLiveHtfStructure(spot),
              mtfScore: mtfAnalyzer.getSummary()?.score ?? null,
              streakSaturation: this.lastObservation?.streakSaturation ?? null,
              settlementStreak: this.lastObservation?.settlementStreak ?? null,
            });
            rememberSkip({
              ticker: ctx.ticker, side: ctx.side, strategyId: ctx.strategyId ?? null,
              rejectionCode: code, entryPriceCents: ctx.entryPriceCents,
              confidence: ctx.confidence,
              pWin: fillPathPWin((() => {
                const curveP = pForStrategyAtAsk(ctx.strategyId, ctx.entryPriceCents, ctx.secsRemaining / 60);
                const sample = ctx.strategyId ? getLearnerPathWinRateSample(ctx.strategyId) : { n: 0, winRate: 0 };
                return pathPWinFromCurveOrLearner({
                  curveP,
                  learnerWR: sample.winRate,
                  learnerN: sample.n,
                  paperMode: this.config.paperMode === true,
                  realBotSettlesN: ctx.strategyId ? getLiveTradeStatsSync(ctx.strategyId, 15).n : 0,
                });
              })()),
              secsRemaining: ctx.secsRemaining,
              ts: now, isPaper: this.config.paperMode,
              lastSignal: this.lastSignalDesc, floor: ctx.floorStrike ?? null,
              lagClass: tape.lagClass, lagSeconds: tape.lagSeconds, lagDollars: tape.lagDollars,
              htfStructure: tape.htf,
              streakSaturation: tape.streakSaturation,
            });
          }
        } catch {
          // Observational only.
        }

        // Profit Doctrine Phase 6: SKIP decision-trace row, gated on the exact
        // same 1/sec-per-key throttle as the bot_trade_skips write directly
        // above (not a second independent throttle) — this widens "every
        // real (non-throttled) skip write" from the Phase 0 EV_FAIL/SIZE_ZERO-
        // only subset to the full P6 SKIP taxonomy, without reopening the
        // flooding risk that throttle already exists to prevent.
        void persistDecisionTraceEvent({
          eventType: "SKIP", ticker: ctx.ticker, side: ctx.side, strategyId: ctx.strategyId,
          secsLeft: ctx.secsRemaining,
          pricing: { askCents: ctx.entryPriceCents, netEvCents: skipEv, contracts: ctx.proposedContracts, pWin: skipPWin, signalConfidence: ctx.confidence },
          gates: { primaryBlocker: code },
          skipChain: reasons,
          chain: reasons,
        });
      }
      const ob = kalshiWS.getLatestOrderbook();
      const sameTicker = ob?.ticker === ctx.ticker;
      const bidDepth = sameTicker ? ob!.yesBids.reduce((s, [, q]) => s + q, 0) : 0;
      const askDepth = sameTicker ? ob!.yesAsks.reduce((s, [, q]) => s + q, 0) : 0;
      const totalDepth = bidDepth + askDepth;
      const metaMtf = mtfAnalyzer.getSummary();
      const currentPrice = this.prices.at(-1)?.price ?? 0;
      const floorStrike = ctx.floorStrike ?? 0;
      const conf01 = ctx.confidence > 1 ? ctx.confidence / 100 : ctx.confidence;
      recordSkippedMetaExample(buildMetaFeatures({
        timestamp: now,
        decisionScope: ctx.scope === "system" ? "SYSTEM" : "MARKET",
        marketTicker: ctx.ticker, contractDurationMins: 15,
        secsRemaining: ctx.secsRemaining,
        path: isValidKalshiPrice(ctx.entryPriceCents) ? getPathConfig(ctx.entryPriceCents).path : "GRAY",
        regime: "unclear",
        strategyId: ctx.strategyId ?? "unknown",
        direction: ctx.side.toUpperCase() as "YES" | "NO",
        strategyConfidence: conf01, preTradeScore: ctx.confidence,
        entryPriceCents: ctx.entryPriceCents, btcPrice: currentPrice, floorStrike,
        distFromFloorPct: floorStrike ? ((currentPrice - floorStrike) / floorStrike) * 100 : 0,
        velocity1m: this.currentVelocity, velocity3m: this.threeMinVelocity,
        isStalling: this.lastStalling, spreadCents: 0,
        bestBidSize: sameTicker ? ob!.yesBids[0]?.[1] ?? 0 : 0,
        bestAskSize: sameTicker ? ob!.yesAsks[0]?.[1] ?? 0 : 0,
        bookImbalance: totalDepth ? (bidDepth - askDepth) / totalDepth : 0,
        opposingDepth: ctx.side === "yes" ? askDepth : bidDepth,
        suspicionScore: kalshiWS.getOrderbookLiquidityInstability(ctx.side).score,
        mtfScore: metaMtf?.score,
        mtfBias: metaMtf?.bias.includes("bull") ? "BULL" : metaMtf?.bias.includes("bear") ? "BEAR" : "NEUTRAL",
        mtfM1Score: metaMtf?.m1?.score, mtfM5Score: metaMtf?.m5?.score,
        mtfM15Score: metaMtf?.m15?.score, mtfH1Score: metaMtf?.h1?.score,
        estimatedWinRate: conf01,
        balanceCents: this.config.paperMode ? this.paperVirtualBalanceCents : this.accountBalance ?? undefined,
        consecutiveLosses: this.consecutiveLosses,
      }), {
        proposedContracts: ctx.proposedContracts,
        reasons,
        rejectionCode: code,
      });
    } catch {
      // Research logging must never affect trading.
    }
  }

  // Cross-horizon admission lock — the 15-min tick and the 30-s hourly tick run
  // on independent mutexes, so both can reach placeOrder while flat in the same
  // instant. This flag makes admission atomic: the first caller claims it
  // synchronously (no await between check and set), the second is rejected.
  private orderAdmissionLock = false;

  /** P2-D: throttle BRAIN_CENTER_VETO spam on six-gate SKIP refresh (once per ticker/candle). */
  private lastBrainVetoLogKey: string | null = null;
  private lastBrainVetoLogAtMs = 0;
  /** D14 — per ticker+reason 60s log throttle (regime line, TAKE, all bind stamps). */
  private readonly logThrottle = new LogThrottle(60_000);
  /** D3 — one trace row per ticker+code+reason per 60s for high-rate skips/blocks. */
  private readonly traceThrottle = new LogThrottle(60_000);
  /** D3 — since-boot TAKE signals vs Mind/brain blocks by reason (status.entryFunnel). */
  readonly entryFunnel = new EntryFunnelCounter();

  /**
   * F1 — Fresh Mind interpret with pendingFrozenFill.shadow immediately before placeOrder.
   * No LLM. Soft CC_VEL alone stays soft; captain HEAVE / preferSkip bind separately.
   */
  private refreshBrainCenterForPlaceOrder(params: {
    side: "yes" | "no";
    strategyId: string;
    askCents: number;
  }): import("./organs/brain-center.js").BrainCenterReport {
    const shadowSrc = this.pendingFrozenFill?.shadow ?? this.openTrade?.frozenShadow ?? null;
    const frozenShadow = shadowSrc
      ? {
          ccVelocityWouldBlock: shadowSrc.ccVelocityWouldBlock ?? null,
          regimeWouldBlock: shadowSrc.regimeWouldBlock ?? null,
          mtfScore: shadowSrc.mtfScore ?? null,
          velocityDolPerMin: shadowSrc.velocityDolPerMin ?? null,
          w2Reason: shadowSrc.w2Reason ?? null,
          constructedNo: shadowSrc.constructedNo ?? null,
          lagProven: shadowSrc.lagProven ?? null,
          lagStale: shadowSrc.lagStale ?? null,
        }
      : null;
    const freshness = this.lastTapeOrgan?.freshness ?? null;
    // Prefer live organ admission; if pending frozen fill, ensure sole TAKE so
    // shadow conflicts / captain see a real TAKE attempt (not stale SKIP poll).
    let admission =
      demoteTakeIfStale(this.lastOrganReport?.admission ?? null, freshness)
      ?? null;
    if (this.pendingFrozenFill != null && !admissionMatchesPlaceOrder(admission, params)) {
      admission = stampAdmissionMsg({
        report: {
          action: "take",
          side: params.side,
          strategyId: params.strategyId,
          askCents: params.askCents,
          p: this.pendingFrozenFill.p,
          ev: this.pendingFrozenFill.ev,
          reason: "frozen_cc_place_refresh",
        },
        frozenCcMode: true,
        frozenSoleDecision: "TAKE",
        frozenSoleCode: "FROZEN_CC_TAKE",
      });
    }
    const lagMeterStatus = getLagMeterStatus(basisTracker.getLagMeter());
    const report = interpretBrainCenter({
      ticker: kalshiWS.getLatest()?.ticker ?? null,
      orderbook: kalshiWS.getLatestOrderbook(),
      orderbookConsistency: brainOrderbookConsistency(),
      balanceCents: this.config.paperMode ? this.paperVirtualBalanceCents : (this.accountBalance ?? null),
      frozenCcMode: this.config.frozenCcMode === true,
      paperMode: this.config.paperMode === true,
      secsRemaining: (() => { try { return getSecsRemaining(); } catch { return null; } })(),
      lastTickMs: this.lastBrainTickMs,
      proposedSize: null,
      admission,
      feedFreshness: freshness,
      sensorBundle: stampSensorMsg({
        freshness,
        regime: this.lastAdaptiveRegime?.rt
          ? {
              vol: this.lastAdaptiveRegime.rt.vol,
              shape: this.lastAdaptiveRegime.rt.shape,
              confidence: this.lastAdaptiveRegime.rt.confidence,
            }
          : null,
        lag: {
          lagSeconds: lagMeterStatus.lagSeconds ?? null,
          lagProven: lagMeterStatus.proven === true,
          lagStale: lagMeterStatus.stale === true,
          indexProxyFresh: this.indexProxyFresh(),
        },
        gold: { cellId: null, nSample: null },
      }),
      exitMonitor: this.openTrade ? (this.lastExitMonitorStamp ?? null) : null,
      settleStamp: this.lastSettleStamp,
      structuralRuinShadow: this.openTrade
        ? (this.lastStructuralRuinShadow ?? null)
        : null,
      frozenShadow,
      strategicContext: {
        session: this.lastMarketState?.session != null ? String(this.lastMarketState.session) : null,
        regimeLabel: this.lastAdaptiveCondition?.condition
          ?? (this.lastAdaptiveRegime?.rt?.shape != null
            ? String(this.lastAdaptiveRegime.rt.shape)
            : null),
        drawdownPct: this.peakBalanceCents > 0
          ? Math.max(0, (1 - this.paperVirtualBalanceCents / this.peakBalanceCents) * 100)
          : null,
        promoteReady: false,
      },
    });
    this.lastBrainCenter = report;
    this.lastBrainTickMs = Date.now();
    return report;
  }

  private async placeOrder(params: Parameters<TradingBot["_placeOrderBody"]>[0]) {
    if (isHardNoFillStrategy(params.strategyId)) {
      this.log("warn", `⛔ HARD_NO_FILL ${params.strategyId} — fail-closed at placeOrder (evaluate TAKE / SIZE_RESCUE cannot fill)`);
      return;
    }
    // PR #16 option B — advisory heave tag carried into the paper entry/tape.
    let mindAdvisoryTag: { advisoryVetoes: string[]; mindHeave: MindHeaveTag | null } | null = null;
    // F1 — Fresh Mind + HEAVE/preferSkip bind under frozenCc (before agent gate).
    // Soft CC_VEL alone does NOT hard-gate (n < 40). No LLM.
    // PR #16: OV-SKIP / coversBoth / calibration heave terms are advisory
    // (tagged + MIND_HEAVE_ADVISORY trace); every other heave term still blocks.
    if (
      this.config.paperMode === true
      && (params.frozenCc === true || this.config.frozenCcMode === true)
    ) {
      try {
        const ask = params.decisionAskCents ?? params.entryPrice;
        const fresh = this.refreshBrainCenterForPlaceOrder({
          side: params.side,
          strategyId: params.strategyId,
          askCents: ask,
        });
        const bind = decideFrozenCcMindBind({
          report: fresh,
          brainCenterAuthority: this.config.brainCenterAuthority === true,
        });
        if (bind.action === "BLOCK") {
          // P2-D: dedupe BRAIN_CENTER_VETO when reason is six-gate SKIP refresh.
          // Keep first bind visible; rate-limit identical ticker+reason.
          const sixGateSkipRefresh =
            bind.stamp === "BRAIN_CENTER_VETO"
            && /six-gate\s+SKIP/i.test(bind.reason);
          let periodKey = "";
          try { periodKey = getPeriodKey(); } catch { periodKey = ""; }
          const vetoKey = `${params.ticker}|${periodKey}|${bind.stamp}|${bind.reason}`;
          const nowMs = Date.now();
          void sixGateSkipRefresh;
          this.entryFunnel.bump(`BLOCK:${blockReasonBucket(bind.stamp, bind.reason)}`);
          // D14 — dedupe every bind stamp per ticker+stamp+reason per 60s.
          const bindMsg = this.logThrottle.gate(throttleKey(params.ticker, bind.stamp, bind.reason), `⛔ ${bind.stamp}: ${bind.reason}`, nowMs);
          if (bindMsg) {
            this.log("warn", bindMsg);
            this.lastBrainVetoLogKey = vetoKey;
            this.lastBrainVetoLogAtMs = nowMs;
          }
          // D3 — evaluate-trace row for the real blocker (one per ticker+stamp+reason per 60s).
          if (this.traceThrottle.gate(throttleKey(params.ticker, "BIND", bind.stamp, bind.reason), "1", nowMs) != null) {
            try {
              let secsForTrace = 0;
              try { secsForTrace = getSecsRemaining(); } catch { secsForTrace = 0; }
              const q = kalshiWS.getLatest();
              const sameTicker = q?.ticker === params.ticker;
              this.logSkippedDecision(bind.stamp, [bind.reason], {
                ticker: params.ticker,
                side: params.side,
                strategyId: params.strategyId,
                entryPriceCents: ask,
                confidence: params.confidence,
                secsRemaining: secsForTrace,
                floorStrike: params.floorStrike,
                traceId: params.traceId,
                pWin: params.strategyWinRate,
                netEVcents: this.pendingFrozenFill?.ev,
                yesAsk: sameTicker ? q?.yesAsk : (params.side === "yes" ? ask : null),
                noAsk: sameTicker ? q?.noAsk : (params.side === "no" ? ask : null),
              });
            } catch { /* trace never affects the block */ }
          }
          // D3(c) — the entry-shadow ledger stamped realDecision:"TAKE" before
          // the bind; append the veto outcome for that decision.
          try {
            const sid = this.pendingFrozenFill?.entryShadowDecisionId ?? null;
            if (sid) appendEntryShadowVeto({ decisionId: sid, ticker: params.ticker, side: params.side, realDecision: `VETO:${bind.stamp}`, reason: bind.reason });
          } catch { /* observe-only */ }
          this.lastSignalDesc = `${bind.stamp}: ${bind.reason}`;
          this.recordAutopilotDecision("SKIP", params.side, this.lastSignalDesc);
          // Shadow calibration: the blocked take still teaches calibration once
          // its market settles (source:"shadow"; never a position/balance/trade).
          try {
            let secsLeft: number | null = null;
            try { secsLeft = getSecsRemaining(); } catch { secsLeft = null; }
            const sh = recordShadowTake({
              ticker: params.ticker,
              side: params.side,
              p: params.strategyWinRate,
              askCents: ask,
              windowKey: periodKey || params.ticker,
              closeMs: typeof secsLeft === "number" && Number.isFinite(secsLeft) ? nowMs + secsLeft * 1000 : null,
              strategyId: params.strategyId,
              blockStamp: bind.stamp,
              blockReason: bind.reason,
              depth: fresh.bookDepth ?? null,
            });
            if (sh.recorded) {
              this.log("info", `🜁 SHADOW_CALIB recorded ${params.ticker} ${params.side.toUpperCase()} p=${params.strategyWinRate} ask=${ask}¢ (blocked by ${bind.stamp}; no position) depth: ${fresh.bookDepth?.reason ?? "n/a"}`);
            }
          } catch { /* shadow calibration never affects the block */ }
          void persistDecisionTraceEvent({
            eventType: "SKIP",
            ticker: params.ticker,
            side: params.side,
            strategyId: params.strategyId,
            chain: [bind.stamp, bind.reason],
            skipChain: [bind.stamp],
            gates: { agentStamp: bind.stamp },
            traceId: params.traceId,
          });
          return;
        }
        // PR #16 option B — allowed. Tag the entry (advisoryVetoes [] = unflagged).
        const adv = bind.advisory ?? null;
        const advKey = `${params.ticker}|${params.side}`;
        mindAdvisoryTag = {
          advisoryVetoes: adv?.advisoryVetoes ? [...adv.advisoryVetoes] : [],
          mindHeave: adv?.heave && adv.heaveValue
            ? { key: advKey, ...adv.heaveValue }
            : null,
        };
        if (adv?.heave === true) {
          const nowMs = Date.now();
          const terms = adv.advisoryVetoes.join(",") || "none";
          const advMsg = this.logThrottle.gate(
            throttleKey(params.ticker, MIND_HEAVE_ADVISORY, advKey, terms),
            `🟡 ${MIND_HEAVE_ADVISORY} ${advKey} — would have blocked under F1 [${terms}] (advisory; hard terms clear)`,
            nowMs,
          );
          if (advMsg) this.log("info", advMsg);
          if (this.traceThrottle.gate(throttleKey(params.ticker, "ADVISORY", advKey, terms), "1", nowMs) != null) {
            void persistDecisionTraceEvent({
              eventType: "CANDIDATE",
              ticker: params.ticker,
              side: params.side,
              strategyId: params.strategyId,
              chain: [MIND_HEAVE_ADVISORY, advKey, ...adv.advisoryVetoes],
              gates: {
                agentStamp: MIND_HEAVE_ADVISORY,
                windowSideKey: advKey,
                advisoryVetoes: adv.advisoryVetoes,
                mindHeave: mindAdvisoryTag.mindHeave,
              },
              traceId: params.traceId,
            });
          }
        }
      } catch (err) {
        this.log("warn", `Mind place-bind refresh failed (fail-open to agent gate): ${(err as Error).message}`);
      }
    }
    // Agent control plane (deterministic — no LLM): halt / sit / skip / brain veto / park.
    if (this.config.agentControlMode === true) {
      // Expire stale pending
      if (this.pendingAgentEntry && isPendingExpired(this.pendingAgentEntry)) {
        this.log("info", `agent pendingAgentEntry timeout id=${this.pendingAgentEntry.id} → SKIP`);
        void persistDecisionTraceEvent({
          eventType: "SKIP",
          ticker: this.pendingAgentEntry.ticker,
          side: this.pendingAgentEntry.side,
          strategyId: this.pendingAgentEntry.strategyId,
          chain: ["AGENT_TIMEOUT", `id=${this.pendingAgentEntry.id}`],
          skipChain: ["AGENT_TIMEOUT"],
          gates: { agentStamp: "AGENT_TIMEOUT" },
          traceId: this.pendingAgentEntry.traceId,
        });
        this.pendingAgentEntry = null;
        this.lastSignalDesc = "AGENT_TIMEOUT: pending entry expired → SKIP";
      }
      // Fresh brain report (refreshed above under frozenCc; else last poll stamp)
      const brainReport = this.lastBrainCenter;
      const gate = decideAgentEntryGate({
        agentControlMode: true,
        requireAgentEntryApproval: this.config.requireAgentEntryApproval === true,
        brainCenterAuthority: this.config.brainCenterAuthority === true,
        paperMode: this.config.paperMode === true,
        directives: this.agentDirectives,
        brainReport,
      });
      if (gate.action === "BLOCK") {
        if (gate.stamp === "AGENT_SKIP_NEXT") {
          this.agentDirectives = consumeSkipNext(this.agentDirectives);
        }
        this.log("warn", `⛔ ${gate.stamp}: ${gate.reason}`);
        this.lastSignalDesc = `${gate.stamp}: ${gate.reason}`;
        this.recordAutopilotDecision("SKIP", params.side, this.lastSignalDesc);
        void persistDecisionTraceEvent({
          eventType: "SKIP",
          ticker: params.ticker,
          side: params.side,
          strategyId: params.strategyId,
          chain: [gate.stamp, gate.reason],
          skipChain: [gate.stamp],
          gates: { agentStamp: gate.stamp },
          traceId: params.traceId,
        });
        return;
      }
      if (gate.action === "PARK") {
        // Replace any prior pending (latest TAKE wins)
        const ask = params.decisionAskCents ?? params.entryPrice;
        this.pendingAgentEntry = newPendingAgentEntry({
          side: params.side,
          ask,
          strategyId: params.strategyId,
          ticker: params.ticker,
          proposal: { ...params } as unknown as Record<string, unknown>,
          brainReport,
          traceId: params.traceId,
        });
        this.lastSignalDesc = `pendingAgentEntry ${this.pendingAgentEntry.id} awaiting agent approve (${params.strategyId} ${params.side} @${ask}¢)`;
        this.log("info", `⏸️ ${this.lastSignalDesc}`);
        void persistDecisionTraceEvent({
          eventType: "SKIP",
          ticker: params.ticker,
          side: params.side,
          strategyId: params.strategyId,
          chain: ["AGENT_PENDING", this.pendingAgentEntry.id],
          skipChain: ["AGENT_PENDING"],
          gates: { agentStamp: "AGENT_PENDING" },
          traceId: params.traceId,
        });
        return;
      }
    }
    // FROZEN_CC dual-brain kill: frozenCcMode → placeOrder only via decideFrozenCcEntry TAKE.
    if (shouldBlockPlaceOrderWithoutFrozenDecision({
      frozenCcMode: this.config.frozenCcMode,
      frozenCc: params.frozenCc,
    })) {
      this.log("warn",
        `⛔ FROZEN_CC_SOLE_TAKE ${params.strategyId} — placeOrder blocked (frozenCcMode requires decideFrozenCcEntry TAKE / frozenCc:true)`,
      );
      this.lastSignalDesc = "FROZEN_CC_SOLE_TAKE: legacy funnel cannot place without frozen decision";
      return;
    }
    // Non-frozen sole take (F2): organTake identity = take + same strategyId/side/ask±1¢.
    // When frozenCcMode TRUE this helper is a no-op — FROZEN_CC_SOLE_TAKE remains sole.
    // Fail-closed: bare action==="take" without identity does NOT allow.
    if (shouldBlockPlaceOrderWithoutOrganTake({
      frozenCcMode: this.config.frozenCcMode,
      organTake: params.organTake,
      organReport: this.lastOrganReport,
      strategyId: params.strategyId,
      side: params.side,
      askCents: params.decisionAskCents ?? params.entryPrice,
    })) {
      this.log("warn", formatDirectorTakeRequiredDesc(params.strategyId));
      this.lastSignalDesc = `${DIRECTOR_TAKE_REQUIRED}: placeOrder needs organ take identity (strategyId/side/ask±1¢) when frozenCcMode is false`;
      return;
    }
    // Sole 15m admit document: paper-release then director (decision-envelope).
    {
      const env = evaluate15mAdmissionEnvelope({
        paperMode: this.config.paperMode === true,
        ticker: params.ticker,
        strategyId: params.strategyId,
        askCents: params.decisionAskCents ?? params.entryPrice,
        frozenCc: params.frozenCc === true,
        reconciliationHalt: this.paperReconcileHalt === true,
        side: params.side,
        durationMins: 15,
        frozenSixGateFill: params.frozenCc === true,
        organAction: this.lastOrganReport?.action ?? null,
        organReason: this.lastOrganReport?.reason ?? null,
        organSide: this.lastOrganReport?.side ?? null,
        organStrategyId: this.lastOrganReport?.strategyId ?? null,
        organP: this.lastOrganReport?.p ?? null,
        organEv: this.lastOrganReport?.ev ?? null,
        organSize: this.lastOrganReport?.size ?? null,
      });
      if (!env.admit) {
        const code = env.blockReason?.startsWith("DIRECTOR_")
          ? "DIRECTOR_PLACEORDER_BLOCK"
          : (env.blockReason ?? "15M_ENVELOPE_BLOCK");
        this.log("warn",
          `⛔ order refused by 15m decision envelope (${code}): ${env.blockReason}`);
        this.lastSignalDesc = `order refused by 15m decision envelope: ${env.blockReason}`;
        return;
      }
    }
    if (this.orderAdmissionLock) {
      this.log("info", `⛔ Order skipped — another order is already being placed (cross-horizon race guard)`);
      return;
    }
    // Task #604: one-position rule at the only admission point. Covers
    // in-memory openTrade, a pending row from a prior process, and a live
    // account-audit mismatch. Paper virtualCents is isolated: live Kalshi
    // manuals/unmanaged must not evaluate-approve-then-skip a paper fill.
    // One paper position still binds.
    {
      const paperAccountStatus = accountStatusForPaperEntry({
        paperMode: this.config.paperMode,
        accountStatus: this.accountPositionAudit.status,
      });
      const accountBlocksSecond =
        paperAccountStatus === "unknown"
        || paperAccountStatus === "unmanaged"
        || paperAccountStatus === "tracked-mismatch";
      if (shouldBlockSecondPosition({
        hasOpenTrade: this.openTrade != null,
        hasPendingUnsettled: this.heldPendingFromRestart,
        accountStatus: paperAccountStatus,
      })) {
        // Paper sticky query-error latch: re-prove via SELECT below (clear only
        // after successful empty). Do not permanent-skip when latch alone blocks.
        if (!shouldReproveHeldPendingViaSelect({
          paperMode: this.config.paperMode === true,
          hasOpenTrade: this.openTrade != null,
          heldPendingFromRestart: this.heldPendingFromRestart,
          accountBlocks: accountBlocksSecond,
        })) {
          const why = this.openTrade
            ? `a position is already open (${this.openTrade.ticker})`
            : this.heldPendingFromRestart
              ? "a pending trade from the prior process is still open"
              : `account audit is ${this.accountPositionAudit.status}`;
          this.log("info", `⛔ Order skipped — ${why}`);
          return;
        }
      }
    }
    this.orderAdmissionLock = true;
    try {
      // Paper: re-check live pending rows every admission (not only restart latch).
      // Closes the mid-session orphan hole: openTrade cleared, PG pending remains,
      // same-ticker double paper fill (YES15@43 pending + YES16@40).
      // Transient SELECT errors retry before permanent query-error latch; latch
      // clears only after a successful empty SELECT (re-prove flat).
      if (this.config.paperMode === true) {
        const now = Date.now();
        const maxAttempts = PAPER_PENDING_QUERY_MAX_ATTEMPTS;
        let rows: Array<{
          id: number;
          ticker: string;
          createdAt: Date;
          contractDurationMins: number | null;
          outcome: string | null;
          isPaper: boolean | null;
        }> | null = null;
        let lastErr: Error | null = null;
        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
          try {
            rows = await db.select({
              id: botTrades.id,
              ticker: botTrades.ticker,
              createdAt: botTrades.createdAt,
              contractDurationMins: botTrades.contractDurationMins,
              outcome: botTrades.outcome,
              isPaper: botTrades.isPaper,
            }).from(botTrades).where(
              or(eq(botTrades.outcome, "pending"), eq(botTrades.outcome, "unresolved")),
            );
            lastErr = null;
            break;
          } catch (err) {
            lastErr = err as Error;
            if (shouldRetryPaperPendingQueryBeforeLatch({ attempt, maxAttempts })) {
              this.log("warn",
                `paper pending double-fill check query error attempt ${attempt}/${maxAttempts} — retrying: ${lastErr.message}`,
              );
              await new Promise(r => setTimeout(r, 50));
              continue;
            }
          }
        }
        if (lastErr != null || rows == null) {
          // Fail-closed after retries: never soft-continue into a paper fill when
          // we cannot prove there is no live pending row.
          if (shouldFailClosedOnPaperPendingQueryError({
            paperMode: true,
            queryError: true,
          })) {
            this.heldPendingFromRestart = true;
            this.log("warn",
              `paper pending double-fill check failed (fail-closed BLOCK after ${maxAttempts} attempts): ${lastErr?.message ?? "no rows"}`,
            );
            return;
          }
        } else {
          const livePaper = rows.filter(r =>
            isPendingStillLive(r, now) &&
            pendingCountsForRestartHold({ paperMode: true, isPaper: r.isPaper }),
          );
          const same = livePaper.find(r => r.ticker === params.ticker);
          if (shouldBlockSameTickerPaperFill({
            paperMode: true,
            pendingSameTicker: same != null,
            anyLivePaperPending: livePaper.length > 0,
          })) {
            this.heldPendingFromRestart = true;
            const tip = same ?? livePaper[0];
            // Mid-session orphan class #9/#11: pending exists but openTrade null —
            // rehydrate so PATH_RIDE continues (still block this new fill).
            if (shouldRehydratePaperOpenTrade({
              paperMode: true,
              openTradeNull: this.openTrade == null,
              hasLivePaperPending: livePaper.length > 0,
            })) {
              await this.adoptRestartPendingGuard();
            }
            this.log("info",
              `⛔ Order skipped — live paper pending #${tip?.id ?? "?"} ${tip?.ticker ?? "?"}` +
              `${same ? " (same-ticker double-fill block)" : " (one paper position)"}`,
            );
            return;
          }
          if (shouldClearHeldPendingAfterEmptySelect({
            selectSucceeded: true,
            livePendingCount: livePaper.length,
          })) {
            this.heldPendingFromRestart = false;
          }
        }
      }
      await this._placeOrderBody(mindAdvisoryTag ? { ...params, mindAdvisory: mindAdvisoryTag } : params);
    } finally {
      this.orderAdmissionLock = false;
    }
  }

  private async _placeOrderBody(params: {
    signal: "LONG" | "SHORT"; side: "yes" | "no"; entryPrice: number;
    floorStrike: number; ticker: string; confidence: number; secs: number;
    strategyWinRate: number; strategyId: string; grokRegime?: GrokRegime;
    isOTMAsymmetry?: boolean;  // OTM Hunter: 5–25¢ entries, 10% equity sizing
    isOTMExpansion?: boolean;   // triggers 45% size reduction + wider time window
    /** Adaptive condition cap — never exceed this regardless of Kelly sizing. */
    conditionMaxContracts?: number;
    /** ARIA-derived size multiplier (0.4–1.0) applied after Kelly contract count */
    ariaSizeMult?: number;
    /** Live velocity ($/min) at order time — enables computeTradeEV's high-velocity
     *  dynamic slippage widening, the same signal PATH_GATE uses. Omit to fall
     *  back to the flat baseline slippage (same as pre-refactor behavior). */
    velocityDolPerMin?: number;
    /** Live bid-ask spread (¢) on the traded side at order time — enables
     *  computeTradeEV's thin-book/wide-spread slippage floor, the same signal
     *  PATH_GATE uses. Omit to fall back to the flat baseline slippage. */
    spreadCents?: number;
    /** Paper CC/LAG maker rest (limit-at-bid). Live ignored. */
    makerEntry?: boolean;
    /** Universal price-band gate (master bot upgrade step 2) — 0.5 for the
     *  56-70¢ half tier (unless a late-anchor exception applied), else 1.
     *  Applied to the non-OTM sizing branch alongside conviction/session mults;
     *  OTM strategies always ask well under the 45¢ full-size ceiling. */
    priceBandSizeMult?: number;
    /** Stack size tier (master bot upgrade step 4) — 0.5 probe / 1 standard / 1.5 press.
     *  Applied to the non-OTM sizing branch alongside priceBandSizeMult/HARVEST;
     *  purely a sizing adjustment on an already-approved trade. */
    stackSizeMult?: number;
    /** SIZE_TIER label matching stackSizeMult, recorded on the open trade for logging/analysis only. */
    sizeTier?: SizeTier;
    /** GO — VOLUME AS RISK SCALAR (2026-08-18): the volume bucket/score computed
     *  once in evaluateEntry() (computeVolumeScore(obs)) and its resulting size
     *  multiplier, threaded through here since this method doesn't have `obs`
     *  in scope. volumeSizeMult multiplies AFTER uMult in computeContracts;
     *  volumeBucket/volumeScoreV are persisted on the trade row (logging +
     *  post-settlement learning input only, never read back for this trade). */
    volumeSizeMult?: number;
    volumeBucket?: VolumeBucket;
    volumeScoreV?: number;
    /** GO — APPLY PACKS ENFORCE (2026-08-18): the live pack's sizeCapMult for
     *  this tick (15m path only — evaluateEntry() sets this from
     *  enforcedPack; no other caller passes it, so it defaults to a no-op 1
     *  everywhere else, incl. the hourly path). Multiplies AFTER uMult and
     *  volumeSizeMult in computeContracts, inside the spec's [0.15, 1.15]
     *  combinedMult safety clamp. */
    packSizeCapMult?: number;
    /** Risk profile + path + regime context for profile-aware sizing */
    modeState?: ModeState;
    /** Eastern-market liquidity regime captured during initial path evaluation for traceability. */
    timeOfDayRegime?: TimeOfDayRegime;
    /** 15 (default) or 60 — recorded on the open trade and used by all gates below. */
    contractDurationMins?: number;
    /** Market close time (ms epoch) — authoritative expiry clock for hourly trades. */
    closeTimeMs?: number;
    /** The getEntryPriceBand() result that was actually enforced by the caller
     *  when this order was evaluated — stored on the open trade so later
     *  post-fill/re-quote checks judge against what was ACTUALLY applied,
     *  not a value recomputed after the effective config may have moved on. */
    entryBandMin?: number;
    entryBandMax?: number;
    /** Internal: set when this order IS a re-quote (chased price once already).
     *  Bounds the chase to exactly one hop — without it, each re-quoted order
     *  re-armed its own fresh requeueContext and could chase again and again,
     *  producing a live IN_TRADE ⇄ WATCHING flip roughly every 12s per hop
     *  (visible as the state badge "flickering" on the Bot page) while also
     *  walking the limit price away from the original signal's edge. */
    requoteCount?: number;
    /** PR #16 option B — advisory heave tag from the placeOrder bind (evidence only). */
    mindAdvisory?: { advisoryVetoes: string[]; mindHeave: MindHeaveTag | null };
    /** GO POST_SIM QUOTE FRESHNESS GATE: the raw ask for `side` captured at
     *  decision time, BEFORE the pre-trade-sim await (evaluateEntry()'s
     *  `rawAsk` / _evaluateHourlyTickBody()'s `rawAsk`) — distinct from
     *  `entryPrice`, which already includes the sweep-above-ask premium.
     *  Falls back to `entryPrice` when omitted (re-quotes and any other
     *  internal caller that doesn't track a separate decision-time ask). */
    decisionAskCents?: number;
    /** GO — SPECIALIST REGIME SYSTEM Phase 0 (DecisionTrace): the per-decision
     *  trace id generated once at the top of the calling evaluateEntry() /
     *  considerAddingToPosition() / _evaluateHourlyTickBody() invocation.
     *  Persisted onto the bot_trades row and the ORDER DecisionTrace so a
     *  fill/settlement can be joined back to the exact reasoning chain that
     *  produced it. Falls back to a freshly generated id for any internal
     *  caller (e.g. re-quotes) that doesn't thread one through — an order
     *  must never be blocked or altered for lacking a traceId. */
    traceId?: string;
    /** GO — SPECIALIST REGIME SYSTEM Phase 2 (SHADOW ONLY): the winning
     *  StrategyResult's edgePct (0-1 scale), threaded through only so the
     *  shadow pack evaluator can check BASIS_LAG_EDGE's minLagEdgePts
     *  against real data instead of guessing. Observation-only — never
     *  read by any live gate, sizing, or order-path logic. */
    edgePct?: number;
    /** Profit Doctrine Phase 6.2 (2026-08-25): the SAME PreTradeVerdict object
     *  instance evaluateEntry() already stamped onto this.lastPreTradeVerdict
     *  for this decision. Passed through so a sizing collapse to 0 contracts
     *  (SIZING_ZERO / RISK_PROFILE / DAILY_TARGET_SIZE_ZERO / DRAWDOWN_GUARD —
     *  admission-survival-funnel's S6 stage) can annotate
     *  verdict.blockedAfterApproval the same way S5 gates (regime/ARIA/
     *  settlement/PATH_GATE) already do. Since objects are by-reference and
     *  this.lastPreTradeVerdict already points at this instance, mutating it
     *  here is visible on the dashboard with no extra plumbing. Optional and
     *  purely observational: never read back to alter sizing or order logic. */
    verdict?: PreTradeVerdict;
    /** The fine-grained RegimeId (regime-engine.ts's `updateRegime()` output —
     *  'unclear' | 'range' | 'strong_uptrend' | 'waterfall' | ... ) the caller
     *  actually evaluated this trade against — the same value threaded into
     *  scoreStrategyEV()'s regime-EV filter and evaluatePathDecision(). This
     *  is distinct from `grokRegime`, the coarse 5-bucket taxonomy
     *  ('trending'|'ranging'|'transitioning'|'high_vol'|'low_vol') derived
     *  from it for allowlists/sizing. Persisted onto bot_trades.regime so
     *  regime-ev-stats.ts's regime×strategy empirical tier can actually match
     *  a future live lookup — it never could when this field wrote
     *  grokRegime instead, because getEmpiricalRegimeAdjustment() is always
     *  called with the fine-grained RegimeId, not the coarse GrokRegime, so
     *  the two vocabularies never intersected. Falls back to grokRegime for
     *  any caller (there are none left) that predates this field. */
    detailedRegime?: string;

    /** FROZEN_CC six-gate path: legacy CC-vel / lockSide fill gates become shadow flags. */
    frozenCc?: boolean;
    /**
     * Non-frozen organ take stamp (F2 identity: take + strategyId + side + ask±1¢).
     * Required at placeOrder when frozenCcMode is false. Ignored when frozen
     * (FROZEN_CC_SOLE_TAKE / frozenCc:true owns that path). Survives requote.
     */
    organTake?: boolean;
  }) {
    const { signal, side, floorStrike, ticker, confidence, secs, strategyWinRate, strategyId, velocityDolPerMin, spreadCents } = params;
    // Intentionally recompute at final order admission. A re-quote can cross
    // into a different Eastern-market liquidity regime while its original order cancels.
    const timeOfDayRegime = getTimeOfDayRegime();
    // Task #441: mutable (not const) — the paper branch below overwrites this
    // with a simulated slippage-adjusted fill price so every downstream use
    // (setOpenTrade, DB writes, logs) reflects the realistic cost, not the
    // originally-quoted price.
    let entryPrice = params.entryPrice;
    const durationMins = params.contractDurationMins ?? 15;
    // GO — SPECIALIST REGIME SYSTEM Phase 0: reuse the caller's traceId when
    // provided (the normal case — evaluateEntry()/considerAddingToPosition()/
    // _evaluateHourlyTickBody() all thread one through); only a caller that
    // predates Phase 0 wiring would omit it, so generate a fallback rather
    // than ever leaving an order without a traceId.
    const orderTraceId = params.traceId ?? generateTraceId();
    // GO — SPECIALIST REGIME SYSTEM Phase 0 (DecisionTrace): _placeOrderBody
    // is the shared admission point both entry paths funnel through (see the
    // POST_SIM QUOTE FRESHNESS GATE comment below), so its own skip calls
    // must carry the *caller's* traceId (orderTraceId), not a fresh one.
    const skip = makeTraceScopedSkip(this.logSkippedDecision.bind(this), { traceId: orderTraceId });

    // Leftover/disabled fill hard-block. disabledStrategies + leftover denylist
    // beat evaluate TAKE / SIZE_RESCUE / backgroundPreTrade. CC/LAG not denylisted.
    // Single gate (was duplicated): annotate verdict + lastSignalDesc so UI honesty
    // matches LEFTOVER_PLACEORDER_BLOCK skips after an evaluate TAKE.
    const leftoverBlock = placeOrderStrategyHardBlockReason(strategyId, this.config);
    if (leftoverBlock) {
      this.log("warn", `⛔ HARD_NO_FILL ${strategyId} — ${leftoverBlock} (evaluate TAKE / SIZE_RESCUE cannot fill)`);
      this.lastSignalDesc = leftoverBlock;
      if (params.verdict) params.verdict.blockedAfterApproval = leftoverBlock;
      skip("LEFTOVER_PLACEORDER_BLOCK", [leftoverBlock], {
        ticker, side, strategyId, entryPriceCents: entryPrice,
        confidence, secsRemaining: secs, floorStrike, proposedContracts: 0,
      });
      return;
    }

    // #725: momentum CC must not fire NO into strongly green 1m velocity
    // (e.g. +$56/min) nor YES into strongly red. Fail-closed only when vel present.
    const ccVelGate = ccVelocityAgainstGate({
      strategyId,
      side,
      velocityDolPerMin: velocityDolPerMin ?? this.currentVelocity,
    });
    if (ccVelGate.block && params.frozenCc === true) {
      // FROZEN_CC: shadow only (already stamped on the fill's shadow flags).
      this.log("info", `🧊 [FROZEN_CC] shadow ${ccVelGate.reason} — would have blocked, not enforced`);
    } else if (ccVelGate.block) {
      const reason = ccVelGate.reason;
      this.log("warn",
        `⛔ ${reason}: CC ${String(side).toUpperCase()} vs 1m vel=${velocityDolPerMin ?? this.currentVelocity} $/min — size 0`);
      this.lastSignalDesc = reason;
      if (params.verdict) params.verdict.blockedAfterApproval = reason;
      skip(reason, [`CC velocity against side (threshold ±40 $/min)`], {
        ticker, side, strategyId, entryPriceCents: entryPrice,
        confidence, secsRemaining: secs, floorStrike, proposedContracts: 0,
      });
      return;
    }

    // ── Price feed sanity check ───────────────────────────────────────────────
    // Reject orders with an out-of-range entry price immediately, before any
    // sizing, balance refresh, or state mutation.  A zero or 100¢ price means
    // the feed stalled; we log a clear skip message so the user has an early
    // warning and the activity log never shows a generic "Order Failed" line.
    if (!isValidKalshiPrice(entryPrice)) {
      this.log("warn",
        `⛔ Bot order skipped — price ${entryPrice}¢ outside 1–99¢ range (stale/zero feed?)`
      );
      // Card honesty: bare return — demote sticky TAKE (skip() not called).
      if (this.lastMoneyGateCard?.approved === true) {
        this.lastMoneyGateCard = demoteMoneyGateCardToSit(this.lastMoneyGateCard, "ASK_OUT_OF_BAND");
      }
      return;
    }

    // ── Time-of-day path hard block ──────────────────────────────────────────
    // This shared, final-admission check covers every order route, including
    // OTM strategies (which have their own earlier evaluator) and re-quotes.
    const orderPath = getPathConfig(entryPrice).path;
    if (isPathBlockedForTimeOfDay(orderPath, timeOfDayRegime)) {
      const reason = "MULTIPLIER path disabled during ASIAN_HOURS liquidity regime";
      this.log("info", `🌙 Time-of-day path gate: ${reason} — order skipped`);
      this.lastSignalDesc = reason;
      if (params.verdict) params.verdict.blockedAfterApproval = `Time-of-day path gate (S6): ${reason}`;
      skip("PATH_GATE", [reason], {
        ticker, side, strategyId, entryPriceCents: entryPrice,
        confidence, secsRemaining: secs, floorStrike, proposedContracts: 0,
      });
      return;
    }

    // ── DAILY-LOSS HALT COVERAGE FIX ──────────────────────────────────────────
    // _placeOrderBody is the single admission point EVERY order (15-min and
    // hourly) funnels through — the daily-loss circuit breaker used to be
    // enforced only in the 15m evaluator's own pre-checks and the
    // post-settlement suspend() call, with no gate here at all. That left two
    // gaps: (1) the hourly path (_evaluateHourlyTickBody) never checked it, so
    // an hourly order could open fresh risk after the cap was already hit;
    // (2) even on the 15m path, a race between the evaluator's earlier check
    // and this later admission point (background pre-trade sim, balance
    // refresh, re-quotes) could let an order slip through if the cap was
    // crossed in between. Checking again here, right before the order is
    // sized/sent, closes both gaps with one gate instead of duplicating the
    // condition at every caller. Cap numbers themselves are untouched — see
    // isDailyLossHalted()/evaluateDailyLossHalt().
    if (this.isDailyLossHalted()) {
      this.log("warn", `⛔ Order blocked [DAILY_HALT] — daily loss cap reached (today ${(this.haltDayPnlCents() / 100).toFixed(2)}, cap ${(this.effectiveDailyLossCapCents() / 100).toFixed(2)})`);
      skip("DAILY_LOSS_HALT", [`daily loss cap reached: today ${this.haltDayPnlCents()}¢ vs cap ${this.effectiveDailyLossCapCents()}¢`], {
        ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── GO POST_SIM QUOTE FRESHNESS GATE (entry path only) ───────────────────
    // Re-validate the ask this trade was approved against is still live
    // immediately before the order goes out. This is the single admission
    // point every order (15-min and hourly) funnels through, so one gate
    // here covers both entry paths without duplicating the check at each
    // call site. Reads only the same quote caches evaluateEntry()/
    // _evaluateHourlyTickBody() already read (kalshiWS / hourlyPoller
    // getLatest()) — no extra network round-trip, no re-run of strategy
    // selection or the Monte Carlo sim itself.
    {
      const decisionAskCents = params.decisionAskCents ?? entryPrice;
      let liveTickerMatches = false;
      let liveAskCents: number | null | undefined = null;
      let feedStale = false;
      if (durationMins === 60) {
        // Hourly path: REST-polled every 30s, no per-tick WS staleness rule
        // exists on this path today (unlike the 15m WS feed) — reusing the
        // 15m thresholds here would misfire on every normal poll cycle, so
        // `feedStale` deliberately stays false per the spec's "if applicable
        // on this path" scoping; missing/moved-quote checks still apply.
        //
        // SEV2 fix (2026-08-18 audit): this used to call getLatest(), which
        // returns the cached tick unconditionally — including one whose
        // period has already closed or that's older than the poller's own
        // documented 90s freshness threshold. getFreshLatest() already
        // encodes both guards (see kalshi-1h-poll.ts) but wasn't wired into
        // this final pre-order gate, so a failed/slow poll cycle could let
        // an expired or stale hourly quote reach the order body. Using the
        // fresh getter here means a stale/expired quote now falls through to
        // `liveTickerMatches=false` below (h1 is null), which the existing
        // freshness check already treats as a skip — no new gate needed.
        const h1 = hourlyPoller.getFreshLatest();
        liveTickerMatches = !!h1 && h1.ticker === ticker;
        liveAskCents = h1 ? (side === "yes" ? h1.yesAsk : h1.noAsk) : null;
      } else {
        const tick = kalshiWS.getLatestForEntry();
        liveTickerMatches = !!tick && tick.ticker === ticker;
        liveAskCents = tick ? (side === "yes" ? tick.yesAsk : tick.noAsk) : null;
        if (tick) {
          const tickAgeMs  = Date.now() - tick.ts;
          const quoteAgeMs = Date.now() - (tick.quoteTs || 0);
          feedStale = isFeedStaleForEntry(tickAgeMs, quoteAgeMs, this.config.paperMode)
            || restQuoteBlocksFill(this.config.paperMode === true, tick.source);
        }
      }
      const freshness = evaluatePostSimQuoteFreshness({
        side, decisionAskCents, liveTickerMatches, liveAskCents, feedStale,
        tolCents: QUOTE_FRESHNESS_TOL_CENTS,
      });
      if (!freshness.ok) {
        this.log("warn", `⛔ Order aborted [${freshness.skipCode}]: ${freshness.reason}`);
        skip(freshness.skipCode, [freshness.reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
    }

    // ── Paper-only-until-reviewed strategies: generic live-mode guard ─────────
    // (Task #446/#361, generalized under Task #367). A strategy that should
    // paper-trade freely but stay blocked from real money until explicitly
    // reviewed declares `liveEnableConfigKey` on its StrategyDefinition
    // (strategy-library.ts) instead of a one-off `if (strategyId === '...')`
    // check here — this is the single admission point every order (15-min
    // and hourly) funnels through.
    if (strategyId === "PAPER_SCALP" && !this.config.paperMode) {
      this.log("warn", `⛔ PAPER_SCALP order blocked — paper-only (never live)`);
      skip("STRATEGY_PAPER_ONLY", ["PAPER_SCALP not approved for live trading"], {
        ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }
    const liveGateKey = getStrategy(strategyId as StrategyId)?.liveEnableConfigKey;
    if (liveGateKey && !this.config.paperMode && !(this.config as unknown as Record<string, unknown>)[liveGateKey]) {
      this.log("warn", `⛔ ${strategyId} order blocked — live mode active but strategy is paper-only pending backtest review`);
      skip("STRATEGY_PAPER_ONLY", [`${strategyId} not yet approved for live trading`], {
        ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── Refresh balance before every order ────────────────────────────────────
    // The 60-second timer can leave accountBalance up to a minute stale.
    // Every sizing decision — contracts, risk cap, Kelly fraction, drawdown guard
    // — depends on the real current equity. Fetch it fresh right now so we never
    // size a trade against an outdated number.
    if (!this.config.paperMode) await this.refreshBalance();

    // ── Refuse to size a live order against an unknown/stale balance ─────────
    // A failed or overdue refresh must never fall through to sizing against
    // whatever number happens to still be cached — that's how a trade gets
    // sized off equity that's minutes old and possibly wrong.
    if (!this.config.paperMode && this.isBalanceStale()) {
      const age = this.getBalanceAgeMs();
      this.lastSignalDesc = "Order aborted — live balance unknown/stale";
      this.log("warn",
        `⛔ Live order aborted — balance ${this.accountBalance === null ? "never fetched" : `${Math.round(age / 1000)}s stale`}` +
        (this.lastBalanceError ? ` (${this.lastBalanceError})` : "")
      );
      skip("BALANCE_STALE", [this.lastSignalDesc], {
        ticker, side, strategyId, entryPriceCents: entryPrice,
        confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // Re-check the daily-target admission gate AFTER the fresh balance fetch:
    // the awaited refresh can cross the target/give-back threshold, and an
    // order must not slip through on the pre-refresh status (arch critic #5).
    await this.refreshDailyTarget();
    {
      const lateBlock = dailyTargetEntryBlock(this.lastDailyTarget, this.dailyTargetLatchDirty, this.dailyTargetLoadFailed);
      if (lateBlock) {
        this.lastSignalDesc = lateBlock;
        this.log("info", `🎯 Order aborted post-balance-refresh: ${lateBlock}`);
        skip("DAILY_TARGET_LATE_BLOCK", [lateBlock], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
    }

    // SEV0 #722: CC|LAG cannot placeOrder when lockSide is SKIP / mtf null/mismatch.
    // PR #14: FROZEN_CC is no longer exempt — the frozen six-gate path stamps a
    // fresh lockSide result on lastW2Log every tick and must hold PASS here too.
    if (strategyId === "CONFLUENCE_CASCADE" || strategyId === "BASIS_LAG_EDGE" || params.frozenCc === true) {
      const lsGate = assertLockSideAllowsFill(this.lastW2Log, side);
      if (!lsGate.ok) {
        this.lastSignalDesc = `${LOCKSIDE_SKIP_NO_FILL}: ${lsGate.reason}`;
        this.log("warn", `⛔ ${LOCKSIDE_SKIP_NO_FILL} [${strategyId}] side=${side} — ${lsGate.reason}`);
        skip(LOCKSIDE_SKIP_NO_FILL, [lsGate.reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
    }

    // 2026-09-05 overnight bleed: CC filled lagProven=false → LAG_FLIP dumps.
    // Asia / short_series / stale: money-makers WAIT (never invent proven).
    if (!paperDeskMakerFillMayRun(this.config)) {
      // Soft gap 012: maker fill path denied on paper/frozen.
      this.log("info", "paperDeskMakerFillMayRun false — maker-fill path skipped on paper/frozen");
    }
    if ((strategyId === "CONFLUENCE_CASCADE" || strategyId === "BASIS_LAG_EDGE") && params.frozenCc !== true) {
      const lagGate = assertLagAllowsMoneyMakerFill({
        strategyId,
        lagProven: this.lastBasisState?.lagProven === true,
        lagStale: this.lastBasisState?.lagStale ?? true,
        lagReason: this.lastBasisState?.lagReason ?? null,
        timeOfDayRegime,
      });
      if (!lagGate.ok) {
        this.lastSignalDesc = `${LAG_UNPROVEN_NO_FILL}: ${lagGate.reason}`;
        this.log("warn", `⛔ ${LAG_UNPROVEN_NO_FILL} [${strategyId}] — ${lagGate.reason}`);
        skip(LAG_UNPROVEN_NO_FILL, [lagGate.reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
    }

    // ── Conviction-tier sizing ─────────────────────────────────────────────────
    // When all major signals are tightly aligned, let the position grow beyond
    // the base Kelly fraction — but never past effectiveMaxContracts.
    //   Tier S (×1.5): conf ≥ 78, edge ≥ 8, MTF strongly aligned, agent agrees
    //   Tier A (×1.25): conf ≥ 72, edge ≥ 6, MTF aligned
    //   Tier B (×1.0): everything else — standard sizing
    const sizingResult = this.computeContracts(confidence, entryPrice, strategyWinRate, this.lastEdge, params.grokRegime, strategyId, durationMins, paperDeskSizeMult(this.config, params.volumeSizeMult ?? 1), paperDeskSizeMult(this.config, params.packSizeCapMult ?? 1));
    const baseContracts = sizingResult.contracts;
    // Unconditional sizing trace — the many downstream multipliers (ARIA, risk
    // profile, daily target, path sizing, strategy-performance) each only log
    // when they CHANGE the count, which made it impossible to tell whether a
    // trade landed on 1 contract because of computeContracts itself or one of
    // the multipliers below. Log the base result every time so a "why only
    // 1 contract" report can be traced to the exact stage.
    this.log("info", `🧮 Base sizing [${strategyId}]: ${baseContracts}× (limiter=${sizingResult.limiter}) — ${sizingResult.detail}`);
    // ARIA may reduce a calculated position, never increase it. NOTE: this
    // raw `sizeMultiplier` field and the path-sizing `ariaSizeMult` below
    // (params.ariaSizeMult, from applyAriaPathRules' riskLevel→SIZE_MULTS
    // table) both come from the SAME expert-agent assessment. They used to
    // both get applied multiplicatively (once here, once again in path
    // sizing), so e.g. riskLevel=MEDIUM (×0.80) stacked with the AI's own
    // sizeMultiplier (×0.70) silently became a ×0.56 cut — squaring the
    // agent's caution and collapsing most trades to 1 contract regardless of
    // portfolioRiskPct (confirmed live 2026-08-08: base sizing of 3-9
    // contracts consistently landing on 1). Only the raw field is read here
    // now (for display); the actual reduction is applied once, combined with
    // the path-sizing multiplier via min(), in the path-sizing block below.
    const aiRisk = this.config.useExpertAgent ? expertAgent.getRiskOverrides() : null;
    this.lastAgentExitPolicy = aiRisk?.exitPolicy ?? null;
    this.lastAgentSizeMultiplier = aiRisk?.sizeMultiplier ?? null;
    const mtfScoreNow   = mtfAnalyzer.getScore();
    const agentAssmt    = expertAgent.getFreshAssessment();
    const mtfAligned    = (side === 'yes' && mtfScoreNow >= 2) || (side === 'no' && mtfScoreNow <= -2);
    const agentAligned  = agentAssmt
      ? (side === 'yes' && agentAssmt.signal === 'YES') || (side === 'no' && agentAssmt.signal === 'NO')
      : false;
    const convTier = (confidence >= 78 && this.lastEdge >= 8 && mtfAligned && agentAligned) ? 'S'
                   : (confidence >= 72 && this.lastEdge >= 6 && mtfAligned)                 ? 'A'
                   : 'B';
    const baseConvMult = convTier === 'S' ? 1.5 : convTier === 'A' ? 1.25 : 1.0;

    // ── Signal-stack sizing multiplier (Trading Behavior design item #1) ─────
    // Purely additive on top of the conviction tier above: the tier already
    // rewards MTF + agent agreement, so the "stack" here checks ONE further,
    // independent signal family (basis-lag: is the leading exchange price
    // actually pulling away from Kalshi's implied fair value in this trade's
    // direction?) that the tier doesn't otherwise see. A small, capped bonus
    // — never a replacement for or loosening of the tier or the hard risk
    // caps evaluated later in this function.
    const basisNow = this.lastBasisState?.rollingBasis;
    const basisAligned = basisNow != null && Number.isFinite(basisNow)
      && Math.abs(basisNow) > this.config.signalStackBasisThreshold
      && ((side === 'yes' && basisNow > 0) || (side === 'no' && basisNow < 0));
    const signalStackMult = (this.config.useSignalStackSizing && basisAligned)
      ? (this.config.paperMode === true ? DESK_SIGNAL_STACK_BONUS : this.config.signalStackBonusMult)
      : 1.0;
    const convMult = baseConvMult * signalStackMult;
    if (signalStackMult !== 1.0) {
      this.log("info", `📶 Signal-stack sizing [${strategyId}]: tier ${convTier} (×${baseConvMult}) + basis-lag agree → ×${signalStackMult.toFixed(2)} (basis=${basisNow!.toFixed(1)})`);
    }

    // OTM plays: conviction tier disabled — edge lives in payout ratio, not momentum scoring.
    const isOTMPlay = params.isOTMExpansion
      || params.isOTMAsymmetry
      || strategyId === "OTM_ASYMMETRY"
      || strategyId === "OTM_BREAKOUT_EXPANSION"
      || strategyId === "DEEP_OTM_SNIPER";
    const effectiveConvMult = isOTMPlay ? 1.0 : paperDeskConvictionMult(this.config, convMult);
    const condCap   = params.conditionMaxContracts ?? this.config.maxContractsPerTrade;
    const equityForCap = this.config.paperMode ? this.paperVirtualBalanceCents : (this.accountBalance ?? 0);

    // ── OTM sizing: Kelly-optimal based on payout multiple ────────────────────
    //
    // Payout multiple = (100 − entry) / entry.
    //   10¢ entry → 9× payout   (Kelly ~20% of bankroll, half-Kelly ~10%)
    //   15¢ entry → 5.7× payout (Kelly ~13%, half-Kelly ~6.5%)
    //   22¢ entry → 3.5× payout (Kelly ~7%, half-Kelly ~3.5%)
    //
    // Hard caps scale with payout to maximise expected value at the right tier:
    //   ≤12¢ (payout ≥7.3×): up to 20 contracts — highest multiplier tier
    //   ≤17¢ (payout ≥4.9×): up to 15 contracts — high multiplier tier
    //   ≤25¢ (payout ≥3.0×): up to 10 contracts — standard OTM tier
    //
    // applyHardRiskLimits() ($2.50 absolute cap, 9% equity cap) remains the safety net.
    const payoutMultiple = isOTMPlay ? (100 - entryPrice) / Math.max(1, entryPrice) : 1;
    const otmHardCap = isOTMPlay
      ? (equityForCap < 2_000                                         // < $20: tiny account guard
          ? 1
          : payoutMultiple >= 7.3                                     // ≤12¢ entry: max mult tier
              ? Math.min(20, this.config.maxContractsPerTrade * 2)
          : payoutMultiple >= 4.9                                     // ≤17¢ entry: high mult tier
              ? Math.min(15, Math.ceil(this.config.maxContractsPerTrade * 1.5))
              : Math.min(10, this.config.maxContractsPerTrade))       // ≤25¢: standard OTM
      : this.config.maxContractsPerTrade;

    let contracts: number;
    if (isOTMPlay) {
      // Real Kalshi fee: min(price, 100-price) × 7% of the ENTRY COST, not a
      // flat 7% of the gross payout — same exact net-win/net-cost functions
      // used by every other sizing branch below (kalshiNetWinCents /
      // kalshiNetCostCents) so OTM plays are judged by the identical fee
      // model, not a cruder approximation that drifts at less-extreme OTM
      // prices (Task #368 review: a flat-payout-haircut approximation
      // overstated edge near the 38¢ upper OTM_BREAKOUT_EXPANSION bound,
      // letting a boundary-case negative-fee-EV trade slip through).
      const netWinPerContract  = kalshiNetWinCents(entryPrice);
      const netCostPerContract = kalshiNetCostCents(entryPrice);
      const netPayoutRatio = Math.min(4.5, netWinPerContract / netCostPerContract);
      const otmEdge = strategyWinRate * netWinPerContract - (1 - strategyWinRate) * netCostPerContract;
      if (otmEdge <= 0) {
        const reason = `OTM sizing: fee-adjusted EV ${otmEdge.toFixed(2)}¢ <= 0 at ${entryPrice}¢ ` +
          `(WR=${(strategyWinRate * 100).toFixed(0)}%, net payout=${netPayoutRatio.toFixed(1)}x, balance=${equityForCap}¢)`;
        this.log("info", `⛔ OTM sizing gate: ${reason} — trade skipped`);
        if (params.verdict) params.verdict.blockedAfterApproval = `Sizing gate (S6): ${reason}`;
        skip("SIZING_ZERO", [reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
          proposedContracts: 0,
        });
        return;
      }
      // Half-Kelly: f* = (WR × netPayoutRatio − loseProb) / netPayoutRatio, then × 0.5
      const kellyFrac = Math.max(0,
        (strategyWinRate * netPayoutRatio - (1 - strategyWinRate)) / netPayoutRatio
      );
      const halfKellyContracts = Math.max(0,
        Math.floor((equityForCap * kellyFrac * 0.5) / Math.ceil(netCostPerContract))
      );
      const prePathMultiplierContracts = Math.max(0, Math.min(
        Math.min(this.effectiveMaxContracts(), condCap, otmHardCap),
        halfKellyContracts
      ));
      const pricePathCfg = getPathConfig(entryPrice);
      contracts = Math.floor(prePathMultiplierContracts * pricePathCfg.sizeMultiplier);
      if (contracts < 1) {
        const reason = `${pricePathCfg.path} sizing multiplier ×${pricePathCfg.sizeMultiplier} reduced ` +
          `${prePathMultiplierContracts} contracts below one`;
        this.log("info", `⛔ OTM sizing gate: ${reason} — trade skipped`);
        if (params.verdict) params.verdict.blockedAfterApproval = `Sizing gate (S6): ${reason}`;
        skip("SIZING_ZERO", [reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
          proposedContracts: 0,
        });
        return;
      }
      const potWinCents  = contracts * netWinPerContract;
      const costCentsOTM = contracts * netCostPerContract;
      this.log("info",
        `🎯 OTM Kelly: ${prePathMultiplierContracts}→${contracts}× @ ${entryPrice}¢ (×${pricePathCfg.sizeMultiplier} ${pricePathCfg.path}) · ${payoutMultiple.toFixed(1)}× gross payout (net ${netPayoutRatio.toFixed(1)}×) · ` +
        `Kelly ${(kellyFrac * 100).toFixed(1)}% · WIN=$${(potWinCents / 100).toFixed(2)} on $${(costCentsOTM / 100).toFixed(2)} risked`
      );
    } else {
      // Honest sizing: 0 base contracts means the fee-adjusted economics don't
      // justify any position — skip the trade entirely rather than forcing 1.
      if (baseContracts <= 0) {
        const reason = `Sizing gate [${sizingResult.limiter}]: ${sizingResult.detail} — strategy=${strategyId} entry=${entryPrice}¢`;
        this.log("info", `⛔ ${reason} — trade skipped`);
        if (params.verdict) params.verdict.blockedAfterApproval = `Sizing gate (S6): ${reason}`;
        skip("SIZING_ZERO", [reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
          proposedContracts: 0,
        });
        return;
      }
      // Universal price-band gate (master bot upgrade step 2) — 56-70¢ asks
      // are half-sized here, before the portfolio-risk band clamp further
      // below (which can otherwise raise a reduced size back up to its
      // minimum, undoing this reduction if applied any later in the chain).
      const priceBandMult = paperDeskSizeMult(this.config, params.priceBandSizeMult ?? 1);
      // Master bot upgrade step 3: flat 0.6× HARVEST-session multiplier,
      // combined multiplicatively with the price-band multiplier (never
      // replaces it) and landed here — before the portfolio-risk band clamp
      // further below — for the same reason as priceBandMult above.
      const harvestMult = paperDeskSizeMult(this.config, this.lastSessionMode === 'HARVEST' ? HARVEST_SIZE_MULT : 1);
      // Master bot upgrade step 4: probe/standard/press stack-quality
      // multiplier, computed by the caller (computeStackTier()) and landed
      // here alongside priceBandMult/harvestMult for the same reason —
      // before the portfolio-risk band clamp further below.
      const stackMult = paperDeskSizeMult(this.config, params.stackSizeMult ?? 1);
      const convContracts = Math.round(baseContracts * effectiveConvMult * priceBandMult * harvestMult * stackMult);
      if (priceBandMult !== 1) {
        this.log("info", `💲 Price-band sizing [${strategyId} @ ${entryPrice}¢]: ×${priceBandMult} (56-70¢ tier, no late-anchor exception)`);
      }
      if (harvestMult !== 1) {
        this.log("info", `🌾 HARVEST sizing [${strategyId} @ ${entryPrice}¢]: ×${harvestMult} (Asia/Sunday/dead-hours session)`);
      }
      if (stackMult !== 1) {
        this.log("info", `📚 Stack-tier sizing [${strategyId} @ ${entryPrice}¢]: SIZE_TIER=${params.sizeTier ?? 'unknown'} ×${stackMult}`);
      }
      // Protective size 0 must skip, not round back up to 1.
      if (convContracts < 1) {
        const reason = `Sizing gate: haircuts reduced ${baseContracts} contracts to ${convContracts} — skip (not round-up to 1)`;
        this.log("info", `⛔ ${reason}`);
        if (params.verdict) params.verdict.blockedAfterApproval = `Sizing gate (S6): ${reason}`;
        skip("SIZING_ZERO", [reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
          proposedContracts: 0,
        });
        return;
      }
      contracts = Math.min(
        Math.min(this.effectiveMaxContracts(), condCap, otmHardCap),
        convContracts
      );
      // This min() is a silent clamp — condCap in particular (the adaptive
      // condition engine's per-market-regime ceiling, e.g. 1-3× in unclear/
      // downtrend/waterfall conditions) can cut a healthy 9× portfolio-risk
      // base down to 1-3× with no trace, which made "why only 1 contract"
      // reports impossible to diagnose from logs alone (confirmed live
      // 2026-08-08: base=9 silently capped to 3 by condCap, not a bug — but
      // untraceable without this line).
      if (contracts < convContracts) {
        const limiter = this.effectiveMaxContracts() === Math.min(this.effectiveMaxContracts(), condCap, otmHardCap) ? 'effectiveMaxContracts'
                       : condCap === Math.min(this.effectiveMaxContracts(), condCap, otmHardCap) ? 'condCap(adaptive condition)'
                       : 'otmHardCap';
        this.log("info",
          `🔻 Sizing cap: ${convContracts}→${contracts}× (limiter=${limiter}: max=${this.effectiveMaxContracts()} condCap=${condCap} otmHardCap=${otmHardCap})`
        );
      }
    }

    if (!isOTMPlay && convMult > 1.0) {
      this.log("info",
        `📈 Conviction tier ${convTier} (×${convMult}): ${baseContracts}→${contracts}× ` +
        `conf=${confidence.toFixed(0)}% edge=${this.lastEdge.toFixed(1)}% ` +
        `MTF${mtfScoreNow > 0 ? '+' : ''}${mtfScoreNow}${agentAligned ? ' agent✓' : ''}`
      );
    }

    // ── Risk-profile sizing ───────────────────────────────────────────────────
    // Applied after Kelly / conviction tier, before path sizing.
    // Encodes CONSERVATIVE/BALANCED/AGGRESSIVE/RECOVERY capital rules:
    //   - globalSizeMult (0.35–1.25×)
    //   - Profile-specific daily loss circuit breaker
    //   - RECOVERY/CONSERVATIVE hard cap at 1 contract
    const mode = params.modeState;
    if (!isOTMPlay && mode) {
      const equityForProfile = this.config.paperMode
        ? this.paperVirtualBalanceCents
        : (this.accountBalance ?? 0);
      const profileResult = applyRiskProfileSizing({
        mode,
        contracts,
        balanceCents:    equityForProfile,
        entryPriceCents: entryPrice,
        todayPnlCents:   this.dayPnlForHardRiskLimits(),
      });
      if (profileResult.blocked) {
        this.log("warn",
          `🛡️ Risk profile blocked order — ${profileResult.reason}`
        );
        if (params.verdict) params.verdict.blockedAfterApproval = `Risk profile (S6): ${profileResult.reason}`;
        skip("RISK_PROFILE", [profileResult.reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
        });
        return;
      }
      if (profileResult.contracts < contracts) {
        this.log("info",
          `📊 Risk profile [${mode.riskProfile}]: ${contracts}→${profileResult.contracts}× (${profileResult.reason})`
        );
      }
      contracts = profileResult.contracts;
      // A protective size of 0 (e.g. RECOVERY's 0.35× floors a 1-2 contract
      // base to 0) must stay 0 — it is the risk profile's way of saying "sit
      // this one out" during a drawdown. Skip here, before the path-aware
      // sizing block below, whose Math.max(1, ...) calls exist to floor its
      // own ARIA/path multipliers and would otherwise silently resurrect this
      // deliberate zero back up to a live 1-contract trade.
      if (contracts < 1) {
        this.log("info",
          `🛡️ Risk profile [${mode.riskProfile}]: sized to 0× (${profileResult.reason}) — skipping trade (protective zero never rounds up)`
        );
        this.lastSignalDesc = `Risk profile [${mode.riskProfile}]: position too small to trade — standing down`;
        if (params.verdict) params.verdict.blockedAfterApproval = `Risk profile (S6): ${mode.riskProfile} sized to 0 contracts (${profileResult.reason})`;
        skip("RISK_PROFILE", [`${mode.riskProfile} sized to 0 contracts (${profileResult.reason})`], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike, proposedContracts: 0,
        });
        return;
      }
    }

    // ── Time-of-day liquidity sizing ─────────────────────────────────────────
    // Applied after the capital-risk profile and before every later sizing cap.
    // The 0.70× Asian-hours haircut applies to every trade family; a fractional
    // one-contract result is deliberately a no-trade, never rounded back up.
    let asianHoursMaxContracts: number | null = null;
    if (timeOfDayRegime === 'ASIAN_HOURS') {
      const preTimeOfDayContracts = contracts;
      contracts = applyTimeOfDaySizeMultiplier(contracts, timeOfDayRegime);
      const equityCentsAsia = this.config.paperMode
        ? this.paperVirtualBalanceCents
        : (this.accountBalance ?? this.paperVirtualBalanceCents);
      const asianFloor = applyAsianHoursMoneyMakerFloor({
        strategyId,
        preTimeOfDayContracts,
        postHaircutContracts: contracts,
        entryPriceCents: entryPrice,
        equityCents: equityCentsAsia,
      });
      contracts = asianFloor.contracts;
      // Leftover engines keep the post-haircut ceiling (often 0 skip).
      // CC/LAG: floor may reband to ≥2% equity — set thin-book ceiling to that size
      // so later liquidity cap cannot re-stub below band (ASIAN_CAP_STUB_CARVE also stays).
      const isCcLagAsia = strategyId === "CONFLUENCE_CASCADE" || strategyId === "BASIS_LAG_EDGE";
      asianHoursMaxContracts = isCcLagAsia
        ? contracts
        : (asianFloor.keptMinOne ? Math.max(contracts, 1) : contracts);
      if (asianFloor.skipped || contracts < 1) {
        const reason = `ASIAN_HOURS liquidity ×${ASIAN_HOURS_SIZE_MULT} reduced ${preTimeOfDayContracts} contracts below one`;
        this.log("info", `🌙 Time-of-day sizing: ${reason} — skipping trade (protective multiplier never rounds up)`);
        this.lastSignalDesc = "Asian-hours liquidity: position too small after 0.70× haircut — standing down";
        if (params.verdict) params.verdict.blockedAfterApproval = `Time-of-day sizing (S6): ${reason}`;
        skip("SIZING_ZERO", [reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike, proposedContracts: 0,
        });
        return;
      }
      if (isCcLagAsia && contracts > Math.max(1, Math.floor(preTimeOfDayContracts * ASIAN_HOURS_SIZE_MULT))) {
        this.log("info",
          `🌙 ASIAN_KEEP1_2PCT [${strategyId}]: haircut would under-band — rebanded to ${contracts}× (≥2% eq @ ${entryPrice}¢ / equity ${equityCentsAsia}¢)`
        );
      } else if (asianFloor.keptMinOne) {
        this.log("info", `🌙 Time-of-day sizing [ASIAN_HOURS]: ${preTimeOfDayContracts}→${contracts}× keep-1 (${strategyId} money-maker; ×${ASIAN_HOURS_SIZE_MULT} floored below one)`);
      } else if (contracts !== preTimeOfDayContracts) {
        this.log("info", `🌙 Time-of-day sizing [ASIAN_HOURS]: ${preTimeOfDayContracts}→${contracts}× (×${ASIAN_HOURS_SIZE_MULT})`);
      }
    }

    // ── Daily target engine sizing ────────────────────────────────────────────
    // Applied AFTER risk-profile sizing (engine is subordinate to the profile).
    // The engine only REDUCES size (protect mode 'reduced' → 0.3×) — it never
    // boosts. A protective multiplier must NEVER round back up to 1: for a
    // 1-contract profile 0.3× means "no trade", not "full size" (risk critic).
    if (this.lastDailyTarget && this.lastDailyTarget.sizeMult < 1.0 && this.lastDailyTarget.sizeMult > 0) {
      const preTarget = contracts;
      contracts = Math.floor(contracts * this.lastDailyTarget.sizeMult);
      if (contracts < 1) {
        this.log("info",
          `🎯 Daily target [${this.lastDailyTarget.paceState}]: ${preTarget}× × ${this.lastDailyTarget.sizeMult} < 1 contract — skipping trade (protective multiplier never rounds up)`
        );
        this.lastSignalDesc = "Protect mode: position too small to trade at 0.3× — standing down";
        if (params.verdict) params.verdict.blockedAfterApproval = `Daily target sizing (S6): sizeMult ${this.lastDailyTarget.sizeMult} floored ${preTarget}× to 0`;
        skip("DAILY_TARGET_SIZE_ZERO", [`sizeMult ${this.lastDailyTarget.sizeMult} floored ${preTarget}× to 0`], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike, proposedContracts: 0,
        });
        return;
      }
      if (contracts !== preTarget) {
        this.log("info",
          `🎯 Daily target [${this.lastDailyTarget.paceState}]: ${preTarget}→${contracts}× (×${this.lastDailyTarget.sizeMult})`
        );
      }
    }

    // ── Path-aware sizing + ARIA Kelly multiplier ─────────────────────────────
    // Applied after risk profile sizing but before hard risk caps.
    // OTM plays already have their own Kelly-optimal sizing — skip them here.
    if (!isOTMPlay && strategyId !== "PAPER_SCALP") {
      const pathCfg          = getPathConfig(entryPrice);
      // Combine the path-aware ARIA multiplier (params.ariaSizeMult, derived
      // from the agent's riskLevel via applyAriaPathRules) with the agent's
      // own raw sizeMultiplier field via min() rather than multiplying both —
      // they represent the SAME underlying risk assessment, so taking the
      // more conservative single value avoids squaring the agent's caution
      // (see note above computeContracts call).
      const ariaMult         = paperDeskSizeMult(this.config, Math.min(params.ariaSizeMult ?? 1.0, aiRisk?.sizeMultiplier ?? 1.0));
      const prePathContracts = contracts;
      // Combine the path multiplier (e.g. GRAY=0.80, MULTIPLIER=0.50) and the
      // ARIA Kelly multiplier into ONE factor applied with a single floor().
      // Flooring after each multiplication separately compounds rounding-down
      // error: e.g. a base of 3 contracts through 0.80 then 0.90 used to go
      // floor(3×0.80)=2 → floor(2×0.90)=1, silently losing more than either
      // multiplier alone intends. Multiplying first (3×0.80×0.90=2.16) and
      // flooring once correctly gives 2 (confirmed as a major contributor to
      // live trades collapsing to 1 contract almost regardless of computed
      // edge/confidence — 2026-08-08).
      const sized = applyPathAwareContracts({
        strategyId,
        prePathContracts,
        pathSizeMultiplier: pathCfg.sizeMultiplier,
        ariaMult,
        maxContracts: pathCfg.maxContracts,
      });
      contracts = sized.contracts;
      // Leftover engines: a path haircut that floors to 0 skips (never
      // Math.max back to 1). CC/LAG keep 1 if prePath was already >=1.
      if (sized.skipped) {
        const reason = `${pathCfg.path} sizing multiplier ×${pathCfg.sizeMultiplier} reduced ` +
          `${prePathContracts} contracts below one`;
        this.log("info", `⛔ Path sizing gate: ${reason} — trade skipped`);
        if (params.verdict) params.verdict.blockedAfterApproval = `Sizing gate (S6): ${reason}`;
        skip("SIZING_ZERO", [reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
          proposedContracts: 0,
        });
        return;
      }
      if (sized.keptMinOne) {
        this.log("info",
          `🛤️ Path sizing [${pathCfg.path}]: money-maker ${strategyId} kept 1 ` +
          `(prePath ${prePathContracts}≥1, ×${pathCfg.sizeMultiplier} path` +
          (ariaMult < 1 ? ` ×${ariaMult} ARIA` : '') +
          ` floored to 0; cap ${pathCfg.maxContracts})`
        );
      } else if (pathCfg.path !== 'HIGH_PROB' || ariaMult < 1) {
        this.log("info",
          `🛤️ Path sizing [${pathCfg.path}]: ${prePathContracts}→${contracts}× ` +
          `(×${pathCfg.sizeMultiplier} path` +
          (ariaMult < 1 ? ` ×${ariaMult} ARIA` : '') +
          ` cap ${pathCfg.maxContracts})`
        );
      }
    }

    // ── Strategy-performance size multiplier (online-adapter.ts) ─────────────
    // Slow, sample-gated multiplier derived from sim_verdicts hit-rate; 1.0
    // (no-op) until a strategy has ≥40 tracked samples, and clamped to a
    // narrow 0.85–1.10 band. Distinct from ariaSizeMult above (a real-time
    // risk override) — this reflects validated historical performance drift.
    {
      const perfSizeMult = paperDeskSizeMult(this.config, getStrategyMultipliersSync(strategyId).size);
      if (perfSizeMult !== 1.0) {
        const preMult = contracts;
        contracts = Math.max(0, Math.floor(contracts * perfSizeMult));
        if (contracts !== preMult) {
          this.log("info", `📈 Strategy-performance sizing [${strategyId}]: ${preMult}→${contracts}× (×${perfSizeMult})`);
        }
      }
    }

    // ── Explicit 2-5% portfolio-risk band ("no exceptions" sizing directive,
    // 2026-08-14) ─────────────────────────────────────────────────────────────
    // Direct requirement: every trade that already cleared the EV/entry gates
    // above must risk between 2% and 5% of current balance — never smaller
    // ("wasting trades on tiny position sizes") and never larger. Runs LAST
    // among the risk-SCALING multipliers (computeContracts' confidence/edge
    // tiers, conviction S/A/B, signal-stack, session haircut, ARIA,
    // strategy-performance, effectiveMaxContracts/condCap/otmHardCap above) —
    // normalizes whatever combination of those ~15 interacting knobs produced
    // into the mandated band, regardless of how they interacted (this exact
    // "nominal % target, several independent multipliers compound to well
    // under it" pattern is why a single late clamp is more reliable than
    // re-tuning each knob individually — see memory:
    // live-sizing-recalibration-2026-08-11.md). Deliberately skipped when
    // contracts is already 0/negative — a gate above decided not to trade at
    // all, and this must never force a new trade into existence, only resize
    // one already approved. Real execution constraints (order-book depth,
    // final-minutes, liquidity suspicion) are intentionally evaluated AFTER
    // this, in the existing entry-guards block below, so they can still
    // legitimately trim size for fill-quality reasons — that's a physical
    // market constraint, not caution, and is not what this directive targets.
    if (contracts > 0) {
      const equityForBand = this.config.paperMode
        ? this.paperVirtualBalanceCents
        : (this.accountBalance ?? 0);
      if (equityForBand > 0) {
        // PATH_RIDE Kelly books (CC/LAG/HA_*): premium at risk = contracts × entry¢
        // on paper virtualCents. 2–4% band. Protective GRAY/ASIAN shrink must NOT
        // pin 1 lot below 2% (Stellar 2026-09-02). Leftover engines keep 2–5% net-cost.
        const pathRideBook = isPathRideKellyBook(strategyId);
        // Paper≡live: same organ skip/size for both modes (kill paperMode-only wrap).
        // F1: frozenCc TAKE already cleared money-machine EV — organ veto is shadow only
        // (mirror ccVel frozen-shadow: log, do not skip EV_FLOOR).
        if (pathRideBook && params.frozenCc === true) {
          const organ = this.lastOrganReport;
          if (organ && organ.action === "skip" && organ.reason === "ev_below_floor") {
            this.log("info",
              `🧊 [FROZEN_CC] shadow organ ev_below_floor — would have blocked, not enforced`);
          }
          // Fall through to equity-band / leftover portfolio band (no organ re-cap).
        } else if (pathRideBook) {
          const organ = this.lastOrganReport;
          const pathSized = this.lastPathSized;
          if (organ && organ.action === "skip" && organ.reason === "ev_below_floor") {
            skip("EV_FLOOR", ["organs skip EV<3 — do not fill PATH_RIDE"], {
              ticker, side, strategyId, entryPriceCents: entryPrice,
              confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
            });
            return;
          }
          if (pathSized && pathSized.action === "skip") {
            const code = pathSized.reason === "ev_below_floor" ? "EV_FLOOR" : "SIZING_ZERO";
            skip(code, [`entryPathAndSize ${pathSized.reason} — do not fill PATH_RIDE`], {
              ticker, side, strategyId, entryPriceCents: entryPrice,
              confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
            });
            return;
          }
          // Re-cap after Kelly: entryPathAndSize with desiredContracts (9% / EV floors uncut).
          // preTradeScore high — PATH already cleared in evaluateEntry; do not re-fail score theater.
          const reSized = entryPathAndSize({
            strategyId,
            p: (typeof strategyWinRate === "number" && Number.isFinite(strategyWinRate))
              ? strategyWinRate
              : (pathSized?.p ?? 0.55),
            ask: entryPrice,
            equity: equityForBand,
            secsRemaining: secs,
            regime: String(params.detailedRegime ?? params.grokRegime ?? "transitioning"),
            velocityDolPerMin: params.velocityDolPerMin ?? this.currentVelocity ?? 0,
            threeMinVelocity: this.threeMinVelocity ?? 0,
            isStalling: false,
            distFromFloorPct: 0.2,
            preTradeScore: 99,
            historicalN: 40,
            spreadCents: params.spreadCents,
            mode: mode,
            timeOfDayRegime,
            paperMode: this.config.paperMode === true,
            desiredContracts: contracts,
            todayPnlCents: this.dayPnlForHardRiskLimits(),
            confidence,
          });
          if (reSized.action === "skip" || reSized.size < 1) {
            const code = reSized.reason === "ev_below_floor" ? "EV_FLOOR" : "SIZING_ZERO";
            skip(code, [`entryPathAndSize ${reSized.reason} — do not fill PATH_RIDE`], {
              ticker, side, strategyId, entryPriceCents: entryPrice,
              confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
            });
            return;
          }
          const ticketEV = (pathSized?.action === "take" && Number.isFinite(pathSized.ev))
            ? pathSized.ev
            : reSized.ev;
          const organSize = (pathSized?.action === "take" && pathSized.size >= 1)
            ? Math.min(pathSized.size, reSized.size)
            : (organ?.action === "take" && organ.strategyId === strategyId && organ.size >= 1)
              ? Math.min(organ.size, reSized.size)
              : reSized.size;
          if (organSize !== contracts) {
            this.log("info",
              `📐 entryPathAndSize PATH_RIDE: ${contracts}→${organSize}× (ticketEV ${ticketEV.toFixed(1)}¢ Kelly 0.60 / 9% / 9% ceiling)`,
            );
          }
          contracts = organSize;
          // F2 2–4% equity band for CC/LAG applied once below (Equity-band sizing).
        } else {
        const unitCostBand = pathRideBook
          ? Math.max(1, entryPrice)
          : Math.max(1, Math.ceil(kalshiNetCostCents(entryPrice)));
        const minPctBand = 0.02;
        const maxPctBand = pathRideBook ? 0.04 : 0.05;
        const minBandContracts = Math.max(1, Math.floor((equityForBand * minPctBand) / unitCostBand));
        const maxBandContracts = Math.max(minBandContracts, Math.floor((equityForBand * maxPctBand) / unitCostBand));
        const netCostBand = unitCostBand;

        // ── MIN-BAND vs PROTECTIVE-SHRINK FIX (2026-08-19, SEV2) ──────────────
        // uMult (estimation-uncertainty), volumeSizeMult (thin/dead order
        // book), and packSizeCapMult (specialist-pack cap) each exist
        // specifically to size a trade DOWN below what confidence/edge alone
        // would produce. Before this fix, this block's minBandContracts floor
        // applied unconditionally — so a trade one of those three had
        // deliberately shrunk below the nominal 2% band got silently
        // re-inflated right back up, erasing exactly the caution those
        // multipliers exist to express. When any of them signals an active
        // protective shrink, the floor is skipped: contracts may still be
        // trimmed DOWN by maxBandContracts (never a reason to grow a
        // position), but is never raised UP to minBandContracts.
        //
        // Deliberately checks the SIGNAL (uMult<1 / volumeSizeMult<1 /
        // packSizeCapMult<1 / volume bucket DEAD-LOW), not a threaded
        // "pre-shrink baseline" contracts count — ~10 more multipliers
        // (daily target, path sizing, ARIA, conviction tier, signal-stack,
        // strategy-performance) stack on top of computeContracts' output
        // before this block runs, so a baseline captured that early would no
        // longer describe the number actually sitting in `contracts` here.
        const volBucketForBand = params.volumeBucket;
        const protectiveShrinkActive = isProtectiveShrinkActive(
          sizingResult.uMult,
          params.volumeSizeMult,
          params.packSizeCapMult,
          volBucketForBand,
          getPathConfig(entryPrice).sizeMultiplier,
          timeOfDayRegime === 'ASIAN_HOURS' ? ASIAN_HOURS_SIZE_MULT : 1,
        );

        const preBandContracts = contracts;
        const bandProtective = pathRideBook ? false : protectiveShrinkActive;
        const bandTarget = evaluatePortfolioRiskBand(
          contracts, minBandContracts, maxBandContracts, bandProtective, this.effectiveMaxContracts()
        );

        if (bandProtective && minBandContracts > preBandContracts) {
          this.log("info",
            `📐 Portfolio-risk band: minBand floor (${minBandContracts}×) would have inflated ${preBandContracts}→${minBandContracts}× ` +
            `but BLOCKED — protective shrink active ` +
            `(uMult=${sizingResult.uMult?.toFixed(3) ?? "n/a"} volumeSizeMult=${params.volumeSizeMult?.toFixed?.(3) ?? params.volumeSizeMult ?? "n/a"} ` +
            `packSizeCapMult=${params.packSizeCapMult ?? "n/a"} volumeBucket=${volBucketForBand ?? "n/a"} ` +
            `timeOfDay=${timeOfDayRegime})`
          );
        }
        if (bandTarget !== preBandContracts) {
          this.log("info",
            `📐 Portfolio-risk band: ${preBandContracts}→${bandTarget}× (target ${(minPctBand*100).toFixed(0)}-${(maxPctBand*100).toFixed(0)}% of $${(equityForBand / 100).toFixed(2)} ` +
            `= ${minBandContracts}-${maxBandContracts}× @ ${entryPrice}¢, unit ${netCostBand}¢` +
            (bandProtective ? ", floor skipped: protective shrink active" : "") + ")"
          );
        }
        contracts = bandTarget;
        }
      }
    }

    // Equity-band sizing: CC|LAG paper 2–4% of equity (still ≤9% hard).
    if ((strategyId === "CONFLUENCE_CASCADE" || strategyId === "BASIS_LAG_EDGE") && contracts > 0) {
      const equityCents = this.config.paperMode
        ? this.paperVirtualBalanceCents
        : (this.accountBalance ?? this.paperVirtualBalanceCents);
      const banded = clampContractsToEquityBand({
        contracts,
        entryPriceCents: entryPrice,
        equityCents,
        feeCentsPerContract: 0,
        minEquityPct: 0.02,
        maxEquityPct: 0.04,
        hardCapEquityPct: 0.09,
      });
      if (banded.contracts !== contracts) {
        this.log("info", `📐 Equity-band sizing [${strategyId}]: ${contracts}→${banded.contracts}× — ${banded.detail}`);
      } else {
        this.log("info", `📐 Equity-band sizing [${strategyId}]: ${contracts}× — ${banded.detail}`);
      }
      contracts = banded.contracts;
    }

    // ── Unified path / final-minutes / depth / liquidity decision ────────────
    // All microstructure controls now return one authoritative final quantity.
    // This makes the order decision auditable and prevents threshold drift
    // between entry evaluation and order construction.
    {
      const ob = kalshiWS.getLatestOrderbook();
      const instability = kalshiWS.getOrderbookLiquidityInstability(side);
      const book = ob
        ? {
            tickerMatches: ob.ticker === ticker,
            fresh: Date.now() - ob.ts < 20_000,
            yesBidDepth: ob.yesBids.reduce((sum: number, [, qty]: [number, number]) => sum + qty, 0),
            yesAskDepth: ob.yesAsks.reduce((sum: number, [, qty]: [number, number]) => sum + qty, 0),
          }
        : undefined;

      // ── P4 LIQUIDITY POLICY (book-aware haircuts, not a signal engine) ──────
      // Runs BEFORE the generic entry-guards check below so its own SKIP
      // reason (LIQ_SPREAD/LIQ_THIN/LIQ_IMBALANCE/BOOK_STALE/BOOK_MISSING)
      // stays distinguishable from entry-guards' BOOK_SUSPICION/
      // DEPTH_IMBALANCE codes. Consume-only: reads the same `ob` L2 snapshot
      // and this order's own spreadCents/entryPrice — never creates a trade
      // thesis, never touches EV/PATH_GATE/RICH_ASK/9%/SEV1/size-0. sizeMult
      // multiplies the size spine AFTER uMult/volSizeMult (computeContracts
      // already ran above); a SKIP here aborts the order outright rather
      // than forcing contracts through at some multiplier.
      if (contracts > 0) {
        const askForBook = params.decisionAskCents ?? entryPrice;
        const bidForBook = params.spreadCents !== undefined ? askForBook - params.spreadCents : undefined;
        const liqSide: 'YES' | 'NO' = side === 'yes' ? 'YES' : 'NO';
        const quote = liqSide === 'YES'
          ? { yesAsk: askForBook, yesBid: bidForBook }
          : { noAsk: askForBook, noBid: bidForBook };
        const liqBook = buildBookSnap({ side: liqSide, currentTicker: ticker, quote, latestOrderbook: ob });
        // Strategies outside the P3 family map (OTM/candlestick/velocity-
        // stall/etc.) default to the strictest family (momentum) — fail-
        // closed, never a silent "no liquidity policy applied".
        const liqFamily = getFamilyPolicy(strategyId as StrategyId) ?? 'momentum';
        const liqVerdict = evaluateLiquidity({ family: liqFamily, book: liqBook, volScale: this.lastMarketState?.volScale });
        logLiquidityDecision({
          strategyId, family: liqFamily, side: liqSide,
          spreadCents: liqBook.spreadCents, depthAtAsk: liqBook.depthAtAsk, imbalance: liqBook.imbalance,
          bookAgeMs: liqBook.bookAgeMs, action: liqVerdict.action, sizeMult: liqVerdict.sizeMult, reason: liqVerdict.reason,
        });
        if (liqVerdict.action === 'SKIP') {
          this.log("info", `💧 Liquidity policy [${liqVerdict.reason}] blocked ${strategyId}: ${liqVerdict.detail}`);
          skip(liqVerdict.reason, [liqVerdict.detail], {
            ticker, side, strategyId, entryPriceCents: entryPrice,
            confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
          });
          return;
        }
        if (liqVerdict.action === 'HAIRCUT') {
          const preLiqContracts = contracts;
          contracts = Math.max(0, Math.floor(contracts * liqVerdict.sizeMult));
          this.log("info",
            `💧 Liquidity policy [${liqVerdict.reason}]: ${preLiqContracts}→${contracts}× ` +
            `(sizeMult=${liqVerdict.sizeMult.toFixed(2)}, ${liqVerdict.detail})`
          );
          if (contracts < 1) {
            skip("LIQ_HAIRCUT_ZERO", [`liquidity haircut reduced ${preLiqContracts}× to 0 (${liqVerdict.reason}: ${liqVerdict.detail})`], {
              ticker, side, strategyId, entryPriceCents: entryPrice,
              confidence, secsRemaining: secs, floorStrike, proposedContracts: preLiqContracts,
            });
            return;
          }
        }
        const imb = bookImbGate({ ourSize: contracts, chosenAskSize: liqBook.depthAtAsk });
        if (imb.action === "SKIP") {
          this.log("info", `📘 BOOK_IMB_GATE size=${contracts} askDepth=${liqBook.depthAtAsk} — skip lift`);
          skip("BOOK_IMB_GATE", [`ask depth ${liqBook.depthAtAsk} vs size ${contracts}`], {
            ticker, side, strategyId, entryPriceCents: entryPrice,
            confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
          });
          return;
        }
        if (imb.action === "HAIRCUT") {
          this.log("info", `📘 BOOK_IMB_GATE haircut ${contracts}→${imb.size} (askDepth=${liqBook.depthAtAsk})`);
          contracts = imb.size;
        }
      }

      const guards = evaluateEntryGuards({
        entryPriceCents: entryPrice,
        secsRemaining: secs,
        contractDurationMins: durationMins,
        proposedContracts: contracts,
        direction: side,
        book,
        liquiditySuspicionScore: instability.score,
        liquiditySuspicionReasons: instability.reasons,
      });
      if (!guards.allowed) {
        this.lastSignalDesc = `Entry guards: ${guards.reasons.join("; ")} — standing down`;
        this.log("info", `🛡️ Entry guards [${guards.path}] blocked: ${guards.reasons.join("; ")}`);
        skip("ENTRY_GUARDS", guards.reasons, {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
        });
        return;
      }
      if (guards.finalContracts !== contracts) {
        this.log("info", `🛡️ Entry guards [${guards.path}]: ${contracts}→${guards.finalContracts}× (${guards.reasons.join("; ")})`);
        contracts = guards.finalContracts;
      }
    }

    // ── Mandatory Asian-hours ceiling ────────────────────────────────────────
    // This comes after every normal sizing modifier and guard. It is separate
    // from the portfolio-band protective-shrink flag because a validated
    // strategy-performance factor may legitimately increase contracts there;
    // it may not weaken the fixed thin-book reduction.
    // GG G: PATH_RIDE CC/LAG carve through thin-book ceiling when cap would
    // shrink gold below 2% equity (floors stay). Always log stub cause.
    const liquidityCappedContracts = capContractsToLiquidityLimit(contracts, asianHoursMaxContracts);
    if (liquidityCappedContracts < contracts) {
      const isCcLag = strategyId === "CONFLUENCE_CASCADE" || strategyId === "BASIS_LAG_EDGE";
      if (isCcLag) {
        const equityCents = this.config.paperMode
          ? this.paperVirtualBalanceCents
          : (this.accountBalance ?? this.paperVirtualBalanceCents);
        const minBand = clampContractsToEquityBand({
          contracts: 1,
          entryPriceCents: entryPrice,
          equityCents,
          minEquityPct: 0.02,
          maxEquityPct: 0.04,
          hardCapEquityPct: 0.09,
        });
        if (liquidityCappedContracts < minBand.contracts) {
          this.log("warn",
            `🌙 ASIAN_CAP_STUB_CARVE [${strategyId}]: thin-book ceiling ${contracts}→${liquidityCappedContracts}× ` +
            `would stub below 2% eq (min=${minBand.contracts}) — carving PATH_RIDE through; keeping ${contracts}×`
          );
          // carve: do not apply liquidityCappedContracts
        } else {
          this.log("info",
            `🌙 Time-of-day liquidity cap [ASIAN_HOURS]: ${contracts}→${liquidityCappedContracts}× ` +
            `(retaining mandatory ×${ASIAN_HOURS_SIZE_MULT} ceiling)`
          );
          contracts = liquidityCappedContracts;
        }
      } else {
        this.log("info",
          `🌙 Time-of-day liquidity cap [ASIAN_HOURS]: ${contracts}→${liquidityCappedContracts}× ` +
          `(retaining mandatory ×${ASIAN_HOURS_SIZE_MULT} ceiling)`
        );
        contracts = liquidityCappedContracts;
      }
    }

    // PAPER_SCALP: never Kelly-up. Cap after conviction/min-band/path multipliers.
    if (strategyId === "PAPER_SCALP" && contracts > 1) {
      this.log("info", `🔒 PAPER_SCALP size cap: ${contracts}→1 (9% is a CAP not a target)`);
      contracts = 1;
    }

    // autoMode ADAPTATION: size down in DD / thin tape. Never > 1.
    // applyHardRiskLimits (9%) still binds after this haircut.
    if (this.config.autoMode && this.lastAdaptation && this.lastAdaptation.sizeMult < 1) {
      const adapted = Math.floor(contracts * this.lastAdaptation.sizeMult);
      if (adapted < contracts) {
        this.log("info",
          `📉 autoMode adapter size: ${contracts}→${adapted}× (sizeMult=${this.lastAdaptation.sizeMult.toFixed(2)})`);
        contracts = adapted;
      }
    }

    // ── Hard risk limits ─────────────────────────────────────────────────────
    // applyHardRiskLimits() is the single source of truth for position sizing
    // safety, at any account size. It checks:
    //   1. 18% daily loss circuit breaker
    //   2. 9% of equity per trade (the sole per-trade cap — no fixed-dollar
    //      or fixed-contract floor, so it scales correctly as equity grows)
    {
      const equityNow = this.config.paperMode
        ? this.paperVirtualBalanceCents
        : (this.accountBalance ?? 0);
      const safeContracts = applyHardRiskLimits(
        equityNow, entryPrice, contracts, this.dayPnlForHardRiskLimits()
      );
      if (safeContracts <= 0) {
        const reason =
          `hard risk limits sized to 0 — equity $${(equityNow / 100).toFixed(2)} ` +
          `dailyPnL ${this.dayPnlForHardRiskLimits()}¢ entry ${entryPrice}¢`;
        this.log("warn", `🛡️ Hard risk limits blocked order — ${reason}`);
        this.lastSignalDesc = reason;
        if (params.verdict) params.verdict.blockedAfterApproval = `Sizing gate (S6): ${reason}`;
        skip("SIZING_ZERO", [reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice, confidence, secsRemaining: secs, floorStrike,
          proposedContracts: 0,
        });
        return;
      }
      if (safeContracts < contracts) {
        this.log("info",
          `🔒 Hard risk cap: ${contracts}→${safeContracts} contracts ` +
          `(equity $${(equityNow / 100).toFixed(2)}, entry ${entryPrice}¢)`
        );
        contracts = safeContracts;
      }
    }

    // ── VELOCITY_STALL_REVERSAL dedicated risk budget (Task #338) ────────────
    // Layered on top of, not instead of, every gate above. This is an
    // unproven manual pattern — cap total cost to a small, separately
    // configurable budget regardless of what Kelly/tiered sizing computed.
    if (strategyId === 'VELOCITY_STALL_REVERSAL') {
      const budgetCents = this.config.velocityStallReversalRiskBudgetCents;
      const perContractCostCents = Math.ceil(kalshiNetCostCents(entryPrice));
      const maxByBudget = Math.floor(budgetCents / Math.max(1, perContractCostCents));
      if (maxByBudget <= 0) {
        this.log("warn",
          `🛡️ Velocity Stall Reversal blocked — entry ${entryPrice}¢ exceeds risk budget $${(budgetCents / 100).toFixed(2)}`
        );
        if (this.lastMoneyGateCard?.approved === true) {
          this.lastMoneyGateCard = demoteMoneyGateCardToSit(this.lastMoneyGateCard, "SIZE_ZERO");
        }
        return;
      }
      if (maxByBudget < contracts) {
        this.log("info",
          `🔒 Velocity Stall Reversal risk budget: ${contracts}→${maxByBudget} contracts (budget $${(budgetCents / 100).toFixed(2)})`
        );
        contracts = maxByBudget;
      }
    }

    // FROZEN_CC: optional fixed size. Applied after every sizing/liquidity gate
    // so a 0 from those gates still stands; this only pins a positive size.
    if (params.frozenCc === true && this.config.frozenCcFixedContracts != null && contracts > 0) {
      const fixed = Math.max(1, Math.floor(this.config.frozenCcFixedContracts));
      if (fixed !== contracts) {
        this.log("info", `🧊 [FROZEN_CC] size ${contracts}→ fixed ${fixed}`);
        contracts = fixed;
      }
    }

    const paper     = this.config.paperMode;
    // When a sufficiently large fill sample is materially worse than the
    // configured baseline, the final EV gate prices that extra execution
    // cost in — paper and live. Fill simulator still simulates fills; the
    // EV gate must see the same cost so paper is not optimistic vs live.
    // Floor is undefined when no sample exists (getObservedSessionSlippageFloorCents returns null).
    const observedSlippageCents = this.getObservedSessionSlippageFloorCents() ?? undefined;

    // ── Stop/reward admission ────────────────────────────────────────────────
    // This is deliberately inside _placeOrderBody(), the one final admission
    // point shared by 15m, hourly, and re-quote paths. It is calculated from
    // the same dynamic MTF/ARIA inputs the exit monitor uses, but then frozen
    // onto OpenTrade so later inputs may tighten, never widen, this risk.
    const isOTMExitStyle = Boolean(params.isOTMAsymmetry || params.isOTMExpansion);
    const mtfAtEntry = mtfAnalyzer.getSummary();
    const entryRiskOverrides = this.config.useExpertAgent ? expertAgent.getRiskOverrides() : null;
    const entryAgentExit = entryRiskOverrides?.exitPolicy ?? null;
    const configuredEntryStopCents = this.config.useDynamicStop
      ? (mtfAtEntry?.dynamicStopCents ?? this.config.stopLossCents)
      : this.config.stopLossCents;
    const configuredEntryProfitCents = this.config.useDynamicProfit
      ? (mtfAtEntry?.dynamicProfitCents ?? this.config.profitTakeCents)
      : this.config.profitTakeCents;
    const entryCentStopCents = Math.min(
      configuredEntryStopCents,
      entryAgentExit?.stopLossCents ?? configuredEntryStopCents,
      this.config.hardStopCents,
    );
    const entryPctStopPct = this.config.usePctStops
      ? Math.min(this.config.softStopPct, this.config.hardStopPct)
      : null;
    const entryBaseProfitCents = Math.min(
      configuredEntryProfitCents,
      entryAgentExit?.profitTakeCents ?? configuredEntryProfitCents,
    );
    const entrySlippageCents = expectedSlippageCents({
      secsRemaining: secs,
      velocityDolPerMin: velocityDolPerMin ?? 0,
      spreadCents,
      observedSlippageCents,
    });
    let entryStopRewardPlan: StopRewardPlan | null = null;
    // #725: money-maker PATH_RIDE CC|LAG — no rigid stop¢/target¢ plan attach.
    const pathRideOwnsExits = isMoneyMakerStrategyId(strategyId);

    if (!isOTMExitStyle && !pathRideOwnsExits) {
      if (!this.config.useStopLoss) {
        const reason = "normal trade has no enabled stop-loss";
        this.log("warn", `⛔ Reward/risk gate: ${reason} — order skipped`);
        if (params.verdict) params.verdict.blockedAfterApproval = `Reward/risk gate (S5): ${reason}`;
        skip("EV_FLOOR", [reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
        });
        return;
      }

      entryStopRewardPlan = computeStopRewardPlan({
        entryPriceCents: entryPrice,
        centStopCents: entryCentStopCents,
        pctStopPct: entryPctStopPct,
        targetProfitCents: computeNormalTargetProfitCents(
          entryPrice,
          entryBaseProfitCents,
          this.config.useProfitTake,
        ),
        slippageCents: entrySlippageCents,
        minRewardRiskRatio: this.config.minRewardRiskRatio,
      });
      if (!entryStopRewardPlan.passes) {
        const plan = entryStopRewardPlan;
        const reason =
          `net reward ${plan.expectedRewardCents.toFixed(1)}¢ / max loss ${plan.maxLossCents.toFixed(1)}¢ = ` +
          `${plan.rewardRiskRatio.toFixed(2)}x < ${plan.minRewardRiskRatio.toFixed(2)}x ` +
          `(stop min(${plan.centStopCents.toFixed(1)}¢, ${plan.pctStopCents?.toFixed(1) ?? "off"}¢) = ${plan.stopLossCents.toFixed(1)}¢; ` +
          `target +${plan.targetProfitCents.toFixed(1)}¢; fees + two-sided slippage included)`;
        // CONFLUENCE/LAG are settlement-EV binaries (live +$50). Cheap-to-mid
        // 49¢ with sweep+vel slip fails scalp RR < 1 while PATH_GATE EV ≥ 3
        // still passes. Thesis-hold VALID/BROKEN is the exit; do not skip.
        if (isMoneyMakerThesisHold(strategyId)) {
          this.log("info",
            `📈 Reward/risk overlay ${reason} — thesis-hold ${strategyId} admitted on PATH_GATE EV, not skipped`);
        } else {
          this.log("warn", `⛔ Reward/risk gate: ${reason} — order skipped`);
          if (params.verdict) params.verdict.blockedAfterApproval = `Reward/risk gate (S5): ${reason}`;
          skip("EV_FLOOR", [reason], {
            ticker, side, strategyId, entryPriceCents: entryPrice,
            confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
          });
          return;
        }
      }
    }

    // ── Auth failure hard guard ────────────────────────────────────────────────
    // If a previous live order attempt failed to sign, block all further live
    // orders immediately — before attempting to re-call kalshiAuthHeaders().
    if (!paper && this.authFailed) {
      this.log("warn", "⚠️ Live order blocked — unresolved auth failure. Restart bot after fixing oraclekey secret.");
      if (this.lastMoneyGateCard?.approved === true) {
        this.lastMoneyGateCard = demoteMoneyGateCardToSit(this.lastMoneyGateCard, "AUTH_FAILED");
      }
      return;
    }

    const costCents = contracts * entryPrice;

    // Drawdown guard: if factor is 0, skip entirely
    if (this.config.useDrawdownGuard && this.drawdownGuardFactor() <= 0) {
      this.log("warn", `⛔ Drawdown guard: position size reduced to 0 — skipping`);
      if (params.verdict) params.verdict.blockedAfterApproval = `Drawdown guard (S6): factor 0`;
      skip("DRAWDOWN_GUARD", ["drawdown guard factor 0"], {
        ticker, side, strategyId, entryPriceCents: entryPrice,
        confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
      });
      return;
    }

    // ── EV gate ───────────────────────────────────────────────────────────────
    // For standard high-probability strategies: fee-adjusted EV ≥ 3¢ floor.
    // For OTM plays: stricter two-part check —
    //   1. Market-implied probability must be BELOW our estimated win rate by a
    //      minimum margin (we need real edge, not just "it might hit").
    //   2. Absolute EV ≥ 5¢ per contract (higher floor than standard 3¢ because
    //      OTM losses are frequent and compound fast on a small account).
    {
      if (isOTMPlay) {
        // OTM-specific EV gate
        // Market-implied win prob: entryPrice / 100 (for YES) or (100-entryPrice)/100 (for NO)
        // We can't know side here but entryPrice is always the cost of the position we're buying.
        const otmGate = evaluateEntryEVGate({
          entryPriceCents: entryPrice,
          strategyWinRate,
          strategyId,
          isOTMAsymmetry: params.isOTMAsymmetry,
          isOTMExpansion: params.isOTMExpansion,
          secsRemaining: secs,
          velocityDolPerMin,
          spreadCents,
          observedSlippageCents,
        });
        const marketImpliedProb = otmGate.marketImpliedProb!;
        const modelEstimatedProb = otmGate.modelEstimatedProb;

        // Gate 1: We must have a minimum edge over the market price.
        // If the market is pricing the contract at 28¢ but our strategy only wins 28% of the time,
        // there is no edge — skip it even if it "looks good" on the chart.
        if (otmGate.code === "OTM_EV_NO_EDGE") {
          this.log("warn",
            `⛔ OTM EV gate: no edge — model prob ${(modelEstimatedProb * 100).toFixed(0)}% ≤ ` +
            `market implied ${(marketImpliedProb * 100).toFixed(0)}% + ${(MIN_EDGE_OVER_MARKET * 100).toFixed(0)}% margin ` +
            `(entry ${entryPrice}¢) — skip`
          );
          skip("OTM_EV_NO_EDGE", [`model ${(modelEstimatedProb * 100).toFixed(0)}% vs market ${(marketImpliedProb * 100).toFixed(0)}%`], {
            ticker, side, strategyId, entryPriceCents: entryPrice,
            confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
          });
          return;
        }

        // Gate 2: Absolute EV must clear the stricter of the OTM floor and
        // the entry-price path floor after fees + slippage.
        // Routed through the same computeTradeEV() PATH_GATE uses — real
        // Kalshi taker fee (min(entry,100-entry)×7%) plus dynamic slippage
        // (final-3-minutes / high-velocity / wide-spread widening) instead of
        // a flat 1.5¢ baseline. No strategyId is passed, so no strategy-family
        // EV discount applies here — same as PATH_GATE's own call.
        const otmEVResult = otmGate.evResult!;
        const otmEV = otmEVResult.netEV;
        const otmEVFloor = Math.max(OTM_EV_FLOOR, getPathConfig(entryPrice).minEVCents);
        if (!otmGate.passes || otmEV < otmEVFloor) {
          this.log("warn",
            `⛔ OTM EV gate: EV ${otmEV.toFixed(1)}¢ < ${otmEVFloor}¢ floor at ${entryPrice}¢ entry ` +
            `(winRate=${(modelEstimatedProb * 100).toFixed(0)}% fee=${otmEVResult.feeCents.toFixed(1)}¢ slip=${otmEVResult.slippageCents.toFixed(1)}¢) — skip`
          );
          skip("OTM_EV_FLOOR", [`EV ${otmEV.toFixed(1)}¢ < ${otmEVFloor}¢`], {
            ticker, side, strategyId, entryPriceCents: entryPrice,
            confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
          });
          return;
        }

        this.log("info",
          `✅ OTM EV gate passed: EV ${otmEV.toFixed(1)}¢ · model ${(modelEstimatedProb * 100).toFixed(0)}% ` +
          `vs market ${(marketImpliedProb * 100).toFixed(0)}% · edge +${((modelEstimatedProb - marketImpliedProb) * 100).toFixed(0)}pp`
        );
      } else {
        // Standard strategies: fee-adjusted EV ≥ 3¢ floor.
        //
        // PATH_GATE and this final gate MUST share the same p = strategyWinRate
        // (winRateAtPrice / expectedWinRate). A massAboveFloor / N(d2)
        // "settlement-hold WR swap" up to 0.97 must never inflate p to pass a
        // rich ask that PATH_GATE would have rejected on the strategy curve.
        const evGate = evaluateEntryEVGate({
          entryPriceCents: entryPrice,
          strategyWinRate,
          strategyId,
          secsRemaining: secs,
          velocityDolPerMin,
          spreadCents,
          observedSlippageCents,
          contracts, // D13 — exact fee on the real order size; 3¢ floor unchanged
        });
        const evResult = evGate.evResult!;
        const feeAdjEV = evGate.netEV!;
        if (!evGate.passes) {
          this.log("warn",
            `⛔ Fee-adj EV ${feeAdjEV.toFixed(1)}¢ < ${EV_FLOOR}¢ floor at ${entryPrice}¢ entry ` +
            `(strategyWinRate=${(strategyWinRate * 100).toFixed(0)}% ` +
            `fee=${evResult.feeCents.toFixed(1)}¢ slip=${evResult.slippageCents.toFixed(1)}¢) — skip`
          );
          skip("EV_FLOOR", [`fee-adj EV ${feeAdjEV.toFixed(1)}¢ < ${EV_FLOOR}¢`], {
            ticker, side, strategyId, entryPriceCents: entryPrice,
            confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
          });
          return;
        }
      }
    }

    // Final safety gate: never place when WS is degraded (paper proves live —
    // paper fills on a dead book would poison evidence). Catches the case
    // where degraded state changed between evaluateEntry and placeOrder.
    if (this.wsDegraded) {
      this.log("warn", "⛔ WS degraded — blocking order (state changed before placement)");
      if (this.lastMoneyGateCard?.approved === true) {
        this.lastMoneyGateCard = demoteMoneyGateCardToSit(this.lastMoneyGateCard, "NO_TAPE");
      }
      return;
    }

    // ── Order-book depth cap ─────────────────────────────────────────────────
    // Last sizing control before the durable intent: every Kelly/risk/
    // profile/strategy cap has already run. Live REST snapshot is a hard
    // admission dependency (missing → DEPTH_UNAVAILABLE). Paper uses the
    // in-memory WS L2 snapshot (kalshiWS.getLatestOrderbook) as the same
    // shrink source; missing depth is DEPTH_UNAVAILABLE in BOTH modes so
    // paper cannot fill a book live would refuse. A successful empty/
    // non-executable book is capped to zero in both modes.
    {
      const depthResult = paper
        ? depthFromInMemoryOrderbook(kalshiWS.getLatestOrderbook(), ticker, side, entryPrice)
        : await fetchOrderbookDepthAtEntry(ticker, side, entryPrice);
      if (!depthResult.available) {
        this.log("warn", `[depth] ${depthResult.warning}; blocking ${paper ? "paper" : "live"} order`);
        if (params.verdict) {
          params.verdict.blockedAfterApproval = "Order-book depth snapshot unavailable";
        }
        skip("DEPTH_UNAVAILABLE", [depthResult.warning], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike, proposedContracts: 0,
        });
        return;
      } else {
        const depthSizing = resolveDepthAwareSizing(
          contracts,
          depthResult,
          this.config.maxDepthFraction,
        );
        const preDepthContracts = contracts;
        const visibleDepth = depthSizing.visibleDepth!;
        contracts = depthSizing.contracts;
        if (contracts < preDepthContracts) {
          this.log("info",
            `depth cap: sized down ${preDepthContracts}→${contracts} ` +
            `(${visibleDepth} contracts visible at price)`
          );
          if (contracts < 1) {
            this.log("warn",
              `[depth] visible depth is too small for the configured ` +
              `${this.config.maxDepthFraction * 100}% cap; skipping order`
            );
            if (params.verdict) {
              params.verdict.blockedAfterApproval = "Order-book depth cap reduced size below one contract";
            }
            skip("DEPTH_SIZE_ZERO", [
              `${visibleDepth} visible contracts × ${this.config.maxDepthFraction} depth fraction`,
            ], {
              ticker, side, strategyId, entryPriceCents: entryPrice,
              confidence, secsRemaining: secs, floorStrike, proposedContracts: 0,
            });
            return;
          }
        }
      }
    }

    // ── Durable intent: write to DB BEFORE calling Kalshi ────────────────────
    // If the process crashes between the API call and the DB write, the trade
    // would exist on Kalshi but not in our database — an unrecoverable phantom
    // position. Writing the intent first (with outcome="pending") ensures we
    // always have a DB record. On API failure we delete or mark it "failed".
    // On success we update the orderId field in-place.
    //
    // Paper trades use a synthetic orderId. Fill/slip/fee is persisted
    // immediately after the simulated fill (awaited — Task #442) so paper
    // history has the same durable intent as live rather than a silent miss.
    let dbId: number | null = null;
    const intentOrderId = paper ? `paper-${Date.now()}` : `intent-${Date.now()}`;

    // Plain-English "why I entered" + whole-position EV estimate at entry —
    // display/logging only, computed from the same EV math PATH_GATE uses but
    // never fed back into gating/sizing itself.
    const entryReason = buildEntryReason({
      strategyId, signal, confidence, entryPriceCents: entryPrice,
      winRate: strategyWinRate, regime: params.grokRegime, velocityDolPerMin,
      sessionMode: this.lastSessionMode,
      exitPlan: entryStopRewardPlan && {
        stopLossCents: entryStopRewardPlan.stopLossCents,
        targetProfitCents: entryStopRewardPlan.targetProfitCents,
        rewardRiskRatio: entryStopRewardPlan.rewardRiskRatio,
      },
    });
    const expectedPnlCents = Math.round(
      computeTradeEV({
        entryPriceCents: entryPrice, winRate: strategyWinRate,
        strategyId: strategyId ?? undefined, secsRemaining: secs,
        velocityDolPerMin, spreadCents, observedSlippageCents,
        // Sweep K3 / item 10: same inputs as the final EV gate, incl. the D13
        // full-order fee (was the C=1 per-contract fee: #74 stored 162 vs gate).
        contracts,
      }).netEV * contracts
    );

    try {
      const [row] = await db.insert(botTrades).values({
        ticker, side, contracts, entryPriceCents: entryPrice,
        floorStrike, secsRemaining: secs, signal, confidence,
        strategyId: strategyId ?? null,
        // Persist the contract duration so per-duration performance/quarantine
        // (strategy-performance.ts) can group by it. NULL was the old implicit
        // 15m; we now write it explicitly.
        contractDurationMins: durationMins,
        // Regime at entry — feeds the empirical strategyId×regime EV stats in
        // regime-ev-stats.ts. See resolveTradeRegimeForPersistence's doc
        // comment for why this must be the fine-grained detailedRegime, not
        // the coarse grokRegime.
        regime: resolveTradeRegimeForPersistence(params.detailedRegime, params.grokRegime),
        velocityPerMin: Math.round(this.currentVelocity),
        orderId: intentOrderId,
        outcome: "pending",
        // Durable paper/live flag (logging only) — previously only inferable
        // from the order_id "paper-" string prefix, which is fragile.
        isPaper: paper,
        fillOrigin: FILL_ORIGIN_BOT,
        // The actual win-rate estimate used by computeTradeEV/sizing for this
        // trade, distinct from the 0-100 `confidence` score.
        winRate: strategyWinRate,
        entryReason,
        expectedPnlCents,
        // Display-only balance snapshot — the same equity value already used
        // for sizing this trade (equityForCap), captured before the order
        // is placed so the log can show "balance before → balance after".
        balanceBeforeCents: Math.round(equityForCap),
        // Stack-tier label (Phase 2, 2026-08-15) — already computed at the
        // 15m-path call site and threaded through placeOrder's params, but
        // previously dropped before the DB write despite a comment claiming
        // it was "recorded for logging/analysis only". Logging only; not
        // read back to affect sizing/gates. Absent (undefined) on the 1H/OTM
        // paths, which don't compute a stack tier — NULL there is correct,
        // not a bug.
        sizeTier: params.sizeTier ?? null,
        // GO — VOLUME AS RISK SCALAR (2026-08-18): the bucket/score this trade
        // was actually sized/gated under, so the post-settlement learner
        // (recordVolumeBucketSettlement) can attribute the outcome back to
        // the right (strategyId × bucket) cell. Logging/learning input only.
        volumeBucket: params.volumeBucket ?? null,
        volumeScoreV: params.volumeScoreV ?? null,
        traceId: orderTraceId,
      }).returning({ id: botTrades.id });
      dbId = row?.id ?? null;
    } catch (e) {
      this.log("warn", `DB intent write failed — aborting order: ${(e as Error).message}`);
      return; // never send a live order without a DB record to match it
    }
    try {
      {
        const spot = this.prices.at(-1)?.price ?? floorStrike ?? 0;
        const tape = stampFromLive({
          side,
          lag: this.lastBasisState,
          htf: computeLiveHtfStructure(spot),
          mtfScore: mtfAnalyzer.getSummary()?.score ?? null,
          streakSaturation: this.lastObservation?.streakSaturation ?? null,
          settlementStreak: this.lastObservation?.settlementStreak ?? null,
        });
        rememberPuzzleTake({
          ticker,
          side: side === "no" ? "NO" : "YES",
          strategyId: strategyId ?? null,
          askCents: entryPrice,
          secsRemaining: secs,
          ts: Date.now(),
          lastSignal: this.lastSignalDesc,
          floor: floorStrike ?? null,
          regime: params.grokRegime ?? null,
          lagClass: tape.lagClass, lagSeconds: tape.lagSeconds, lagDollars: tape.lagDollars,
          htfStructure: tape.htf,
          streakSaturation: tape.streakSaturation,
        });
      }
    } catch {
      // Puzzle memory must never abort placeOrder.
    }

    let orderId: string | null = intentOrderId;

    if (!paper) {
      if (!leftoverLiveOrderMayRun(this.config)) {
        this.log("warn", "leftover live order POST skipped (paper/frozen desk)");
        if (dbId) deleteTradeIntent(dbId).catch(() => {});
        return;
      }
      const placed = await leftoverLiveOrderRun(this.config, () =>
        leftoverLivePlaceFunnel.call(this, {
          ticker,
          side,
          contracts,
          entryPrice,
          dbId,
          strategyId,
          kalshiAuthHeaders,
          getKalshiRejectionDetail,
          kalshiSameSidePosition,
          isAuthSigningFailed,
          deleteTradeIntent,
        }),
      );
      if (!placed || !placed.ok || !placed.orderId) {
        return;
      }
      orderId = placed.orderId;
    } else {
      // Task #441 — Realistic Paper Fills: paper used to simulate every fill
      // at the exact quoted price with slippageCents hardcoded to 0, making
      // paper P&L a slippage-free upper bound live can never actually reach
      // (live pays real adverse slippage on top of the same fee). Simulate a
      // realistic adverse fill here instead, sourced from this strategy's own
      // recent live slippage (falls back to the cross-strategy live average,
      // then a static estimate — see estimatePaperSlippageCents doc comment).
      // A taker's slippage is always adverse (worse than the quoted price),
      // never a windfall, so this always makes the paper fill strictly
      // more expensive/less favorable than the naive `entryPrice`.
      const makerPaper = paper && params.makerEntry === true && isMoneyMakerStrategyId(strategyId);
      const paperSlippageCents = makerPaper ? 0 : Math.round(await estimatePaperSlippageCents(strategyId ?? null));
      const paperFillPriceCents = makerPaper
        ? entryPrice
        : Math.min(99, entryPrice + paperSlippageCents);
      // P0-1: still-mid on EXECUTABLE fill (ask+sweep+slip) BEFORE debit/setOpenTrade.
      // Live #12: yesAskAtEntry=46 entry=48 — decision quote cleared, slip landed coin-flip.
      if (
        !params.isOTMAsymmetry
        && !params.isOTMExpansion
        && (
          inStillMidCoinFlip(paperFillPriceCents)
          || sweptFillHitsStillMid(entryPrice, paperSlippageCents)
        )
      ) {
        this.log("warn",
          `📄 PAPER: fill ${paperFillPriceCents}¢ still-mid 48–52 ` +
          `(entry ${entryPrice}¢ + slip ${paperSlippageCents}¢) — abort before debit`);
        this.lastSignalDesc =
          `still-mid fill ${paperFillPriceCents}¢ (entry ${entryPrice}¢ + slip ${paperSlippageCents}¢) — skip`;
        if (dbId) deleteTradeIntent(dbId).catch(() => {});
        return;
      }
      // PR #14 — re-check EV ≥ 3¢ and the 20–55¢ CC band at the FILL price
      // (quote + slip) before debit. Quote can pass while the slipped fill
      // fails (#72 pattern) → skip FILL_PRICE_EV_FAIL / FILL_PRICE_BAND_FAIL.
      if (
        !params.isOTMAsymmetry
        && !params.isOTMExpansion
        && (params.frozenCc === true || isMoneyMakerStrategyId(strategyId))
      ) {
        const fillCheck = checkPaperFillPrice({
          p: strategyWinRate,
          quoteCents: entryPrice,
          fillPriceCents: paperFillPriceCents,
          contracts,
          maker: makerPaper,
          checkBand: params.frozenCc === true || strategyId === "CONFLUENCE_CASCADE",
        });
        if (!fillCheck.ok) {
          this.log("warn", `📄 PAPER: ${fillCheck.code} — ${fillCheck.reason} — abort before debit`);
          this.lastSignalDesc = `${fillCheck.code}: ${fillCheck.reason}`;
          if (params.verdict) params.verdict.blockedAfterApproval = this.lastSignalDesc;
          skip(fillCheck.code, [fillCheck.reason], {
            ticker, side, strategyId, entryPriceCents: paperFillPriceCents,
            confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
          });
          if (dbId) deleteTradeIntent(dbId).catch(() => {});
          return;
        }
      }
      const paperCostCents = makerPaper
        ? contracts * paperFillPriceCents + kalshiMakerFeeCents(paperFillPriceCents, contracts)
        : paperFillCostCents(contracts, paperFillPriceCents);

      if (this.paperVirtualBalanceCents < paperCostCents) {
        this.log("warn", `📄 PAPER: Insufficient virtual balance — skipping`);
        if (dbId) deleteTradeIntent(dbId).catch(() => {});
        return;
      }
      this.paperVirtualBalanceCents -= paperCostCents;
      this.persistPaperLedger();
      appendPaperTrade({
        ts: Date.now(), ticker, side, contracts,
        ...(typeof dbId === "number" && dbId > 0 ? { tradeId: dbId } : {}), // GE_013 durable id (never fabricated)
        entryPriceCents: paperFillPriceCents,
        strategyId: strategyId ?? null,
        isPaper: true,
        fillOrigin: FILL_ORIGIN_BOT,
        outcome: "pending",
        ...tagPathRideFill(strategyId ?? null),
        ...(params.mindAdvisory
          ? { advisoryVetoes: params.mindAdvisory.advisoryVetoes, mindHeave: params.mindAdvisory.mindHeave }
          : {}),
      });
      // Paper trades never go through the live order-status poll (there's no
      // real exchange round-trip), so fillPriceCents/slippageCents/filledAt
      // were previously left permanently null for every paper trade. Write
      // them explicitly here — entryPriceCents itself is updated to the
      // simulated fill price (not just fillPriceCents/slippageCents
      // metadata) because _detectSettlementBody()'s paper settlement path
      // computes P&L off trade.entryPriceCents; a display-only slippage
      // column with no cost impact would not satisfy the task ("paper P&L
      // ... reflects these costs, not an upper bound").
      if (dbId) {
        const paperFeeCents = makerPaper
          ? kalshiMakerFeeCents(paperFillPriceCents, contracts)
          : kalshiTakerFeeCents(paperFillPriceCents, contracts);
        // Task #442: paper has no live order-status poll to recover a missed
        // fill write. Await the persist (same durable intent as the live
        // intent insert above) and log a hard failure instead of swallowing.
        try {
          await db.update(botTrades).set({
            orderPlacedAt: new Date(), entryPriceCents: paperFillPriceCents,
            fillPriceCents: paperFillPriceCents, slippageCents: paperSlippageCents,
            filledAt: new Date(), feeCents: paperFeeCents, contractsFilled: contracts,
          }).where(eq(botTrades.id, dbId));
        } catch (e: unknown) {
          this.log("error",
            `DB persist FAILED for paper fill ${dbId} — paper history may be missing fill/slip/fee: ${e instanceof Error ? e.message : String(e)}`
          );
        }
      }
      // Keep the in-memory entryPrice used below (setOpenTrade, logs) in
      // sync with what was actually persisted/charged.
      entryPrice = paperFillPriceCents;
    }

    // Paper fills can be worse than the decision quote. Recompute the
    // display/snapshot plan at the simulated fill so its entry audit trail is
    // honest. Live orders keep the admission plan, because their true fill is
    // not available until after the exchange has accepted the order.
    if (entryStopRewardPlan) {
      entryStopRewardPlan = computeStopRewardPlan({
        entryPriceCents: entryPrice,
        centStopCents: entryCentStopCents,
        pctStopPct: entryPctStopPct,
        targetProfitCents: computeNormalTargetProfitCents(
          entryPrice,
          entryBaseProfitCents,
          this.config.useProfitTake,
        ),
        // entryPrice is the simulated fill (not the decision quote), so its
        // actual adverse entry cost is already represented in the price. Only
        // retain modeled adverse slippage for the eventual exit.
        entrySlippageCents: paper ? 0 : entrySlippageCents,
        exitSlippageCents: entrySlippageCents,
        minRewardRiskRatio: this.config.minRewardRiskRatio,
      });
      if (paper && !entryStopRewardPlan.passes && !isMoneyMakerThesisHold(strategyId)) {
        // A simulated fill can cross the minimum after the decision quote.
        // Roll it back completely — balance and durable intent — rather than
        // opening a paper trade the real entry gate would have rejected.
        // Money-maker thesis-hold (CONFLUENCE/LAG) is admitted on PATH_GATE EV.
        const refundedCostCents = paperFillCostCents(contracts, entryPrice);
        this.paperVirtualBalanceCents += refundedCostCents;
        this.persistPaperLedger();
        if (dbId) await deleteTradeIntent(dbId).catch(() => {});
        const plan = entryStopRewardPlan;
        const reason =
          `paper fill made net reward ${plan.expectedRewardCents.toFixed(1)}¢ / max loss ` +
          `${plan.maxLossCents.toFixed(1)}¢ = ${plan.rewardRiskRatio.toFixed(2)}x < ` +
          `${plan.minRewardRiskRatio.toFixed(2)}x`;
        this.log("warn", `⛔ Reward/risk gate: ${reason} — paper order rolled back`);
        if (params.verdict) params.verdict.blockedAfterApproval = `Reward/risk gate (S5): ${reason}`;
        skip("EV_FLOOR", [reason], {
          ticker, side, strategyId, entryPriceCents: entryPrice,
          confidence, secsRemaining: secs, floorStrike, proposedContracts: contracts,
        });
        return;
      }
    }

    this.setOpenTrade({
      ticker, side, contracts, entryPriceCents: entryPrice,
      floorStrike, signal, confidence, velocity: this.currentVelocity,
      openedAt: Date.now(), dbId, orderId, periodKey: getPeriodKey(),
      paper, fillOrigin: FILL_ORIGIN_BOT, addedContracts: false, maxGainCents: 0,
      advisoryVetoes: params.mindAdvisory ? params.mindAdvisory.advisoryVetoes : null,
      mindHeave: params.mindAdvisory ? params.mindAdvisory.mindHeave : null,
      strategyId: strategyId ?? 'unknown',
      // Any long-shot/OTM-style play — OTM_ASYMMETRY, DEEP_OTM_SNIPER (via
      // isOTMAsymmetry) AND OTM_BREAKOUT_EXPANSION (via isOTMExpansion) —
      // must get the same "high-value" exit treatment (percentage/multiplier
      // targets, no fixed-¢ stop) throughout monitorOpenTrade(). Before this
      // fix, isOTMExpansion only affected entry sizing; every downstream exit
      // gate keys off isOTMAsymmetry alone, so OTM_BREAKOUT_EXPANSION trades
      // were silently getting normal-strategy exit rules (e.g. a fixed -22¢
      // stop) applied to entries as cheap as 11¢ — mathematically nonsensical
      // and inconsistent with its own entry-price band (Task #368 review).
      isOTMAsymmetry: (params.isOTMAsymmetry ?? false) || (params.isOTMExpansion ?? false),
      preferEarlyExit: this.lastStreakSatDecision?.preferEarlyExit === true || this.lastStreakSatDecision?.takeFade === true,
      // #725 PATH_RIDE CC|LAG: do not attach rigid −8/+47¢ stop/target plans.
      // PATH_RIDE owns exits (decidePathRideExit). HARD_STOP / 9% / EV floors untouched.
      entryStopCents: isMoneyMakerStrategyId(strategyId) ? undefined : entryStopRewardPlan?.stopLossCents,
      entryTargetProfitCents: isMoneyMakerStrategyId(strategyId) ? undefined : entryStopRewardPlan?.targetProfitCents,
      entryMaxLossCents: isMoneyMakerStrategyId(strategyId) ? undefined : entryStopRewardPlan?.maxLossCents,
      entryExpectedRewardCents: isMoneyMakerStrategyId(strategyId) ? undefined : entryStopRewardPlan?.expectedRewardCents,
      entryRewardRiskRatio: isMoneyMakerStrategyId(strategyId) ? undefined : entryStopRewardPlan?.rewardRiskRatio,
      entryBandMin: params.entryBandMin ?? this.config.minEntryPrice,
      entryBandMax: params.entryBandMax ?? this.config.maxEntryPrice,
      contractDurationMins: durationMins,
      closeTimeMs: params.closeTimeMs
        ?? resolve15mCloseTimeMs(params.ticker, params.secs, Date.now()),
      regimeAtEntry: params.grokRegime ?? null,
      strategyWinRateAtEntry: typeof params.strategyWinRate === "number" ? params.strategyWinRate : null,
      // Same snapshot persisted to balanceBeforeCents above — kept in memory
      // for external-close balance-delta inference.
      balanceBeforeCents: Math.round(equityForCap),
      // Task #351: immutable entry-time MTF/ARIA snapshot (see OpenTrade doc comment).
      mtfScoreAtEntry: mtfAnalyzer.getSummary()?.score ?? null,
      mtfBiasAtEntry: mtfAnalyzer.getSummary()?.bias ?? null,
      ariaSignalAtEntry: expertAgent.lastAssessment?.signal ?? null,
      ariaConfAdjAtEntry: expertAgent.lastAssessment?.confAdj ?? null,
      // GO — VOLUME AS RISK SCALAR (2026-08-18): carried in-memory so the
      // settlement-time learner can attribute the outcome without a DB read.
      volumeBucket: params.volumeBucket ?? null,
      chartPoints: [],
      // STORY_STAMP entry snapshot — close writers stamp fee-net fields fail-closed.
      yesAskAtEntry: typeof this.lastObservation?.yesAsk === "number" ? this.lastObservation.yesAsk : null,
      noAskAtEntry: typeof this.lastObservation?.noAsk === "number" ? this.lastObservation.noAsk : null,
      sessionModeAtEntry: this.lastSessionMode ?? null,
      pFilledSideAtEntry: typeof params.strategyWinRate === "number" ? params.strategyWinRate : null,
      lockSideAtEntry: this.lastW2Log
        ? {
            mtf: (this.lastW2Log.mtf_side === "yes" || this.lastW2Log.mtf_side === "no")
              ? this.lastW2Log.mtf_side : null,
            ha: (this.lastW2Log.ha_side === "yes" || this.lastW2Log.ha_side === "no")
              ? this.lastW2Log.ha_side : null,
            analog: (this.lastW2Log.analog_side === "yes" || this.lastW2Log.analog_side === "no")
              ? this.lastW2Log.analog_side : null,
            lagProven: this.lastW2Log.lag_proven === true,
            result: this.lastW2Log.lock_result ?? null,
            htfRange: this.lastW2Log.lockSide?.htfRange ?? null,
            ltfRange: this.lastW2Log.lockSide?.ltfRange ?? null,
            sr: this.lastW2Log.lockSide
              ? { atS: this.lastW2Log.lockSide.sr.atS, atR: this.lastW2Log.lockSide.sr.atR }
              : null,
            channel: this.lastW2Log.lockSide
              ? {
                  intact: this.lastW2Log.lockSide.channel.intact,
                  broken: this.lastW2Log.lockSide.channel.broken,
                  slopeUp: this.lastW2Log.lockSide.channel.slopeUp,
                }
              : null,
            volState: this.lastW2Log.lockSide?.volState ?? null,
            deltaSign: this.lastW2Log.lockSide?.deltaSign ?? null,
            pattern: this.lastW2Log.lockSide?.pattern ?? null,
            pin: this.lastW2Log.lockSide
              ? {
                  gap: this.lastW2Log.lockSide.pin.gap,
                  reach: this.lastW2Log.lockSide.pin.reach,
                  state: this.lastW2Log.lockSide.pin.state,
                }
              : null,
            brtiSign: this.lastW2Log.lockSide?.brtiSign ?? null,
            why: this.lastW2Log.lockSide_why ?? this.lastW2Log.lockSide?.why ?? null,
          }
        : null,
    });

    if (params.frozenCc === true && this.openTrade) {
      // FROZEN_CC measurement: stamp the fill and write the append-only FILL row.
      const pending = this.pendingFrozenFill;
      this.openTrade.frozenCc = true;
      // Every FROZEN/CC fill is PATH_RIDE book (leftoverTbNoOp belt).
      this.openTrade.pathRide = true;
      this.openTrade.exitBook = PATH_RIDE_EXIT_BOOK;
      this.openTrade.frozenShadow = pending?.shadow ?? emptyShadowFlags();
      this.openTrade.frozenEntryP = pending?.p ?? null;
      this.openTrade.frozenEntryEvCents = pending?.ev ?? null;
      // P1-A: persist entry EV on close stamps (was null 168/174 for money-makers).
      if (
        typeof pending?.ev === "number"
        && Number.isFinite(pending.ev)
        && this.openTrade.entryExpectedRewardCents == null
      ) {
        this.openTrade.entryExpectedRewardCents = pending.ev;
      }
      // Scar-Echo Learning: bind mind state at paper fill (never blocks fill).
      try {
        if (paper === true) {
          const shadow = this.openTrade.frozenShadow;
          const conflicts: string[] = [];
          if (shadow?.ccVelocityWouldBlock) conflicts.push("CC_VEL_AGAINST_SOLE_TAKE");
          if (shadow?.regimeWouldBlock === true) conflicts.push("REGIME_WOULD_BLOCK_SOLE_TAKE");
          const mind = this.lastBrainCenter;
          const decisionKindFill = side === "no" ? "TAKE_NO" : "TAKE_YES";
          const bindBase: ScarEntryBind = {
            conflicts: conflicts.length
              ? conflicts
              : (mind?.conflicts?.map((c) => c.code) ?? []),
            councilResolved: mind?.council?.resolved ?? null,
            horizonPhase: mind?.horizon?.phase ?? null,
            diagnosis: mind?.goldenEggThought?.diagnosis ?? null,
            decisionKind: decisionKindFill,
            frozenCc: true,
            strategyId: strategyId ?? null,
            side: side === "no" ? "no" : "yes",
            askBand: askBandFromCents(entryPrice),
            askCents: entryPrice,
          };
          const honesty = stampScarFillHonesty(bindBase);
          const bind: ScarEntryBind = { ...bindBase, ...honesty };
          const scar = recordScar(bind);
          this.openTrade.scarId = scar.id;
          persistScar(scar);
        }
      } catch { /* never block fill on SEL */ }
      this.openTrade.frozenShadowExitWouldSell = null;
      this.openTrade.frozenShadowExitFirstAtMs = null;
      // Sit-WATCH: BSM theo from fresh 5Hz BRTI only; null if missing/out-of-band
      // (never invent book-inferred BTC into theo; reject <10¢ or >90¢ — not 1¢).
      let entryTheoCents: number | null = null;
      let entryTheoMissing = true;
      try {
        // Observe-only stamp: allow 5s BRTI age (gate freshness stays tighter elsewhere).
        const brtiUsd = kalshiWS.getFreshBrtiUsd(5_000);
        const vol = realizedVolFromBuffer(this.prices);
        const minsLeftTheo = secs / 60;
        const stamped = stampEntryTheoFromBrti({
          brtiUsd,
          floorStrike,
          vol,
          minsLeft: minsLeftTheo,
          side,
        });
        // Belt: force sanitize even if stamp path is bypassed/regressed.
        const belt = sanitizeTheoCents(stamped.entryTheoCents);
        entryTheoCents = belt.theoCents;
        entryTheoMissing = belt.theoMissing || stamped.entryTheoMissing;
        if (entryTheoMissing) {
          this.log("info",
            `[entryTheo] FILL miss ticker=${ticker} reason=${stamped.reason} raw=${stamped.rawTheoCents} brti=${brtiUsd ?? "null"} vol=${Number.isFinite(vol) ? vol.toFixed(4) : "?"}`,
          );
        }
      } catch (err) {
        entryTheoCents = null;
        entryTheoMissing = true;
        this.log("info", `[entryTheo] FILL miss ticker=${ticker} reason=throw ${(err as Error)?.message ?? err}`);
      }
      this.openTrade.frozenEntryTheoCents = entryTheoCents;
      this.openTrade.frozenEntryShadowDecisionId = pending?.entryShadowDecisionId ?? null;
      this.openTrade.frozenEntryShadowSit = pending?.shadowSit === true;
      this.openTrade.frozenEntryShadowProtectedCheapNo = pending?.protectedCheapNo === true;
      this.openTrade.frozenEntryShadowProtectedCheapYes = pending?.protectedCheapYes === true;
      appendFrozenLedgerRow({
        kind: "FILL",
        ruleset: FROZEN_CC_RULESET_VERSION,
        gitSha: runningGitSha(),
        ts: Date.now(),
        ticker,
        strategyId: strategyId ?? FROZEN_CC_STRATEGY_ID,
        side,
        askCents: entryPrice,
        contracts,
        secsRemaining: secs,
        p: pending?.p ?? null,
        evCents: pending?.ev ?? null,
        confidence,
        entryFeeCents: kalshiTakerFeeCents(entryPrice, contracts),
        paper: paper === true,
        shadow: this.openTrade.frozenShadow,
        entryTheoCents,
        entryTheoMissing,
      });
      try { maybeWritePromoteArtifacts(readFrozenLedger()); } catch { /* measurement */ }
    }
    try {
      if (paper && this.config.paperMode === true) {
        notePaperBarFill({
          ticker,
          strategyId: strategyId ?? "unknown",
          side,
          askCents: entryPrice,
          n: contracts,
        });
      }
    } catch { /* observational paper-bar-tape */ }
    // GO — APPLY PACKS ENFORCE: in enforce mode, use the REAL per-tick pack
    // evaluateEntry() computed and cached on `this` (guaranteed to be the
    // exact pack that just gated eligibility/confBump/sizeCapMult for THIS
    // order) instead of a second independent shadow re-derivation. shadow/
    // off modes keep the prior pure-observation compute, which never reads
    // or affects the real order above.
    let packShadow: ShadowPackEvaluation | null = null;
    let realOrderPack: SpecialistPack | null = null;
    try {
      if (this.config.specialistPacksMode === 'enforce') {
        realOrderPack = this.lastEnforcedPack;
      } else if (this.config.specialistPacksMode !== 'off') {
        const regimeDebug = getRegimeDebug();
        // GO — WIRE LOW_VOL PACK FROM V_bucket: this order was already sized
        // using the tick's own volume-risk bucket (see evaluateEntry()'s
        // computeVolumeScore block) and carries it on `params` — reuse the
        // SAME bucket rather than recomputing, so the shadow pack agrees
        // with what actually happened this tick. Falls back to 'NORMAL'
        // (never LOW_VOL) on the rare path that doesn't set it.
        const orderVBucket: VolumeBucket = params.volumeBucket ?? 'NORMAL';
        packShadow = evaluateSpecialistPackShadow({
          regime: regimeDebug.current,
          vBucket: orderVBucket,
          disabledSet: [...effectiveDisabledStrategies(this.config), ...getDbDisabledStrategies(durationMins)],
          dwellMs: Date.now() - regimeDebug.sinceMs,
          candidate: { strategyId: strategyId as StrategyId, askCents: entryPrice, edgePct: params.edgePct },
        });
        if (packShadow.packId) {
          this.log("info",
            `🧪 [pack-shadow] R=${regimeDebug.current} pack=${packShadow.packId} ` +
            `eligible=[${packShadow.wouldEligible.join(',')}] cap=${packShadow.wouldSizeCap} ` +
            `bump=${packShadow.wouldConfBump} live=ORDER(${strategyId}) would=${packShadow.wouldOutcome}`);
        }
      }
      if (realOrderPack) {
        this.log("info",
          `📦 [pack-enforce] pack=${realOrderPack.id} live=ORDER(${strategyId}) ` +
          `sizeCap=${realOrderPack.sizeCapMult} confBump=${realOrderPack.confBump} contracts=${contracts}`);
      }
    } catch (err) {
      this.log("warn", `[pack-enforce] compute error (non-fatal, mode=${this.config.specialistPacksMode}): ${(err as Error).message}`);
    }
    const orderTracePackId = realOrderPack ? realOrderPack.id : (packShadow?.packId ?? undefined);
    const orderTraceEligible = realOrderPack ? (this.lastPackEligibleIds ?? []) : packShadow?.wouldEligible;
    const orderTracePackCap = realOrderPack ? realOrderPack.sizeCapMult : (packShadow?.wouldSizeCap ?? undefined);
    // GO — SPECIALIST REGIME SYSTEM Phase 0 (DecisionTrace): unconditional
    // ORDER trace for every successful placement (paper or live), joined to
    // the bot_trades row via traceId (persisted above) and botTradeId here.
    void persistDecisionTrace({
      traceId: orderTraceId, ts: Date.now(), ticker, side, secsLeft: secs,
      // Phase 1 (SPECIALIST REGIME SYSTEM): `regime` now carries the sticky
      // committed R_t (fine 10-value RegimeId) per spec, not the coarse
      // GrokRegime this previously held — grokRegime is still recoverable
      // via getGrokRegimeFromDetailed(getRegime()) if needed downstream.
      regime: getRegime(), regimeHeldBy: getRegimeHeldBy() ?? undefined,
      strategyId, ask: entryPrice, pSize: contracts,
      feeCents: kalshiTakerFeeCents(entryPrice, contracts),
      breakevenWR: kalshiBreakevenWinRate(entryPrice, contracts),
      volMult: params.volumeSizeMult, contracts, outcome: "ORDER",
      // GO — APPLY PACKS ENFORCE: combinedMult is the sizing stack's own
      // [0.15, 1.15]-clamped uMult*volumeSizeMult*packSizeCapMult product
      // computed in computeContracts(); undefined when no pack is live
      // (shadow/off modes, or enforce with no pack this tick) since there's
      // nothing to distinguish it from the pre-existing uMult*volumeSizeMult
      // product in that case.
      combinedMult: realOrderPack ? (params.packSizeCapMult ?? 1) * (params.volumeSizeMult ?? 1) : undefined,
      pWin: strategyWinRate,
      signalConfidence: confidence,
      chain: [
        `durationMins=${durationMins}`, paper ? "paper" : "live", `pWin=${strategyWinRate}`, `signalConfidence=${confidence}`,
        ...(realOrderPack ? [`PACK:${realOrderPack.id}:confBump=${realOrderPack.confBump}:cap=${realOrderPack.sizeCapMult}:enforce`] : []),
        ...(!realOrderPack && packShadow?.packId ? [`SHADOW_PACK:${packShadow.packId}:confBump=${packShadow.wouldConfBump}:cap=${packShadow.wouldSizeCap}:outcome=${packShadow.wouldOutcome}`] : []),
      ],
      botTradeId: dbId ?? undefined,
      pack: orderTracePackId,
      eligible: orderTraceEligible,
      packCap: orderTracePackCap,
    });
    // Profit Doctrine Phase 6: same successful-placement commit point gets a
    // second row under the wider eventType taxonomy (ENTRY), carrying the
    // richer pricing/sizing/gates blocks the P6 spec calls for. Additive
    // alongside the Phase 0 ORDER row above — not a replacement — so every
    // existing outcome='ORDER' consumer is untouched.
    void persistDecisionTraceEvent({
      traceId: orderTraceId, eventType: "ENTRY", ticker, side, strategyId, secsLeft: secs,
      family: getStrategyFamily(strategyId as StrategyId), packId: orderTracePackId,
      pricing: { askCents: entryPrice, netEvCents: entryStopRewardPlan?.expectedRewardCents, contracts, pWin: strategyWinRate, signalConfidence: confidence },
      sizing: {
        uMult: params.volumeSizeMult, volSizeMult: params.volumeSizeMult,
        stackedMult: realOrderPack ? (params.packSizeCapMult ?? 1) * (params.volumeSizeMult ?? 1) : undefined,
      },
      gates: { primaryBlocker: null, evPass: true, pathPass: true },
      chain: [durationMins === 60 ? "1h" : "15m", paper ? "paper" : "live"],
    });
    // Consume the stall-reversal signal immediately on fill so the same armed
    // sequence can't be re-fired on subsequent ticks within its grace window.
    if (strategyId === 'VELOCITY_STALL_REVERSAL') this.velocityReversalDetector.reset();
    // Research record: capture only decision-time facts immediately after a
    // successful fill. Do not derive these fields later (look-ahead leakage).
    const ob = kalshiWS.getLatestOrderbook();
    const bidDepth = ob?.ticker === ticker ? ob.yesBids.reduce((sum, [, qty]) => sum + qty, 0) : 0;
    const askDepth = ob?.ticker === ticker ? ob.yesAsks.reduce((sum, [, qty]) => sum + qty, 0) : 0;
    const totalDepth = bidDepth + askDepth;
    const metaMtf = mtfAnalyzer.getSummary();
    const currentPrice = this.prices.at(-1)?.price ?? floorStrike;
    // Best-effort mirror of the "Regime clarity signal" trendAligned predicate
    // (confidence-scoring step above) for logging-only fields below.
    const metaTrendAligned = params.grokRegime === "trending" &&
      ((side === "yes" && this.currentVelocity > 0) || (side === "no" && this.currentVelocity < 0));
    try {
      // This is the single allowed decision record for a filled order. Its ID
      // is held on OpenTrade and updated with the exact settlement later.
      this.openTrade!.metaExampleId = recordMetaDecision(buildMetaFeatures({
        timestamp: this.openTrade!.openedAt, marketTicker: ticker, contractDurationMins: durationMins,
        secsRemaining: secs, path: getPathConfig(entryPrice).path, regime: params.grokRegime ?? "unclear",
        strategyId: this.openTrade!.strategyId, direction: side.toUpperCase() as "YES" | "NO",
        strategyConfidence: confidence > 1 ? confidence / 100 : confidence, preTradeScore: confidence,
        entryPriceCents: entryPrice, btcPrice: currentPrice, floorStrike,
        distFromFloorPct: floorStrike ? ((currentPrice - floorStrike) / floorStrike) * 100 : 0,
        velocity1m: this.currentVelocity, velocity3m: this.threeMinVelocity,
        isStalling: this.lastStalling, spreadCents: 0,
        bestBidSize: ob?.yesBids[0]?.[1] ?? 0, bestAskSize: ob?.yesAsks[0]?.[1] ?? 0,
        bookImbalance: totalDepth ? (bidDepth - askDepth) / totalDepth : 0,
        opposingDepth: side === "yes" ? askDepth : bidDepth,
        suspicionScore: kalshiWS.getOrderbookLiquidityInstability(side).score,
        mtfScore: metaMtf?.score, mtfBias: metaMtf?.bias.includes("bull") ? "BULL" : metaMtf?.bias.includes("bear") ? "BEAR" : "NEUTRAL",
        mtfM1Score: metaMtf?.m1?.score, mtfM5Score: metaMtf?.m5?.score,
        mtfM15Score: metaMtf?.m15?.score, mtfH1Score: metaMtf?.h1?.score,
        // Best-effort recomputation of the identical predicates in the
        // confidence-scoring step (trading-bot.ts, "Regime clarity signal"
        // block) — that step doesn't thread its trendAligned/lowVol booleans
        // out to here, and duplicating the exact source condition is safer
        // for a logging-only field than plumbing new state through the
        // whole entry pipeline for it. Uses this.currentVelocity as the
        // velocity source, matching the velocity1m field logged above.
        regimeBonusFired: metaTrendAligned,
        regimePenaltyFired: !metaTrendAligned && params.grokRegime === "low_vol",
        estimatedWinRate: confidence > 1 ? confidence / 100 : confidence,
        balanceCents: this.config.paperMode ? this.paperVirtualBalanceCents : this.accountBalance ?? undefined,
        consecutiveLosses: this.consecutiveLosses, riskProfile: params.modeState?.riskProfile,
      }), {
        allowed: true,
        finalContracts: contracts,
      });
    } catch (err) {
      this.log("warn", `Meta-example capture failed: ${(err as Error).message}`);
    }
    this.openTradeMaxGain        = 0;
    this.openTradePnlCents       = 0;
    this.volStaleFallbackLogged  = false;
    this.volStaleAddLogged       = false;
    this.tradedThisPeriod        = true;
    this.state               = "IN_TRADE";

    const maxProfit    = contracts * (100 - entryPrice);
    const multiplier   = entryPrice > 0 ? ((100 - entryPrice) / entryPrice).toFixed(2) : "—";
    const exitPlanText = entryStopRewardPlan
      ? `stop −${entryStopRewardPlan.stopLossCents.toFixed(1)}¢ · take +${entryStopRewardPlan.targetProfitCents.toFixed(1)}¢ · ` +
        `net R/R ${entryStopRewardPlan.rewardRiskRatio.toFixed(2)}x ` +
        `(risk ${entryStopRewardPlan.maxLossCents.toFixed(1)}¢ / reward ${entryStopRewardPlan.expectedRewardCents.toFixed(1)}¢)`
      : "OTM exit plan (no fixed stop)";

    // FEE ORGAN — sized fill observability (entry fee; RT if sold at mark)
    {
      const feeCents = kalshiTakerFeeCents(entryPrice, contracts);
      const feePct = kalshiFeePctOfCost(entryPrice, contracts);
      const beWR = kalshiBreakevenWinRate(entryPrice, contracts);
      const tick = kalshiWS.getLatest();
      const markAsk = side === "yes"
        ? (tick?.yesAsk || entryPrice)
        : (tick?.noAsk || entryPrice);
      const rtIfSold = expectedRoundTripFeeCents(entryPrice, markAsk, contracts);
      this.log("info",
        `💸 [fee-organ] ${signal} ${contracts}× @ ${entryPrice}¢ | feeCents=${feeCents} ` +
        `feePctOfCost=${feePct.toFixed(2)}% | breakevenWR=${(beWR * 100).toFixed(1)}% | ` +
        `roundTripFeeIfSoldAtMark=${rtIfSold}¢`
      );
    }

    if (paper) {
      this.log("order",
        `📝 PAPER ${signal} · ${contracts}× ${side.toUpperCase()} @ ${entryPrice}¢ · ` +
        `cost $${(costCents / 100).toFixed(2)} · max $${(maxProfit / 100).toFixed(2)} (${multiplier}x) · ` +
        `${exitPlanText} · bal $${(this.paperVirtualBalanceCents / 100).toFixed(2)}`
      );
    } else {
      this.log("order",
        `✅ ${signal} · ${contracts}× ${side.toUpperCase()} @ ${entryPrice}¢ (ask) · ` +
        `${exitPlanText} · edge ${this.lastEdge.toFixed(1)}%`
      );
      // Schedule fill-check: if the order hasn't filled within 5 s, cancel it.
      // Ordering at the ask should fill instantly — if it doesn't, the spread moved.
      // Store context so cancelUnfilledOrder can attempt one re-quote.
      // Only arm this on the ORIGINAL order (requoteCount 0/undefined) — a
      // re-quoted order must not re-arm its own requeueContext, or the chase
      // can repeat indefinitely (see requoteCount doc comment above).
      if (orderId && !params.requoteCount) {
        this.requeueContext = {
          side, signal, originalAsk: entryPrice,
          params: { signal, side, entryPrice, floorStrike, ticker, confidence, secs, strategyWinRate, strategyId, velocityDolPerMin, spreadCents },
        };
        this.cancelUnfilledOrder(orderId, dbId).catch(() => {});
      }
    }
  }

  /**
   * GO EXECUTION INTEGRITY BATCH — A1 (order lifecycle durability).
   *
   * A 2xx response from Kalshi's order-placement endpoint means the order was
   * ACCEPTED, not that it filled. Every caller that needs to know whether a
   * position actually changed (exit, add-to-position) must poll this real
   * order-status endpoint and treat the result as the source of truth — never
   * assume a fill from the placement response alone.
   *
   * `confirmed: false` means every poll attempt failed to get a definitive
   * read from Kalshi (network/API failure throughout the window). Callers
   * MUST treat that as unknown/unresolved — NOT as filled and NOT as
   * failed-to-fill. A timeout is never a success.
   */
  private async pollOrderFillStatus(
    orderId: string,
    opts: { attempts?: number; intervalMs?: number; expectedContracts?: number; timeoutMs?: number } = {},
  ): Promise<{ confirmed: boolean; filled: number; status: string; avgPriceCents: number | null }> {
    return leftoverLivePollOrderFillStatus.call(this, orderId, opts);
  }

  /** Re-reads a single entry order after a cancellation race. `null` means
   * Kalshi did not give us a definitive snapshot, never that the order is
   * unfilled. */
  private async fetchEntryOrderStatus(orderId: string): Promise<EntryOrderStatusSnapshot | null> {
    return leftoverLiveFetchEntryOrderStatus.call(this, orderId);
  }

  /**
   * Cancels the still-resting portion of a partial entry. Thin leftover funnel wrapper.
   */
  private async cancelPartialEntryRemainder(
    orderId: string,
    snapshot: EntryOrderStatusSnapshot,
    requestedContracts: number,
  ): Promise<EntryOrderStatusSnapshot | null> {
    return leftoverLiveCancelPartialEntryRemainder.call(this, orderId, snapshot, requestedContracts);
  }

  private async cancelUnfilledOrder(orderId: string, dbId: number | null): Promise<void> {
    await leftoverLiveUnfilledFunnel.call(this, { orderId, dbId, ...leftoverLiveUnfilledHelpers({ MAX_CHASE, SWEEP_PREMIUM }) });
  }


  // ── Settlement detection ──────────────────────────────────────────────────────

  private async detectSettlement() {
    // Task #301: detectSettlement() is invoked both from the tick loop
    // (awaited) and fire-and-forget by forceSettleCheck() (watchdog, when the
    // open trade looks unusually old — exactly the moment a slow tick and a
    // watchdog nudge are most likely to race). recordSettlement() only clears
    // this.openTrade at the very end, after several awaits (DB write, etc.),
    // so without this guard both call paths could pass the "openTrade still
    // set" check and record the SAME trade's outcome twice — double-counting
    // wins/losses in the per-strategy learning stats (recordOutcome) and
    // today/paper stats. Set synchronously before any await so a second
    // concurrent call always sees it set.
    if (this.settlementCheckInFlight) return;
    this.settlementCheckInFlight = true;
    try {
      await this._detectSettlementBody();
    } catch (err) {
      // The paper-mode branch below had no safety net at all, so a throw from
      // recordSettlement() on that fire-and-forget path became a silent
      // unhandled rejection instead of a visible bot-log error.
      this.log("error", `[settlement] uncaught error: ${(err as Error).message}`);
    } finally {
      this.settlementCheckInFlight = false;
    }
  }

  private async _detectSettlementBody() {
    if (!this.openTrade) return;
    const trade = this.openTrade;

    if (trade.paper) {
      const tick          = kalshiWS.getLatest();
      // GE_001 (safe port): Kalshi official result → pre-close print (after
      // grace) → latest print only 10 min past close. Never a post-close print
      // while better evidence can still arrive; never stuck unresolved.
      const nowMs = Date.now();
      let kalshiResult: "yes" | "no" | null = null;
      if (nowMs - this.lastPaperSettleResultFetchMs >= 10_000) {
        this.lastPaperSettleResultFetchMs = nowMs;
        try { kalshiResult = await fetchMarketResultPublic(trade.ticker); } catch { kalshiResult = null; }
      }
      // SEV0 (sweep S2): re-check after the await: another path may have closed it.
      if (this.openTrade !== trade || trade.settlementFinalized === true) return;
      const src = decidePaperSettleSource({
        kalshiResult,
        preClosePrice: paperSettlementRefPrice(this.prices, trade.closeTimeMs),
        latestPrice: this.prices.length > 0 ? this.prices[this.prices.length - 1].price : null,
        closeTimeMs: trade.closeTimeMs,
        nowMs,
      });
      if (src.kind !== "wait" && (src.kind === "kalshi" || trade.floorStrike)) {
        const priceUp = src.kind === "kalshi" ? src.priceUp : src.price > (trade.floorStrike as number);
        if (src.kind === "print" && src.basis === "latest_fallback") {
          this.log("warn", `[settlement] ${trade.ticker}: no Kalshi result / pre-close print 10 min after close — latest-print fallback`);
        }
        const won     = trade.side === "yes" ? priceUp : !priceUp;
        const { pnlCents: pnl, payoutCents: payout } = computeBinarySettlementPnl(trade.contracts, trade.entryPriceCents, won);
        // Contract settlement (not an early-exit): stamp skip ITM/OTM for this
        // ticker so sat-out strategies learn from the same close. Shadow-only.
        try { resolveSkipsForTicker(trade.ticker, priceUp ? "YES" : "NO"); } catch { /* observational */ }
        await this.recordSettlement(trade, won ? "win" : "loss", pnl, payout, undefined, "SETTLEMENT");
      }
      return;
    }

    try {
      const apiPath = kalshiSettlementsPath(5);
      const r       = await fetch(`${KALSHI_API_DOMAIN}${apiPath}`, {
        headers: { ...await kalshiAuthHeaders("GET", apiPath), Accept: "application/json" },
        signal: AbortSignal.timeout(6_000),
      });
      if (r.ok) {
        const data = (await r.json()) as { settlements?: Array<{ ticker: string; revenue: number; profit?: number }> };
        const match = (data.settlements ?? []).find(s => s.ticker === trade.ticker);
        if (match) {
          // match.profit from Kalshi API is already net of fees.
          // The manual fallback (revenue − cost) is gross — fee-adjust it.
          const grossProfit    = match.revenue - trade.contracts * trade.entryPriceCents;
          const fallbackFee    = grossProfit > 0 ? kalshiTakerFeeCents(trade.entryPriceCents, trade.contracts) : 0;
          const profit         = match.profit ?? (grossProfit - fallbackFee);
          const won            = profit >= 0;
          // Infer contract YES/NO from our side × win, then label sat-outs.
          const settledYesNo   = trade.side === "yes" ? (won ? "YES" : "NO") : (won ? "NO" : "YES");
          try { resolveSkipsForTicker(trade.ticker, settledYesNo); } catch { /* observational */ }
          await this.recordSettlement(trade, won ? "win" : "loss", Math.round(profit), match.revenue, undefined, "SETTLED_KALSHI");
          return;
        }
      }
    } catch (err) {
      this.log("warn", `Settlement API fetch failed: ${(err as Error).message}`);
    }

    // Settlement API unavailable or had no match for this ticker yet.
    // BUG FIX (settlement-fallback): this used to infer win/loss from the
    // last fresh BTC price observation (tick.floorStrike / lastObs vs
    // trade.floorStrike) whenever Kalshi's own settlement wasn't available —
    // a stale (up to 90s-old) proxy price could book the OPPOSITE of
    // Kalshi's real outcome at a boundary, and even though that heuristic
    // outcome was flagged authoritative=false (excluded from strategy
    // learning), it still advanced todayStats/paperStats win-loss counters
    // and the consecutive-loss streak via recordSettlement()'s default
    // affectsRiskCounters=true — i.e. it silently invented a settled result
    // that moved live risk state. Removed entirely: Kalshi is the only
    // source of truth for a live settlement outcome. We only ever retry
    // (poll) or, after a bounded timeout, give up cleanly as "unresolved"
    // (no win/loss booked, no risk counters touched) — see
    // resolveSettlementFallbackOutcome().
    const outcome = resolveSettlementFallbackOutcome(
      this.settlementUnresolvedSinceTs,
      Date.now(),
      SETTLEMENT_UNRESOLVED_TIMEOUT_MS,
    );
    if (outcome.action === "keep-waiting") {
      if (outcome.since !== this.settlementUnresolvedSinceTs) this.settlementUnresolvedSinceTs = outcome.since;
      this.log("warn",
        `Settlement API unavailable/no match for ${trade.ticker} — retrying (${Math.round(outcome.elapsedMs / 1000)}s of ${Math.round(SETTLEMENT_UNRESOLVED_TIMEOUT_MS / 1000)}s timeout)`
      );
    } else {
      await this.recordUnresolvedSettlement(trade,
        `Kalshi settlement unavailable/no match for ${Math.round(outcome.elapsedMs / 1000)}s (timeout ${Math.round(SETTLEMENT_UNRESOLVED_TIMEOUT_MS / 1000)}s) — no win/loss booked.`
      );
    }
  }

  /**
   * Finalizes a live trade whose real Kalshi settlement could not be
   * confirmed within the timeout. Persists outcome="unresolved" (pnlCents
   * left NULL — "unknown", not "flat") via the same shared primitive used by
   * external-close/startup recovery, and deliberately does NOT: book a
   * win/loss, touch todayStats/paperStats/consecutiveLosses/currentStreak,
   * or feed strategy learning / meta-labeling. Clears openTrade so the bot
   * isn't stuck holding a phantom position.
   */
  private async recordUnresolvedSettlement(trade: OpenTrade, reasonText: string): Promise<void> {
    let unresolvedPersistFailed = false;
    if (trade.dbId != null) {
      try {
        await markTradeUnresolved(trade.dbId, "SETTLEMENT_UNRESOLVED", reasonText);
      } catch (err) {
        unresolvedPersistFailed = true;
        this.log("error", `[settlement] FAILED to persist SETTLEMENT_UNRESOLVED for trade #${trade.dbId} (${trade.ticker}): ${(err as Error).message}`);
      }
    }
    this.openTradeMaxGain  = 0;
    this.openTradePnlCents = 0;
    this.log("settle", `❓ SETTLEMENT_UNRESOLVED · ${trade.ticker}${trade.paper ? " [PAPER]" : ""} · ${reasonText}`);
    // Paper never KEEP (CLOSE spam root). Live fail-closed KEEP when PG pending would orphan.
    if (trade.paper !== true && shouldKeepOpenTradeAfterSettlePersistFail({
      hasDbId: trade.dbId != null,
      persistFailed: unresolvedPersistFailed,
    })) {
      this.log("error",
        `[settlement] fail-closed KEEP openTrade #${trade.dbId} — unresolved persist failed; refusing openTrade=null orphan`,
      );
      return;
    }
    // Route through setOpenTrade() (not a bare assignment) — see the
    // "openTrade write consolidation" convention used at every other
    // settlement/close exit path in this file.
    this.setOpenTrade(null);
  }

  private settleRetryTimer: ReturnType<typeof setInterval> | null = null;
  private lastPostCloseSettleNudgeMs = 0;
  private exitQuoteMismatchLogged = false;

  /**
   * Settlement audit (Sep 25): retry settle writes that failed while the DB was
   * degraded, instead of leaving bot_trades "pending" until a restart sweep.
   * Only touches rows still outcome="pending". Persistence only.
   */
  private startSettlePersistRetryLoop(): void {
    if (this.settleRetryTimer) return;
    const run = () => {
      void drainSettlePersistRetry(async (dbId, patch) => {
        const rows = await db.update(botTrades).set(patch)
          .where(and(eq(botTrades.id, dbId), eq(botTrades.outcome, "pending")))
          .returning({ id: botTrades.id });
        return rows.length > 0;
      }).then((r) => {
        for (const id of [...r.landed, ...r.alreadySettled]) {
          if (r.landed.includes(id)) this.log("info", `[settlement] retry persisted trade #${id} (was left pending by a failed DB write)`);
          // Live fail-closed KEEP: release the finalized trade once its row landed.
          const ot = this.openTrade;
          if (ot && ot.dbId === id && ot.settlementFinalized === true) this.setOpenTrade(null);
        }
      }).catch(() => { /* next interval */ });
    };
    run();
    this.settleRetryTimer = setInterval(run, SETTLE_RETRY_INTERVAL_MS);
    (this.settleRetryTimer as { unref?: () => void }).unref?.();
  }

  private async recordSettlement(trade: OpenTrade, outcome: "win" | "loss", pnlCentsIn: number, payoutCents = 0, exitBreakdown?: ExitPriceBreakdown, exitReason?: string, authoritative = true, affectsRiskCounters = true) {
    // PARTIAL-FILL PnL FIX: fold in any earlier CONFIRMED partial exit leg(s)
    // on this same trade (see exitEarly()'s give-up-partial branch, which
    // accumulates realizedPartialPnlCents/FeeCents instead of discarding
    // them). Centralized here — rather than at each call site — so EVERY
    // terminal path that can close this trade (early exit, Kalshi settlement
    // match, external-close inference) reports the FULL realized economics
    // across all fills, not just whichever leg happened to trigger the final
    // call. Win/loss is recomputed from the combined total because folding
    // in the earlier leg can flip the sign (e.g. a profitable partial exit
    // followed by a losing final leg can still net an overall win, or vice
    // versa) — trusting the caller's pre-computed outcome would reintroduce
    // the exact "scored on the remainder only" bug this fixes.
    // SEV0 (sweep S2): idempotent. settlementFinalized is stamped synchronously
    // below, so a second caller (watchdog forceSettleCheck vs tick exitEarly vs
    // rollover settle) must return here instead of crediting cash/reserve and
    // writing a second tape close for the same fill.
    if (trade.settlementFinalized === true) {
      this.log("warn", `[settlement] duplicate settle ignored for ${trade.ticker} #${trade.dbId ?? "?"} (${exitReason ?? "SETTLEMENT"} ${pnlCentsIn}¢) — already finalized`);
      if (this.openTrade === trade && (trade.paper === true || trade.dbId == null || !isSettleRetryQueued(trade.dbId))) {
        this.setOpenTrade(null);
      }
      return;
    }
    const partialPnlCents = trade.realizedPartialPnlCents ?? 0;
    const partialFeeCents = trade.realizedPartialFeeCents ?? 0;
    const combined = combineSettlementWithPriorPartial(pnlCentsIn, partialPnlCents);
    const pnlCents = combined.pnlCents;
    outcome = combined.outcome;
    if (combined.folded) {
      this.log("info",
        `[partial-fill] ${trade.ticker}: folding in ${trade.realizedPartialContracts ?? "?"} earlier-closed contract(s) — ` +
        `prior leg(s) net ${partialPnlCents >= 0 ? '+' : ''}$${(partialPnlCents / 100).toFixed(2)} (fee $${(partialFeeCents / 100).toFixed(2)}) + ` +
        `this leg ${(pnlCentsIn) >= 0 ? '+' : ''}$${(pnlCentsIn / 100).toFixed(2)} = total ${pnlCents >= 0 ? '+' : ''}$${(pnlCents / 100).toFixed(2)} → ${outcome}`);
    }
    // Honesty: stamp sync BEFORE any await so exitEarly/PATH_RIDE cannot re-enter
    // and spam CLOSE rows after settlement accounting already ran.
    trade.settlementFinalized = true;
    let settlePersistFailed = false;
    // Master bot upgrade step 4: settlement-path sibling of the exitEarly()
    // press-cooldown write above — covers trades that ride to settlement
    // rather than exiting early (loss or THESIS_BREAK_EXIT/LAG_FLIP_EXIT).
    if (outcome === "loss" || exitReason === "THESIS_BREAK_EXIT" || exitReason === "LAG_FLIP_EXIT") {
      this.pressCooldownTicker = trade.ticker;
      this.pressCooldownUntil  = Date.now() + STACK_PRESS_COOLDOWN_MS;
    }
    // GO EXECUTION INTEGRITY BATCH — A2: an unattributed balance-inference
    // delta (EXTERNAL_CLOSE_BALANCE_INFERRED — see handleExternalClose) can
    // be contaminated by account activity other than this trade's own close
    // (another manual order, a deposit/withdrawal, a second settlement) that
    // happens to still fall inside this position's physically-possible P&L
    // range. The plausibility bound rejects impossible values but cannot
    // prove attribution, so it must never gate live risk decisions — a
    // contaminated positive delta could otherwise silently defer the daily
    // loss cap (todayStats.pnlCents) or reset the consecutive-loss cooldown.
    // Only fill-confirmed / authoritative settlement prices move risk
    // counters; balance-inferred exits are still persisted to the DB below
    // for honest dashboard display, just excluded from what gates trading.
    const origin: FillOrigin = trade.fillOrigin ?? FILL_ORIGIN_BOT;
    this.overallStats.pnlCents += pnlCents;
    if (shouldFeedLearner(origin, trade.strategyId)) {
      if (affectsRiskCounters) {
        this.todayStats.pnlCents += pnlCents;
      }
    } else if (affectsRiskCounters) {
      // Manual: overall P&L only. Do not move bot daily-loss / WR counters.
    }
    this.openTradeMaxGain     = 0;
    this.openTradePnlCents    = 0;

    // Profit Doctrine Phase 6: single choke-point SETTLE decision-trace row —
    // recordSettlement() is called from every terminal path (early exit,
    // normal Kalshi/paper settlement, external close) except the startup-
    // recovery sweep (which writes its own RECON row directly — see
    // recoverStalePendingTrades()/settlement-helpers.ts). Fire-and-forget.
    void persistDecisionTraceEvent({
      eventType: "SETTLE", ticker: trade.ticker, side: trade.side, strategyId: trade.strategyId,
      exit: { reasonCode: exitReason ?? "SETTLEMENT", pnlCents, outcome, authoritative },
      chain: [exitReason ?? "SETTLEMENT", authoritative ? "authoritative" : "inferred"],
    });
    const lastPx = paperSettlementRefPrice(this.prices, trade.closeTimeMs);
    const expirySettle = isExpirySettleReason(exitReason ?? "SETTLEMENT");
    // P0-D: stamp officialSettle when Kalshi result is knowable (expiry OR
    // period already closed) even on PATH_RIDE_TP / early exits. Never invent
    // from paper W/L — only BTC@close vs floor via kalshiSettleFromTruth.
    const periodClosed =
      typeof trade.closeTimeMs === "number"
      && trade.closeTimeMs > 0
      && Date.now() >= trade.closeTimeMs;
    const truthSettleOk = expirySettle || periodClosed;
    const officialSettle = kalshiSettleFromTruth({
      btcClose: truthSettleOk ? lastPx : null,
      floorStrike: truthSettleOk ? trade.floorStrike : null,
    });
    try {
      if (this.config.paperMode === true && trade.paper) {
        notePaperBarExit({
          ticker: trade.ticker,
          exitReason: exitReason ?? "SETTLEMENT",
          holdMs: Date.now() - trade.openedAt,
          velAgainstTicks: this.thesisVelocityAgainstTicks,
          ticketAdverseCents: null,
          kalshiSettle: truthSettleOk ? officialSettle : null,
          virtualCents: this.paperVirtualBalanceCents,
          wins: this.paperStats.wins,
          losses: this.paperStats.losses,
          pnlCents: this.paperStats.pnlCents,
        });
        if (expirySettle) {
          flushPaperBar(trade.ticker, {
            kalshiSettle: officialSettle,
            virtualCents: this.paperVirtualBalanceCents,
            wins: this.paperStats.wins,
            losses: this.paperStats.losses,
            pnlCents: this.paperStats.pnlCents,
            expiry: true,
          });
        }
      }
    } catch { /* observational paper-bar-tape */ }
    // This trade is now closed — clear its ARIA-HOLD coalescing entry so a
    // future trade on the same ticker starts a fresh coalescing window
    // rather than potentially bumping a stale row from this now-closed trade.
    clearAriaCoalesceCache(trade.ticker);
    // Resolve the research example only with the same reliability boundary as
    // strategy learning. Heuristic observations stay recorded but unlabeled.
    try {
      resolveTakenMetaExample({
        id: trade.metaExampleId, ticker: trade.ticker, openedAt: trade.openedAt,
        settledITM: outcome === "win", pnlCents, exitReason: exitReason ?? "SETTLEMENT",
        authoritative,
      });
    } catch (err) {
      this.log("warn", `Meta-example resolution failed: ${(err as Error).message}`);
    }

    // ── Strategy learning: record outcome for this strategy ───────────────────
    // Fires for both paper and live trades so the bot learns from all simulations.
    // Pass the strategy's expectedWinRate as the Bayesian prior so new strategies
    // start with smarter warm-start weights from trade #1.
    try {
      // Only AUTHORITATIVE outcomes (Kalshi settlement API / real fills) feed
      // strategy learning — heuristic fallbacks would contaminate win rates.
      // Duration-scoped learning: 15m and 1h outcomes are tracked separately.
      // Shared with recoverStalePendingTrades() (settlement-helpers.ts) so a
      // late-recovered trade feeds the exact same pipelines the same way.
      if (trade.strategyId && authoritative) {
        await feedLearningPipelines(
          trade.strategyId, outcome === "win", pnlCents, trade.contractDurationMins,
          msg => this.log("warn", msg),
          trade.dbId ?? undefined, trade.paper,
          exitReason,
          trade.fillOrigin ?? FILL_ORIGIN_BOT,
        );
      }
    } catch (err) {
      this.log("warn", `Strategy-learning update failed for ${trade.strategyId ?? "unknown"}: ${(err as Error).message}`);
    }

    // ── OTM/multiplier stats: tracked separately from overall todayStats ──────
    // Mixing OTM results into overall stats distorts win-rate signals because
    // OTM strategies are designed to have a low win rate with high payout.
    const OTM_STRATEGY_IDS = ['OTM_ASYMMETRY', 'OTM_BREAKOUT_EXPANSION'];
    if (trade.strategyId && OTM_STRATEGY_IDS.includes(trade.strategyId)) {
      this.otmStats.pnlCents += pnlCents;
      const paid = trade.contracts * trade.entryPriceCents;
      this.otmStats.totalPaidCents += paid;
      if (outcome === 'win') {
        this.otmStats.wins++;
        // Track average win multiple: gross payout / cost per contract
        const grossPayout = payoutCents > 0 ? payoutCents : trade.contracts * 100;
        const multiple    = paid > 0 ? grossPayout / paid : 0;
        this.otmStats._winMultipleSum += multiple;
        this.otmStats._winCount       += 1;
        this.otmStats.avgWinMultiple   = +(this.otmStats._winMultipleSum / this.otmStats._winCount).toFixed(2);
      } else {
        this.otmStats.losses++;
      }
      const otmTotal = this.otmStats.wins + this.otmStats.losses;
      const otmWR    = otmTotal > 0 ? (this.otmStats.wins / otmTotal * 100).toFixed(0) : '—';
      this.log("info",
        `📊 OTM stats: ${otmTotal} trades · ${otmWR}% WR · PnL ${pnlCents >= 0 ? '+' : ''}$${(this.otmStats.pnlCents / 100).toFixed(2)}` +
        (this.otmStats.avgWinMultiple ? ` · avg win ${this.otmStats.avgWinMultiple.toFixed(2)}×` : '')
      );
    }

    // Same affectsRiskCounters guard as todayStats.pnlCents above: an
    // unattributed balance-inferred outcome must not reset/advance the
    // consecutive-loss cooldown or the win/loss counters that feed it either.
    if (affectsRiskCounters && shouldFeedLearner(origin, trade.strategyId)) {
      if (outcome === "win") {
        this.todayStats.wins++;
        this.consecutiveLosses = 0;
        this.currentStreak     = this.currentStreak > 0 ? this.currentStreak + 1 : 1;
      } else {
        this.todayStats.losses++;
        this.consecutiveLosses++;
        this.currentStreak     = this.currentStreak < 0 ? this.currentStreak - 1 : -1;
      }
    }
    // Display / learner strategy WR: THESIS_BREAK / LAG_FLIP (risk_exit) keep PnL, not W/L.
    if (countsTowardStrategyWinRate(exitReason)) {
      if (outcome === "win") this.overallStats.wins++;
      else this.overallStats.losses++;
    }

    if (trade.paper) {
      // Display book can include manuals in overallStats. paperStats.pnl is
      // the paper session cash tape; still do not let manuals feed halt
      // (halt reads todayStats only). Keep paperStats cash honest for all
      // paper tickets so virtualCents matches the blotter.
      this.paperStats.pnlCents += Math.round(pnlCents);
      const isBinarySettlement = !exitReason || exitReason === "SETTLEMENT" || exitReason === "SETTLED_KALSHI";
      if (isBinarySettlement) {
        // Kalshi pays $1.00/contract on a win, $0 on a loss. Entry fee already
        // taken at fill — do not subtract computeBinarySettlementPnl's fee again.
        this.paperVirtualBalanceCents += paperSettlementCreditCents(trade.contracts, outcome === "win");
      } else {
        // Early exit: credit actual exit proceeds, debit the exit taker fee
        // already in pnlCents. Never credit 100 and never credit 0-because-payout-was-0.
        const exitCents = trade.contracts > 0 ? payoutCents / trade.contracts : 0;
        this.paperVirtualBalanceCents += paperEarlyExitCreditCents(trade.contracts, exitCents);
      }
      // Paper cash P&L already moved above. Ledger WR is BOT only — manuals
      // must not mix into paper bot win rate.
      if (includeInBotWinRate(origin, trade.strategyId)) {
        if (includeInStrategyWinRate(origin, trade.strategyId, exitReason)) {
          if (outcome === "win") this.paperStats.wins++;
          else this.paperStats.losses++;
        }
        if (outcome === "win") {
          // Reserve pool: lock in a portion of profits
          if (this.config.reservePct > 0) {
            const toReserve = Math.round(pnlCents * this.config.reservePct / 100);
            this.reservePoolCents         += toReserve;
            this.paperVirtualBalanceCents -= toReserve;
            this.log("info", `Reserve: +$${(toReserve / 100).toFixed(2)} -> pool $${(this.reservePoolCents / 100).toFixed(2)}`);
          }
        }
      }

      // Update peak balance
      if (this.paperVirtualBalanceCents > this.peakBalanceCents) {
        this.peakBalanceCents = this.paperVirtualBalanceCents;
      }
      this.persistPaperLedger();
      // Append-only close row so paper-trades.jsonl is not stuck at outcome=pending.
      // Matches stories + virtualCents ledger. Does not rewrite fill lines.
      try {
        {
          // P3-D: observe-only stamp for secondary-exit cluster (no new exits / floors uncut).
          {
            const er = String(exitReason ?? "");
            if (
              /PATH_RIDE_CATASTROPHIC/.test(er)
              || /LAG_FLIP/.test(er)
              || er === "THESIS_BREAK"
              || er === "THESIS_BREAK_EXIT"
            ) {
              this.log("info", `👁 ${SECONDARY_EXIT_CLUSTER_OBSERVE} exitReason=${er}`);
            }
          }
          const storyStamp = storyStampFromCloseState({
            side: trade.side,
            fillAsk: trade.entryPriceCents,
            entryPriceCents: trade.entryPriceCents,
            yesAsk: trade.yesAskAtEntry ?? null,
            noAsk: trade.noAskAtEntry ?? null,
            pFilledSide: trade.pFilledSideAtEntry ?? trade.strategyWinRateAtEntry ?? null,
            evCents: (typeof trade.frozenEntryEvCents === "number" && Number.isFinite(trade.frozenEntryEvCents) ? trade.frozenEntryEvCents : null) ?? trade.entryExpectedRewardCents ?? null,
            thesisStatus: trade.exitThesisStatus ?? null,
            ticketGreen: typeof trade.exitTicketGreen === "boolean" ? trade.exitTicketGreen : null,
            holdMs: typeof trade.exitHoldMs === "number" && Number.isFinite(trade.exitHoldMs)
              ? trade.exitHoldMs
              : (Date.now() - trade.openedAt),
            exitReason: exitReason ?? "SETTLEMENT",
            SESSION_MODE: trade.sessionModeAtEntry ?? this.lastSessionMode ?? null,
            lockSide: trade.lockSideAtEntry ?? null,
            pnlCents,
            feeNetCents: pnlCents,
            outcome,
            officialSettle: officialSettle ?? null,
            settledSide: officialSettle ?? null,
            officialKalshi: officialSettle ?? null,
            btcClose: truthSettleOk ? lastPx : null,
            floorStrike: trade.floorStrike ?? null,
          });
          // Desk/brain: stampStatus OK | STORY_STAMP_INCOMPLETE (incomplete ≠ win).
          this.lastSettleStamp = stampSettleMsg({
            stampStatus: storyStamp.stampStatus,
            feeNetCents: storyStamp.feeNetCents,
            feeNetVsSkip: storyStamp.feeNetVsSkip,
            officialSettle: storyStamp.officialSettle,
          });
          // GG R3#1 fee-net — backfill from settle truth before ledger write
          appendPaperTradeClose({
            ts: Date.now(),
            ticker: trade.ticker,
            ...(typeof trade.dbId === "number" && trade.dbId > 0 ? { tradeId: trade.dbId } : {}), // GE_013
            side: trade.side,
            contracts: trade.contracts,
            entryPriceCents: trade.entryPriceCents,
            strategyId: trade.strategyId ?? null,
            fillOrigin: (trade.fillOrigin === "manual" ? "manual" : "bot"),
            outcome,
            pnlCents,
            exitReason: storyStamp.exitReason ?? exitReason ?? "SETTLEMENT",
            exitPriceCents: trade.contracts > 0 ? Math.round(payoutCents / trade.contracts) : null,
            ...(trade.advisoryVetoes !== undefined ? { advisoryVetoes: trade.advisoryVetoes ?? null } : {}),
            ...(trade.mindHeave !== undefined ? { mindHeave: trade.mindHeave ?? null } : {}),
            holdMs: storyStamp.holdMs,
            settledAt: Date.now(),
            ...tagPathRideFill(trade.strategyId ?? null),
            fillAsk: storyStamp.fillAsk,
            yesAsk: storyStamp.yesAsk,
            noAsk: storyStamp.noAsk,
            pFilledSide: storyStamp.pFilledSide,
            evCents: storyStamp.evCents,
            thesisStatus: storyStamp.thesisStatus,
            ticketGreen: storyStamp.ticketGreen,
            SESSION_MODE: storyStamp.SESSION_MODE,
            lockSide: storyStamp.lockSide,
            feeNetCents: storyStamp.feeNetCents,
            skipBaselineCents: storyStamp.skipBaselineCents,
            skipBaselineSource: storyStamp.skipBaselineSource,
            feeNetVsSkip: storyStamp.feeNetVsSkip,
            officialSettle: storyStamp.officialSettle,
            exitClass: storyStamp.exitClass,
            stampStatus: storyStamp.stampStatus,
            soldEarly: storyStamp.soldEarly,
            heldWrongSide: storyStamp.heldWrongSide,
            holdToSettlement: storyStamp.holdToSettlement,
            chartSnapshot: buildTradeChartSnapshot({
              points: trade.chartPoints,
              entryTs: trade.openedAt,
              exitTs: Date.now(),
              exitReason: storyStamp.exitReason ?? exitReason ?? "SETTLEMENT",
              floorStrike: trade.floorStrike ?? 0,
              signal: trade.signal,
            }),
          });
          // Oracle Mind episodic fee-net memory (paper close) — ring + optional JSONL.
          try {
            const shadow = trade.frozenShadow;
            const conflictsAtEntry: string[] = [];
            if (shadow?.ccVelocityWouldBlock) conflictsAtEntry.push("CC_VEL_AGAINST_SOLE_TAKE");
            if (
              typeof shadow?.mtfScore === "number"
              && shadow.mtfScore > 0
              && typeof shadow?.velocityDolPerMin === "number"
              && shadow.ccVelocityWouldBlock
              && (
                (trade.side === "yes" && shadow.velocityDolPerMin <= -40)
                || (trade.side === "no" && shadow.velocityDolPerMin >= 40)
              )
            ) {
              conflictsAtEntry.push("MTF_BULL_INTO_RED_VEL");
            }
            if (shadow?.regimeWouldBlock === true) conflictsAtEntry.push("REGIME_WOULD_BLOCK_SOLE_TAKE");
            const feeNet =
              typeof storyStamp.feeNetCents === "number" && Number.isFinite(storyStamp.feeNetCents)
                ? Math.round(storyStamp.feeNetCents)
                : Math.round(pnlCents);
            const tradeSide = trade.side === "no" ? "no" : "yes";
            const settledRaw =
              (storyStamp as { officialSettle?: string | null; settledSide?: string | null }).officialSettle
              ?? (storyStamp as { settledSide?: string | null }).settledSide
              ?? null;
            const causal = attributeSettleCausal({
              side: tradeSide,
              settledSide: settledRaw,
              exitReason: exitReason ?? storyStamp.exitReason ?? null,
              pnlCents: feeNet,
            });
            recordBrainEpisode(
              {
                atMs: Date.now(),
                side: tradeSide,
                strategyId: trade.strategyId ?? null,
                conflictsAtEntry,
                feeNetCents: feeNet,
                decisionKind:
                  tradeSide === "no" ? "TAKE_NO" : "TAKE_YES",
                sideCorrect: causal.sideCorrect,
                exitSavedWrongSide: causal.exitSavedWrongSide,
                settledSide: causal.settledSide,
                exitReason: causal.exitReason,
                sidePickerWeight: causal.weightForSidePicker,
                // title auto-filled by nameBrainEpisode inside recordBrainEpisode
              },
              { persist: true },
            );
            // Calibration ledger: p of the FILLED side vs that side's settle hit.
            // PR #14: prefer pFilledSide (p of the side bought), stamp ticker +
            // entry time (gate sampler = one sample per window, first decision),
            // and park EARLY-EXIT fills (no official settle yet) for scoring
            // against the market's real settlement instead of dropping them.
            try {
              const pFilled = trade.pFilledSideAtEntry
                ?? (storyStamp as { pFilledSide?: number | null }).pFilledSide
                ?? null;
              const pCal =
                typeof pFilled === "number" && Number.isFinite(pFilled)
                  ? pFilled
                  : typeof trade.strategyWinRateAtEntry === "number" && Number.isFinite(trade.strategyWinRateAtEntry)
                    ? trade.strategyWinRateAtEntry
                    : null;
              if (pCal != null && causal.sideCorrect != null) {
                recordCalibrationObs({
                  p: pCal,
                  hit: causal.sideCorrect === true,
                  askCents: trade.entryPriceCents,
                  side: tradeSide,
                  source: "fill",
                  ticker: trade.ticker,
                  atMs: typeof trade.openedAt === "number" && Number.isFinite(trade.openedAt) ? trade.openedAt : Date.now(),
                });
              } else if (pCal != null && causal.sideCorrect == null) {
                recordEarlyExitFillForCalibration({
                  ticker: trade.ticker,
                  side: tradeSide,
                  p: pCal,
                  askCents: trade.entryPriceCents,
                  entryAtMs: typeof trade.openedAt === "number" && Number.isFinite(trade.openedAt) ? trade.openedAt : Date.now(),
                  closeMs: typeof trade.closeTimeMs === "number" && Number.isFinite(trade.closeTimeMs) ? trade.closeTimeMs : null,
                  strategyId: trade.strategyId ?? null,
                  exitReason: exitReason ?? storyStamp.exitReason ?? null,
                });
              }
            } catch { /* never block settle on calibration */ }
            // Scar-Echo: tattoo fee-net vs skip + causal (skip≈0).
            try {
              const feeNetVsSkip =
                typeof storyStamp.feeNetVsSkip === "number" && Number.isFinite(storyStamp.feeNetVsSkip)
                  ? Math.round(storyStamp.feeNetVsSkip)
                  : feeNet;
              const tattoo = {
                feeNetVsSkipCents: feeNetVsSkip,
                outcome: (feeNetVsSkip > 0 ? "win" : feeNetVsSkip < 0 ? "loss" : "flat") as
                  "win" | "loss" | "flat",
                sideCorrect: causal.sideCorrect,
                exitSavedWrongSide: causal.exitSavedWrongSide,
                settledSide: causal.settledSide,
                exitReason: causal.exitReason,
                sidePickerWeight: causal.weightForSidePicker,
              };
              if (trade.scarId) {
                const closed = closeScar(trade.scarId, tattoo);
                if (closed) persistScar(closed);
              } else if (trade.paper === true) {
                // Late scar if fill path missed open (rehydrate) — still learn.
                const decisionKindFill = tradeSide === "no" ? "TAKE_NO" : "TAKE_YES";
                const bindBase: ScarEntryBind = {
                  conflicts: conflictsAtEntry,
                  councilResolved: null,
                  horizonPhase: null,
                  diagnosis: null,
                  decisionKind: decisionKindFill,
                  frozenCc: trade.frozenCc === true,
                  strategyId: trade.strategyId ?? null,
                  side: tradeSide,
                  askBand: askBandFromCents(trade.entryPriceCents),
                  askCents: trade.entryPriceCents,
                };
                const honesty = stampScarFillHonesty(bindBase);
                const bind: ScarEntryBind = { ...bindBase, ...honesty };
                const scar = recordScar(bind);
                const closed = closeScar(scar.id, tattoo);
                if (closed) persistScar(closed);
              }
            } catch { /* never block settle on SEL */ }
          } catch { /* never block settle on mind memory */ }
        }
      } catch { /* never block settlement bookkeeping */ }
    }

    const pnlStr  = pnlCents >= 0 ? `+$${(pnlCents / 100).toFixed(2)}` : `-$${(Math.abs(pnlCents) / 100).toFixed(2)}`;
    const streak  = this.consecutiveLosses > 0 ? ` · ${this.consecutiveLosses} loss streak` : "";
    const paper   = trade.paper ? " [PAPER]" : "";
    const paperBal = trade.paper ? ` · bal $${(this.paperVirtualBalanceCents / 100).toFixed(2)} (peak $${(this.peakBalanceCents / 100).toFixed(2)})` : "";
    this.log("settle",
      `${outcome === "win" ? "🏆" : "💸"} ${outcome.toUpperCase()}${paper} · ${pnlStr} · today: $${(this.todayStats.pnlCents / 100).toFixed(2)}${streak}${paperBal}`
    );

    if (this.consecutiveLosses >= 2) {
      this.log("warn", `⚠️ ${this.consecutiveLosses} consecutive losses — raising velocity threshold (cooldown active)`);
    }

    let settlePatchForRetry: Record<string, unknown> | null = null;
    let settleDbWritten = false;
    if (trade.dbId) {
      try {
        const resolvedExitReason = exitReason ?? "SETTLEMENT";
        // Display-only balance snapshot right after this trade resolved.
        // Paper: paperVirtualBalanceCents already reflects the payout/reserve
        // adjustment applied above. Live: best-known accountBalance (updated
        // on its own poll timer) — same number the dashboard shows live, not
        // guaranteed to be this trade's exact isolated effect if another
        // position settled in between, but honest to what the account looked
        // like at that moment.
        const balanceAfterCents = trade.paper
          ? Math.round(this.paperVirtualBalanceCents)
          : (this.accountBalance != null ? Math.round(this.accountBalance) : null);
        const settlePatch: Record<string, unknown> = {
          outcome, pnlCents, pnlDollars: pnlCents / 100, settledAt: new Date(),
          exitReason: resolvedExitReason,
          balanceAfterCents,
          // FEE ORGAN: entry taker fee always (win or loss). Early sell adds
          // SECOND fee at exit. Settlement has no second fee. Recovery path
          // already uses computeBinarySettlementPnl (entry fee always).
          // PARTIAL-FILL: fold prior leg fees so fee-net never drops charged fees.
          feeCents: (() => {
            const entryFee = kalshiTakerFeeCents(trade.entryPriceCents, trade.contracts);
            const binary = !resolvedExitReason || resolvedExitReason === "SETTLEMENT" || resolvedExitReason === "SETTLED_KALSHI";
            let exitFee = 0;
            if (!binary && trade.contracts > 0 && payoutCents > 0) {
              const exitPx = payoutCents / trade.contracts;
              if (exitPx > 0) exitFee = kalshiTakerFeeCents(exitPx, trade.contracts);
            }
            return entryFee + exitFee + partialFeeCents;
          })(),
          exitReasonText: buildExitReasonText(resolvedExitReason, { outcome, maxGainCents: trade.maxGainCents }),
        };
        if (exitBreakdown) {
          settlePatch.exitTheoPrice = Math.round(exitBreakdown.theo);
          settlePatch.exitMktPrice  = Math.round(exitBreakdown.mkt);
        }
        settlePatchForRetry = settlePatch;
        await db.update(botTrades).set(settlePatch).where(eq(botTrades.id, trade.dbId));
        settleDbWritten = true;

        // Deterministic trade story (no OpenRouter). BOT fills only; MANUAL → no
        // jsonl / no learner write. Winning +EV may raise 0.72–1.18 weight.
        // Never cuts EV 3¢ / Kelly 0.60 / 9% / 15% reserve / daily halt.
        try {
          {
            const storyStamp = storyStampFromCloseState({
              side: trade.side,
              fillAsk: trade.entryPriceCents,
              entryPriceCents: trade.entryPriceCents,
              yesAsk: trade.yesAskAtEntry ?? null,
              noAsk: trade.noAskAtEntry ?? null,
              pFilledSide: trade.pFilledSideAtEntry ?? trade.strategyWinRateAtEntry ?? null,
              evCents: (typeof trade.frozenEntryEvCents === "number" && Number.isFinite(trade.frozenEntryEvCents) ? trade.frozenEntryEvCents : null) ?? trade.entryExpectedRewardCents ?? null,
              thesisStatus: trade.exitThesisStatus ?? null,
              ticketGreen: typeof trade.exitTicketGreen === "boolean" ? trade.exitTicketGreen : null,
              holdMs: typeof trade.exitHoldMs === "number" && Number.isFinite(trade.exitHoldMs)
                ? trade.exitHoldMs
                : (Date.now() - trade.openedAt),
              exitReason: resolvedExitReason,
              SESSION_MODE: trade.sessionModeAtEntry ?? this.lastSessionMode ?? null,
              lockSide: trade.lockSideAtEntry ?? null,
              pnlCents,
              feeNetCents: pnlCents,
              outcome,
              officialSettle: officialSettle ?? null,
              settledSide: officialSettle ?? null,
              officialKalshi: officialSettle ?? null,
              btcClose: truthSettleOk ? lastPx : null,
              floorStrike: trade.floorStrike ?? null,
            });
            // Desk/brain: keep latest settle stampStatus visible (incomplete ≠ win).
            this.lastSettleStamp = stampSettleMsg({
              stampStatus: storyStamp.stampStatus,
              feeNetCents: storyStamp.feeNetCents,
              feeNetVsSkip: storyStamp.feeNetVsSkip,
              officialSettle: storyStamp.officialSettle,
            });
            // GG R3#1 fee-net — backfill from settle truth before story write
            persistSettledBotStory({
              fillOrigin: trade.fillOrigin ?? FILL_ORIGIN_BOT,
              strategyId: trade.strategyId,
              side: trade.side,
              signal: trade.signal,
              outcome,
              pnlCents,
              entryPriceCents: trade.entryPriceCents,
              ask: trade.entryPriceCents,
              fillAsk: storyStamp.fillAsk,
              yesAsk: storyStamp.yesAsk,
              noAsk: storyStamp.noAsk,
              pFilledSide: storyStamp.pFilledSide,
              SESSION_MODE: storyStamp.SESSION_MODE,
              lockSide: storyStamp.lockSide,
              confidence: trade.confidence,
              exitReason: resolvedExitReason,
              exitReasonCode: resolvedExitReason,
              ticker: trade.ticker,
              contracts: trade.contracts,
              filledAt: trade.openedAt,
              settledAt: Date.now(),
              expectedPnlCents: (typeof trade.frozenEntryEvCents === "number" && Number.isFinite(trade.frozenEntryEvCents) ? trade.frozenEntryEvCents : null) ?? trade.entryExpectedRewardCents ?? null,
              evCents: storyStamp.evCents ?? (typeof trade.frozenEntryEvCents === "number" && Number.isFinite(trade.frozenEntryEvCents) ? trade.frozenEntryEvCents : null) ?? trade.entryExpectedRewardCents ?? null,
              p: storyStamp.pFilledSide ?? trade.strategyWinRateAtEntry ?? null,
              winRateAtPrice: storyStamp.pFilledSide ?? trade.strategyWinRateAtEntry ?? null,
              mtf: trade.mtfScoreAtEntry ?? null,
              pathRide: trade.pathRide === true,
              thesisStatus: storyStamp.thesisStatus ?? trade.exitThesisStatus ?? null,
              riverValid: typeof trade.exitRiverValid === "boolean" ? trade.exitRiverValid : null,
              river: typeof trade.exitRiverValid === "boolean" ? trade.exitRiverValid : null,
              ticketGreen: storyStamp.ticketGreen,
              ruleFired: trade.exitThesisRuleFired ?? null,
              holdMs: storyStamp.holdMs ?? (Date.now() - trade.openedAt),
              feeNetCents: storyStamp.feeNetCents ?? pnlCents,
              skipBaselineCents: storyStamp.skipBaselineCents,
              feeNetVsSkip: storyStamp.feeNetVsSkip,
              exitClass: storyStamp.exitClass,
              stampStatus: storyStamp.stampStatus,
              soldEarly: storyStamp.soldEarly,
              heldWrongSide: storyStamp.heldWrongSide,
              holdToSettlement: storyStamp.holdToSettlement,
              maxGainCents: trade.maxGainCents ?? null,
              thesisStatusPassedToDecideExit: true,
              contractDurationMins: trade.contractDurationMins,
              winRate: trade.strategyWinRateAtEntry ?? null,
              regime: trade.regimeAtEntry ?? null,
              tradeId: trade.dbId,
              settledSide: storyStamp.officialSettle ?? officialSettle,
              officialKalshi: storyStamp.officialSettle ?? officialSettle,
              btcClose: truthSettleOk ? lastPx : null,
              floorStrike: trade.floorStrike ?? null,
              evaluate: {
                strategyId: trade.strategyId,
                signal: trade.signal,
                confidence: trade.confidence,
                regime: trade.regimeAtEntry ?? null,
                winRate: trade.strategyWinRateAtEntry ?? null,
                expectedEvCents: (typeof trade.frozenEntryEvCents === "number" && Number.isFinite(trade.frozenEntryEvCents) ? trade.frozenEntryEvCents : null) ?? trade.entryExpectedRewardCents ?? null,
              },
            });
          }
        } catch { /* never block settlement bookkeeping */ }

        // FrozenLedger CLOSE — fee-net vs skip baseline (0 = never-took). Measurement only.
        try {
          if (trade.frozenCc === true || trade.strategyId === FROZEN_CC_STRATEGY_ID) {
            const feeNetCents = pnlCents;
            appendFrozenLedgerRow({
              kind: "CLOSE",
              ruleset: FROZEN_CC_RULESET_VERSION,
              gitSha: runningGitSha(),
              ts: Date.now(),
              ticker: trade.ticker,
              strategyId: trade.strategyId ?? FROZEN_CC_STRATEGY_ID,
              side: trade.side,
              askCents: trade.entryPriceCents,
              contracts: trade.contracts,
              exitReason: resolvedExitReason,
              exitPriceCents: null,
              holdMs: Date.now() - trade.openedAt,
              outcome: outcome === "win" ? "win" : "loss",
              pnlCents,
              feeNetCents,
              skipPnlCents: 0,
              feeNetVsSkip: feeNetCents - 0,
              entryFeeCents: 0,
              exitFeeCents: 0,
              // was "YES"/"NO" into a yes/no field → frozen-cc hold-to-settle math (needs yes/no) always null
              settledSide: officialSettle === "YES" ? "yes" : officialSettle === "NO" ? "no" : null,
              holdToSettlePnlCents: null,
              exitVsHoldCents: null,
              shadowExitWouldSell: null,
              shadowExitFirstAtMs: null,
              shadow: trade.frozenShadow ?? emptyShadowFlags(),
            });
            // Sit-WATCH observe: tally soft-sit (ha/regime) CLOSE buckets live.
            // Fire-and-forget — never enable hard sits; never throw into settle.
            try {
              const shadow = trade.frozenShadow ?? emptyShadowFlags();
              const exitCentsLive =
                trade.contracts > 0 && payoutCents > 0
                  ? Math.round(payoutCents / trade.contracts)
                  : null;
              const exitTheoLive =
                exitBreakdown != null && Number.isFinite(exitBreakdown.theo)
                  ? Math.round(exitBreakdown.theo)
                  : null;
              recordShadowSitClose({
                ticker: trade.ticker,
                side: trade.side,
                contracts: trade.contracts,
                entryCents: trade.entryPriceCents,
                exitCents: exitCentsLive,
                pnlCents,
                exitReason: resolvedExitReason,
                holdMs: Date.now() - trade.openedAt,
                shadow,
                ha_disagree: shadow.w2Reason === "ha_disagree",
                regimeWouldBlock: shadow.regimeWouldBlock === true,
                pin_reachable: shadow.w2Reason === "pin_reachable" ? true : null,
                htfWouldBlock: shadow.htfWouldBlock,
                w2Reason: shadow.w2Reason,
                w2Kind: shadow.w2Kind,
                mtfScore: shadow.mtfScore,
                constructedNo: shadow.constructedNo,
                lagProven: shadow.lagProven,
                lagStale: shadow.lagStale,
                entryTheoCents: trade.frozenEntryTheoCents ?? null,
                exitTheoCents: exitTheoLive,
              });
            } catch { /* sit-WATCH observe — never throw into settle */ }
            try { maybeWritePromoteArtifacts(readFrozenLedger()); } catch { /* measurement */ }
          }
        } catch { /* never block settlement bookkeeping */ }

        // GO — VOLUME AS RISK SCALAR (2026-08-18): LIVE-ONLY (recordVolumeBucketSettlement
        // itself no-ops on isPaper=true) learn update for the (strategyId × bucket)
        // cell this trade was entered under. Fire-and-forget — never let a DB hiccup
        // here delay/block settlement bookkeeping; never touches disabledStrategies
        // or EV floors, only its own learnedMult column.
        if (trade.strategyId && trade.volumeBucket) {
          recordVolumeBucketSettlement({
            strategyId: trade.strategyId,
            bucket: trade.volumeBucket,
            isPaper: trade.paper,
            won: outcome === "win",
            pnlCents,
          }).catch((err) => this.log("warn", `[volume-risk] learn hook failed: ${(err as Error).message}`));
        }

        // AI postmortem — a short "what went right/wrong" report, generated
        // once per trade and persisted after the fact. Fire-and-forget: never
        // let a slow/failed AI call delay or block settlement bookkeeping.
        // Generated for EVERY settled trade (authoritative or heuristic) —
        // ARIA's learning loop (expert-agent.ts) reads these back to extract
        // lessons, so a heuristic-only settlement still deserves a narrative
        // even though it's excluded from the stricter strategy-learning
        // win-rate stats above. The report text itself doesn't assert
        // anything about aggregate performance, only what happened in this
        // one trade, so it's honest either way.
        {
          const dbIdForPostmortem = trade.dbId;
          generateTradePostmortem({
            strategyId: trade.strategyId ?? null, signal: trade.signal, side: trade.side,
            ticker: trade.ticker, entryPriceCents: trade.entryPriceCents,
            confidence: trade.confidence ?? null, regime: trade.regimeAtEntry ?? null, outcome, pnlCents,
            contracts: trade.contracts, exitReasonCode: resolvedExitReason,
            timeInTradeSecs: Math.round((Date.now() - trade.openedAt) / 1000),
            winRateEstimate: trade.strategyWinRateAtEntry ?? null,
            mtfScoreAtEntry: trade.mtfScoreAtEntry ?? null,
            mtfBiasAtEntry: trade.mtfBiasAtEntry ?? null,
            ariaSignalAtEntry: trade.ariaSignalAtEntry ?? null,
            ariaConfAdjAtEntry: trade.ariaConfAdjAtEntry ?? null,
          }).then(postmortem => {
            if (postmortem && dbIdForPostmortem != null) {
              db.update(botTrades)
                .set({ postmortem, postmortemGeneratedAt: new Date() })
                .where(eq(botTrades.id, dbIdForPostmortem))
                .catch(() => {});
            }
          }).catch(() => {});
        }
      } catch (err) {
        // This DB write is the ONLY durable record that this trade settled —
        // silently swallowing its failure (as this catch used to do) means a
        // real settlement can vanish with zero operator visibility, left as
        // outcome="pending" forever unless the startup stale-trade sweep
        // later happens to catch it. Log loudly so it's visible in the
        // watchdog/incident tooling even though there's no dedicated
        // "settlement persistence" subsystem to gate auto-start on yet.
        settlePersistFailed = true;
        if (!settleDbWritten && settlePatchForRetry && trade.dbId != null) {
          try {
            enqueueSettlePersistRetry({ dbId: trade.dbId, ticker: trade.ticker, patch: settlePatchForRetry, error: (err as Error).message });
          } catch { /* retry queue is best-effort */ }
        }
        this.log("warn",
          `[settlement] FAILED to persist settlement for trade #${trade.dbId} (${trade.ticker}, ${outcome}, ` +
          `${pnlCents >= 0 ? "+" : ""}${(pnlCents / 100).toFixed(2)}) — DB row remains "pending"; ` +
          (settleDbWritten ? `(settle row was written; a later step threw) ` : `queued for DB retry every ${SETTLE_RETRY_INTERVAL_MS / 1000}s; `) +
          `startup stale-trade sweep is the backstop: ${(err as Error).message}`
        );
      }
    }

    // Fail-closed orphan guard: never clear openTrade when PG pending would remain.
    // Paper never KEEP (CLOSE spam root — settlementFinalized already stamped).
    if (trade.paper !== true && shouldKeepOpenTradeAfterSettlePersistFail({
      hasDbId: trade.dbId != null,
      persistFailed: settlePersistFailed,
    })) {
      this.log("error",
        `[settlement] fail-closed KEEP openTrade #${trade.dbId} ${trade.ticker} — persist failed; refusing openTrade=null orphan`,
      );
      return;
    }

    // Route through setOpenTrade() (not a bare assignment) so
    // positionLastConfirmedAt is reset here too — this settlement path used
    // to leave a stale confirmation timestamp dangling into the next flat/
    // open-trade state, same dangling-state class as the counters below.
    this.setOpenTrade(null);
    this.settlementHoldActive = false;
    this.strikeCrossTicks      = 0;
    // fastReversalTicks/structureFailTicks were previously only cleared when
    // they themselves triggered an exit — a trade that instead closed via
    // settlement left its last velocity-against-position count dangling, so
    // the very first monitoring tick of the NEXT trade could inherit it and
    // fire a spurious FAST_REVERSAL/structure-fail exit within moments of
    // opening, without ever observing two genuinely consecutive bad ticks.
    this.fastReversalTicks     = 0;
    this.structureFailTicks    = 0;
    this.holdModeHardFloorTicks = 0; // same dangling-counter risk as above (Task #303)
    // Task #427 audit (Step 6): thesisVelocityAgainstTicks/basisFlipAgainstTicks
    // (THESIS_BREAK_EXIT rule 1 / LAG_FLIP_EXIT persistence counters, added
    // 2026-08-14) were missed when the dangling-counter fix above landed — same
    // risk: a stale count could satisfy the ≥3-tick persistence gate within a
    // tick or two of the next same-side trade opening instead of requiring
    // genuine fresh confirmation.
    this.thesisVelocityAgainstTicks = 0;
    this.basisFlipAgainstTicks      = 0;
    this.lagFlipBothAgainstSecStreak = 0;
    this.lagFlipLastSampleSec = -1;
    // P5 ARIA GUARDIAN: same dangling-state class as the counters above.
    this.lastAriaGuardianEvalTs     = null;
    this.ariaGuardianTighten        = null;
    // Same dangling-counter class as above: a stale vol-buffer streak from
    // this trade's entry evaluation must not carry into the next entry
    // attempt and get it one tick closer to the ">1" hard-block.
    this.sharedGateStaleStreak      = 0;
    this.state                = "WATCHING";

    if (this.isDailyLossHalted()) {
      this.log("warn", `🛑 Daily loss cap reached — suspending`);
      this.suspend();
    }

    if (!trade.paper) await this.refreshBalance();
  }

  /**
   * Runs every 1 second to keep a fresh pre-trade sim verdict cached.
   * When evaluateEntry() fires, the verdict is almost always already computed —
   * eliminating the multi-DB / Monte-Carlo latency at the moment of entry.
   *
   * HARD RULE: this timer must NEVER call placeOrder. A __bg__-tagged cache
   * is warming only — evaluateEntry must not treat it as a matching-strategy
   * approval (cacheHit requires an exact strategyId, not '__bg__').
   */
  private async backgroundPreTrade(): Promise<void> {
    // Only run when the bot is actively watching
    if (this.state !== 'WATCHING') return;
    // Guard against concurrent executions piling up when runPreTradeSim is slow
    if (this.bgPreTradeRunning) return;
    this.bgPreTradeRunning = true;
    try {
      // Need a recent observation (built every 2 s by tick())
      const obs = this.lastObservation;
      if (!obs || Date.now() - this.lastObsTs > 4_000) return;
      // Warm the 15m cache only. Hourly/perp tickers never belong here
      // (and this method never placeOrder).
      if (!is15mDeskEvaluateAllowed({
        ticker: obs.ticker,
        enable1HContracts: this.config.enable1HContracts,
        enable1HLive: this.config.enable1HLive,
      }).ok) return;

      // Determine the most likely trade direction:
      //  1. Use the last strategy signal if it's recent
      //  2. Fall back to velocity direction
      let direction: 'LONG' | 'SHORT';
      let strategyId: string;

      if (this.lastStrategyResult) {
        direction  = this.lastStrategyResult.signal === 'YES' ? 'LONG' : 'SHORT';
        strategyId = this.lastStrategyResult.strategyId;
      } else {
        if (Math.abs(obs.velocityDolPerMin) < 20) return;   // no clear direction
        direction  = obs.velocityDolPerMin > 0 ? 'LONG' : 'SHORT';
        strategyId = '__bg__';
      }

      const secs = obs.secsRemaining;

      // ── Buffer staleness guard (pre-trade sim) ─────────────────────────────────
      // If vol data is stale, skip caching a verdict — runPreTradeSim internally
      // calls realizedVol(priceBuffer) and would derive a misleading Monte-Carlo
      // estimate. evaluateEntry() will detect staleness independently and apply
      // its own conservative fallback, so no warn log is needed here.
      const bgLastTickAgeMs = this.prices.length > 0
        ? Date.now() - this.prices[this.prices.length - 1].ts
        : Infinity;
      if (bgLastTickAgeMs > 30_000) return;

      const backgroundEntryPrice = direction === 'LONG' ? obs.yesAsk : obs.noAsk;
      const verdict = await runPreTradeSim({
        obs, direction, priceBuffer: this.prices, secsRemaining: secs,
        entryPriceCents: backgroundEntryPrice,
        // CONSENSUS MEASUREMENT PURITY (2026-08-16): disabled strategies must
        // not affect consensus — reuse the 15m main path's own effective
        // disabled set (cached the instant evaluateEntry() computes it), not
        // a second/narrower one invented for this background warming loop.
        disabledIds: this.lastEffectiveDisabledSet,
      });
      // Stamp the quoteTs the verdict was simulated against so evaluateEntry()
      // can prove the cached verdict is not older than the quote it decides on.
      const bgQuoteTs = kalshiWS.getLatest()?.quoteTs ?? 0;
      // cachedVerdict is this function's real purpose (warm the sim result so
      // evaluateEntry() can skip the multi-DB/Monte-Carlo latency at decision
      // time) and is ALWAYS refreshed regardless of the precedence check below.
      // Tag it background-only so it can never be mistaken for a real per-tick
      // decision until evaluateEntry() itself promotes it (see the cacheHit
      // branch, which explicitly clears this flag). Root cause of "trade
      // approved but nothing happened" (2026-08-26): a STAY_OUT tick returns
      // early and never touches lastRealVerdictDirection/Ts, so the old
      // 1.5s precedence window alone let this loop's un-gated verdict overwrite
      // the dashboard field indefinitely during any STAY_OUT stretch.
      verdict.backgroundOnly = true;
      this.cachedVerdict = { verdict, direction, strategyId, ts: Date.now(), quoteTs: bgQuoteTs };

      // Task #402 (root cause, not just the blockedAfterApproval symptom):
      // this loop and tick()'s real evaluateEntry() are two independent
      // 500ms timers that both used to write lastPreTradeVerdict (the
      // dashboard-facing field) with no ordering guarantee — any field added
      // to the verdict could flicker or get silently erased depending on
      // which timer happened to run last. Give the real pipeline a short
      // precedence window instead of re-stamping one field: if evaluateEntry()
      // itself decided on this exact direction very recently, this loop's
      // independently-recomputed (and downstream-gate-unaware) verdict does
      // NOT overwrite the dashboard field this cycle — the real, fully
      // authoritative verdict (including any post-approval block) stays
      // displayed until the real pipeline itself supersedes it or the window
      // (1.5s — one missed tick's worth of jitter) lapses.
      const realVerdictIsFresher =
        this.lastRealVerdictDirection === direction &&
        Date.now() - this.lastRealVerdictTs < 1_500;
      if (!realVerdictIsFresher) {
        this.lastPreTradeVerdict = verdict;   // keeps getStatus() panel fresh
      }

      // Learning loop: persist background verdicts too — rejected/background
      // simulations are central to scoring simulator decisions. Deduped inside
      // on (period, ticker, direction, approved, 60s slot).
      predictionLearner.persistVerdict(verdict, {
        ticker: kalshiWS.getLatest()?.ticker,
        btcPrice: obs.currentPrice,
        floorStrike: obs.floorStrike,
        secsRemaining: secs,
        strategyId,
      });
    } catch {
      // Silent — evaluateEntry() will run its own inline call as fallback
    } finally {
      this.bgPreTradeRunning = false;
    }
  }

  private suspend() {
    // Must mirror stop()'s full teardown. Previously only tickTimer was
    // cleared — balanceTimer (15s) and pretradeTimer (500ms) kept running
    // in the background. A resume via start() (e.g. after a daily-loss-cap
    // suspend) then registered a SECOND balanceTimer and pretradeTimer on
    // top of the still-running originals, giving two concurrent balance
    // refreshers and two concurrent pre-trade sim loops racing on shared
    // state (accountBalance, cachedVerdict, bgPreTradeRunning) with no
    // synchronization between the old and new intervals.
    if (this.tickTimer)     clearInterval(this.tickTimer);
    if (this.balanceTimer)  clearInterval(this.balanceTimer);
    if (this.pretradeTimer) clearInterval(this.pretradeTimer);
    if (this._unsubQuoteWake) { this._unsubQuoteWake(); this._unsubQuoteWake = null; }
    if (this._coalesceTimer)  { clearTimeout(this._coalesceTimer); this._coalesceTimer = null; }
    this.tickTimer      = null;
    this.balanceTimer   = null;
    this.pretradeTimer  = null;
    this.config.enabled = false;
    this.state          = "SUSPENDED";
    this.reportUptime("suspend");

    // Tasks #165/#166: suspend() used to leave the bot with NO balance
    // polling and NO auth probing at all — the tick-driven auth-recovery
    // check lives in _tickBody(), which only runs while tickTimer is active.
    // A user who fixed their credentials (or waited out a rotation) while
    // the bot sat SUSPENDED (e.g. daily-loss-cap trip) would see the auth
    // failure banner "stuck" until the bot was manually restarted, even
    // though nothing else was actually still broken. ensureIdleBalancePolling()
    // resumes the independent 15s live-balance timer, whose refresh body
    // already clears authFailed on the first successful fetch — the same
    // recovery path idle/never-started bots already rely on.
    if (this.accountPositionReconcileTimer) {
      clearInterval(this.accountPositionReconcileTimer);
      this.accountPositionReconcileTimer = null;
    }
    this.ensureIdleBalancePolling();
  }

  /** Cheap auth probe — called at bot start in live mode.
   *  Sets authFailed immediately if signing fails or the API rejects credentials. */
  private async probeAuth(): Promise<void> {
    // Note: this file's local kalshiAuthHeaders() (unlike the shared
    // kalshi-auth.ts one used by routes/kalshi.ts) already wraps signing in
    // its own try/catch and returns {} on failure, so it's safe to call bare
    // here — the !headers["KALSHI-ACCESS-KEY"] check below is what actually
    // detects both "no key configured" and "signing failed" cases.
    const apiPath = KALSHI_PATH_PORTFOLIO_BALANCE;
    const headers = await kalshiAuthHeaders("GET", apiPath);
    if (!headers["KALSHI-ACCESS-KEY"]) {
      this.authFailed = true;
      this.authFailedReason = "signing";
      this.log("warn", "⚠️ Auth signing failed at start — live orders will be blocked. Check your oraclekey secret.");
      return;
    }
    try {
      const r = await fetch(`${KALSHI_API_DOMAIN}${apiPath}`, {
        headers: { ...headers, Accept: "application/json" },
        signal: AbortSignal.timeout(5_000),
      });
      if (r.status === 401 || r.status === 403) {
        this.authFailed = true;
        this.authFailedReason = "server";
        this.log("warn", `⚠️ Auth probe rejected by Kalshi (HTTP ${r.status}) — live orders will be blocked. Check your oracle and oraclekey secrets.`);
        return;
      }
      const data = (await r.json().catch(() => ({}))) as { balance?: number };
      if (data.balance != null) {
        const next = applyKalshiBalancePoll({
          paperMode: this.config.paperMode,
          paperVirtualCents: this.paperVirtualBalanceCents,
          peakCents: this.peakBalanceCents,
          kalshiBalanceCents: data.balance,
        });
        this.accountBalance = next.kalshiCashCents;
        this.peakBalanceCents = next.peakCents;
        // paperVirtualBalanceCents is intentionally NOT assigned from Kalshi cash
      }
      if (this.authFailed) {
        this.authFailed = false;
        this.authFailedReason = null;
        this.log("info", "✅ Auth probe passed — credentials are valid.");
      } else {
        this.log("info", "✅ Auth probe passed — credentials valid, live trading enabled.");
      }
    } catch (err) {
      // Network error — don't flag authFailed (transient), just log
      this.log("warn", `⚠️ Auth probe could not reach Kalshi: ${(err as Error).message}. Will retry on first order.`);
    }
  }

  private async refreshBalance(): Promise<void> {
    // Paper still polls Kalshi cash (shown separately). Must not write paperVirtual.
    if (this.balanceRefreshing) return;  // previous call still in flight — skip, don't stack
    this.balanceRefreshing = true;
    try {
      await this._refreshBalanceBody();
    } finally {
      this.balanceRefreshing = false;
    }
  }

  /**
   * Keep live balance fresh even while the bot is OFF/idle.
   *
   * Bug (found 2026-08-04): the 15s balance-refresh timer only ever started
   * inside start()/suspend()-resume, so a bot left disabled (config.enabled:
   * false — e.g. the user just hasn't turned it on this session) NEVER called
   * refreshBalance() at all. accountBalance stayed null forever, so
   * isBalanceStale() was permanently true, and the health panel showed a
   * never-clearing "Live balance unknown — new orders blocked" incident for
   * hours — even though the bot wasn't running and no order was ever
   * attempted. The warning was true in the most literal sense but useless:
   * it never reflected an actual failure, just "nobody has asked yet."
   *
   * Fix: poll balance on this independent timer whenever we're in live mode,
   * regardless of whether the bot is actively trading. It backs off while the
   * tick-driven balanceTimer is already running (bot started) to avoid a
   * redundant concurrent poll at the same cadence.
   */
  ensureIdleBalancePolling() {
    if (this.idleBalanceTimer) return; // already running
    this.idleBalanceTimer = setInterval(() => {
      if (!this.balanceTimer) void this.refreshBalance();
    }, 15_000);
    void this.refreshBalance();
  }

  /** A failed refresh schedules exactly one fast retry so an outage doesn't have to wait
   *  out the full 15s poll cadence — bounded to one extra attempt per failure, since a
   *  continuing outage will just re-arm this same retry from the next failed attempt. */
  private scheduleBalanceFastRetry() {
    if (this.balanceRetryTimer) return;
    this.balanceRetryTimer = setTimeout(() => {
      this.balanceRetryTimer = null;
      void this.refreshBalance();
    }, 5_000);
  }

  private async _refreshBalanceBody(): Promise<void> {
    const apiPath = KALSHI_PATH_PORTFOLIO_BALANCE;
    try {
      const headers = await kalshiAuthHeaders("GET", apiPath);
      if (!headers["KALSHI-ACCESS-KEY"]) {
        // Signing failed locally — flag auth and bail
        if (!this.authFailed) {
          this.authFailed = true;
          this.authFailedReason = "signing";
          this.log("warn", "⚠️ Balance refresh: auth signing failed — live orders will be blocked. Check your oraclekey secret.");
        }
        this.balanceFetchFailures++;
        this.lastBalanceError = "Auth signing failed";
        return;
      }
      const r = await fetch(`${KALSHI_API_DOMAIN}${apiPath}`, {
        headers: { ...headers, Accept: "application/json" },
        signal: AbortSignal.timeout(5_000),
      });
      if (r.status === 401 || r.status === 403) {
        if (!this.authFailed) {
          this.authFailed = true;
          this.authFailedReason = "server";
          this.log("warn", `⚠️ Balance refresh rejected by Kalshi (HTTP ${r.status}) — live orders will be blocked. Check your oracle and oraclekey secrets.`);
        }
        this.balanceFetchFailures++;
        this.lastBalanceError = `Kalshi rejected request (HTTP ${r.status})`;
        return;
      }
      if (!r.ok) {
        this.balanceFetchFailures++;
        this.lastBalanceError = `Kalshi returned HTTP ${r.status}`;
        this.scheduleBalanceFastRetry();
        return;
      }
      const data = (await r.json()) as { balance?: number };
      if (data.balance != null) {
        const next = applyKalshiBalancePoll({
          paperMode: this.config.paperMode,
          paperVirtualCents: this.paperVirtualBalanceCents,
          peakCents: this.peakBalanceCents,
          kalshiBalanceCents: data.balance,
        });
        this.accountBalance   = next.kalshiCashCents;
        this.balanceUpdatedAt = Date.now();
        this.balanceFetchFailures = 0;
        this.lastBalanceError = null;
        this.peakBalanceCents = next.peakCents;
        // paperVirtualBalanceCents is intentionally NOT assigned from Kalshi cash
      } else {
        // 200 OK but no balance field — still a failure to learn the real number.
        this.balanceFetchFailures++;
        this.lastBalanceError = "Kalshi response missing balance field";
        this.scheduleBalanceFastRetry();
      }
      // Successful balance fetch — clear any stale auth failure
      if (this.authFailed) {
        this.authFailed = false;
        this.authFailedReason = null;
        this.log("info", "✅ Balance refresh succeeded — auth failure cleared, live trading re-enabled.");
      }
    } catch (err) {
      this.balanceFetchFailures++;
      this.lastBalanceError = `Network error: ${(err as Error).message}`;
      this.scheduleBalanceFastRetry();
    }
  }

  /**
   * Keeps a definitive Kalshi order rejection on BotStatus just long enough
   * for the SSE/status poll cadence to reach every dashboard consumer. Without
   * this grace window, a quick successful retry can clear the only UI signal
   * before it is ever rendered.
   */
  private publishOrderRejection(ticker: string, side: string, reason: string): void {
    const rejection = { ts: Date.now(), ticker, side, reason };
    this.lastOrderRejection = rejection;
    const clearTimer = setTimeout(() => {
      if (this.lastOrderRejection?.ts === rejection.ts) this.lastOrderRejection = null;
    }, 6_000);
    clearTimer.unref?.();
  }

  private log(level: BotLogEvent["level"], message: string) {
    const e: BotLogEvent = { ts: Date.now(), level, message };
    // Isolate each listener: log() is called from deep inside the tick loop,
    // so a listener that throws synchronously (e.g. a buggy SSE/UI subscriber)
    // must not propagate out and abort whatever async operation is currently
    // mid-flight in the caller.
    for (const fn of this.listeners) {
      try { fn(e); } catch (err) {
        console.error("[bot] log listener threw:", (err as Error).message);
      }
    }
    // Persist so history survives SSE reconnects, page reloads, and process
    // restarts — previously this was live-broadcast-only and the panel
    // showed up blank on every reconnect (Task: "live log needs full history").
    try { appendLog(e); } catch (err) {
      console.error("[bot] failed to persist log entry:", (err as Error).message);
    }
    console.info(`[bot] [${level}] ${message}`);
  }

  /** Recent log history (oldest first) — used to backfill a freshly-opened SSE stream. */
  getRecentLogs(limit?: number): BotLogEvent[] {
    return getRecentLogs(limit);
  }
}

export const tradingBot = new TradingBot();

const IS_UNIT_TEST_RUNTIME = process.env.NODE_TEST_CONTEXT !== undefined;
const CONFIG_SCHEMA_VERSION = 3;

/** Recovery-sweep tuning — exported so tests can assert against the same constants. */
import {
  STALE_TRADE_SETTLEMENT_BUFFER_MS,
  STALE_TRADE_DEFAULT_DURATION_MINS,
  resolvePaperStartupKalshiVsLocal,
  paperStartupRecoveryMayUseLocalPeriod,
  paperLocalSettlementFromPeriod,
  lookupPaperLocalSettlementResult,
  isTradeStaleEnoughToRecover
} from "./stale-trade-recovery.js";
export {
  STALE_TRADE_SETTLEMENT_BUFFER_MS,
  STALE_TRADE_DEFAULT_DURATION_MINS,
  resolvePaperStartupKalshiVsLocal,
  paperStartupRecoveryMayUseLocalPeriod,
  paperLocalSettlementFromPeriod,
  lookupPaperLocalSettlementResult,
  isTradeStaleEnoughToRecover
} from "./stale-trade-recovery.js";

// ── Restore persisted config on server startup ────────────────────────────────
// Applies any previously-saved config (paperMode, enabled, etc.) and auto-starts
// the bot if it was running when the server last shut down. This intentionally
// does not run when node:test imports the module.
if (!IS_UNIT_TEST_RUNTIME) {
  // Hydrate the in-memory log ring buffer from disk so the Live Log panel has
  // real history to show immediately on the first SSE connection after restart.
  loadPersistedLogs();

  // Close any open ON segment left by a crash, then mark this process start.
  try {
    botUptimeLog.onProcessBoot({
      state: tradingBot.state,
      enabled: tradingBot.config.enabled === true,
      paperMode: tradingBot.config.paperMode === true,
    });
  } catch (err) {
    console.error("[bot] uptime boot log failed:", (err as Error).message);
  }

  // The execution-quality card is visible while the bot is stopped too, so do
  // not defer this load until start()/the first enabled tick.
  void tradingBot.hydrateSessionFillStats().catch((err) =>
    console.warn(`[bot] Daily fill stats hydration failed: ${(err as Error).message}`),
  );

  const saved = loadPersistedConfig();
  if (Object.keys(saved).length > 0) {
    const savedVersion = saved.configSchemaVersion ?? 1;
    const migratedOverrides: Partial<BotConfig> = {};
    if (savedVersion < 2) {
      migratedOverrides.usePortfolioRisk = true;
    }
    if (savedVersion < 3) {
      migratedOverrides.minRewardRiskRatio = MIN_REWARD_RISK_RATIO;
    }

    // Apply saved config without triggering a redundant save.
    // All BotConfig fields — including disabledStrategies — are restored via
    // the spread.  Forced overrides: enabled:false (so the bot doesn't
    // auto-start until we've checked the saved.enabled flag below) and any
    // versioned migration values, which must win over the stale saved value.
    tradingBot.config = {
      ...tradingBot.config,
      ...saved,
      ...migratedOverrides,
      configSchemaVersion: CONFIG_SCHEMA_VERSION,
      enabled: false,
    };
    // P0: disk .bot-config frozenCcMode wins over constructor default false.
    tradingBot.config = mergeDiskFrozenCcMode(tradingBot.config, saved);
    tradingBot.config.minRewardRiskRatio = Math.max(
      MIN_REWARD_RISK_RATIO,
      Number.isFinite(tradingBot.config.minRewardRiskRatio)
        ? tradingBot.config.minRewardRiskRatio
        : MIN_REWARD_RISK_RATIO,
    );
    const bootLock = applyComposerLocks(tradingBot.config, {
      openRouterKey: process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY ?? "",
    });
    tradingBot.config = bootLock.config;
    // Re-assert after composer/frozen locks — disk true must survive bounce.
    if (saved.frozenCcMode === true) {
      tradingBot.config.frozenCcMode = true;
    }
    // Phase C: AND sit armed on disk must survive bounce (not OR; not default false).
    if ((saved as { frozenCcAndSit?: boolean }).frozenCcAndSit === true) {
      tradingBot.config.frozenCcAndSit = true;
    }
    for (const note of bootLock.notes) {
      console.warn(`[bot] LOCK: ${note}`);
    }
    const disabledCount = tradingBot.config.disabledStrategies.length;
    console.info(
      `[bot] Restored persisted config` +
      (disabledCount > 0
        ? ` (${disabledCount} disabled strateg${disabledCount === 1 ? "y" : "ies"}: ${tradingBot.config.disabledStrategies.join(", ")})`
        : "")
    );
    if (savedVersion < CONFIG_SCHEMA_VERSION) {
      console.info(
        `[bot] Migrated persisted config v${savedVersion} → v${CONFIG_SCHEMA_VERSION}: ` +
        `applied current risk-control defaults`
      );
      savePersistedConfig(tradingBot.config);
    }
  }

  // CONFIG_GUARD (Phase 1, 2026-08-15): boot check + hourly re-check. Must run
  // AFTER the restore-from-disk above — that block assigns `tradingBot.config`
  // directly (not via updateConfig()) specifically so restoring on startup
  // doesn't count as a "real" config change, which means it's also exactly
  // the kind of write CONFIG_GUARD's drift check would otherwise misfire on
  // if lastGoodManual had already been seeded from the hardcoded class-field
  // defaults. Running the first check here — after the real persisted values
  // are in place — means lastGoodManual's very first snapshot is the actual
  // restored config, not a default the process never really ran with.
  // Wired only on the live singleton (not per-instance in the class itself)
  // so unit tests that construct their own `new TradingBot()` don't pick up
  // a background timer. Runs independent of start()/enabled — see
  // runConfigGuard() for why a stopped bot still needs this.
  tradingBot.runConfigGuard();
  setInterval(() => tradingBot.runConfigGuard(), 60 * 60 * 1000);
  // Shadow calibration resolver — blocked-take shadows → mind calibration on
  // settle. Public market read only; never orders, balance or trades.
  setInterval(() => {
    void sweepShadowCalibration({ log: (m) => console.log(`[bot] ${m}`) }).catch(() => { /* retry */ });
  }, 60_000).unref?.();

  // `openTrade` (which carries the dbId of any in-flight trade) is in-memory
  // only and is never persisted, unlike config. If the process restarts while
  // a trade is open, that bot_trades row is orphaned at outcome="pending"
  // forever — nothing in the new process knows it exists, so it never gets
  // settled (2026-08-06 incident: a paper trade opened right as the process
  // restarted stayed "pending" in the UI indefinitely). Sweep for these once
  // per startup and resolve them from the recorded period settlement.
  //
  // For LIVE mode specifically, openTrade=null after a restart also means the
  // bot has zero visibility into whatever Kalshi itself thinks the account
  // holds — a crash mid-trade (or any position opened outside the bot's own
  // order flow) leaves a real, financially-live position with nobody
  // managing stops/exits. Auto-start must not resume blind order-taking until
  // that's been checked. Both sweeps run before the auto-start decision so a
  // detected live position can veto it.
  (async () => {
    await recoverStalePendingTrades().catch(err =>
      console.warn(`[bot] Stale pending-trade recovery failed: ${(err as Error).message}`));
    // Task #604: still-live (too-young) pending rows are not recovered above.
    // Hold new entries so restart cannot open a second position.
    await tradingBot.adoptRestartPendingGuard().catch(err =>
      console.warn(`[bot] Restart pending-exposure guard failed: ${(err as Error).message}`));

    let blockAutoStart = false;
    if (!tradingBot.config.paperMode) {
      blockAutoStart = await tradingBot.checkForUnmanagedLivePositions();
    } else {
      // Bug fix: checkForUnmanagedLivePositions() is the ONLY place that ever
      // calls incidentStore.exitDegraded("position") — and the branch above
      // skips it entirely while paperMode=true. If the incident was raised
      // during an earlier live-mode run and the operator then switched to
      // paperMode (a common troubleshooting step), it had no path back to
      // healthy: neither further restarts nor reset_paper_sim (which only
      // resets the paper P&L simulator, not incidentStore) could ever clear
      // it — it would show "position unmanaged" forever. Re-run the same
      // real Kalshi-ground-truth check here too, but ONLY when an incident
      // is already open, so a clean paper-only setup (e.g. no live
      // credentials configured) never gets a *new* false incident from this
      // branch. `incidentStore.init()` is idempotent (no-ops if already
      // initialised) — awaiting it first guarantees the in-memory map is
      // loaded from the DB before we read it, regardless of how this
      // module-import-time IIFE races against index.ts's own init() call.
      await incidentStore.init();
      if (shouldRecheckPositionIncidentInPaperMode(true, incidentStore.getDegradedSince("position") !== null)) {
        await tradingBot.checkForUnmanagedLivePositions();
      }
    }

    const autoStartDecision = evaluateAutoStartDecision(!!saved.enabled, blockAutoStart);
    if (autoStartDecision.shouldStart) {
      console.info("[bot] Auto-starting (was running before restart)");
      // Small delay so the WS connection can establish first
      setTimeout(() => tradingBot.start(), 3_000);
    } else {
      if (autoStartDecision.didNotResume) {
        // Task #376: the bot WAS running before this restart but is not
        // resuming — surface this loudly instead of silently going idle.
        // checkForUnmanagedLivePositions() already logged + raised a
        // "position" incident for the underlying cause; this flag is the
        // dashboard-facing "your bot did not come back on its own" signal,
        // scoped separately so it's visible even after that incident clears.
        tradingBot.didNotResumeAfterRestart = true;
        tradingBot.didNotResumeReason =
          "An unmanaged live position was detected at startup — auto-start was blocked for manual review.";
        console.warn(
          `[bot] ⚠️ Bot was running before this restart but did NOT resume — ${tradingBot.didNotResumeReason}`);
      }
      // Paper and live: keep Kalshi cash fresh (paper virtual is never overwritten).
      tradingBot.ensureIdleBalancePolling();
    }
  })();
}

/**
 * One-shot startup sweep: finds bot_trades rows still marked "pending" from a
 * previous process, old enough per their OWN contract duration that they must
 * have already settled, and resolves them against the authoritative
 * btc_periods settlement record, using the same win/loss formula as the live
 * paper-settlement path. If no matching period can be found, marks the row
 * "unresolved" rather than leaving it "pending" forever — a real state was
 * reached and is retrievable from Kalshi order history even if this
 * bookkeeping guess can't confirm it.
 *
 * Deliberate design, not an oversight — see
 * docs/startup-reconciliation-deliberate-design-2026-08-12.md before
 * changing the unresolved-fallback branches or the shared settlement
 * primitives this uses.
 *
 * Task #443: also re-attempts rows already marked "unresolved" by a PRIOR
 * run of this same sweep. "Unresolved" means "we couldn't match a settled
 * period at the time" — it is not a terminal state. btc_periods settlement
 * data can arrive late (e.g. the settlement poller itself was down at that
 * moment), so a row parked as unresolved minutes/hours ago may well be
 * resolvable now. Never re-touches "win"/"loss" rows — those are already
 * authoritative and finance-affecting; only "pending" and "unresolved" are
 * still-open bookkeeping states.
 */
async function recoverStalePendingTrades() {
  const now = Date.now();
  // Cheap DB-side floor: nothing younger than the shortest possible window
  // (default duration + buffer) can be stale yet, so no need to fetch it.
  // The real per-trade duration check still runs in JS below via
  // isTradeStaleEnoughToRecover — this is just an optimization to avoid
  // fetching obviously-too-young rows.
  const minCutoff = new Date(now - (STALE_TRADE_DEFAULT_DURATION_MINS * 60 * 1000 + STALE_TRADE_SETTLEMENT_BUFFER_MS));
  const candidates = await db.select().from(botTrades)
    .where(and(
      or(eq(botTrades.outcome, "pending"), eq(botTrades.outcome, "unresolved")),
      lt(botTrades.createdAt, minCutoff),
    ));
  const stale = candidates.filter(trade => isTradeStaleEnoughToRecover(trade, now));
  if (stale.length === 0) return;

  const pendingCount = stale.filter(t => t.outcome === "pending").length;
  const unresolvedCount = stale.length - pendingCount;
  console.warn(`[bot] Found ${pendingCount} orphaned pending + ${unresolvedCount} previously-unresolved trade(s) — recovering…`);

  // Ground-truth-first settlement lookup (2026-08-16 ops-integrity fix).
  // This used to score every trade purely off the local btc_periods table.
  // That table is populated/corrected by periodRecorder.start()'s own async
  // backfill(), which runs unawaited and with no ordering guarantee relative
  // to this sweep — both fire independently at process boot. A trade caught
  // by a restart could get scored against incomplete/pre-correction local
  // data and receive a wrong, irreversible verdict (confirmed: trade #2831,
  // KXBTC15M-26AUG161200-00, was recorded LOSS via this path while Kalshi's
  // own settlement — and the local table itself, once backfill finished a
  // moment later — both show it was a WIN). Fix: ask Kalshi directly for this
  // exact ticker's settlement result first, the same ground truth
  // periodRecorder's own backfill relies on, and only fall back to the local
  // table if Kalshi can't be reached. Settlements are fetched once per
  // distinct series for the whole sweep, not per-trade, to avoid hammering
  // Kalshi when several trades are stale at once.
  const settlementsBySeries = new Map<string, Awaited<ReturnType<typeof fetchKalshiSettlements>>>();
  // Returns the matched settlement's result AND its real settle timestamp
  // (KalshiSettlement.ts — settle_time, falling back to close_time), not
  // just the win/loss result. Recovering a trade used to stamp settledAt as
  // `new Date()` — whenever the recovery sweep happened to run, which can be
  // tens of minutes after the contract actually settled — producing an
  // impossible "time in trade" on the dashboard (confirmed: trade #2831
  // showed 59m20s in a 15-minute contract). Using Kalshi's own settle
  // timestamp fixes this at the source for every future recovery.
  async function lookupDirectResult(ticker: string): Promise<{ result: "yes" | "no"; ts: number } | null> {
    const series = ticker.split("-")[0];
    if (!series) return null;
    if (!settlementsBySeries.has(series)) {
      try {
        settlementsBySeries.set(series, await fetchKalshiSettlements(400, series, true));
      } catch (err) {
        console.warn(`[bot] Direct Kalshi settlement fetch failed for series ${series}: ${(err as Error).message}`);
        settlementsBySeries.set(series, []);
      }
    }
    const match = settlementsBySeries.get(series)!.find(s => s.ticker === ticker);
    return match && (match.result === "yes" || match.result === "no") ? { result: match.result, ts: match.ts } : null;
  }

  for (const trade of stale) {
    try {
      // SEV0 (#727): paper tape PATH_RIDE_* / early-exit close already booked
      // virt + paperStats. Prefer that outcome+pnl+exitReason — never re-score
      // via Kalshi STARTUP_RECOVERY binary wipe (wrong result=no → LOSS -1355¢).
      // Runs BEFORE floorStrike gate so a tape close still repairs orphans
      // missing floorStrike.
      if (trade.isPaper === true) {
        const tapeClose = lookupPaperTapeCloseForRecovery(loadPaperTrades(), {
          ticker: trade.ticker,
          side: trade.side,
          contracts: trade.contracts,
          entryPriceCents: trade.entryPriceCents,
        });
        if (tapeClose) {
          const settledAt = tapeClose.settledAtMs != null
            ? new Date(tapeClose.settledAtMs)
            : new Date();
          let settleFee = trade.feeCents ?? 0;
          if (
            tapeClose.exitPriceCents != null
            && tapeClose.entryPriceCents != null
            && tapeClose.contracts != null
          ) {
            const ee = computeEarlyExitFeeNetPnl(
              tapeClose.contracts,
              tapeClose.entryPriceCents,
              tapeClose.exitPriceCents,
            );
            settleFee = Math.round(ee.entryFeeCents + ee.exitFeeCents);
          }
          const won = tapeClose.outcome === "win";
          const pnlCents = tapeClose.pnlCents;
          const currentBalanceCents = tradingBot.getStatus().paperVirtualBalanceCents;
          const balanceAfterCents = computeGuardedBalanceAfterCents({
            currentBalanceCents,
            balanceBeforeCents: trade.balanceBeforeCents,
            closedContracts: tapeClose.contracts ?? trade.contracts,
            entryPriceCents: tapeClose.entryPriceCents ?? trade.entryPriceCents,
          });
          await db.update(botTrades).set({
            outcome: tapeClose.outcome,
            pnlCents,
            pnlDollars: pnlCents / 100,
            settledAt,
            exitReason: tapeClose.exitReason,
            feeCents: settleFee,
            balanceAfterCents,
          }).where(eq(botTrades.id, trade.id));
          console.warn(
            `[bot] Recovered paper trade #${trade.id} (${trade.ticker}) from paper-trades.jsonl ` +
            `${tapeClose.exitReason}: ${won ? "WIN" : "LOSS"} ${pnlCents >= 0 ? "+" : ""}${pnlCents}¢ ` +
            `(tape close beats Kalshi STARTUP_RECOVERY wipe)`
          );
          void persistDecisionTraceEvent({
            eventType: "RECON", ticker: trade.ticker, side: trade.side as "yes" | "no",
            strategyId: trade.strategyId ?? undefined,
            exit: {
              reasonCode: tapeClose.exitReason,
              pnlCents,
              outcome: tapeClose.outcome,
              authoritative: true,
            },
            chain: [tapeClose.exitReason, "PAPER_TAPE_CLOSE"],
          });
          if (trade.strategyId) {
            await feedLearningPipelines(
              trade.strategyId, won, pnlCents, trade.contractDurationMins,
              msg => console.warn(`[bot] ${msg}`), trade.id, trade.isPaper,
              startupRecoveryLearningExitReason(tapeClose.exitReason),
              trade.fillOrigin,
            );
          }
          continue;
        }
      }

      if (trade.floorStrike == null) {
        await markTradeUnresolved(trade.id, "STARTUP_RECOVERY_UNRESOLVED",
          "Recovered at startup from a previous process's orphaned pending trade — no floorStrike was recorded on this row, so no settlement period could be matched.");
        console.warn(`[bot] Trade #${trade.id} (${trade.ticker}) has no floorStrike on record — marked unresolved`);
        continue;
      }

      // let (not const): paperLocal / Kalshi-vs-local preference may reassign.
      let directResult = await lookupDirectResult(trade.ticker);

      // Fail-closed fix (startup-recovery-settlement-race): this used to fall
      // back to the local btc_periods mirror whenever directResult was null —
      // but that null is indistinguishable from "Kalshi's settlement API was
      // transiently unreachable at boot" vs. "genuinely no match". A transient
      // failure could silently score an orphaned trade off a stale/incomplete
      // local row, permanently feeding P&L and strategy learning with a
      // number that was never actually confirmed. No direct exact-ticker
      // settlement now always means unresolved/retry — never a local
      // fallback — exactly like the no-floorStrike and fill-verification
      // branches elsewhere in this function.
      //
      // SEV0 (#727) paper-only: if Kalshi exists but local period disagrees
      // on yes/no, prefer paperLocal — never stamp a wipe that contradicts
      // local settle YES for paper.
      if (trade.isPaper === true) {
        const paperLocal = await lookupPaperLocalSettlementResult(trade);
        const pref = resolvePaperStartupKalshiVsLocal(directResult, paperLocal);
        if (pref.kind === "use") {
          if (directResult != null && pref.source === "paperLocal" && paperLocal
              && directResult.result !== paperLocal.result) {
            console.warn(
              `[bot] Paper trade #${trade.id} (${trade.ticker}) — Kalshi result=${directResult.result} ` +
              `disagrees with local period result=${paperLocal.result}; preferring paperLocal (no contradicting wipe)`
            );
          } else if (directResult == null && pref.source === "paperLocal") {
            console.warn(`[bot] Paper trade #${trade.id} (${trade.ticker}) — Kalshi match missing; closing from local period (paper only)`);
          }
          directResult = pref.result;
        }
      } else if (directResult == null) {
        // Live: no local fallback (fail closed).
      }
      if (directResult == null) {
        await markTradeUnresolved(trade.id, "STARTUP_RECOVERY_UNRESOLVED",
          "Recovered at startup from a previous process's orphaned pending trade — Kalshi's own settlement record for this exact ticker could not be fetched or matched (API unreachable or not yet visible); will retry on next restart.");
        console.warn(`[bot] Trade #${trade.id} (${trade.ticker}) — no direct Kalshi settlement match — marked unresolved`);
        continue;
      }

      // Live orders only: confirm this order actually filled before treating
      // it as a real settled position, and capture the real opening-fill
      // stats (price/contracts/fee) in the same request (see
      // fetchKalshiOpeningFillData's doc comment). Paper trades never touch
      // the real exchange, so there is nothing to verify/fetch for them —
      // skip straight to scoring as before. Fail closed on any outcome other
      // than a confirmed fill, exactly like the no-floorStrike and
      // no-matching-period branches above.
      let openingFillStats: ReturnType<typeof computeOpeningFillStats> = null;
      if (!trade.isPaper) {
        const sinceMs = (trade.orderPlacedAt ?? trade.createdAt).getTime();
        const fillData = await fetchKalshiOpeningFillData(trade.ticker, trade.side, sinceMs);
        if (fillData === null) {
          await markTradeUnresolved(trade.id, "STARTUP_RECOVERY_UNRESOLVED",
            "Recovered at startup from a previous process's orphaned pending trade — could not confirm with Kalshi whether this order ever filled (auth/network failure); will retry on next restart.");
          console.warn(`[bot] Trade #${trade.id} (${trade.ticker}) — fill verification unavailable — marked unresolved`);
          continue;
        }
        if (!fillData.hasFill) {
          await db.update(botTrades).set({
            outcome: "cancelled", cancelledAt: new Date(), cancelReason: "STARTUP_RECOVERY_NEVER_FILLED",
            contractsFilled: 0, exitReasonText: buildExitReasonText("UNFILLED_TIMEOUT", {}),
          }).where(eq(botTrades.id, trade.id));
          console.warn(`[bot] Trade #${trade.id} (${trade.ticker}) — Kalshi confirms this order never filled — marked cancelled, not scored as a settlement`);
          continue;
        }
        openingFillStats = fillData.stats;
      }

      const priceUp = directResult.result === "yes";
      const won     = trade.side === "yes" ? priceUp : !priceUp;

      // Prefer Kalshi's own confirmed opening fill (real avg price, real
      // contract count, real fee) over the placed-order's quoted
      // entryPriceCents + the locally-approximated fee formula. The two can
      // diverge meaningfully — trade #2831 was quoted/recorded at 59¢ but
      // actually filled at 53¢, understating its real win by $0.72. Falls
      // back to the shared computeBinarySettlementPnl formula (used by
      // recordSettlement()'s live paths too) when no real fill stats could
      // be parsed, so a parse failure never blocks recovery.
      let pnlCents: number;
      let settleFee: number;
      let entryPriceCentsCorrected: number | undefined;
      let contractsFilled: number | undefined;
      if (openingFillStats) {
        const payoutCents = won ? openingFillStats.contracts * 100 : 0;
        pnlCents = payoutCents - openingFillStats.costCents - openingFillStats.feeCents;
        settleFee = openingFillStats.feeCents;
        entryPriceCentsCorrected = openingFillStats.avgPriceCents;
        contractsFilled = openingFillStats.contracts;
      } else {
        // Shared with recordSettlement()'s live paths (settlement-helpers.ts) —
        // this exact win/loss/fee formula used to be a 3rd hand-copied inline
        // implementation here, and had drifted (see the prior-lookup fix below).
        ({ pnlCents, feeCents: settleFee } = computeBinarySettlementPnl(trade.contracts, trade.entryPriceCents, won));
      }

      // Real Kalshi settle timestamp (settle_time falling back to close_time —
      // see KalshiSettlement.ts), not "whenever this recovery sweep happened
      // to run". Always available now that the local-period fallback (which
      // had no dedicated settle-timestamp column) has been removed — see the
      // fail-closed fix above.
      const settledAt = new Date(directResult.ts * 1000);

      // Bug found 2026-08-18: every other settlement path (recordSettlement)
      // writes a display-only balanceAfterCents snapshot, but this recovery
      // path never did — a DB audit confirmed live loss #3503 (STARTUP_RECOVERY,
      // 2026-08-18) has balanceAfterCents=NULL despite being fully settled.
      // The dashboard's "Balance: X → Y" summary (bot.tsx computeLogSummary)
      // picks the newest trade with a non-null balanceAfterCents, so a gap
      // here makes it silently skip the real latest trade and surface an
      // arbitrarily older (and potentially stale) snapshot instead — this is
      // exactly what produced a "$706.19 → $36.79" balance line that
      // contradicted the account's real live balance. Fill the same gap here.
      const currentBalanceCents = trade.isPaper
        ? tradingBot.getStatus().paperVirtualBalanceCents
        : tradingBot.getStatus().accountBalance;
      const balanceAfterCents = computeGuardedBalanceAfterCents({
        currentBalanceCents,
        balanceBeforeCents: trade.balanceBeforeCents,
        closedContracts: contractsFilled ?? trade.contracts,
        entryPriceCents: entryPriceCentsCorrected ?? trade.entryPriceCents,
      });

      await db.update(botTrades).set({
        outcome: won ? "win" : "loss", pnlCents, pnlDollars: pnlCents / 100, settledAt,
        exitReason: STARTUP_RECOVERY_EXIT_REASON, feeCents: settleFee, balanceAfterCents,
        ...(entryPriceCentsCorrected != null ? { entryPriceCents: entryPriceCentsCorrected } : {}),
        ...(contractsFilled != null ? { contractsFilled } : {}),
      }).where(eq(botTrades.id, trade.id));
      // SEV2 (sweep S5): paper recovery must also book the tape close, or the
      // tape-first ledger rebuild keeps the fill as an open-cost debit forever
      // (a winning payout never reaches paper cash). Idempotent per trade id.
      if (trade.isPaper === true) {
        try {
          const wroteTape = appendPaperTradeCloseOnce({
            ts: Date.now(),
            ticker: trade.ticker,
            tradeId: trade.id,
            side: trade.side === "no" ? "no" : "yes",
            contracts: contractsFilled ?? trade.contractsFilled ?? trade.contracts,
            entryPriceCents: entryPriceCentsCorrected ?? trade.entryPriceCents,
            strategyId: trade.strategyId ?? null,
            fillOrigin: trade.fillOrigin === "manual" ? "manual" : "bot",
            outcome: won ? "win" : "loss",
            pnlCents,
            exitReason: STARTUP_RECOVERY_EXIT_REASON,
            settledAt: settledAt.getTime(),
          });
          if (wroteTape) void tradingBot.reloadPaperLedgerFromTape();
        } catch { /* tape best-effort; PG row is authoritative */ }
      }
      const settledDesc = `Kalshi result=${directResult.result}`;
      const priceDesc = entryPriceCentsCorrected != null && entryPriceCentsCorrected !== trade.entryPriceCents
        ? `${trade.entryPriceCents}¢ quoted → ${entryPriceCentsCorrected}¢ real fill` : `@${trade.entryPriceCents}¢`;
      console.warn(
        `[bot] Recovered trade #${trade.id} (${trade.ticker} ${trade.side} ${priceDesc}): ` +
        `${won ? "WIN" : "LOSS"} ${pnlCents >= 0 ? "+" : ""}${pnlCents}¢ (${settledDesc} vs floor ${trade.floorStrike})`
      );

      // Profit Doctrine Phase 6: RECON row — this path bypasses
      // recordSettlement() entirely (see the balanceAfterCents comment
      // above), so it needs its own explicit trace write; it never gets a
      // SETTLE row otherwise.
      void persistDecisionTraceEvent({
        eventType: "RECON", ticker: trade.ticker, side: trade.side as "yes" | "no", strategyId: trade.strategyId ?? undefined,
        exit: { reasonCode: STARTUP_RECOVERY_EXIT_REASON, pnlCents, outcome: won ? "win" : "loss", authoritative: true },
        chain: [STARTUP_RECOVERY_EXIT_REASON, settledDesc],
      });

      // Feed the same learning/performance pipelines a normal settlement
      // would — this is an authoritative outcome (real recorded settlement
      // price), just resolved late. Meta-example resolution is skipped: its
      // id only ever lived on the in-memory OpenTrade, so it can't be
      // recovered from the DB row alone. Previously hardcoded a 0.65 prior
      // here instead of the strategy's real expectedWinRate — feedLearningPipelines
      // does the same lookup recordSettlement() uses, so recovered trades no
      // longer warm-start on a worse prior than a live settlement would.
      if (trade.strategyId) {
        await feedLearningPipelines(trade.strategyId, won, pnlCents, trade.contractDurationMins, msg => console.warn(`[bot] ${msg}`), trade.id, trade.isPaper, startupRecoveryLearningExitReason(STARTUP_RECOVERY_EXIT_REASON), trade.fillOrigin);
      }
    } catch (err) {
      console.warn(`[bot] Failed to recover trade #${trade.id}: ${(err as Error).message}`);
    }
  }
}
