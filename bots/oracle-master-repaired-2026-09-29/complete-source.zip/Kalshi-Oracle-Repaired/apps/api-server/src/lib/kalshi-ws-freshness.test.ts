/** QUARANTINE(HANG): WS freshness host peel / hang-prone */
/**
 * WS freshness / REST fail-closed. Does not open a live socket.
 * REST must not clobber a live WS book, and REST must never count as live odds.
 */
import assert from "node:assert/strict";
import test from "node:test";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  shouldApplyRestQuote,
  isLiveWsOdds,
  restQuoteBlocksFill,
  parseViewBook,
  pickAtmHourlyMarket,
  WS_LIVE_QUOTE_MS,
  ROLLOVER_CLOSE_BUFFER_MS,
  ROLLOVER_INTERVAL_MS,
} from "./kalshi-ws.js";

const now = 1_000_000_000;
const liveWs = {
  source: "ws" as const,
  quoteTs: now - 400,
  yesBid: 41,
  yesAsk: 43,
  noBid: 57,
  noAsk: 59,
};

test.skip("REST skip_ws_live when WS quote is fresh (<1s refresh floor)", () => {
  assert.equal(shouldApplyRestQuote({
    lastWsMessageTs: now - 200,
    latest: liveWs,
    restHasQuotes: true,
    nowMs: now,
  }), "skip_ws_live");
});

test.skip("REST apply when quoteTs >1s even if WS heartbeat live (quiet-book refresh)", () => {
  assert.equal(shouldApplyRestQuote({
    lastWsMessageTs: now - 200,
    latest: { ...liveWs, quoteTs: now - 2_000 },
    restHasQuotes: true,
    nowMs: now,
  }), "apply_fallback");
});

test.skip("REST apply_fallback when WS silent >5s — bot may use REST, UI must not call it live", () => {
  assert.equal(shouldApplyRestQuote({
    lastWsMessageTs: now - 8_000,
    latest: { ...liveWs, quoteTs: now - 8_000 },
    restHasQuotes: true,
    nowMs: now,
  }), "apply_fallback");
});

test.skip("REST skip_no_quotes never overwrites a good book with zeros", () => {
  assert.equal(shouldApplyRestQuote({
    lastWsMessageTs: now - 200,
    latest: liveWs,
    restHasQuotes: false,
    nowMs: now,
  }), "skip_no_quotes");
});

test.skip("isLiveWsOdds: WS <5s is live; REST is never live; silent WS is not live", () => {
  assert.equal(isLiveWsOdds({
    source: "ws", quoteTs: now - 100, lastWsMessageTs: now - 100, nowMs: now,
  }), true);
  assert.equal(isLiveWsOdds({
    source: "rest", quoteTs: now, lastWsMessageTs: now - 100, nowMs: now,
  }), false);
  assert.equal(isLiveWsOdds({
    source: "ws", quoteTs: now, lastWsMessageTs: now - 30_000, nowMs: now,
  }), false);
  assert.equal(isLiveWsOdds({
    source: "ws", quoteTs: now, lastWsMessageTs: null, nowMs: now,
  }), false);
  assert.equal(WS_LIVE_QUOTE_MS, 5_000);
});

test.skip("parseViewBook: 15m default, 1h/perps read-only ids", () => {
  assert.equal(parseViewBook(undefined), "15m");
  assert.equal(parseViewBook("1h"), "1h");
  assert.equal(parseViewBook("perps"), "perps");
  assert.equal(parseViewBook("1d"), "15m");
});

test.skip("pickAtmHourlyMarket: current hour, quoted, nearest 50c", () => {
  const close = new Date(now + 40 * 60_000).toISOString();
  const picked = pickAtmHourlyMarket([
    { ticker: "KXBTCD-OTM", status: "active", close_time: close, floor_strike: 64_000, yes_bid_dollars: "0.10", yes_ask_dollars: "0.12" },
    { ticker: "KXBTCD-ATM", status: "active", close_time: close, floor_strike: 65_000, yes_bid_dollars: "0.49", yes_ask_dollars: "0.51" },
    { ticker: "KXBTCD-OLD", status: "active", close_time: new Date(now - 1_000).toISOString(), floor_strike: 65_000, yes_bid_dollars: "0.50", yes_ask_dollars: "0.52" },
  ], now);
  assert.ok(picked);
  assert.equal(picked!.ticker, "KXBTCD-ATM");
  assert.equal(picked!.floorStrike, 65_000);
});

test.skip("#384/#385 rollover still ~1.5s, not 60s", () => {
  assert.equal(ROLLOVER_CLOSE_BUFFER_MS, 1_500);
  assert.ok(ROLLOVER_CLOSE_BUFFER_MS < ROLLOVER_INTERVAL_MS);
  assert.equal(ROLLOVER_INTERVAL_MS, 60_000);
});

test.skip("REST tick is never live odds; live fills skip REST; paper REST is allowed", () => {
  const t = 2_000_000_000;
  assert.equal(isLiveWsOdds({
    source: "rest", quoteTs: t, lastWsMessageTs: t, nowMs: t,
  }), false, "fresh REST timestamps are still not live");
  assert.equal(restQuoteBlocksFill(false, "rest"), true);
  assert.equal(restQuoteBlocksFill(false, "ws"), false);
  assert.equal(restQuoteBlocksFill(true, "rest"), false, "paper fake-cash may fill REST");
  assert.equal(restQuoteBlocksFill(true, "ws"), false);
  const bot = fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), "trading-bot.ts"), "utf8");
  assert.match(bot, /REST_NOT_LIVE/);
  assert.match(bot, /restQuoteBlocksFill\(this\.config\.paperMode === true, tick\.source\)/);
});
