import { test } from "node:test";
import assert from "node:assert/strict";
import express from "express";
import type { AddressInfo } from "node:net";
import { requireDeskAdminToken, tokenMatches, configuredAdminToken } from "./desk-admin-token.js";

async function withApp(fn: (base: string) => Promise<void>) {
  const app = express();
  app.use(express.json());
  app.use("/api", requireDeskAdminToken);
  app.get("/api/bot/status", (_q, r) => { r.json({ ok: true }); });
  app.post("/api/bot/start", (_q, r) => { r.json({ started: true }); });
  app.post("/api/auth/login", (_q, r) => { r.json({ ok: true }); });
  const srv = app.listen(0);
  const base = `http://127.0.0.1:${(srv.address() as AddressInfo).port}`;
  try { await fn(base); } finally { srv.close(); }
}

test("no DESK_ADMIN_TOKEN: mutating routes behave exactly as today", async () => {
  delete process.env.DESK_ADMIN_TOKEN;
  assert.equal(configuredAdminToken(), null);
  await withApp(async base => {
    const r = await fetch(`${base}/api/bot/start`, { method: "POST" });
    assert.equal(r.status, 200);
  });
});

test("DESK_ADMIN_TOKEN set: POST without/with wrong token = 401, right token = 200; GET open; auth exempt", async () => {
  process.env.DESK_ADMIN_TOKEN = "unit-test-token-xyz";
  try {
    await withApp(async base => {
      const noTok = await fetch(`${base}/api/bot/start`, { method: "POST" });
      assert.equal(noTok.status, 401);
      const noTokBody: unknown = await noTok.json();
      assert.ok(noTokBody !== null && typeof noTokBody === "object" && "adminTokenRequired" in noTokBody);
      assert.equal(noTokBody.adminTokenRequired, true);
      const bad = await fetch(`${base}/api/bot/start`, { method: "POST", headers: { "X-Desk-Admin-Token": "nope" } });
      assert.equal(bad.status, 401);
      const good = await fetch(`${base}/api/bot/start`, { method: "POST", headers: { "X-Desk-Admin-Token": "unit-test-token-xyz" } });
      assert.equal(good.status, 200);
      assert.equal((await fetch(`${base}/api/bot/status`)).status, 200);
      assert.equal((await fetch(`${base}/api/auth/login`, { method: "POST" })).status, 200);
    });
  } finally { delete process.env.DESK_ADMIN_TOKEN; }
});

test("tokenMatches is exact and rejects empty", () => {
  assert.equal(tokenMatches("a", "a"), true);
  assert.equal(tokenMatches("a ", "a"), false);
  assert.equal(tokenMatches("", "a"), false);
  assert.equal(tokenMatches(undefined, "a"), false);
});

test("app.ts wires the account gate (successor of desk lock + this middleware) on /api before the router", async () => {
  const { readFileSync } = await import("node:fs");
  const src = readFileSync(new URL("../app.ts", import.meta.url), "utf8");
  const mw = src.indexOf('app.use("/api", accountsApiGate)');
  const rt = src.indexOf('app.use("/api", router)');
  assert.ok(mw > 0 && rt > mw);
});
