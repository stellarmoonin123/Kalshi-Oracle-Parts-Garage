/**
 * AUTO POLICY (auto mode v3) — regime-conditioned, evidence-driven settings.
 *
 * What the operator asked for: "auto mode adapts to BTC market conditions and
 * sets the bot's configuration in the smartest way possible."
 *
 * What "smartest" can honestly mean here: the settings are chosen from the
 * bot's OWN settled fills, split by the market state that was live at entry,
 * and only moved away from the operator's values when there is enough
 * evidence to justify it. No research tables, no LLM, no hand-tuned deltas.
 *
 *   market state  = collapsed regime-engine regime × tape thinness
 *   evidence      = settled bot_trades rows (fee-net P&L per contract),
 *                   recency-weighted, with a state → market → global fallback
 *                   so a thin cell borrows from its parents instead of guessing
 *   policy/state  = suppressed strategies, minConfidence, entry-ask window,
 *                   size multiplier — every knob clamped to operator bounds
 *
 * Modes
 *   off     nothing computed
 *   shadow  policy computed and every fill is stamped with the verdict the
 *           policy WOULD have given; the CLOSE row records the realised P&L so
 *           the scoreboard can show "P&L of fills the policy would have
 *           blocked" vs "allowed". This is how the policy earns the right to
 *           write.
 *   live    the per-state policy is overlaid on the effective entry filters
 *           (tighten or loosen, but never outside the operator bounds) and the
 *           size multiplier is applied after Kelly / bands.
 *
 * Never touched: paperMode, EV floor, Kelly fraction, 9% per-trade cap, daily
 * halt, hard stops. FROZEN_CC forces live → shadow (the frozen experiment must
 * not have a moving ruleset; shadow still learns from its fills).
 *
 * Everything in this file is pure so it can be unit-tested and replayed
 * offline against the same rows the live bot sees.
 */

export type MarketState = "TREND" | "REVERSAL" | "RANGE" | "SQUEEZE" | "WATERFALL" | "UNCLEAR";
export type TapeState = "THIN" | "OK";
export type AutoPolicyMode = "off" | "shadow" | "live";
export const AUTO_POLICY_MODES: readonly AutoPolicyMode[] = ["off", "shadow", "live"];

export const MARKET_STATES: readonly MarketState[] = ["TREND", "REVERSAL", "RANGE", "SQUEEZE", "WATERFALL", "UNCLEAR"];
export const TAPE_STATES: readonly TapeState[] = ["THIN", "OK"];

/** Collapse the 10 sticky regime-engine regimes into 6 states with usable sample sizes. */
export function marketStateFromRegime(regime: string | null | undefined): MarketState {
  switch (regime) {
    case "strong_uptrend":
    case "strong_downtrend":
    case "breakout_up":
    case "breakdown":
      return "TREND";
    case "fakeout":
    case "exhaustion":
      return "REVERSAL";
    case "range":
      return "RANGE";
    case "squeeze":
      return "SQUEEZE";
    case "waterfall":
      return "WATERFALL";
    default:
      return "UNCLEAR";
  }
}

export function tapeStateFromVolume(bucket: string | null | undefined): TapeState {
  return bucket === "DEAD" || bucket === "LOW" ? "THIN" : "OK";
}

export function stateId(market: MarketState, tape: TapeState): string {
  return `${market}/${tape}`;
}

export function stateIdFor(regime: string | null | undefined, volumeBucket: string | null | undefined): string {
  return stateId(marketStateFromRegime(regime), tapeStateFromVolume(volumeBucket));
}

/** One settled fill. pnlCents is the whole-position fee-net P&L. */
export interface EvidenceRow {
  strategyId: string;
  regime: string | null;
  volumeBucket: string | null;
  entryPriceCents: number;
  confidence: number | null;
  contracts: number;
  pnlCents: number;
  outcome: "win" | "loss";
  settledAtMs: number;
  isPaper: boolean;
}

export interface AutoPolicyBounds {
  /** [lowest, highest] minConfidence the policy may set. */
  minConfidence: [number, number];
  /** [lowest minEntryPrice, highest maxEntryPrice] the policy may set. */
  entryPrice: [number, number];
  /** [lowest, highest] size multiplier. Default hi = 1 (never size up). */
  sizeMult: [number, number];
}

export interface AutoPolicyParams {
  /** Settled fills a cell needs before the policy trusts it. */
  minSamples: number;
  /** z for the one-sided confidence bound on mean P&L per contract (1.28 ≈ 90%). */
  z: number;
  /** Ignore fills older than this. */
  lookbackDays: number;
  /** Recency half-life for weighting fills. */
  halfLifeDays: number;
  /** Include paper fills as evidence (there is rarely enough live data). */
  includePaper: boolean;
  /** Mean fee-net P&L per contract (¢) at which sizeMult reaches its upper bound. */
  fullSizeLbCents: number;
}

export const DEFAULT_AUTO_POLICY_PARAMS: AutoPolicyParams = {
  minSamples: 20,
  z: 1.28,
  lookbackDays: 45,
  halfLifeDays: 10,
  includePaper: true,
  fullSizeLbCents: 5,
};

export interface OperatorBaseline {
  minConfidence: number;
  minEntryPrice: number;
  maxEntryPrice: number;
}

/** Default bounds: tighten-only around the operator's current values, never size up. */
export function defaultBoundsFor(baseline: OperatorBaseline): AutoPolicyBounds {
  return {
    minConfidence: [baseline.minConfidence, Math.max(baseline.minConfidence, 75)],
    entryPrice: [baseline.minEntryPrice, baseline.maxEntryPrice],
    sizeMult: [0.5, 1],
  };
}

export interface CellStats {
  n: number;
  wins: number;
  /** Recency-weighted mean fee-net P&L per contract (¢). */
  meanCents: number;
  /** Lower / upper one-sided bounds on meanCents. */
  lbCents: number;
  ubCents: number;
  winRate: number;
}

const EMPTY_STATS: CellStats = { n: 0, wins: 0, meanCents: 0, lbCents: 0, ubCents: 0, winRate: 0 };

function rowWeight(row: EvidenceRow, nowMs: number, halfLifeDays: number): number {
  const ageDays = Math.max(0, (nowMs - row.settledAtMs) / 86_400_000);
  return Math.pow(0.5, ageDays / Math.max(0.1, halfLifeDays));
}

export function cellStats(rows: EvidenceRow[], nowMs: number, params: AutoPolicyParams): CellStats {
  if (rows.length === 0) return EMPTY_STATS;
  let sw = 0, swx = 0, wins = 0;
  const perContract: number[] = [];
  const weights: number[] = [];
  for (const r of rows) {
    const c = Math.max(1, r.contracts);
    const x = r.pnlCents / c;
    const w = rowWeight(r, nowMs, params.halfLifeDays);
    perContract.push(x); weights.push(w);
    sw += w; swx += w * x;
    if (r.outcome === "win") wins++;
  }
  const mean = sw > 0 ? swx / sw : 0;
  let swv = 0;
  for (let i = 0; i < perContract.length; i++) swv += weights[i] * (perContract[i] - mean) ** 2;
  // Weighted sample variance; with one row fall back to a wide prior so a single
  // fill can never produce a confident bound.
  const variance = rows.length > 1 && sw > 0 ? swv / sw * (rows.length / (rows.length - 1)) : 40 ** 2;
  const se = Math.sqrt(variance / rows.length);
  return {
    n: rows.length,
    wins,
    meanCents: round2(mean),
    lbCents: round2(mean - params.z * se),
    ubCents: round2(mean + params.z * se),
    winRate: round2(wins / rows.length),
  };
}

function round2(x: number): number { return Math.round(x * 100) / 100; }

export type EvidenceLevel = "state" | "market" | "global" | "none";

/** Pick the most specific row set with at least minSamples, recording where it came from. */
export function pickEvidence(
  rows: EvidenceRow[],
  market: MarketState,
  tape: TapeState,
  minSamples: number,
): { rows: EvidenceRow[]; level: EvidenceLevel } {
  const inState = rows.filter(r => marketStateFromRegime(r.regime) === market && tapeStateFromVolume(r.volumeBucket) === tape);
  if (inState.length >= minSamples) return { rows: inState, level: "state" };
  const inMarket = rows.filter(r => marketStateFromRegime(r.regime) === market);
  if (inMarket.length >= minSamples) return { rows: inMarket, level: "market" };
  if (rows.length >= minSamples) return { rows, level: "global" };
  return { rows: inState.length > 0 ? inState : inMarket.length > 0 ? inMarket : rows, level: "none" };
}

export const CONF_BANDS: ReadonlyArray<readonly [number, number]> = [[0, 55], [55, 60], [60, 65], [65, 70], [70, 101]];
export const ASK_BANDS: ReadonlyArray<readonly [number, number]> = [[1, 35], [36, 45], [46, 55], [56, 65], [66, 99]];

export interface StrategyVerdict {
  strategyId: string;
  level: EvidenceLevel;
  stats: CellStats;
  suppressed: boolean;
}

export interface StatePolicy {
  stateId: string;
  market: MarketState;
  tape: TapeState;
  level: EvidenceLevel;
  n: number;
  /** Strategies with enough evidence in this state AND an upper bound below zero. */
  suppressStrategies: string[];
  strategies: StrategyVerdict[];
  /** null = keep the operator's value. */
  minConfidence: number | null;
  minEntryPrice: number | null;
  maxEntryPrice: number | null;
  sizeMult: number;
  /** Stats of the fills that would pass this state's policy. */
  passingStats: CellStats;
  reasons: string[];
}

export interface AutoPolicy {
  version: 3;
  computedAtMs: number;
  params: AutoPolicyParams;
  bounds: AutoPolicyBounds;
  baseline: OperatorBaseline;
  totalRows: number;
  paperRows: number;
  states: Record<string, StatePolicy>;
}

function clamp(x: number, lo: number, hi: number): number { return Math.max(lo, Math.min(hi, x)); }

function bandStats(rows: EvidenceRow[], pick: (r: EvidenceRow) => number | null, band: readonly [number, number], nowMs: number, params: AutoPolicyParams): CellStats {
  return cellStats(rows.filter(r => { const v = pick(r); return v != null && v >= band[0] && v <= band[1]; }), nowMs, params);
}

/**
 * minConfidence: the lowest band such that every fill at/above it has enough
 * evidence and a positive lower bound. If evidence exists but nothing clears
 * zero, go to the top of the bounds (most restrictive). No evidence → null.
 */
export function chooseMinConfidence(
  rows: EvidenceRow[],
  baseline: OperatorBaseline,
  bounds: AutoPolicyBounds,
  nowMs: number,
  params: AutoPolicyParams,
): { value: number | null; reason: string } {
  const [lo, hi] = bounds.minConfidence;
  let anyEvidence = false;
  for (const band of CONF_BANDS) {
    const floor = band[0];
    if (floor > hi) break;
    const cum = cellStats(rows.filter(r => r.confidence != null && r.confidence >= floor), nowMs, params);
    if (cum.n < params.minSamples) continue;
    anyEvidence = true;
    if (cum.lbCents > 0) {
      const value = clamp(Math.max(floor, lo), lo, hi);
      return { value, reason: `conf≥${floor}: n=${cum.n} lb=${cum.lbCents}¢ > 0 → minConfidence ${value}` };
    }
  }
  if (anyEvidence) return { value: hi, reason: `no confidence floor within [${lo},${hi}] has lb>0 → most restrictive ${hi}` };
  void baseline;
  return { value: null, reason: `fewer than ${params.minSamples} fills with confidence → operator value kept` };
}

/**
 * Entry window: the span of ask bands whose own evidence clears zero. Bands
 * without enough evidence are neither allowed nor forbidden on their own; the
 * window is the min..max of the allowed bands, clamped to bounds.
 */
export function chooseEntryWindow(
  rows: EvidenceRow[],
  bounds: AutoPolicyBounds,
  nowMs: number,
  params: AutoPolicyParams,
): { min: number | null; max: number | null; reason: string } {
  const perBandMin = Math.max(8, Math.ceil(params.minSamples / 2));
  const allowed: Array<readonly [number, number]> = [];
  const judged: string[] = [];
  for (const band of ASK_BANDS) {
    const s = bandStats(rows, r => r.entryPriceCents, band, nowMs, params);
    if (s.n < perBandMin) continue;
    judged.push(`${band[0]}-${band[1]}¢ n=${s.n} lb=${s.lbCents}`);
    if (s.lbCents > 0) allowed.push(band);
  }
  if (judged.length === 0) return { min: null, max: null, reason: `no ask band has ≥${perBandMin} fills → operator window kept` };
  if (allowed.length === 0) return { min: null, max: null, reason: `ask bands judged (${judged.join("; ")}) but none clear zero → operator window kept, size shrinks instead` };
  const [blo, bhi] = bounds.entryPrice;
  const min = clamp(Math.min(...allowed.map(b => b[0])), blo, bhi);
  const max = clamp(Math.max(...allowed.map(b => b[1])), blo, bhi);
  return { min, max: Math.max(min, max), reason: `allowed ask bands ${allowed.map(b => `${b[0]}-${b[1]}`).join(",")} → window ${min}-${max}¢ (${judged.join("; ")})` };
}

/** Size: scales with the lower bound of the passing set; unknown → small. */
export function chooseSizeMult(passing: CellStats, bounds: AutoPolicyBounds, params: AutoPolicyParams): { value: number; reason: string } {
  const [lo, hi] = bounds.sizeMult;
  if (passing.n === 0) return { value: lo, reason: "no passing fills → smallest size" };
  const evidenceFrac = clamp(passing.n / params.minSamples, 0, 1);
  const edgeFrac = clamp(passing.lbCents / params.fullSizeLbCents, 0, 1);
  // Partial evidence caps how far above the floor we can go; the edge decides where within that.
  const strength = evidenceFrac * edgeFrac;
  const value = round2(lo + (hi - lo) * strength);
  return { value, reason: `n=${passing.n}/${params.minSamples} lb=${passing.lbCents}¢ → sizeMult ${value}` };
}

export function derivePolicy(
  allRows: EvidenceRow[],
  baseline: OperatorBaseline,
  bounds: AutoPolicyBounds,
  params: AutoPolicyParams = DEFAULT_AUTO_POLICY_PARAMS,
  nowMs: number = Date.now(),
): AutoPolicy {
  const cutoff = nowMs - params.lookbackDays * 86_400_000;
  const rows = allRows.filter(r =>
    r.settledAtMs >= cutoff &&
    (r.outcome === "win" || r.outcome === "loss") &&
    Number.isFinite(r.pnlCents) &&
    (params.includePaper || !r.isPaper),
  );
  const strategyIds = [...new Set(rows.map(r => r.strategyId))].sort();
  const states: Record<string, StatePolicy> = {};

  for (const market of MARKET_STATES) {
    for (const tape of TAPE_STATES) {
      const id = stateId(market, tape);
      const ev = pickEvidence(rows, market, tape, params.minSamples);
      const reasons: string[] = [`evidence level=${ev.level} n=${ev.rows.length}`];

      const strategies: StrategyVerdict[] = strategyIds.map(sid => {
        const sEv = pickEvidence(rows.filter(r => r.strategyId === sid), market, tape, params.minSamples);
        const stats = cellStats(sEv.rows, nowMs, params);
        const suppressed = stats.n >= params.minSamples && stats.ubCents < 0;
        return { strategyId: sid, level: sEv.level, stats, suppressed };
      });
      const suppressStrategies = strategies.filter(s => s.suppressed).map(s => s.strategyId);
      if (suppressStrategies.length > 0) reasons.push(`suppress ${suppressStrategies.join(",")} (ub<0 with n≥${params.minSamples})`);

      const unsuppressed = ev.rows.filter(r => !suppressStrategies.includes(r.strategyId));
      // Window first, then the confidence floor on fills inside that window:
      // a bad ask band should be removed by the window, not by raising the
      // confidence bar on everything.
      const win = chooseEntryWindow(unsuppressed, bounds, nowMs, params);
      reasons.push(win.reason);
      const effMin = win.min ?? baseline.minEntryPrice;
      const effMax = win.max ?? baseline.maxEntryPrice;
      const inWindow = unsuppressed.filter(r => r.entryPriceCents >= effMin && r.entryPriceCents <= effMax);
      const conf = chooseMinConfidence(inWindow, baseline, bounds, nowMs, params);
      reasons.push(conf.reason);
      const effMinConf = conf.value ?? baseline.minConfidence;
      const passingRows = unsuppressed.filter(r =>
        (r.confidence == null || r.confidence >= effMinConf) &&
        r.entryPriceCents >= effMin && r.entryPriceCents <= effMax,
      );
      const passingStats = cellStats(passingRows, nowMs, params);
      const size = chooseSizeMult(passingStats, bounds, params);
      reasons.push(size.reason);

      states[id] = {
        stateId: id, market, tape, level: ev.level, n: ev.rows.length,
        suppressStrategies, strategies,
        minConfidence: conf.value, minEntryPrice: win.min, maxEntryPrice: win.max,
        sizeMult: size.value, passingStats, reasons,
      };
    }
  }

  return {
    version: 3, computedAtMs: nowMs, params, bounds, baseline,
    totalRows: rows.length, paperRows: rows.filter(r => r.isPaper).length, states,
  };
}

/** The subset of effective entry filters the policy is allowed to move. */
export interface PolicyOverlayTarget {
  minConfidence: number;
  minEntryPrice: number;
  maxEntryPrice: number;
  disabledStrategies: string[];
}

export function applyAutoPolicyOverlay<T extends PolicyOverlayTarget>(
  eff: T,
  policy: AutoPolicy | null,
  currentStateId: string,
  mode: AutoPolicyMode,
): { eff: T; applied: string[] } {
  if (mode !== "live" || !policy) return { eff, applied: [] };
  const sp = policy.states[currentStateId];
  if (!sp) return { eff, applied: [] };
  const next: T = { ...eff, disabledStrategies: [...eff.disabledStrategies] };
  const applied: string[] = [];
  const [cLo, cHi] = policy.bounds.minConfidence;
  const [pLo, pHi] = policy.bounds.entryPrice;
  if (sp.minConfidence != null) {
    const v = clamp(sp.minConfidence, cLo, cHi);
    if (v !== next.minConfidence) { applied.push(`minConfidence ${next.minConfidence}→${v}`); next.minConfidence = v; }
  }
  if (sp.minEntryPrice != null) {
    const v = clamp(sp.minEntryPrice, pLo, pHi);
    if (v !== next.minEntryPrice) { applied.push(`minEntryPrice ${next.minEntryPrice}→${v}`); next.minEntryPrice = v; }
  }
  if (sp.maxEntryPrice != null) {
    const v = clamp(sp.maxEntryPrice, pLo, pHi);
    if (v !== next.maxEntryPrice) { applied.push(`maxEntryPrice ${next.maxEntryPrice}→${v}`); next.maxEntryPrice = v; }
  }
  if (next.maxEntryPrice < next.minEntryPrice) next.maxEntryPrice = next.minEntryPrice;
  for (const sid of sp.suppressStrategies) {
    if (!next.disabledStrategies.includes(sid)) { next.disabledStrategies.push(sid); applied.push(`suppress ${sid}`); }
  }
  return { eff: next, applied };
}

export function policySizeMult(policy: AutoPolicy | null, currentStateId: string, mode: AutoPolicyMode): number {
  if (mode !== "live" || !policy) return 1;
  const sp = policy.states[currentStateId];
  if (!sp) return 1;
  const [lo, hi] = policy.bounds.sizeMult;
  return clamp(sp.sizeMult, lo, hi);
}

/** What the policy says about one concrete fill — stamped on every fill in shadow AND live. */
export interface PolicyVerdict {
  stateId: string;
  level: EvidenceLevel;
  wouldBlock: boolean;
  reasons: string[];
  sizeMult: number;
  policyComputedAtMs: number | null;
}

export function judgeFill(
  policy: AutoPolicy | null,
  fill: { strategyId: string; regime: string | null; volumeBucket: string | null; confidence: number | null; entryPriceCents: number },
  baseline: OperatorBaseline,
): PolicyVerdict {
  const id = stateIdFor(fill.regime, fill.volumeBucket);
  const sp = policy?.states[id];
  if (!policy || !sp) return { stateId: id, level: "none", wouldBlock: false, reasons: ["no policy"], sizeMult: 1, policyComputedAtMs: policy?.computedAtMs ?? null };
  const reasons: string[] = [];
  if (sp.suppressStrategies.includes(fill.strategyId)) reasons.push(`strategy ${fill.strategyId} suppressed in ${id}`);
  const minConf = sp.minConfidence ?? baseline.minConfidence;
  if (fill.confidence != null && fill.confidence < minConf) reasons.push(`confidence ${fill.confidence} < ${minConf}`);
  const lo = sp.minEntryPrice ?? baseline.minEntryPrice;
  const hi = sp.maxEntryPrice ?? baseline.maxEntryPrice;
  if (fill.entryPriceCents < lo || fill.entryPriceCents > hi) reasons.push(`ask ${fill.entryPriceCents}¢ outside ${lo}-${hi}¢`);
  return { stateId: id, level: sp.level, wouldBlock: reasons.length > 0, reasons, sizeMult: sp.sizeMult, policyComputedAtMs: policy.computedAtMs };
}

/** Append-only shadow ledger rows (data/auto-policy-shadow.jsonl). */
export interface ShadowFillRow {
  kind: "FILL";
  ts: number;
  mode: AutoPolicyMode;
  ticker: string;
  strategyId: string;
  side: "yes" | "no";
  askCents: number;
  contracts: number;
  confidence: number | null;
  regime: string | null;
  volumeBucket: string | null;
  verdict: PolicyVerdict;
  isPaper: boolean;
}
export interface ShadowCloseRow {
  kind: "CLOSE";
  ts: number;
  mode: AutoPolicyMode;
  ticker: string;
  strategyId: string;
  side: "yes" | "no";
  askCents: number;
  contracts: number;
  outcome: string;
  pnlCents: number;
  exitReason: string;
  verdict: PolicyVerdict;
  isPaper: boolean;
}
export type ShadowRow = ShadowFillRow | ShadowCloseRow;

export interface ShadowScoreboard {
  closes: number;
  baselinePnlCents: number;
  /** Σ pnl of fills the policy would have allowed, scaled by its sizeMult. */
  policyPnlCents: number;
  blocked: { n: number; wins: number; pnlCents: number };
  allowed: { n: number; wins: number; pnlCents: number; sizedPnlCents: number };
  /** policyPnlCents − baselinePnlCents: positive means the policy would have helped. */
  upliftCents: number;
  byState: Record<string, { closes: number; blocked: number; blockedPnlCents: number; allowedPnlCents: number }>;
}

export function summarizeShadow(rows: ShadowRow[]): ShadowScoreboard {
  const closes = rows.filter((r): r is ShadowCloseRow => r.kind === "CLOSE");
  const sb: ShadowScoreboard = {
    closes: closes.length, baselinePnlCents: 0, policyPnlCents: 0,
    blocked: { n: 0, wins: 0, pnlCents: 0 },
    allowed: { n: 0, wins: 0, pnlCents: 0, sizedPnlCents: 0 },
    upliftCents: 0, byState: {},
  };
  for (const c of closes) {
    sb.baselinePnlCents += c.pnlCents;
    const st = sb.byState[c.verdict.stateId] ??= { closes: 0, blocked: 0, blockedPnlCents: 0, allowedPnlCents: 0 };
    st.closes++;
    if (c.verdict.wouldBlock) {
      sb.blocked.n++; sb.blocked.pnlCents += c.pnlCents; if (c.outcome === "win") sb.blocked.wins++;
      st.blocked++; st.blockedPnlCents += c.pnlCents;
    } else {
      const sized = Math.round(c.pnlCents * c.verdict.sizeMult);
      sb.allowed.n++; sb.allowed.pnlCents += c.pnlCents; sb.allowed.sizedPnlCents += sized;
      if (c.outcome === "win") sb.allowed.wins++;
      sb.policyPnlCents += sized;
      st.allowedPnlCents += c.pnlCents;
    }
  }
  sb.upliftCents = sb.policyPnlCents - sb.baselinePnlCents;
  return sb;
}

/** Sanitize operator-supplied bounds; falls back to defaults for anything malformed. */
export function normalizeBounds(raw: unknown, baseline: OperatorBaseline): AutoPolicyBounds {
  const d = defaultBoundsFor(baseline);
  const pair = (v: unknown, def: [number, number], lo: number, hi: number): [number, number] => {
    if (!Array.isArray(v) || v.length !== 2) return def;
    const a = Number(v[0]), b = Number(v[1]);
    if (!Number.isFinite(a) || !Number.isFinite(b)) return def;
    const x = clamp(Math.min(a, b), lo, hi), y = clamp(Math.max(a, b), lo, hi);
    return [x, y];
  };
  const r = (raw ?? {}) as Record<string, unknown>;
  return {
    minConfidence: pair(r.minConfidence, d.minConfidence, 40, 95),
    entryPrice: pair(r.entryPrice, d.entryPrice, 1, 99),
    sizeMult: pair(r.sizeMult, d.sizeMult, 0.1, 1.5),
  };
}

export function normalizeMode(raw: unknown): AutoPolicyMode {
  return AUTO_POLICY_MODES.includes(raw as AutoPolicyMode) ? (raw as AutoPolicyMode) : "off";
}
