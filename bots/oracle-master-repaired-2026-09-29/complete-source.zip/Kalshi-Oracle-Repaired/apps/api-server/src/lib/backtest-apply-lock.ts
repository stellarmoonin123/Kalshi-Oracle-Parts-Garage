/**
 * Composer cannot loosen live trading knobs from Backtest / Sim Lab.
 * LIVE_APPLY false. paperMode true. autoMode false.
 * Never CHANGE_EV_FLOOR / ENABLE_STRATEGY / Kelly / disabledStrategies / paperMode.
 * Does not import trading-bot.ts.
 */
export const APPLY_BACKTEST_REFUSE_REASON =
  "composer cannot loosen — LIVE_APPLY false; never CHANGE_EV_FLOOR / ENABLE_STRATEGY / Kelly / disabledStrategies / paperMode";

export const APPLY_BACKTEST_REFUSED = {
  ok: false as const,
  applied: false as const,
  refused: true as const,
  reason: APPLY_BACKTEST_REFUSE_REASON,
  liveApplyEnabled: false as const,
  paperMode: true as const,
  autoMode: false as const,
  never: ["CHANGE_EV_FLOOR", "ENABLE_STRATEGY", "Kelly", "disabledStrategies", "paperMode"] as const,
};

export function refuseApplyBacktestConfig(): typeof APPLY_BACKTEST_REFUSED {
  return { ...APPLY_BACKTEST_REFUSED };
}
