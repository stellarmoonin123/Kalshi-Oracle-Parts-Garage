/**
 * skip.ts — desk default.
 *
 * Lottery 7–12¢ in the last 150s is skip (1715-15 8¢ last-2.5m).
 * Still-mid 48–52¢ is skip on the green-sell book (desk STILL_MID) (1645 still 49¢ confluence dump).
 * Binary pin (strike-levels.pinRisk) is skip on still-mid 48–52¢ when spot is
 * inside one bounce-band of the floor and the floor is within $25 of a $100
 * psych. Skip/tighten, not a fill. Does not CHANGE_EV_FLOOR.
 *
 * paperMode true. autoMode false. LIVE_APPLY false.
 * Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR.
 */
import { is15mDeskEvaluateAllowed } from "../15m-product.js";
import { TICKET_VEL_MIN_MOVE_CENTS } from "../intra-scalp-replay.js";
import { pinRisk } from "../strike-levels.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;

/** Last 150s = last 2.5m lottery window. */
export const LOTTERY_LAST_SECS = 150;
export const LOTTERY_ASK_MIN_CENTS = 7; // lottery band — not desk door 20
export const LOTTERY_ASK_MAX_CENTS = 12;

/** Still-mid band for the green-sell book. Inclusive. */
export const STILL_MID_MIN_CENTS = 48;
export const STILL_MID_MAX_CENTS = 52;

export type DeskBook = "settlement" | "scalp" | "green-sell" | "skip";

export type DeskSkipObs = {
  askCents?: number | null;
  secsRemaining?: number | null;
  book?: DeskBook | null;
  /** True when ticket dMid/dt is not moving. Unknown + green-sell mid → fail closed skip. */
  still?: boolean;
  dMidCents?: number | null;
  ticker?: string | null;
  /** Live BTC. Optional — pinRisk is a no-op without both spot and floor. */
  spot?: number | null;
  /** This bar's KXBTC15M strike. */
  floor?: number | null;
};

export type DeskSkipDecision =
  | { skip: true; reason: string; book: DeskBook }
  | { skip: false; reason: "pass"; book: DeskBook };

function bookOf(obs: DeskSkipObs): DeskBook {
  return obs.book ?? "settlement";
}

function isLotteryAsk(ask: number): boolean {
  return ask >= LOTTERY_ASK_MIN_CENTS && ask <= LOTTERY_ASK_MAX_CENTS;
}

function isStillMidAsk(ask: number): boolean {
  return ask >= STILL_MID_MIN_CENTS && ask <= STILL_MID_MAX_CENTS;
}

/** Fail closed: unknown still on a mid ask is treated as still. */
export function isStillTicket(obs: DeskSkipObs): boolean {
  if (obs.still === true) return true;
  if (obs.still === false) return false;
  if (typeof obs.dMidCents === "number" && Number.isFinite(obs.dMidCents)) {
    return Math.abs(obs.dMidCents) < TICKET_VEL_MIN_MOVE_CENTS;
  }
  return true;
}

/**
 * Default skip. Lottery and still-mid fire before any predicate.
 * LIVE_APPLY is never flipped true.
 */
export function deskSkip(obs: DeskSkipObs): DeskSkipDecision {
  const book = bookOf(obs);

  if (LIVE_APPLY || LIVE_APPLY_ENABLED) {
    return { skip: true, reason: "live_apply_refused", book };
  }

  const product = is15mDeskEvaluateAllowed({ ticker: obs.ticker ?? null });
  if (!product.ok) {
    return { skip: true, reason: product.reason.toLowerCase(), book };
  }

  const ask = obs.askCents;
  const secs = obs.secsRemaining;

  if (
    typeof ask === "number" && Number.isFinite(ask)
    && typeof secs === "number" && Number.isFinite(secs)
    && isLotteryAsk(ask)
    && secs <= LOTTERY_LAST_SECS
  ) {
    return { skip: true, reason: "lottery_7_12_last_150s", book };
  }

  if (
    book === "green-sell"
    && typeof ask === "number" && Number.isFinite(ask)
    && isStillMidAsk(ask)
    && isStillTicket(obs)
  ) {
    return { skip: true, reason: "still_mid_48_52_green_sell", book };
  }

  if (
    typeof ask === "number" && Number.isFinite(ask)
    && typeof obs.spot === "number" && Number.isFinite(obs.spot)
    && typeof obs.floor === "number" && Number.isFinite(obs.floor)
  ) {
    const pr = pinRisk({
      spot: obs.spot,
      floor: obs.floor,
      askCents: ask,
      still: isStillTicket(obs),
    });
    if (pr.pin) {
      return { skip: true, reason: pr.reason, book };
    }
  }

  return { skip: false, reason: "pass", book };
}
