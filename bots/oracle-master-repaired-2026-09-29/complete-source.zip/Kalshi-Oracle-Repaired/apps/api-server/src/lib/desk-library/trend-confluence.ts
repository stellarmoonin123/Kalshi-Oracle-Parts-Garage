/**
 * trend-confluence.ts — settlement book, shadow.
 *
 * Confluence ONLY if regime is an actual trend (strong_up / strong_down).
 * Ask not still-mid 48–52 in unclear (desk STILL_MID) (1645 still 49¢ dump).
 *
 * Reuses settlement-side.ts for one side + MTF veto.
 *
 * paperMode true. autoMode false. LIVE_APPLY false.
 * Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR.
 */
import { decideSettlementSide } from "../settlement-side.js";
import { TICKET_VEL_MIN_MOVE_CENTS } from "../intra-scalp-replay.js";
import { pinRisk } from "../strike-levels.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;

export const TREND_REGIMES = ["strong_uptrend", "strong_downtrend"] as const;
export type TrendRegime = (typeof TREND_REGIMES)[number];

/** Unclear still-mid skip band. Inclusive 48–52 (desk STILL_MID). 1645 was 49¢. */
export const UNCLEAR_STILL_MID_MIN_CENTS = 48;
export const UNCLEAR_STILL_MID_MAX_CENTS = 52;

export type TrendConfluenceOpts = {
  side: "yes" | "no";
  askCents: number;
  regime?: string | null;
  still?: boolean;
  dMidCents?: number | null;
  mtf?: number;
  pWin?: number | null;
  spot?: number | null;
  floor?: number | null;
};

export type TrendConfluenceDecision = {
  take: boolean;
  reason: string;
};

function skip(reason: string): TrendConfluenceDecision {
  return { take: false, reason };
}

export function isActualTrend(regime?: string | null): regime is TrendRegime {
  return regime === "strong_uptrend" || regime === "strong_downtrend";
}

function ticketStill(still: boolean | undefined, dMidCents?: number | null): boolean {
  if (still === false) return false;
  if (typeof dMidCents === "number" && Number.isFinite(dMidCents)) {
    return Math.abs(dMidCents) < TICKET_VEL_MIN_MOVE_CENTS;
  }
  // still is true or omitted — omitted without a mid move is treated as still.
  return true;
}

function isUnclearStillMid(opts: TrendConfluenceOpts): boolean {
  const ask = opts.askCents;
  if (!(ask >= UNCLEAR_STILL_MID_MIN_CENTS && ask <= UNCLEAR_STILL_MID_MAX_CENTS)) {
    return false;
  }
  const regime = opts.regime ?? "unclear";
  if (regime !== "unclear") return false;
  return ticketStill(opts.still, opts.dMidCents);
}

/**
 * Shadow predicate. Unclear still-mid is skip. Only strong_up / strong_down take.
 */
export function shouldTrendConfluenceTake(opts: TrendConfluenceOpts): TrendConfluenceDecision {
  if (LIVE_APPLY || LIVE_APPLY_ENABLED) {
    return skip("live_apply_refused");
  }
  if (
    typeof opts.spot === "number" && Number.isFinite(opts.spot)
    && typeof opts.floor === "number" && Number.isFinite(opts.floor)
  ) {
    const still = ticketStill(opts.still, opts.dMidCents);
    const pr = pinRisk({
      spot: opts.spot,
      floor: opts.floor,
      askCents: opts.askCents,
      still,
    });
    if (pr.pin) return skip(pr.reason);
  }
  if (isUnclearStillMid(opts)) {
    return skip("unclear_still_mid");
  }
  if (!isActualTrend(opts.regime)) {
    return skip("regime_not_trend");
  }

  const wr = opts.pWin != null && Number.isFinite(opts.pWin) ? opts.pWin : null;
  const sideDecision = decideSettlementSide({
    pYes: opts.side === "yes" ? wr : null,
    pNo: opts.side === "no" ? wr : null,
    mtf: opts.mtf ?? 0,
  });
  if (sideDecision.side === "skip") {
    return skip(sideDecision.reason);
  }
  if (sideDecision.side !== opts.side) {
    return skip("side_mismatch");
  }

  return { take: true, reason: "trend_confluence" };
}
