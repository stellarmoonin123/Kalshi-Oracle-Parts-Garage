/**
 * QUARANTINE — cheap-persist-sell.ts
 * DEAD_REMOVE candidate / leftover deny. OFF money-path placeOrder wire.
 * Shadow/replay imports may remain; HARD_NO_FILL + paper-release still block fills.
 * DO NOT ENABLE. DO NOT WIRE as a second entry law beside frozen six-gate / CC|LAG.
 *
 * --- original header follows ---
 */
/**
 * cheap-persist-sell.ts
 *
 * OBSERVE dual-gate. Paper/research only.
 * Entry: persist ≥15s ∩ ask 7–22 ∩ 2–12m ∩ EV ≥3¢.
 * Exit: CEE (green +8 / 2× / TB / lag-flip / 90s). NEVER HOLD 7–22
 * (HOLD −69¢ n=22 on 2026-09-02 council tape).
 *
 * Does not ENABLE CHEAP_EARLY_EXIT / cheapEarlyExitEnabled.
 * LIVE_APPLY false. ENABLE default false. Not a TradingBot fill path.
 * Never cut EV 3¢ / Kelly 0.60 / 9%. Never paperMode false.
 */
import { CHEAP_SIDE_ASK_MAX_CENTS, CHEAP_SIDE_ASK_MIN_CENTS, isCheapSideMidWindow } from "./cheap-side-15m.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;
export const CHEAP_PERSIST_SELL_ENABLED_DEFAULT = false as const;

export const CHEAP_PERSIST_ASK_MIN_CENTS = CHEAP_SIDE_ASK_MIN_CENTS;
export const CHEAP_PERSIST_ASK_MAX_CENTS = CHEAP_SIDE_ASK_MAX_CENTS;
export const CHEAP_PERSIST_MIN_MS = 15_000;
export const CHEAP_PERSIST_EV_FLOOR_CENTS = 3;

export type CheapPersistSellOpts = {
  side: "yes" | "no";
  askCents: number;
  secsRemaining: number;
  msOnSideOfFloor: number;
  evCents: number;
  enabled?: boolean;
};

export type CheapPersistSellDecision = {
  take: boolean;
  reason: string;
  exitRule: "cee_green8";
};

export function isCheapPersistSellDualGateOpen(enabled: boolean | undefined): boolean {
  return enabled === true;
}

function skip(reason: string): CheapPersistSellDecision {
  return { take: false, reason, exitRule: "cee_green8" };
}

export function shouldCheapPersistSellTake(opts: CheapPersistSellOpts): CheapPersistSellDecision {
  if (LIVE_APPLY || LIVE_APPLY_ENABLED) return skip("live_apply_refused");
  if (!isCheapPersistSellDualGateOpen(opts.enabled)) return skip("dual_gate_closed");
  if (!(opts.askCents >= CHEAP_PERSIST_ASK_MIN_CENTS && opts.askCents <= CHEAP_PERSIST_ASK_MAX_CENTS)) {
    return skip("ask_not_7_22");
  }
  if (opts.askCents >= 7 && opts.askCents <= 12 && opts.secsRemaining <= 150) return skip("lottery");
  if (!isCheapSideMidWindow(opts.secsRemaining / 60)) return skip("not_2_12m");
  if (!(opts.msOnSideOfFloor >= CHEAP_PERSIST_MIN_MS)) return skip("persist_lt_15s");
  if (!(opts.evCents >= CHEAP_PERSIST_EV_FLOOR_CENTS)) return skip("ev_lt_3");
  return { take: true, reason: "cheap_persist_sell", exitRule: "cee_green8" };
}
