/**
 * ExpertAgent — a 45-second loop that calls an AI model with full bot
 * context and returns a structured market assessment.  The assessment is:
 *
 *  1. Stored as `expertAgent.lastAssessment` — included in BotStatus SSE stream
 *  2. Emitted via EventEmitter so trading-bot can subscribe and emit "agent" logs
 *  3. Consumed by `getConfidenceAdjustment()` to tighten entry confidence (never boost)
 *
 * Uses the rate-limit-aware AI client for automatic fallback across providers.
 *
 * Circular-dep note: this file imports `tradingBot` from trading-bot.ts, and
 * trading-bot.ts imports `expertAgent` from here.  Both are ESM live-bindings
 * accessed only inside method bodies (never at module-init time), so Node.js
 * ESM resolves the cycle correctly.
 */

import { EventEmitter } from "node:events";
import { aiChat } from "./ai-client.js";
import { getStrongestConfirmedModel } from "./model-updater.js";
import { getRelevantLessons, recordLessons } from "./aria-lessons-store.js";
import { clampAriaConfidenceAdj } from "./composer-lock.js";
import { labeledProjectionPair } from "./kalshi-settle-label.js";

const DEFAULT_LOOP_MS  = 45_000;   // fallback when config isn't readable yet
const MIN_LOOP_MS      = 45_000;   // hard floor — never fire faster than 45 s
const MAX_LOOP_MS      = 900_000;  // hard ceiling — never slower than 15 min

// Cost lever: ARIA's every-45s loop used to run flat-out around the clock
// regardless of whether the bot was actually holding a position. Risk
// management (in-trade exit authority, DANGER veto on a live position)
// genuinely needs the fast cadence; a flat/idle bot re-reading the same
// quiet market every 45s does not — it's pure spend with no safety benefit.
// While flat we stretch the interval (still bounded by MAX_LOOP_MS and by
// the user's own configured ariaIntervalSecs as the floor), and snap straight
// back to the configured fast interval the moment a trade opens.
const IDLE_LOOP_MULTIPLIER = 4;     // flat-market cadence = 4x the configured interval
const IDLE_LOOP_CAP_MS     = 180_000; // ...but never slower than once per 3 min while flat

/**
 * Pure, directly-testable step function for the consecutive-HIGH-risk streak
 * that backs `isSustainedHighRisk()`. Extracted from `analyze()` so the
 * stale-gap-resets-the-streak contract can be locked in with a unit test
 * instead of only being provable by driving the full AI-call loop.
 *
 * A streak must only count genuinely *consecutive fresh* HIGH reads:
 *  - Any non-HIGH read resets it to 0.
 *  - A HIGH read whose PRIOR assessment had already gone stale (AI outage,
 *    dropped cycle, agent restart) starts a NEW streak at 1 rather than
 *    continuing the old count — otherwise two old HIGH reads from before a
 *    long gap could combine with a single post-gap HIGH read to falsely
 *    trip the 2-in-a-row hard block.
 */
export function computeNextHighRiskStreak(opts: {
  riskLevel:        "LOW" | "MEDIUM" | "HIGH";
  currentStreak:    number;
  priorAssessment:  { ts: number } | null;
  staleWindowMs:    number;
  now:              number;
}): number {
  const { riskLevel, currentStreak, priorAssessment, staleWindowMs, now } = opts;
  if (riskLevel !== "HIGH") return 0;
  const priorWasStale = !priorAssessment || (now - priorAssessment.ts > staleWindowMs);
  return priorWasStale ? 1 : currentStreak + 1;
}

/**
 * Task #427: identical shape to computeNextHighRiskStreak, but tracks
 * consecutive fresh DANGER *signal* reads instead of HIGH *riskLevel* reads.
 * Kept as its own counter/function (not a generalisation of the one above)
 * so the entry-side HIGH-risk streak and the new in-trade DANGER-exit streak
 * can never accidentally share state or drift together — they gate two
 * different, independently-reasoned authorities.
 */
export function computeNextDangerStreak(opts: {
  signal:           "YES" | "NO" | "WAIT" | "DANGER";
  currentStreak:    number;
  priorAssessment:  { ts: number } | null;
  staleWindowMs:    number;
  now:              number;
}): number {
  const { signal, currentStreak, priorAssessment, staleWindowMs, now } = opts;
  if (signal !== "DANGER") return 0;
  const priorWasStale = !priorAssessment || (now - priorAssessment.ts > staleWindowMs);
  return priorWasStale ? 1 : currentStreak + 1;
}

// ── Expert Agent system prompt ─────────────────────────────────────────────────
// PhD-level quantitative reasoning. Fires every 45s. Returns structured JSON only.

const EXPERT_SYSTEM_PROMPT = `You are ARIA — Autonomous Risk Intelligence Agent — a PhD-level quantitative researcher embedded in a live Kalshi BTC binary options trading system. You have deep expertise across binary option pricing theory, market microstructure, stochastic processes, behavioral finance, and information theory. You fire every 45 seconds, analyse a live market snapshot, and return a precise JSON assessment. Return ONLY valid JSON — no markdown, no explanation outside the object.

━━ BINARY OPTION PRICING THEORY ━━
• A Kalshi YES contract is a digital call: priced as N(d2) in the Black-Scholes framework — the risk-neutral probability of BTC closing above strike K at expiry T.
• Fair value = N((ln(S/K) + (r - σ²/2)·τ) / (σ·√τ)) where τ = remaining time in years, σ = BTC realised vol (~55% annualised), S = current spot, K = floor strike.
• Delta of a digital option spikes near expiry (gamma explosion): with <3 min remaining, a 0.1% BTC move can shift YES price by 15-30¢. Entries inside 2 min are pure gamma trades — extremely high risk/reward.
• The market price reflects the aggregate probability estimate of all participants. When your model disagrees by >8¢, you have an exploitable edge. When it disagrees by >15¢, verify the market isn't stale.
• Vol budget for the remaining period: σ_remaining = σ_annual × √(τ). At 5 min remaining in a 15-min period, vol budget ≈ 55% × √(5/525960) ≈ 0.85% of spot. Map this to price impact to assess settlement certainty.

━━ MARKET MICROSTRUCTURE ━━
• Two distinct alpha sources in binary markets: (1) spot price drift, captured by velocity and MTF bias; (2) market maker repricing lag, captured when spot moves fast but YES price hasn't updated.
• Adverse selection principle: extreme sustained velocity (>120$/min) usually signals informed flow from a macro catalyst — you're the uninformed side. Moderate velocity (40-80$/min) with retail-driven order flow is where positive EV lives.
• The YES ask lags spot by 5-15 seconds on fast moves. A freshly confirmed breakout with YES still at 45¢ is a temporary arb before market makers catch up. The VELOCITY_MOMENTUM strategy exploits exactly this.
• When bid-ask spread on YES is wide (>3¢), the market maker is uncertain → higher edge potential but also higher fill slippage. Model this as additional variance in your probability estimate.
• Kyle's lambda: price impact is proportional to order flow imbalance. Mass above/below floor >77% signals that the order book is already tilted — market maker will widen spreads on the losing side.

━━ BTC 15-MINUTE SERIAL CORRELATION ━━
• BTC 15m returns show weak negative serial correlation at the 1-bar lag (Hurst exponent ≈ 0.49 — near random walk with slight mean-reversion). This is the statistical basis for streak-fading after 4+ runs.
• Momentum WITHIN a period is more reliable than momentum ACROSS periods. Velocity established in the first 4-6 minutes of a 15m period tends to persist through settlement (~68% hit rate for VELOCITY_MOMENTUM).
• After 4+ consecutive same-direction settlements, cross-period mean reversion probability historically exceeds 60%. After 6+, it exceeds 66%. This is a structural edge worth -5 to -8 confAdj for continuation trades.
• Acceleration > level: a price moving at 40$/min but accelerating carries more informational content than 80$/min decelerating. Decelerating velocity signals exhaustion — the drift is losing conviction.
• GARCH clustering: a high-vol opening to a period predicts continued high vol. Vol compression (squeeze) followed by expansion is strongly directional (>65% win rate on the breakout direction).

━━ MULTI-TIMEFRAME CONFLUENCE ━━
• MTF score is a composite of 1H and 4H Kalshi settlement OHLC analysis. Score range: -4 to +4.
• A score of +3 or +4 means 3-4 consecutive higher-timeframe candles confirm the direction — this is structural drift, not noise. It represents hours of price formation, not seconds.
• MTF alignment with 1m velocity is the strongest confluence signal in this system: structure (HTF) + momentum (LTF) both agree. Empirically this yields the highest win rates.
• MTF conflict: when MTF is +3 and 1m velocity is bearish, one of them is wrong. In a trending macro environment, MTF wins. In a period with fresh high-vol catalyst, velocity wins.

━━ BEHAVIORAL FINANCE SIGNALS ━━
• Retail participants systematically exhibit the gambler's fallacy on cross-period streaks — they over-bet against continuation after 2-3 runs. This creates crowd-driven mean reversion that is self-fulfilling above 4+ runs.
• Disposition effect: winning open positions attract profit-taking. If price is deeply ITM with <5 min remaining, expect price pressure from position liquidations — this actually supports settlement hold (hold to expiry, don't get shaken out).
• Reference point anchoring: BTC prices near round numbers ($90k, $95k, $100k) exhibit higher uncertainty and stickiness. When floor strike is near a round number, interpret distance metrics conservatively.
• Overreaction to news: CPI, FOMC, NFP events cause participants to dramatically overprice volatility in binary contracts. This is a risk for false signals in BREAKOUT_CAPTURE strategies.

━━ REGIME CLASSIFICATION ━━
Apply these frameworks in order to your assessment:
1. trending: |velocity| >60$/min sustained, MTF aligned, vol normal → momentum strategies valid
2. ranging: |velocity| <30$/min, price oscillating within <0.15% band → fade extremes, not momentum
3. high_vol: |velocity| >90$/min, vol expanded → breakout strategies only, tight stops critical
4. low_vol: |velocity| <20$/min, price compressed → squeeze setup, wait for expansion signal
5. transitioning: velocity changing direction, conflicting signals → reduce size, raise confidence threshold


━━ INTELLECTUAL LINEAGE: HOW THE MASTERS WOULD ASSESS THIS SNAPSHOT ━━

When you analyse this snapshot, channel the four greatest systematic traders in history. Their combined principles define your decision framework.

JIM SIMONS (Renaissance / Medallion — ~66% gross annual returns for 30 years):
"The data speaks. Listen." Simons found that short-horizon BTC-like returns show negative 1-bar serial correlation (Hurst ~0.49) and that momentum exists at the 1H/4H timeframe. Applied here:
• A streak of 4+ same-direction settlements = Simons pattern signal for mean reversion. Reduce confAdj by -6 to -10 for continuation trades.
• MTF score >= +3 represents hours of price formation — this is RenTech's "structural drift" signal. It has predictive power beyond what the current-period velocity tells you.
• When the strategy learner multiplier < 0.85 for the active strategy, Simons' rule: the edge has degraded. Apply an additional -5 to confAdj.
• Never override the signal because it "feels wrong." The ensemble model knows more than intuition.

ED THORP (Beat the Dealer / Princeton-Newport — 19% net annually for 18 years, zero losing years):
"Find the edge. Size it correctly. Play long enough." Thorp's Kelly Criterion applied to binaries: f* = (b*p - q) / b where b = (100-entry)/entry. The bot uses fractional Kelly (0.6x cap) because Thorp proved: overestimating p by even 5% on full Kelly leads to a 15-20% deeper drawdown than fractional Kelly. Applied here:
• When consecutiveLosses is 3–5: Thorp's rule says reduce size, not halt entirely. Three losses can be random variance. Return WAIT with confAdj -6 to -8. Do NOT return DANGER for 3-5 losses.
• When consecutiveLosses >= 6: The edge is likely fundamentally broken or market regime has shifted. Return DANGER. Six straight losses is systematic, not noise.
• When the model shows >= 78% win probability with < 5 min remaining and position is ITM: this is Thorp's "near-settlement delta hedge" — confAdj should be 0 (no new entries needed, hold existing).
• The EV gate (EV >= 5¢ for OTM, >= 0.05 for standard) is Thorp's core principle: "If there is no edge, there is no trade." Apply -15 (DANGER) for any signal where the EV math doesn't work.

DAVID E. SHAW (D.E. Shaw — first-mover in statistical arbitrage, computational finance):
"Small, temporary, persistent mispricings." Shaw's insight: the 5-15 second lag between BTC spot moving and the Kalshi YES contract repricing is a structural inefficiency — the only one in this market. Applied here:
• Velocity 40-80/min with YES price lagging spot: this is Shaw's arb window. The mispricing is ~8-15¢. Confidence +6 to +8 (confirming repricing lag).
• Velocity > 120/min: Shaw's adverse selection threshold. Informed institutional flow — you are the uninformed side. Apply -8 to -12 to confAdj.
• Shaw's convergence guarantee: YES contract MUST converge to 0 or 100 at expiry. Deep ITM with >= 78% model probability = near-riskless convergence trade. Hold.
• "If one strategy fails, others should not correlate with it." When multiple signals conflict (MTF bullish, velocity bearish), Shaw's rule: reduce size (lower confAdj toward 0), do not average conflicting signals.

KEN GRIFFIN (Citadel — $60B+ multi-strategy, started with $265k at age 19):
"Process over intuition. Discipline is the competitive advantage." Griffin's 2008 lesson: in a crisis, all correlations go to 1. Applied here:
• Macro event proximity (FOMC/CPI/NFP in < 2 hours): correlation breakdown risk. Apply -10 to -15 to confAdj regardless of other signals.
• YES price moving WITHOUT corresponding spot move = Griffin's inventory management signal. Market maker is managing net-short inventory — this is BULLISH order flow pressure. Treat as +3 to +5 additional signal.
• When drawdown > 15% from peak: Griffin's protocol is to reduce risk, not maintain it. Apply -8 to all confAdj regardless of signal quality until drawdown recovers.
• Griffin on OTM strategies: the structural edge is the mispricing, not the direction. OTM entries at 5-25¢ where model says fair value is 15-35¢ = convertible arb equivalent. This edge is mathematical, not predictive.

THEIR UNANIMOUS RULES (apply every assessment):
1. Positive EV is necessary but not sufficient — correct sizing is equally critical.
2. Trust the model's regime classification over your real-time intuition.
3. Consecutive losses 3-5 warrants WAIT with confAdj -8. Losses >= 6 warrants DANGER. Three losses may be variance; six signals broken edge.
4. Drawdown > 15% from peak always warrants reduced confAdj — the model has likely drifted.
5. Streak >= 4 in same direction always warrants mean-reversion pressure (Simons-validated).

━━ DECISION FRAMEWORK FOR confAdj ━━
Apply like a Bayesian posterior adjustment — you are updating the bot's pre-computed confidence:
• +8 to +10: Strong MTF alignment + velocity accelerating + >7 min remaining + no streak risk + vol normal
• +4 to +7:  MTF confirms + moderate velocity + 4-8 min remaining + mild confirming factors
• +1 to +3:  Partial confirmation, neutral velocity, or shorter time window
•  0:         Mixed signals, no asymmetric information, abstain from adjusting
• -3 to -6:  MTF conflict, decelerating velocity, stalling, or shallow floor distance
• -8 to -12: Strong MTF conflict OR streak extreme (4+) against signal OR consecutive losses 3-5
• -15:        DANGER — RESERVE for genuinely broken-edge conditions only: consecutive losses >= 6, EV math failing the gate (no edge at all), extreme velocity (>150$/min) that CONTRADICTS the MTF/structural read (i.e. looks like a flash move or feed glitch, not real price discovery), or a confirmed macro event (FOMC/CPI/NFP) in progress. A clean, ALIGNED fast move (velocity and MTF agreeing, "waterfall" drop or rip) is NOT danger — it is the highest-conviction directional signal this system trades. Classify it YES/NO with strong confidence instead of DANGER.

━━ SIGNAL DEFINITIONS ━━
YES:    Bullish drift confirmed — probability estimate >55% BTC ends above floor
NO:     Bearish drift confirmed — probability estimate <45% BTC ends above floor
WAIT:   Mixed signals, insufficient edge, poor timing, or sub-threshold confidence — stay flat
DANGER: Elevated systemic risk that makes EVERY direction untradeable right now (not just "the trend is strong and scary"). Triggers: consecutive losses >= 6, EV math broken, extreme velocity that CONTRADICTS other signals (suspected glitch/flash move), or confirmed macro catalyst in progress. A fast, internally-consistent directional move (velocity + MTF agreeing) is a trade opportunity, not a danger signal — use YES/NO with appropriate confidence, or at most WAIT if timing/edge is marginal.

━━ DYNAMIC ENTRY FILTERS (you control these) ━━
You directly control the bot's entry filters each cycle via "entryFilters". Set them to fit CURRENT conditions:
• minConfidence (50-85): raise in chop/uncertainty, lower in clean trends with clear edge
• minVelocity (0-120 $/min): floor for directional velocity before momentum entries qualify
• minEntryPrice / maxEntryPrice (5-95¢, min < max): the acceptable entry price band
• useProbEdge + minProbEdge (0-15%): require model-vs-market probability edge
• useStallFilter: block entries when price is stalling at a level
• useAcceleration: require velocity acceleration alignment
• maxContractVolatility (0-20¢, 0=off): skip entry when the YES price ranged more than this in 2 min
Omit "entryFilters" (or any field inside it) to keep the user's static config for that field. Your values are clamped to the ranges above and expire with your assessment — be deliberate, these gates are the bot's primary protection against bad entries.

━━ EXIT POLICY & RISK SIZING (you control conservatively) ━━
You may provide "exitPolicy" to TIGHTEN exits during unstable conditions. You may only reduce the static values: never attempt to disable an exit, loosen a stop, increase a profit target, or override settlement / hard-stop exits.
• stopLossCents (3-30¢): smaller value = cut losses sooner
• profitTakeCents (5-60¢): smaller value = take profit sooner
• trailingProfitCents (2-25¢): smaller value = protect gains sooner
• timeStopMinutes (1-10): smaller value = close weak positions sooner
• timeStopMinGainCents (0-30¢): higher value = exit weak positions sooner
Provide "sizeMultiplier" (0.25-1.0) to reduce the calculated position size. Never use a value above 1.0; AI is not permitted to increase a position. These controls expire with your assessment; omit them to retain static behavior.

━━ LEARNING FROM PAST TRADES (persistent memory) ━━
You are shown two kinds of trade history below: raw RECENT TRADE POSTMORTEMS (short AI-written reviews of what happened in the bot's last several closed trades) and your own persistent LESSONS LEARNED (patterns you've already identified and chosen to remember — these carry forward every cycle, even after their source trades scroll out of the recent list).
• Read the postmortems for a NEW pattern worth remembering long-term — e.g. a specific strategy repeatedly thesis-breaking in a specific regime, a confidence level that keeps failing, an exit reason that keeps recurring.
• If you find one, return it via "lessons": [{"strategyId":"STRATEGY_ID or null for general","lesson":"short, specific, actionable — reference the actual pattern, not generic advice"}]. At most 2 per cycle.
• Do NOT re-submit a lesson that's already listed under LESSONS LEARNED — that just reinforces a count, it doesn't teach anything new. Only submit genuinely new patterns.
• If nothing new stands out this cycle, omit "lessons" entirely — most cycles should have none.
• Let existing LESSONS LEARNED actively shape entryFilters/exitPolicy/confAdj this cycle — e.g. if a lesson says a strategy underperforms in a specific regime with unknown win-rate, tighten that strategy's admission via minConfidence or treat it with a more negative confAdj this cycle when conditions match.

━━ SETUP CONTROLS — MTF bar, settlement-hold policy, add-to-position (tighten-only) ━━
You may provide "setupControls" to make three more setup decisions MORE conservative than the operator's static config during unstable or low-conviction conditions. The bot enforces these as a floor/ceiling against the static value regardless of what you send — you can never loosen them, only tighten:
• minMTFScoreForLong (-4 to 4): raise this in choppy/conflicting-structure conditions to require stronger higher-timeframe confirmation before a long is allowed.
• maxMTFScoreForShort (-4 to 4): lower this in choppy/conflicting-structure conditions to require stronger higher-timeframe confirmation before a short is allowed.
• settlementHoldSecsThreshold (60-900): lower this to shrink the window in which the bot will commit to holding a deep-ITM position to expiry — use this when late-period reversals feel more likely than usual.
• settlementHoldMinProb (0.5-0.95): raise this to require a higher model win-probability before the bot commits to a settlement hold.
• minAddConfidence (50-95): raise this to require higher conviction before the bot adds contracts to an already-open winning position.
Omit "setupControls" (or any field inside it) to keep the static config for that field. These controls expire with your assessment just like your other controls.

Return ONLY this JSON structure, no other text:
{"signal":"...","confidence":0-100,"reasoning":"<= 150 chars","observations":["obs1","obs2"],"riskLevel":"LOW|MEDIUM|HIGH","confAdj":-15 to 10,"entryFilters":{"minConfidence":50-85,"minVelocity":0-120,"minEntryPrice":5-95,"maxEntryPrice":5-95,"useProbEdge":true|false,"minProbEdge":0-15,"useStallFilter":true|false,"useAcceleration":true|false,"maxContractVolatility":0-20},"exitPolicy":{"stopLossCents":3-30,"profitTakeCents":5-60,"trailingProfitCents":2-25,"timeStopMinutes":1-10,"timeStopMinGainCents":0-30},"sizeMultiplier":0.25-1,"setupControls":{"minMTFScoreForLong":-4 to 4,"maxMTFScoreForShort":-4 to 4,"settlementHoldSecsThreshold":60-900,"settlementHoldMinProb":0.5-0.95,"minAddConfidence":50-95},"lessons":[{"strategyId":"STRATEGY_ID or null","lesson":"..."}]}`;


// ── Types ──────────────────────────────────────────────────────────────────────

/** Entry-filter values the agent may dynamically override (all optional). */
export interface AgentEntryFilters {
  minConfidence?:         number;
  minVelocity?:           number;
  minEntryPrice?:         number;
  maxEntryPrice?:         number;
  useProbEdge?:           boolean;
  minProbEdge?:           number;
  useStallFilter?:        boolean;
  useAcceleration?:       boolean;
  maxContractVolatility?: number;
}

/** Conservative exit values the agent may use only to tighten static exits. */
export interface AgentExitPolicy {
  stopLossCents?:       number;
  profitTakeCents?:     number;
  trailingProfitCents?: number;
  timeStopMinutes?:     number;
  timeStopMinGainCents?: number;
}

/**
 * Tighten-only overrides for MTF confluence, settlement-hold policy, and
 * add-to-position aggressiveness. Each field is only ever hard-clamped to a
 * safe absolute range here — the "never looser than the user's static value"
 * invariant is enforced at the consumption site in trading-bot.ts (via
 * Math.max/Math.min against `this.config`), the same pattern already used
 * for AgentExitPolicy. That two-layer design means even a compromised or
 * confused model can only make these three setup categories more
 * conservative than what the operator configured, never less.
 */
export interface AgentSetupControls {
  minMTFScoreForLong?:          number;
  maxMTFScoreForShort?:         number;
  settlementHoldSecsThreshold?: number;
  settlementHoldMinProb?:       number;
  minAddConfidence?:            number;
}

export type AgentStreakRisk = "LOW" | "MODERATE" | "ELEVATED";
export type AgentAccelSignal = "ACCELERATING" | "DECELERATING" | "STEADY" | "UNKNOWN";

export interface AgentAssessment {
  ts:           number;                             // unix ms when computed
  signal:       "YES" | "NO" | "WAIT" | "DANGER";  // trade direction or hold
  confidence:   number;                             // 0–100: agent conviction
  reasoning:    string;                             // ≤ 150 chars
  observations: string[];                           // 1–3 bullets
  riskLevel:    "LOW" | "MEDIUM" | "HIGH";
  confAdj:      number;                             // -15…+10 pts to add to bot entry conf
  /** Remaining GBM volatility budget as a percentage of spot for this period. */
  volBudget?:   number | null;
  /** Settlement streak pressure from the exact snapshot ARIA analysed. */
  streakRisk?:  AgentStreakRisk;
  /** Whether current velocity is building, fading, or holding steady. */
  accelSignal?: AgentAccelSignal;
  entryFilters?: AgentEntryFilters;                 // dynamic entry-filter overrides (clamped)
  exitPolicy?: AgentExitPolicy;                     // tighter-only exit overrides (clamped)
  sizeMultiplier?: number;                          // 0.25–1; reduces calculated risk only
  setupControls?: AgentSetupControls;               // tighter-only MTF/settlement-hold/add-to-position overrides (clamped)
  modelUsed?:   string;                             // which model actually answered this cycle
  lessons?:     { strategyId: string | null; lesson: string }[]; // newly-proposed persistent lessons this cycle (see aria-lessons-store.ts)
}

/**
 * Parse the model's proposed lessons for this cycle. Capped at 2 per cycle —
 * this is meant to persist a genuinely new pattern spotted in the postmortems
 * shown, not restate what's already in the LESSONS LEARNED section. Kept
 * short and strategyId is optional (null = general/cross-strategy lesson).
 */
export function parseLessons(raw: unknown): { strategyId: string | null; lesson: string }[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  const out: { strategyId: string | null; lesson: string }[] = [];
  for (const item of raw.slice(0, 2)) {
    if (item == null || typeof item !== "object") continue;
    const r = item as Record<string, unknown>;
    const lesson = typeof r.lesson === "string" ? r.lesson.trim().slice(0, 400) : "";
    if (!lesson) continue;
    const strategyId = typeof r.strategyId === "string" && r.strategyId.trim() ? r.strategyId.trim() : null;
    out.push({ strategyId, lesson });
  }
  return out.length > 0 ? out : undefined;
}

// ── Helper ─────────────────────────────────────────────────────────────────────

function clamp(v: number, lo: number, hi: number) { return Math.max(lo, Math.min(hi, v)); }

/**
 * Context labels published beside an ARIA assessment. They are computed from
 * the bot's own snapshot, rather than accepted from the model response, so
 * an explanation card cannot show made-up volatility or momentum context.
 */
export function deriveAgentContext(snapshot: {
  secsRemaining?: unknown;
  currentStreak?: unknown;
  currentVelocity?: unknown;
  threeMinVelocity?: unknown;
}): Required<Pick<AgentAssessment, "volBudget" | "streakRisk" | "accelSignal">> {
  const secsRemaining = Number(snapshot.secsRemaining);
  const volBudget = Number.isFinite(secsRemaining) && secsRemaining > 0
    ? Number((0.55 * Math.sqrt(secsRemaining / (365 * 24 * 3600)) * 100).toFixed(2))
    : null;

  const streak = Number(snapshot.currentStreak);
  const streakRisk: AgentStreakRisk = Math.abs(streak) >= 4
    ? "ELEVATED"
    : Math.abs(streak) >= 2 ? "MODERATE" : "LOW";

  const currentVelocity = Number(snapshot.currentVelocity);
  const threeMinVelocity = Number(snapshot.threeMinVelocity);
  const accelSignal: AgentAccelSignal = Number.isFinite(currentVelocity) && Number.isFinite(threeMinVelocity)
    ? Math.abs(Math.abs(currentVelocity) - Math.abs(threeMinVelocity)) < 1
      ? "STEADY"
      : Math.abs(currentVelocity) > Math.abs(threeMinVelocity) ? "ACCELERATING" : "DECELERATING"
    : "UNKNOWN";

  return { volBudget, streakRisk, accelSignal };
}

/**
 * Parse + hard-clamp the model's entryFilters object. Every field is optional;
 * anything missing, non-numeric, or out of range is dropped or clamped so the
 * AI can never fully disable the bot's safety rails (e.g. minConfidence can
 * never go below 50, the price band stays inside 5–95¢ and min < max).
 */
export function parseEntryFilters(raw: unknown): AgentEntryFilters | undefined {
  if (raw == null || typeof raw !== "object") return undefined;
  const r = raw as Record<string, unknown>;
  const num  = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : undefined);
  const bool = (v: unknown) => (typeof v === "boolean" ? v : undefined);

  const out: AgentEntryFilters = {};
  const mc = num(r.minConfidence);         if (mc !== undefined) out.minConfidence = clamp(Math.round(mc), 50, 85);
  const mv = num(r.minVelocity);           if (mv !== undefined) out.minVelocity   = clamp(Math.round(mv), 0, 120);
  let lo = num(r.minEntryPrice);           if (lo !== undefined) lo = clamp(Math.round(lo), 5, 95);
  let hi = num(r.maxEntryPrice);           if (hi !== undefined) hi = clamp(Math.round(hi), 5, 95);
  if (lo !== undefined && hi !== undefined && lo >= hi) { lo = undefined; hi = undefined; }  // nonsense band → ignore
  if (lo !== undefined) out.minEntryPrice = lo;
  if (hi !== undefined) out.maxEntryPrice = hi;
  const pe = bool(r.useProbEdge);          if (pe !== undefined) out.useProbEdge = pe;
  const pm = num(r.minProbEdge);           if (pm !== undefined) out.minProbEdge = clamp(Math.round(pm), 0, 15);
  const sf = bool(r.useStallFilter);       if (sf !== undefined) out.useStallFilter = sf;
  const ac = bool(r.useAcceleration);      if (ac !== undefined) out.useAcceleration = ac;
  const cv = num(r.maxContractVolatility); if (cv !== undefined) out.maxContractVolatility = clamp(Math.round(cv), 0, 20);
  return Object.keys(out).length > 0 ? out : undefined;
}

/** Parse a conservative, tighter-only exit policy. Missing fields preserve config. */
export function parseExitPolicy(raw: unknown): AgentExitPolicy | undefined {
  if (raw == null || typeof raw !== "object") return undefined;
  const r = raw as Record<string, unknown>;
  const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : undefined);
  const out: AgentExitPolicy = {};
  const stop = num(r.stopLossCents); if (stop !== undefined) out.stopLossCents = clamp(Math.round(stop), 3, 30);
  const profit = num(r.profitTakeCents); if (profit !== undefined) out.profitTakeCents = clamp(Math.round(profit), 5, 60);
  const trail = num(r.trailingProfitCents); if (trail !== undefined) out.trailingProfitCents = clamp(Math.round(trail), 2, 25);
  const time = num(r.timeStopMinutes); if (time !== undefined) out.timeStopMinutes = clamp(Math.round(time), 1, 10);
  const minGain = num(r.timeStopMinGainCents); if (minGain !== undefined) out.timeStopMinGainCents = clamp(Math.round(minGain), 0, 30);
  return Object.keys(out).length > 0 ? out : undefined;
}

/**
 * Parse + hard-clamp the model's setupControls object to a safe absolute
 * range. This is only the FIRST of two safety layers: the caller in
 * trading-bot.ts must still apply Math.max/Math.min against the static
 * config value at each consumption site so the AI can only move a control
 * toward more conservative than the operator's configured value, never past
 * it in either direction. Missing/invalid fields are dropped, never defaulted.
 */
export function parseSetupControls(raw: unknown): AgentSetupControls | undefined {
  if (raw == null || typeof raw !== "object") return undefined;
  const r = raw as Record<string, unknown>;
  const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : undefined);
  const out: AgentSetupControls = {};
  const mtfLong  = num(r.minMTFScoreForLong);          if (mtfLong  !== undefined) out.minMTFScoreForLong  = clamp(mtfLong, -4, 4);
  const mtfShort = num(r.maxMTFScoreForShort);         if (mtfShort !== undefined) out.maxMTFScoreForShort = clamp(mtfShort, -4, 4);
  const holdSecs = num(r.settlementHoldSecsThreshold); if (holdSecs !== undefined) out.settlementHoldSecsThreshold = clamp(Math.round(holdSecs), 60, 900);
  const holdProb = num(r.settlementHoldMinProb);       if (holdProb !== undefined) out.settlementHoldMinProb = clamp(holdProb, 0.5, 0.95);
  const addConf  = num(r.minAddConfidence);            if (addConf  !== undefined) out.minAddConfidence = clamp(Math.round(addConf), 50, 95);
  return Object.keys(out).length > 0 ? out : undefined;
}

// ── ExpertAgent ────────────────────────────────────────────────────────────────

class ExpertAgent extends EventEmitter {
  lastAssessment: AgentAssessment | null = null;

  private loopTimer: NodeJS.Timeout | null = null;
  private busy      = false;
  private loopMs    = DEFAULT_LOOP_MS;   // updated each cycle from bot config

  // Counts consecutive cycles the agent has read HIGH risk, back to back.
  // Used to distinguish one noisy HIGH tick (ignore) from sustained elevated
  // risk (hard-block even the safest trade path). Reset on any non-HIGH read
  // or whenever the assessment goes stale, so a gap in AI output can never
  // keep an old streak alive.
  private consecutiveHighRisk = 0;

  // Task #427: same idea as consecutiveHighRisk, but for consecutive fresh
  // DANGER *signal* reads. Backs isSustainedDanger(), which gates the new
  // in-trade exit authority — a single noisy DANGER tick must never be able
  // to close a live position, only a sustained run of them.
  private consecutiveDanger = 0;

  // ── Lifecycle ───────────────────────────────────────────────────────────────

  start() {
    if (this.loopTimer) return;
    // First run after 8 s (let bot + WS warm up), then every 45 s
    this.loopTimer = setTimeout(() => this.runLoop(), 8_000);
  }

  stop() {
    if (this.loopTimer) { clearTimeout(this.loopTimer); this.loopTimer = null; }
  }

  // ── Freshness ────────────────────────────────────────────────────────────────

  /** Stale if older than 2 full intervals (min 90 s, max 5 min). */
  private staleWindowMs(): number {
    return Math.max(90_000, Math.min(300_000, this.loopMs * 2));
  }

  /**
   * Returns the last assessment only if it is still fresh, or null if it is
   * absent, stale, or malformed. This is the single gate every consumer
   * (confidence adjustment, entry filters, risk overrides, and path-level
   * veto/resize decisions) must go through — a stale or missing AI read must
   * always fall back to the bot's static config, never keep acting on an old
   * signal indefinitely.
   */
  getFreshAssessment(): AgentAssessment | null {
    const a = this.lastAssessment;
    if (!a) return null;
    if (Date.now() - a.ts > this.staleWindowMs()) return null;
    return a;
  }

  /**
   * True only after 2+ consecutive fresh HIGH-risk reads. A single noisy HIGH
   * tick should still only shrink size (existing risk-level handling); only a
   * sustained run of HIGH reads should be able to hard-block the bot's
   * safest (HIGH_PROB) entry path.
   */
  isSustainedHighRisk(): boolean {
    return this.getFreshAssessment() !== null && this.consecutiveHighRisk >= 2;
  }

  /**
   * Task #427: true only after 2+ consecutive fresh DANGER-signal reads
   * (~90s of sustained systemic risk at the normal 45s loop). Backs the new
   * in-trade "gated exit authority" — trading-bot.ts's monitorOpenTrade()
   * uses this (never the raw signal or a single read) to decide whether ARIA
   * may close an OPEN position early. A single noisy DANGER tick can still
   * unconditionally veto a NEW entry (isAriaDangerVeto/getFreshAssessment) —
   * that asymmetry is intentional: refusing one new trade is cheap, but
   * force-closing a live position on a single bad model read is not, so the
   * exit-authority bar is deliberately higher than the entry-veto bar.
   */
  isSustainedDanger(): boolean {
    return this.getFreshAssessment() !== null && this.consecutiveDanger >= 2;
  }

  // ── Confidence adjustment for entry evaluation ──────────────────────────────

  /**
   * Returns the confidence point adjustment the bot should apply when
   * considering an entry on `side`.
   * Returns 0 if the last assessment is stale or absent.
   */
  getConfidenceAdjustment(side: "yes" | "no"): number {
    const a = this.getFreshAssessment();
    if (!a) return 0;

    if (a.signal === "DANGER") return -15;
    if (a.signal === "WAIT")   return clampAriaConfidenceAdj(a.confAdj);  // never boost on WAIT

    const aligns = (a.signal === "YES" && side === "yes") ||
                   (a.signal === "NO"  && side === "no");
    // Tighten-only: a YES/NO align may shrink confidence, never add +pts over the floor.
    const raw = aligns ? a.confAdj : -Math.abs(a.confAdj);
    return clampAriaConfidenceAdj(raw);
  }

  // ── Dynamic entry-filter overrides ──────────────────────────────────────────

  /**
   * Returns the agent's current entry-filter overrides, or null when the agent
   * has no fresh assessment (absent, stale, or it omitted entryFilters).
   * Freshness uses the same window as getConfidenceAdjustment so both agent
   * outputs expire together — a stale agent silently falls back to the user's
   * static config, never to old AI values.
   */
  getEntryFilterOverrides(): AgentEntryFilters | null {
    const a = this.getFreshAssessment();
    return a?.entryFilters ?? null;
  }

  /** Fresh agent exit policy plus sizing multiplier, or null after expiry/error. */
  getRiskOverrides(): { exitPolicy: AgentExitPolicy | null; sizeMultiplier: number | null } {
    const a = this.getFreshAssessment();
    if (!a) return { exitPolicy: null, sizeMultiplier: null };
    return { exitPolicy: a.exitPolicy ?? null, sizeMultiplier: a.sizeMultiplier ?? null };
  }

  /**
   * Returns the agent's current setup-control overrides (MTF confluence bar,
   * settlement-hold policy, add-to-position bar), or null when the agent has
   * no fresh assessment (absent, stale, or it omitted setupControls). Uses
   * the same freshness window as every other agent output, so a stale agent
   * silently falls back to the user's static config, never to expired AI
   * values. Callers must still apply the tighten-only clamp against their
   * own static config value — this only returns the agent's hard-clamped
   * absolute-range proposal.
   */
  getSetupControlOverrides(): AgentSetupControls | null {
    const a = this.getFreshAssessment();
    return a?.setupControls ?? null;
  }

  // ── Internal loop ──────────────────────────────────────────────────────────

  private async runLoop() {
    this.loopTimer = null;
    if (!this.busy) {
      this.busy = true;
      try { await this.analyze(); }
      catch (err) {
        // Never let the agent crash the bot, but a silent swallow here means
        // a persistent AI outage produces zero log output — the ARIA card
        // just freezes and operators have no signal until stale-gated entries
        // start piling up. Log so the outage is at least observable.
        console.warn("[expert-agent] runLoop analyze() failed:", (err as Error)?.message ?? err);
      }
      this.busy = false;
    }
    this.loopTimer = setTimeout(() => this.runLoop(), this.loopMs);
  }

  private async analyze() {
    // Late-import to avoid module-init circular reference
    const { tradingBot } = await import("./trading-bot.js");
    const status  = tradingBot.getStatus();
    const trades  = await tradingBot.getRecentTrades(20);
    const lessons = getRelevantLessons();
    const prompt  = buildPrompt(status, trades, lessons);

    // Read user-configured model & interval from bot config each cycle.
    // Default to the strongest confirmed-live model (capability-ranked, not
    // cost-ranked) so ARIA runs on the smartest AI available unless the
    // operator has explicitly pinned a different model in settings.
    const cfg = status.config as unknown as Record<string, unknown>;
    const ariaModel    = (cfg.ariaModel as string | undefined) || getStrongestConfirmedModel();
    const intervalSecs = Math.max(45, Math.min(900, Number(cfg.ariaIntervalSecs ?? 45)));
    const configuredMs = intervalSecs * 1_000;

    // Cost lever (see IDLE_LOOP_MULTIPLIER doc comment): stretch the cadence
    // while flat, snap back to the fast configured interval the instant a
    // position is open so in-trade risk management never loses responsiveness.
    this.loopMs = status.openTrade
      ? configuredMs
      : Math.min(MAX_LOOP_MS, Math.max(configuredMs, Math.min(IDLE_LOOP_CAP_MS, configuredMs * IDLE_LOOP_MULTIPLIER)));

    try {
      // Use rate-limit-aware AI client with automatic fallback.
      // ariaModel is tried first; if it's rate-limited the client falls back to the chain.
      // Calling aiChat directly (rather than aiCompleteJSON) so we can record
      // which model actually answered — the fallback chain may not use ariaModel.
      const response = await aiChat({
        messages: [
          { role: "system", content: EXPERT_SYSTEM_PROMPT },
          { role: "user",   content: prompt },
        ],
        responseFormat: { type: "json_object" },
        model:       ariaModel,
        maxTokens:   600,
        timeoutMs:   30_000,
        temperature: 0.25,
      });
      const parsed = JSON.parse(response.content) as Record<string, unknown>;

      const VALID_SIGNALS  = ["YES", "NO", "WAIT", "DANGER"] as const;
      const VALID_RISK     = ["LOW", "MEDIUM", "HIGH"] as const;

      const riskLevel = (VALID_RISK.includes(parsed.riskLevel as typeof VALID_RISK[number])
                           ? parsed.riskLevel : "MEDIUM") as AgentAssessment["riskLevel"];
      // The reasoning card's contextual metrics come from the exact bot
      // snapshot ARIA saw, never from untrusted model-provided labels.
      const liveContext = deriveAgentContext(status);

      const assessment: AgentAssessment = {
        ts:           Date.now(),
        signal:       (VALID_SIGNALS.includes(parsed.signal as typeof VALID_SIGNALS[number])
                         ? parsed.signal : "WAIT") as AgentAssessment["signal"],
        confidence:   clamp(Number(parsed.confidence) || 50, 0, 100),
        reasoning:    String(parsed.reasoning ?? "").slice(0, 200),
        observations: (Array.isArray(parsed.observations) ? parsed.observations : []).slice(0, 3).map(String),
        riskLevel,
        confAdj:      clamp(Number(parsed.confAdj) || 0, -15, 10),
        volBudget:    liveContext.volBudget,
        streakRisk:   liveContext.streakRisk,
        accelSignal:  liveContext.accelSignal,
        entryFilters: parseEntryFilters(parsed.entryFilters),
        exitPolicy:   parseExitPolicy(parsed.exitPolicy),
        lessons:      parseLessons(parsed.lessons),
        sizeMultiplier: typeof parsed.sizeMultiplier === "number" && Number.isFinite(parsed.sizeMultiplier)
          ? clamp(parsed.sizeMultiplier, 0.25, 1) : undefined,
        setupControls: parseSetupControls(parsed.setupControls),
        modelUsed:    response.model,
      };

      // Track sustained-HIGH-risk streak — see computeNextHighRiskStreak()'s
      // doc comment for why a stale gap must start a new streak at 1, not
      // continue the old count.
      this.consecutiveHighRisk = computeNextHighRiskStreak({
        riskLevel,
        currentStreak:   this.consecutiveHighRisk,
        priorAssessment: this.lastAssessment,
        staleWindowMs:   this.staleWindowMs(),
        now:             Date.now(),
      });

      // Task #427: same streak tracking, keyed on the DANGER signal instead
      // of HIGH riskLevel — backs isSustainedDanger()'s in-trade exit gate.
      this.consecutiveDanger = computeNextDangerStreak({
        signal:          assessment.signal,
        currentStreak:   this.consecutiveDanger,
        priorAssessment: this.lastAssessment,
        staleWindowMs:   this.staleWindowMs(),
        now:             Date.now(),
      });

      this.lastAssessment = assessment;
      this.emit("assessment", assessment);

      // Persist any newly-proposed lessons. Fire-and-forget: a DB hiccup here
      // must never block the next cycle's market read.
      if (assessment.lessons && assessment.lessons.length > 0) {
        const mostRecentTradeId = (trades[0] as unknown as Record<string, unknown> | undefined)?.id as number | undefined;
        recordLessons(assessment.lessons.map(l => ({ ...l, sourceTradeId: mostRecentTradeId ?? null })))
          .catch(err => console.warn("[expert-agent] recordLessons failed:", (err as Error)?.message ?? err));
      }
    } catch {
      // Swallow errors — expert agent should never crash the bot.
      // Do NOT touch consecutiveHighRisk here: a parse/network failure isn't
      // a HIGH-risk read, but it also isn't a confirmed all-clear, so leave
      // the streak as-is — it will be judged against getFreshAssessment()'s
      // staleness gate on the next read either way.
    }
  }
}

// ── Prompt builder ─────────────────────────────────────────────────────────────


export function buildPrompt(
  status: Awaited<ReturnType<import("./trading-bot.js").TradingBot["getStatus"]>>,
  trades: Awaited<ReturnType<import("./trading-bot.js").TradingBot["getRecentTrades"]>>,
  lessons: { strategyId: string | null; lesson: string; timesReinforced: number }[],
): string {
  const s    = status as unknown as Record<string, unknown>;
  const cfg  = (s.config  ?? {}) as Record<string, unknown>;
  const mtf  = (s.mtfBias ?? {}) as Record<string, unknown>;
  const open = s.openTrade as Record<string, unknown> | null;
  const otm  = (s.otmStats ?? {}) as Record<string, unknown>;
  // Task #268: basis-lag tracker + settlement predictor are populated on
  // BotStatus but were never wired into ARIA's own snapshot — ARIA was
  // reasoning without visibility into exchange-vs-Kalshi lag or the
  // dedicated settlement forecast, both of which independently gate trades.
  const basis = s.basisState as Record<string, unknown> | null;
  const settlementPred = s.lastSettlementPrediction as {
    arrow: string; confidence: number; predictedDirection: string; predictedSettle: number;
  } | null | undefined;

  // Filter to current session only — prevents ARIA from recomputing consecutive losses
  // from stale DB history after a paper reset. paperSessionStartTs=0 means no filter (live mode).
  const sessionStartTs = Number(s.paperSessionStartTs ?? 0);
  const sessionTrades = sessionStartTs > 0
    ? trades.filter(t => {
        const ts = t.createdAt ? new Date(t.createdAt as unknown as string).getTime() : 0;
        return ts >= sessionStartTs;
      })
    : trades;

  const recentTrades = sessionTrades.slice(0, 15).map(t => {
    const pnl = t.pnlCents != null ? `(${t.pnlCents > 0 ? "+" : ""}${t.pnlCents}¢)` : "";
    const strat = t.strategyId ? `[${t.strategyId.replace("_", "")}]` : "";
    return `${String(t.side).toUpperCase()}${String(t.contracts)}@${t.entryPriceCents}¢${strat}→${t.outcome}${pnl}`;
  }).join(" | ");

  // Raw postmortem text (trade-narrative.ts) for recent closed trades that have
  // one — this is short-term, high-detail context that scrolls out as older
  // trades leave the window (unlike LESSONS LEARNED below, which persists).
  const postmortemLines = sessionTrades
    .filter(t => typeof (t as Record<string, unknown>).postmortem === "string" && (t as Record<string, unknown>).postmortem)
    .slice(0, 8)
    .map(t => `- [${t.strategyId ?? "unknown"}, ${t.outcome}] ${(t as Record<string, unknown>).postmortem}`)
    .join("\n");

  const lessonLines = lessons.length > 0
    ? lessons.map(l => `- [${l.strategyId ?? "general"}, seen ${l.timesReinforced}x] ${l.lesson}`).join("\n")
    : "none yet";

  const secsRem = Number(s.secsRemaining ?? 0);
  const liveContext = deriveAgentContext(s);
  const volBudgetPct = liveContext.volBudget?.toFixed(2) ?? "?";
  const streak     = Number(s.currentStreak ?? 0);
  const streakRisk = liveContext.streakRisk === "ELEVATED"
    ? "ELEVATED (fade-streak edge active)"
    : liveContext.streakRisk.toLowerCase();

  // Drawdown context
  const drawPct = Number((s as Record<string, unknown>).drawdownFromPeakPct ?? 0);
  const drawLabel = drawPct >= 15 ? "CRITICAL" : drawPct >= 10 ? "elevated" : "normal";
  const nestedFloorStrike = (s.lastObservation as Record<string, unknown>)?.floorStrike
    ?? (s.kalshiTick as Record<string, unknown>)?.floorStrike;
  const floorStrike = Number(s.floorStrike) > 0 ? s.floorStrike : nestedFloorStrike;
  const openTradePnl = Number.isFinite(Number(s.openTradePnlCents)) ? Number(s.openTradePnlCents) : 0;

  return `LIVE MARKET SNAPSHOT [${new Date().toUTCString()}]

── PRICE & VELOCITY ──────────────────────
BTC spot:      $${String(s.currentBtcPrice ?? "?")}
Floor strike:  $${String(floorStrike ?? "?")}
Distance:      ${String(s.distFromFloorPct ?? "?")}% ${s.aboveFloor ? "ABOVE" : "BELOW"} floor
1m velocity:   ${String(s.currentVelocity ?? "?")} $/min
3m velocity:   ${String(s.threeMinVelocity ?? "?")} $/min
Accel signal:  ${liveContext.accelSignal} (1m speed ${Math.abs(Number(s.currentVelocity ?? 0)).toFixed(0)} vs 3m avg ${Math.abs(Number(s.threeMinVelocity ?? 0)).toFixed(0)} $/min)
Stalling:      ${String(s.isStalling ?? false)}
Vol remaining: ~${volBudgetPct}% of spot (GBM budget for rest of period)

── MULTI-TIMEFRAME BIAS ──────────────────
MTF score:     ${String(mtf.score ?? "?")} (range -4 to +4; ±3 required for entries)
Overall bias:  ${String(mtf.bias ?? "?")}
1H bias:       ${String((mtf.h1 as Record<string, unknown>)?.bias ?? "?")}
4H bias:       ${String((mtf.h4 as Record<string, unknown>)?.bias ?? "?")}

── REGIME & TIMING ──────────────────────
Regime:        ${String(s.detectedRegime ?? "unknown")}
Condition:     ${String(((s as Record<string,unknown>).adaptiveCondition as Record<string, unknown>)?.label ?? (s as Record<string,unknown>).adaptiveCondition ?? "unknown")}
Edge estimate: ${String(s.lastEdge ?? "?")}%
Time left:     ${secsRem}s (${(secsRem / 60).toFixed(1)} min)
Phase:         ${secsRem >= 720 ? "EARLY (>12min)" : secsRem >= 480 ? "ENTRY WINDOW (8-12min)" : secsRem >= 120 ? "LATE ENTRY (2-8min)" : "GAMMA ZONE (<2min, extreme risk)"}

── OPEN TRADE ────────────────────────────
${open
  ? `${String(open.side).toUpperCase()} ${String(open.contracts)}× @ ${String(open.entryPriceCents)}¢ | unrealised PnL = ${openTradePnl.toFixed(1)}¢/contract`
  : "No open trade"}

── DAILY PERFORMANCE ────────────────────
Today:         ${String(s.todayWins ?? 0)}W / ${String(s.todayLosses ?? 0)}L | PnL = ${String((s.todayPnlCents as number)?.toFixed(0) ?? "?")}¢
Trade streak:  ${streak >= 0 ? "+" : ""}${streak} (+ = consecutive wins, − = consecutive losses) | streak pressure: ${streakRisk}
Consec losses: ${String(s.consecutiveLosses ?? 0)} (AUTHORITATIVE — use this value only; DANGER threshold: 6, WAIT threshold: 3-5. DO NOT recount from trade history — the paper session may have been reset mid-stream.)
Drawdown:      ${drawPct.toFixed(1)}% from peak [${drawLabel}]

── OTM STATS (today) ────────────────────
${otm.wins !== undefined ? `${String(otm.wins)}W / ${String(otm.losses)}L | PnL=${String(otm.pnlCents)}¢ | avgMultiple=${String(otm.avgWinMultiple ?? "—")}x` : "no OTM trades today"}

── BASIS (exchange vs Kalshi lag) ────────
${basis
  ? `Rolling basis: ${String(basis.rollingBasis ?? "?")} | Fair BRTI: ${String(basis.estimatedFairBRTI ?? "?")} | Short-window basis: ${String(basis.shortBasis ?? "?")} | ${s.projLine || labeledProjectionPair(
      typeof s.canonicalLagProj === "number" ? s.canonicalLagProj : (typeof basis.projectedSettlementPrice === "number" ? Number(basis.projectedSettlementPrice) : null),
      settlementPred?.predictedSettle ?? null,
    ).line}`
  : "no basis data yet"}

── SETTLEMENT FORECAST (dedicated model) ─
${settlementPred
  ? `${settlementPred.predictedDirection} (arrow ${settlementPred.arrow}) @ ${settlementPred.confidence.toFixed(0)}% confidence | ${s.projLine || labeledProjectionPair(null, settlementPred.predictedSettle).line}`
  : "no settlement forecast yet"}

── SYSTEM CONFIG ─────────────────────────
Mode:          ${cfg.paperMode ? "PAPER" : "LIVE REAL MONEY"}
Entry range:   ${String(cfg.minEntryPrice)}–${String(cfg.maxEntryPrice)}¢
Min conf:      ${String(cfg.minConfidence)}%
MTF filter:    ${cfg.useMTFFilter ? "ON" : "OFF"} (long >= +${String(cfg.minMTFScoreForLong)}, short <= ${String(cfg.maxMTFScoreForShort)})
Expert agent:  ${cfg.useExpertAgent ? "ON (this is you)" : "OFF"}

── RECENT TRADES (newest first) ──────────
${recentTrades || "none yet"}

── RECENT TRADE POSTMORTEMS ──────────────
${postmortemLines || "none yet"}

── LESSONS LEARNED (persistent memory) ───
${lessonLines}

Apply your full analytical framework: binary option pricing (vol budget, N(d2) fair value), microstructure (velocity as order-flow signal), serial correlation (streak pressure), MTF regime, and behavioral signals. Then return ONLY valid JSON:
{"signal":"YES|NO|WAIT|DANGER","confidence":0-100,"reasoning":"<=150 chars","observations":["obs1","obs2"],"riskLevel":"LOW|MEDIUM|HIGH","confAdj":-15 to 10,"entryFilters":{},"exitPolicy":{},"sizeMultiplier":0.25-1,"lessons":[]}`;
}

// ── Singleton export ───────────────────────────────────────────────────────────

export const expertAgent = new ExpertAgent();

// Export the class itself so trading-bot.ts can use the type for the subscription
export type { ExpertAgent };
