/**
 * Display mapping: Kalshi YES/NO from tape/close-vs-floor, never paper W/L
 * or period up/down. Closed rows do not read as "settled unknown".
 */
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  kxbct15mPeriodUtcIso,
  kxbtc15mCloseUtcIso,
  dirSettleFromRow,
  lookupKalshiSettleForTrade,
  enrichBotTradesForDisplay,
  mergePersistedStoryWithKnownSettle,
  overlayKnownSettleInWhatHappened,
} from "./bot-trades-display.js";
import { settlementPhrase, collapsedStoryFields, coerceTradeStory, buildTradeStory } from "./trade-story.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));

test("D6: KXBTC15M ticker hhmm is the ET CLOSE; period key is the START (close − 15m)", () => {
  assert.equal(kxbtc15mCloseUtcIso("KXBTC15M-26SEP021315-15"), "2026-09-02T17:15:00.000Z");
  assert.equal(kxbct15mPeriodUtcIso("KXBTC15M-26SEP021315-15"), "2026-09-02T17:00:00.000Z");
  assert.equal(kxbct15mPeriodUtcIso("KXBTC15M-26SEP022200-00"), "2026-09-03T01:45:00.000Z");
  // Audit case: 191130 closes 15:30Z, so its period starts 15:15Z (not 191145's 15:30Z).
  assert.equal(kxbct15mPeriodUtcIso("KXBTC15M-26SEP191130-30"), "2026-09-19T15:15:00.000Z");
});

test("D6: settle label for 191130 comes from its own period, not the next contract", () => {
  const tape = {
    settleByTicker: new Map(),
    storyByTradeId: new Map(),
    dirByPeriod: new Map([
      ["2026-09-19T15:15:00.000Z", { btcClose: 81554.02, floorStrike: 81689.73, settledSide: "NO" as const }],
      ["2026-09-19T15:30:00.000Z", { btcClose: 81800, floorStrike: 81554.02, settledSide: "YES" as const }],
    ]),
  };
  assert.equal(lookupKalshiSettleForTrade({ ticker: "KXBTC15M-26SEP191130-30" }, tape).settledSide, "NO");
});

test("D11: DST fall-back hour is ambiguous from ET text → null; Kalshi UTC close_time wins", () => {
  // Nov 1 2026 01:15 ET happens twice (EDT 05:15Z and EST 06:15Z).
  assert.equal(kxbtc15mCloseUtcIso("KXBTC15M-26NOV010115-15"), null);
  assert.equal(kxbct15mPeriodUtcIso("KXBTC15M-26NOV010115-15", "2026-11-01T06:15:00Z"), "2026-11-01T06:00:00.000Z");
  // Unambiguous EST after the change.
  assert.equal(kxbtc15mCloseUtcIso("KXBTC15M-26NOV020115-15"), "2026-11-02T06:15:00.000Z");
});

test("settlement-directions uses close vs floor, never up/down", () => {
  assert.equal(dirSettleFromRow({ direction: "up", floorStrike: 65000, settledPrice: 64990 })?.settledSide, "NO");
  assert.equal(dirSettleFromRow({ direction: "down", floorStrike: 65000, settledPrice: 65010 })?.settledSide, "YES");
  assert.equal(dirSettleFromRow({ direction: "up" }), null);
});

test("lookup prefers official/tape settle; does not use PnL sign", () => {
  const tape = {
    settleByTicker: new Map([["KXBTC15M-26SEP021315-15", "NO" as const]]),
    storyByTradeId: new Map(),
    dirByPeriod: new Map(),
  };
  const looked = lookupKalshiSettleForTrade({
    ticker: "KXBTC15M-26SEP021315-15",
    floorStrike: 77_000,
  }, tape);
  assert.equal(looked.settledSide, "NO");
  const official = lookupKalshiSettleForTrade({
    ticker: "KXBTC15M-26SEP021315-15",
    settledSide: "YES",
  }, tape);
  assert.equal(official.settledSide, "YES", "official Kalshi field wins over tape");
});

test("enrich attaches YES/NO story for a closed early dump", () => {
  const tapeTicker = "KXBTC15M-26SEP021400-00";
  const period = kxbct15mPeriodUtcIso(tapeTicker)!;
  const rows = enrichBotTradesForDisplay([{
    id: 509,
    ticker: tapeTicker,
    side: "yes",
    signal: "LONG",
    outcome: "loss",
    pnlCents: -296,
    exitReason: "HARD_STOP_EXIT",
    fillOrigin: "bot",
    strategyId: "BASIS_LAG_EDGE",
    contracts: 18,
    entryPriceCents: 36,
    isPaper: true,
    orderId: "paper-509",
    floorStrike: 77_000,
    settledSide: null,
  }]);
  // without tape in env this may be unknown; lookup via injected dir:
  const looked = lookupKalshiSettleForTrade({
    ticker: tapeTicker,
    floorStrike: 77_000,
  }, {
    settleByTicker: new Map(),
    storyByTradeId: new Map(),
    dirByPeriod: new Map([[period, { btcClose: 77_200, floorStrike: 77_000, settledSide: "YES" }]]),
  });
  assert.equal(looked.settledSide, "YES");
  void rows;
  void period;
});

test("settlementPhrase: early exits paint sold early · settled when Kalshi YES/NO known", () => {
  // Doctrine: known settle always in settle slot; early exits keep sold early too.
  assert.equal(
    settlementPhrase({ settlement: "YES", outcome: "loss", pnlCents: -10, soldEarly: true, exitReason: "PATH_RIDE_HA_FLIP" }),
    "sold early · settled YES",
  );
  assert.equal(
    settlementPhrase({ settlement: "YES", outcome: "loss", pnlCents: -144, exitReason: "HARD_STOP_EXIT" }),
    "sold early · settled YES",
  );
  assert.equal(
    settlementPhrase({ settlement: "NO", outcome: "win", pnlCents: 12, exitReason: "PATH_RIDE_TP" }),
    "sold early · settled NO",
  );
  // Held-to-expiry only paints settled YES/NO (no sold early).
  assert.equal(
    settlementPhrase({ settlement: "YES", outcome: "win", pnlCents: 42, holdToSettlement: true, exitReason: "SETTLEMENT" }),
    "settled YES",
  );
  assert.equal(
    settlementPhrase({ settlement: "NO", outcome: "loss", pnlCents: -40, holdToSettlement: true, exitReason: "SETTLED_KALSHI" }),
    "settled NO",
  );
  assert.equal(settlementPhrase({ settlement: "unknown", outcome: "pending" }), "pending");
  assert.equal(settlementPhrase({ settlement: "unknown", outcome: "loss", pnlCents: -50, exitReason: "HARD_STOP" }), "sold early");
  assert.doesNotMatch(settlementPhrase({ settlement: "unknown", outcome: "win", pnlCents: 169, exitReason: "PATH_RIDE_TP" }), /Kalshi unset|unsettled/i);
  const collEarly = collapsedStoryFields({
    side: "yes",
    outcome: "loss",
    pnlCents: -144,
    settledSide: "YES",
    exitReason: "PATH_RIDE_HA_FLIP",
  });
  assert.equal(collEarly.result, "LOSS");
  assert.equal(collEarly.settlePhrase, "sold early · settled YES");
  assert.match(collEarly.line, /YES · LOSS · sold early · settled YES/);
  assert.notEqual(collEarly.settlePhrase, "settled YES");
  const collHold = collapsedStoryFields({
    side: "yes",
    outcome: "win",
    pnlCents: 42,
    settledSide: "YES",
    exitReason: "SETTLEMENT",
    holdToSettlement: true,
  });
  assert.equal(collHold.result, "WIN");
  assert.match(collHold.line, /YES · WIN · settled YES/);
});

// Doctrine (Sep 24): WIN/LOSS follows realized fee-net P&L sign, not settle side.
test("YES+settled YES held with −P&L = LOSS (label follows fee-net P&L)", () => {
  const coll = collapsedStoryFields({
    side: "yes",
    outcome: "loss",
    pnlCents: -10,
    settledSide: "YES",
    exitReason: "SETTLEMENT",
    holdToSettlement: true,
  });
  assert.equal(coll.result, "LOSS");
  assert.equal(coll.settlePhrase, "settled YES");
  assert.match(coll.line, /YES · LOSS · settled YES/);
});

test("cancelled → ORPHAN not SKIP_N/A", () => {
  const coll = collapsedStoryFields({ side: "yes", outcome: "cancelled", pnlCents: 0 });
  assert.equal(coll.result, "ORPHAN");
  assert.equal(coll.settlePhrase, "orphan");
  assert.doesNotMatch(coll.line, /SKIP_N\/A/);
});

test("GET /bot/trades maps enrichBotTradesForDisplay; paperMode stays true in display helper", () => {
  const routes = readFileSync(path.join(DIR, "../routes/bot.ts"), "utf8");
  const disp = readFileSync(path.join(DIR, "bot-trades-display.ts"), "utf8");
  assert.match(routes, /enrichBotTradesForDisplay/);
  assert.match(disp, /PAPER_MODE = true/);
  assert.doesNotMatch(disp, /paperMode\s*=\s*false/);
  assert.doesNotMatch(disp, /ENABLE_/);
});

test("early-exit LOSS + known Kalshi YES: sold early · settled YES, never held-only settle W/L", () => {
  const persisted = {
    side: "YES" as const,
    settlement: "unknown" as const,
    result: "LOSS" as const,
    pnlCents: -144,
    setup: "YES 15× dump",
    entryReason: "YES 15× dump",
    strategy: "CONFLUENCE_CASCADE",
    duration: "16s",
    holdToSettlement: false,
    soldEarly: true,
    heldWrongSide: false,
    whatHappened: "CONFLUENCE_CASCADE YES sold early (16s), closed · Kalshi unset, LOSS -1.44. PATH_RIDE_HA_FLIP",
    exitReason: "PATH_RIDE_HA_FLIP",
    wentRight: [] as string[],
    wentWrong: ["Setup resolved against the position."],
    lessons: ["Keep floors."],
    ask: 44,
    mtf: 3,
    evCents: 35,
    p: 0.54,
    valid: true,
    river: false,
    holdMs: 15844,
    exitReasonCode: "PATH_RIDE_HA_FLIP",
    officialSettle: "unknown" as const,
    feeNetCents: -144,
    skipPnlCents: 0 as const,
    feeNetVsSkip: -144,
    counterfactual: { kind: "NO_TB" as const, actualExit: "PATH_RIDE_HA_FLIP", actualFeeNetCents: -144, altFeeNetCents: null, feeNetVsActual: null, skipPnlCents: 0 as const, wouldHaveWon: false, taughtWinner: "unknown" as const, autoApply: false, wiringBug: null, implementHoldToSettlement: false as const, organ: "none" as const, wentRight: [] as string[], lessons: [] as string[] },
  };
  const rebuilt = {
    ...persisted,
    settlement: "unknown" as const,
    officialSettle: "YES" as const,
    whatHappened: "CONFLUENCE_CASCADE YES sold early (16s), sold early, LOSS -1.44. PATH_RIDE_HA_FLIP",
    valid: null as boolean | null,
    river: null as boolean | null,
  };
  const merged = mergePersistedStoryWithKnownSettle(persisted, rebuilt, null, "YES");
  assert.ok(merged);
  assert.equal(merged!.officialSettle, "YES", "market fact kept on officialSettle");
  assert.equal(merged!.result, "LOSS");
  assert.equal(merged!.soldEarly, true);
  assert.equal(merged!.valid, true, "persisted thesis valid kept");
  assert.equal(merged!.river, false, "persisted riverValid kept");
  assert.match(merged!.whatHappened, /sold early · settled YES/);
  assert.equal(merged!.settlement, "YES");
  assert.doesNotMatch(merged!.whatHappened, /Kalshi unset/);
  // Must not be settled-only (fake held sole slot).
  assert.doesNotMatch(merged!.whatHappened, /\)\s*,\s*settled YES\s*,/);
  const stillUnknown = mergePersistedStoryWithKnownSettle(persisted, null, null, null);
  assert.equal(stillUnknown!.settlement, "unknown");
});

test("OPEN / ORPHAN display vocabulary — never SKIP_N/A for pending or empty", () => {
  assert.equal(settlementPhrase({ settlement: "unknown", outcome: "pending" }), "pending");
  assert.equal(settlementPhrase({ settlement: "unknown", outcome: null }), "orphan");
  assert.equal(settlementPhrase({ settlement: "unknown", outcome: "" }), "orphan");
  const pending = collapsedStoryFields({ side: "yes", outcome: "pending", pnlCents: 0 });
  assert.equal(pending.result, "OPEN");
  assert.doesNotMatch(pending.line, /SKIP_N\/A/);
  const orphan = collapsedStoryFields({ side: "no", outcome: null as any, pnlCents: null as any });
  assert.equal(orphan.result, "ORPHAN");
  assert.equal(orphan.settlePhrase, "orphan");
  assert.doesNotMatch(orphan.line, /SKIP_N\/A · open/);
  assert.equal(coerceTradeStory({ result: "OPEN" } as any)?.result, "OPEN");
  assert.equal(coerceTradeStory({ result: "ORPHAN" } as any)?.result, "ORPHAN");
  const built = buildTradeStory({
    fillOrigin: "bot",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    outcome: "pending",
    pnlCents: 0,
  });
  assert.equal(built?.result, "OPEN");
});

test("fee-net card PnL: pnlCents is fee-net; TradeRow nests fees (source lock)", () => {
  const botTsx = readFileSync(path.join(DIR, "../../../kalshi-trader/src/pages/bot.tsx"), "utf8");
  const rowStart = botTsx.indexOf("function TradeRow");
  assert.ok(rowStart >= 0);
  // TradeRow is large — take enough to cover expand fee-net block (~2.5k lines of JSX).
  const row = botTsx.slice(rowStart, rowStart + 40_000);
  assert.match(row, /data-feenet-pnl="true"/);
  assert.match(row, /P&L \(fee-net\):/);
  assert.match(row, /fees \$\{\(t\.feeCents \/ 100\)\.toFixed\(2\)\} included/);
  // Settled paths nest fees; no bare additive "Fees:" sibling on win/loss.
  assert.match(row, /outcome !== 'win' && t\.outcome !== 'loss'/);
});

test("overlayKnownSettleInWhatHappened: early exit paints sold early · settled; held paints settled", () => {
  const line = "CONFLUENCE_CASCADE YES sold early (16s), closed · Kalshi unset, LOSS -1.44. PATH_RIDE_HA_FLIP";
  const overEarly = overlayKnownSettleInWhatHappened(line, "YES", { soldEarly: true, holdToSettlement: false, exitReason: "PATH_RIDE_HA_FLIP", outcome: "loss", pnlCents: -144 });
  assert.match(overEarly, /sold early · settled YES/);
  assert.doesNotMatch(overEarly, /Kalshi unset/);
  assert.match(overEarly, /sold early \(16s\)/);
  assert.doesNotMatch(overEarly, /\)\s*,\s*settled YES\s*,/);
  const overHold = overlayKnownSettleInWhatHappened(
    "CONFLUENCE_CASCADE YES held to settlement (14m), closed · Kalshi unset, WIN +0.42. SETTLEMENT",
    "YES",
    { holdToSettlement: true, exitReason: "SETTLEMENT", outcome: "win", pnlCents: 42 },
  );
  assert.match(overHold, /settled YES/);
  assert.equal(settlementPhrase({ settlement: "NO", holdToSettlement: true, exitReason: "SETTLEMENT" }), "settled NO");
  assert.equal(
    overlayKnownSettleInWhatHappened("bare unset Kalshi unset tail", "NO", {
      soldEarly: true, holdToSettlement: false, outcome: "loss", pnlCents: -1,
    }),
    "bare unset sold early · settled NO tail",
  );
});

test("merge early-exit: known Kalshi stamps settlement + sold early · settled YES in whatHappened", () => {
  const persisted = {
    side: "YES" as const,
    settlement: "unknown" as const,
    result: "LOSS" as const,
    pnlCents: -144,
    setup: "YES dump",
    entryReason: "YES dump",
    strategy: "CONFLUENCE_CASCADE",
    duration: "16s",
    holdToSettlement: false,
    soldEarly: true,
    heldWrongSide: false,
    whatHappened: "CONFLUENCE_CASCADE YES sold early (16s), closed · Kalshi unset, LOSS -1.44. PATH_RIDE_HA_FLIP",
    exitReason: "PATH_RIDE_HA_FLIP",
    wentRight: [] as string[],
    wentWrong: ["against"],
    lessons: ["keep floors"],
    ask: 44,
    mtf: 3,
    evCents: 35,
    p: 0.54,
    valid: true,
    river: false,
    holdMs: 15844,
    exitReasonCode: "PATH_RIDE_HA_FLIP",
    officialSettle: "unknown" as const,
    feeNetCents: -144,
    skipPnlCents: 0 as const,
    feeNetVsSkip: -144,
    counterfactual: { kind: "NO_TB" as const, actualExit: "PATH_RIDE_HA_FLIP", actualFeeNetCents: -144, altFeeNetCents: null, feeNetVsActual: null, skipPnlCents: 0 as const, wouldHaveWon: false, taughtWinner: "unknown" as const, autoApply: false, wiringBug: null, implementHoldToSettlement: false as const, organ: "none" as const, wentRight: [] as string[], lessons: [] as string[] },
  };
  const rebuiltUnknownSettle = {
    ...persisted,
    settlement: "unknown" as const,
    officialSettle: "unknown" as const,
    whatHappened: "CONFLUENCE_CASCADE YES sold early (16s), sold early, LOSS -1.44. PATH_RIDE_HA_FLIP",
    valid: null as boolean | null,
    river: null as boolean | null,
  };
  const merged = mergePersistedStoryWithKnownSettle(persisted, rebuiltUnknownSettle, null, "YES");
  assert.equal(merged!.officialSettle, "YES");
  assert.equal(merged!.settlement, "YES");
  assert.match(merged!.whatHappened, /sold early · settled YES/);
  assert.doesNotMatch(merged!.whatHappened, /\)\s*,\s*settled YES\s*,/);
  assert.doesNotMatch(merged!.whatHappened, /Kalshi unset/);
  assert.equal(merged!.valid, true);
  const noRebuild = mergePersistedStoryWithKnownSettle(persisted, null, null, "NO");
  assert.equal(noRebuild!.officialSettle, "NO");
  assert.equal(noRebuild!.settlement, "NO");
  assert.match(noRebuild!.whatHappened, /sold early · settled NO/);
  assert.doesNotMatch(noRebuild!.whatHappened, /\)\s*,\s*settled NO\s*,/);
});

test("TradeRow cash Δ: fee-net primary; muted cash Δ only when balances diverge (source lock)", () => {
  const botTsx = readFileSync(path.join(DIR, "../../../kalshi-trader/src/pages/bot.tsx"), "utf8");
  const rowStart = botTsx.indexOf("function TradeRow");
  assert.ok(rowStart >= 0);
  const row = botTsx.slice(rowStart, rowStart + 45_000);
  assert.match(row, /cashDeltaCents/);
  assert.match(row, /cashDivergesFromFeeNet/);
  assert.match(row, /data-cash-delta="true"/);
  assert.match(row, /cash Δ/);
  assert.match(row, /data-feenet-pnl="true"/);
  // Never additive fees on win/loss
  assert.match(row, /fees \$\{\(t\.feeCents \/ 100\)\.toFixed\(2\)\} included/);
  assert.match(row, /outcome !== 'win' && t\.outcome !== 'loss'/);
});

test("settlement audit: display exposes where the settle side came from (settledSource)", () => {
  const tape = {
    settleByTicker: new Map([["KXBTC15M-26SEP021315-15", "NO" as const]]),
    storyByTradeId: new Map(),
    dirByPeriod: new Map([["2026-09-19T15:15:00.000Z", { btcClose: 81554.02, floorStrike: 81689.73, settledSide: "NO" as const }]]),
  };
  assert.equal(lookupKalshiSettleForTrade({ ticker: "X", settledSide: "YES" }, tape).settledSource, "row");
  assert.equal(lookupKalshiSettleForTrade({ ticker: "KXBTC15M-26SEP021315-15" }, tape).settledSource, "paper_bar_tape");
  assert.equal(lookupKalshiSettleForTrade({ ticker: "KXBTC15M-26SEP191130-30" }, tape).settledSource, "period_recorder");
  assert.equal(lookupKalshiSettleForTrade({ ticker: "KXBTC15M-26SEP011200-00" }, { settleByTicker: new Map(), storyByTradeId: new Map(), dirByPeriod: new Map() }).settledSource, null);
});
