import assert from "node:assert/strict";
import test from "node:test";
import { decideAtPoint } from "./causal-sim.js";
import { POLICY_LEAN, POLICY_LEGACY } from "./sim-policy.js";
import { getStrategy, getAllStrategyMeta } from "../strategy-library.js";
import type { StrategyObservation, StrategyId } from "../strategy-library.js";

/**
 * GO — BACKTEST LAB v5 (2026-08-22): proves the two presets' `consensusMode`
 * actually changes the pipeline's admit decision through `decideAtPoint`,
 * not just in an isolated `checkStrategyConsensus` unit test.
 *
 * Every strategy except SQUEEZE_EXPANSION is forced to a neutral (STAY_OUT)
 * signal so exactly one strategy agrees, regardless of which pack (if any)
 * is enforced for the observation's regime/volume bucket — isolating the
 * `requireMode` behavior itself from pack-eligibility effects.
 */
function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65000,
    floorStrike: 65000,
    velocityDolPerMin: 40,     // above both policies' minVelocity (24)
    threeMinVelocity: 40,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0,
    massAboveFloor: 50,
    secsRemaining: 600,        // minute-5 decision window
    yesAsk: 55,
    noAsk: 45,
    // 'unclear' is the one condition-adapter overlay with an empty
    // suppressStrategies list (condition-adapter.ts's 'unclear'/default
    // case) — every other regime's overlay suppresses SQUEEZE_EXPANSION or
    // another likely solo candidate, which would confound this test's
    // isolation of `requireMode` from condition suppression.
    regime: "unclear",
    ...overrides,
  } as StrategyObservation;
}

test("BACKTEST LAB v5: LEAN (solo consensus) admits a single agreeing strategy; LEGACY (require2) blocks the same solo signal", () => {
  const soloId: StrategyId = "SQUEEZE_EXPANSION";
  const allIds = getAllStrategyMeta().map(m => m.id);
  const originals = new Map<string, any>();

  for (const id of allIds) {
    const strat = getStrategy(id as any);
    if (!strat) continue;
    originals.set(id, strat.evaluate);
    strat.evaluate = (id === soloId
      ? (() => ({ strategyId: soloId, strategyName: "Squeeze Expansion", signal: "YES", confidence: 0.75, reason: "forced solo test signal" }))
      : (() => ({ strategyId: id, strategyName: id, signal: "STAY_OUT", confidence: 0, reason: "neutral test stub" }))) as any;
  }

  try {
    // LEAN preset: packMode 'enforce' would restrict eligibility to the
    // RANGE pack's own list, which may or may not include SQUEEZE_EXPANSION
    // — force packMode 'off' via a local clone so this test isolates
    // `consensusMode` specifically, not pack-eligibility interaction (that
    // is covered separately by the pack tests in specialist-packs.test.ts).
    const leanNoPack = { ...POLICY_LEAN, packMode: 'off' as const };
    const legacyNoPack = { ...POLICY_LEGACY, packMode: 'off' as const };

    const leanDecision = decideAtPoint(baseObs(), leanNoPack);
    assert.equal(leanDecision.admitted, true, `LEAN (solo) should admit a lone agreeing strategy, got skipReason=${leanDecision.skipReason}`);
    assert.equal(leanDecision.strategyId, soloId);
    assert.equal(leanDecision.consensusCount, 1);

    const legacyDecision = decideAtPoint(baseObs(), legacyNoPack);
    assert.equal(legacyDecision.admitted, false, "LEGACY (require2) must block a lone agreeing strategy");
    assert.equal(legacyDecision.skipReason, "CONSENSUS");
    assert.equal(legacyDecision.consensusCount, 1);
  } finally {
    for (const [id, fn] of originals) {
      const strat = getStrategy(id as any);
      if (strat) strat.evaluate = fn;
    }
  }
});
