/**
 * kalshi-order-body.test.ts
 *
 * Regression tests for the bot's automated order-construction path.
 *
 * These tests guard against field-name mismatches between the internal
 * KalshiOrderInput representation (contracts / pricePerContract) and the
 * Kalshi V2 REST API body (count / price).  A silent field rename would
 * cause orders to be silently malformed; this suite catches that class of
 * regression.
 *
 * Run with:
 *   node --experimental-strip-types src/lib/kalshi-order-body.test.ts
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { buildKalshiV2Body, buildKalshiV2ExitBody, isValidKalshiPrice } from "./kalshi-order-body.js";

// ── 1. YES side: contracts → count (string), pricePerContract → price (dollars) ─

test("YES side: count equals String(contracts)", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 5, 45);
  assert.equal(body.count, "5", "contracts must map to count as a string");
});

test("YES side: price equals pricePerContract / 100 to 2 d.p.", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 5, 45);
  assert.equal(body.price, "0.45", "45¢ YES price must map to '0.45'");
});

test("YES side: V2 side is 'bid'", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 5, 45);
  assert.equal(body.side, "bid");
});

// ── 2. NO side: price is the YES equivalent (100 - pricePerContract) / 100 ──────

test("NO side: count equals String(contracts)", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "no", 3, 30);
  assert.equal(body.count, "3", "contracts must map to count as a string for NO trades");
});

test("NO side: price equals (100 - pricePerContract) / 100 to 2 d.p.", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "no", 3, 30);
  assert.equal(body.price, "0.70", "30¢ NO price must convert to YES equivalent '0.70'");
});

test("NO side: V2 side is 'ask'", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "no", 3, 30);
  assert.equal(body.side, "ask");
});

// ── 3. Field names: output must use Kalshi V2 names, not the input names ─────────
//    Guard: 'count' and 'price' must be present; 'contracts' and
//    'pricePerContract' must NOT be present in the wire body.

test("wire body uses 'count', not 'contracts'", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 2, 60) as unknown as Record<string, unknown>;
  assert.ok("count" in body,     "wire body must have 'count'");
  assert.ok(!("contracts" in body), "wire body must NOT have 'contracts'");
});

test("wire body uses 'price', not 'pricePerContract'", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 2, 60) as unknown as Record<string, unknown>;
  assert.ok("price" in body,              "wire body must have 'price'");
  assert.ok(!("pricePerContract" in body), "wire body must NOT have 'pricePerContract'");
});

// ── 4. Required V2 envelope fields are always present ────────────────────────────

test("wire body always includes required V2 envelope fields", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 1, 50);
  assert.equal(body.time_in_force,              "good_till_canceled");
  assert.equal(body.self_trade_prevention_type, "taker_at_cross");
  assert.equal(body.post_only,                  false);
  assert.equal(body.cancel_order_on_pause,      false);
  assert.equal(body.reduce_only,                false);
});

// ── 5. Price boundary values ──────────────────────────────────────────────────────

test("1¢ YES price maps to '0.01'", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 1, 1);
  assert.equal(body.price, "0.01");
});

test("99¢ YES price maps to '0.99'", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 1, 99);
  assert.equal(body.price, "0.99");
});

test("1¢ NO price maps to '0.99' YES equivalent", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "no", 1, 1);
  assert.equal(body.price, "0.99");
});

test("99¢ NO price maps to '0.01' YES equivalent", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "no", 1, 99);
  assert.equal(body.price, "0.01");
});

// ── 5b. isValidKalshiPrice — boundary acceptance/rejection ────────────────────────

test("isValidKalshiPrice: 0 is rejected (below minimum)", () => {
  assert.equal(isValidKalshiPrice(0), false, "0¢ is below the 1¢ minimum and must be rejected");
});

test("isValidKalshiPrice: 1 is accepted (minimum valid price)", () => {
  assert.equal(isValidKalshiPrice(1), true, "1¢ is the minimum valid price");
});

test("isValidKalshiPrice: 99 is accepted (maximum valid price)", () => {
  assert.equal(isValidKalshiPrice(99), true, "99¢ is the maximum valid price");
});

test("isValidKalshiPrice: 100 is rejected (above maximum)", () => {
  assert.equal(isValidKalshiPrice(100), false, "100¢ is above the 99¢ maximum and must be rejected");
});

// ── 6. ticker passes through unchanged ───────────────────────────────────────────

test("ticker is preserved verbatim in the wire body", () => {
  const ticker = "KXBTC15M-25Jul2024-B62000";
  const body = buildKalshiV2Body(ticker, "yes", 1, 50);
  assert.equal(body.ticker, ticker);
});

// ── 7. Multi-contract sizing ──────────────────────────────────────────────────────

test("count is always a string even for large contract counts", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 100, 50);
  assert.equal(typeof body.count, "string", "count must be a string");
  assert.equal(body.count, "100");
});

// ── 8. buildKalshiV2ExitBody — YES sell ──────────────────────────────────────────

test("EXIT YES sell: V2 side is 'ask'", () => {
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "yes", 3, 55, 0);
  assert.equal(body.side, "ask", "selling YES must use ask side");
});

test("EXIT YES sell: price equals exitPriceCents / 100 with no sweep buffer", () => {
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "yes", 3, 55, 0);
  assert.equal(body.price, "0.55", "55¢ exit with 0 sweep must map to '0.55'");
});

test("EXIT YES sell: sweep buffer is subtracted from exit price", () => {
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "yes", 3, 55, 6);
  assert.equal(body.price, "0.49", "55¢ - 6¢ sweep must map to '0.49'");
});

test("EXIT YES sell: price is clamped to minimum 0.01 after sweep", () => {
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "yes", 1, 3, 6);
  assert.equal(body.price, "0.01", "3¢ - 6¢ sweep must clamp to minimum '0.01'");
});

// ── 9. buildKalshiV2ExitBody — NO close ──────────────────────────────────────────

test("EXIT NO close: V2 side is 'bid'", () => {
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "no", 2, 30, 0);
  assert.equal(body.side, "bid", "closing NO must use bid side (buy YES)");
});

test("EXIT NO close: price equals YES-equivalent (100 - exitPriceCents) / 100 with no sweep", () => {
  // exitPriceCents is the YES price; closing NO means buying YES at 100 - 30 = 70¢
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "no", 2, 30, 0);
  assert.equal(body.price, "0.70", "30¢ NO position closed with 0 sweep: YES price = (100-30)/100 = '0.70'");
});

test("EXIT NO close: sweep buffer is added to the YES-equivalent price", () => {
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "no", 2, 30, 6);
  assert.equal(body.price, "0.76", "30¢ NO close with 6¢ sweep: YES price = (100-30+6)/100 = '0.76'");
});

test("EXIT NO close: YES-equivalent price is clamped to maximum 0.99 after sweep", () => {
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "no", 1, 5, 6);
  assert.equal(body.price, "0.99", "5¢ NO close + 6¢ sweep = 101¢ must clamp to maximum '0.99'");
});

// ── 10. buildKalshiV2ExitBody — shared envelope fields ───────────────────────────

test("EXIT body count equals String(contracts)", () => {
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "yes", 7, 50, 0);
  assert.equal(body.count, "7", "contracts must map to count as a string");
});

test("EXIT body includes required V2 envelope fields", () => {
  const body = buildKalshiV2ExitBody("KXBTC15M-25Jul2024-B62000", "yes", 1, 50, 0);
  assert.equal(body.time_in_force,              "good_till_canceled");
  assert.equal(body.self_trade_prevention_type, "taker_at_cross");
  assert.equal(body.post_only,                  false);
  assert.equal(body.cancel_order_on_pause,      false);
  // 2026-08-19 incident: reduce_only:true (added 2026-08-18 for a real but
  // rarer duplicate-exit-order risk) caused Kalshi's V2 order API to reject
  // EVERY exit order with HTTP 400 "invalid order" for ~1.5 days, so every
  // stop-loss/thesis-break exit silently failed and rode to settlement
  // instead. Reverted to false — the in-process pre-order position check in
  // exitEarly() (fetchKalshiPosition before every attempt) is the guard
  // against the original duplicate-order scenario instead.
  assert.equal(body.reduce_only,                false);
});

test("EXIT body ticker is preserved verbatim", () => {
  const ticker = "KXBTC15M-25Jul2024-B62000";
  const body = buildKalshiV2ExitBody(ticker, "yes", 1, 50, 0);
  assert.equal(body.ticker, ticker);
});

// ── 11. add-to-position path — field names match the entry order ──────────────────
//  The bot's addToPosition() method calls buildKalshiV2Body() with (ticker, side,
//  addContracts, addPrice) where addPrice comes from tick.yesAsk / tick.noAsk in
//  whole cents.  These tests confirm the resulting wire body uses the V2 field names
//  'count' and 'price', not the internal names 'contracts' / 'pricePerContract'.

test("add-to-position YES: wire body uses 'count', not 'contracts'", () => {
  // addPrice = tick.yesAsk = 48¢, addContracts = 1
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 1, 48) as unknown as Record<string, unknown>;
  assert.ok("count" in body,        "add-to-position body must have 'count'");
  assert.ok(!("contracts" in body), "add-to-position body must NOT have 'contracts'");
});

test("add-to-position YES: wire body uses 'price', not 'pricePerContract'", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 1, 48) as unknown as Record<string, unknown>;
  assert.ok("price" in body,                "add-to-position body must have 'price'");
  assert.ok(!("pricePerContract" in body),  "add-to-position body must NOT have 'pricePerContract'");
});

test("add-to-position YES: count is '1' for a single added contract", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 1, 48);
  assert.equal(body.count, "1", "single add-to-position must produce count '1'");
});

test("add-to-position YES: price equals yesAsk / 100 to 2 d.p.", () => {
  // tick.yesAsk = 48¢ → v2Price = "0.48"
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 1, 48);
  assert.equal(body.price, "0.48", "48¢ YES ask must map to '0.48'");
});

test("add-to-position YES: V2 side is 'bid' (buying YES contracts)", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 1, 48);
  assert.equal(body.side, "bid", "buying YES must use bid side");
});

test("add-to-position NO: count is '1' for a single added contract", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "no", 1, 35);
  assert.equal(body.count, "1", "single NO add-to-position must produce count '1'");
});

test("add-to-position NO: price equals (100 - noAsk) / 100 to 2 d.p.", () => {
  // tick.noAsk = 35¢ → YES-equivalent = (100 - 35) / 100 = "0.65"
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "no", 1, 35);
  assert.equal(body.price, "0.65", "35¢ NO ask must map to YES-equivalent '0.65'");
});

test("add-to-position NO: V2 side is 'ask' (buying NO contracts)", () => {
  const body = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "no", 1, 35);
  assert.equal(body.side, "ask", "buying NO must use ask side");
});
// ── 12. scaled-in position close — add uses entry body, close uses exit body ───────
//  A successful add-to-position increments openTrade.contracts. The later
//  exitEarly() call passes that full size to buildKalshiV2ExitBody(), rather
//  than reusing the add's entry body or losing the exit sweep.

test("scaled-in YES close: full count, exit field names, and sweep price are preserved", () => {
  const addBody = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "yes", 1, 48);
  const closeBody = buildKalshiV2ExitBody(
    addBody.ticker,
    "yes",
    2, // original contract plus the confirmed add-to-position contract
    48,
    4,
  ) as unknown as Record<string, unknown>;

  assert.equal(closeBody.count, "2", "closing a scaled-in position must use the full tracked count");
  assert.equal(closeBody.price, "0.44", "YES close must subtract the 4¢ sweep from the exit quote");
  assert.equal(closeBody.side, "ask", "closing YES must use the V2 ask side");
  assert.ok("count" in closeBody, "close wire body must use 'count'");
  assert.ok("price" in closeBody, "close wire body must use 'price'");
  assert.ok(!("contracts" in closeBody), "close wire body must not use internal 'contracts'");
  assert.ok(!("pricePerContract" in closeBody), "close wire body must not use internal 'pricePerContract'");
});

test("scaled-in NO close: full count and YES-equivalent sweep price are preserved", () => {
  const addBody = buildKalshiV2Body("KXBTC15M-25Jul2024-B62000", "no", 1, 35);
  const closeBody = buildKalshiV2ExitBody(
    addBody.ticker,
    "no",
    2, // original contract plus the confirmed add-to-position contract
    35,
    4,
  );

  assert.equal(closeBody.count, "2", "closing a scaled-in NO position must use the full tracked count");
  assert.equal(closeBody.price, "0.69", "NO close must add the 4¢ sweep to its 65¢ YES equivalent");
  assert.equal(closeBody.side, "bid", "closing NO must use the V2 bid side");
  assert.equal(closeBody.reduce_only, false, "close body must retain the API-compatible reduce_only value");
});

// ── D7: idempotent client_order_id ──────────────────────────────────────────
import { stableClientOrderId as _cid, buildKalshiV2Body as _b, buildKalshiV2ExitBody as _bx } from "./kalshi-order-body.js";
import { test as _t } from "node:test";
import _assert from "node:assert/strict";

_t("D7: same intent → same client_order_id; different intent → different", () => {
  assert_eq(_cid("entry", 72), _cid("entry", 72));
  _assert.notEqual(_cid("entry", 72), _cid("entry", 73));
  _assert.notEqual(_cid("exit", "k", 0, 0, 18), _cid("exit", "k", 0, 1, 18));
  _assert.ok(_cid("entry", 72).length <= 40 && _cid("entry", 72).startsWith("oc-entry-"));
});

_t("D7: bodies carry client_order_id only when given", () => {
  _assert.equal(_b("T", "yes", 1, 40, "oc-x").client_order_id, "oc-x");
  _assert.equal("client_order_id" in _b("T", "yes", 1, 40), false);
  _assert.equal(_bx("T", "no", 1, 40, 0, "oc-y").client_order_id, "oc-y");
});

function assert_eq(a: unknown, b: unknown) { _assert.equal(a, b); }
