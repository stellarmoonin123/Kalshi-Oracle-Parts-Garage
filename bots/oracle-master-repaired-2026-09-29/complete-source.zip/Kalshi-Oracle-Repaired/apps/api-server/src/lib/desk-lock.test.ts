import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import express from "express";
import cookieParser from "cookie-parser";
import type { AddressInfo } from "node:net";
import type { Server } from "node:http";
import {
  constantTimeEqual,
  deskInternalHeaders,
  createDeskSession,
  verifyDeskSession,
  createLoginRateLimiter,
  requireDeskLock,
  isDeskPublicPath,
  isDeskAuthorized,
  deskCookieOptions,
  DESK_SESSION_COOKIE,
} from "./desk-lock.js";

const PASS = "unit-test-passcode-xyz";
const PREV = process.env.DESK_ADMIN_TOKEN;
let server: Server;
let base = "";

before(async () => {
  process.env.DESK_ADMIN_TOKEN = PASS;
  const app = express();
  app.set("trust proxy", 1);
  app.use(express.json());
  app.use(cookieParser());
  app.use("/api", requireDeskLock);
  // routes/auth.ts is now the multi-user account login (accounts/middleware.ts
  // gate); the passcode login it used to host is retired. The lock middleware
  // itself (lib only, no longer mounted by app.ts) is still exercised here.
  app.post("/api/auth/login", (req, res) => {
    const given = typeof req.body?.passcode === "string" ? req.body.passcode : "";
    if (!constantTimeEqual(given, PASS)) { res.status(401).json({ error: "Incorrect passcode" }); return; }
    res.cookie(DESK_SESSION_COOKIE, createDeskSession(PASS), deskCookieOptions());
    res.json({ ok: true, deskLock: true });
  });
  app.get("/api/auth/me", (req, res) => { res.json({ authenticated: isDeskAuthorized(req, PASS), deskLock: true }); });
  app.get("/api/healthz", (_q, r) => { r.json({ ok: true }); });
  app.get("/api/bot/trades", (_q, r) => { r.json({ trades: [] }); });
  app.post("/api/bot/start", (_q, r) => { r.json({ started: true }); });
  server = app.listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
after(() => {
  server?.close();
  if (PREV === undefined) delete process.env.DESK_ADMIN_TOKEN; else process.env.DESK_ADMIN_TOKEN = PREV;
});

// Simulate a proxied (non-loopback-internal) client.
const ext = (ip = "203.0.113.7") => ({ "x-forwarded-for": ip });

test("constant-time compare: equal / unequal / length-mismatch / non-string", () => {
  assert.equal(constantTimeEqual(PASS, PASS), true);
  assert.equal(constantTimeEqual("wrong", PASS), false);
  assert.equal(constantTimeEqual(PASS + "x", PASS), false);
  assert.equal(constantTimeEqual("", PASS), false);
  assert.equal(constantTimeEqual(undefined, PASS), false);
  assert.equal(constantTimeEqual(123 as unknown, PASS), false);
});

test("session tokens: verify, expire, and die when the passcode rotates", () => {
  const t = createDeskSession(PASS, 1_000);
  assert.equal(verifyDeskSession(t, PASS, 2_000), true);
  assert.equal(verifyDeskSession(t, PASS, 1_000 + 31 * 24 * 3600_000), false);
  assert.equal(verifyDeskSession(t, "rotated", 2_000), false);
  assert.equal(verifyDeskSession(t.replace(/.$/, (c) => (c === "A" ? "B" : "A")), PASS, 2_000), false);
  assert.equal(verifyDeskSession("garbage", PASS), false);
});

test("rate limiter: 5 tries/min per key, then 429 until the window resets", () => {
  const rl = createLoginRateLimiter({ max: 5, windowMs: 60_000 });
  for (let i = 0; i < 5; i++) assert.equal(rl.hit("ip", 0).ok, true);
  const sixth = rl.hit("ip", 1_000);
  assert.equal(sixth.ok, false);
  assert.equal(rl.hit("other-ip", 1_000).ok, true);
  assert.equal(rl.hit("ip", 60_001).ok, true);
});

test("public paths", () => {
  assert.ok(isDeskPublicPath("/healthz"));
  assert.ok(isDeskPublicPath("/auth/login"));
  assert.ok(!isDeskPublicPath("/bot/trades"));
});

test("middleware: unauth GET/POST → 401, healthz open, login → cookie works, bearer works", async () => {
  assert.equal((await fetch(`${base}/api/healthz`, { headers: ext() })).status, 200);
  assert.equal((await fetch(`${base}/api/bot/trades`, { headers: ext() })).status, 401);
  const post = await fetch(`${base}/api/bot/start`, { method: "POST", headers: ext() });
  assert.equal(post.status, 401);
  assert.equal(((await post.json()) as { deskLocked?: boolean }).deskLocked, true);

  const bad = await fetch(`${base}/api/auth/login`, { method: "POST", headers: { ...ext("198.51.100.1"), "content-type": "application/json" }, body: JSON.stringify({ passcode: "nope" }) });
  assert.equal(bad.status, 401);

  const ok = await fetch(`${base}/api/auth/login`, { method: "POST", headers: { ...ext("198.51.100.1"), "content-type": "application/json" }, body: JSON.stringify({ passcode: PASS }) });
  assert.equal(ok.status, 200);
  const setCookie = ok.headers.get("set-cookie") ?? "";
  assert.match(setCookie, /desk_session=/);
  assert.match(setCookie, /HttpOnly/i);
  assert.match(setCookie, /SameSite=Strict/i);
  assert.ok(!JSON.stringify(await ok.json()).includes(PASS), "passcode never echoed");
  const cookie = setCookie.split(";")[0];
  assert.equal((await fetch(`${base}/api/bot/trades`, { headers: { ...ext(), cookie } })).status, 200);
  const me = await (await fetch(`${base}/api/auth/me`, { headers: { ...ext(), cookie } })).json() as { authenticated: boolean };
  assert.equal(me.authenticated, true);

  assert.equal((await fetch(`${base}/api/bot/start`, { method: "POST", headers: { ...ext(), authorization: `Bearer ${PASS}` } })).status, 200);
  assert.equal((await fetch(`${base}/api/bot/start`, { method: "POST", headers: { ...ext(), authorization: "Bearer wrong" } })).status, 401);
});

// Login rate limiting for the account login is covered in
// routes/accounts.integration.test.ts ("rate limiting: per identifier and per IP").
// The limiter primitive itself is covered by the "rate limiter" test above.

test("D8: no loopback bypass — bare 127.0.0.1 calls are locked", async () => {
  assert.equal((await fetch(`${base}/api/bot/trades`)).status, 401);
  assert.equal((await fetch(`${base}/api/bot/start`, { method: "POST" })).status, 401);
});

test("D8: in-process SELF calls pass with the per-process internal token; forged token fails", async () => {
  assert.equal((await fetch(`${base}/api/bot/trades`, { headers: deskInternalHeaders() })).status, 200);
  assert.equal((await fetch(`${base}/api/bot/trades`, { headers: { "x-desk-internal": "guess" } })).status, 401);
});
