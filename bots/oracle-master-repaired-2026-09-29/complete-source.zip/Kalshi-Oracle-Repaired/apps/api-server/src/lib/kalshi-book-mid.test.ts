/**
 * Krypt one-sided mid steal — never (bid+0)/2.
 */
import assert from "node:assert/strict";
import test from "node:test";
import { bookMidCents } from "./kalshi-book-mid.js";

test("both sides → average", () => {
  assert.equal(bookMidCents(40, 44), 42);
  assert.equal(bookMidCents(41, 42), 42); // rounds .5 up via Math.round
});

test("bid only → bid (NOT half)", () => {
  assert.equal(bookMidCents(40, 0), 40);
  assert.notEqual(bookMidCents(40, 0), 20);
});

test("ask only → ask (NOT half)", () => {
  assert.equal(bookMidCents(0, 55), 55);
  assert.notEqual(bookMidCents(0, 55), 28); // would be Math.round(55/2)=28
});

test("empty book → lastFallback", () => {
  assert.equal(bookMidCents(0, 0, 63), 63);
  assert.equal(bookMidCents(0, 0, 0), 0);
  assert.equal(bookMidCents(NaN, NaN, 50), 50);
});

test("negative / non-finite quotes treated as missing", () => {
  assert.equal(bookMidCents(-1, 40), 40);
  assert.equal(bookMidCents(40, -2), 40);
  assert.equal(bookMidCents(NaN, 33), 33);
});
