/**
 * bollinger-band-strategy.test.ts
 *
 * Unit tests for the BOLLINGER_BAND strategy's evaluate() (Task #445).
 * Covers both sub-theses (squeeze-breakout continuation, band-extreme mean
 * reversion) plus the shared gates (insufficient history, time window,
 * trend-regime skip for the reversion thesis).
 *
 * Run with: tsx --test src/lib/bollinger-band-strategy.test.ts
 */

import { test } from "node:test";
import assert    from "node:assert/strict";
import { getStrategy, type StrategyObservation } from "./strategy-library.js";

const strategy = getStrategy('BOLLINGER_BAND');
if (!strategy) throw new Error("BOLLINGER_BAND strategy not found");

function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65_100,
    floorStrike:  65_000,
    velocityDolPerMin: 0,
    threeMinVelocity:  0,
    isStalling:   false,
    stallStrength: 'none',
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60, // 5 min — inside the 2-12 min window
    ...overrides,
  };
}

test("returns null when bbPercentB is undefined (insufficient price history)", () => {
  const result = strategy.evaluate(baseObs({ bbPercentB: undefined }));
  assert.equal(result, null);
});

test("returns null outside the 2-12 minute window even with a clear band-extreme reading", () => {
  const tooLate = baseObs({ secsRemaining: 60, bbPercentB: 0 });
  assert.equal(strategy.evaluate(tooLate), null);

  const tooEarly = baseObs({ secsRemaining: 13 * 60, bbPercentB: 0 });
  assert.equal(strategy.evaluate(tooEarly), null);
});

test("mean reversion: fires YES when price is at/below the lower band", () => {
  const result = strategy.evaluate(baseObs({ bbPercentB: 0 }));
  assert.ok(result, "expected the strategy to fire");
  assert.equal(result!.signal, 'YES');
  assert.equal(result!.strategyId, 'BOLLINGER_BAND');
  assert.equal(result!.confidence, 0.58);
});

test("mean reversion: fires NO when price is at/above the upper band", () => {
  const result = strategy.evaluate(baseObs({ bbPercentB: 1 }));
  assert.ok(result);
  assert.equal(result!.signal, 'NO');
  assert.equal(result!.confidence, 0.58);
});

test("mean reversion: does not fire when price sits inside the bands", () => {
  const result = strategy.evaluate(baseObs({ bbPercentB: 0.5 }));
  assert.equal(result, null);
});

test("mean reversion: skipped in strongly trending/breakout regimes", () => {
  for (const regime of ['strong_uptrend', 'strong_downtrend', 'breakout_up', 'breakdown'] as const) {
    const result = strategy.evaluate(baseObs({ bbPercentB: 0, regime }));
    assert.equal(result, null, `expected no reversion fire in regime=${regime}`);
  }
});

test("mean reversion: still fires in a non-trending regime (e.g. range)", () => {
  const result = strategy.evaluate(baseObs({ bbPercentB: 0, regime: 'range' }));
  assert.ok(result);
});

test("squeeze-breakout: observe-only — upside break falls through to mean-reversion NO (fill path locked off)", () => {
  // Production: `if (false && bbRecentSqueezeExpansion…)` — BB FAST-FLIP/expansion
  // is Tier C observe-only. Band-extreme mean-reversion remains the only fill path.
  const result = strategy.evaluate(baseObs({
    bbPercentB: 1.1,
    bbRecentSqueezeExpansion: true,
    velocityDolPerMin: 20,
  }));
  assert.ok(result, "expected mean-reversion fallthrough at upper band");
  assert.equal(result!.signal, 'NO');
  assert.equal(result!.confidence, 0.58);
  assert.doesNotMatch(result!.reason, /Squeeze-breakout/);
});

test("squeeze-breakout: observe-only — downside break falls through to mean-reversion YES", () => {
  const result = strategy.evaluate(baseObs({
    bbPercentB: -0.1,
    bbRecentSqueezeExpansion: true,
    velocityDolPerMin: -20,
  }));
  assert.ok(result);
  assert.equal(result!.signal, 'YES');
  assert.equal(result!.confidence, 0.58);
  assert.doesNotMatch(result!.reason, /Squeeze-breakout/);
});

test("squeeze-breakout: does not fire without a recent squeeze, even with a band break + velocity", () => {
  const result = strategy.evaluate(baseObs({
    bbPercentB: 1.1,
    bbRecentSqueezeExpansion: false,
    velocityDolPerMin: 20,
  }));
  // Falls through to the mean-reversion thesis instead, which requires
  // bbPercentB <= 0 or >= 1 (1.1 satisfies >= 1) — so it still fires, but as
  // the reversion thesis (lower confidence), not the breakout one.
  assert.ok(result);
  assert.equal(result!.confidence, 0.58);
  assert.doesNotMatch(result!.reason, /Squeeze-breakout/);
});

test("squeeze-breakout: does not fire when velocity fails to confirm the break direction", () => {
  const result = strategy.evaluate(baseObs({
    bbPercentB: 1.1,
    bbRecentSqueezeExpansion: true,
    velocityDolPerMin: 2, // below the |15| confirmation threshold
  }));
  // Falls through to mean-reversion (bbPercentB >= 1 still satisfies that gate).
  assert.ok(result);
  assert.equal(result!.confidence, 0.58);
});

test("squeeze-breakout observe-only: squeeze flag does not raise confidence above mean-reversion", () => {
  const withSqueeze = strategy.evaluate(baseObs({
    bbPercentB: 1,
    bbRecentSqueezeExpansion: true,
    velocityDolPerMin: 20,
  }));
  const reversion = strategy.evaluate(baseObs({
    bbPercentB: 1,
    bbRecentSqueezeExpansion: false,
  }));
  // Both hit the same mean-reversion fill path while breakout stays locked off.
  assert.equal(withSqueeze!.confidence, 0.58);
  assert.equal(reversion!.confidence, 0.58);
  assert.equal(withSqueeze!.signal, reversion!.signal);
});
