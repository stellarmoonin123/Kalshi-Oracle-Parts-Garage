/**
 * historical-backtester.ts  —  10 000-scenario historical simulation engine
 *
 * ┌───────────────────────────────────────────────────────────────┐
 * │  Design: the bot is the student; the future is the judge.     │
 * │                                                               │
 * │  For each scenario window of 200 × 15-min candles:           │
 * │   • Bot sees candles[0..199]  — past only, all indicators.   │
 * │   • Bot fires its full strategy stack (all 12 strategies).   │
 * │   • A Kalshi 15-min contract is simulated at the window end. │
 * │   • Settlement is candles[200].close  — the "oracle future". │
 * │   • Win/loss → pattern-learner + per-strategy sim stats.     │
 * │                                                               │
 * │  10 000 windows sampled across 9 distinct BTC market phases  │
 * │  (bull runs, crashes, recoveries, sideways, ATHs) covering   │
 * │  2021–2025 give the bot exposure to every regime it will     │
 * │  face in live trading.                                        │
 * │                                                               │
 * │  Data source: Binance is tried first (full 2021-2025 regime  │
 * │  history) but is geo-blocked (HTTP 451) from some hosts —    │
 * │  when every phase fetch fails, this falls back to the bot's  │
 * │  own real Kalshi settlement history instead of failing. That │
 * │  fallback has far less regime diversity (only whatever       │
 * │  window Kalshi/the DB actually has), but it is 100% real     │
 * │  settled price data, never synthetic/fabricated candles.     │
 * └───────────────────────────────────────────────────────────────┘
 */

import fs   from 'fs';
import path from 'path';
import { evaluateAllStrategies, getAllStrategyMeta, classifyRegimeFromBuffer, placeableWithoutHaWhenMoneyMakerFires } from './strategy-library.js';
import type { StrategyObservation, StrategyResult } from './strategy-library.js';
import type { OHLCCandle } from './backtest-engine.js';
import { fetchKalshiCandles } from './kalshi-price.js';
import { computeBollingerBands } from './bollinger-bands.js';
import { getEntryPriceBand, kalshiFeeCents } from './constants.js';
import { computeTradeEV } from './trade-path.js';
import { detectCandlePattern, toHeikinAshi } from './candlestick-patterns.js';
import { VelocityReversalDetector } from './velocity-reversal-detector.js';
import {
  recordPatternOutcome, fingerprintObs, flushPatterns,
} from './pattern-learner.js';
import type { SimSummary } from './pattern-learner.js';
import { getPack, computeWouldEligible, filterPoolByPack, PHASE2_ALWAYS_DISABLED } from './specialist-packs.js';
import type { SpecialistPack, PackId } from './specialist-packs.js';
import { computeVolumeScore } from './volume-risk.js';

export type { SimSummary };

// ── Paths ─────────────────────────────────────────────────────────────────────

// process.cwd()-based, NOT __dirname-based — see strategy-learner.ts for the
// full writeup of why an __dirname-relative '../../data' silently resolves
// to the wrong directory once esbuild bundles this file into dist/index.mjs.
// BACKTEST_SCRATCH_DIR is an opt-in override (unset in the live workflow, so
// production behavior is unchanged) that lets an ad-hoc validation run write
// its sim-results.json / pattern-memory.json to an isolated scratch
// directory instead of the live bot's shared data/ dir — otherwise a
// one-off analysis run risks merging synthetic sim-derived pattern stats
// into the same pattern-memory.json the live bot reads for confidence
// boosts (see pattern-learner.ts).
const DATA_DIR   = path.resolve(process.env.BACKTEST_SCRATCH_DIR || process.cwd(), 'data');
const SIM_FILE   = path.join(DATA_DIR, 'sim-results.json');

// ── Market phases ─────────────────────────────────────────────────────────────
// Each phase captures a distinct BTC regime.  We fetch 2 × 1000 = 2000 candles
// per phase (≈ 20 days of 15m data).  9 phases = 18 000 candles total, giving
// 9 × (2000 - 203) = 16 173 possible windows — plenty for 10 000 samples.

interface MarketPhase {
  name:    string;
  startMs: number;   // Binance startTime param
}

const MARKET_PHASES: MarketPhase[] = [
  { name: 'Bull 2021 Q1',     startMs: 1609459200_000 },   // Jan 2021
  { name: 'Crash May 2021',   startMs: 1620086400_000 },   // May 2021
  { name: 'Recovery Q3 2021', startMs: 1627776000_000 },   // Aug 2021
  { name: 'ATH Nov 2021',     startMs: 1635724800_000 },   // Nov 2021
  { name: 'Bear 2022',        startMs: 1651363200_000 },   // May 2022
  { name: 'FTX Collapse',     startMs: 1667260800_000 },   // Nov 2022
  { name: 'Recovery 2023',    startMs: 1675209600_000 },   // Feb 2023
  { name: 'ETF Bull 2024',    startMs: 1704067200_000 },   // Jan 2024
  { name: 'ATH 2025',         startMs: Math.max(1735689600_000, Date.now() - 20 * 86400_000) },
];

const CANDLES_PER_PHASE    = 2000;   // 2 × Binance 1000-limit batches
const WINDOW_HISTORY       = 200;    // candles the bot sees
const WINDOW_FUTURE        = 3;      // candles for settlement
const WINDOW_SIZE          = WINDOW_HISTORY + WINDOW_FUTURE;
const BINANCE_INTERVAL     = '15m';
const FETCH_DELAY_MS       = 110;    // polite rate-limit gap between API calls

// ── Kalshi contract constants ─────────────────────────────────────────────────

// Was a flat 3¢ approximation. Live pricing is NOT flat — Kalshi's taker fee
// is proportional to distance from 50¢ (min(price, 100-price) * rate, see
// kalshiFeeCents in constants.ts), so a flat fee understated cost on
// near-50¢ entries and overstated it on far-OTM entries, silently skewing
// backtest P&L/win-rate away from what live economics actually produce.
// Kept only as a documented historical constant, no longer used below.
const CONTRACT_FEE_CENTS   = 3;      // approximate fill friction (superseded — see kalshiFeeCents)
const ANNUALISED_VOL       = 0.65;   // BTC annual vol used in Black-Scholes approx

// ── Utility: miniature erf (Horner poly, same as backtest.ts) ─────────────────

function erf(x: number): number {
  const sign = x >= 0 ? 1 : -1;
  const a    = Math.abs(x);
  const t    = 1 / (1 + 0.3275911 * a);
  const poly = t * (0.254829592 + t * (-0.284496736 + t * (1.421413741 + t * (-1.453152027 + t * 1.061405429))));
  return sign * (1 - poly * Math.exp(-a * a));
}

function normalCDF(z: number): number {
  return 0.5 * (1 + erf(z / Math.SQRT2));
}

// ── Utility: RSI-14 ───────────────────────────────────────────────────────────

function calcRSI14(closes: number[]): number {
  if (closes.length < 15) return 50;
  const gains: number[] = [];
  const losses: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    gains.push(Math.max(0, d));
    losses.push(Math.max(0, -d));
  }
  let ag = gains.slice(0, 14).reduce((a, b) => a + b) / 14;
  let al = losses.slice(0, 14).reduce((a, b) => a + b) / 14;
  for (let i = 14; i < gains.length; i++) {
    ag = (ag * 13 + gains[i]) / 14;
    al = (al * 13 + losses[i]) / 14;
  }
  return al === 0 ? 100 : 100 - 100 / (1 + ag / al);
}

// ── Utility: Bollinger Band %B (0=lower, 1=upper) ────────────────────────────
// Delegates to the shared bollinger-bands.ts module so the backtester's band
// math can never drift from the live bot's / strategy library's.

function calcBBPercent(closes: number[], n = 20): number {
  const bb = computeBollingerBands(closes, n, 2);
  if (!bb) return 0.5;
  return Math.max(0, Math.min(1, bb.percentB));
}

// ── Trading-session labeling (research only — see sessionStats above) ─────────
//
// Non-overlapping 8-hour UTC blocks, named after the exchange conventionally
// dominant in that window. Crypto trades 24/7 so these are liquidity/activity
// proxies, not literal market-hours — still the standard convention used to
// look for session-of-day effects in continuous markets.
function sessionLabelForUnixSeconds(unixSeconds: number): string {
  const hourUtc = new Date(unixSeconds * 1000).getUTCHours();
  if (hourUtc >= 0  && hourUtc < 8)  return 'asia_00_08utc';
  if (hourUtc >= 8  && hourUtc < 16) return 'europe_08_16utc';
  return 'us_16_24utc';
}

function isWeekendUnixSeconds(unixSeconds: number): boolean {
  const day = new Date(unixSeconds * 1000).getUTCDay(); // 0 = Sunday, 6 = Saturday
  return day === 0 || day === 6;
}

// ── Velocity stall-reversal replay (Task #339) ────────────────────────────────
// VELOCITY_STALL_REVERSAL always showed 0 fires in this simulator because
// obs.velocityReversal was simply never populated here — the live detector
// (velocity-reversal-detector.ts) is a stateful sequence machine fed one
// price sample per tick, and no equivalent feed existed in the backtest
// path. Replays the same historical window buildSimObs already sees (past
// candles only, no lookahead) through a fresh per-scenario detector
// instance, using each candle's close/timestamp as one sample — the same
// no-lookahead discipline candlePattern replay above already established.
//
// IMPORTANT — this fixes the plumbing bug but does NOT make the strategy
// meaningfully backtestable with this simulator's data. The detector's whole
// sequence (sharp move → stall <2.5s of near-zero velocity → ~10s tight
// consolidation → confirmed opposite reversal) is designed around SUB-MINUTE
// live tick data and times out after 8 minutes end-to-end. This simulator's
// historical candles are 15-MINUTE bars (BINANCE_INTERVAL/Coinbase phase
// data) — each successive sample fed to the detector is already 15 minutes
// apart, i.e. longer than the detector's entire max sequence window, so the
// stall/consolidation phases can structurally never be observed here
// regardless of scenario count. Confirmed empirically 2026-08-13: 6,000
// scenarios of a standalone strategyFilter run produced 0 fires. Do not
// re-run this at a higher scenario count expecting a different result, and
// do not treat "0 fires across N scenarios" as evidence the strategy is
// unprofitable or safe — it is simply unmeasurable by this tool. The only
// valid evaluation path for this strategy is real live/paper trading data
// (once enough of it has accumulated) or a genuinely sub-minute historical
// tick dataset, neither of which this simulator currently has.
function replayVelocityReversal(
  candles:     OHLCCandle[],
  floorStrike: number,
): ReturnType<VelocityReversalDetector['update']> | undefined {
  if (candles.length < 5) return undefined;
  const detector = new VelocityReversalDetector();
  let snapshot: ReturnType<VelocityReversalDetector['update']> | undefined;
  for (const c of candles) {
    snapshot = detector.update({ ticker: 'sim', price: c.close, ts: c.time * 1000, floorStrike });
  }
  return snapshot;
}

// ── Build StrategyObservation from a candle window ────────────────────────────

/**
 * BACKTEST LAB v5 (2026-08-22): exported (was module-private) so the causal
 * LEAN-vs-LEGACY simulator (backtest-lab-v5/causal-sim.ts) can build
 * StrategyObservations from real historical candles through this SAME,
 * already-causal-safety-audited function instead of a second hand-rolled
 * reimplementation. Purely additive — no call site or behavior inside this
 * function changed. The lab wraps calls to this function with a temporary
 * seeded Math.random substitute (see causal-sim.ts's `withSeededRandom`) so
 * its yesAsk/noAsk/askSpread draws are reproducible across the poison test's
 * two passes; that substitution lives entirely in the lab module and never
 * touches this function's own behavior when called normally (e.g. from
 * runHistoricalSim below, which is unaffected and keeps using real
 * Math.random).
 */
export function buildSimObs(
  candles:       OHLCCandle[],
  floorStrike:   number,
  secsRemaining: number,
): StrategyObservation {
  const sorted = [...candles].sort((a, b) => a.time - b.time);
  // 2026-08-25 lookahead fix (Task #354): the LAST candle in the window is
  // the one still FORMING at decision time — runHistoricalSim's own
  // floor-realism comment above documents that decisions fire 2-7 minutes
  // before a 15-min candle's close (8-13 min after its open). This function
  // used to treat that forming candle's own CLOSE as "current price" for
  // every feature below (v1/v3 velocity, stall detection, massAboveFloor,
  // distFromFloorPct) — i.e. it read a price the real decision could not
  // have known yet, the same future-leakage class already fixed once for
  // the floor anchor (2026-08-22) and once for a stalling filter. Anchoring
  // to the last FULLY CLOSED candle instead removes that leak; every caller
  // (runHistoricalSim, the causal LEAN/LEGACY lab, research-factory) already
  // passes windows far larger than the 2-candle minimum this needs.
  const closedIdx = Math.max(0, sorted.length - 2);
  const latest    = sorted[closedIdx];
  const oneAgo    = sorted[Math.max(0, closedIdx - 1)];
  const threeAgo  = sorted[Math.max(0, closedIdx - 3)];
  const tenAgo    = sorted[Math.max(0, closedIdx - 10)];

  const cur = latest.close;

  const dt1  = Math.max(1, (latest.time - oneAgo.time) / 60);
  const dt3  = Math.max(1, (latest.time - threeAgo.time) / 60);
  const v1   = (latest.close - oneAgo.close) / dt1;
  const v3   = (latest.close - threeAgo.close) / dt3;

  // Stall detection
  const lastRange  = Math.abs(latest.close - latest.open);
  const priorRange = Math.abs(oneAgo.close - oneAgo.open);
  const isStalling = priorRange > 0 && lastRange < priorRange * 0.35 && Math.abs(v1) > 5;
  const stallStrength: 'none' | 'weak' | 'strong' = isStalling
    ? (Math.abs(v1) < 10 ? 'strong' : 'weak')
    : 'none';

  // Velocity acceleration (10-bar smoothed diff).
  // BACKTEST LAB v5 (2026-08-22): added the `sorted.length >= 2` guard —
  // `tenAgo` is always truthy (it clamps to index 0), so a 1-candle window
  // (the causal lab's very first period's minute-5 decision has nothing
  // before it) used to crash on `sorted[sorted.length - 2]` being
  // undefined. No existing caller (runHistoricalSim et al.) ever passed a
  // window this small, so this is purely defensive — behavior for every
  // window >= 2 candles is unchanged.
  const earlyV = (tenAgo && sorted.length >= 2) ? (sorted[sorted.length - 2].close - tenAgo.close) /
                           Math.max(1, (sorted[sorted.length - 2].time - tenAgo.time) / 60) : 0;
  const velocityAccel = v1 - earlyV;

  // Probability mass (Black-Scholes binary approximation)
  const tau          = secsRemaining / (365 * 24 * 3600);
  const sigma        = floorStrike * ANNUALISED_VOL * Math.sqrt(tau);
  const z            = sigma > 0 ? (cur - floorStrike) / sigma : 0;
  const massAboveFloor = normalCDF(z) * 100;
  const distFromFloorPct = (cur - floorStrike) / floorStrike * 100;

  // Volume state
  const vols    = sorted.slice(-20).map(c => c.volume);
  const avgVol  = vols.reduce((a, b) => a + b, 0) / vols.length;
  const curVol  = latest.volume;
  const volumeState: 'low' | 'normal' | 'high' =
    curVol > avgVol * 1.5 ? 'high' : curVol < avgVol * 0.6 ? 'low' : 'normal';

  // Trend
  const shortTrend: 'up'|'down'|'sideways'  = v1 >  20 ? 'up' : v1  < -20 ? 'down' : 'sideways';
  const mediumTrend: 'up'|'down'|'sideways' = v3 >  15 ? 'up' : v3  < -15 ? 'down' : 'sideways';

  // Simple MTF proxy: 5m vs 1h slope from the window
  const longSMA  = sorted.slice(-60).map(c => c.close);
  const longMean = longSMA.reduce((a, b) => a + b, 0) / longSMA.length;
  const mtfScore = cur > longMean * 1.005 ? 2 : cur < longMean * 0.995 ? -2 : 0;

  const regime = classifyRegimeFromBuffer({ velocityDolPerMin: v1, threeMinVelocity: v3, isStalling, stallStrength, distFromFloorPct });

  // Candlestick pattern (SAKATA_CANDLE_PATTERN backtest fix — Task #416).
  // Live, this comes from a background analyzer polling real 1-minute OHLC;
  // here it must come from the same past-only candle window the rest of obs
  // is built from (the tail of `sorted`, which ends at `latest` — strictly
  // before `futureCandle`, the caller's settlement oracle) or SAKATA would
  // never have a chance to fire in a backtest at all, regardless of the
  // detector's own lookahead-safety. Note this necessarily runs the pattern
  // detector on this window's own candle granularity (15-minute bars from
  // Binance/Coinbase phase data) rather than the live analyzer's 1-minute
  // bars — real historical 1-minute OHLC for the full 2021-2025 span isn't
  // fetched by this simulator, so the shape being detected is the same
  // Homma/Sakata geometry read at a coarser timeframe, not a fabricated one.
  const patternLookback = sorted.slice(-20);
  const haCandles    = toHeikinAshi(patternLookback);
  const patternRead  = haCandles.length >= 5 ? detectCandlePattern(haCandles) : null;
  const candlePattern = patternRead ? { ...patternRead } : undefined;

  // Task #339: replay VELOCITY_STALL_REVERSAL's stateful detector over this
  // same past-only window so the strategy has a real chance to fire in sim.
  const velocityReversal = replayVelocityReversal(sorted, floorStrike);

  // Simulated Yes/No quotes (Task #416 backtest fix). Several strategies
  // (LATE_MOMENTUM_CONTINUATION, BASIS_LAG_EDGE, MEAN_REVERSION_STRETCH) hard
  // -require obs.yesAsk/obs.noAsk to even evaluate — without this they always
  // returned null in the historical sim regardless of scenario count, which
  // looked identical to "this strategy never fires" when the real cause was
  // "this strategy's price gate was never given a price." Computed here, once
  // per scenario, from the SAME massAboveFloor read the rest of obs is built
  // from (no future data), using the one shared quote model
  // (simulateQuotePrice) — simulateKalshiTrade below reuses these same values
  // for whichever side actually gets selected, instead of drawing a second,
  // inconsistent random quote after the fact.
  const yesAsk = simulateQuotePrice(massAboveFloor);
  const noAsk  = simulateQuotePrice(100 - massAboveFloor);
  const askSpread = 2 + Math.random() * 3; // ordinary 2-5¢ bid-ask, matches simulateQuotePrice's own spread model
  const yesBid = Math.max(1, Math.round(yesAsk - askSpread));
  const noBid  = Math.max(1, Math.round(noAsk - askSpread));

  // Task #466 investigation (2026-08-14): `fairDistFromFloorPct` and
  // `estimatedFairBRTI` are DELIBERATELY not populated here — this is the
  // same "genuinely un-backtestable" situation as replayVelocityReversal
  // above, not an overlooked plumbing gap. Live, those fields come from
  // basis-tracker.ts's rolling EWMA of (Kalshi order-book-implied price −
  // raw exchange spot), sampled continuously off two synchronized live
  // feeds. This simulator only ever has ONE historical price series per
  // scenario (Binance/Coinbase candle closes, or — in the geo-block
  // fallback — Kalshi's own settlement history) with no matching
  // historical Kalshi-implied-price series to diff it against, so there is
  // no data from which to reconstruct a historical basis at all. The 11
  // strategies switched to `obs.fairDistFromFloorPct ?? obs.distFromFloorPct`
  // (see strategy-library.ts) safely fall back to plain `distFromFloorPct`
  // in every backtest run as a result — this is expected, not a bug, and
  // should not be "fixed" by fabricating a synthetic basis value. The only
  // valid way to evaluate the fair-corrected paths of those 11 strategies
  // is live/paper trading data.
  return {
    currentPrice:     cur,
    floorStrike,
    velocityDolPerMin: v1,
    threeMinVelocity:  v3,
    velocityAccel,
    isStalling,
    stallStrength,
    distFromFloorPct,
    massAboveFloor,
    secsRemaining,
    volumeState,
    shortTrend,
    mediumTrend,
    regime,
    mtfScore,
    candlePattern,
    velocityReversal,
    yesAsk,
    noAsk,
    yesBid,
    noBid,
  };
}

// ── Kalshi contract price simulation ─────────────────────────────────────────

interface TradeResult {
  signal:      'YES' | 'NO';
  strategyId:  string;
  strategyName: string;
  entryPrice:  number;   // cents (1-99)
  settlePct:   number;   // 0 or 100
  won:         boolean;
  pnlCents:    number;
  confidence:  number;
  regime:      string;
  fpKey:       string;
}

// Probability of the quote being a "lagged" one — the market hasn't caught up
// to the fresh true-probability read yet — vs. an ordinary efficient quote.
// Kept modest (not the ~22% first tried) because a higher rate, combined with
// the band gate only admitting the largest divergences, selected for
// implausibly huge per-trade edges (35¢+ average P&L on a handful of "found
// the market asleep" trades) — real mispricings this large are the rare tail,
// not a fifth of all quotes.
const LAGGED_QUOTE_PROB = 0.10;

/**
 * Simulate a Kalshi contract's ask price for a given true win probability.
 *
 * This is the ONE shared quote-generation model for every backtest/quick-test
 * path in the codebase (the full historical simulator AND the route-level
 * quick strategy test in routes/backtest.ts). Do not re-derive a second copy
 * of this model at another call site — a second approximation is a second
 * place for it to silently drift from this one (Task #368 review: the quick
 * test route kept its own hand-rolled probability±spread model after this
 * function was introduced, reintroducing the exact 0-trades regression this
 * function exists to fix).
 *
 * See simulateKalshiTrade below for the full rationale on why this uses a
 * fat-tailed "occasionally lagged quote" noise model instead of pricing
 * every entry as trueProb ± a small spread (tautologically ~0-edge, and
 * structurally unreachable inside a tight band for any strategy that only
 * fires at already-lopsided probabilities) or a fixed compression toward 50
 * (makes the most extreme OTM bands permanently unreachable).
 */
export function simulateQuotePrice(trueProb: number): number {
  const spread     = 2 + Math.random() * 3;               // 2-5¢, ordinary bid-ask
  const isLagged   = Math.random() < LAGGED_QUOTE_PROB;
  const divergence = isLagged ? 10 + Math.random() * 20 : spread;  // 10-30¢ vs 2-5¢
  return Math.max(5, Math.min(95, Math.round(trueProb + (Math.random() < 0.5 ? divergence : -divergence))));
}

export function simulateKalshiTrade(
  signal:          'YES' | 'NO',
  strategyId:      string,
  strategyName:    string,
  confidence:      number,
  obs:             StrategyObservation,
  settlementClose: number,
): TradeResult {
  const strike = obs.floorStrike;

  // Entry price: the market's ASK, not the model's true probability.
  //
  // The previous model set entryPrice = trueProb ± a 2-5¢ spread, which makes
  // every simulated trade tautologically ~0-edge before fees (a contract
  // "priced" at exactly its win probability has no edge by definition) — and,
  // worse, it meant every strategy whose signal criteria only fires on
  // already-extreme conditions (e.g. FLOOR_DISTANCE/LATE_ENTRY_ANCHOR only
  // fire once price is clearly displaced from the floor, i.e. trueProb is
  // already 75-95%) could NEVER produce an entryPrice inside the standard
  // 28-62¢ band, so the newly added band gate rejected literally every trade
  // (Task #368 review: 0 trades across a 4 000-scenario run).
  //
  // Multiple strategies in this library exist specifically because real
  // order books do not instantly reprice to fair value (velocity/momentum/
  // breakout strategies are built to front-run exactly that lag). Modeling
  // that lag as an occasional LARGE-noise event (~22% of quotes, 12-50¢ off
  // true probability) rather than a fixed compression toward 50 keeps the
  // full 5-95¢ range reachable for every strategy's own band — a fixed
  // affine compression instead makes some strategies' target bands
  // permanently unreachable (e.g. DEEP_OTM_SNIPER's 5-14¢ band cannot be hit
  // if every quote is pulled toward 50). The other ~78% of quotes track true
  // probability closely (ordinary 2-5¢ bid-ask spread) — an efficient quote
  // correctly gets rejected by the band gate as "no real edge left," exactly
  // like the live bot would skip a fairly-priced contract.
  //
  // entryPrice reuses obs.yesAsk/obs.noAsk (Task #416) — the exact quote
  // already attached to obs in buildSimObs — instead of drawing a fresh,
  // independent simulateQuotePrice() sample here. Strategies that gate on
  // obs.yesAsk/obs.noAsk pre-selection (LATE_MOMENTUM_CONTINUATION,
  // BASIS_LAG_EDGE, MEAN_REVERSION_STRETCH) must see the SAME price that
  // actually fills, or a strategy could pass its own price gate against one
  // random quote and then get filled/settled against a different one.
  // Falls back to a fresh draw only for callers that still hand in an obs
  // built without these fields (e.g. any older test fixture).
  const entryPrice = signal === 'YES'
    ? (obs.yesAsk ?? simulateQuotePrice(obs.massAboveFloor))
    : (obs.noAsk  ?? simulateQuotePrice(100 - obs.massAboveFloor));

  // Settlement
  // A win pays out 100¢ (the contract settles at $1); a loss pays out 0¢.
  // Net P&L is always (payout - entryPrice - fee) — the cost basis is only
  // ever subtracted once. The previous formula pre-netted the win case as
  // `100 - entryPrice` and then subtracted entryPrice a SECOND time, which
  // silently turned real wins into apparent losses for any entry > 50¢.
  const won         = signal === 'YES' ? settlementClose > strike : settlementClose < strike;
  const payout      = won ? 100 : 0;
  // Price-dependent Kalshi fee (same formula live pays), not the old flat
  // 3¢ approximation — see CONTRACT_FEE_CENTS comment above.
  const feeCents    = kalshiFeeCents(entryPrice);
  const pnlCents    = payout - entryPrice - feeCents;

  return {
    signal,
    strategyId,
    strategyName,
    entryPrice,
    settlePct:   won ? 100 : 0,
    won,
    pnlCents,
    confidence,
    regime:      obs.regime ?? 'unclear',
    fpKey:       fingerprintObs(obs),
  };
}

// ── Binance historical data fetcher ──────────────────────────────────────────

async function fetchBinanceCandles(
  startMs: number,
  count:   number,
  interval = BINANCE_INTERVAL,
): Promise<OHLCCandle[]> {
  const results: OHLCCandle[] = [];
  let currentStart = startMs;
  const batchSize  = 1000;
  const batches    = Math.ceil(count / batchSize);

  for (let b = 0; b < batches; b++) {
    const limit = Math.min(batchSize, count - results.length);
    const url   = `https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=${interval}&startTime=${currentStart}&limit=${limit}`;

    try {
      const resp = await fetch(url);
      if (!resp.ok) throw new Error(`Binance HTTP ${resp.status}`);
      const raw = await resp.json() as Array<[number, string, string, string, string, string]>;
      if (!raw.length) break;

      for (const c of raw) {
        results.push({
          time:   Math.floor(c[0] / 1000),
          open:   parseFloat(c[1]),
          high:   parseFloat(c[2]),
          low:    parseFloat(c[3]),
          close:  parseFloat(c[4]),
          volume: parseFloat(c[5]),
        });
      }
      currentStart = raw[raw.length - 1][0] + 1;
    } catch (err) {
      console.warn(`[sim] Binance fetch error (phase, batch ${b}): ${(err as Error).message}`);
      break;
    }

    if (b < batches - 1) await new Promise(r => setTimeout(r, FETCH_DELAY_MS));
  }
  return results;
}

// ── Coinbase historical data fetcher (Binance fallback) ───────────────────────
// Binance returns HTTP 451 (geo-blocked) from Replit-hosted servers. Coinbase's
// public Exchange API is reachable and serves genuine historical OHLC candles
// (real intra-candle price action, not interpolated) back through at least
// 2021, so it gives real regime diversity without Binance access.
// Max 300 candles per request — paginate forward from startMs.

async function fetchCoinbaseCandles(
  startMs:        number,
  count:          number,
  granularitySec = 900,   // 900s = 15m, matching BINANCE_INTERVAL
): Promise<OHLCCandle[]> {
  const results: OHLCCandle[] = [];
  let cursorSec        = Math.floor(startMs / 1000);
  const maxPerReq      = 300;
  const batches        = Math.ceil(count / maxPerReq);

  for (let b = 0; b < batches; b++) {
    const remaining = count - results.length;
    const thisBatch = Math.min(maxPerReq, remaining);
    if (thisBatch <= 0) break;
    const endSec  = cursorSec + thisBatch * granularitySec;
    const startIso = new Date(cursorSec * 1000).toISOString();
    const endIso   = new Date(endSec * 1000).toISOString();
    const url = `https://api.exchange.coinbase.com/products/BTC-USD/candles?granularity=${granularitySec}&start=${startIso}&end=${endIso}`;

    try {
      const resp = await fetch(url, { headers: { 'User-Agent': 'kalshi-bot-backtester/1.0' } });
      if (!resp.ok) throw new Error(`Coinbase HTTP ${resp.status}`);
      const raw = await resp.json() as Array<[number, number, number, number, number, number]>;
      if (!raw.length) { cursorSec = endSec; continue; }

      // Coinbase returns [time, low, high, open, close, volume], newest-first.
      const sorted = [...raw].sort((a, b) => a[0] - b[0]);
      for (const c of sorted) {
        results.push({ time: c[0], low: c[1], high: c[2], open: c[3], close: c[4], volume: c[5] });
      }
      cursorSec = endSec;
    } catch (err) {
      console.warn(`[sim] Coinbase fetch error (phase, batch ${b}): ${(err as Error).message}`);
      break;
    }

    if (b < batches - 1) await new Promise(r => setTimeout(r, FETCH_DELAY_MS));
  }
  return results;
}

// ── Seeded deterministic random (Mulberry32) ──────────────────────────────────

function mulberry32(seed: number): () => number {
  return function() {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

// ── Progress callback type ────────────────────────────────────────────────────

export interface SimProgress {
  phase:         'fetching' | 'simulating' | 'learning' | 'done' | 'error';
  message:       string;
  scenariosDone: number;
  scenariosTotal: number;
  tradesPlaced:  number;
  wins:          number;
  currentWinRate: number;
  phaseName?:    string;
  error?:        string;
}

// ── Last results cache ────────────────────────────────────────────────────────

let _lastSim: SimSummary | null = null;

export function getLastSimResults(): SimSummary | null {
  if (_lastSim) return _lastSim;
  try {
    if (fs.existsSync(SIM_FILE)) {
      _lastSim = JSON.parse(fs.readFileSync(SIM_FILE, 'utf8')) as SimSummary;
    }
  } catch { /* corrupt */ }
  return _lastSim;
}

let _simRunning = false;
export function isSimRunning(): boolean { return _simRunning; }

// ── Main simulation entry point ───────────────────────────────────────────────

// Candle fetches (esp. Coinbase's paginated 9-phase pull) take a while and
// the underlying historical data doesn't change minute to minute, so cache
// it across calls in the same process — lets strategyFilter runs (looping
// once per strategy to measure standalone expectancy) reuse the same real
// data instead of re-fetching 9 phases per strategy.
let _phaseCandleCache: { at: number; data: Array<{ phase: MarketPhase; candles: OHLCCandle[] }> } | null = null;
const PHASE_CACHE_TTL_MS = 30 * 60_000;

/** Extracted from runHistoricalSim's step 1 (2026-08-19, pack backtest) so
 *  runPackBacktest can reuse the exact same fetch/cache/fallback path
 *  instead of a second, drift-prone copy. Behavior is byte-identical to the
 *  inline block this replaced — same cache, same Binance→Coinbase→Kalshi
 *  fallback order, same emitted progress messages. */
export async function loadPhaseCandles(
  emit: (p: Omit<SimProgress, 'scenariosTotal'>) => void,
): Promise<Array<{ phase: MarketPhase; candles: OHLCCandle[] }>> {
  let phaseCandles: Array<{ phase: MarketPhase; candles: OHLCCandle[] }>;

  if (_phaseCandleCache && Date.now() - _phaseCandleCache.at < PHASE_CACHE_TTL_MS) {
    phaseCandles = _phaseCandleCache.data;
    emit({ phase: 'fetching', message: 'Using cached historical data…', scenariosDone: 0, tradesPlaced: 0, wins: 0, currentWinRate: 0 });
  } else {
    emit({ phase: 'fetching', message: 'Fetching historical BTC data from Binance…', scenariosDone: 0, tradesPlaced: 0, wins: 0, currentWinRate: 0 });

    phaseCandles = [];
    for (const phase of MARKET_PHASES) {
      emit({ phase: 'fetching', message: `Fetching ${phase.name}…`, scenariosDone: 0, tradesPlaced: 0, wins: 0, currentWinRate: 0, phaseName: phase.name });
      let candles = await fetchBinanceCandles(phase.startMs, CANDLES_PER_PHASE);
      if (candles.length < WINDOW_SIZE) {
        candles = await fetchCoinbaseCandles(phase.startMs, CANDLES_PER_PHASE);
      }
      if (candles.length >= WINDOW_SIZE) {
        phaseCandles.push({ phase, candles });
      }
    }

    if (!phaseCandles.length) {
      emit({ phase: 'fetching', message: 'Binance and Coinbase unreachable — falling back to real Kalshi settlement history…', scenariosDone: 0, tradesPlaced: 0, wins: 0, currentWinRate: 0 });
      const kalshiCandles = await fetchKalshiCandles(15, 1_000);
      if (kalshiCandles.length >= WINDOW_SIZE) {
        phaseCandles.push({ phase: { name: 'Kalshi Settlement History (real, recent)', startMs: 0 }, candles: kalshiCandles });
      }
    }

    if (phaseCandles.length) _phaseCandleCache = { at: Date.now(), data: phaseCandles };
  }

  if (!phaseCandles.length) throw new Error('No historical data fetched — check network');
  return phaseCandles;
}

/** Extracted from runHistoricalSim's step 1 window-pool build, reused by
 *  runPackBacktest for the identical sampling behavior (same shuffle-with-
 *  replacement scheme, same seeded RNG contract). */
function buildScenarioWindows(
  phaseCandles: Array<{ phase: MarketPhase; candles: OHLCCandle[] }>,
  target: number,
  rand: () => number,
): Array<{ pIdx: number; start: number }> {
  const windowPool: Array<{ pIdx: number; start: number }> = [];
  for (let pIdx = 0; pIdx < phaseCandles.length; pIdx++) {
    const len = phaseCandles[pIdx].candles.length;
    for (let i = 0; i + WINDOW_SIZE <= len; i++) {
      windowPool.push({ pIdx, start: i });
    }
  }
  if (!windowPool.length) throw new Error('Window pool empty — candle windows too short');

  const scenarioWindows: Array<{ pIdx: number; start: number }> = [];
  for (let i = 0; i < target; i++) {
    const idx = Math.floor(rand() * windowPool.length);
    scenarioWindows.push(windowPool[idx]);
  }
  return scenarioWindows;
}

export async function runHistoricalSim(
  opts: { scenarios?: number; seed?: number; strategyFilter?: string } = {},
  onProgress?: (p: SimProgress) => void,
): Promise<SimSummary> {
  if (_simRunning) throw new Error('Simulation already running');
  _simRunning = true;

  const TARGET      = Math.min(50_000, Math.max(1_000, opts.scenarios ?? 10_000));
  const rand        = mulberry32(opts.seed ?? 42);
  const startedAt   = Date.now();

  const emit = (p: Omit<SimProgress, 'scenariosTotal'>) =>
    onProgress?.({ ...p, scenariosTotal: TARGET });

  try {
    // ── 1. Fetch historical data ───────────────────────────────────────────────
    const phaseCandles = await loadPhaseCandles(emit);
    const scenarioWindows = buildScenarioWindows(phaseCandles, TARGET, rand);

    // ── 2. Run simulations ────────────────────────────────────────────────────

    const strategyMeta = getAllStrategyMeta();
    const stratNameMap: Record<string, string> = {};
    for (const s of strategyMeta) stratNameMap[s.id] = s.name;

    // Per-strategy accumulators
    const stratStats: Record<string, { n: number; wins: number; pnl: number }> = {};
    const regimeStats: Record<string, { n: number; wins: number; pnl: number }> = {};
    // Only populated when opts.strategyFilter is set — every recorded trade
    // already belongs to that one strategy, so these buckets are always a
    // breakdown of the filtered strategy's own trades, never a cross-strategy mix.
    const priceStats: Record<string, { n: number; wins: number; pnl: number }> = {};
    const timeStats:  Record<string, { n: number; wins: number; pnl: number }> = {};
    // Always populated (independent of strategyFilter) — every trade is
    // tagged by real UTC trading session / weekday at its entry candle's
    // actual historical timestamp. Research question: does BTC/Kalshi show
    // an exploitable session-of-day or weekday effect worth gating entries
    // on (design doc's "Hunt/Harvest" proposal)? See
    // sessionLabelForUnixSeconds() below for the session boundaries.
    const sessionStats: Record<string, { n: number; wins: number; pnl: number }> = {};
    const weekdayStats: Record<'weekday' | 'weekend', { n: number; wins: number; pnl: number }> = {
      weekday: { n: 0, wins: 0, pnl: 0 },
      weekend: { n: 0, wins: 0, pnl: 0 },
    };

    let tradesPlaced = 0;
    let totalWins    = 0;
    let totalPnl     = 0;

    emit({ phase: 'simulating', message: `Running ${TARGET.toLocaleString()} scenarios…`, scenariosDone: 0, tradesPlaced: 0, wins: 0, currentWinRate: 0 });

    for (let si = 0; si < TARGET; si++) {
      const { pIdx, start } = scenarioWindows[si];
      const allCandles      = phaseCandles[pIdx].candles;
      const histCandles     = allCandles.slice(start, start + WINDOW_HISTORY);
      const futureCandle    = allCandles[start + WINDOW_HISTORY];   // oracle

      // 2026-08-22 floor-realism fix: the floor used to be derived from the
      // window's own last CLOSE (the decision-time price), which means every
      // synthetic scenario started with price at-or-above its own floor by
      // construction (confirmed empirically: 0 of 60,000 sampled scenarios
      // had price below the floor). Live Kalshi floors are fixed at the real
      // contract's period OPEN, and price can — and does — drift below them
      // before a late-firing strategy triggers, so this systematically
      // overstated win rates for every floor-distance-based strategy
      // (distFromFloorPct/massAboveFloor). Each candle here is a 15-minute
      // bar (see loadPhaseCandles/BINANCE_INTERVAL) and decision happens
      // 2-7 minutes before its close, i.e. 8-13 minutes after its open — so
      // that candle's OPEN is the right proxy for "price when this period's
      // floor was actually set". buildSimObs below still derives its own
      // "current price" from the window's last CLOSE internally — only the
      // floor anchor moves earlier in time, letting it land above OR below
      // decision-time price exactly like a real live contract.
      const periodOpenPrice = histCandles[histCandles.length - 1].open;
      const floorStrike     = Math.floor(periodOpenPrice / 1000) * 1000;
      if (floorStrike <= 0) continue;

      // Simulate entry timing (2-7 min before expiry, matching live bot config)
      const secsRemaining = 120 + Math.floor(rand() * 300);

      const obs = buildSimObs(histCandles, floorStrike, secsRemaining);
      const { all: simAll, best: simDefaultBest } = evaluateAllStrategies(obs);
      // strategyFilter forces a single strategy's own signal (if it fired)
      // instead of the cross-strategy "best" pick — used to measure each
      // strategy's standalone expectancy rather than only whichever strategy
      // wins the confidence competition most often.
      const best = opts.strategyFilter
        ? (simAll.find(r => r.strategyId === opts.strategyFilter) ?? null)
        : simDefaultBest;

      if (best && best.signal !== 'STAY_OUT') {
        const signal = best.signal as 'YES' | 'NO';
        const result = simulateKalshiTrade(
          signal,
          best.strategyId,
          best.strategyName ?? stratNameMap[best.strategyId] ?? best.strategyId,
          best.confidence,
          obs,
          futureCandle.close,
        );

        // Entry-price band gate (Task #368): the live/paper bot rejects any
        // order outside its strategy-specific entry-price band before it
        // ever reaches order placement (28-62¢ for standard strategies; each
        // OTM strategy has its own tighter sweet spot — see
        // getEntryPriceBand). Without this gate the backtest "trades" prices
        // production never would — mostly rich, near-certain 85-95¢ entries
        // that look like a high win rate but carry negative expectancy once
        // fees are paid.
        const band = getEntryPriceBand(result.strategyId);
        const inBand = result.entryPrice >= band.min && result.entryPrice <= band.max;

        // Fee/slippage-aware EV floor (Task: backtest/live parity, 2026-08-11):
        // live never places an order with EV ratio < 0.03 (see
        // estimateTradeEV/passesPathEVGate in trading-bot.ts / trade-path.ts).
        // The backtester previously had no equivalent — it would happily
        // record a "trade" at a price/confidence combination live would have
        // skipped entirely, inflating simulated win-rate/P&L versus what live
        // trading actually allows itself to take. Same ratio, same 0.03
        // floor, same strategy-family EV discount (via strategyId).
        const { netEV, totalFriction } = computeTradeEV({
          entryPriceCents: result.entryPrice,
          winRate:         result.confidence,
          strategyId:      result.strategyId,
        });
        const totalCost   = result.entryPrice + totalFriction;
        const evRatio      = (totalCost > 0 && totalCost < 100) ? netEV / totalCost : -1;
        const passesEVFloor = evRatio >= 0.03;

        if (inBand && passesEVFloor) {
          // Record for strategy stats
          if (!stratStats[result.strategyId]) stratStats[result.strategyId] = { n: 0, wins: 0, pnl: 0 };
          stratStats[result.strategyId].n++;
          if (result.won) stratStats[result.strategyId].wins++;
          stratStats[result.strategyId].pnl += result.pnlCents;

          // Record for regime stats
          const reg = result.regime;
          if (!regimeStats[reg]) regimeStats[reg] = { n: 0, wins: 0, pnl: 0 };
          regimeStats[reg].n++;
          if (result.won) regimeStats[reg].wins++;
          regimeStats[reg].pnl += result.pnlCents;

          // Record for pattern learner
          recordPatternOutcome(result.fpKey, result.won, result.pnlCents);

          // Record session/weekday buckets — always meaningful (every trade
          // has a real entry timestamp regardless of which strategy fired).
          const entryUnixSeconds = histCandles[histCandles.length - 1].time;
          const session = sessionLabelForUnixSeconds(entryUnixSeconds);
          if (!sessionStats[session]) sessionStats[session] = { n: 0, wins: 0, pnl: 0 };
          sessionStats[session].n++;
          if (result.won) sessionStats[session].wins++;
          sessionStats[session].pnl += result.pnlCents;

          const weekdayBucket: 'weekday' | 'weekend' = isWeekendUnixSeconds(entryUnixSeconds) ? 'weekend' : 'weekday';
          weekdayStats[weekdayBucket].n++;
          if (result.won) weekdayStats[weekdayBucket].wins++;
          weekdayStats[weekdayBucket].pnl += result.pnlCents;

          // Record price/time-left buckets — only meaningful when strategyFilter
          // is set (every trade here already belongs to that one strategy).
          if (opts.strategyFilter) {
            const priceBucket = `${Math.floor(result.entryPrice / 5) * 5}-${Math.floor(result.entryPrice / 5) * 5 + 4}c`;
            if (!priceStats[priceBucket]) priceStats[priceBucket] = { n: 0, wins: 0, pnl: 0 };
            priceStats[priceBucket].n++;
            if (result.won) priceStats[priceBucket].wins++;
            priceStats[priceBucket].pnl += result.pnlCents;

            const minLeft = Math.floor(secsRemaining / 60);
            const timeBucket = `${minLeft}-${minLeft + 1}min`;
            if (!timeStats[timeBucket]) timeStats[timeBucket] = { n: 0, wins: 0, pnl: 0 };
            timeStats[timeBucket].n++;
            if (result.won) timeStats[timeBucket].wins++;
            timeStats[timeBucket].pnl += result.pnlCents;
          }

          tradesPlaced++;
          if (result.won) totalWins++;
          totalPnl += result.pnlCents;
        }
        // else: entry-price band gate (Task #368) rejected this signal — the
        // live/paper bot would never have placed this order, so it's not
        // counted as a trade. See getEntryPriceBand in constants.ts.
      }

      // Progress update every 500 scenarios
      if ((si + 1) % 500 === 0) {
        emit({
          phase:          'simulating',
          message:        `Simulated ${si + 1} / ${TARGET} scenarios`,
          scenariosDone:  si + 1,
          tradesPlaced,
          wins:           totalWins,
          currentWinRate: tradesPlaced > 0 ? totalWins / tradesPlaced : 0,
          phaseName:      phaseCandles[pIdx].phase.name,
        });
      }
    }

    // ── 3. Persist learned patterns ───────────────────────────────────────────
    emit({ phase: 'learning', message: 'Persisting pattern memory…', scenariosDone: TARGET, tradesPlaced, wins: totalWins, currentWinRate: tradesPlaced > 0 ? totalWins / tradesPlaced : 0 });
    await flushPatterns();

    // ── 4. Build summary ──────────────────────────────────────────────────────
    const { getAllPatterns } = await import('./pattern-learner.js');
    const allPatterns = getAllPatterns(20);

    const summary: SimSummary = {
      totalScenarios: TARGET,
      tradesPlaced,
      wins:           totalWins,
      losses:         tradesPlaced - totalWins,
      winRate:        tradesPlaced > 0 ? totalWins / tradesPlaced : 0,
      totalPnlCents:  totalPnl,
      avgPnlCents:    tradesPlaced > 0 ? totalPnl / tradesPlaced : 0,
      byStrategy: Object.entries(stratStats).map(([id, s]) => ({
        strategyId: id,
        name:       stratNameMap[id] ?? id,
        n:          s.n,
        winRate:    s.n > 0 ? s.wins / s.n : 0,
        avgPnl:     s.n > 0 ? s.pnl / s.n : 0,
      })).sort((a, b) => b.winRate - a.winRate),
      byRegime: Object.entries(regimeStats).map(([regime, s]) => ({
        regime,
        n:       s.n,
        winRate: s.n > 0 ? s.wins / s.n : 0,
        avgPnl:  s.n > 0 ? s.pnl / s.n : 0,
      })).sort((a, b) => b.n - a.n),
      bySession: Object.entries(sessionStats).map(([session, s]) => ({
        session,
        n:       s.n,
        winRate: s.n > 0 ? s.wins / s.n : 0,
        avgPnl:  s.n > 0 ? s.pnl / s.n : 0,
      })).sort((a, b) => a.session.localeCompare(b.session)),
      byWeekday: (['weekday', 'weekend'] as const).map(bucket => ({
        bucket,
        n:       weekdayStats[bucket].n,
        winRate: weekdayStats[bucket].n > 0 ? weekdayStats[bucket].wins / weekdayStats[bucket].n : 0,
        avgPnl:  weekdayStats[bucket].n > 0 ? weekdayStats[bucket].pnl / weekdayStats[bucket].n : 0,
      })),
      ...(opts.strategyFilter ? {
        byEntryPriceBucket: Object.entries(priceStats).map(([bucket, s]) => ({
          bucket, n: s.n, winRate: s.n > 0 ? s.wins / s.n : 0, avgPnl: s.n > 0 ? s.pnl / s.n : 0,
        })).sort((a, b) => a.bucket.localeCompare(b.bucket, undefined, { numeric: true })),
        byTimeLeftBucket: Object.entries(timeStats).map(([bucket, s]) => ({
          bucket, n: s.n, winRate: s.n > 0 ? s.wins / s.n : 0, avgPnl: s.n > 0 ? s.pnl / s.n : 0,
        })).sort((a, b) => a.bucket.localeCompare(b.bucket, undefined, { numeric: true })),
      } : {}),
      topPatterns:   allPatterns.filter(p => p.edge > 0).slice(0, 15),
      worstPatterns: allPatterns.filter(p => p.edge < 0).slice(0, 15),
      phasesCovered: phaseCandles.map(pc => pc.phase.name),
      runDurationMs: Date.now() - startedAt,
      completedAt:   Date.now(),
    };

    _lastSim = summary;
    try {
      await fs.promises.mkdir(DATA_DIR, { recursive: true });
      await fs.promises.writeFile(SIM_FILE, JSON.stringify(summary, null, 2));
    } catch { /* non-fatal */ }

    emit({ phase: 'done', message: `Done — ${tradesPlaced} trades, ${(summary.winRate * 100).toFixed(1)}% win rate`, scenariosDone: TARGET, tradesPlaced, wins: totalWins, currentWinRate: summary.winRate });

    return summary;

  } catch (err) {
    const msg = (err as Error).message;
    emit({ phase: 'error', message: msg, error: msg, scenariosDone: 0, tradesPlaced: 0, wins: 0, currentWinRate: 0 });
    throw err;
  } finally {
    _simRunning = false;
  }
}

// ── Specialist pack backtest (Task: "Back test the new packs", 2026-08-19) ────
//
// The SPECIALIST_PACKS system (specialist-packs.ts) went live in ENFORCE mode
// today with zero historical validation — see that module's header. This runs
// the SAME scenario stream (identical candles, identical buildSimObs, identical
// futureCandle settlement oracle) through TWO parallel decision paths per
// scenario so the only variable between them is the pack layer itself:
//
//   BASELINE:      evaluateAllStrategies(obs) with no pack restriction — this
//                  mirrors runHistoricalSim's own existing (no-disabled-set)
//                  default path, i.e. "what the backtester already reports
//                  today, unchanged".
//   PACK-ENFORCED: getPack(regime, vBucket) → computeWouldEligible (excludes
//                  PHASE2_ALWAYS_DISABLED, same as live) → filterPoolByPack →
//                  select best of the filtered pool.
//
// Both arms are then run through the EXACT SAME entry-price-band + fee/EV-
// floor gates already used by runHistoricalSim (getEntryPriceBand /
// computeTradeEV) before being counted as a "trade" — so a signal that only
// the pack path or only the baseline path allows through the gates is not
// mis-attributed to the other arm.
//
// KNOWN LIMITATION (documented, not silently glossed over): obs.regime here
// is the legacy INSTANTANEOUS classifyRegimeFromBuffer tag (see buildSimObs),
// not the canonical sticky/hysteretic R_t that regime-engine.ts/trading-bot.ts
// actually feed getPack() with live. classifyRegimeFromBuffer never emits
// 'squeeze' (only regime-engine.ts's hysteresis state machine detects a real
// vol-compression squeeze), so the SQUEEZE pack is structurally unreachable
// in this backtest and will always show n=0 — this is the same category of
// gap as replayVelocityReversal/fairDistFromFloorPct above, not a bug to
// chase. TREND/RANGE/TRANSITION/LOW_VOL are all reachable and meaningful.

/** Mirrors trading-bot.ts's exported `selectBestEnabled` (same confidence-
 *  weighted consensus / MIXED-split / unanimous-bonus rules), duplicated here
 *  as a small pure function rather than imported — trading-bot.ts is a large
 *  file with live bot bootstrap side effects at module scope, and importing
 *  it from an offline research/backtest module risks pulling that in. Input
 *  must already be confidence-sorted (evaluateAllStrategies's `all` already
 *  is) and already filtered to the eligible/enabled pool — this function does
 *  no further disabled-set filtering of its own. Keep in sync with
 *  trading-bot.ts's selectBestEnabled if that logic changes.
 *
 *  BACKTEST LAB v5 (2026-08-22): exported (was module-private) so the causal
 *  LEAN-vs-LEGACY simulator (backtest-lab-v5/causal-sim.ts) replays the same
 *  weighted-consensus/MIXED-split/unanimous-bonus selection real live uses,
 *  instead of a third hand-rolled copy of this logic. Purely additive. */
const LEFTOVER_MIXED_KILL_IDS = new Set(["TICKET_WAVE", "NO_CROSS"]);

function isMoneyMakerDirectionalFire(r: { strategyId: string; signal: string }): boolean {
  return (r.strategyId === "CONFLUENCE_CASCADE" || r.strategyId === "BASIS_LAG_EDGE")
    && (r.signal === "YES" || r.signal === "NO");
}

export function selectBestFromPool(pool: StrategyResult[]): StrategyResult | null {
  if (pool.length === 0) return null;
  const withoutHa = placeableWithoutHaWhenMoneyMakerFires(pool);
  const moneyMakerFired = withoutHa.some(isMoneyMakerDirectionalFire);
  const ranked = moneyMakerFired
    ? withoutHa.filter(r => !LEFTOVER_MIXED_KILL_IDS.has(r.strategyId))
    : withoutHa;
  if (ranked.length === 0) return null;
  const longWeight  = ranked.filter(r => r.signal === 'YES').reduce((s, r) => s + r.confidence, 0);
  const shortWeight = ranked.filter(r => r.signal === 'NO' ).reduce((s, r) => s + r.confidence, 0);
  const totalWeight = longWeight + shortWeight;
  const winningShare = totalWeight > 0 ? Math.max(longWeight, shortWeight) / totalWeight : 0;

  const longs  = ranked.filter(r => r.signal === 'YES');
  const shorts = ranked.filter(r => r.signal === 'NO');
  const consensus: 'LONG' | 'SHORT' | 'MIXED' | 'NONE' =
    longs.length > 0 && shorts.length === 0 ? 'LONG' :
    shorts.length > 0 && longs.length === 0 ? 'SHORT' :
    longs.length > 0                         ? 'MIXED' : 'NONE';

  const top    = ranked[0];
  const runner = ranked[1];
  if (!top) return null;
  if (top.confidence < 0.55 && !isMoneyMakerDirectionalFire(top)) return null;

  if (consensus === 'MIXED' && runner?.signal !== top.signal) {
    const weightGap = winningShare - 0.5;
    if (weightGap >= 0.20 && top.confidence - (runner?.confidence ?? 0) >= 0.08) {
      return { ...top, confidence: top.confidence - 0.03 };
    } else if (top.confidence - (runner?.confidence ?? 0) >= 0.12) {
      return { ...top, confidence: top.confidence - 0.05 };
    }
    return null;
  } else if (consensus !== 'MIXED' && runner?.signal === top.signal) {
    const unanimousBonus = winningShare >= 0.85 ? 0.04 : 0.02;
    return { ...top, confidence: Math.min(0.94, top.confidence + unanimousBonus) };
  }
  return top;
}

/** Runs the same price-band + fee/EV-floor admission gate runHistoricalSim
 *  uses, given an already-selected candidate. Returns the TradeResult only if
 *  it would actually be placed live — `null` means the gate rejected it (not
 *  counted as a trade in either arm, matching runHistoricalSim's own
 *  behavior). Pure — no shared-state writes. */
function gateAndSimulate(
  best: StrategyResult,
  obs: StrategyObservation,
  futureClose: number,
): TradeResult | null {
  const signal = best.signal as 'YES' | 'NO';
  const result = simulateKalshiTrade(signal, best.strategyId, best.strategyName ?? best.strategyId, best.confidence, obs, futureClose);

  const band = getEntryPriceBand(result.strategyId);
  const inBand = result.entryPrice >= band.min && result.entryPrice <= band.max;
  if (!inBand) return null;

  const { netEV, totalFriction } = computeTradeEV({
    entryPriceCents: result.entryPrice,
    winRate:         result.confidence,
    strategyId:      result.strategyId,
  });
  const totalCost = result.entryPrice + totalFriction;
  const evRatio    = (totalCost > 0 && totalCost < 100) ? netEV / totalCost : -1;
  if (evRatio < 0.03) return null;

  return result;
}

interface ArmStats { n: number; wins: number; pnl: number; }
function toArmSummary(s: ArmStats) {
  return {
    tradesPlaced: s.n,
    wins: s.wins,
    losses: s.n - s.wins,
    winRate: s.n > 0 ? s.wins / s.n : 0,
    totalPnlCents: s.pnl,
    avgPnlCents: s.n > 0 ? s.pnl / s.n : 0,
  };
}

export interface PackBacktestSummary {
  totalScenarios: number;
  /** No pack restriction — same selection runHistoricalSim's default path uses today. */
  baseline: ReturnType<typeof toArmSummary>;
  /** getPack(regime, vBucket) eligibility + confBump/sizeCap semantics applied. */
  packEnforced: ReturnType<typeof toArmSummary>;
  /** Per-pack breakdown of the pack-enforced arm's own trades (SQUEEZE excluded
   *  from meaningful results — see module doc comment on why it's unreachable). */
  byPack: Array<{ packId: PackId; n: number; winRate: number; avgPnl: number }>;
  /** How often each pack (or none) was the active routing decision this tick,
   *  REGARDLESS of whether a trade was actually placed — shows real-world
   *  pack-selection frequency independent of the downstream gates. */
  packSelectionFrequency: Array<{ packId: PackId | 'NO_PACK'; n: number; pct: number }>;
  deltaWinRate: number;      // packEnforced.winRate - baseline.winRate
  deltaAvgPnlCents: number;  // packEnforced.avgPnlCents - baseline.avgPnlCents
  deltaTradesPlaced: number; // packEnforced.tradesPlaced - baseline.tradesPlaced
  phasesCovered: string[];
  runDurationMs: number;
  completedAt: number;
}

let _lastPackSim: PackBacktestSummary | null = null;
const PACK_SIM_FILE = path.join(DATA_DIR, 'pack-sim-results.json');

export function getLastPackBacktestResults(): PackBacktestSummary | null {
  if (_lastPackSim) return _lastPackSim;
  try {
    if (fs.existsSync(PACK_SIM_FILE)) {
      _lastPackSim = JSON.parse(fs.readFileSync(PACK_SIM_FILE, 'utf8')) as PackBacktestSummary;
    }
  } catch { /* corrupt */ }
  return _lastPackSim;
}

export async function runPackBacktest(
  opts: { scenarios?: number; seed?: number } = {},
  onProgress?: (p: SimProgress) => void,
): Promise<PackBacktestSummary> {
  if (_simRunning) throw new Error('Simulation already running');
  _simRunning = true;

  const TARGET    = Math.min(50_000, Math.max(1_000, opts.scenarios ?? 10_000));
  const rand      = mulberry32(opts.seed ?? 42);
  const startedAt = Date.now();

  const emit = (p: Omit<SimProgress, 'scenariosTotal'>) =>
    onProgress?.({ ...p, scenariosTotal: TARGET });

  try {
    const phaseCandles     = await loadPhaseCandles(emit);
    const scenarioWindows  = buildScenarioWindows(phaseCandles, TARGET, rand);

    const baseline: ArmStats     = { n: 0, wins: 0, pnl: 0 };
    const packEnforced: ArmStats = { n: 0, wins: 0, pnl: 0 };
    const byPack: Record<string, ArmStats> = {};
    const packFreq: Record<string, number> = {};

    emit({ phase: 'simulating', message: `Running ${TARGET.toLocaleString()} pack-comparison scenarios…`, scenariosDone: 0, tradesPlaced: 0, wins: 0, currentWinRate: 0 });

    for (let si = 0; si < TARGET; si++) {
      const { pIdx, start } = scenarioWindows[si];
      const allCandles   = phaseCandles[pIdx].candles;
      const histCandles  = allCandles.slice(start, start + WINDOW_HISTORY);
      const futureCandle = allCandles[start + WINDOW_HISTORY];

      // See matching comment in runHistoricalSim above — floor anchor moved
      // from decision-time close to period-open (this candle's own open) so
      // synthetic scenarios can land above OR below their floor by decision
      // time, like a real live contract.
      const periodOpenPrice = histCandles[histCandles.length - 1].open;
      const floorStrike     = Math.floor(periodOpenPrice / 1000) * 1000;
      if (floorStrike <= 0) continue;

      const secsRemaining = 120 + Math.floor(rand() * 300);
      const obs = buildSimObs(histCandles, floorStrike, secsRemaining);
      const { all: simAll, best: simDefaultBest } = evaluateAllStrategies(obs);

      // ── Pack routing (identical inputs to the live 15m tick's own compute) ──
      const vBucket = computeVolumeScore(obs).bucket;
      const pack: SpecialistPack | null = getPack(obs.regime ?? 'unclear', vBucket);
      const packKey = pack ? pack.id : 'NO_PACK';
      packFreq[packKey] = (packFreq[packKey] ?? 0) + 1;

      // ── Baseline arm: unchanged existing behavior ───────────────────────────
      if (simDefaultBest && simDefaultBest.signal !== 'STAY_OUT') {
        const traded = gateAndSimulate(simDefaultBest, obs, futureCandle.close);
        if (traded) {
          baseline.n++;
          if (traded.won) baseline.wins++;
          baseline.pnl += traded.pnlCents;
        }
      }

      // ── Pack-enforced arm ────────────────────────────────────────────────────
      const eligibleIds = pack ? new Set(computeWouldEligible(pack, PHASE2_ALWAYS_DISABLED)) : null;
      const packPool = filterPoolByPack(simAll, eligibleIds);
      const packBest = selectBestFromPool(packPool);
      if (packBest && packBest.signal !== 'STAY_OUT') {
        const traded = gateAndSimulate(packBest, obs, futureCandle.close);
        if (traded) {
          packEnforced.n++;
          if (traded.won) packEnforced.wins++;
          packEnforced.pnl += traded.pnlCents;
          if (pack) {
            if (!byPack[pack.id]) byPack[pack.id] = { n: 0, wins: 0, pnl: 0 };
            byPack[pack.id].n++;
            if (traded.won) byPack[pack.id].wins++;
            byPack[pack.id].pnl += traded.pnlCents;
          }
        }
      }

      if ((si + 1) % 500 === 0) {
        emit({
          phase: 'simulating',
          message: `Simulated ${si + 1} / ${TARGET} scenarios (baseline ${baseline.n} trades / pack ${packEnforced.n} trades)`,
          scenariosDone: si + 1,
          tradesPlaced: packEnforced.n,
          wins: packEnforced.wins,
          currentWinRate: packEnforced.n > 0 ? packEnforced.wins / packEnforced.n : 0,
          phaseName: phaseCandles[pIdx].phase.name,
        });
      }
    }

    const totalFreq = Object.values(packFreq).reduce((a, b) => a + b, 0) || 1;
    const summary: PackBacktestSummary = {
      totalScenarios: TARGET,
      baseline: toArmSummary(baseline),
      packEnforced: toArmSummary(packEnforced),
      byPack: Object.entries(byPack).map(([packId, s]) => ({
        packId: packId as PackId, n: s.n, winRate: s.n > 0 ? s.wins / s.n : 0, avgPnl: s.n > 0 ? s.pnl / s.n : 0,
      })).sort((a, b) => b.n - a.n),
      packSelectionFrequency: Object.entries(packFreq).map(([packId, n]) => ({
        packId: packId as PackId | 'NO_PACK', n, pct: n / totalFreq,
      })).sort((a, b) => b.n - a.n),
      deltaWinRate: toArmSummary(packEnforced).winRate - toArmSummary(baseline).winRate,
      deltaAvgPnlCents: toArmSummary(packEnforced).avgPnlCents - toArmSummary(baseline).avgPnlCents,
      deltaTradesPlaced: packEnforced.n - baseline.n,
      phasesCovered: phaseCandles.map(pc => pc.phase.name),
      runDurationMs: Date.now() - startedAt,
      completedAt: Date.now(),
    };

    _lastPackSim = summary;
    try {
      await fs.promises.mkdir(DATA_DIR, { recursive: true });
      await fs.promises.writeFile(PACK_SIM_FILE, JSON.stringify(summary, null, 2));
    } catch { /* non-fatal */ }

    emit({
      phase: 'done',
      message: `Done — baseline ${summary.baseline.tradesPlaced} trades (${(summary.baseline.winRate * 100).toFixed(1)}%) vs pack-enforced ${summary.packEnforced.tradesPlaced} trades (${(summary.packEnforced.winRate * 100).toFixed(1)}%)`,
      scenariosDone: TARGET, tradesPlaced: summary.packEnforced.tradesPlaced, wins: summary.packEnforced.wins, currentWinRate: summary.packEnforced.winRate,
    });

    return summary;
  } catch (err) {
    const msg = (err as Error).message;
    emit({ phase: 'error', message: msg, error: msg, scenariosDone: 0, tradesPlaced: 0, wins: 0, currentWinRate: 0 });
    throw err;
  } finally {
    _simRunning = false;
  }
}
