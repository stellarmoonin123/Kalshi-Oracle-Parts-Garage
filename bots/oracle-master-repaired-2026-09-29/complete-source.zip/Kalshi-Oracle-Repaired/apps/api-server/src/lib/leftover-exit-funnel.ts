/**
 * Leftover monitor exit stack (TB / LAG / HARD_STOP / ARIA / hold-to-settlement / trail).
 * Paper KXBTC15M never runs it. PATH_RIDE is the only booked exit on paper/frozen.
 * Host leftoverExitStackMayRun is the only door. Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
import { ariaMayGovernOrders } from "./fill-authority.js";
import { expertAgent } from "./expert-agent.js";
import { capToManualBoundary } from "./tighten-only.js";
import { mtfAnalyzer, getMtfOhlcBars } from "./mtf-analyzer.js";
import { ticketAdverseThesisBreakOk, pathRideAntiFlickerExitOk, THESIS_BREAK_MIN_HOLD_MS } from "./timing-clock.js";
import { CATASTROPHIC_MARK_CENTS } from "./thesis-state.js";
import { decideHoldOrSell } from "./hold-sell.js";
import {
  isPathRideKellyBook,
  isPathRideFlickerBook,
  isPathRideOpenTrade,
  holdHardFloorMaySell,
} from "./path-ride.js";
import { isMoneyMakerStrategyId } from "./settlement-side.js";
import { basisTracker, projectSettlementPrice } from "./basis-tracker.js";
import { fillPathPWin } from "./organs/probability.js";
import { kalshiFeeCents, kalshiNetWinCents, kalshiNetCostCents } from "./constants.js";

export const LEFTOVER_EXIT_FUNNEL_LOADED = true as const;

export const FROZEN_EXIT_FUNNEL_MARKERS = [
  "EXIT PRIORITY 1: THESIS-BREAK",
  "EXIT PRIORITY 2: LAG-FLIP",
  "EXIT PRIORITY 3: HARD STOP",
  "ARIA_GATED_EXIT",
  "BREAKEVEN_GUARD",
  "TIME_DECAY",
  "LATE_LOCK",
] as const;

export type LeftoverExitStackLocals = {
  trade: any;
  currentSidePrice: number;
  perContractPnl: number;
  secs: number;
  vel: number;
  btcPrice: number;
  tick: any;
  priceBreakdown: any;
  openThesis: any;
  stalling: boolean;
  liveModelProb: number | null | undefined;
  evalSidePrice: number;
  isHoldToSettlementExempt: (trade: any) => boolean;
  computeNormalTargetProfitCents: (...args: any[]) => number;
  preserveEntryTargetFloor: (...args: any[]) => number;
  shouldEnforceNormalTradeStop: (opts: any) => boolean;
  evaluateStopLossDecision: (params: any) => string | null;
};

export async function leftoverExitStackFunnel(
  this: any,
  locals: LeftoverExitStackLocals,
): Promise<void> {
  const {
    trade,
    currentSidePrice,
    perContractPnl,
    secs,
    vel,
    btcPrice,
    tick,
    priceBreakdown,
    openThesis,
    stalling,
    liveModelProb,
    evalSidePrice,
    isHoldToSettlementExempt,
    computeNormalTargetProfitCents,
    preserveEntryTargetFloor,
    shouldEnforceNormalTradeStop,
    evaluateStopLossDecision,
  } = locals;

    // ── EXIT PRIORITY 1: THESIS-BREAK (persistence-gated) ─────────────────────
    // Stellar: THESIS_BREAK / LAG_FLIP outrank % hard/soft stops. 15s+3¢
    // anti-flicker lives in thesisState (15s + 3¢, no flicker); live TB
    // uses ticket-adverse ≥3¢ + velocity/floor/pattern, plus 15s min hold on
    // money-maker VELOCITY_FLIP_AGAINST only (do not enable the global timing-clock live flag).
    if (await this.checkThesisBreak(trade, currentSidePrice, perContractPnl, secs, vel, btcPrice, tick.floorStrike, priceBreakdown, openThesis.status)) return;

    // ── EXIT PRIORITY 2: LAG-FLIP (persistence-gated, 15s+3 both-against + lagProven) ─
    if (await this.checkLagFlip(trade, currentSidePrice, perContractPnl, secs, vel, tick.floorStrike, priceBreakdown)) return;

    // ── EXIT PRIORITY 3: HARD STOP (catastrophic mark≤5¢ or thesis BROKEN) ───
    // Must still run before holdToSettlement. VALID + deep red % does NOT exit.
    if (await this.checkHardStop(trade, currentSidePrice, perContractPnl, secs, priceBreakdown, openThesis.status)) return;

    // ── EXIT PRIORITY 4: ARIA EXIT (Task #427 / P5 ARIA GUARDIAN) ─────────────
    // Order: thesis-break > lag-flip > hard stop > ARIA EXIT >
    // settlement-hold > soft/time/trailing. See resolveExitPriority()
    // in aria-guardian.ts. Two independent ARIA authorities share this tier:
    //   1. The pre-existing sustained-DANGER LLM veto (originally landed ahead
    //      of checkHardStop — RELOCATED here 2026-08-26 so a live DANGER read
    //      can never race ahead of the account's real hard stop; trigger/
    //      threshold unchanged: expertAgent.isSustainedDanger() still requires
    //      2+ CONSECUTIVE fresh DANGER reads).
    //   2. The new deterministic Guardian (aria-guardian.ts) — a state-driven
    //      scored policy (NOT an LLM call on this hot tick path) that can
    //      recommend HOLD/TIGHTEN/EXIT/SETTLE_HOLD from MarketState/lag/
    //      liquidity/thesis-persistence signals already computed elsewhere.
    //      EXIT only actually fires through isAriaExitAllowed()'s hard gate
    //      (confidence ≥ ARIA_EXIT_MIN_CONF, real evidence, past the entry
    //      grace period, not too close to expiry) and always applies via the
    //      same exitEarly() used by every other exit path here — never a new
    //      order-placement path of its own.
    if (ariaMayGovernOrders(this.config) && expertAgent.isSustainedDanger()) {
      const dangerReason = expertAgent.getFreshAssessment()?.reasoning ?? "—";
      this.log("warn", `🤖 ARIA sustained DANGER — gated in-trade exit: ${dangerReason}`);
      await this.exitEarly("ARIA_GATED_EXIT", currentSidePrice, priceBreakdown);
      return;
    }
    if (await this.checkAriaGuardian(trade, currentSidePrice, perContractPnl, secs, vel, tick.floorStrike, priceBreakdown)) return;

    // ── HOLD-TO-SETTLEMENT MODE ───────────────────────────────────────────────
    // Binary contracts settle in or out of the money; intra-period marks are
    // noise. Evidence (Aug 1 2026 audit of 53 settled trades): median hold was
    // ~30 s on a 15-min contract, and 10 of 34 losses would have settled as
    // WINS if simply held. In this mode only three exits exist:
    //   1. High-odds profit lock at ≥85¢ (capture ~90% of max, skip settle risk)
    //   2. Catastrophic thesis break — BTC decisively through the strike
    //      against us, sustained ≥10s, market confirms (≤25¢), enough time
    //      left that the market's low price is meaningful
    //   3. Settlement itself (detectSettlement)
    if (this.config.holdToSettlement && !isHoldToSettlementExempt(trade)) {
      // 1. Profit lock
      if (currentSidePrice >= 85) {
        this.log("info",
          `💰 High-odds exit (hold mode): contract at ${currentSidePrice.toFixed(0)}¢ · ` +
          `+${perContractPnl.toFixed(1)}¢/contract vs ${trade.entryPriceCents}¢ entry`);
        await this.exitEarly("HIGH_ODDS_EXIT", currentSidePrice, priceBreakdown);
        return;
      }
      // 2. Catastrophic thesis break — moved out to checkThesisBreak() (2026-08-14),
      //    called unconditionally BEFORE this hold-to-settlement branch so it fires
      //    even under hold mode, not just here. That call already ran above and
      //    returned if it fired, so reaching this point means no thesis-break rule
      //    was satisfied this tick. See checkThesisBreak's doc comment.
      // 4. Hard floor — a last-resort backstop independent of the thesis-break
      //    check above (Task #303). Thesis-break only fires once WE positively
      //    confirm BTC crossed the strike against us (btcPrice vs tick.floorStrike
      //    with a buffer); if that computation ever disagrees with the live
      //    market — a stale/noisy btcPrice sample, a series without a clean
      //    floorStrike, a momentary feed gap — throughStrike can simply never
      //    become true while the LIVE MARKET price has already cratered to
      //    near-zero. Without this, such a trade has zero exits left in hold
      //    mode and rides all the way to settlement for a guaranteed max loss,
      //    exactly the "point of no return" gap this task is about. This check
      //    trusts only the market's own live price (no strike computation
      //    required), so it is deliberately a stricter/lower threshold than
      //    thesis-break's ≤25¢, and uses the same 20-tick sustain + secs>5
      //    gating so a single wick can't shake us out of a genuinely live trade.
      const HOLD_MODE_HARD_FLOOR_CENTS = 8;
      if (currentSidePrice <= HOLD_MODE_HARD_FLOOR_CENTS) {
        this.holdModeHardFloorTicks++;
      } else {
        this.holdModeHardFloorTicks = 0;
      }
      if (this.holdModeHardFloorTicks >= 20 && secs > 5) {
        const floorGreen = Number.isFinite(currentSidePrice) && Number.isFinite(trade.entryPriceCents)
          && currentSidePrice > trade.entryPriceCents;
        if (!holdHardFloorMaySell({
          markCents: currentSidePrice,
          ticketGreen: floorGreen,
          thesisStatus: openThesis.status,
          holdMs: Date.now() - trade.openedAt,
        })) {
          this.holdModeHardFloorTicks = 0;
        } else {
        this.holdModeHardFloorTicks = 0;
        this.log("warn",
          `🛑 Hard floor (hold mode): market ${currentSidePrice.toFixed(0)}¢ sustained ≤` +
          `${HOLD_MODE_HARD_FLOOR_CENTS}¢ with no strike-break confirmation · salvaging remaining value`);
        await this.exitEarly("HOLD_HARD_FLOOR", currentSidePrice, priceBreakdown);
        return;
        }
      }
      // 5. Otherwise: hold. Settlement is handled by detectSettlement().
      return;
    }

    // Thesis failure: velocity strongly reversed AND stalling.
    // Threshold raised from 45 → 65 $/min: at 45 a modest BTC drift against the
    // position combined with a stall fires a soft stop too easily.  65 requires a
    // genuine sustained reversal before the thesis is considered broken.
    const velocityAgainstUs = (trade.side === "yes" && vel < -65) ||
                               (trade.side === "no"  && vel >  65);
    const thesisBroken  = velocityAgainstUs && stalling;

    // structureFail: velocity > 100 $/min against position, not stalling.
    // Previously fired on a SINGLE tick — in volatile BTC markets a 100 $/min
    // spike for one sample is noise, not a genuine reversal.  Now requires 2+
    // consecutive ticks (same pattern as FAST_REVERSAL) before the soft stop
    // is allowed to use it as a trigger.
    const moderateReversal = velocityAgainstUs && !stalling && Math.abs(vel) > 100;
    if (moderateReversal) {
      this.structureFailTicks++;
    } else {
      this.structureFailTicks = 0;
    }
    const leftoverFrBook = isPathRideFlickerBook(trade) || trade.strategyId === "NO_CROSS";
    const ticketAdverseCentsHere = trade.entryPriceCents - currentSidePrice;
    // CC/LAG/HA_*/NO_CROSS: structure-fail must not dump a green coupon.
    const structureFail = this.structureFailTicks >= 2
      && (!leftoverFrBook || ticketAdverseThesisBreakOk(ticketAdverseCentsHere));

    // ── Fast-reversal exit: consecutive ticks of strong counter-velocity ───────
    // When a rapid move flips sharply against us (> 120 $/min) for 2+ straight
    // ticks we exit immediately — a sustained fast reversal wrecks binary P&L
    // faster than any normal stop can react.
    const strongReversal = (trade.side === "yes" && vel < -120) ||
                           (trade.side === "no"  && vel >  120);
    if (strongReversal) {
      this.fastReversalTicks++;
    } else {
      this.fastReversalTicks = 0;
    }
    if (this.fastReversalTicks >= 2) {
      const holdMs = Date.now() - trade.openedAt;
      const ticketAdverseCents = ticketAdverseCentsHere;
      const catastrophic = Number.isFinite(currentSidePrice) && currentSidePrice <= CATASTROPHIC_MARK_CENTS;
      // Leftover-15s: CC/LAG/PATH_RIDE/HA_/NO_CROSS FAST_REVERSAL needs 15s+3¢
      // (pathRideAntiFlickerExitOk) + thesisStatus===BROKEN. EXIT organ A: cannot
      // soft-dump VALID/UNKNOWN/green. Empty ≠ BROKEN. Ruin ≤5¢ (catastrophic) stays.
      // PATH_RIDE early-return above owns CC/LAG — this bind is leftover non-ride only.
      const ticketGreenFr = Number.isFinite(currentSidePrice)
        && Number.isFinite(trade.entryPriceCents)
        && currentSidePrice > trade.entryPriceCents;
      const thesisBrokenExplicit = openThesis.status === "BROKEN";
      if (!catastrophic && (
        ticketGreenFr
        || !thesisBrokenExplicit
        || !pathRideAntiFlickerExitOk({ holdMs, ticketAdverseCents })
      )) {
        return;
      }
      this.fastReversalTicks = 0;
      this.structureFailTicks = 0; // clear both counters on hard exit
      await this.exitEarly("FAST_REVERSAL", currentSidePrice, priceBreakdown);
      return;
    }

    // ── Get dynamic stop/profit targets ───────────────────────────────────────
    const mtf = mtfAnalyzer.getSummary();
    const configuredStopCents   = this.config.useDynamicStop
      ? (mtf?.dynamicStopCents ?? this.config.stopLossCents)
      : this.config.stopLossCents;
    const configuredProfitCents = this.config.useDynamicProfit
      ? (mtf?.dynamicProfitCents ?? this.config.profitTakeCents)
      : this.config.profitTakeCents;
    // ARIA may only tighten existing exit thresholds. It cannot disable a
    // forced exit, expand a stop, or override hold-to-settlement safeguards.
    const riskOverrides = ariaMayGovernOrders(this.config) ? expertAgent.getRiskOverrides() : null;
    const agentExit = riskOverrides?.exitPolicy ?? null;
    this.lastAgentExitPolicy = agentExit;
    this.lastAgentSizeMultiplier = riskOverrides?.sizeMultiplier ?? null;
    const stopCents = agentExit?.stopLossCents !== undefined
      ? Math.min(configuredStopCents, agentExit.stopLossCents)
      : configuredStopCents;
    const baseProfitCents = agentExit?.profitTakeCents !== undefined
      ? Math.min(configuredProfitCents, agentExit.profitTakeCents)
      : configuredProfitCents;
    const preAriaTrailingProfitCents = agentExit?.trailingProfitCents !== undefined
      ? Math.min(this.config.trailingProfitCents, agentExit.trailingProfitCents)
      : this.config.trailingProfitCents;
    // P5 ARIA GUARDIAN: same independent multiplicative TIGHTEN layer as the
    // stop calc above — mult always in (0,1], never widens, applied on top of
    // agentExit's own tighten-only override, never a separate ratchet.
    const trailingProfitCents = this.ariaGuardianTighten?.trailMult
      ? Math.max(1, Math.round(preAriaTrailingProfitCents * this.ariaGuardianTighten.trailMult))
      : preAriaTrailingProfitCents;
    const timeStopMinutes = agentExit?.timeStopMinutes !== undefined
      ? Math.min(this.config.timeStopMinutes, agentExit.timeStopMinutes)
      : this.config.timeStopMinutes;
    const rawTimeStopMinGainCents = agentExit?.timeStopMinGainCents !== undefined
      // A higher threshold exits weak profits sooner. Unlike the other exit
      // widths, this is therefore a lower-bound tightening control.
      ? Math.max(this.config.timeStopMinGainCents, agentExit.timeStopMinGainCents)
      : this.config.timeStopMinGainCents;
    // Manual ceiling extension (2026-08-15): same Math.max-against-raw-config
    // shape as minConfidence had pre-Phase-1 — ARIA could ratchet this above
    // the operator's own value indefinitely. Cap it while autoMode=false.
    const timeStopMinGainCap = capToManualBoundary(
      rawTimeStopMinGainCents, this.config.timeStopMinGainCents, this.config.autoMode, "higher-is-tighter",
    );
    if (timeStopMinGainCap.capped) {
      console.warn(`[manual-floor-guard] ARIA tightened timeStopMinGainCents to ${rawTimeStopMinGainCents} while autoMode=false — capped to manual ${this.config.timeStopMinGainCents}`);
    }
    const timeStopMinGainCents = timeStopMinGainCap.value;

    // Entry admitted a fee/slippage-aware, fixed maximum loss. MTF/ARIA can
    // make the current stop tighter, but cannot widen the money at risk after
    // the fact. Legacy in-memory trades have no snapshot, so retain the old
    // gross-upside fallback only for their remaining lifetime.
    const legacyStopCeiling = Math.max(0, 100 - trade.entryPriceCents);
    const entryStopCeiling = trade.entryStopCents ?? legacyStopCeiling;
    const preAriaCappedStopCents = !trade.isOTMAsymmetry
      ? Math.min(stopCents, entryStopCeiling)
      : stopCents;
    if (preAriaCappedStopCents < stopCents) {
      this.log("info", `[risk-cap] stop-loss capped ${stopCents}¢ → ${preAriaCappedStopCents}¢ by entry-time reward/risk plan`);
    }
    // P5 ARIA GUARDIAN: independent multiplicative TIGHTEN layer, applied on
    // TOP of every cap above (agentExit's own tighten-only min/max, and the
    // entry-time risk ceiling). Multiplier is always in (0,1] (clampTighten
    // guarantees this) so this can only ever shrink further, never escape
    // preAriaCappedStopCents/undo the ceiling — see aria-size-multiplier-
    // double-count in memory for why this stays a SEPARATE layer rather than
    // folding into agentExit's own min()/max() calc.
    const riskCappedStopCents = this.ariaGuardianTighten?.stopMult
      ? Math.round(preAriaCappedStopCents * this.ariaGuardianTighten.stopMult)
      : preAriaCappedStopCents;
    if (riskCappedStopCents < preAriaCappedStopCents) {
      this.log("info", `[aria-guardian] stop-loss tightened ${preAriaCappedStopCents}¢ → ${riskCappedStopCents}¢ (stopMult=${this.ariaGuardianTighten!.stopMult!.toFixed(2)})`);
    }

    // ── Profit target ─────────────────────────────────────────────────────────
    //
    // OTM Asymmetry Hunter uses a completely different exit philosophy:
    // the user's manual style is to cash out at 75–97¢ contract value rather
    // than holding to binary settlement. At an 8¢ entry:
    //   Normal target:  max(12, 92 × 0.28) = 26¢ → exits at 34¢ contract value
    //   OTM target:     75 − 8 = 67¢ profit      → exits at 75¢ contract value
    // This captures ~80% of theoretical max while eliminating binary settlement risk.
    // A 6× multiplier floor (e.g. 8¢ → 48¢ gain floor) ensures we still exit
    // early if the contract spikes fast before reaching 75¢.
    //
    // Normal path: scale to 28% of max payout so near-the-money trades don't
    // leave money on the table when a 30¢ entry naturally runs to 70¢+.
    // ── High-odds exit: cash out when contract reaches 85¢+ ─────────────────
    // User strategy: ride to settlement OR take profits at 85-90% odds.
    // When the contract is at 85¢ we've captured 85-90% of maximum gain —
    // e.g. a 40¢ entry that reaches 85¢ = +45¢ profit = 112% return.
    // At 30¢ entry → 85¢ = +55¢ = 183% return (well over the "2×" target).
    // We prefer not to hold the last 15¢ risk-free gap through settlement noise.
    const HIGH_ODDS_EXIT = 85; // ¢ contract value to cash out
    if (!trade.isOTMAsymmetry && currentSidePrice >= HIGH_ODDS_EXIT) {
      this.log("info",
        `💰 High-odds exit: contract at ${currentSidePrice.toFixed(0)}¢ ≥ ${HIGH_ODDS_EXIT}¢ · ` +
        `+${perContractPnl.toFixed(1)}¢ per contract · entry was ${trade.entryPriceCents}¢`
      );
      await this.exitEarly("HIGH_ODDS_EXIT", currentSidePrice, priceBreakdown);
      return;
    }

    const maxPotentialGain = Math.max(0, 100 - trade.entryPriceCents);
    let profitCents: number;
    if (trade.isOTMAsymmetry) {
      // OTM: exit near 75¢ contract value OR at 6× return — whichever is lower
      const targetContractValue = 80;  // was 75 — push target higher for bigger gains
      const absoluteTarget = Math.max(0, targetContractValue - trade.entryPriceCents);
      const multiplierTarget = trade.entryPriceCents * 6;  // 6× e.g. 8¢ → 48¢ gain
      profitCents = Math.min(absoluteTarget, multiplierTarget);
    } else {
      // Normal path: target 75% of max potential gain rather than 28%.
      // This aligns with the "ride to settlement" philosophy — we take early
      // profits only when the position is very close to its ceiling, not after
      // a small 12¢ move.  The high-odds exit at 85¢ handles the final leg.
      profitCents = computeNormalTargetProfitCents(
        trade.entryPriceCents,
        baseProfitCents,
        this.config.useProfitTake,
      );
      // ARIA's fresh policy is a conservative ceiling on the FINAL derived
      // target, not merely the static base value. Without this cap the 75%-of-
      // upside floor could mask a valid smaller AI target entirely (e.g. 40¢
      // entry → 45¢ target despite ARIA requesting 5¢). Mandatory high-odds,
      // hard-stop, hold-to-settlement, and settlement exits remain earlier in
      // the decision order and cannot be changed by the agent.
      if (agentExit?.profitTakeCents !== undefined) {
        profitCents = Math.min(profitCents, agentExit.profitTakeCents);
      }
      // Reward/risk was admitted using this precise entry-time target. Later
      // MTF/ARIA updates may not silently lower the reward while the matching
      // entry stop stays immutable; doing so would make an approved ≥1.0 R/R
      // trade economically worse after it is already open.
      const targetBeforeEntryFloor = profitCents;
      profitCents = preserveEntryTargetFloor(profitCents, trade.entryTargetProfitCents);
      if (profitCents > targetBeforeEntryFloor) {
        this.log("info",
          `[risk-cap] profit target held at entry plan +${profitCents}¢ ` +
          `(live target tried to tighten to +${targetBeforeEntryFloor}¢)`);
      }
    }

    // ── Stop-loss: value-based (market price) OR fixed-¢ ─────────────────────
    // All stop checks use the raw market price (currentSidePrice / perContractPnl).
    // Previously used evalSidePrice (60% theoretical blend) which caused the
    // model's conviction (e.g. theory → 1¢) to fire hard stops when the actual
    // executable market price had barely moved.  Stops should only fire when
    // you can actually exit at a bad price, not when the model predicts you will.
    if (shouldEnforceNormalTradeStop({
      isOTMAsymmetry: trade.isOTMAsymmetry,
      useStopLoss: this.config.useStopLoss,
      entryStopCents: trade.entryStopCents,
    })) {
      // Advertised ¢ / % stops. Stellar: while thesis VALID/UNKNOWN these do
      // not fire. BROKEN uses TB/lag first; this is backup. OTM exempt.
      const stopDecision = evaluateStopLossDecision({
        useStopLoss: this.config.useStopLoss,
        isOTMAsymmetry: trade.isOTMAsymmetry,
        perContractPnl,
        riskCappedStopCents,
        usePctStops: this.config.usePctStops,
        entryPriceCents: trade.entryPriceCents,
        currentSidePrice,
        softStopPct: this.config.softStopPct,
        thesisBroken,
        structureFail,
        entryStopCents: trade.entryStopCents,
        thesisStatus: openThesis.status,
      });
      if (stopDecision) {
        await this.exitEarly(stopDecision, currentSidePrice, priceBreakdown);
        return;
      }
    }

    // ── MTF bias shift against position ───────────────────────────────────────
    if (this.config.useMTFFilter && mtf) {
      const mtfAgainst = (trade.side === "yes" && mtf.score <= -2) ||
                         (trade.side === "no"  && mtf.score >=  2);
      if (mtfAgainst && perContractPnl < -5) {
        await this.exitEarly("MTF_REVERSAL", currentSidePrice, priceBreakdown);
        return;
      }
    }

    // ── Settlement hold — ride deep-ITM contracts to expiry ──────────────────
    // When the model shows high win-probability, the contract is deep in-the-money,
    // and fewer than N seconds remain, the expected value of holding to the full
    // 100¢ settlement FAR exceeds any early exit.
    //
    // Example: enter YES at 40¢, now eval 78¢ with 3 min left, modelProb 88%
    //   Early exit EV  = (78 − 40) × 0.93 = +35.3¢ per contract (guaranteed)
    //   Hold EV        = 0.88 × 60 × 0.93 − 0.12 × 40 = +49.1 − 4.8 = +44.3¢
    //   → Hold is worth +9¢ more per contract before position-size multiplier
    //
    // Hard stops and fast-reversal exits (above) remain fully active.
    {
      // p = fill-path winRateAtPrice at the traded ask. Do not 1-p lastModelProb.
      const winProbRaw = fillPathPWin(trade.strategyWinRateAtEntry) ?? liveModelProb;
      const winProb = typeof winProbRaw === "number" ? winProbRaw : Number.NaN;
      // ── Expert Agent setup-control overrides (tighten-only) ─────────────────
      // ARIA may shrink the hold window (engage the hold only closer to expiry)
      // and/or raise the win-probability bar required to commit to riding a
      // position to settlement. getEffectiveSettlementHold() is the single
      // source of truth shared with evaluateEntry()/_placeOrderBody(), so this
      // is exactly the same window/probability the entry-time EV gate assumed
      // — a fresh AI read can only make the hold policy stricter, never
      // looser; a stale/absent assessment leaves both at their static values.
      const { secsThreshold: effSettlementHoldSecsThreshold, minProb: effSettlementHoldMinProb } =
        this.getEffectiveSettlementHold();
      // evalSidePrice threshold lowered from 70→55: at a 60¢ entry the blended
      // price (60% theoretical + 40% market) can sit at ~65¢ when BTC is well
      // above the floor but the market book has temporarily thinned.  Requiring
      // >70 was blocking the hold in exactly those cases.
      // 2026-08-14: the old >-12 tolerance let the hold ENGAGE and CONTINUE on
      // a small red mark-to-market, on the theory that a blended-price wobble
      // doesn't necessarily mean BTC crossed the floor. The user's explicit
      // requirement is stricter — settlement hold must never ride a red or
      // sub-min-gain position on model-probability confidence alone, so this
      // now uses settlementHoldMinGainCents (default 0: must be at/above
      // breakeven) as its own named, independently reasoned-about gate.
      const settlementHoldGainOk = perContractPnl >= this.config.settlementHoldMinGainCents;
      // ── Lag gate (2026-08-14, "use lag knowledge for every trade") ─────────
      // Settlement hold may only continue while the exchange-led projection
      // agrees with our side OR is neutral/stale (isLagAgainstSide already
      // treats missing/stale data as "not against" — never punished). A
      // single confirmed-against tick disqualifies the hold; no persistence
      // requirement here because this only withdraws hold ELIGIBILITY (falls
      // back to the normal soft/time/trailing stop stack below), it does not
      // itself force an exit — LAG_FLIP_EXIT above is the persistence-gated
      // exit for that.
      const lagAgainstHold = this.isLagAgainstSide(trade.side, tick.floorStrike, vel, secs);
      // LOCKED_ITM hold-sell: minProb 0.58 + evalSidePrice>55 is not enough to
      // ride to expiry. decideHoldOrSell HOLD_SETTLE requires mark>=90 AND a
      // USD wick budget the strike cannot cover in time left (maxWickDollars).
      // Cheap-side/OTM never HOLD_SETTLE (isHoldToSettlementExempt + the
      // duplicated check inside hold-sell.ts). Does not reorder hard stop /
      // thesis-break / lag-flip (already ran above). Does not flip
      // holdToSettlement true. Does not use confidence as p.
      const holdSellProj = (!basisTracker.isFairValueStale() && this.lastBasisState?.estimatedFairBRTI != null)
        ? projectSettlementPrice(this.lastBasisState.estimatedFairBRTI, vel, secs)
        : null;
      const brtiNow = Date.now();
      const brtiPrints = secs > 0 && secs <= 60
        ? this.prices.filter((px: { ts: number; price: number }) => brtiNow - px.ts <= 60_000 && Number.isFinite(px.price) && px.price > 0).map((px: { ts: number; price: number }) => px.price)
        : null;
      const holdSell = decideHoldOrSell({
        strategyId: trade.strategyId ?? null,
        isOTMAsymmetry: trade.isOTMAsymmetry,
        markCents: currentSidePrice,
        entryCents: trade.entryPriceCents,
        peakUnrealizedCents: this.openTradeMaxGain,
        secsRemaining: secs,
        projectedSettlement: holdSellProj,
        floor: tick.floorStrike > 0 ? tick.floorStrike : null,
        side: trade.side,
        hardStop: false,
        thesisBreak: false,
        lagFlip: false,
        trailingGivebackCents: this.config.trailingProfitCents ?? 12,
        preferEarlyExit: trade.preferEarlyExit === true,
        holdMs: Date.now() - trade.openedAt,
        ohlc1m: getMtfOhlcBars(1)?.bars ?? null,
        ohlc5m: getMtfOhlcBars(5)?.bars ?? null,
        spot: btcPrice,
        brtiPrints: brtiPrints && brtiPrints.length > 0 ? brtiPrints : null,
        brtiSpot: btcPrice,
      });
      const settlementHoldEligible =
        this.config.useSettlementHold
        && !isHoldToSettlementExempt(trade)
        && secs > 0
        && secs < effSettlementHoldSecsThreshold
        && settlementHoldGainOk
        && evalSidePrice > 55
        && winProb >= effSettlementHoldMinProb
        && !lagAgainstHold
        && holdSell.action === "HOLD_SETTLE";

      if (settlementHoldEligible && !this.settlementHoldActive) {
        this.settlementHoldActive = true;
        // Fee-correct settlement hold EV:
        //   hold: win gets (net win after taker fee); loss costs (entry + taker fee)
        //   exit: sell at evalSidePrice, pay exit taker fee on the exit order
        const netWinAtSettle   = kalshiNetWinCents(trade.entryPriceCents);
        const totalEntryCost   = kalshiNetCostCents(trade.entryPriceCents);
        const holdEV = winProb * netWinAtSettle - (1 - winProb) * totalEntryCost;
        const exitProceeds = Math.max(0, evalSidePrice - kalshiFeeCents(evalSidePrice));
        const exitEV = Math.max(0, exitProceeds - trade.entryPriceCents - kalshiFeeCents(trade.entryPriceCents));
        this.log("info",
          `🏁 Settlement hold engaged: ${Math.floor(secs / 60)}m ${secs % 60}s left · ` +
          `eval ${evalSidePrice.toFixed(0)}¢ · winProb ${(winProb * 100).toFixed(0)}% · ` +
          `hold EV +${holdEV.toFixed(1)}¢ vs exit EV +${exitEV.toFixed(1)}¢ per contract · ` +
          `max settle gain +$${(netWinAtSettle * trade.contracts / 100).toFixed(2)}`
        );
      } else if (!settlementHoldEligible && this.settlementHoldActive) {
        this.settlementHoldActive = false;
        if (!settlementHoldGainOk) {
          this.log("warn",
            `🔓 HOLD_CANCEL_GAIN_GONE: settlement hold cancelled — unrealized ${perContractPnl.toFixed(1)}¢ ` +
            `< min ${this.config.settlementHoldMinGainCents}¢ (or negative) despite winProb ` +
            `${(winProb * 100).toFixed(0)}% · re-enabling soft/time stops · secsLeft=${secs} ` +
            `side=${trade.side.toUpperCase()} entry=${trade.entryPriceCents}¢ eval=${evalSidePrice.toFixed(0)}¢`
          );
        } else if (lagAgainstHold) {
          this.log("warn",
            `🔓 HOLD_CANCEL_LAG_FLIP: settlement hold cancelled — exchange-led projection now against ` +
            `${trade.side.toUpperCase()} · modelProb ${(winProb * 100).toFixed(0)}% · re-enabling soft/time ` +
            `stops (hard stop remains unconditional) · secsLeft=${secs} unrealizedCents=${perContractPnl.toFixed(1)}`
          );
        } else {
          this.log("info", `🔓 Settlement hold released — conditions no longer met, resuming normal exits`);
        }
      }

      if (settlementHoldEligible) return; // suppress trailing stop, profit-take, time-decay, breakeven guard
    }

    // ── Near-expiry safety exit for small accounts (normal trades only) ─────────
    // OTM_ASYMMETRY skips this: an 8¢ entry will have perContractPnl < 8 for
    // the entire trade until BTC actually crosses the floor — we'd exit every
    // OTM position in the last 3 minutes before it has a chance to pay off.
    if (!trade.isOTMAsymmetry && !isPathRideOpenTrade(trade)) {
      const equityExit = this.config.paperMode
        ? this.paperVirtualBalanceCents
        : (this.accountBalance ?? 0);
      if (equityExit < 5000 && secs < 180 && perContractPnl < 8) {
        await this.exitEarly("TIME_STOP_SMALL_ACCT", currentSidePrice, priceBreakdown);
        return;
      }
    }

    // ── Smart time stop: < N min left AND not clearly winning ─────────────────
    // OTM trades: a flat OTM position with < 2.5 min left is fine — let it run.
    // Normal trades: cut flat/losing positions before they expire worthless.
    // PATH_RIDE already returned above (decidePathRideExit only; no leftover
    // TB / FR / HARD_STOP). Do not TIME_STOP fallthrough <15s if tagging missed.
    // hold-sell SELL already consumed as first exit — do not race a second.
    const pathRideHoldMs = Date.now() - trade.openedAt;
    const pathRideNoTimeStop = isPathRideOpenTrade(trade)
      || (isPathRideKellyBook(trade.strategyId)
        && Number.isFinite(pathRideHoldMs)
        && pathRideHoldMs < THESIS_BREAK_MIN_HOLD_MS);
    if (!pathRideNoTimeStop && !trade.isOTMAsymmetry && this.config.useTimeStop && secs < timeStopMinutes * 60) {
      if (perContractPnl <= 0) {
        await this.exitEarly("TIME_STOP", currentSidePrice, priceBreakdown);
        return;
      }
      if (perContractPnl < timeStopMinGainCents && thesisBroken) {
        await this.exitEarly("TIME_STOP_WEAK", currentSidePrice, priceBreakdown);
        return;
      }
    }

    // Money-maker PATH_RIDE owns exits — fixed profitTakeCents / trailing / breakeven
    // must not compete on CC/LAG (belt-and-suspenders; isPathRideOpenTrade already returned).
    if (isPathRideFlickerBook(trade) || isMoneyMakerStrategyId(trade.strategyId)) {
      return;
    }

    // ── Trailing stop ─────────────────────────────────────────────────────────
    // OTM path: wide band (25¢) that only activates above 40¢ peak — we want to
    // ride the contract from 8¢ to 75¢+ without getting shaken out at 30¢.
    // Once the contract has run to 50¢+ peak, tighten to 20¢ so we exit near
    // the top rather than giving back the whole gain.
    //
    // Normal path: 3-tier trailing stop with settlement approach widening.
    if (this.config.useProfitTake) {
      if (trade.isOTMAsymmetry) {
        // Two-tier OTM trailing stop:
        //
        // Tier 1 — "Quick spike" (peak ≥ 100% of entry, i.e. contract doubled):
        //   Catches the pattern where BTC lurches toward the floor, the contract
        //   briefly doubles (10¢→20¢, 15¢→30¢), then BTC reverses and the
        //   contract collapses back to zero. Trail at 30% of peak gain so we
        //   capture the 2–3× without holding through the reversal.
        //   Example: 10¢ entry → peak 20¢ (+10¢) → trail=3¢ → exit if slides to 17¢.
        //
        // Tier 2 — "Full run" (peak ≥ 40¢ gain):
        //   BTC has crossed or is very near the floor; the contract is in deep
        //   in-the-money territory. Use a wider fixed band (25¢) to ride it
        //   toward the 75¢ PROFIT_TAKE target without getting shaken out by
        //   normal settlement noise. Tighten to 20¢ once peak hits 50¢+.
        const OTM_QUICK_ACTIVATE = trade.entryPriceCents;  // 100% gain = 2× entry
        const OTM_FULL_ACTIVATE  = 40;  // ¢ peak to enter full-run zone
        const OTM_TRAIL_WIDE     = 25;  // ¢ band in full-run zone (< 50¢ peak)
        const OTM_TRAIL_TIGHT    = 20;  // ¢ band in full-run zone (≥ 50¢ peak)

        const slippage = this.openTradeMaxGain - perContractPnl;

        if (this.openTradeMaxGain >= OTM_FULL_ACTIVATE) {
          // Tier 2: full-run — fixed wide band
          const trailBand = this.openTradeMaxGain >= 50 ? OTM_TRAIL_TIGHT : OTM_TRAIL_WIDE;
          if (slippage >= trailBand) {
            this.log("info",
              `🎯 OTM full-run trail: peak=${this.openTradeMaxGain.toFixed(1)}¢ ` +
              `current=${perContractPnl.toFixed(1)}¢ slippage=${slippage.toFixed(1)}¢ band=${trailBand}¢`);
            await this.exitEarly("TRAILING_STOP", currentSidePrice, priceBreakdown);
            return;
          }
        } else if (this.openTradeMaxGain >= OTM_QUICK_ACTIVATE) {
          // Tier 1: quick spike — 30% of peak gain, min 3¢
          const trailBand = Math.max(3, Math.ceil(this.openTradeMaxGain * 0.30));
          if (slippage >= trailBand) {
            this.log("info",
              `🎯 OTM quick-spike trail: peak=${this.openTradeMaxGain.toFixed(1)}¢ ` +
              `current=${perContractPnl.toFixed(1)}¢ slippage=${slippage.toFixed(1)}¢ band=${trailBand}¢ ` +
              `(entry=${trade.entryPriceCents}¢ 30% of peak)`);
            await this.exitEarly("TRAILING_STOP", currentSidePrice, priceBreakdown);
            return;
          }
        }
      } else {
        // Normal 3-tier trailing stop with settlement approach widening.
        //
        // Gap fix: previously TRAIL_ACTIVATE fired at 6.3¢ but used a 10¢ band,
        // so a trade that peaked at 8¢ would trail 10¢ and exit at −2¢ — a loss
        // from a profitable peak. Fix: when the trailing stop would exit below
        // entry (perContractPnl < 0), suppress it and let the hard/soft stop
        // system handle the position instead. The trailing stop's job is to lock
        // in gains, not duplicate stop-loss logic.
        const inSettlementApproach = secs < 240 && perContractPnl > 0;
        const settlementMult       = inSettlementApproach ? 1.5 : 1.0;
        const TRAIL_ACTIVATE = Math.max(5, profitCents * 0.35);
        const TRAIL_TIGHT    = profitCents * 0.70;
        if (this.openTradeMaxGain >= TRAIL_ACTIVATE) {
          const slippage  = this.openTradeMaxGain - perContractPnl;
          const baseBand  = this.openTradeMaxGain >= TRAIL_TIGHT
            ? Math.max(3, Math.ceil(trailingProfitCents * 0.5))
            : trailingProfitCents;
          const trailBand = Math.ceil(baseBand * settlementMult);
          if (slippage >= trailBand && perContractPnl >= 0) {
            // Only fire when still at or above entry — trailing stop = profit protector.
            // If position has already crossed below entry, let hard/soft stop handle it.
            this.log("info",
              `🎯 Trailing stop: peak=${this.openTradeMaxGain.toFixed(1)}¢ ` +
              `current=${perContractPnl.toFixed(1)}¢ slippage=${slippage.toFixed(1)}¢ ` +
              `band=${trailBand}¢${inSettlementApproach ? ' (settlement×1.5)' : ''}`);
            await this.exitEarly("TRAILING_STOP", currentSidePrice, priceBreakdown);
            return;
          }
        }
      }
    }

    // ── Breakeven guard ───────────────────────────────────────────────────────
    // Normal trades only — OTM trades start underwater by design (the contract
    // stays at 5–15¢ for most of its life until the move happens). Applying a
    // breakeven guard would fire constantly and kill the position.
    // Breakeven guard threshold lowered from profitCents×0.60 to TRAIL_ACTIVATE
    // (max(5, profitCents×0.35) ≈ 6.3¢). Previously only activated at 10.8¢ peak,
    // leaving a gap where a trade that peaked at 7–10¢ could slip below entry
    // without any breakeven protection before the trailing stop band kicked in.
    const _beTrailActivate = Math.max(5, profitCents * 0.35);
    if (!trade.isOTMAsymmetry && this.config.useProfitTake
        && this.openTradeMaxGain >= _beTrailActivate && perContractPnl < -2) {
      this.log("info",
        `🛡 Breakeven guard: peaked at ${this.openTradeMaxGain.toFixed(1)}¢, ` +
        `now ${perContractPnl.toFixed(1)}¢ — protecting capital`);
      await this.exitEarly("BREAKEVEN_GUARD", currentSidePrice, priceBreakdown);
      return;
    }

    // ── Profit-take ───────────────────────────────────────────────────────────
    // OTM: fire as soon as target is hit — no momentum condition required.
    //   The user's style is to cash out once the contract is deep in-the-money
    //   (~75¢) rather than holding for binary settlement. Do the same.
    // Normal: only fire when momentum is failing (stall or reversal) so winners
    //   that are still accelerating keep running.
    if (this.config.useProfitTake && perContractPnl >= profitCents) {
      if (trade.isOTMAsymmetry) {
        await this.exitEarly("PROFIT_TAKE", currentSidePrice, priceBreakdown);
        return;
      }
      const momentumFailing = stalling || velocityAgainstUs;
      if (momentumFailing) {
        await this.exitEarly("PROFIT_TAKE", currentSidePrice, priceBreakdown);
        return;
      }
    }

    // ── Time-decay exit: last 90 seconds — lock in any profit (normal only) ───
    // OTM: the contract may only reach 75¢ in the final 90s as BTC approaches
    // settlement — exiting at >5¢ would kill the trade right before the payoff.
    if (!trade.isOTMAsymmetry && this.config.useTimeDecayExit && secs < 90 && perContractPnl > 5) {
      await this.exitEarly("TIME_DECAY", currentSidePrice, priceBreakdown);
      return;
    }

    // ── Late lock: solid profit + stalling near end (normal only) ────────────
    if (!trade.isOTMAsymmetry && this.config.useProfitTake
        && secs < 180 && perContractPnl >= profitCents * 0.7 && stalling) {
      await this.exitEarly("LATE_LOCK", currentSidePrice, priceBreakdown);
      return;
    }
}
