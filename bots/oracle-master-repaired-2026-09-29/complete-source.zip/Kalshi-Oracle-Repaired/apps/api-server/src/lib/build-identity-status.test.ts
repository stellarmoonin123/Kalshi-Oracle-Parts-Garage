/** R3 — gitSha must surface on getStatus() and /healthz (was null: fields absent). */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { runningGitSha } from "./frozen-cc.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));

test("runningGitSha honours baked GIT_SHA env", () => {
  const prev = process.env.GIT_SHA;
  process.env.GIT_SHA = "abc123def456";
  try { assert.equal(runningGitSha(), "abc123def456"); }
  finally { if (prev === undefined) delete process.env.GIT_SHA; else process.env.GIT_SHA = prev; }
});

test("getStatus + /healthz wire runningGitSha", () => {
  const bot = fs.readFileSync(path.join(HERE, "trading-bot.ts"), "utf8");
  const getStatus = bot.slice(bot.indexOf("  getStatus(): BotStatus {"));
  assert.match(getStatus.slice(0, 20000), /gitSha:\s+runningGitSha\(\)/);
  const health = fs.readFileSync(path.join(HERE, "..", "routes", "health.ts"), "utf8");
  assert.match(health, /build:\s*\{\s*gitSha:\s*runningGitSha\(\)/);
});

test("chat get_healthz / get_status surface build gitSha", async () => {
  const { runDeskTool } = await import("./chat-desk-tools.js");
  const deps: any = { getStatus: () => ({ gitSha: "sha-status" }), healthz: async () => ({ healthy: true, build: { gitSha: "sha-hz" } }) };
  assert.equal(JSON.parse(await runDeskTool("get_healthz", {}, deps)).gitSha, "sha-hz");
  assert.equal(JSON.parse(await runDeskTool("get_status", {}, deps)).gitSha, "sha-status");
});
