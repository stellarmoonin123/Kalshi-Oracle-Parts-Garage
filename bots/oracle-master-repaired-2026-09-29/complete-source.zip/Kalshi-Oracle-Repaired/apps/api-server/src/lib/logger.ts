import pino from "pino";

const isProduction = process.env.NODE_ENV === "production";

/** Paths pino redacts. Keep in sync with fail-clean.test.ts. */
export const LOG_REDACT_PATHS = [
  "req.headers.authorization",
  "req.headers.cookie",
  'req.headers["x-api-key"]',
  "res.headers['set-cookie']",
  "*.privateKey",
  "*.private_key",
  "*.apiKey",
  "*.api_key",
  "*.apiSecret",
  "*.password",
  "*.secret",
  "*.pem",
];

export const logger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  redact: LOG_REDACT_PATHS,
  ...(isProduction
    ? {}
    : {
        transport: {
          target: "pino-pretty",
          options: { colorize: true },
        },
      }),
});
