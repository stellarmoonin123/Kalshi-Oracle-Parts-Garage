/** Stub: paper settlement never stamps official YES/NO from leftover live API. */
export function paperSettlementMayStampOfficialYesNo(): false {
  return false;
}
