import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import zlib from "node:zlib";
import { maybeRotateJsonl, listArchives, pruneArchives, resetJsonlRotateForTests, DECISION_TRACE_ROTATE, REGIME_TRACE_ROTATE } from "./jsonl-rotate.js";

beforeEach(() => resetJsonlRotateForTests());
const dir = () => fs.mkdtempSync(path.join(os.tmpdir(), "rot-"));

test("under cap → no rotation", () => {
  const d = dir(); const f = path.join(d, "evaluate-decision-trace.jsonl");
  fs.writeFileSync(f, "{}\n");
  assert.equal(maybeRotateJsonl(f, { maxBytes: 100, keep: 3, maxAgeDays: 14, checkEveryMs: 0 }).rotated, null);
  assert.ok(fs.existsSync(f));
});

test("over cap → renamed + gzipped, content preserved, live file restarts", async () => {
  const d = dir(); const f = path.join(d, "evaluate-decision-trace.jsonl");
  const body = '{"a":1}\n'.repeat(50);
  fs.writeFileSync(f, body);
  const r = maybeRotateJsonl(f, { maxBytes: 100, keep: 3, maxAgeDays: 14, checkEveryMs: 0, nowMs: Date.UTC(2026, 8, 24, 12) });
  assert.ok(r.rotated);
  assert.equal(fs.existsSync(f), false);
  await r.gzip;
  const gz = `${r.rotated}.gz`;
  assert.ok(fs.existsSync(gz));
  assert.equal(fs.existsSync(r.rotated!), false);
  assert.equal(zlib.gunzipSync(fs.readFileSync(gz)).toString(), body);
  fs.appendFileSync(f, "{}\n");
  assert.equal(fs.readFileSync(f, "utf8"), "{}\n");
});

test("keep cap + age cap prune old archives; other files untouched", () => {
  const d = dir(); const f = path.join(d, "regime-decision-trace.jsonl");
  const names = ["20260901T000000Z", "20260920T000000Z", "20260921T000000Z", "20260922T000000Z", "20260923T000000Z"]
    .map((s) => path.join(d, `regime-decision-trace.${s}.jsonl.gz`));
  for (const n of names) fs.writeFileSync(n, "x");
  const old = new Date(Date.now() - 30 * 86_400_000);
  fs.utimesSync(names[0]!, old, old);
  for (const keepName of ["mind-calibration.jsonl", "mind-calibration-shadow.jsonl", "paper-trades.jsonl", "evaluate-decision-trace.20260901T000000Z.jsonl.gz"]) {
    fs.writeFileSync(path.join(d, keepName), "k");
  }
  pruneArchives(f, { maxBytes: 1, keep: 3, maxAgeDays: 14 });
  assert.equal(listArchives(f).length, 3);
  for (const keepName of ["mind-calibration.jsonl", "mind-calibration-shadow.jsonl", "paper-trades.jsonl", "evaluate-decision-trace.20260901T000000Z.jsonl.gz"]) {
    assert.ok(fs.existsSync(path.join(d, keepName)), keepName);
  }
});

test("stat throttle: second check within window is a no-op", () => {
  const d = dir(); const f = path.join(d, "x.jsonl");
  fs.writeFileSync(f, "y".repeat(500));
  const o = { maxBytes: 100, keep: 3, maxAgeDays: 14, nowMs: 1_000_000 };
  maybeRotateJsonl(f, { ...o, maxBytes: 10_000 });
  assert.equal(maybeRotateJsonl(f, { ...o, nowMs: 1_000_500 }).rotated, null);
});

test("caps: evaluate 50 MB, regime 20 MB, keep 3, 14 days", () => {
  assert.equal(DECISION_TRACE_ROTATE.maxBytes, 50 * 1024 * 1024);
  assert.equal(REGIME_TRACE_ROTATE.maxBytes, 20 * 1024 * 1024);
  assert.equal(DECISION_TRACE_ROTATE.keep, 3);
  assert.equal(DECISION_TRACE_ROTATE.maxAgeDays, 14);
});
