/**
 * bot-uptime-log.ts
 *
 * Append-only ON/OFF history for the trading bot so operators can see when
 * the desk was armed across restarts and crash gaps.
 *
 * Definitions (operator-facing):
 *   ON  = config.enabled === true AND runtime state is WATCHING / IN_TRADE
 *         (armed loop — not IDLE/STOPPED/SUSPENDED after stop).
 *   OFF = enabled false, or process stopped / IDLE after stop, or API down
 *         (gap closed on next boot).
 *
 * Only transitions + optional heartbeat ≤1/hour. Never spam ticks.
 * Does not touch paper ledger / EV floors / ENABLE leftovers.
 */

import fs from "node:fs";
import path from "node:path";

export type UptimeEvent =
  | "on"
  | "off"
  | "process_start"
  | "process_stop"
  | "gap"
  | "heartbeat";

export interface UptimeSegment {
  ts: number;
  event: UptimeEvent;
  state: string;
  enabled: boolean;
  paperMode: boolean;
  reason?: string;
  pid?: number;
}

export interface UptimeContext {
  state: string;
  enabled: boolean;
  paperMode: boolean;
  reason?: string;
  pid?: number;
  ts?: number;
}

export interface UptimeSummary {
  onMs: number;
  offMs: number;
  segments: UptimeSegment[];
  windowMs: number;
  fromTs: number;
  toTs: number;
}

export interface UptimeSnapshot {
  current: {
    on: boolean;
    state: string;
    enabled: boolean;
    paperMode: boolean;
    sinceTs: number | null;
    reason: string | null;
  };
  recent: UptimeSegment[];
  last24h: UptimeSummary;
  last7d: UptimeSummary;
}

const DEFAULT_FILE = path.join(process.cwd(), "data", "bot-uptime.jsonl");
const HEARTBEAT_MIN_INTERVAL_MS = 60 * 60 * 1000; // ≤1/hour
const RECENT_LIMIT = 80;

/** Armed = ON per operator definition. */
export function isBotArmed(enabled: boolean, state: string): boolean {
  return enabled === true && (state === "WATCHING" || state === "IN_TRADE");
}

function ensureDir(filePath: string) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
}

function readAll(filePath: string): UptimeSegment[] {
  try {
    if (!fs.existsSync(filePath)) return [];
    const raw = fs.readFileSync(filePath, "utf8");
    const out: UptimeSegment[] = [];
    for (const line of raw.split("\n")) {
      if (!line.trim()) continue;
      try {
        const row = JSON.parse(line) as UptimeSegment;
        if (
          typeof row.ts === "number" &&
          typeof row.event === "string" &&
          typeof row.state === "string" &&
          typeof row.enabled === "boolean" &&
          typeof row.paperMode === "boolean"
        ) {
          out.push(row);
        }
      } catch {
        // skip corrupt line
      }
    }
    return out;
  } catch (err) {
    console.error("[bot-uptime-log] failed to read:", (err as Error).message);
    return [];
  }
}

function appendLine(filePath: string, row: UptimeSegment): void {
  try {
    ensureDir(filePath);
    fs.appendFileSync(filePath, JSON.stringify(row) + "\n");
  } catch (err) {
    console.error("[bot-uptime-log] failed to append:", (err as Error).message);
  }
}

/** Last armed status implied by the log (ignores process_start/stop and heartbeat). */
export function lastArmedFromSegments(segments: UptimeSegment[]): boolean | null {
  for (let i = segments.length - 1; i >= 0; i--) {
    const e = segments[i]!.event;
    if (e === "on") return true;
    if (e === "off" || e === "gap") return false;
  }
  return null;
}

/** Timestamp of the most recent on/off/gap that set current armed status. */
export function lastArmedTransitionTs(segments: UptimeSegment[]): number | null {
  for (let i = segments.length - 1; i >= 0; i--) {
    const e = segments[i]!.event;
    if (e === "on" || e === "off" || e === "gap") return segments[i]!.ts;
  }
  return null;
}

export function summarizeUptime(
  segments: UptimeSegment[],
  windowMs: number,
  now = Date.now(),
  currentlyArmed?: boolean,
): UptimeSummary {
  const fromTs = now - windowMs;
  const inWindow = segments.filter(s => s.ts >= fromTs && s.ts <= now);

  // Determine armed status just before the window by scanning all segments
  // with ts < fromTs.
  let armed = false;
  for (const s of segments) {
    if (s.ts >= fromTs) break;
    if (s.event === "on") armed = true;
    else if (s.event === "off" || s.event === "gap") armed = false;
  }

  let onMs = 0;
  let cursor = fromTs;
  for (const s of inWindow) {
    if (s.ts > cursor) {
      const dt = s.ts - cursor;
      if (armed) onMs += dt;
      cursor = s.ts;
    }
    if (s.event === "on") armed = true;
    else if (s.event === "off" || s.event === "gap") armed = false;
  }
  // Close to now
  const endArmed = currentlyArmed !== undefined ? currentlyArmed : armed;
  if (now > cursor) {
    const dt = now - cursor;
    if (endArmed) onMs += dt;
  }
  const cappedOn = Math.min(Math.max(0, onMs), windowMs);
  return {
    onMs: cappedOn,
    offMs: windowMs - cappedOn,
    segments: inWindow,
    windowMs,
    fromTs,
    toTs: now,
  };
}

export interface BotUptimeLog {
  filePath: string;
  /** Boot: close open ON with gap if needed, then process_start. */
  onProcessBoot(ctx: UptimeContext): UptimeSegment[];
  /** Graceful shutdown: off if armed, then process_stop. */
  onProcessStop(ctx: UptimeContext): UptimeSegment[];
  /** Record armed↔disarmed transition (no-op if unchanged). */
  recordTransition(ctx: UptimeContext & { reason?: string }): UptimeSegment | null;
  /** Optional ≤1/hour heartbeat while ON. */
  maybeHeartbeat(ctx: UptimeContext): UptimeSegment | null;
  readAll(): UptimeSegment[];
  summarize(windowMs: number, now?: number): UptimeSummary;
  getSnapshot(ctx: UptimeContext, recentLimit?: number): UptimeSnapshot;
}

export function createBotUptimeLog(filePath = DEFAULT_FILE): BotUptimeLog {
  let lastHeartbeatTs = 0;

  function build(ctx: UptimeContext, event: UptimeEvent): UptimeSegment {
    const row: UptimeSegment = {
      ts: ctx.ts ?? Date.now(),
      event,
      state: ctx.state,
      enabled: ctx.enabled === true,
      paperMode: ctx.paperMode === true,
      pid: ctx.pid ?? process.pid,
    };
    if (ctx.reason) row.reason = ctx.reason;
    return row;
  }

  function write(row: UptimeSegment): UptimeSegment {
    appendLine(filePath, row);
    return row;
  }

  const api: BotUptimeLog = {
    filePath,

    onProcessBoot(ctx) {
      const written: UptimeSegment[] = [];
      const all = readAll(filePath);
      const lastArmed = lastArmedFromSegments(all);
      if (lastArmed === true) {
        written.push(write(build({
          ...ctx,
          enabled: false,
          reason: "crash gap",
        }, "gap")));
      }
      written.push(write(build({
        ...ctx,
        reason: ctx.reason ?? "process start",
      }, "process_start")));
      return written;
    },

    onProcessStop(ctx) {
      const written: UptimeSegment[] = [];
      const all = readAll(filePath);
      const lastArmed = lastArmedFromSegments(all);
      const armedNow = isBotArmed(ctx.enabled, ctx.state);
      if (lastArmed === true || armedNow) {
        written.push(write(build({
          ...ctx,
          enabled: false,
          reason: ctx.reason ?? "process stop",
        }, "off")));
      }
      written.push(write(build({
        ...ctx,
        enabled: false,
        reason: ctx.reason ?? "process stop",
      }, "process_stop")));
      return written;
    },

    recordTransition(ctx) {
      const armed = isBotArmed(ctx.enabled, ctx.state);
      const all = readAll(filePath);
      const lastArmed = lastArmedFromSegments(all);
      if (lastArmed === armed) return null;
      const event: UptimeEvent = armed ? "on" : "off";
      const reason = ctx.reason ?? (armed ? "armed" : "disarmed");
      return write(build({ ...ctx, reason }, event));
    },

    maybeHeartbeat(ctx) {
      if (!isBotArmed(ctx.enabled, ctx.state)) return null;
      const now = ctx.ts ?? Date.now();
      if (now - lastHeartbeatTs < HEARTBEAT_MIN_INTERVAL_MS) return null;
      // Also respect last heartbeat on disk so restarts don't double-fire.
      const all = readAll(filePath);
      for (let i = all.length - 1; i >= 0; i--) {
        if (all[i]!.event === "heartbeat") {
          if (now - all[i]!.ts < HEARTBEAT_MIN_INTERVAL_MS) return null;
          break;
        }
      }
      lastHeartbeatTs = now;
      return write(build({ ...ctx, reason: ctx.reason ?? "heartbeat", ts: now }, "heartbeat"));
    },

    readAll() {
      return readAll(filePath);
    },

    summarize(windowMs, now = Date.now()) {
      const all = readAll(filePath);
      const armed = lastArmedFromSegments(all) === true;
      return summarizeUptime(all, windowMs, now, armed);
    },

    getSnapshot(ctx, recentLimit = RECENT_LIMIT) {
      const all = readAll(filePath);
      const liveOn = isBotArmed(ctx.enabled, ctx.state);
      const sinceTs = lastArmedTransitionTs(all);
      const lastReason = (() => {
        for (let i = all.length - 1; i >= 0; i--) {
          const e = all[i]!;
          if (e.event === "on" || e.event === "off" || e.event === "gap") {
            return e.reason ?? null;
          }
        }
        return null;
      })();
      return {
        current: {
          on: liveOn,
          state: ctx.state,
          enabled: ctx.enabled === true,
          paperMode: ctx.paperMode === true,
          sinceTs,
          reason: lastReason,
        },
        recent: all.slice(-recentLimit),
        last24h: summarizeUptime(all, 24 * 60 * 60 * 1000, Date.now(), liveOn),
        last7d: summarizeUptime(all, 7 * 24 * 60 * 60 * 1000, Date.now(), liveOn),
      };
    },
  };

  return api;
}

/** Process-wide singleton (data/bot-uptime.jsonl under api-server cwd). */
export const botUptimeLog = createBotUptimeLog();
