import test from "node:test";
import assert from "node:assert/strict";
import { applyAriaPathRules, isAriaDangerVeto, type AriaAssessment, type TradePath } from "./trade-path.js";
import { computeNextHighRiskStreak, computeNextDangerStreak } from "./expert-agent.js";
import { expertAgent, type AgentAssessment } from "./expert-agent.js";
import { tradingBot } from "./trading-bot.js";

// Importing the bot restores its singleton; don't allow its timer to run in this
// pure policy test.
tradingBot.stop();

const PATHS: TradePath[] = ["HIGH_PROB", "GRAY", "MULTIPLIER"];

// ── DANGER hard veto ─────────────────────────────────────────────────────────

test("ARIA DANGER hard-vetoes every path, even when riskLevel disagrees (LOW)", () => {
  for (const path of PATHS) {
    const aria: AriaAssessment = { confAdj: 8, riskLevel: "LOW", signal: "DANGER" };
    const decision = applyAriaPathRules({ path, baseConfidence: 70, aria });
    assert.equal(decision.allowed, false, `${path} should be blocked on DANGER`);
    assert.equal(decision.sizeMult, 0);
  }
});

test("ARIA DANGER veto reason is surfaced for operator visibility", () => {
  const aria: AriaAssessment = { confAdj: 0, riskLevel: "MEDIUM", signal: "DANGER", reasoning: "waterfall drop" };
  const decision = applyAriaPathRules({ path: "HIGH_PROB", baseConfidence: 60, aria });
  assert.equal(decision.allowed, false);
  assert.match(decision.reason, /DANGER/);
  assert.match(decision.reason, /waterfall drop/);
});

// ── Sustained HIGH-risk hard block on HIGH_PROB ──────────────────────────────

test("a single HIGH-risk tick only shrinks HIGH_PROB size, never blocks it", () => {
  const aria: AriaAssessment = { confAdj: -5, riskLevel: "HIGH", signal: "WAIT", sustainedHighRisk: false };
  const decision = applyAriaPathRules({ path: "HIGH_PROB", baseConfidence: 70, aria });
  assert.equal(decision.allowed, true, "one-off HIGH read must not block the safest path");
  assert.equal(decision.sizeMult, 0.60);
});

test("sustained (2+) HIGH-risk reads hard-block HIGH_PROB", () => {
  const aria: AriaAssessment = { confAdj: -5, riskLevel: "HIGH", signal: "WAIT", sustainedHighRisk: true };
  const decision = applyAriaPathRules({ path: "HIGH_PROB", baseConfidence: 70, aria });
  assert.equal(decision.allowed, false);
  assert.equal(decision.sizeMult, 0);
  assert.match(decision.reason, /sustained HIGH risk/i);
});

test("sustainedHighRisk flag has no effect on GRAY/MULTIPLIER — they already hard-block on HIGH", () => {
  for (const path of ["GRAY", "MULTIPLIER"] as TradePath[]) {
    const withoutStreak = applyAriaPathRules({
      path, baseConfidence: 70,
      aria: { confAdj: -8, riskLevel: "HIGH", signal: "WAIT", sustainedHighRisk: false },
    });
    const withStreak = applyAriaPathRules({
      path, baseConfidence: 70,
      aria: { confAdj: -8, riskLevel: "HIGH", signal: "WAIT", sustainedHighRisk: true },
    });
    assert.equal(withoutStreak.allowed, false, `${path} already blocks on a single HIGH read`);
    assert.equal(withStreak.allowed, false);
  }
});

// ── sizeMultiplier can never exceed 1.0 (never increase a position) ─────────

test("ARIA path rules never produce a sizeMult above 1.0 for any path/risk/signal combination", () => {
  const risks: AriaAssessment["riskLevel"][] = ["LOW", "MEDIUM", "HIGH"];
  const signals: NonNullable<AriaAssessment["signal"]>[] = ["YES", "NO", "WAIT", "DANGER"];
  for (const path of PATHS) {
    for (const riskLevel of risks) {
      for (const signal of signals) {
        for (const sustainedHighRisk of [false, true]) {
          const decision = applyAriaPathRules({
            path, baseConfidence: 65,
            aria: { confAdj: 10, riskLevel, signal, sustainedHighRisk },
          });
          assert.ok(decision.sizeMult <= 1.0, `${path}/${riskLevel}/${signal} sizeMult ${decision.sizeMult} > 1.0`);
        }
      }
    }
  }
});

// ── isAriaDangerVeto: OTM-safe DANGER hard veto ──────────────────────────────
// OTM setups (OTM_ASYMMETRY / DEEP_OTM_SNIPER) have their own dedicated
// gate/sizing path and skip applyAriaPathRules() entirely. Regression test for
// the gap where a fresh DANGER read could still let an OTM order through:
// trading-bot.ts must check isAriaDangerVeto() unconditionally, before the
// OTM/non-OTM branch, so no strategy family can bypass it.

test("isAriaDangerVeto is true only for a DANGER signal, false for null/other signals", () => {
  assert.equal(isAriaDangerVeto({ signal: "DANGER" }), true);
  assert.equal(isAriaDangerVeto({ signal: "YES" }), false);
  assert.equal(isAriaDangerVeto({ signal: "NO" }), false);
  assert.equal(isAriaDangerVeto({ signal: "WAIT" }), false);
  assert.equal(isAriaDangerVeto(null), false);
  assert.equal(isAriaDangerVeto(undefined), false);
  assert.equal(isAriaDangerVeto({}), false);
});

test("regression: an OTM setup must be blocked by DANGER even though it never calls applyAriaPathRules", () => {
  // Simulates trading-bot.ts's actual order-gating flow for an OTM strategy:
  // OTM setups skip applyAriaPathRules() (they have their own gate/sizing),
  // so isAriaDangerVeto() must be the ONLY gate standing between a fresh
  // DANGER read and placeOrder() — assert it still blocks the order.
  const isOTMSetup = true;
  const dangerAssmt: AriaAssessment = { confAdj: 0, riskLevel: "HIGH", signal: "DANGER", reasoning: "waterfall drop" };

  let placedOrder = false;
  function evaluateOtmOrderRoute() {
    if (isAriaDangerVeto(dangerAssmt)) return; // must block before any OTM-specific branch
    if (isOTMSetup) {
      placedOrder = true; // OTM's own dedicated gate would normally run here
    }
  }
  evaluateOtmOrderRoute();
  assert.equal(placedOrder, false, "OTM order must never be placed while ARIA is DANGER");
});

// ── ExpertAgent freshness + sustained-risk tracking ──────────────────────────

test("getFreshAssessment returns null when absent or stale, the assessment when fresh", () => {
  const old = expertAgent.lastAssessment;
  try {
    expertAgent.lastAssessment = null;
    assert.equal(expertAgent.getFreshAssessment(), null);

    const fresh: AgentAssessment = {
      ts: Date.now(), signal: "YES", confidence: 80, reasoning: "ok",
      observations: [], riskLevel: "LOW", confAdj: 5,
    };
    expertAgent.lastAssessment = fresh;
    assert.equal(expertAgent.getFreshAssessment(), fresh);

    expertAgent.lastAssessment = { ...fresh, ts: Date.now() - 301_000 };
    assert.equal(expertAgent.getFreshAssessment(), null, "assessment older than the stale window must fall back to null");
  } finally {
    expertAgent.lastAssessment = old;
  }
});

test("computeNextHighRiskStreak: a stale-gap HIGH read starts a new streak at 1, not a continuation", () => {
  const staleWindowMs = 300_000;
  const now = Date.now();

  // Two consecutive fresh HIGH reads build the streak normally.
  let streak = computeNextHighRiskStreak({
    riskLevel: "HIGH", currentStreak: 0,
    priorAssessment: null, staleWindowMs, now: now - 200_000,
  });
  assert.equal(streak, 1);
  streak = computeNextHighRiskStreak({
    riskLevel: "HIGH", currentStreak: streak,
    priorAssessment: { ts: now - 200_000 }, staleWindowMs, now: now - 150_000,
  });
  assert.equal(streak, 2, "two genuinely consecutive fresh HIGH reads should reach 2");

  // Regression: a long outage (prior read now stale) means the NEXT HIGH read
  // must restart the streak at 1, not continue on to 3 — it is not the third
  // of a consecutive run, it is the first fresh read after a gap.
  const afterLongOutage = now; // far beyond staleWindowMs past the last (150_000-ago) read
  streak = computeNextHighRiskStreak({
    riskLevel: "HIGH", currentStreak: streak,
    priorAssessment: { ts: now - 150_000 - staleWindowMs - 1_000 }, // prior read itself already stale
    staleWindowMs, now: afterLongOutage,
  });
  assert.equal(streak, 1, "a HIGH read arriving after a stale gap must restart the streak, not inherit the old count");

  // A single non-HIGH read always resets to 0 regardless of freshness.
  streak = computeNextHighRiskStreak({
    riskLevel: "MEDIUM", currentStreak: 5,
    priorAssessment: { ts: now }, staleWindowMs, now,
  });
  assert.equal(streak, 0);

  // No prior assessment at all (first-ever read) — a HIGH read starts fresh at 1.
  streak = computeNextHighRiskStreak({
    riskLevel: "HIGH", currentStreak: 0,
    priorAssessment: null, staleWindowMs, now,
  });
  assert.equal(streak, 1);
});

test("isSustainedHighRisk requires both a fresh assessment AND 2+ consecutive HIGH reads", () => {
  const old = expertAgent.lastAssessment;
  const oldStreak = (expertAgent as unknown as { consecutiveHighRisk: number }).consecutiveHighRisk;
  try {
    const fresh: AgentAssessment = {
      ts: Date.now(), signal: "WAIT", confidence: 50, reasoning: "elevated",
      observations: [], riskLevel: "HIGH", confAdj: -8,
    };
    expertAgent.lastAssessment = fresh;

    (expertAgent as unknown as { consecutiveHighRisk: number }).consecutiveHighRisk = 1;
    assert.equal(expertAgent.isSustainedHighRisk(), false, "one HIGH read is not sustained");

    (expertAgent as unknown as { consecutiveHighRisk: number }).consecutiveHighRisk = 2;
    assert.equal(expertAgent.isSustainedHighRisk(), true, "2+ consecutive HIGH reads is sustained");

    // A stale assessment must never let an old streak keep blocking trades.
    expertAgent.lastAssessment = { ...fresh, ts: Date.now() - 301_000 };
    assert.equal(expertAgent.isSustainedHighRisk(), false, "stale assessment must not honor an old HIGH-risk streak");
  } finally {
    expertAgent.lastAssessment = old;
    (expertAgent as unknown as { consecutiveHighRisk: number }).consecutiveHighRisk = oldStreak;
  }
});

// ── Task #427: sustained-DANGER in-trade exit authority ──────────────────────

test("computeNextDangerStreak: a stale-gap DANGER read starts a new streak at 1, not a continuation", () => {
  const staleWindowMs = 300_000;
  const now = Date.now();

  let streak = computeNextDangerStreak({
    signal: "DANGER", currentStreak: 0,
    priorAssessment: null, staleWindowMs, now: now - 200_000,
  });
  assert.equal(streak, 1);
  streak = computeNextDangerStreak({
    signal: "DANGER", currentStreak: streak,
    priorAssessment: { ts: now - 200_000 }, staleWindowMs, now: now - 150_000,
  });
  assert.equal(streak, 2, "two genuinely consecutive fresh DANGER reads should reach 2");

  // A long outage (prior read now stale) means the NEXT DANGER read restarts
  // the streak at 1 rather than inheriting the pre-outage count.
  streak = computeNextDangerStreak({
    signal: "DANGER", currentStreak: streak,
    priorAssessment: { ts: now - 150_000 - staleWindowMs - 1_000 },
    staleWindowMs, now,
  });
  assert.equal(streak, 1, "a DANGER read arriving after a stale gap must restart the streak, not inherit the old count");

  // Any non-DANGER read always resets to 0 regardless of freshness.
  streak = computeNextDangerStreak({
    signal: "WAIT", currentStreak: 5,
    priorAssessment: { ts: now }, staleWindowMs, now,
  });
  assert.equal(streak, 0);

  // First-ever read — a DANGER read starts fresh at 1.
  streak = computeNextDangerStreak({
    signal: "DANGER", currentStreak: 0,
    priorAssessment: null, staleWindowMs, now,
  });
  assert.equal(streak, 1);
});

test("isSustainedDanger requires both a fresh assessment AND 2+ consecutive DANGER reads", () => {
  const old = expertAgent.lastAssessment;
  const oldStreak = (expertAgent as unknown as { consecutiveDanger: number }).consecutiveDanger;
  try {
    const fresh: AgentAssessment = {
      ts: Date.now(), signal: "DANGER", confidence: 90, reasoning: "waterfall drop",
      observations: [], riskLevel: "HIGH", confAdj: -15,
    };
    expertAgent.lastAssessment = fresh;

    (expertAgent as unknown as { consecutiveDanger: number }).consecutiveDanger = 1;
    assert.equal(expertAgent.isSustainedDanger(), false, "one DANGER read must not authorize closing a live position");

    (expertAgent as unknown as { consecutiveDanger: number }).consecutiveDanger = 2;
    assert.equal(expertAgent.isSustainedDanger(), true, "2+ consecutive DANGER reads is sustained");

    // A stale assessment must never let an old streak keep force-closing trades.
    expertAgent.lastAssessment = { ...fresh, ts: Date.now() - 301_000 };
    assert.equal(expertAgent.isSustainedDanger(), false, "stale assessment must not honor an old DANGER streak");
  } finally {
    expertAgent.lastAssessment = old;
    (expertAgent as unknown as { consecutiveDanger: number }).consecutiveDanger = oldStreak;
  }
});

test("DANGER signal still applies the existing -15 confidence adjustment via getConfidenceAdjustment", () => {
  const old = expertAgent.lastAssessment;
  try {
    expertAgent.lastAssessment = {
      ts: Date.now(), signal: "DANGER", confidence: 90, reasoning: "waterfall",
      observations: [], riskLevel: "HIGH", confAdj: -15,
    };
    assert.equal(expertAgent.getConfidenceAdjustment("yes"), -15);
    assert.equal(expertAgent.getConfidenceAdjustment("no"), -15);
  } finally {
    expertAgent.lastAssessment = old;
  }
});

test("getConfidenceAdjustment never boosts a YES align (tighten-only)", () => {
  const old = expertAgent.lastAssessment;
  try {
    expertAgent.lastAssessment = {
      ts: Date.now(), signal: "YES", confidence: 80, reasoning: "ok",
      observations: [], riskLevel: "LOW", confAdj: 12,
    };
    assert.equal(expertAgent.getConfidenceAdjustment("yes"), 0, "aligned +12 must clamp to 0");
    assert.ok(expertAgent.getConfidenceAdjustment("no") <= 0, "misaligned side must not boost");
    expertAgent.lastAssessment = {
      ts: Date.now(), signal: "YES", confidence: 80, reasoning: "ok",
      observations: [], riskLevel: "LOW", confAdj: -8,
    };
    assert.equal(expertAgent.getConfidenceAdjustment("yes"), -8);
  } finally {
    expertAgent.lastAssessment = old;
  }
});

test("applyAriaPathRules finalConfAdj never positive even when Aria proposes +10", () => {
  const decision = applyAriaPathRules({
    path: "HIGH_PROB", baseConfidence: 50,
    aria: { confAdj: 10, riskLevel: "LOW", signal: "YES" },
  });
  assert.equal(decision.allowed, true);
  assert.ok(decision.finalConfAdj <= 0, `finalConfAdj ${decision.finalConfAdj} must not boost`);
  assert.ok(decision.sizeMult <= 1.0);
});
