/**
 * backtest-engine.wilsonrank.test.ts
 *
 * Unit tests for Task #400: computeWilsonRankScore — the sample-size-adjusted
 * ranking score that prevents thin-sample combos from topping the grid-search
 * optimizer's rankings purely on luck.
 *
 * The formula uses a Wilson-LB shrinkage factor (wlb / rawWR): for any given
 * raw win rate, this factor is ≈1 when n is large (LB ≈ rawWR) and shrinks
 * toward 0 for very small n or extreme win rates with wide CIs. The final
 * score is the geometric mean of shrinkage × composite, so both evidence
 * quality AND statistical confidence must be high to rank well.
 *
 * Run with:  tsx --test src/lib/backtest-engine.wilsonrank.test.ts
 * (or via `pnpm run test` which globs all *.test.ts)
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { computeWilsonRankScore } from "./backtest-engine.js";

// ── Core invariant: Wilson penalty shrinks thin-sample combos ────────────────

test("thin high-WR combo does not rank above well-evidenced moderate-WR combo", () => {
  // Motivating example from task description: n=78 / WR=97.4% — the exact
  // case that originally ranked near the top purely on luck.
  // n=500 / WR=70% represents a well-evidenced combo with the same composite.
  // Wilson shrinkage at 78 trades is 91.1% / 97.4% ≈ 0.935.
  // Wilson shrinkage at 500 trades is 65.8% / 70.0% ≈ 0.940.
  // The well-evidenced combo's shrinkage matches/exceeds the thin one, so it
  // scores at least as high.
  const thin  = computeWilsonRankScore(78,  Math.round(78  * 0.974), 0.85);
  const thick = computeWilsonRankScore(500, Math.round(500 * 0.70),  0.85);

  // thick must NOT be outranked by thin
  assert.ok(
    thick >= thin,
    `Expected well-evidenced combo (${thick.toFixed(4)}) ≥ thin/high-WR (${thin.toFixed(4)})`,
  );
});

test("score monotonically increases as n grows (constant WR and composite)", () => {
  const wr  = 0.70;
  const scores = [50, 100, 200, 500, 1000].map(n =>
    computeWilsonRankScore(n, Math.round(n * wr), 0.6),
  );
  for (let i = 1; i < scores.length; i++) {
    assert.ok(
      scores[i] >= scores[i - 1],
      `Score should not decrease as n grows: scores[${i}]=${scores[i].toFixed(4)} < scores[${i-1}]=${scores[i-1].toFixed(4)}`,
    );
  }
});

test("score is 0 when tradesEntered is 0", () => {
  const score = computeWilsonRankScore(0, 0, 0.9);
  assert.strictEqual(score, 0);
});

test("score is 0 when wins is 0", () => {
  const score = computeWilsonRankScore(100, 0, 0.9);
  assert.strictEqual(score, 0);
});

test("score is 0 when composite is 0 (geometric mean collapses to 0)", () => {
  const score = computeWilsonRankScore(500, 350, 0);
  assert.strictEqual(score, 0);
});

test("score is in [0, 1] for all valid inputs", () => {
  const cases: [number, number, number][] = [
    [30,   27,  0.5],
    [78,   76,  0.85],
    [200,  140, 0.6],
    [1000, 700, 0.9],
    [100,  50,  0.1],   // WR=50% just barely passes the entry filter
    [0,    0,   0.9],
  ];
  for (const [n, w, c] of cases) {
    const score = computeWilsonRankScore(n, w, c);
    assert.ok(score >= 0 && score <= 1, `score=${score} out of [0,1] for n=${n} w=${w} c=${c}`);
  }
});

// ── Composite still matters (both dimensions required) ────────────────────────

test("higher composite scores higher when sample size and WR are equal", () => {
  const n    = 300;
  const wins = Math.round(n * 0.65);
  const low  = computeWilsonRankScore(n, wins, 0.3);
  const high = computeWilsonRankScore(n, wins, 0.8);
  assert.ok(high > low, `Expected high-composite (${high.toFixed(4)}) > low-composite (${low.toFixed(4)})`);
});

test("higher WR scores higher when n and composite are equal", () => {
  const n   = 300;
  const c   = 0.6;
  const low = computeWilsonRankScore(n, Math.round(n * 0.55), c);
  const hi  = computeWilsonRankScore(n, Math.round(n * 0.75), c);
  assert.ok(hi > low, `Expected high-WR (${hi.toFixed(4)}) > low-WR (${low.toFixed(4)})`);
});

// ── Shrinkage direction: large-n shrinkage > small-n shrinkage (same WR) ─────

test("well-evidenced combo has higher shrinkage factor than thin combo at same raw WR", () => {
  // Shrinkage = wlb / rawWR.  For fixed rawWR, wlb → rawWR as n → ∞, so
  // shrinkage → 1.  For small n, wlb is further below rawWR → lower shrinkage.
  // This test checks that directly (via score at fixed composite).
  const wr = 0.72;
  const small = computeWilsonRankScore(30,   Math.round(30   * wr), 0.7);
  const large = computeWilsonRankScore(1000, Math.round(1000 * wr), 0.7);
  assert.ok(large > small, `Large-n (${large.toFixed(4)}) should beat small-n (${small.toFixed(4)}) at same WR/composite`);
});
