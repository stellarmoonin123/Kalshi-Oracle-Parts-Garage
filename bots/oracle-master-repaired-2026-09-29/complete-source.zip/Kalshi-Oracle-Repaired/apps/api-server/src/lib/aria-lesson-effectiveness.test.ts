/**
 * aria-lesson-effectiveness.test.ts
 *
 * Integration tests for the lesson effectiveness report.
 *
 * Strategy:
 *   - Insert a small set of synthetic aria_lessons + bot_trades rows
 *     with known timestamps (before/after an anchor lesson).
 *   - Run computeAriaLessonEffectiveness() and assert on the output.
 *   - Clean up all test rows after each run.
 *
 * Run with:
 *   pnpm --filter @workspace/api-server run test
 */

import { test, before, after } from "node:test";
import assert from "node:assert/strict";

import { db, ariaLessons, botTrades } from "@workspace/db";
import { inArray, eq } from "drizzle-orm";
import { computeAriaLessonEffectiveness } from "./aria-lesson-effectiveness.js";

// ── Unique tags so we never collide with real production rows ─────────────────
const TAG = `__test_effectiveness_${Date.now()}__`;
const STRAT_A = `TEST_STRAT_EFF_A_${TAG}`;
const STRAT_B = `TEST_STRAT_EFF_B_${TAG}`;

const insertedTradeIds: number[] = [];
const insertedLessonIds: number[] = [];

// Anchor timestamps:
// BEFORE window  → 2020-01-01
// Lesson created → 2020-06-01
// AFTER window   → 2020-12-01
const BEFORE_TS = new Date("2020-01-15T12:00:00Z");
const LESSON_TS = new Date("2020-06-01T00:00:00Z");
const AFTER_TS  = new Date("2020-12-15T12:00:00Z");

before(async () => {
  // Insert lessons directly (bypassing aria-lessons-store so we control
  // createdAt precisely — the store always uses defaultNow()).
  const lessonRows = await db
    .insert(ariaLessons)
    .values([
      // Lesson for STRAT_A (anchor at LESSON_TS)
      {
        strategyId: STRAT_A,
        lesson:     `[${TAG}] Test lesson for strategy A — avoid low-vol regime`,
        timesReinforced: 2,
        createdAt:       LESSON_TS,
        lastReinforcedAt: LESSON_TS,
      },
      // Second lesson for STRAT_A (later — should NOT become the anchor)
      {
        strategyId: STRAT_A,
        lesson:     `[${TAG}] Test lesson for strategy A second lesson`,
        timesReinforced: 1,
        createdAt:       new Date("2020-08-01T00:00:00Z"),
        lastReinforcedAt: new Date("2020-08-01T00:00:00Z"),
      },
      // Lesson for STRAT_B (same anchor date for simplicity)
      {
        strategyId: STRAT_B,
        lesson:     `[${TAG}] Test lesson for strategy B`,
        timesReinforced: 1,
        createdAt:       LESSON_TS,
        lastReinforcedAt: LESSON_TS,
      },
    ])
    .returning({ id: ariaLessons.id });

  insertedLessonIds.push(...lessonRows.map(r => r.id));

  // Insert trades:
  //   STRAT_A before lesson: 2 wins (+100 each), 3 losses (−50 each)   → winRate=40%, avgEV=−10
  //   STRAT_A after lesson:  4 wins (+100 each), 1 loss  (−50 each)    → winRate=80%, avgEV=+70
  //   STRAT_B before lesson: 1 win  (+200),      2 losses (−100 each)  → winRate=33%, avgEV=0
  //   STRAT_B after lesson:  0 trades                                   → empty window
  const makeBase = (strategyId: string, ts: Date) => ({
    ticker: "KXBTC-TEST-EFF",
    side: "yes" as const,
    contracts: 1,
    entryPriceCents: 50,
    signal: "LONG",
    strategyId,
    // Use createdAt directly; settledAt is null so the report will fall back to createdAt.
    createdAt: ts,
  });

  const tradeValues = [
    // STRAT_A BEFORE: 2 wins
    { ...makeBase(STRAT_A, BEFORE_TS), outcome: "win",  pnlCents:  100, orderId: `${TAG}-a-b-w1` },
    { ...makeBase(STRAT_A, BEFORE_TS), outcome: "win",  pnlCents:  100, orderId: `${TAG}-a-b-w2` },
    // STRAT_A BEFORE: 3 losses
    { ...makeBase(STRAT_A, BEFORE_TS), outcome: "loss", pnlCents:  -50, orderId: `${TAG}-a-b-l1` },
    { ...makeBase(STRAT_A, BEFORE_TS), outcome: "loss", pnlCents:  -50, orderId: `${TAG}-a-b-l2` },
    { ...makeBase(STRAT_A, BEFORE_TS), outcome: "loss", pnlCents:  -50, orderId: `${TAG}-a-b-l3` },
    // STRAT_A AFTER: 4 wins
    { ...makeBase(STRAT_A, AFTER_TS), outcome: "win",  pnlCents:  100, orderId: `${TAG}-a-a-w1` },
    { ...makeBase(STRAT_A, AFTER_TS), outcome: "win",  pnlCents:  100, orderId: `${TAG}-a-a-w2` },
    { ...makeBase(STRAT_A, AFTER_TS), outcome: "win",  pnlCents:  100, orderId: `${TAG}-a-a-w3` },
    { ...makeBase(STRAT_A, AFTER_TS), outcome: "win",  pnlCents:  100, orderId: `${TAG}-a-a-w4` },
    // STRAT_A AFTER: 1 loss
    { ...makeBase(STRAT_A, AFTER_TS), outcome: "loss", pnlCents:  -50, orderId: `${TAG}-a-a-l1` },
    // STRAT_B BEFORE: 1 win, 2 losses
    { ...makeBase(STRAT_B, BEFORE_TS), outcome: "win",  pnlCents:  200, orderId: `${TAG}-b-b-w1` },
    { ...makeBase(STRAT_B, BEFORE_TS), outcome: "loss", pnlCents: -100, orderId: `${TAG}-b-b-l1` },
    { ...makeBase(STRAT_B, BEFORE_TS), outcome: "loss", pnlCents: -100, orderId: `${TAG}-b-b-l2` },
    // STRAT_B AFTER: no trades intentionally (empty window test)
  ];

  const tradeRows = await db
    .insert(botTrades)
    .values(tradeValues)
    .returning({ id: botTrades.id });

  insertedTradeIds.push(...tradeRows.map(r => r.id));
});

after(async () => {
  if (insertedTradeIds.length > 0) {
    await db.delete(botTrades).where(inArray(botTrades.id, insertedTradeIds));
  }
  if (insertedLessonIds.length > 0) {
    await db.delete(ariaLessons).where(inArray(ariaLessons.id, insertedLessonIds));
  }
});

// ─────────────────────────────────────────────────────────────────────────────

test("computeAriaLessonEffectiveness: report shape is valid", async () => {
  const report = await computeAriaLessonEffectiveness();
  assert.ok(typeof report.generatedAt === "string", "generatedAt must be an ISO string");
  assert.ok(typeof report.totalLessons === "number", "totalLessons must be a number");
  assert.ok(typeof report.bucketsAnalyzed === "number", "bucketsAnalyzed must be a number");
  assert.ok(typeof report.caveat === "string" && report.caveat.length > 0, "caveat must be non-empty");
  assert.ok(Array.isArray(report.records), "records must be an array");
});

test("computeAriaLessonEffectiveness: STRAT_A bucket shows correct before/after window stats", async () => {
  const report = await computeAriaLessonEffectiveness();
  const rec = report.records.find(r => r.strategyId === STRAT_A);
  assert.ok(rec, `Record for ${STRAT_A} must be present`);

  // Before: 5 trades (2W 3L), winRate=0.4, avgEV=(200−150)/5=10
  assert.equal(rec.before.n, 5, "STRAT_A before: 5 trades");
  assert.equal(rec.before.wins, 2, "STRAT_A before: 2 wins");
  assert.equal(rec.before.losses, 3, "STRAT_A before: 3 losses");
  assert.ok(Math.abs((rec.before.winRate ?? 0) - 0.4) < 0.001, "STRAT_A before: winRate=0.4");
  // avgEV = (2*100 + 3*(-50)) / 5 = (200 - 150) / 5 = 10
  assert.ok(Math.abs((rec.before.avgEvCents ?? 0) - 10) < 0.01, "STRAT_A before: avgEV=10");

  // After: 5 trades (4W 1L), winRate=0.8, avgEV=(400−50)/5=70
  assert.equal(rec.after.n, 5, "STRAT_A after: 5 trades");
  assert.equal(rec.after.wins, 4, "STRAT_A after: 4 wins");
  assert.equal(rec.after.losses, 1, "STRAT_A after: 1 loss");
  assert.ok(Math.abs((rec.after.winRate ?? 0) - 0.8) < 0.001, "STRAT_A after: winRate=0.8");
  // avgEV = (4*100 + 1*(-50)) / 5 = (400 - 50) / 5 = 70
  assert.ok(Math.abs((rec.after.avgEvCents ?? 0) - 70) < 0.01, "STRAT_A after: avgEV=70");

  // Deltas: +0.4 win-rate, +60 EV
  assert.ok(rec.winRateDelta !== null && Math.abs(rec.winRateDelta - 0.4) < 0.001, "STRAT_A winRateDelta=+0.4");
  assert.ok(rec.evDelta !== null && Math.abs(rec.evDelta - 60) < 0.01, "STRAT_A evDelta=+60");
});

test("computeAriaLessonEffectiveness: STRAT_A anchor lesson is the earliest one", async () => {
  const report = await computeAriaLessonEffectiveness();
  const rec = report.records.find(r => r.strategyId === STRAT_A);
  assert.ok(rec, `Record for ${STRAT_A} must be present`);
  // There are 2 lessons for STRAT_A — the anchor must be the earlier one (LESSON_TS)
  assert.equal(rec.anchorLessonCreatedAt.getTime(), LESSON_TS.getTime(), "Anchor must be the earliest lesson");
  assert.equal(rec.lessonIds.length, 2, "STRAT_A must list both lesson IDs");
});

test("computeAriaLessonEffectiveness: STRAT_B after window is empty, verdict explains it", async () => {
  const report = await computeAriaLessonEffectiveness();
  const rec = report.records.find(r => r.strategyId === STRAT_B);
  assert.ok(rec, `Record for ${STRAT_B} must be present`);

  assert.equal(rec.after.n, 0, "STRAT_B after: no trades");
  assert.equal(rec.after.winRate, null, "STRAT_B after: winRate must be null");
  assert.equal(rec.winRateDelta, null, "STRAT_B winRateDelta must be null");
  assert.ok(rec.verdict.includes("No settled trades AFTER"), `Verdict must mention empty after window, got: ${rec.verdict}`);
});

test("computeAriaLessonEffectiveness: low-confidence flag is set when n < MIN_SAMPLE", async () => {
  const report = await computeAriaLessonEffectiveness();
  const recA = report.records.find(r => r.strategyId === STRAT_A);
  assert.ok(recA, `Record for ${STRAT_A} must be present`);
  // Both windows have 5 trades each, which is below MIN_SAMPLE=10
  assert.equal(recA.before.lowConfidence, true, "Before window with n=5 must be low-confidence");
  assert.equal(recA.after.lowConfidence, true,  "After window with n=5 must be low-confidence");
});

test("computeAriaLessonEffectiveness: report includes a non-empty caveat", async () => {
  const report = await computeAriaLessonEffectiveness();
  assert.ok(report.caveat.toLowerCase().includes("correlation"), "Caveat must mention correlation");
  assert.ok(report.caveat.toLowerCase().includes("causation"), "Caveat must mention causation");
});
