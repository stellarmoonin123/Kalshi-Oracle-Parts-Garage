/**
 * settle-persist-retry.ts: durable retry for settlement DB writes that failed.
 *
 * Bug (Sep 25 settlement audit): recordSettlement() books paper cash, the
 * paper ledger file and the paper-trades.jsonl close, then writes bot_trades.
 * If that single DB write failed (the DB was marked degraded 35x in 24h), the
 * paper openTrade was still cleared, so the bot_trades row stayed
 * outcome="pending" until a restart ran the stale-trade sweep. That sweep
 * re-scores from Kalshi / binary truth, not the real early-exit close, which is
 * exactly how #72 got booked as ORPHAN_OPEN_CLEARED_VOID.
 *
 * Fix: queue the exact settle patch (file-backed under the desk data dir, so
 * it survives a restart) and retry it until it lands. The retry only updates a
 * row that is still outcome="pending"; it never rewrites an already-closed row.
 * Accounting/persistence only: no trading decision reads this.
 */
import fs from "node:fs";
import path from "node:path";
import { deskDataPath } from "./desk-data-dir.js";

export const SETTLE_RETRY_FILENAME = "settle-persist-retry.json";
export const SETTLE_RETRY_INTERVAL_MS = 30_000;

export type SettlePatch = Record<string, unknown>;

export interface SettleRetryItem {
  dbId: number;
  ticker: string;
  patch: SettlePatch;
  queuedAt: number;
  attempts: number;
  lastError: string | null;
}

/** Returns true when the row was updated, false when it is no longer pending (already settled). */
export type SettleUpdater = (dbId: number, patch: SettlePatch) => Promise<boolean>;

export function settleRetryPath(): string {
  return process.env.SETTLE_RETRY_PATH || deskDataPath(SETTLE_RETRY_FILENAME);
}

function serializePatch(patch: SettlePatch): SettlePatch {
  const out: SettlePatch = {};
  for (const [k, v] of Object.entries(patch)) {
    out[k] = v instanceof Date ? { __date: v.toISOString() } : v;
  }
  return out;
}

export function hydratePatch(patch: SettlePatch): SettlePatch {
  const out: SettlePatch = {};
  for (const [k, v] of Object.entries(patch)) {
    if (v && typeof v === "object" && typeof (v as { __date?: unknown }).__date === "string") {
      out[k] = new Date((v as { __date: string }).__date);
    } else {
      out[k] = v;
    }
  }
  return out;
}

export function loadSettleRetryQueue(filePath = settleRetryPath()): SettleRetryItem[] {
  try {
    if (!fs.existsSync(filePath)) return [];
    const raw = JSON.parse(fs.readFileSync(filePath, "utf8"));
    if (!Array.isArray(raw)) return [];
    return raw.filter((r): r is SettleRetryItem =>
      r && typeof r === "object" && typeof r.dbId === "number" && r.patch && typeof r.patch === "object");
  } catch {
    return [];
  }
}

function saveQueue(items: SettleRetryItem[], filePath = settleRetryPath()): void {
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const tmp = `${filePath}.tmp.${process.pid}`;
    fs.writeFileSync(tmp, JSON.stringify(items, null, 2), "utf8");
    fs.renameSync(tmp, filePath);
  } catch (err) {
    console.error("[settle-retry] failed to persist retry queue:", err);
  }
}

/** Queue (or replace) the settle patch for a trade whose settlement write failed. */
export function enqueueSettlePersistRetry(
  item: { dbId: number; ticker: string; patch: SettlePatch; error?: string | null },
  filePath = settleRetryPath(),
): SettleRetryItem[] {
  const q = loadSettleRetryQueue(filePath).filter((r) => r.dbId !== item.dbId);
  q.push({
    dbId: item.dbId,
    ticker: item.ticker,
    patch: serializePatch(item.patch),
    queuedAt: Date.now(),
    attempts: 0,
    lastError: item.error ?? null,
  });
  saveQueue(q, filePath);
  return q;
}

export interface SettleRetryResult {
  landed: number[];
  alreadySettled: number[];
  stillPending: number[];
}

/** Try every queued write once. Items that land (or are already settled) leave the queue. */
export async function drainSettlePersistRetry(
  update: SettleUpdater,
  filePath = settleRetryPath(),
): Promise<SettleRetryResult> {
  const q = loadSettleRetryQueue(filePath);
  const result: SettleRetryResult = { landed: [], alreadySettled: [], stillPending: [] };
  if (q.length === 0) return result;
  const keep: SettleRetryItem[] = [];
  for (const item of q) {
    try {
      const updated = await update(item.dbId, hydratePatch(item.patch));
      if (updated) result.landed.push(item.dbId);
      else result.alreadySettled.push(item.dbId);
    } catch (err) {
      keep.push({ ...item, attempts: item.attempts + 1, lastError: (err as Error).message ?? String(err) });
      result.stillPending.push(item.dbId);
    }
  }
  saveQueue(keep, filePath);
  return result;
}

export function settleRetryQueueDepth(filePath = settleRetryPath()): number {
  return loadSettleRetryQueue(filePath).length;
}

export function isSettleRetryQueued(dbId: number, filePath = settleRetryPath()): boolean {
  return loadSettleRetryQueue(filePath).some((r) => r.dbId === dbId);
}
