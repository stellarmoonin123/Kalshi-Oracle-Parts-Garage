/** account-position.ts — external-close / opening-fill / paper-slippage helpers (PhD peel) */
import { db, botTrades } from "@workspace/db";
import { desc, eq, and, sql } from "drizzle-orm";
import {
  KALSHI_EXPECTED_SLIPPAGE_CENTS,
  KALSHI_API_DOMAIN,
  KALSHI_PATH_PORTFOLIO_FILLS,
} from "./constants.js";
import { kalshiAuthHeadersAsync } from "./kalshi-auth.js";
import { fetchWithRetry } from "./fetch-retry.js";
import type { AccountPositionSnapshot } from "./trading-bot-types.js";

async function kalshiAuthHeaders(method: string, apiPath: string): Promise<Record<string, string>> {
  return kalshiAuthHeadersAsync(method, apiPath);
}

/**
 * Pure helper — reads Kalshi's signed net position off for our tracked side.
 * Kalshi's portfolio/positions `position` field: positive = net long YES,
 * negative = net long NO. Exported for unit testing.
 */
export function kalshiSameSidePosition(position: number, side: "yes" | "no"): number {
  return side === "yes" ? Math.max(0, position) : Math.max(0, -position);
}

/**
 * Pure helper — true when Kalshi shows fewer contracts on our tracked side
 * than the bot believes it holds. Exported for unit testing.
 */
/**
 * Pure win/loss + P&L inference from a before/after account-balance snapshot,
 * used when a manual/external close can't be priced from a matching Kalshi
 * fill. Returns null when either snapshot is unavailable (balance poll
 * unreachable, or the trade predates the balanceBeforeCents field) — the
 * caller must fall back to "unresolved" rather than guessing.
 */
export function computeBalanceInferredOutcome(opts: {
  balanceBeforeCents: number | null;
  balanceAfterCents:  number | null;
}): { outcome: "win" | "loss"; pnlCents: number } | null {
  if (opts.balanceBeforeCents == null || opts.balanceAfterCents == null) return null;
  const pnlCents = opts.balanceAfterCents - opts.balanceBeforeCents;
  return { outcome: pnlCents >= 0 ? "win" : "loss", pnlCents };
}

/**
 * True when a balance-inferred P&L is physically possible for the position
 * that was actually closed. A Kalshi binary contract can never trade above
 * 100c or below 0c, so no exit — however it happened — can produce a P&L
 * outside [-(closedContracts*entryPriceCents), closedContracts*(100-entryPriceCents)]
 * (plus a small fee/rounding buffer) for a position bought at entryPriceCents.
 * A balance delta outside this bound means the delta isn't (purely) this
 * trade closing — e.g. a second concurrent balance-moving event on the
 * account, or a stale/wrong snapshot — and must not be trusted as this
 * trade's P&L. Exported for unit testing.
 */
export function isBalanceInferredPnlPlausible(
  pnlCents: number,
  closedContracts: number,
  entryPriceCents: number,
  feeBufferCents = 50,
): boolean {
  if (closedContracts <= 0) return false;
  const maxWin  = closedContracts * (100 - entryPriceCents) + feeBufferCents;
  const maxLoss = -(closedContracts * entryPriceCents) - feeBufferCents;
  return pnlCents <= maxWin && pnlCents >= maxLoss;
}

/**
 * Display-only balanceAfterCents for a settlement, bounded against what the
 * trade's own contracts/entry price can physically produce (reuses
 * isBalanceInferredPnlPlausible's ground-truth bound) so a single bad/stale
 * balance read never gets permanently written as "the account looked like
 * this right after this trade" — see recoverStalePendingTrades' 2026-08-18
 * fix note for the confirmed incident this guards against. Exported for unit
 * testing.
 */
export function computeGuardedBalanceAfterCents(opts: {
  currentBalanceCents: number | null;
  balanceBeforeCents: number | null;
  closedContracts: number;
  entryPriceCents: number;
}): number | null {
  if (opts.currentBalanceCents == null) return null;
  const rounded = Math.round(opts.currentBalanceCents);
  if (opts.balanceBeforeCents == null) return rounded; // no prior snapshot to sanity-check against
  const impliedDelta = rounded - opts.balanceBeforeCents;
  return isBalanceInferredPnlPlausible(impliedDelta, opts.closedContracts, opts.entryPriceCents) ? rounded : null;
}

export function isPositionMismatch(kalshiSameSideContracts: number, trackedContracts: number): boolean {
  return kalshiSameSideContracts < trackedContracts;
}


/**
 * Compare the complete unsettled-position response with the bot's one-position
 * in-memory model. This deliberately distinguishes:
 *   - `unknown`: Kalshi could not be read (never treat that as flat);
 *   - `tracked-mismatch`: the tracked ticker is smaller/larger than Kalshi;
 *   - `unmanaged`: another ticker or the opposite side is live;
 *   - `flat`/`managed`: the account agrees with the bot.
 *
 * The account-wide poll is not allowed to repair an overage by silently
 * changing `openTrade.contracts`: an excess can be the duplicate-contract
 * failure this guard is designed to expose.
 */
export { trackedKalshiTradeForAudit } from "./fill-origin.js";

export function classifyAccountPositionState(
  positions: AccountPositionSnapshot[] | null,
  trade: { ticker: string; side: "yes" | "no"; contracts: number } | null,
): {
  status: "unknown" | "flat" | "managed" | "tracked-mismatch" | "unmanaged";
  unmanaged: AccountPositionSnapshot[];
  trackedContracts: number | null;
  expectedContracts: number | null;
} {
  if (positions === null) {
    return { status: "unknown", unmanaged: [], trackedContracts: null, expectedContracts: trade?.contracts ?? null };
  }

  if (!trade) {
    return positions.length === 0
      ? { status: "flat", unmanaged: [], trackedContracts: 0, expectedContracts: 0 }
      : { status: "unmanaged", unmanaged: positions, trackedContracts: null, expectedContracts: 0 };
  }

  const sameTicker = positions.filter(p => p.ticker === trade.ticker);
  const sameSide = sameTicker.reduce(
    (total, p) => total + kalshiSameSidePosition(p.position, trade.side),
    0,
  );
  const unmanaged = positions.filter(p =>
    p.ticker !== trade.ticker ||
    (p.ticker === trade.ticker && kalshiSameSidePosition(p.position, trade.side) === 0),
  );

  if (unmanaged.length > 0) {
    return { status: "unmanaged", unmanaged, trackedContracts: sameSide, expectedContracts: trade.contracts };
  }
  if (sameSide !== trade.contracts) {
    return {
      status: "tracked-mismatch",
      unmanaged: [],
      trackedContracts: sameSide,
      expectedContracts: trade.contracts,
    };
  }
  return {
    status: "managed",
    unmanaged: [],
    trackedContracts: sameSide,
    expectedContracts: trade.contracts,
  };
}

/**
 * Pure helper: how many contracts did an external close actually close, given
 * what the bot tracked and what Kalshi now confirms is still open? A partial
 * external close (kalshiRemainingContracts > 0) must NOT be priced as if the
 * full tracked size closed — that silently overstates the realized win/loss
 * by whatever fraction is still open on Kalshi. Clamped at 0 defensively;
 * callers should already guarantee kalshiRemainingContracts < trackedContracts
 * (see isPositionMismatch) before reaching here.
 */
export function computeExternalCloseClosedContracts(trackedContracts: number, kalshiRemainingContracts: number): number {
  return Math.max(0, trackedContracts - kalshiRemainingContracts);
}

/** Shape of a row from Kalshi's GET /portfolio/fills, restricted to the fields
 *  computeExternalCloseExitPriceCents needs. Field names verified 2026-08-09
 *  against a real response (see that function's doc comment) and Kalshi's
 *  published OpenAPI spec (docs.kalshi.com/api-reference/portfolio/get-fills).
 */
export interface KalshiFill {
  ticker?: string;
  outcome_side?: string;   // 'yes' | 'no' — the canonical field (see below); NOT the deprecated `side`
  count_fp?: string;       // fixed-point contract count string, e.g. "10.00" (can be fractional per-fill)
  yes_price_dollars?: string; // fixed-point dollar string, e.g. "0.9000"
  no_price_dollars?: string;  // fixed-point dollar string, e.g. "0.1000"
  fee_cost?: string;       // fixed-point dollar string, e.g. "0.174400" — Kalshi's own real fee for this fill
}

/**
 * Pure helper — contracts-weighted average price (whole cents, expressed in
 * `side`'s own terms) of the fill(s) on `ticker` that closed a `side`
 * position. Returns null when no matching closing fill is found or a value
 * fails to parse — callers must treat null as "price unresolved", never as
 * "0¢". Exported for unit testing.
 *
 * Kalshi's fills endpoint uses `outcome_side` for the directional exposure a
 * fill produced ("buy-yes and sell-no produce 'yes'; buy-no and sell-yes
 * produce 'no'" — per Kalshi's docs). A fill that CLOSES a `side` position is
 * therefore always on the OPPOSITE `outcome_side` — confirmed 2026-08-09
 * against a real bot-closed live trade, where a YES position's closing sell
 * fill reported `outcome_side: "no"`. The legacy `side`/`action` fields
 * (deprecated by Kalshi, scheduled for removal) were tried first and found
 * to be misleading for exactly this case, so they are deliberately not used
 * here. Contract counts arrive as the fixed-point string `count_fp` (can be
 * fractional per individual fill, e.g. "0.79" + "0.21" for one 1-contract
 * close split across two price levels) and prices as fixed-point dollar
 * strings `yes_price_dollars`/`no_price_dollars`, not integer cents.
 */
export function computeExternalCloseExitPriceCents(
  fills: KalshiFill[],
  ticker: string,
  side: "yes" | "no",
): number | null {
  const closingOutcomeSide = side === "yes" ? "no" : "yes";
  const closingFills = fills.filter(f => f.ticker === ticker && f.outcome_side === closingOutcomeSide);
  if (closingFills.length === 0) return null;

  let totalContracts = 0;
  let totalCents      = 0;
  for (const f of closingFills) {
    const priceDollars = side === "yes" ? f.yes_price_dollars : f.no_price_dollars;
    const priceNum = typeof priceDollars === "string" ? parseFloat(priceDollars) : NaN;
    const countNum = typeof f.count_fp === "string" ? parseFloat(f.count_fp) : NaN;
    if (!Number.isFinite(priceNum) || !Number.isFinite(countNum) || countNum <= 0) continue;
    totalContracts += countNum;
    totalCents     += Math.round(priceNum * 100) * countNum;
  }
  if (totalContracts === 0) return null;
  return Math.round(totalCents / totalContracts);
}

/**
 * Pure helper — true if `fills` contains at least one fill that OPENED a
 * `side` position on `ticker` (an entry fill). An opening fill's
 * `outcome_side` matches the position's own side directly — the opposite of
 * computeExternalCloseExitPriceCents's closing-fill check (see that
 * function's doc comment for the outcome_side convention). Exported for
 * unit testing.
 */
export function hasKalshiOpeningFill(
  fills: KalshiFill[],
  ticker: string,
  side: string,
): boolean {
  return fills.some(f => f.ticker === ticker && f.outcome_side === side);
}

/**
 * Pure helper — contracts-weighted average OPENING fill price/count/fee for
 * a `side` position on `ticker`, straight from Kalshi's own fills record.
 * This is the real, exchange-confirmed entry price — it can (and often
 * does) differ from `bot_trades.entryPriceCents`, which records the
 * quoted/placed price at decision time, not the price the order actually
 * filled at (confirmed 2026-08-16: trade #2831 was recorded at a 59¢ quote
 * but Kalshi's fill shows it actually filled at 53¢, a real ~$0.72
 * difference in settlement P&L). `feeCents` is Kalshi's own reported
 * `fee_cost` for the fill(s), not a locally re-derived estimate — use it
 * directly rather than recomputing via kalshiFeeCents() when this data is
 * available. Returns null when no matching opening fill is found or all
 * values fail to parse. Exported for unit testing.
 */
export function computeOpeningFillStats(
  fills: KalshiFill[],
  ticker: string,
  side: string,
): { avgPriceCents: number; contracts: number; costCents: number; feeCents: number } | null {
  const openingFills = fills.filter(f => f.ticker === ticker && f.outcome_side === side);
  if (openingFills.length === 0) return null;
  let totalContracts = 0;
  let totalCents = 0;
  let totalFeeCents = 0;
  for (const f of openingFills) {
    const priceDollars = side === "yes" ? f.yes_price_dollars : f.no_price_dollars;
    const priceNum = typeof priceDollars === "string" ? parseFloat(priceDollars) : NaN;
    const countNum = typeof f.count_fp === "string" ? parseFloat(f.count_fp) : NaN;
    if (!Number.isFinite(priceNum) || !Number.isFinite(countNum) || countNum <= 0) continue;
    totalContracts += countNum;
    totalCents += Math.round(priceNum * 100) * countNum;
    const feeNum = typeof f.fee_cost === "string" ? parseFloat(f.fee_cost) : NaN;
    if (Number.isFinite(feeNum)) totalFeeCents += feeNum * 100;
  }
  if (totalContracts <= 0) return null;
  return {
    avgPriceCents: Math.round(totalCents / totalContracts),
    contracts: Math.round(totalContracts),
    costCents: Math.round(totalCents),
    feeCents: Math.round(totalFeeCents),
  };
}

// Task #441 — Realistic Paper Fills: cache of recent live-slippage averages
// per strategy so paper fills stop simulating a fantasy 0¢-slippage entry.
// Keyed by strategyId (or "__global__" for the cross-strategy fallback).
// TTL matches the DB read cost/benefit tradeoff of other backtest-derived
// caches in this file — live slippage distribution shifts slowly (minutes to
// hours), not tick to tick.
const paperSlippageCache = new Map<string, { avgCents: number; ts: number }>();
const PAPER_SLIPPAGE_CACHE_TTL_MS = 5 * 60_000;
const PAPER_SLIPPAGE_SAMPLE_SIZE  = 30;

/**
 * Estimates the slippage (in cents, always >= 0 — a taker never gets a
 * BETTER-than-quoted fill on this exchange) a paper fill should simulate,
 * sourced from recent REAL live fills for the same strategy so paper P&L
 * stops being a slippage-free upper bound on what live can achieve. Falls
 * back to the cross-strategy live average, then to the static
 * KALSHI_EXPECTED_SLIPPAGE_CENTS estimate when no live data exists yet
 * (e.g. a brand-new strategy, or a bot that has only ever run in paper mode).
 * Never throws — a DB error just falls through to the static estimate.
 */
export async function estimatePaperSlippageCents(strategyId: string | null): Promise<number> {
  const cacheKey = strategyId ?? "__unknown__";
  const cached = paperSlippageCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < PAPER_SLIPPAGE_CACHE_TTL_MS) return cached.avgCents;

  try {
    const whereClause = strategyId
      ? and(eq(botTrades.isPaper, false), eq(botTrades.strategyId, strategyId), sql`${botTrades.slippageCents} is not null`)
      : and(eq(botTrades.isPaper, false), sql`${botTrades.slippageCents} is not null`);
    const rows = await db
      .select({ slippageCents: botTrades.slippageCents })
      .from(botTrades)
      .where(whereClause)
      .orderBy(desc(botTrades.createdAt))
      .limit(PAPER_SLIPPAGE_SAMPLE_SIZE);

    if (rows.length === 0) {
      // No per-strategy sample — try the cross-strategy average once, cached
      // under its own key, before falling all the way back to the static
      // estimate. Avoids one new strategy's cold start looking artificially
      // slippage-free while every other strategy already has live data.
      if (strategyId !== null) {
        const globalCents = await estimatePaperSlippageCents(null);
        paperSlippageCache.set(cacheKey, { avgCents: globalCents, ts: Date.now() });
        return globalCents;
      }
      paperSlippageCache.set(cacheKey, { avgCents: KALSHI_EXPECTED_SLIPPAGE_CENTS, ts: Date.now() });
      return KALSHI_EXPECTED_SLIPPAGE_CENTS;
    }

    const avgRaw = rows.reduce((s, r) => s + (r.slippageCents ?? 0), 0) / rows.length;
    // Live slippageCents is signed (fillCents - expectedFillCents); a paper
    // fill has no "better than quoted" concept to simulate against (there's
    // no real order book to occasionally get lucky on), so floor it at 0 —
    // consistently modeling the adverse-only cost, never a windfall.
    const avgCents = Math.max(0, avgRaw);
    paperSlippageCache.set(cacheKey, { avgCents, ts: Date.now() });
    return avgCents;
  } catch (err) {
    console.debug(`[paper-slippage] estimate failed, using static fallback: ${(err as Error).message}`);
    return KALSHI_EXPECTED_SLIPPAGE_CENTS;
  }
}

/**
 * Ops-integrity fix (Phase 4, 2026-08-16): recoverStalePendingTrades() used
 * to score every orphaned pending/unresolved LIVE trade against settlement
 * price alone, with no check that the order had ever actually been filled
 * by Kalshi. A live order that crashed out before its own 12s
 * unfilled-timeout could even fire would be stuck 'pending' forever and, on
 * the next restart, get scored as a real win/loss — fabricating P&L for a
 * position that never opened. This queries Kalshi's real fills for the
 * ticker from just before the trade was placed, mirroring
 * fetchExternalCloseExitPrice's proven pattern (same endpoint/auth/retry).
 * Also returns the real opening-fill stats (price/contracts/fee) from the
 * same response, in one request, so the caller can score P&L off Kalshi's
 * actual fill instead of the placed-order's quoted entryPriceCents.
 * Returns null — not a result object — when the check itself could not be
 * completed (no auth / network / non-2xx). Callers must treat null as
 * "couldn't verify", never as "confirmed unfilled" or "confirmed filled".
 */
export async function fetchKalshiOpeningFillData(
  ticker: string,
  side: string,
  sinceMs: number,
): Promise<{ hasFill: boolean; stats: ReturnType<typeof computeOpeningFillStats> } | null> {
  try {
    const apiPath = KALSHI_PATH_PORTFOLIO_FILLS;
    const headers = await kalshiAuthHeaders("GET", apiPath);
    if (!headers["KALSHI-ACCESS-KEY"]) return null;
    // 5-minute back-pad: our createdAt is when the DB row was written, which
    // can lag Kalshi's own fill timestamp by a few seconds under load — pad
    // generously rather than risk missing a genuine fill just outside the window.
    const minTs = Math.floor(sinceMs / 1000) - 300;
    const url = `${KALSHI_API_DOMAIN}${apiPath}?ticker=${encodeURIComponent(ticker)}&min_ts=${minTs}&limit=100`;
    const r = await fetchWithRetry(url, { headers: { ...headers, Accept: "application/json" } }, { attempts: 2, timeoutMs: 4_000 });
    if (!r.ok) return null;
    const data = (await r.json()) as { fills?: KalshiFill[] };
    const fills = Array.isArray(data.fills) ? data.fills : null;
    if (!fills) return null;
    return { hasFill: hasKalshiOpeningFill(fills, ticker, side), stats: computeOpeningFillStats(fills, ticker, side) };
  } catch {
    return null;
  }
}
