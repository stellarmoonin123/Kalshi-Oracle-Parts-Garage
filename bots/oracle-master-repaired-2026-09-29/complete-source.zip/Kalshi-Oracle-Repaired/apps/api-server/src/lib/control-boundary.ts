/** Control-plane contracts. No IO, source writes, exchange calls or policy mutation. */
export function parseBearerToken(header: string | undefined): string | undefined {
  return header?.match(/^Bearer[ \t]+([^\s]+)[ \t]*$/i)?.[1];
}

export const CHAT_READ_ONLY_REASON =
  "Desk chat is read/propose-only. Source changes and tests require a separate credential-free checkout and reviewed release.";

export function denyChatMutation() {
  return { ok: false as const, refused: true as const, reason: CHAT_READ_ONLY_REASON };
}

/** Interim barrier: these adapters do not share the bot's durable account executor.
 * An operator's live mode is necessary, but cannot manufacture that missing owner.
 * There is deliberately no environment toggle that bypasses this barrier.
 */
export function manualExchangeWriteRefusal(paperMode: unknown) {
  return paperMode !== false
    ? { status: 409, code: "PAPER_EXCHANGE_WRITE_BLOCKED", error: "Paper mode cannot submit or cancel real exchange orders." }
    : { status: 503, code: "SHARED_EXECUTOR_REQUIRED", error: "Manual exchange writes are unavailable until they use the shared account execution and reconciliation service." };
}

export function createManualExchangeWriteBoundary(getPaperMode: () => unknown) {
  return (req: { method: string }, res: { status(code: number): { json(body: unknown): unknown } }, next: () => unknown) => {
    if (req.method !== "POST" && req.method !== "DELETE") return next();
    let paperMode: unknown;
    try { paperMode = getPaperMode(); } catch { paperMode = undefined; }
    const refusal = manualExchangeWriteRefusal(paperMode);
    return res.status(refusal.status).json({ success: false, code: refusal.code, error: refusal.error });
  };
}

export function publicLiveness() { return { status: "ok" as const }; }
