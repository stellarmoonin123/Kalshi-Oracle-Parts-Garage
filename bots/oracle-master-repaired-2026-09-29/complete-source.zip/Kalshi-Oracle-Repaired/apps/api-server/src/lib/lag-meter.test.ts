/** QUARANTINE(P2): lag-meter research; frozen shadow-only */
/**
 * lag-meter.test.ts
 *
 * Observable only. LAG_METER is not ENABLE_STRATEGY. LIVE_APPLY is not flipped.
 * TradingBot.evaluate may import lagAgreesWithSide (skip/veto). It must not
 * construct LagMeter or call estimateLag — BasisTracker owns the meter.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  estimateLag,
  lagAgreesWithSide,
  LagMeter,
  getLagMeterStatus,
  lagMeterStatusFromReading,
  forwardFill1sBuckets,
  alignTo1sBuckets,
  LAG_METER_MAX_LAG_SEC,
  LAG_METER_COLD_SEED_MAX_SEC,
  LAG_METER_MIN_CORR,
  LAG_METER_MIN_N,
  LAG_METER_HALF_LIFE_MS,
  LAG_METER_STALE_MS,
  type LagTick,
  type LagSeries,
} from "./lag-meter.js";

const LIB = path.dirname(fileURLToPath(import.meta.url));

const T0 = 1_724_000_000_000;

function lcg(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}

function randomWalk(n: number, start: number, seed: number, t0 = T0): LagTick[] {
  const rng = lcg(seed);
  const ticks: LagTick[] = [];
  let px = start;
  for (let i = 0; i < n; i++) {
    px += (rng() - 0.5) * 24;
    ticks.push({ tMs: t0 + i * 1000, px });
  }
  return ticks;
}

/** Kalshi implied = Coinbase delayed `lagSec` seconds (same timestamps). */
function delayedFollower(leader: LagTick[], lagSec: number): LagTick[] {
  const out: LagTick[] = [];
  for (let i = lagSec; i < leader.length; i++) {
    out.push({ tMs: leader[i].tMs, px: leader[i - lagSec].px });
  }
  return out;
}

function seriesAtLag(lagSec: number, n = 180, seed = 42): { series: LagSeries; nowMs: number } {
  const coinbase = randomWalk(n, 80_000, seed);
  const kalshiImplied = delayedFollower(coinbase, lagSec);
  const nowMs = coinbase[coinbase.length - 1].tMs;
  return { series: { coinbase, kalshiImplied }, nowMs };
}

test.skip("locks: maxLag 30s, minCorr 0.25, minN 60, half-life 60s, stale 45s", () => {
  assert.equal(LAG_METER_MAX_LAG_SEC, 30);
  assert.equal(LAG_METER_MIN_CORR, 0.25);
  assert.equal(LAG_METER_MIN_N, 60);
  assert.equal(LAG_METER_HALF_LIFE_MS, 60_000);
  assert.equal(LAG_METER_STALE_MS, 45_000);
});

test.skip("synthetic: Kalshi = Coinbase delayed 8s → lagSeconds ~8, not stale", () => {
  const { series, nowMs } = seriesAtLag(8);
  const r = estimateLag(series, { nowMs });
  assert.equal(r.stale, false, r.reason);
  assert.equal(r.reason, "ok");
  assert.ok(r.lagSeconds != null, "lagSeconds should be set");
  assert.ok(Math.abs(r.lagSeconds! - 8) <= 1, `expected ~8s, got ${r.lagSeconds}`);
  assert.ok(r.rawTau != null && Math.abs(r.rawTau - 8) <= 1, `rawTau ~8, got ${r.rawTau}`);
  assert.ok(r.corr != null && r.corr >= LAG_METER_MIN_CORR, `corr ${r.corr}`);
  assert.ok(r.sampleN >= LAG_METER_MIN_N, `sampleN ${r.sampleN}`);
  assert.ok(r.lagDollars != null, "lagDollars should be set");
  const cb = series.coinbase;
  const last = cb[cb.length - 1].px;
  const then = cb[cb.length - 1 - 8].px;
  assert.ok(Math.abs(r.lagDollars! - (last - then)) < 1e-6, `lagDollars ${r.lagDollars} vs ${last - then}`);
});

test.skip("uncorrelated noise → stale", () => {
  const coinbase = randomWalk(220, 80_000, 1);
  const kalshiImplied = randomWalk(220, 80_000, 99);
  const nowMs = coinbase[coinbase.length - 1].tMs;
  const r = estimateLag({ coinbase, kalshiImplied }, { nowMs });
  assert.equal(r.stale, true, `expected stale, got lagSeconds=${r.lagSeconds} corr=${r.corr} reason=${r.reason}`);
  assert.equal(r.lagSeconds, null);
  assert.ok(r.reason === "corr_junk" || r.reason === "n_low" || r.reason === "zero_variance", r.reason);
});

test.skip("empty series → stale", () => {
  const nowMs = T0 + 120_000;
  const empty = estimateLag({ coinbase: [], kalshiImplied: [] }, { nowMs });
  assert.equal(empty.stale, true);
  assert.equal(empty.reason, "empty_series");
  assert.equal(empty.lagSeconds, null);

  const oneSide = estimateLag(
    { coinbase: randomWalk(120, 80_000, 7), kalshiImplied: [] },
    { nowMs: T0 + 119_000 },
  );
  assert.equal(oneSide.stale, true);
  assert.equal(oneSide.reason, "empty_series");
});

test.skip("short series → stale", () => {
  const { series, nowMs } = seriesAtLag(8, 20);
  const r = estimateLag(series, { nowMs });
  assert.equal(r.stale, true);
  assert.equal(r.lagSeconds, null);
  assert.ok(r.reason === "short_series" || r.reason === "n_low" || r.reason === "empty_series", r.reason);
});

test.skip("timestamps >45s old → stale", () => {
  const { series, nowMs } = seriesAtLag(8, 180);
  const r = estimateLag(series, { nowMs: nowMs + 46_000 });
  assert.equal(r.stale, true);
  assert.equal(r.reason, "timestamps_stale");
  assert.equal(r.lagSeconds, null);
});

test.skip("series gaps → stale", () => {
  const coinbase = randomWalk(180, 80_000, 3);
  // Drop 4 consecutive seconds every 10 — holes >2s must remain series_gaps
  // (forward-fill only covers ≤2s misses).
  const kalshiImplied = delayedFollower(coinbase, 8).filter((t) => {
    const rel = Math.floor(t.tMs / 1000) % 10;
    return rel < 6; // keep 6, drop 4 → maxGap 5
  });
  const nowMs = coinbase[coinbase.length - 1].tMs;
  const r = estimateLag({ coinbase, kalshiImplied }, { nowMs });
  assert.equal(r.stale, true);
  assert.ok(r.reason === "series_gaps" || r.reason === "n_low" || r.reason === "short_series", r.reason);
  assert.equal(r.lagSeconds, null);
});

test.skip("brief ≤2s holes forward-fill — live Coinbase+BRTI not stuck series_gaps", () => {
  const { series, nowMs } = seriesAtLag(8, 180);
  // Drop every 3rd kalshi second in a short mid band (1s holes after fill)
  const k = series.kalshiImplied.filter((t) => {
    const s = Math.floor(t.tMs / 1000);
    const rel = s - Math.floor(series.kalshiImplied[0].tMs / 1000);
    return !(rel > 40 && rel < 100 && rel % 3 === 0);
  });
  const r = estimateLag({ coinbase: series.coinbase, kalshiImplied: k }, { nowMs });
  assert.equal(r.stale, false, `expected warm after ≤2s fill, got ${r.reason}`);
  assert.ok(r.lagSeconds != null);
});

test.skip("forwardFill1sBuckets fills 2s hole, leaves 3s+ gap", () => {
  const buckets = new Map<number, number>([[100, 1], [103, 2]]); // missing 101,102 → fill; gap from 100→103 is 3
  const filled = forwardFill1sBuckets(buckets, 100, 103, 2);
  assert.equal(filled.get(101), 1);
  assert.equal(filled.get(102), 1);
  assert.equal(filled.get(103), 2);
  const wide = new Map<number, number>([[100, 1], [104, 2]]); // 3 missing → no fill across 3s+
  const filled2 = forwardFill1sBuckets(wide, 100, 104, 2);
  assert.equal(filled2.has(101), true);
  assert.equal(filled2.has(102), true);
  assert.equal(filled2.has(103), false); // 100→104 exceeds maxFillSec from last real
});

test.skip("lagAgreesWithSide signs", () => {
  assert.equal(lagAgreesWithSide("yes", 12), true);
  assert.equal(lagAgreesWithSide("yes", -12), false);
  assert.equal(lagAgreesWithSide("no", -12), true);
  assert.equal(lagAgreesWithSide("no", 12), false);
  assert.equal(lagAgreesWithSide("yes", 0), false);
  assert.equal(lagAgreesWithSide("no", 0), false);
  assert.equal(lagAgreesWithSide("yes", null), false);
  assert.equal(lagAgreesWithSide("no", null), false);
  assert.equal(lagAgreesWithSide("yes", Number.NaN), false);
});

test.skip("EWMA does not jump from 5 to 25 on one window", () => {
  const meter = new LagMeter();
  const five = seriesAtLag(5, 200, 11);
  const first = meter.update(five.series, { nowMs: five.nowMs });
  assert.equal(first.stale, false, first.reason);
  assert.ok(first.lagSeconds != null);
  assert.ok(Math.abs(first.lagSeconds! - 5) <= 1, `seed ~5, got ${first.lagSeconds}`);

  const twentyFive = seriesAtLag(25, 200, 11);
  const second = meter.update(twentyFive.series, { nowMs: five.nowMs + 1000, dtMs: 1000 });
  assert.equal(second.stale, false, second.reason);
  assert.ok(second.lagSeconds != null);
  // Half-life 60s, dt=1s → alpha ≈ 0.0115, so 5 → 25 moves ~0.23s, not 20s.
  assert.ok(
    Math.abs(second.lagSeconds! - first.lagSeconds!) < 2,
    `EWMA jumped: ${first.lagSeconds} → ${second.lagSeconds}`,
  );
  assert.ok(second.lagSeconds! < 12, `looks like a jump toward 25: ${second.lagSeconds}`);
  assert.ok(Math.abs(second.lagSeconds! - 25) > 10, `landed near 25: ${second.lagSeconds}`);
});

test.skip("residualDollars is (exchange - brtiProxy) - rollingBasis; lagDollars is Coinbase Δ$ over tau", () => {
  const { series, nowMs } = seriesAtLag(8);
  const r = estimateLag(series, {
    nowMs,
    exchange: 80_040,
    brtiProxy: 80_010,
    rollingBasis: 20,
  });
  assert.equal(r.residualDollars, 10);
  const cb = series.coinbase;
  const last = cb[cb.length - 1].px;
  const then = cb[cb.length - 1 - 8].px;
  assert.ok(r.lagDollars != null);
  assert.ok(Math.abs(r.lagDollars! - (last - then)) < 1e-6);
  assert.notEqual(r.lagDollars, r.residualDollars, "THE Stellar $ is Coinbase over tau, not residual");
  const missing = estimateLag(series, { nowMs });
  assert.equal(missing.residualDollars, null);
});

test.skip("adaptive: synthetic tau 5s then 12s → EWMA tracks (not a fixed 5–15s)", () => {
  const meter = new LagMeter();
  const five = seriesAtLag(5, 200, 11);
  const first = meter.update(five.series, { nowMs: five.nowMs, dtMs: 0 });
  assert.equal(first.stale, false, first.reason);
  assert.ok(first.lagSeconds != null);
  assert.ok(Math.abs(first.lagSeconds! - 5) <= 1, `seed ~5, got ${first.lagSeconds}`);
  assert.ok(first.rawTau != null && Math.abs(first.rawTau - 5) <= 1, `rawTau ~5, got ${first.rawTau}`);

  const twelve = seriesAtLag(12, 200, 11);
  let last = first;
  for (let i = 1; i <= 180; i++) {
    last = meter.update(twelve.series, { nowMs: twelve.nowMs, dtMs: 1000 });
  }
  assert.equal(last.stale, false, last.reason);
  assert.ok(last.lagSeconds != null);
  assert.ok(last.rawTau != null && Math.abs(last.rawTau - 12) <= 1, `rawTau ~12, got ${last.rawTau}`);
  // Half-life 60s × 3 = 180s → remaining 0.125 of the 5→12 gap. ~11.1s.
  assert.ok(
    last.lagSeconds! > 9 && last.lagSeconds! < 12.5,
    `EWMA should track toward 12, got ${last.lagSeconds}`,
  );
  assert.ok(
    Math.abs(last.lagSeconds! - 12) < Math.abs(last.lagSeconds! - 5),
    `should be closer to 12 than 5: ${last.lagSeconds}`,
  );
  assert.ok(last.lagSeconds! > first.lagSeconds!, `did not drift: ${first.lagSeconds} → ${last.lagSeconds}`);
});

test.skip("fail-closed: after a live reading, junk/thin/stale → null not a leftover constant", () => {
  const meter = new LagMeter();
  const good = seriesAtLag(8, 180, 42);
  const live = meter.update(good.series, { nowMs: good.nowMs });
  assert.equal(live.stale, false, live.reason);
  assert.ok(live.lagSeconds != null);

  const coinbase = randomWalk(220, 80_000, 1);
  const kalshiImplied = randomWalk(220, 80_000, 99);
  const nowMs = coinbase[coinbase.length - 1].tMs;
  const junk = meter.update({ coinbase, kalshiImplied }, { nowMs, dtMs: 1000 });
  assert.equal(junk.stale, true, junk.reason);
  assert.equal(junk.lagSeconds, null, "must not keep the previous 8s as a fake constant");
  assert.equal(junk.lagDollars, null);
  assert.equal(junk.rawTau, null);

  const thin = meter.update(seriesAtLag(8, 20).series, { nowMs: T0 + 19_000, dtMs: 1000 });
  assert.equal(thin.stale, true);
  assert.equal(thin.lagSeconds, null);
});

test.skip("NOT a StrategyId / ENABLE_STRATEGY; evaluate may import lagAgreesWithSide only", () => {
  const bot = fs.readFileSync(path.join(LIB, "trading-bot.ts"), "utf8");
  assert.match(bot, /from ["']\.\/lag-meter\.js["']/, "evaluate imports lagAgreesWithSide from lag-meter");
  assert.match(bot, /lagAgreesWithSide/);
  assert.equal(bot.includes("new LagMeter"), false, "BasisTracker owns LagMeter, not evaluate");
  assert.equal(bot.includes("estimateLag"), false);
  const optInStart = bot.indexOf("const STRATEGY_OPT_IN_GATES");
  const lockedStart = bot.indexOf("const LOCKED_DISABLED_STRATEGIES");
  assert.ok(optInStart >= 0 && lockedStart >= 0);
  const optIn = bot.slice(optInStart, lockedStart);
  assert.equal(/LAG_METER/.test(optIn), false);
  const locked = bot.slice(lockedStart, lockedStart + 1600);
  assert.equal(/LAG_METER/.test(locked), false);
  const lib = fs.readFileSync(path.join(LIB, "strategy-library.ts"), "utf8");
  assert.equal(lib.includes("lag-meter"), false);
  assert.equal(lib.includes("estimateLag"), false);
});

test.skip("lagDollars uses nearest prior Coinbase bucket; missing px is not 0", () => {
  const { series, nowMs } = seriesAtLag(8, 180, 42);
  const cb = series.coinbase;
  const lastSec = Math.floor(cb[cb.length - 1].tMs / 1000);
  const lookbackSec = lastSec - 8;
  // Drop the exact lookback second (simulate a 1s Coinbase hole).
  const gapped = series.coinbase.filter((t) => Math.floor(t.tMs / 1000) !== lookbackSec);
  const r = estimateLag({ coinbase: gapped, kalshiImplied: series.kalshiImplied }, { nowMs });
  assert.equal(r.stale, false, r.reason);
  assert.ok(r.lagDollars != null, "nearest-prior px must fill a 1s hole");
  assert.ok(r.lagDollars !== 0 || Math.abs(cb[cb.length - 1].px - cb[cb.length - 2].px) < 1e-9);

  const zeroed = series.coinbase.map((t, i) => i === 0 ? { ...t, px: 0 } : t);
  const z = estimateLag({ coinbase: zeroed, kalshiImplied: series.kalshiImplied }, { nowMs });
  // px<=0 is dropped at align; must not become lagDollars from 0.
  if (z.lagDollars != null) {
    const impliedThen = z.lagDollars; // if present, now-then with positive px only
    assert.ok(Number.isFinite(impliedThen));
  }
});

test.skip("getLagMeterStatus exposes tau/corr/stale/leadDollars and never invents 5–15s", () => {
  const empty = lagMeterStatusFromReading(null);
  assert.equal(empty.tau, null);
  assert.equal(empty.stale, true);
  assert.equal(empty.leadDollars, null);
  assert.notEqual(empty.tau, 5);
  assert.notEqual(empty.tau, 15);

  const meter = new LagMeter();
  const none = getLagMeterStatus(meter);
  assert.equal(none.tau, null);
  assert.equal(none.stale, true);

  const { series, nowMs } = seriesAtLag(8);
  meter.update(series, { nowMs });
  const ok = meter.getStatus();
  if (!ok.stale) {
    assert.ok(ok.tau != null);
    assert.ok(Math.abs(ok.tau! - 8) <= 2);
  } else {
    assert.equal(ok.tau, null, "stale status must not keep a fake tau");
  }

  const stale = lagMeterStatusFromReading({
    lagSeconds: 12,
    lagDollars: 40,
    residualDollars: null,
    corr: 0.1,
    stale: true,
    sampleN: 10,
    reason: "corr_junk",
    rawTau: 12,
    leaderName: "coinbase",
    leadSeconds: null,
    leadDollars: 40,
    proofHitRate: null,
    proven: false,
  });
  assert.equal(stale.tau, null);
  assert.equal(stale.lagSeconds, null);
  assert.equal(stale.leadDollars, 40);
  assert.equal(stale.stale, true);
});

test.skip("never reports proven=true when stale (lagProven∧lagStale honesty)", () => {
  const status = lagMeterStatusFromReading({
    lagSeconds: 8,
    lagDollars: 25,
    residualDollars: null,
    corr: 0.5,
    stale: true,
    sampleN: 20,
    reason: "n_low",
    rawTau: 8,
    leaderName: "coinbase",
    leadSeconds: 30,
    leadDollars: 31,
    proofHitRate: 0.7,
    proven: true, // catch-up may have hits while series is thin
  });
  assert.equal(status.stale, true);
  assert.equal(status.proven, false, "stale status must clear proven");
  assert.equal(status.tau, null);
  assert.equal(status.lagSeconds, null);
  // lead$ may remain for diagnostics; proven must not.
  assert.equal(status.leadSeconds, 30);
});

test.skip("cold EWMA seed caps tau ≤ COLD_SEED_MAX (no 30s lag$ flash)", () => {
  assert.equal(LAG_METER_COLD_SEED_MAX_SEC, 8);
  assert.ok(LAG_METER_COLD_SEED_MAX_SEC < LAG_METER_MAX_LAG_SEC);
  const here = path.dirname(fileURLToPath(import.meta.url));
  const src = fs.readFileSync(path.join(here, "lag-meter.ts"), "utf8");
  assert.match(src, /LAG_METER_COLD_SEED_MAX_SEC/);
  assert.match(src, /Math\.min\(rawTau, LAG_METER_COLD_SEED_MAX_SEC\)/);
});
