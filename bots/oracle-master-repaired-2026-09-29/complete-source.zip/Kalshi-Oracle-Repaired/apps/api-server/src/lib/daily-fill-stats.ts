import { db, dailyFillStats } from "@workspace/db";
import { and, eq, sql } from "drizzle-orm";

export interface DailyFillStatsSnapshot {
  placed: number;
  filled: number;
  cancelled: number;
  totalSlippageCents: number;
  slippageSamples: number;
}

export interface DailyFillStatsDelta {
  placed?: number;
  filled?: number;
  cancelled?: number;
  totalSlippageCents?: number;
  slippageSamples?: number;
}

/**
 * Keep older development databases usable until the normal schema sync runs.
 * The DDL matches lib/db/src/schema/daily-fill-stats.ts and is idempotent.
 */
let schemaReady: Promise<void> | null = null;
export function ensureDailyFillStatsSchema(): Promise<void> {
  if (!schemaReady) {
    schemaReady = (async () => {
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS daily_fill_stats (
          id                   serial PRIMARY KEY,
          date                 text NOT NULL,
          paper_mode           boolean NOT NULL DEFAULT false,
          placed               integer NOT NULL DEFAULT 0,
          filled               integer NOT NULL DEFAULT 0,
          cancelled            integer NOT NULL DEFAULT 0,
          total_slippage_cents integer NOT NULL DEFAULT 0,
          slippage_samples    integer NOT NULL DEFAULT 0,
          created_at           timestamp NOT NULL DEFAULT now(),
          updated_at           timestamp NOT NULL DEFAULT now()
        )
      `);
      await db.execute(sql`
        CREATE UNIQUE INDEX IF NOT EXISTS daily_fill_stats_date_mode_uq
        ON daily_fill_stats (date, paper_mode)
      `);
    })().catch((err) => {
      schemaReady = null;
      throw err;
    });
  }
  return schemaReady;
}

const EMPTY_STATS: DailyFillStatsSnapshot = {
  placed: 0,
  filled: 0,
  cancelled: 0,
  totalSlippageCents: 0,
  slippageSamples: 0,
};

export async function loadDailyFillStats(opts: {
  date: string;
  paperMode: boolean;
}): Promise<DailyFillStatsSnapshot> {
  await ensureDailyFillStatsSchema();
  const rows = await db.select({
    placed: dailyFillStats.placed,
    filled: dailyFillStats.filled,
    cancelled: dailyFillStats.cancelled,
    totalSlippageCents: dailyFillStats.totalSlippageCents,
    slippageSamples: dailyFillStats.slippageSamples,
  }).from(dailyFillStats).where(and(
    eq(dailyFillStats.date, opts.date),
    eq(dailyFillStats.paperMode, opts.paperMode),
  )).limit(1);
  return rows[0] ?? { ...EMPTY_STATS };
}

/**
 * Atomically add an execution event to the daily row. Concurrent fill/cancel
 * callbacks cannot overwrite each other's counters because each conflict
 * update increments the values in the database.
 */
export async function incrementDailyFillStats(opts: {
  date: string;
  paperMode: boolean;
  delta: DailyFillStatsDelta;
}): Promise<void> {
  await ensureDailyFillStatsSchema();
  const delta = {
    placed: opts.delta.placed ?? 0,
    filled: opts.delta.filled ?? 0,
    cancelled: opts.delta.cancelled ?? 0,
    totalSlippageCents: opts.delta.totalSlippageCents ?? 0,
    slippageSamples: opts.delta.slippageSamples ?? 0,
  };
  if (Object.values(delta).every(value => value === 0)) return;

  await db.insert(dailyFillStats).values({
    date: opts.date,
    paperMode: opts.paperMode,
    ...delta,
  }).onConflictDoUpdate({
    target: [dailyFillStats.date, dailyFillStats.paperMode],
    set: {
      placed: sql`${dailyFillStats.placed} + excluded.placed`,
      filled: sql`${dailyFillStats.filled} + excluded.filled`,
      cancelled: sql`${dailyFillStats.cancelled} + excluded.cancelled`,
      totalSlippageCents: sql`${dailyFillStats.totalSlippageCents} + excluded.total_slippage_cents`,
      slippageSamples: sql`${dailyFillStats.slippageSamples} + excluded.slippage_samples`,
      updatedAt: new Date(),
    },
  });
}