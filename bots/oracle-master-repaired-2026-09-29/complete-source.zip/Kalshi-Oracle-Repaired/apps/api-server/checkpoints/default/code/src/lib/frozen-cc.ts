/**
 * FROZEN_CC — the one-hypothesis experiment mode.
 *
 * When `config.frozenCcMode` is true the bot runs exactly ONE ruleset and
 * nothing else may change it at runtime:
 *
 *   ENTRY (six hard gates, everything else is a logged shadow flag)
 *     1. fresh quote                  — existing STALE_QUOTE / FEED gates upstream
 *     2. time window                  — 3..13 minutes remaining
 *     3. price band                   — ask 20..55¢ (C-money desk door; Fable structure), excluding 48..52¢ coin-flip
 *     4. side alignment               — CONFLUENCE_CASCADE fired AND alignedTakeGate
 *                                       TAKE on the same side (MTF trend + strike)
 *     5. EV                           — fee-aware netEV >= EV_FLOOR (alignedTakeGate)
 *     6. one position + daily halt    — existing gates upstream
 *
 *   EXIT (C-money / money-machine, ask 20–55)
 *     Real PATH_RIDE owns adaptive exits (PATH_RIDE_TP when green, soft giveback,
 *     thesis rules). holdToSettlement is forced OFF so winners are not trapped.
 *     Catastrophic mark (<= frozenCcCatastrophicCents, default 5¢) is a last-resort
 *     failsafe that requires SUSTAINED ≤threshold (FROZEN_CC_CATASTROPHIC_SUSTAIN_MS),
 *     never a single wick. Optional frozenCcTakeProfitCents still fires immediately.
 *     When moneyMachinePathRide is false (legacy experiment), PATH_RIDE is shadow-only.
 *
 *   MEASUREMENT
 *     data/frozen-cc-ledger.jsonl — one FILL row and one CLOSE row per trade with
 *     every shadow flag, fees, settled side, realised fee-net P&L and the
 *     counterfactual hold-to-settlement P&L. Append-only, never rewritten.
 *
 * This file is pure (no bot imports) so it can be unit-tested in isolation.
 * trading-bot.ts calls into it from three hooks: evaluateEntry (after the
 * aligned/W2 side locks are computed), the PATH_RIDE exit block, and
 * recordSettlement.
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { execSync } from "node:child_process";
import { kalshiTakerFeeCents } from "./fees/kalshi-fee.js";
import type { AlignedTake } from "./aligned-take-gate.js";
import { sanitizeTheoCents } from "./brti-theo-sanity.js";

// ── Constants (change = new experiment, bump FROZEN_CC_RULESET_VERSION) ──────

export const FROZEN_CC_RULESET_VERSION = "frozen-cc-v1";
export const FROZEN_CC_STRATEGY_ID = "CONFLUENCE_CASCADE" as const;
export const FROZEN_CC_MIN_SECS = 3 * 60;
export const FROZEN_CC_MAX_SECS = 13 * 60;
export const FROZEN_CC_ASK_MIN = 20;
export const FROZEN_CC_ASK_MAX = 55;
export const FROZEN_CC_STILL_MID_MIN = 48;
export const FROZEN_CC_STILL_MID_MAX = 52;
export const FROZEN_CC_DEFAULT_CATASTROPHIC_CENTS = 5;
/** Sustained mark≤catastrophic required before PATH_RIDE_CATASTROPHIC (no single-wick dump). */
export const FROZEN_CC_CATASTROPHIC_SUSTAIN_MS = 20_000;
export const FROZEN_CC_LEDGER_FILENAME = "frozen-cc-ledger.jsonl";

/** Every strategy id the library knows. Frozen mode disables all but CC. */
export const ALL_STRATEGY_IDS = [
  "VELOCITY_MOMENTUM", "FLOOR_DISTANCE", "BREAKOUT_CAPTURE", "FAKEOUT_FADE",
  "EXHAUSTION_ANCHOR", "BRTI_PROBABILITY", "SQUEEZE_EXPANSION", "CONFLUENCE_CASCADE",
  "LATE_ENTRY_ANCHOR", "MTF_ALIGNED", "CHANNEL_BOUNCE", "OTM_BREAKOUT_EXPANSION",
  "OTM_ASYMMETRY", "DEEP_OTM_SNIPER", "VELOCITY_STALL_REVERSAL", "SAKATA_CANDLE_PATTERN",
  "LATE_MOMENTUM_CONTINUATION", "BASIS_LAG_EDGE", "MEAN_REVERSION_STRETCH", "BOLLINGER_BAND",
  "SETTLEMENT_PREDICTION", "TOP_REVERSAL", "BOTTOM_REVERSAL", "CHEAP_SIDE_15M",
  "CHEAP_EARLY_EXIT", "PANIC_FADE", "STREAK_SAT_FADE", "HA_RIVER",
] as const;

/** Strategy ids frozen CC must keep out of evaluate (CC itself stays eligible). */
export function unionFrozenEvaluateDisabled(): string[] {
  return ALL_STRATEGY_IDS.filter((id) => id !== FROZEN_CC_STRATEGY_ID);
}

// ── Config lock ──────────────────────────────────────────────────────────────

export type FrozenCcLockableConfig = {
  frozenCcMode?: boolean;
  frozenCcFixedContracts?: number | null;
  frozenCcTakeProfitCents?: number | null;
  frozenCcCatastrophicCents?: number;
  autoMode?: boolean;
  autoModeV2Mode?: "off" | "suggest" | "bounded_write";
  autoPolicyMode?: string;
  useExpertAgent?: boolean;
  specialistPacksMode?: string;
  useDailyTarget?: boolean;
  enable1HContracts?: boolean;
  enable1HLive?: boolean;
  holdToSettlement?: boolean;
  strategyOverride?: string | null;
  disabledStrategies?: string[];

  sessionHarvestEnabled?: boolean;
  settlementVetoEnabled?: boolean;
  settlementConsensusVoteEnabled?: boolean;
  useSettlementHold?: boolean;
  useStrongMTFDirectionLock?: boolean;
  usePerpsOtmHunter?: boolean;
  perpsOtmHunterEnabled?: boolean;
  /** Snapshot of operator values before freeze — restored when frozenCcMode turns off. */
  frozenCcSaved?: {
    autoMode?: boolean;
    autoModeV2Mode?: "off" | "suggest" | "bounded_write";
  autoPolicyMode?: string;
    useExpertAgent?: boolean;
    specialistPacksMode?: string;
    useDailyTarget?: boolean;
    enable1HContracts?: boolean;
    enable1HLive?: boolean;
    holdToSettlement?: boolean;
    strategyOverride?: string | null;
    disabledStrategies?: string[];
    settlementVetoEnabled?: boolean;
    settlementConsensusVoteEnabled?: boolean;
  } | null;
};

export const FROZEN_CC_N_ACTIONABLE = 40;
export const FROZEN_CC_N_STRONG = 100;
export const FROZEN_CC_N_FABLE = 200;


/**
 * Forces every runtime re-enable path off while frozen. Runs inside
 * applyComposerLocks so boot-restore, PUT /bot/config, the agent tool and the
 * dashboard all converge on the same values. Returns the notes it applied.
 */
export function applyFrozenCcLocks<T extends FrozenCcLockableConfig>(
  config: T,
): { config: T; notes: string[] } {
  if (config.frozenCcMode !== true) return { config, notes: [] };
  const next: T = { ...config };
  const notes: string[] = [];
  // Snapshot once so turning the mode off can restore the operator desk.
  if (!(next as FrozenCcLockableConfig).frozenCcSaved) {
    (next as FrozenCcLockableConfig).frozenCcSaved = {
      autoMode: next.autoMode,
      autoPolicyMode: next.autoPolicyMode,
      autoModeV2Mode: next.autoModeV2Mode,
      useExpertAgent: next.useExpertAgent,
      specialistPacksMode: next.specialistPacksMode,
      useDailyTarget: next.useDailyTarget,
      enable1HContracts: next.enable1HContracts,
      enable1HLive: next.enable1HLive,
      holdToSettlement: next.holdToSettlement,
      strategyOverride: next.strategyOverride ?? null,
      disabledStrategies: [...(next.disabledStrategies ?? [])],
      settlementVetoEnabled: next.settlementVetoEnabled,
      settlementConsensusVoteEnabled: next.settlementConsensusVoteEnabled,
    };
    notes.push("FROZEN_CC: snapshot pre-freeze config into frozenCcSaved");
  }
  const force = <K extends keyof FrozenCcLockableConfig>(key: K, value: FrozenCcLockableConfig[K]) => {
    if (next[key] !== value) {
      notes.push(`FROZEN_CC: ${String(key)} ${JSON.stringify(next[key])} -> ${JSON.stringify(value)}`);
      (next as FrozenCcLockableConfig)[key] = value;
    }
  };
  force("autoMode", false);
  if (next.autoPolicyMode === "live") force("autoPolicyMode", "shadow");
  force("autoModeV2Mode", "off");
  force("useExpertAgent", false);
  force("specialistPacksMode", "off");
  force("useDailyTarget", false);
  force("enable1HContracts", false);
  force("enable1HLive", false);
  // C-money money-machine: sell-green / PATH_RIDE adaptive — never pure hold-to-settle.
  force("holdToSettlement", false);
  force("strategyOverride", null);
  force("settlementVetoEnabled", false);
  force("settlementConsensusVoteEnabled", false);
  if ("usePerpsOtmHunter" in next) force("usePerpsOtmHunter", false);
  if ("perpsOtmHunterEnabled" in next) force("perpsOtmHunterEnabled", false);
  const wantDisabled = ALL_STRATEGY_IDS.filter((id) => id !== FROZEN_CC_STRATEGY_ID);
  const have = new Set(next.disabledStrategies ?? []);
  const same = wantDisabled.length === have.size && wantDisabled.every((id) => have.has(id));
  if (!same) {
    notes.push(`FROZEN_CC: disabledStrategies -> everything except ${FROZEN_CC_STRATEGY_ID}`);
    next.disabledStrategies = [...wantDisabled];
  }
  const fixed = next.frozenCcFixedContracts;
  if (fixed != null && (!Number.isFinite(fixed) || fixed < 1 || Math.floor(fixed) !== fixed)) {
    notes.push(`FROZEN_CC: frozenCcFixedContracts ${JSON.stringify(fixed)} invalid -> null (use sizing band)`);
    next.frozenCcFixedContracts = null;
  }
  const tp = next.frozenCcTakeProfitCents;
  if (tp != null && (!Number.isFinite(tp) || tp < 60 || tp > 99)) {
    notes.push(`FROZEN_CC: frozenCcTakeProfitCents ${JSON.stringify(tp)} outside 60..99 -> null (off)`);
    next.frozenCcTakeProfitCents = null;
  }
  const cat = next.frozenCcCatastrophicCents;
  if (cat == null || !Number.isFinite(cat) || cat < 1 || cat > 15) {
    if (cat !== FROZEN_CC_DEFAULT_CATASTROPHIC_CENTS) {
      notes.push(`FROZEN_CC: frozenCcCatastrophicCents ${JSON.stringify(cat)} -> ${FROZEN_CC_DEFAULT_CATASTROPHIC_CENTS}`);
    }
    next.frozenCcCatastrophicCents = FROZEN_CC_DEFAULT_CATASTROPHIC_CENTS;
  }
  return { config: next, notes };
}

// ── Entry decision ───────────────────────────────────────────────────────────

export type FrozenSide = "yes" | "no";

/**
 * Everything the old funnel would have vetoed on, recorded but NOT enforced.
 * Null means "not computed this tick". These are the columns the go/no-go
 * analysis will slice on after >=200 settled fills.
 */
export type FrozenShadowFlags = {
  w2Kind: "TAKE" | "SKIP" | "TAG" | string | null;
  w2Reason: string | null;
  sessionMode: string | null;
  harvestWouldSuppress: boolean | null;
  regime: string | null;
  grokRegime: string | null;
  regimeWouldBlock: boolean | null;
  mtfScore: number | null;
  lagProven: boolean | null;
  lagStale: boolean | null;
  lagDollars: number | null;
  velocityDolPerMin: number | null;
  ccVelocityWouldBlock: string | null;
  htfWouldBlock: boolean | null;
  streakSaturationWouldBlock: boolean | null;
  consecutiveLosses: number | null;
  spreadCents: number | null;
  ccConfidence: number | null;
  ccReason: string | null;
  alignedKind: "TAKE" | "SKIP" | null;
  alignedReason: string | null;
  alignedStrategyId: string | null;
  constructedNo: boolean | null;
  /** update_015: lockSide organ shadow (not a 7th gate). */
  lockSideKind: "TAKE" | "SKIP" | "TAG" | string | null;
  lockSideWhy: string | null;
  lockSideMtf: number | null;
};

export function emptyShadowFlags(): FrozenShadowFlags {
  return {
    w2Kind: null, w2Reason: null, sessionMode: null, harvestWouldSuppress: null,
    regime: null, grokRegime: null, regimeWouldBlock: null, mtfScore: null,
    lagProven: null, lagStale: null, lagDollars: null, velocityDolPerMin: null,
    ccVelocityWouldBlock: null, htfWouldBlock: null, streakSaturationWouldBlock: null,
    consecutiveLosses: null, spreadCents: null, ccConfidence: null, ccReason: null,
    alignedKind: null, alignedReason: null, alignedStrategyId: null, constructedNo: null,
    lockSideKind: null, lockSideWhy: null, lockSideMtf: null,
  };
}

/**
 * Dual-brain kill at placeOrder: when frozenCcMode is on, only a fill stamped
 * by the decideFrozenCcEntry TAKE path (params.frozenCc === true) may admit.
 * Legacy evaluateEntry / hourly / SIZE_RESCUE cannot place without that stamp.
 * Does not cut floors, ENABLE leftovers, or flip paperMode.
 */
export function shouldBlockPlaceOrderWithoutFrozenDecision(opts: {
  frozenCcMode: boolean | undefined;
  frozenCc?: boolean;
}): boolean {
  if (opts.frozenCcMode !== true) return false;
  return opts.frozenCc !== true;
}

/** Pre-decision shadow stamp (W2 / session / regime / aligned) — peeled from evaluateEntry. */
export type FrozenShadowPreDecisionInput = {
  w2Kind: FrozenShadowFlags["w2Kind"];
  w2Reason: string | null;
  sessionMode: string | null;
  harvestWouldSuppress: boolean | null;
  regime: string | null;
  grokRegime: string | null;
  regimeWouldBlock: boolean | null;
  mtfScore: number | null;
  lagProven: boolean | null;
  lagStale: boolean | null;
  lagDollars: number | null;
  velocityDolPerMin: number | null;
  consecutiveLosses: number | null;
  ccConfidence: number | null;
  ccReason: string | null;
  aligned: AlignedTake;
};

export function buildFrozenShadowPreDecision(input: FrozenShadowPreDecisionInput): FrozenShadowFlags {
  const shadow = emptyShadowFlags();
  shadow.w2Kind = input.w2Kind;
  shadow.w2Reason = input.w2Reason;
  shadow.sessionMode = input.sessionMode;
  shadow.harvestWouldSuppress = input.harvestWouldSuppress;
  shadow.regime = input.regime;
  shadow.grokRegime = input.grokRegime;
  shadow.regimeWouldBlock = input.regimeWouldBlock;
  shadow.mtfScore = input.mtfScore;
  shadow.lagProven = input.lagProven;
  shadow.lagStale = input.lagStale;
  shadow.lagDollars = input.lagDollars;
  shadow.velocityDolPerMin = input.velocityDolPerMin;
  shadow.consecutiveLosses = input.consecutiveLosses;
  shadow.ccConfidence = input.ccConfidence;
  shadow.ccReason = input.ccReason;
  shadow.alignedKind = input.aligned.kind;
  shadow.alignedReason = input.aligned.kind === "SKIP" ? input.aligned.reason : null;
  shadow.alignedStrategyId = input.aligned.kind === "TAKE" ? input.aligned.strategyId : null;
  shadow.constructedNo = input.aligned.kind === "TAKE" ? input.aligned.constructedNo === true : null;
  return shadow;
}

/** Side-specific shadow flags after decideFrozenCcEntry TAKE (ccVel / HTF / spread). Pure. */
export type FrozenShadowPostTakeInput = {
  shadow: FrozenShadowFlags;
  side: FrozenSide;
  ask: number;
  /** From ccVelocityAgainstGate — reason string when block, else null. */
  ccVelocityWouldBlock: string | null;
  /** HTF sideBias; null = HTF threw / unknown → htfWouldBlock null. */
  htfSideBias: "YES" | "NO" | "skip" | "UNKNOWN" | string | null;
  bidCents: number | null | undefined;
};

export function enrichFrozenShadowPostTake(input: FrozenShadowPostTakeInput): FrozenShadowFlags {
  const shadow: FrozenShadowFlags = { ...input.shadow };
  shadow.ccVelocityWouldBlock = input.ccVelocityWouldBlock;
  const bias = input.htfSideBias;
  if (bias == null) {
    shadow.htfWouldBlock = null;
  } else if (bias === "YES") {
    shadow.htfWouldBlock = input.side === "no";
  } else if (bias === "NO") {
    shadow.htfWouldBlock = input.side === "yes";
  } else {
    shadow.htfWouldBlock = false;
  }
  const bid = input.bidCents;
  shadow.spreadCents =
    typeof bid === "number" && Number.isFinite(bid) ? input.ask - bid : null;
  return shadow;
}

/** One-line FROZEN TAKE log (keeps evaluateEntry thin). */
export function formatFrozenCcTakeDesc(input: {
  side: FrozenSide;
  ask: number;
  p: number;
  ev: number;
  secs: number;
  mtfScore: number;
  shadow: FrozenShadowFlags;
}): string {
  const s = input.shadow;
  return (
    `[FROZEN_CC] TAKE ${input.side.toUpperCase()} @ ${input.ask}¢ p=${input.p.toFixed(2)} EV=${input.ev.toFixed(1)}¢ ` +
    `secs=${Math.round(input.secs)} mtf=${input.mtfScore} shadow{w2=${s.w2Kind}${s.w2Reason ? ":" + s.w2Reason : ""} ` +
    `harvest=${s.harvestWouldSuppress} regime=${s.regimeWouldBlock} ccVel=${s.ccVelocityWouldBlock ?? "-"} htf=${s.htfWouldBlock}}`
  );
}

/** LIVE hard-sit reason when frozenCcAndSit AND (ha_disagree ∧ regimeWouldBlock). */
export const AND_SIT_HA_REGIME = "AND_SIT_HA_REGIME";

/**
 * Same predicate as shadow-sit-watch andSitWouldBlock — kept here so frozen-cc
 * never imports the observe-only sit-watch module (sit-watch imports frozen-cc).
 */
export function andSitWouldBlockLive(haDisagree: boolean, regimeWouldBlock: boolean): boolean {
  return haDisagree === true && regimeWouldBlock === true;
}

/** Fail-closed LIVE entry blocker: flag armed AND both soft sits true. */
export function andSitHardBlocksEntry(opts: {
  armed: boolean;
  haDisagree: boolean;
  regimeWouldBlock: boolean;
}): boolean {
  return opts.armed === true && andSitWouldBlockLive(opts.haDisagree, opts.regimeWouldBlock);
}

export type FrozenCcEntryInput = {
  secsRemaining: number;
  yesAsk: number | null | undefined;
  noAsk: number | null | undefined;
  /** CONFLUENCE_CASCADE evaluate() result for this tick, or null if it did not fire. */
  cc: { signal: "YES" | "NO" | "STAY_OUT"; confidence: number; reason?: string } | null;
  aligned: AlignedTake;
  shadow: FrozenShadowFlags;
  /**
   * When true, hard-SIT if ha_disagree ∧ regimeWouldBlock (AND only).
   * Default/omit = false historically. Separate from promote ha_disagree observeOnly.
   */
  andSitArmed?: boolean;
};

export type FrozenCcEntryDecision =
  | {
      kind: "TAKE";
      strategyId: typeof FROZEN_CC_STRATEGY_ID;
      side: FrozenSide;
      ask: number;
      p: number;
      ev: number;
      confidence: number;
      shadow: FrozenShadowFlags;
    }
  | { kind: "SKIP"; code: string; reason: string; side: FrozenSide | null; ask: number | null; shadow: FrozenShadowFlags };

export function inFrozenAskBand(ask: number | null | undefined): ask is number {
  if (typeof ask !== "number" || !Number.isFinite(ask)) return false;
  return ask >= FROZEN_CC_ASK_MIN && ask <= FROZEN_CC_ASK_MAX;
}

export function inFrozenStillMid(ask: number): boolean {
  return ask >= FROZEN_CC_STILL_MID_MIN && ask <= FROZEN_CC_STILL_MID_MAX;
}

export function inFrozenTimeWindow(secs: number): boolean {
  return Number.isFinite(secs) && secs >= FROZEN_CC_MIN_SECS && secs <= FROZEN_CC_MAX_SECS;
}

/**
 * The six-gate decision. Deterministic and side-effect free.
 * Gate order: time -> CC fired -> aligned TAKE -> same side -> band -> still-mid
 * -> optional AND hard-sit (ha_disagree ∧ regimeWouldBlock when andSitArmed).
 * (EV >= 3 and fresh quote are inside alignedTakeGate / upstream.)
 * OR / ha-alone / regime-alone are NEVER wired here.
 */
export function decideFrozenCcEntry(input: FrozenCcEntryInput): FrozenCcEntryDecision {
  const shadow = input.shadow;
  const skip = (code: string, reason: string, side: FrozenSide | null, ask: number | null): FrozenCcEntryDecision =>
    ({ kind: "SKIP", code, reason, side, ask, shadow });

  const ccSide: FrozenSide | null =
    input.cc?.signal === "YES" ? "yes" : input.cc?.signal === "NO" ? "no" : null;
  const ccAsk = ccSide === "yes" ? input.yesAsk : ccSide === "no" ? input.noAsk : null;
  const ccAskNum = typeof ccAsk === "number" && Number.isFinite(ccAsk) ? ccAsk : null;

  if (!inFrozenTimeWindow(input.secsRemaining)) {
    return skip("FROZEN_TIME_WINDOW",
      `secs=${Math.round(input.secsRemaining)} outside ${FROZEN_CC_MIN_SECS}..${FROZEN_CC_MAX_SECS}`,
      ccSide, ccAskNum);
  }
  if (!ccSide) {
    return skip("FROZEN_CC_NOT_FIRED", "CONFLUENCE_CASCADE did not signal this tick", null, null);
  }
  if (input.aligned.kind !== "TAKE") {
    return skip("FROZEN_ALIGNED_SKIP", `alignedTakeGate ${input.aligned.reason}`, ccSide, ccAskNum);
  }
  if (input.aligned.strategyId !== FROZEN_CC_STRATEGY_ID) {
    return skip("FROZEN_ALIGNED_NOT_CC", `alignedTakeGate chose ${input.aligned.strategyId}`, ccSide, ccAskNum);
  }
  if (input.aligned.side !== ccSide) {
    return skip("FROZEN_SIDE_DISAGREE",
      `CC says ${ccSide.toUpperCase()} but MTF/strike lock says ${input.aligned.side.toUpperCase()}`,
      ccSide, ccAskNum);
  }
  const ask = input.aligned.ask;
  if (!inFrozenAskBand(ask)) {
    return skip("FROZEN_PRICE_BAND", `ask ${ask}¢ outside ${FROZEN_CC_ASK_MIN}..${FROZEN_CC_ASK_MAX}`, ccSide, ask);
  }
  if (inFrozenStillMid(ask)) {
    return skip("FROZEN_STILL_MID", `ask ${ask}¢ inside coin-flip ${FROZEN_CC_STILL_MID_MIN}..${FROZEN_CC_STILL_MID_MAX}`, ccSide, ask);
  }

  // LIVE AND paper-sit (Stellar YES 2026-09-11): block only when BOTH soft sits
  // would fire. Flag default false historically; promote ha_disagree stays observeOnly.
  const haDisagree = shadow.w2Reason === "ha_disagree";
  const regimeBlock = shadow.regimeWouldBlock === true;
  if (andSitHardBlocksEntry({
    armed: input.andSitArmed === true,
    haDisagree,
    regimeWouldBlock: regimeBlock,
  })) {
    return skip(
      AND_SIT_HA_REGIME,
      `AND sit: ha_disagree ∧ regimeWouldBlock (fail-closed)`,
      ccSide,
      ask,
    );
  }

  return {
    kind: "TAKE",
    strategyId: FROZEN_CC_STRATEGY_ID,
    side: ccSide,
    ask,
    p: input.aligned.p,
    ev: input.aligned.ev,
    confidence: input.cc?.confidence ?? 0,
    shadow,
  };
}

// ── Exit decision ────────────────────────────────────────────────────────────

export type FrozenCcExitInput = {
  entryCents: number;
  markCents: number;
  secsRemaining: number;
  catastrophicCents: number;
  takeProfitCents: number | null;
  /** What the legacy PATH_RIDE disposition wanted (SELL reason). */
  shadowRideKind: string | null;
  shadowRideReason: string | null;
  /**
   * C-money money-machine (ask 20–55): defer to real PATH_RIDE for green TP /
   * soft giveback / thesis exits. Catastrophic remains a sustained failsafe only.
   * When false, PATH_RIDE is shadow-only (legacy hold-to-settle experiment).
   */
  moneyMachinePathRide?: boolean;
  /** Continuous ms the mark has been ≤ catastrophicCents (0 if currently above). */
  catastrophicBelowMs?: number;
  /** Required sustain for catastrophic (default FROZEN_CC_CATASTROPHIC_SUSTAIN_MS). */
  catastrophicSustainMs?: number;
};

export type FrozenCcExitDecision =
  | { action: "SELL"; reason: "PATH_RIDE_CATASTROPHIC" | "FROZEN_TAKE_PROFIT" }
  | { action: "HOLD"; shadowWouldSell: string | null }
  | { action: "DEFER_PATH_RIDE" };

export function decideFrozenCcExit(input: FrozenCcExitInput): FrozenCcExitDecision {
  const mark = input.markCents;
  const moneyMachine = input.moneyMachinePathRide === true;
  const sustainNeed = input.catastrophicSustainMs ?? FROZEN_CC_CATASTROPHIC_SUSTAIN_MS;
  const belowMs = input.catastrophicBelowMs ?? 0;

  // Last-resort failsafe: sustained ≤threshold only — a single wick must not dump.
  // Money-machine: DEFER to decidePathRideExit which gates cat as BROKEN+persist≥20s
  // ONLY (projection-against NOT enough). Do not dump VALID/UNKNOWN/omit here (#12 /
  // UNKNOWN-cat class). DEFER is safe only because PATH_RIDE itself is so gated.
  if (
    Number.isFinite(mark)
    && mark <= input.catastrophicCents
    && belowMs >= sustainNeed
  ) {
    if (moneyMachine) {
      return { action: "DEFER_PATH_RIDE" };
    }
    return { action: "SELL", reason: "PATH_RIDE_CATASTROPHIC" };
  }

  // mark≤cat but not sustained: HOLD — never DEFER into PATH_RIDE same tick
  // (DEFER→instant PATH_RIDE_CATASTROPHIC re-admit caused −$12.69 class wipe).
  if (Number.isFinite(mark) && mark <= input.catastrophicCents && belowMs < sustainNeed) {
    return { action: "HOLD", shadowWouldSell: "PATH_RIDE_CATASTROPHIC" };
  }

  if (input.takeProfitCents != null && Number.isFinite(mark) && mark >= input.takeProfitCents) {
    return { action: "SELL", reason: "FROZEN_TAKE_PROFIT" };
  }

  if (moneyMachine) {
    // Adaptive PATH_RIDE owns green exits / giveback / thesis — not shadow-hold.
    return { action: "DEFER_PATH_RIDE" };
  }

  const shadowWouldSell = input.shadowRideKind === "SELL" ? (input.shadowRideReason ?? "SELL") : null;
  return { action: "HOLD", shadowWouldSell };
}

// ── Counterfactual + ledger ──────────────────────────────────────────────────

/**
 * Fee-net P&L (cents, whole position) if the position had been held to
 * settlement. Settlement pays 100¢ with no exit fee; entry taker fee applies.
 * Returns null when the settled side is unknown.
 */
export function holdToSettlementPnlCents(opts: {
  side: FrozenSide;
  entryCents: number;
  contracts: number;
  settledSide: FrozenSide | null | undefined;
}): number | null {
  const { side, entryCents, contracts, settledSide } = opts;
  if (settledSide !== "yes" && settledSide !== "no") return null;
  if (!(contracts > 0) || !Number.isFinite(entryCents)) return null;
  const fee = kalshiTakerFeeCents(entryCents, contracts);
  const won = settledSide === side;
  return won ? (100 - entryCents) * contracts - fee : -(entryCents * contracts) - fee;
}

export type FrozenLedgerFillRow = {
  kind: "FILL";
  ruleset: string;
  gitSha: string | null;
  ts: number;
  ticker: string;
  strategyId: string;
  side: FrozenSide;
  askCents: number;
  contracts: number;
  secsRemaining: number;
  p: number | null;
  evCents: number | null;
  confidence: number | null;
  entryFeeCents: number;
  paper: boolean;
  shadow: FrozenShadowFlags;
  /** BSM theo at fill (¢); null if BRTI/vol unavailable or outside [10,90]. OBSERVE only. */
  entryTheoCents?: number | null;
  /** True when entryTheoCents is null (missing BRTI, incomplete inputs, or out-of-band). */
  entryTheoMissing?: boolean;
};

export type FrozenLedgerCloseRow = {
  kind: "CLOSE";
  ruleset: string;
  gitSha: string | null;
  ts: number;
  ticker: string;
  strategyId: string;
  side: FrozenSide;
  askCents: number;
  contracts: number;
  exitReason: string;
  exitPriceCents: number | null;
  holdMs: number;
  outcome: "win" | "loss";
  pnlCents: number;
  /** Fee-net realised PnL (same units as pnlCents; named for scoreboard). */
  feeNetCents: number;
  /** Skip baseline PnL (0 = never-took counterfactual). */
  skipPnlCents: number;
  /** feeNetCents − skipPnlCents. */
  feeNetVsSkip: number;
  entryFeeCents: number;
  exitFeeCents: number;
  settledSide: FrozenSide | null;
  holdToSettlePnlCents: number | null;
  /** Realised minus counterfactual: negative means the early exit cost money. */
  exitVsHoldCents: number | null;
  shadowExitWouldSell: string | null;
  shadowExitFirstAtMs: number | null;
  shadow: FrozenShadowFlags;
  /** BSM theo at exit (¢); null if unavailable. OBSERVE only. */
  exitTheoCents?: number | null;
  /** Propagated from FILL (¢); null + missing when FILL never stamped. OBSERVE only. */
  entryTheoCents?: number | null;
  entryTheoMissing?: boolean;
};

export type FrozenLedgerRow = FrozenLedgerFillRow | FrozenLedgerCloseRow;

export function frozenLedgerPath(): string {
  if (process.env.FROZEN_CC_LEDGER_PATH) return path.resolve(process.env.FROZEN_CC_LEDGER_PATH);
  return path.resolve(process.cwd(), "data", FROZEN_CC_LEDGER_FILENAME);
}

export function appendFrozenLedgerRow(row: FrozenLedgerRow, filePath = frozenLedgerPath()): void {
  try {
    // Fail-closed theo: never persist 1¢ / out-of-band on FILL or CLOSE.
    let out: FrozenLedgerRow = row;
    if (row.kind === "FILL") {
      const s = sanitizeTheoCents(row.entryTheoCents);
      out = {
        ...row,
        entryTheoCents: s.theoCents,
        entryTheoMissing: s.theoMissing || row.entryTheoMissing === true || s.theoCents == null,
      };
    } else if (row.kind === "CLOSE") {
      const sExit = sanitizeTheoCents(row.exitTheoCents);
      const sEntry = sanitizeTheoCents(row.entryTheoCents);
      out = {
        ...row,
        exitTheoCents: sExit.theoCents,
        entryTheoCents: sEntry.theoCents,
        entryTheoMissing: sEntry.theoMissing || row.entryTheoMissing === true || sEntry.theoCents == null,
      };
    }
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.appendFileSync(filePath, JSON.stringify(out) + "\n");
  } catch {
    // Measurement must never take the bot down. The row is also in the log.
  }
}

export function readFrozenLedger(filePath = frozenLedgerPath()): FrozenLedgerRow[] {
  try {
    if (!fs.existsSync(filePath)) return [];
    return fs.readFileSync(filePath, "utf8")
      .split("\n")
      .filter((l) => l.trim().length > 0)
      .map((l) => {
        const row = JSON.parse(l) as FrozenLedgerRow;
        // Read-side sanitize: null any 1¢ / out-of-band theo leaked into historical jsonl.
        if (row.kind === "FILL") {
          const s = sanitizeTheoCents(row.entryTheoCents);
          return {
            ...row,
            entryTheoCents: s.theoCents,
            entryTheoMissing: s.theoMissing || row.entryTheoMissing === true || s.theoCents == null,
          };
        }
        if (row.kind === "CLOSE") {
          const sExit = sanitizeTheoCents(row.exitTheoCents);
          const sEntry = sanitizeTheoCents(row.entryTheoCents);
          return {
            ...row,
            exitTheoCents: sExit.theoCents,
            entryTheoCents: sEntry.theoCents,
            entryTheoMissing: sEntry.theoMissing || row.entryTheoMissing === true || sEntry.theoCents == null,
          };
        }
        return row;
      });
  } catch {
    return [];
  }
}

let cachedGitSha: string | null | undefined;
/** Short git SHA of the running checkout (env GIT_SHA wins; best effort). */
export function runningGitSha(): string | null {
  if (cachedGitSha !== undefined) return cachedGitSha;
  const fromEnv = process.env.GIT_SHA ?? process.env.REPL_GIT_SHA ?? process.env.SOURCE_COMMIT;
  if (fromEnv && fromEnv.trim()) {
    cachedGitSha = fromEnv.trim().slice(0, 12);
    return cachedGitSha;
  }
  try {
    cachedGitSha = execSync("git rev-parse --short=12 HEAD", { stdio: ["ignore", "pipe", "ignore"], timeout: 2000 })
      .toString().trim() || null;
  } catch {
    cachedGitSha = null;
  }
  return cachedGitSha;
}

// ── Go / no-go summary ───────────────────────────────────────────────────────

export type FrozenCcSummary = {
  ruleset: string;
  fills: number;
  closes: number;
  wins: number;
  losses: number;
  winRate: number | null;
  pnlCents: number;
  meanPnlPerTradeCents: number | null;
  /** 95% CI on mean P&L per trade (normal approx). */
  ci95: [number, number] | null;
  holdToSettlePnlCents: number | null;
  exitVsHoldCents: number | null;
  secondHalfPnlCents: number | null;
  maxDrawdownCents: number;
  targetN: number;
  verdict: "INSUFFICIENT_DATA" | "GO" | "NO_GO";
  reasons: string[];
};

export const FROZEN_CC_TARGET_N = 200;

/**
 * Promote N / WR / PnL must count one settled bot CC fill once.
 * Spam CLOSE rows (persist-fail KEEP re-entry) and SETTLEMENT ghosts after an
 * early PATH_RIDE exit are collapsed: FIFO fill→best close, prefer early exit.
 */
export function uniqueFrozenSettledCloses(rows: FrozenLedgerRow[]): FrozenLedgerCloseRow[] {
  const fills = rows.filter((r): r is FrozenLedgerFillRow => r.kind === "FILL")
    .slice()
    .sort((a, b) => a.ts - b.ts);
  const closes = rows.filter((r): r is FrozenLedgerCloseRow => r.kind === "CLOSE")
    .slice()
    .sort((a, b) => a.ts - b.ts);
  const isEarlyClose = (c: FrozenLedgerCloseRow) => {
    const r = String(c.exitReason ?? "");
    return r.startsWith("PATH_RIDE_") || r === "HIGH_ODDS_EXIT" || r === "HALF_RIDE";
  };
  const pickBest = (buf: FrozenLedgerCloseRow[]) => {
    if (!buf.length) return null;
    const early = buf.filter(isEarlyClose);
    const pool = early.length > 0 ? early : buf;
    return [...pool].sort((a, b) => a.ts - b.ts)[0] ?? null;
  };
  // CLOSE-only ledgers (tests / legacy): one best close per ticker — never raw spam N.
  if (fills.length === 0) {
    const byTicker = new Map<string, FrozenLedgerCloseRow[]>();
    for (const c of closes) {
      const buf = byTicker.get(c.ticker) ?? [];
      buf.push(c);
      byTicker.set(c.ticker, buf);
    }
    const out: FrozenLedgerCloseRow[] = [];
    for (const buf of byTicker.values()) {
      const best = pickBest(buf);
      if (best) out.push(best);
    }
    return out.sort((a, b) => a.ts - b.ts);
  }
  const openFills: FrozenLedgerFillRow[] = [];
  const pendingByTicker = new Map<string, FrozenLedgerCloseRow[]>();
  const out: FrozenLedgerCloseRow[] = [];

  const flushTicker = (ticker: string) => {
    const buf = pendingByTicker.get(ticker) ?? [];
    if (!buf.length) return;
    const fillIdx = openFills.findIndex((f) => f.ticker === ticker);
    if (fillIdx < 0) {
      pendingByTicker.set(ticker, []);
      return; // orphan spam — no FILL
    }
    const best = pickBest(buf);
    openFills.splice(fillIdx, 1);
    pendingByTicker.set(ticker, []);
    if (best) out.push(best);
  };

  // Merge fill+close streams chronologically.
  type Ev = { ts: number; kind: "FILL" | "CLOSE"; fill?: FrozenLedgerFillRow; close?: FrozenLedgerCloseRow };
  const events: Ev[] = [
    ...fills.map((f) => ({ ts: f.ts, kind: "FILL" as const, fill: f })),
    ...closes.map((c) => ({ ts: c.ts, kind: "CLOSE" as const, close: c })),
  ].sort((a, b) => a.ts - b.ts || (a.kind === "FILL" ? -1 : 1));

  for (const ev of events) {
    if (ev.kind === "FILL" && ev.fill) {
      flushTicker(ev.fill.ticker);
      openFills.push(ev.fill);
      continue;
    }
    if (ev.kind === "CLOSE" && ev.close) {
      const t = ev.close.ticker;
      const buf = pendingByTicker.get(t) ?? [];
      buf.push(ev.close);
      pendingByTicker.set(t, buf);
    }
  }
  for (const t of [...pendingByTicker.keys()]) flushTicker(t);
  return out;
}

export function summarizeFrozenLedger(rows: FrozenLedgerRow[], targetN = FROZEN_CC_TARGET_N): FrozenCcSummary {
  const fills = rows.filter((r): r is FrozenLedgerFillRow => r.kind === "FILL");
  const closes = uniqueFrozenSettledCloses(rows);
  const n = closes.length;
  const wins = closes.filter((c) => c.outcome === "win").length;
  const losses = n - wins;
  const pnls = closes.map((c) => c.pnlCents);
  const pnl = pnls.reduce((a, b) => a + b, 0);
  const mean = n > 0 ? pnl / n : null;
  let ci95: [number, number] | null = null;
  if (n >= 2 && mean != null) {
    const varSum = pnls.reduce((a, x) => a + (x - mean) * (x - mean), 0);
    const sd = Math.sqrt(varSum / (n - 1));
    const half = 1.96 * sd / Math.sqrt(n);
    ci95 = [mean - half, mean + half];
  }
  const cfRows = closes.filter((c) => c.holdToSettlePnlCents != null);
  const holdCf = cfRows.length > 0 ? cfRows.reduce((a, c) => a + (c.holdToSettlePnlCents ?? 0), 0) : null;
  const exitVsHold = cfRows.length > 0 ? cfRows.reduce((a, c) => a + (c.exitVsHoldCents ?? 0), 0) : null;
  const half = Math.floor(n / 2);
  const secondHalf = n >= 2 ? pnls.slice(half).reduce((a, b) => a + b, 0) : null;
  let peak = 0, run = 0, maxDd = 0;
  for (const x of pnls) {
    run += x;
    if (run > peak) peak = run;
    if (peak - run > maxDd) maxDd = peak - run;
  }
  const reasons: string[] = [];
  let verdict: FrozenCcSummary["verdict"] = "INSUFFICIENT_DATA";
  if (n < targetN) {
    reasons.push(`${n}/${targetN} settled fills — keep collecting, do not tune`);
  } else {
    const ciPositive = ci95 != null && ci95[0] > 0;
    const secondPositive = secondHalf != null && secondHalf > 0;
    if (ciPositive && secondPositive) {
      verdict = "GO";
      reasons.push("mean P&L per trade > 0 with 95% CI excluding zero", "second half of sample is positive");
    } else {
      verdict = "NO_GO";
      if (!ciPositive) reasons.push("95% CI on mean P&L per trade includes or is below zero");
      if (!secondPositive) reasons.push("second half of sample is not positive");
    }
  }
  return {
    ruleset: FROZEN_CC_RULESET_VERSION,
    fills: fills.length,
    closes: n,
    wins,
    losses,
    winRate: n > 0 ? wins / n : null,
    pnlCents: pnl,
    meanPnlPerTradeCents: mean,
    ci95,
    holdToSettlePnlCents: holdCf,
    exitVsHoldCents: exitVsHold,
    secondHalfPnlCents: secondHalf,
    maxDrawdownCents: maxDd,
    targetN,
    verdict,
    reasons,
  };
}

/** Restore operator values saved when freeze first engaged. */
export function restoreFrozenCcSaved<T extends FrozenCcLockableConfig>(
  config: T,
): { config: T; notes: string[] } {
  if (config.frozenCcMode === true) return { config, notes: [] };
  const saved = config.frozenCcSaved;
  if (!saved) return { config, notes: [] };
  const next: T = { ...config };
  const notes: string[] = [];
  const keys = [
    "autoMode", "autoModeV2Mode", "autoPolicyMode", "useExpertAgent", "specialistPacksMode",
    "useDailyTarget", "enable1HContracts", "enable1HLive", "holdToSettlement",
    "strategyOverride", "disabledStrategies", "settlementVetoEnabled",
    "settlementConsensusVoteEnabled",
  ] as const;
  for (const k of keys) {
    if (k in saved && (saved as Record<string, unknown>)[k] !== undefined) {
      (next as Record<string, unknown>)[k] = (saved as Record<string, unknown>)[k];
      notes.push(`FROZEN_CC restore: ${k}`);
    }
  }
  (next as FrozenCcLockableConfig).frozenCcSaved = null;
  notes.push("FROZEN_CC: cleared frozenCcSaved");
  return { config: next, notes };
}

// ── Promote loop (learn → verdict → human-confirmed apply) ───────────────────
// Phase C (PHD-MASTER-PLAN §8): scoreboard labels inconclusive / candidate /
// GO|NO_GO on unique N at 40/100/200. readyToPromote ONLY when GO criteria met
// (n≥200 + CI>0 + second half >0). Shadow shortlist needs n≥60/side.
// Apply requires exact phrase APPLY FROZEN PROMOTE — never silent draft apply.
// Hard-gate add ⇒ bump FROZEN_CC_RULESET_VERSION (restarts unique count).

export type PromoteTier = "inconclusive" | "preliminary" | "strong" | "fable_gold";
/** Phase C primary scoreboard labels (unique N milestones 40 / 100 / 200). */
export type PromoteScoreboardLabel = "inconclusive" | "candidate" | "GO" | "NO_GO";
export type PromoteGateVerdict = "KEEP_OUT" | "PROMOTE_HARD" | "INCONCLUSIVE";

/** Exact human confirm phrase — any promote apply path must match this. */
export const APPLY_FROZEN_PROMOTE_PHRASE = "APPLY FROZEN PROMOTE";
/** Shadow attribution shortlist: both WITH and WITHOUT arms need this many. */
export const SHADOW_ATTRIBUTION_MIN_N_PER_SIDE = 60;
/** Floors a promote patch must never cut. */
export const PROMOTE_EV_FLOOR_CENTS_MIN = 3;
export const PROMOTE_KELLY_CAP = 0.60;

export type PromoteGateRow = {
  gate: string;
  verdict: PromoteGateVerdict;
  nWith: number;
  nWithout: number;
  pnlWithCents: number;
  pnlWithoutCents: number;
  meanWithCents: number | null;
  meanWithoutCents: number | null;
  wrWith: number | null;
  wrWithout: number | null;
  pnlDeltaMeanCents: number | null;
  wrDelta: number | null;
  /** 95% CI on (meanWith − meanWithout). Null when either arm lacks variance. */
  deltaCi95: [number, number] | null;
  reason: string;
  /** Observe-only splits (e.g. ha_disagree) never auto-wire entry blockers. */
  observeOnly?: boolean;
};

export type PromoteScoreboardSnapshot = {
  nUnique: number;
  /** Primary label from unique N + GO criteria. */
  label: PromoteScoreboardLabel;
  /** Label at the 40 milestone (inconclusive until n≥40, then candidate until 200). */
  at40: PromoteScoreboardLabel;
  /** Label at the 100 milestone. */
  at100: PromoteScoreboardLabel;
  /** Label at the 200 milestone — GO|NO_GO only once n≥200. */
  at200: PromoteScoreboardLabel;
  readyToPromote: boolean;
  goNoGo: "GO" | "NO_GO" | "INSUFFICIENT_DATA";
  ruleset: string;
};

export type FrozenCcPromoteVerdict = {
  ruleset: string;
  generatedAt: string;
  closes: number;
  /** Settled N — alias of closes for Learning scoreboard honesty. */
  settledN: number;
  /** Realised fee-net Σ pnlCents on CLOSE rows. */
  feeNetCents: number;
  /** Documented skip baseline ¢ — "never took" counterfactual inventory (=0). */
  skipBaselineCents: number;
  /** Source label for skip baseline (never silent −0 sugar). */
  skipBaselineSource: "never_took";
  /** feeNetCents − skipBaselineCents. */
  feeNetVsSkip: number;
  /** Per-arm minN for promote CI honesty. */
  minNPerArm: number;
  targetActionable: number;
  targetStrong: number;
  targetFable: number;
  /** Go/no-go always scores against FROZEN_CC_TARGET_N (200), never 40. */
  goNoGoTargetN: number;
  /** Legacy tier (preliminary/strong/fable_gold) — prefer scoreboardLabel. */
  tier: PromoteTier;
  /** Phase C primary label: inconclusive | candidate | GO | NO_GO. */
  scoreboardLabel: PromoteScoreboardLabel;
  /** Milestone snapshot at 40 / 100 / 200. */
  scoreboard: PromoteScoreboardSnapshot;
  /**
   * Phase C: true ONLY when GO criteria met on unique N (n≥200 + CI>0 +
   * second half >0). Never true merely because n≥40.
   */
  readyToPromote: boolean;
  /**
   * True in the candidate band (40 ≤ n < 200): draft/observe only —
   * never implies applyable promote.
   */
  observeOnly: boolean;
  goNoGo: ReturnType<typeof summarizeFrozenLedger>["verdict"];
  gates: PromoteGateRow[];
  /** Shadow shortlist — at most one PROMOTE_HARD flag with n≥60/side. */
  shadowShortlist: PromoteGateRow[];
  shadowShortlistBlocked: boolean;
  shadowShortlistReason: string | null;
  progressLabel: string;
};

const PROMOTE_BOOL_FLAGS: (keyof FrozenShadowFlags)[] = [
  "harvestWouldSuppress", "regimeWouldBlock", "htfWouldBlock",
  "lagProven", "lagStale", "constructedNo",
];

function wrOf(xs: FrozenLedgerCloseRow[]): number | null {
  if (!xs.length) return null;
  return xs.filter((c) => c.outcome === "win").length / xs.length;
}
function meanOf(xs: FrozenLedgerCloseRow[]): number | null {
  if (!xs.length) return null;
  return xs.reduce((a, c) => a + c.pnlCents, 0) / xs.length;
}

/** Sample variance (n−1). Null when n < 2. */
function sampleVar(xs: number[]): number | null {
  if (xs.length < 2) return null;
  const m = xs.reduce((a, b) => a + b, 0) / xs.length;
  return xs.reduce((a, x) => a + (x - m) * (x - m), 0) / (xs.length - 1);
}

/**
 * Attack F4: 95% CI on mean difference (WITH − WITHOUT).
 * Requires both arms n≥2 for variance. Never promotes on raw delta alone.
 */
export function meanDiffCi95(
  withPnls: number[],
  withoutPnls: number[],
): [number, number] | null {
  if (withPnls.length < 2 || withoutPnls.length < 2) return null;
  const mW = withPnls.reduce((a, b) => a + b, 0) / withPnls.length;
  const mO = withoutPnls.reduce((a, b) => a + b, 0) / withoutPnls.length;
  const vW = sampleVar(withPnls);
  const vO = sampleVar(withoutPnls);
  if (vW == null || vO == null) return null;
  const se = Math.sqrt(vW / withPnls.length + vO / withoutPnls.length);
  if (!Number.isFinite(se)) return null;
  const half = 1.96 * se;
  const d = mW - mO;
  return [d - half, d + half];
}

/** Legacy tier labels (kept for API back-compat). Prefer scoreboardLabel. */
export function promoteTierForCloses(n: number): PromoteTier {
  if (n >= FROZEN_CC_N_FABLE) return "fable_gold";
  if (n >= FROZEN_CC_N_STRONG) return "strong";
  if (n >= FROZEN_CC_N_ACTIONABLE) return "preliminary";
  return "inconclusive";
}

/**
 * Phase C scoreboard label on unique N.
 * <40 inconclusive · [40,200) candidate · ≥200 GO|NO_GO from ledger verdict.
 */
export function promoteScoreboardLabel(
  n: number,
  goNoGo: "GO" | "NO_GO" | "INSUFFICIENT_DATA",
): PromoteScoreboardLabel {
  if (n < FROZEN_CC_N_ACTIONABLE) return "inconclusive";
  if (n < FROZEN_CC_TARGET_N) return "candidate";
  return goNoGo === "GO" ? "GO" : "NO_GO";
}

/** Milestone labels at 40 / 100 / 200 for the current unique N. */
export function promoteScoreboardSnapshot(
  n: number,
  goNoGo: "GO" | "NO_GO" | "INSUFFICIENT_DATA",
  ruleset: string = FROZEN_CC_RULESET_VERSION,
): PromoteScoreboardSnapshot {
  const labelAt = (milestone: number): PromoteScoreboardLabel => {
    if (n < milestone) return "inconclusive";
    if (milestone < FROZEN_CC_TARGET_N) return "candidate";
    return goNoGo === "GO" ? "GO" : "NO_GO";
  };
  const label = promoteScoreboardLabel(n, goNoGo);
  return {
    nUnique: n,
    label,
    at40: labelAt(FROZEN_CC_N_ACTIONABLE),
    at100: labelAt(FROZEN_CC_N_STRONG),
    at200: labelAt(FROZEN_CC_TARGET_N),
    readyToPromote: label === "GO",
    goNoGo,
    ruleset,
  };
}

/**
 * Unique settled closes for the active ruleset only.
 * Bumping FROZEN_CC_RULESET_VERSION restarts the promote count (Phase C).
 */
export function uniqueFrozenSettledClosesForRuleset(
  rows: FrozenLedgerRow[],
  ruleset: string = FROZEN_CC_RULESET_VERSION,
): FrozenLedgerCloseRow[] {
  return uniqueFrozenSettledCloses(rows).filter((c) => c.ruleset === ruleset);
}

/**
 * One-flag shadow shortlist. Empty + blocked unless a non-observe PROMOTE_HARD
 * gate has n≥SHADOW_ATTRIBUTION_MIN_N_PER_SIDE on BOTH arms.
 */
export function shadowAttributionShortlist(gates: PromoteGateRow[]): {
  shortlist: PromoteGateRow[];
  blocked: boolean;
  reason: string | null;
} {
  const minN = SHADOW_ATTRIBUTION_MIN_N_PER_SIDE;
  const eligible = gates.filter(
    (g) =>
      g.observeOnly !== true
      && g.verdict === "PROMOTE_HARD"
      && g.nWith >= minN
      && g.nWithout >= minN,
  );
  if (eligible.length === 0) {
    return {
      shortlist: [],
      blocked: true,
      reason:
        `shortlist blocked: need ≥1 PROMOTE_HARD flag with n≥${minN} on both WITH and WITHOUT arms (observe-only gates excluded)`,
    };
  }
  // One flag only — highest mean Δ¢.
  const best = [...eligible].sort(
    (a, b) => (b.pnlDeltaMeanCents ?? -Infinity) - (a.pnlDeltaMeanCents ?? -Infinity),
  )[0]!;
  return { shortlist: [best], blocked: false, reason: null };
}

export type PromotePatchActions = {
  frozenCcMode?: boolean;
  askDoorMin?: number;
  askDoorMax?: number;
  restorePathRide?: boolean;
  restoreLagMoneyMakers?: boolean;
  promoteHardGates?: string[];
  keepOutShadow?: string[];
  paperMode?: boolean;
  keepEvFloorCents?: number;
  keepKelly?: boolean;
  [k: string]: unknown;
};

export type PromotePatchDraft = {
  kind: "frozen-cc-promote-patch-v1";
  confirmPhrase: typeof APPLY_FROZEN_PROMOTE_PHRASE;
  generatedAt: string;
  tier: PromoteTier;
  scoreboardLabel: PromoteScoreboardLabel;
  closes: number;
  settledN: number;
  goNoGo: "GO" | "NO_GO" | "INSUFFICIENT_DATA";
  readyToPromote: boolean;
  /** draft = candidate band; ready = GO. Apply refuses draft. */
  status: "draft" | "ready";
  applyable: boolean;
  actions: PromotePatchActions;
  note: string;
};

export type PromoteApplyGateResult =
  | { ok: true; actions: PromotePatchActions; patch: PromotePatchDraft }
  | { ok: false; reason: string };

/**
 * Human confirm + floor locks for any promote apply path.
 * Refuses without exact APPLY FROZEN PROMOTE. Refuses draft / non-GO.
 * Refuses paperMode false or EV/Kelly cuts. Never mutates disk itself.
 */
export function assertPromoteApplyGate(args: {
  confirmPhrase: string | null | undefined;
  patch: unknown;
}): PromoteApplyGateResult {
  const phrase = typeof args.confirmPhrase === "string" ? args.confirmPhrase : "";
  if (phrase !== APPLY_FROZEN_PROMOTE_PHRASE) {
    return {
      ok: false,
      reason: `Refusing: pass confirm "${APPLY_FROZEN_PROMOTE_PHRASE}" — no silent draft apply`,
    };
  }
  if (args.patch == null || typeof args.patch !== "object") {
    return { ok: false, reason: "Refusing: missing or invalid promote patch" };
  }
  const patch = args.patch as Partial<PromotePatchDraft> & { actions?: PromotePatchActions };
  if (patch.kind != null && patch.kind !== "frozen-cc-promote-patch-v1") {
    return { ok: false, reason: `Refusing: unknown patch kind ${String(patch.kind)}` };
  }
  const actions: PromotePatchActions = { ...(patch.actions ?? {}) };
  if (actions.paperMode === false) {
    return { ok: false, reason: "Refusing: promote patch cannot set paperMode false" };
  }
  if (
    typeof actions.keepEvFloorCents === "number"
    && Number.isFinite(actions.keepEvFloorCents)
    && actions.keepEvFloorCents < PROMOTE_EV_FLOOR_CENTS_MIN
  ) {
    return {
      ok: false,
      reason: `Refusing: cannot cut EV floor below ${PROMOTE_EV_FLOOR_CENTS_MIN}¢`,
    };
  }
  if (actions.keepKelly === false) {
    return { ok: false, reason: "Refusing: cannot cut Kelly" };
  }
  const goNoGo = patch.goNoGo;
  const ready = patch.readyToPromote === true || patch.applyable === true || goNoGo === "GO";
  const status = patch.status;
  if (status === "draft" || !ready) {
    return {
      ok: false,
      reason:
        "Refusing: promote is draft-only until GO criteria on unique N (readyToPromote) — phrase alone is not enough",
    };
  }
  // Force floors even if patch omitted them.
  const safeActions: PromotePatchActions = {
    ...actions,
    paperMode: true,
    keepEvFloorCents: Math.max(
      PROMOTE_EV_FLOOR_CENTS_MIN,
      typeof actions.keepEvFloorCents === "number" && Number.isFinite(actions.keepEvFloorCents)
        ? actions.keepEvFloorCents
        : PROMOTE_EV_FLOOR_CENTS_MIN,
    ),
    keepKelly: true,
  };
  const normalized: PromotePatchDraft = {
    kind: "frozen-cc-promote-patch-v1",
    confirmPhrase: APPLY_FROZEN_PROMOTE_PHRASE,
    generatedAt: typeof patch.generatedAt === "string" ? patch.generatedAt : new Date().toISOString(),
    tier: (patch.tier as PromoteTier) ?? "inconclusive",
    scoreboardLabel: (patch.scoreboardLabel as PromoteScoreboardLabel) ?? "GO",
    closes: Number(patch.closes ?? patch.settledN ?? 0) || 0,
    settledN: Number(patch.settledN ?? patch.closes ?? 0) || 0,
    goNoGo: goNoGo === "GO" || goNoGo === "NO_GO" || goNoGo === "INSUFFICIENT_DATA"
      ? goNoGo
      : "GO",
    readyToPromote: true,
    status: "ready",
    applyable: true,
    actions: safeActions,
    note: typeof patch.note === "string" ? patch.note : "Human-confirmed promote apply",
  };
  return { ok: true, actions: safeActions, patch: normalized };
}

/**
 * Documented ruleset bump contract (Phase C): changing hard gates or ask/EV/Kelly
 * floors requires bumping FROZEN_CC_RULESET_VERSION so unique-N restarts.
 * This helper never mutates the constant — call sites must bump the export.
 */
export function rulesetBumpRestartsPromoteCountNote(nextRuleset: string): string {
  return (
    `Ruleset bump ${FROZEN_CC_RULESET_VERSION} → ${nextRuleset}: unique promote N restarts. `
    + `Hard-gate add requires GO + "${APPLY_FROZEN_PROMOTE_PHRASE}"; without phrase = draft-only / refuse apply.`
  );
}

export function computePromoteVerdict(
  rows: FrozenLedgerRow[],
  opts?: { minN?: number; ruleset?: string },
): FrozenCcPromoteVerdict {
  const ruleset = opts?.ruleset ?? FROZEN_CC_RULESET_VERSION;
  // Promote N = unique settled bot CC fills for active ruleset — never raw CLOSE spam.
  const closes = uniqueFrozenSettledClosesForRuleset(rows, ruleset);
  const n = closes.length;
  const tier = promoteTierForCloses(n);
  // Gate measurement may look at n≥40; readyToPromote itself is GO-only (below).
  const measurementReady = n >= FROZEN_CC_N_ACTIONABLE;
  // Attack F4 / L2: goNoGo MUST use TARGET_N=200 — never rebound to 40 (fake GO).
  // Score against current-ruleset closes only (bump restarts count).
  const summary = summarizeFrozenLedger(
    rows.filter((r) => r.ruleset === ruleset),
    FROZEN_CC_TARGET_N,
  );
  const scoreboard = promoteScoreboardSnapshot(n, summary.verdict, ruleset);
  const scoreboardLabel = scoreboard.label;
  const ready = scoreboard.readyToPromote; // GO only
  const observeOnly = scoreboardLabel === "candidate";
  const minN = opts?.minN ?? Math.min(20, Math.floor(FROZEN_CC_N_ACTIONABLE / 2));
  const feeNetCents = closes.reduce((a, c) => a + c.pnlCents, 0);
  const gates: PromoteGateRow[] = [];

  const split = (
    name: string,
    pred: (sh: FrozenShadowFlags) => boolean | null,
    gateOpts?: { observeOnly?: boolean },
  ) => {
    const on = closes.filter((c) => pred(c.shadow) === true);
    const off = closes.filter((c) => pred(c.shadow) === false);
    const meanWith = meanOf(on);
    const meanWithout = meanOf(off);
    const wrWith = wrOf(on);
    const wrWithout = wrOf(off);
    const delta = meanWith != null && meanWithout != null ? meanWith - meanWithout : null;
    const deltaCi = meanDiffCi95(
      on.map((c) => c.pnlCents),
      off.map((c) => c.pnlCents),
    );
    let verdict: PromoteGateVerdict = "INCONCLUSIVE";
    let reason = "";
    if (on.length < minN || off.length < minN || !measurementReady) {
      verdict = "INCONCLUSIVE";
      reason = !measurementReady
        ? `${n}/${FROZEN_CC_N_ACTIONABLE} settled — need ≥${FROZEN_CC_N_ACTIONABLE} before promote measurement`
        : `nWith=${on.length} nWithout=${off.length} below minN=${minN}`;
    } else if (deltaCi == null) {
      verdict = "INCONCLUSIVE";
      reason = `need n≥2 on both arms for 95% CI (nWith=${on.length} nWithout=${off.length}) — raw Δ alone never promotes`;
    } else if (deltaCi[0] > 0) {
      // CI entirely above 0 → WITH significantly beats WITHOUT → PROMOTE_HARD
      verdict = "PROMOTE_HARD";
      reason = `Δ mean ${delta!.toFixed(1)}¢ · 95% CI [${deltaCi[0].toFixed(1)}, ${deltaCi[1].toFixed(1)}] excludes 0 (WITH > WITHOUT)`;
    } else if (deltaCi[1] < 0) {
      verdict = "KEEP_OUT";
      reason = `Δ mean ${delta!.toFixed(1)}¢ · 95% CI [${deltaCi[0].toFixed(1)}, ${deltaCi[1].toFixed(1)}] excludes 0 (WITH ≤ WITHOUT) — stay shadow/OFF`;
    } else {
      verdict = "INCONCLUSIVE";
      reason = `Δ mean ${(delta ?? 0).toFixed(1)}¢ · 95% CI [${deltaCi[0].toFixed(1)}, ${deltaCi[1].toFixed(1)}] includes 0 — never raw delta>0`;
    }
    gates.push({
      gate: name, verdict, nWith: on.length, nWithout: off.length,
      pnlWithCents: on.reduce((a, c) => a + c.pnlCents, 0),
      pnlWithoutCents: off.reduce((a, c) => a + c.pnlCents, 0),
      meanWithCents: meanWith, meanWithoutCents: meanWithout,
      wrWith, wrWithout, pnlDeltaMeanCents: delta,
      wrDelta: wrWith != null && wrWithout != null ? wrWith - wrWithout : null,
      deltaCi95: deltaCi,
      reason,
      observeOnly: gateOpts?.observeOnly === true ? true : undefined,
    });
  };

  for (const f of PROMOTE_BOOL_FLAGS) {
    split(String(f), (sh) => (typeof sh[f] === "boolean" ? (sh[f] as boolean) : null));
  }
  split("w2 SKIP", (sh) => (sh.w2Kind == null ? null : sh.w2Kind === "SKIP"));
  // L7: null → exclude both arms (never coerce unknown into WITHOUT).
  split("ccVelocityWouldBlock", (sh) => (sh.ccVelocityWouldBlock == null ? null : true));
  split("sessionMode HARVEST", (sh) => (sh.sessionMode == null ? null : sh.sessionMode === "HARVEST"));
  // L4 / Attack F4: ha_disagree observe split in verdict only — NEVER entry blocker.
  split(
    "ha_disagree",
    (sh) => (sh.w2Reason == null ? null : sh.w2Reason === "ha_disagree"),
    { observeOnly: true },
  );

  const short = shadowAttributionShortlist(gates);

  const progressTarget = n < FROZEN_CC_N_ACTIONABLE
    ? FROZEN_CC_N_ACTIONABLE
    : n < FROZEN_CC_N_STRONG
      ? FROZEN_CC_N_STRONG
      : FROZEN_CC_N_FABLE;
  // L6: always surface goNoGoTargetN=200. Phase C label in progress string.
  const progressLabel = scoreboardLabel === "GO"
    ? `${n}/${progressTarget} GO · readyToPromote (target ${FROZEN_CC_TARGET_N})`
    : `${n}/${progressTarget} ${scoreboardLabel} · goNoGo=${summary.verdict} (target ${FROZEN_CC_TARGET_N})${observeOnly ? " · observe-only/draft" : ""}`;

  return {
    ruleset,
    generatedAt: new Date().toISOString(),
    closes: n,
    settledN: n,
    feeNetCents,
    skipBaselineCents: 0,
    skipBaselineSource: "never_took" as const,
    feeNetVsSkip: feeNetCents - 0,
    minNPerArm: minN,
    targetActionable: FROZEN_CC_N_ACTIONABLE,
    targetStrong: FROZEN_CC_N_STRONG,
    targetFable: FROZEN_CC_N_FABLE,
    goNoGoTargetN: FROZEN_CC_TARGET_N,
    tier,
    scoreboardLabel,
    scoreboard,
    readyToPromote: ready,
    observeOnly,
    goNoGo: summary.verdict,
    gates,
    shadowShortlist: short.shortlist,
    shadowShortlistBlocked: short.blocked,
    shadowShortlistReason: short.reason,
    progressLabel,
  };
}

export function promoteVerdictPath(): string {
  if (process.env.FROZEN_CC_PROMOTE_VERDICT_PATH) {
    return path.resolve(process.env.FROZEN_CC_PROMOTE_VERDICT_PATH);
  }
  return path.resolve(process.cwd(), "data", "frozen-cc-promote-verdict.json");
}

export function promotePatchPath(): string {
  if (process.env.FROZEN_CC_PROMOTE_PATCH_PATH) {
    return path.resolve(process.env.FROZEN_CC_PROMOTE_PATCH_PATH);
  }
  return path.resolve(process.cwd(), "..", "..", "ops", "frozen-cc-promote-patch.json");
}

function buildPromotePatchDraft(verdict: FrozenCcPromoteVerdict): PromotePatchDraft {
  const promoteHard = verdict.gates
    .filter((g) => g.verdict === "PROMOTE_HARD" && g.observeOnly !== true)
    .map((g) => g.gate);
  const keepOut = verdict.gates.filter((g) => g.verdict === "KEEP_OUT").map((g) => g.gate);
  const applyable = verdict.readyToPromote === true;
  return {
    kind: "frozen-cc-promote-patch-v1",
    confirmPhrase: APPLY_FROZEN_PROMOTE_PHRASE,
    generatedAt: verdict.generatedAt,
    tier: verdict.tier,
    scoreboardLabel: verdict.scoreboardLabel,
    closes: verdict.closes,
    settledN: verdict.settledN,
    goNoGo: verdict.goNoGo,
    readyToPromote: verdict.readyToPromote,
    status: applyable ? "ready" : "draft",
    applyable,
    actions: {
      frozenCcMode: false,
      askDoorMin: 20,
      askDoorMax: 55,
      restorePathRide: true,
      restoreLagMoneyMakers: true,
      promoteHardGates: applyable ? verdict.shadowShortlist.map((g) => g.gate) : promoteHard,
      keepOutShadow: keepOut,
      paperMode: true,
      keepEvFloorCents: PROMOTE_EV_FLOOR_CENTS_MIN,
      keepKelly: true,
    },
    note: applyable
      ? `Human must run scripts/frozen-cc-apply-promote.ts with confirm ${APPLY_FROZEN_PROMOTE_PHRASE}. Does not silently rewrite live PATH_RIDE.`
      : `DRAFT only (${verdict.scoreboardLabel}) — refuse apply until GO on unique N + ${APPLY_FROZEN_PROMOTE_PHRASE}.`,
  };
}

/** Auto-write verdict (+ draft/ready/blocked patch). Never mutates live config. Never applies. */
export function maybeWritePromoteArtifacts(rows: FrozenLedgerRow[]): FrozenCcPromoteVerdict {
  const verdict = computePromoteVerdict(rows);
  try {
    fs.mkdirSync(path.dirname(promoteVerdictPath()), { recursive: true });
    fs.writeFileSync(promoteVerdictPath(), JSON.stringify(verdict, null, 2) + "\n");
    // Always rewrite patch artifact so spam-era ready patches cannot linger.
    // n<40 → blocked stub; candidate → draft; GO → ready. Apply still gated.
    const patch = buildPromotePatchDraft(verdict);
    if (verdict.settledN < FROZEN_CC_N_ACTIONABLE && !verdict.readyToPromote) {
      patch.status = "draft";
      patch.applyable = false;
      patch.readyToPromote = false;
      patch.note =
        `BLOCKED (${verdict.scoreboardLabel} ${verdict.settledN}/${FROZEN_CC_N_ACTIONABLE}) — refuse apply until GO + ${APPLY_FROZEN_PROMOTE_PHRASE}.`;
    }
    const patchFile = path.resolve(process.cwd(), "data", "frozen-cc-promote-patch.json");
    const opsPatch = path.resolve(process.cwd(), "..", "..", "ops", "frozen-cc-promote-patch.json");
    fs.writeFileSync(patchFile, JSON.stringify(patch, null, 2) + "\n");
    try {
      fs.mkdirSync(path.dirname(opsPatch), { recursive: true });
      fs.writeFileSync(opsPatch, JSON.stringify(patch, null, 2) + "\n");
    } catch { /* ops optional */ }
  } catch {
    // measurement must never take the bot down
  }
  return verdict;
}
