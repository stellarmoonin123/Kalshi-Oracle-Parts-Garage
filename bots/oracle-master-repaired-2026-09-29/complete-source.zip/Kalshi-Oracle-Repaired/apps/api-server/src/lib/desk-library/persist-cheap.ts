/**
 * persist-cheap.ts — settlement book, shadow.
 *
 * Cheap 19–22¢ (band inclusive), 2–12m, evaluate fair-agree persist ≥60s,
 * HA not fighting if provided. Hold-to-settlement default.
 *
 * Reuses cheap-side-15m (2–12m window + cheapSideWinRate), settlement-side
 * (one side, MTF veto), hold-sell (HOLD_SETTLE default). Does not duplicate them.
 *
 * paperMode true. autoMode false. LIVE_APPLY false.
 * Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR.
 */
import {
  cheapSideWinRate,
  isCheapSideMidWindow,
} from "../cheap-side-15m.js";
import { decideSettlementSide } from "../settlement-side.js";
import { decideHoldOrSell, type HoldSellAction, type HoldSellInput } from "../hold-sell.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;

/** HOW_TO_TRADE cell (A). Inclusive. */
export const PERSIST_CHEAP_ASK_MIN_CENTS = 19;
export const PERSIST_CHEAP_ASK_MAX_CENTS = 22;
/** Evaluate fair-agree persist. Do not cut. */
export const PERSIST_CHEAP_MIN_MS = 60_000;
export const PERSIST_CHEAP_HOLD_DEFAULT: HoldSellAction = "HOLD_SETTLE";

export type PersistCheapHa = {
  color: "green" | "red";
  consecutive?: number;
};

export type PersistCheapOpts = {
  side: "yes" | "no";
  askCents: number;
  secsRemaining: number;
  /** Consecutive ms evaluate fair has agreed with this side of the floor. */
  msFairAgree: number;
  mtf?: number;
  /** If omitted, HA is not provided → not fighting. */
  ha?: PersistCheapHa | null;
  /** winRateAtPrice. Never confidence. If omitted, cheapSideWinRate is used. */
  pWin?: number | null;
  floor?: number | null;
  projectedSettlement?: number | null;
};

export type PersistCheapDecision = {
  take: boolean;
  reason: string;
  holdDefault: HoldSellAction;
};

function skip(reason: string): PersistCheapDecision {
  return { take: false, reason, holdDefault: PERSIST_CHEAP_HOLD_DEFAULT };
}

export function isPersistCheapAsk(ask: number): boolean {
  return Number.isFinite(ask)
    && ask >= PERSIST_CHEAP_ASK_MIN_CENTS
    && ask <= PERSIST_CHEAP_ASK_MAX_CENTS;
}

/** YES + red HA, or NO + green HA. Missing HA is not fighting. */
export function haFightsSide(side: "yes" | "no", ha?: PersistCheapHa | null): boolean {
  if (!ha) return false;
  if (side === "yes" && ha.color === "red") return true;
  if (side === "no" && ha.color === "green") return true;
  return false;
}

function fairAgrees(side: "yes" | "no", floor?: number | null, proj?: number | null): boolean | null {
  if (!(typeof floor === "number" && floor > 0)) return null;
  if (!(typeof proj === "number" && proj > 0)) return null;
  return side === "yes" ? proj > floor : proj < floor;
}

/**
 * Hold-to-settlement default for this predicate. Reuses decideHoldOrSell
 * without tagging CHEAP_SIDE_15M (that id is sell-before-expiry exempt).
 */
export function persistCheapHold(
  input: Omit<HoldSellInput, "strategyId"> & { strategyId?: string },
) {
  return decideHoldOrSell({
    ...input,
    strategyId: input.strategyId ?? "PERSIST_CHEAP",
  });
}

/**
 * Shadow predicate. Caller passes already-measured persist ms.
 * Does not size, place, or mutate BotConfig.
 */
export function shouldPersistCheapTake(opts: PersistCheapOpts): PersistCheapDecision {
  if (LIVE_APPLY || LIVE_APPLY_ENABLED) {
    return skip("live_apply_refused");
  }
  if (!isPersistCheapAsk(opts.askCents)) {
    return skip("ask_not_19_22");
  }
  const minLeft = opts.secsRemaining / 60;
  if (!isCheapSideMidWindow(minLeft)) {
    return skip("window");
  }
  if (!(opts.msFairAgree >= PERSIST_CHEAP_MIN_MS)) {
    return skip("persist_lt_60s");
  }
  const agreed = fairAgrees(opts.side, opts.floor, opts.projectedSettlement);
  if (agreed === false) {
    return skip("fair_disagree");
  }
  if (haFightsSide(opts.side, opts.ha)) {
    return skip("ha_fighting");
  }

  const wr = opts.pWin != null && Number.isFinite(opts.pWin)
    ? opts.pWin
    : cheapSideWinRate(opts.askCents, minLeft);
  const sideDecision = decideSettlementSide({
    pYes: opts.side === "yes" ? wr : null,
    pNo: opts.side === "no" ? wr : null,
    mtf: opts.mtf ?? 0,
  });
  if (sideDecision.side === "skip") {
    return skip(sideDecision.reason);
  }
  if (sideDecision.side !== opts.side) {
    return skip("side_mismatch");
  }

  return { take: true, reason: "persist_cheap", holdDefault: PERSIST_CHEAP_HOLD_DEFAULT };
}
