/**
 * online-adapter.ts
 *
 * Slow, sample-size-aware confidence/size adaptation from the sim_verdicts
 * learning table. Runs on an hourly schedule (see src/index.ts), not per
 * tick — this is a background sweep, never called from the live decision
 * path directly.
 *
 * Scope is intentionally narrow: this ONLY writes confMultiplier /
 * sizeMultiplier onto strategy_performance rows via
 * setStrategyMultipliers() + a direct DB update. It never touches the
 * `enabled` flag — that is refreshStrategyPerformance()'s job alone. Keeping
 * exactly one function (isStrategyEnabledSync, backed by
 * refreshStrategyPerformance) responsible for enablement avoids recreating
 * the dual-decision-maker problem this migration was meant to fix.
 */
import { db, simVerdicts, strategyPerformance } from "@workspace/db";
import { and, gte, isNotNull, eq } from "drizzle-orm";
import { logger } from "./logger.js";
import { setStrategyMultipliers } from "./strategy-performance.js";
import { adaptiveTuningLog } from "./adaptive-tuning-log.js";

const LOOKBACK_MS  = 14 * 24 * 60 * 60 * 1000; // 14 days
const MIN_SAMPLES   = 40;
const ADAPT_RATE     = 0.08; // slow EMA — a single hourly run can't swing the multiplier far
const CONF_MIN = 0.7,  CONF_MAX = 1.25;
const SIZE_MIN = 0.85, SIZE_MAX = 1.10; // narrower band — size affects live risk more directly than confidence

export async function adaptFromRecentVerdicts(): Promise<void> {
  const since = new Date(Date.now() - LOOKBACK_MS);

  const rows = await db
    .select({
      strategyId:  simVerdicts.strategyId,
      simWasRight: simVerdicts.simWasRight,
      confidence:  simVerdicts.confidence,
    })
    .from(simVerdicts)
    .where(and(
      gte(simVerdicts.createdAt, since),
      isNotNull(simVerdicts.simWasRight),
      isNotNull(simVerdicts.strategyId),
    ));

  const byStrategy = new Map<string, { right: number; total: number }>();
  for (const r of rows) {
    if (!r.strategyId) continue;
    const s = byStrategy.get(r.strategyId) ?? { right: 0, total: 0 };
    s.total++;
    if (r.simWasRight) s.right++;
    byStrategy.set(r.strategyId, s);
  }

  for (const [strategyId, stats] of byStrategy) {
    if (stats.total < MIN_SAMPLES) continue;

    const hitRate = stats.right / stats.total;
    const confTarget = Math.max(CONF_MIN, Math.min(CONF_MAX, 1.0 + (hitRate - 0.55) * 1.5));
    const sizeTarget = Math.max(SIZE_MIN, Math.min(SIZE_MAX, 1.0 + (hitRate - 0.55) * 0.75));

    const current = await db
      .select({ conf: strategyPerformance.confMultiplier, size: strategyPerformance.sizeMultiplier })
      .from(strategyPerformance)
      .where(eq(strategyPerformance.strategyId, strategyId))
      .limit(1);

    const prevConf = current[0]?.conf ?? 1.0;
    const prevSize = current[0]?.size ?? 1.0;
    const nextConf = Math.round((prevConf * (1 - ADAPT_RATE) + confTarget * ADAPT_RATE) * 1000) / 1000;
    const nextSize = Math.round((prevSize * (1 - ADAPT_RATE) + sizeTarget * ADAPT_RATE) * 1000) / 1000;

    // strategy_performance may not have a row yet if this strategy has no
    // settled bot_trades — insert a neutral enabled row so the multiplier
    // has somewhere to live; refreshStrategyPerformance() will fill in the
    // real trade stats the next time this strategy settles a trade.
    await db.insert(strategyPerformance)
      .values({ strategyId, confMultiplier: nextConf, sizeMultiplier: nextSize, lastAdaptedAt: new Date(), updatedAt: new Date() })
      .onConflictDoUpdate({
        target: strategyPerformance.strategyId,
        set: { confMultiplier: nextConf, sizeMultiplier: nextSize, lastAdaptedAt: new Date(), updatedAt: new Date() },
      });

    setStrategyMultipliers(strategyId, nextConf, nextSize);

    logger.info({ strategyId, hitRate, samples: stats.total, prevConf, nextConf, prevSize, nextSize }, "[online-adapter] multipliers updated");

    // Phase 1 observability (adaptive-control-plan.md): log online-adapter's
    // baseline as-is today, pre-refactor. Fire-and-forget — must never break
    // the hourly sweep.
    const reason = `hitRate=${(hitRate * 100).toFixed(1)}% over ${stats.total} samples (14d)`;
    void Promise.all([
      adaptiveTuningLog.recordChange({
        parameter: `confMultiplier:${strategyId}`, owner: "online-adapter", role: "baseline",
        newValue: nextConf, band: [CONF_MIN, CONF_MAX], signal: "wilson", reason,
      }),
      adaptiveTuningLog.recordChange({
        parameter: `sizeMultiplier:${strategyId}`, owner: "online-adapter", role: "baseline",
        newValue: nextSize, band: [SIZE_MIN, SIZE_MAX], signal: "wilson", reason,
      }),
    ]).catch(() => {});
  }
}
