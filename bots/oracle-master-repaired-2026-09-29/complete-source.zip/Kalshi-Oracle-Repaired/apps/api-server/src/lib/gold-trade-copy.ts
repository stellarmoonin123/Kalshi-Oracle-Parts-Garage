/**
 * gold-trade-copy — copy Replit winning trade *shapes* when they reappear.
 *
 * "Learn from trade history" = take the same cells (strategy/side/ask band)
 * that printed fee-net on the settled live book — not only abstract gate patches.
 *
 * Does NOT fill without EV≥3. Does NOT cut Kelly/floors. Does NOT ENABLE junk.
 * Does NOT flip paperMode. Fill-power lock: aligned TAKE band is 28–55 / LAG≥10
 * / still-mid always blocks — gold cells 56–62 or LAG 48–52 may still match for
 * logging/tags but alignedTakeGate must not TAKE them.
 * Tags never widen CC/LAG evaluate time windows (hard max 15m is the floor-safe
 * fill-power open; preferred LAG 3–10 + large-edge override stays).
 * Caller lock: strategy-library CC/LAG maxTimeMins MUST equal module hard max
 * (evaluateAllStrategies filters metadata BEFORE evaluate — stale 11/13 starved
 * gold 14–15m while direct evaluate still fired).
 */
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

export type GoldStrategyId = "CONFLUENCE_CASCADE" | "BASIS_LAG_EDGE";
export type GoldSide = "yes" | "no";
export type GoldPreferredExit = "HIGH_ODDS" | "PATH_RIDE";

export type GoldCell = {
  cellId: string;
  strategyId: GoldStrategyId;
  side: GoldSide;
  askMin: number;
  askMax: number;
  preferredExit: GoldPreferredExit;
  feeNetSampleUsd: number;
  nSample: number;
  winN?: number;
  toxic?: boolean;
  exampleAsks?: number[];
  exampleTradeIds?: string[];
};

export type GoldCellsFile = {
  asOf: string;
  source: string;
  note?: string;
  cells: GoldCell[];
};

export type GoldMatchObs = {
  strategyId?: string | null;
  side?: GoldSide | null;
  /** Ask for the candidate side (preferred). */
  ask?: number | null;
  yesAsk?: number | null;
  noAsk?: number | null;
  lagProven?: boolean;
};

export type GoldMatchResult = {
  match: boolean;
  cellId?: string;
  reason: string;
  cell?: GoldCell;
};

const HERE = dirname(fileURLToPath(import.meta.url));
const DEFAULT_CELLS_PATH = join(HERE, "replit-gold-cells.json");

let cached: GoldCell[] | null = null;

export function loadGoldCells(path: string = DEFAULT_CELLS_PATH): GoldCell[] {
  if (cached && path === DEFAULT_CELLS_PATH) return cached;
  try {
    const raw = JSON.parse(readFileSync(path, "utf8")) as GoldCellsFile;
    const cells = Array.isArray(raw.cells) ? raw.cells : [];
    if (path === DEFAULT_CELLS_PATH) cached = cells;
    return cells;
  } catch (err) {
    // Missing/unreadable on Fly image or fresh checkout — degrade soft (empty cells).
    const msg = err instanceof Error ? err.message : String(err);
    console.warn(`[gold-trade-copy] loadGoldCells failed (${path}): ${msg}`);
    if (path === DEFAULT_CELLS_PATH) cached = [];
    return [];
  }
}

/** Test / hot-reload helper. */
export function resetGoldCellsCache(): void {
  cached = null;
}

function askForSide(obs: GoldMatchObs, side: GoldSide): number | null {
  if (typeof obs.ask === "number" && Number.isFinite(obs.ask)) return obs.ask;
  const fromSide = side === "yes" ? obs.yesAsk : obs.noAsk;
  if (typeof fromSide === "number" && Number.isFinite(fromSide)) return fromSide;
  return null;
}

function inBand(ask: number, cell: GoldCell): boolean {
  return ask >= cell.askMin && ask <= cell.askMax;
}

/**
 * Match observation to a non-toxic Replit gold cell.
 * Prefer higher feeNetSampleUsd when multiple cells overlap (e.g. 48–50 in
 * both LAG_YES_42_50 and LAG_YES_48_52 → pick richer sample).
 */
export function matchGoldCell(
  obs: GoldMatchObs,
  cells: GoldCell[] = loadGoldCells(),
): GoldMatchResult {
  const side = obs.side ?? null;
  if (side !== "yes" && side !== "no") {
    return { match: false, reason: "side_missing" };
  }
  const ask = askForSide(obs, side);
  if (ask == null) return { match: false, reason: "ask_missing" };

  // Explicit toxic anti-cell: LAG cheap &lt;42 — never gold-copy.
  const toxicHit = cells.find(
    (c) =>
      c.toxic === true
      && c.strategyId === "BASIS_LAG_EDGE"
      && (obs.strategyId == null || obs.strategyId === c.strategyId)
      && (c.side === side)
      && inBand(ask, c),
  );
  if (toxicHit) {
    return {
      match: false,
      cellId: toxicHit.cellId,
      reason: "toxic_anti_cell",
      cell: toxicHit,
    };
  }

  const candidates = cells.filter((c) => {
    if (c.toxic === true) return false;
    if (c.side !== side) return false;
    if (!inBand(ask, c)) return false;
    if (obs.strategyId != null && obs.strategyId !== "" && obs.strategyId !== c.strategyId) {
      return false;
    }
    // LAG gold requires lagProven when strategy is LAG or unspecified preferring LAG cell.
    if (c.strategyId === "BASIS_LAG_EDGE" && obs.lagProven !== true) {
      return false;
    }
    return true;
  });

  if (candidates.length === 0) {
    return { match: false, reason: "no_gold_cell" };
  }

  candidates.sort((a, b) => b.feeNetSampleUsd - a.feeNetSampleUsd);
  const best = candidates[0]!;
  return {
    match: true,
    cellId: best.cellId,
    reason: `gold_cell:${best.cellId}`,
    cell: best,
  };
}

/** Prefer gold strategy when both CC and LAG could fire on the same ask. */
export function preferGoldStrategyId(
  obs: GoldMatchObs,
  cells: GoldCell[] = loadGoldCells(),
): GoldStrategyId | null {
  const m = matchGoldCell(obs, cells);
  if (!m.match || !m.cell) return null;
  return m.cell.strategyId;
}
