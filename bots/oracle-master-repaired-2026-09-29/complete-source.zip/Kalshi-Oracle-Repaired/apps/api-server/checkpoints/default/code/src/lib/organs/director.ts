/**
 * director — types + money-path compose. TradingBot remains ONE director.
 * Organs never ENABLE engines or cut EV 3¢ / Kelly 0.60 / 9% / PATH_GATE.
 * paperMode is not flipped here.
 */
import type { StrategyObservation, StrategyResult } from "../strategy-library.js";
import { snapshotTape, type TapeSnapshot, type TapeInput } from "./tape.js";
import { evaluateSide, pickOneSide, type SideDecision, type SideOrSkip } from "./side.js";
import { pForStrategyAtAsk, fillPathPWin } from "./probability.js";
import { evaluateEdge } from "./edge.js";
import { pathPWinFromCurveOrLearner, getLearnerPathWinRateSample } from "../strategy-learner.js";
import { getLiveTradeStatsSync } from "../strategy-performance.js";
import { isMoneyMakerStrategyId } from "../settlement-side.js";
import { isHardNoFillStrategy } from "../hard-no-fill.js";
import { inDeskAskBand } from "../paper-desk-v2.js";
import { inStillMidCoinFlip, STILL_MID_UNCLEAR_SKIP } from "../aligned-take-gate.js";
import { sizePathRide } from "./size.js";
import { tagPaperFill } from "./fill.js";
import { bookImbGate } from "./book-gate.js";
import { planMakerEntry } from "./maker.js";
import { decideExit } from "./exit.js";
import { EV_FLOOR } from "../admission.js";
import {
  stampAdmissionMsg,
  type AdmissionMsg,
} from "./brain-stamps.js";

export type OrganAction = "skip" | "take";

export type OrganReport = {
  action: OrganAction;
  side: SideOrSkip;
  p: number | null;
  ev: number | null;
  size: number;
  reason: string;
  strategyId: string | null;
  pathRide: boolean;
  exitBook: "PATH_RIDE" | undefined;
  /** Ask ¢ at decideMoneyPath TAKE — identity stamp for organTake (F2). */
  askCents: number | null;
  /** Unified AdmissionMsg — soleAuthority + decision + advisory under frozen. */
  admission?: AdmissionMsg;
};

export type MoneyPathInput = {
  obs: StrategyObservation;
  /** If passed, side organ uses these instead of re-evaluating CC/LAG/HA. */
  results?: StrategyResult[];
  paperMode: boolean;
  equityCents: number;
  todayPnlCents?: number;
  tape?: TapeInput;
  haRiverCcLagAgree?: boolean;
  desiredContracts?: number;
  chosenAskSize?: number | null;
  /** When true, admission stamp marks organ as advisoryParallel (frozen sole). */
  frozenCcMode?: boolean;
};

function skipReport(
  reason: string,
  extra?: Partial<OrganReport>,
  frozenCcMode?: boolean,
): OrganReport {
  const base: OrganReport = {
    action: "skip",
    side: extra?.side ?? "skip",
    p: extra?.p ?? null,
    ev: extra?.ev ?? null,
    size: 0,
    reason,
    strategyId: extra?.strategyId ?? null,
    pathRide: extra?.pathRide ?? false,
    exitBook: extra?.exitBook,
    askCents: extra?.askCents ?? null,
  };
  base.admission = stampAdmissionMsg({ report: base, frozenCcMode });
  return base;
}

function askForSide(obs: StrategyObservation, side: "yes" | "no"): number | null {
  const ask = side === "yes" ? obs.yesAsk : obs.noAsk;
  return typeof ask === "number" && Number.isFinite(ask) ? ask : null;
}

/**
 * Money path: tape → side → HARD_NO_FILL / desk door 20–55 → p=winRateAtPrice
 * → EV 3¢ → Kelly/9%/2–4% → fill tag.
 * Organs talk; this function reports. TradingBot decides whether to place.
 * Honesty: never action=take unless placeable (CC|LAG, in-band ask, not leftover).
 */
export function decideMoneyPath(input: MoneyPathInput): OrganReport {
  const frozen = input.frozenCcMode === true;
  const sideDec: SideDecision = input.results
    ? pickOneSide(input.results)
    : evaluateSide(input.obs);
  if (sideDec.side === "skip") {
    return skipReport(sideDec.reason, { strategyId: sideDec.strategyId }, frozen);
  }
  const side = sideDec.side;
  const strategyId = sideDec.strategyId;
  // Honesty: leftover HARD_NO_FILL never logs/paints take (cannot placeOrder).
  if (isHardNoFillStrategy(strategyId)) {
    return skipReport("HARD_NO_FILL", { side, strategyId }, frozen);
  }
  const ask = askForSide(input.obs, side);
  // Align organs take with W2 / desk door — never take out-of-band or still-mid.
  if (ask != null && inStillMidCoinFlip(ask)) {
    return skipReport(STILL_MID_UNCLEAR_SKIP, { side, strategyId }, frozen);
  }
  if (ask == null || !inDeskAskBand(side, ask)) {
    return skipReport("ask_out_of_band", { side, strategyId }, frozen);
  }
  const minutesLeft = (input.obs.secsRemaining ?? 0) / 60;
  const curveP = fillPathPWin(pForStrategyAtAsk(strategyId, ask, minutesLeft));
  const learnerSample = strategyId && isMoneyMakerStrategyId(strategyId)
    ? getLearnerPathWinRateSample(strategyId)
    : null;
  const p = learnerSample && strategyId
    ? pathPWinFromCurveOrLearner({
        curveP,
        learnerWR: learnerSample.winRate,
        learnerN: learnerSample.n,
        paperMode: input.paperMode,
        realBotSettlesN: getLiveTradeStatsSync(strategyId, 15).n,
      })
    : curveP;
  if (p == null || ask == null) {
    return skipReport("p_null", { side, strategyId, p: null }, frozen);
  }
  const edge = evaluateEdge({
    entryPriceCents: ask,
    pWin: p,
    strategyId: strategyId ?? undefined,
    secsRemaining: input.obs.secsRemaining,
    velocityDolPerMin: input.obs.velocityDolPerMin,
    spreadCents: (() => {
      const bid = side === "yes" ? input.obs.yesBid : input.obs.noBid;
      if (typeof bid === "number" && Number.isFinite(bid)) return ask - bid;
      return undefined;
    })(),
  });
  if (!edge.take) {
    return skipReport(edge.reason, { side, strategyId, p, ev: edge.ev }, frozen);
  }
  if (edge.ev == null || !(edge.ev >= EV_FLOOR)) {
    return skipReport("ev_below_floor", { side, strategyId, p, ev: edge.ev }, frozen);
  }
  const sized = sizePathRide({
    strategyId,
    paperMode: input.paperMode,
    equityCents: input.equityCents,
    entryCents: ask,
    contracts: input.desiredContracts ?? 99,
    netEV: edge.ev, // fee-net ticket EV — never dummy EV_FLOOR (that pins 2%)
    pWin: p,
    todayPnlCents: input.todayPnlCents,
    haRiverCcLagAgree: input.haRiverCcLagAgree,
  });
  if (sized.skipped) {
    return skipReport(sized.reason, { side, strategyId, p, ev: edge.ev }, frozen);
  }
  const imb = bookImbGate({ ourSize: sized.contracts, chosenAskSize: input.chosenAskSize });
  if (imb.action === "SKIP") {
    return skipReport("BOOK_IMB_GATE", { side, strategyId, p, ev: edge.ev }, frozen);
  }
  const n = imb.size;
  planMakerEntry({
    paperMode: input.paperMode,
    strategyId,
    side,
    bothSides: false,
    ev: edge.ev,
    yesAsk: input.obs.yesAsk,
    noAsk: input.obs.noAsk,
    yesBid: input.obs.yesBid,
    noBid: input.obs.noBid,
    secsRemaining: input.obs.secsRemaining,
  });
  const tagged = tagPaperFill(strategyId);
  const takeReport: OrganReport = {
    action: "take",
    side,
    p,
    ev: edge.ev,
    size: n,
    reason: sideDec.reason,
    strategyId,
    pathRide: tagged.pathRide,
    exitBook: tagged.exitBook,
    askCents: ask,
  };
  takeReport.admission = stampAdmissionMsg({ report: takeReport, frozenCcMode: frozen });
  return takeReport;
}

/**
 * Non-frozen placeOrder take authority (P1 + F2 identity).
 * When frozenCcMode is TRUE this gate never fires — FROZEN_CC_SOLE_TAKE
 * (frozenCc:true from decideFrozenCcEntry) remains the sole frozen stamp.
 * When frozenCcMode is FALSE, placeOrder requires an identity-matched organ
 * take: lastOrganReport.action==="take" AND same strategyId AND same side
 * AND ask within 1¢ (or an explicit organTake stamp already computed that way).
 * Bare action==="take" without identity is NOT enough (Attack A2 rubber-stamp).
 * Does not cut EV/Kelly/door floors, flip paperMode, or ENABLE leftovers.
 */
export const DIRECTOR_TAKE_REQUIRED = "DIRECTOR_TAKE_REQUIRED" as const;
/** Ask tolerance ¢ for organTake identity (F2). */
export const ORGAN_TAKE_ASK_TOL_CENTS = 1;

export function formatDirectorTakeRequiredDesc(strategyId: string): string {
  return (
    `⛔ ${DIRECTOR_TAKE_REQUIRED} ${strategyId} — placeOrder blocked ` +
    `(non-frozen requires decideMoneyPath take + strategyId/side/ask±1¢ identity)`
  );
}

/**
 * F2: organTake identity — take + same strategyId + same side + ask within tol.
 * Pure. Frozen callers must not use this to starve FROZEN_CC_SOLE_TAKE.
 */
export function organTakeIdentityMatches(opts: {
  report: Pick<OrganReport, "action" | "strategyId" | "side" | "askCents"> | null | undefined;
  strategyId: string;
  side: "yes" | "no";
  askCents: number;
  tolCents?: number;
}): boolean {
  const r = opts.report;
  if (!r || r.action !== "take") return false;
  if (r.strategyId !== opts.strategyId) return false;
  if (r.side !== opts.side) return false;
  const organAsk = r.askCents;
  if (typeof organAsk !== "number" || !Number.isFinite(organAsk)) return false;
  if (!Number.isFinite(opts.askCents)) return false;
  const tol = opts.tolCents ?? ORGAN_TAKE_ASK_TOL_CENTS;
  return Math.abs(organAsk - opts.askCents) <= tol;
}

/** Compute placeOrder organTake stamp from lastOrganReport (identity-aware). */
export function stampOrganTakeFromReport(opts: {
  report: OrganReport | null | undefined;
  strategyId: string;
  side: "yes" | "no";
  askCents: number;
}): boolean {
  return organTakeIdentityMatches(opts);
}


/** F-B1: frozen sole TAKE = decideFrozenCcEntry; organ take must not mutate live model prob. */
export const FROZEN_ORGANS_ADVISORY = "FROZEN_ORGANS_ADVISORY" as const;

/** GG#2 / P0#2: PATH_RIDE decideMoneyPath skip must hard-return (any reason). */
export function pathRideOrganSkipBlocksEvaluate(
  report: Pick<OrganReport, "action" | "reason">,
): { block: true; reason: string } | { block: false } {
  if (report.action === "skip") {
    return { block: true, reason: report.reason };
  }
  return { block: false };
}

/** F-B1: write lastModelProb from organ take only when not frozen. */
export function shouldWriteOrganTakeModelProb(opts: {
  frozenCcMode: boolean | undefined;
  action: OrganAction;
}): boolean {
  return opts.frozenCcMode !== true && opts.action === "take";
}

/** GG#3 / P0#3: organ TAKE must own result.best identity (strategyId/side/ask±1¢). */
export const ORGAN_BEST_MISMATCH = "ORGAN_BEST_MISMATCH" as const;

export type OrganBestRow = {
  strategyId: string;
  signal: string;
};

/**
 * Force best to the organ take identity, rematching from `all` when needed.
 * Mismatched / ask-drifted → ORGAN_BEST_MISMATCH (caller empties evaluate).
 */
export function resolveOrganBestOrMismatch<T extends OrganBestRow>(opts: {
  report: Pick<OrganReport, "action" | "strategyId" | "side" | "askCents">;
  best: T | null | undefined;
  all: readonly T[];
  yesAsk?: number | null;
  noAsk?: number | null;
}): { ok: true; best: T } | { ok: false; reason: typeof ORGAN_BEST_MISMATCH } {
  const r = opts.report;
  if (r.action !== "take" || (r.side !== "yes" && r.side !== "no") || !r.strategyId) {
    return { ok: false, reason: ORGAN_BEST_MISMATCH };
  }
  const side = r.side;
  const wantSignal = side === "yes" ? "YES" : "NO";
  const rawAsk = side === "yes" ? opts.yesAsk : opts.noAsk;
  const askCents = typeof rawAsk === "number" && Number.isFinite(rawAsk) ? rawAsk : Number.NaN;

  const matches = (cand: T): boolean =>
    cand.signal === wantSignal
    && organTakeIdentityMatches({
      report: r,
      strategyId: cand.strategyId,
      side,
      askCents,
    });

  if (opts.best && matches(opts.best)) {
    return { ok: true, best: opts.best };
  }
  const forced = opts.all.find(
    (c) => c.strategyId === r.strategyId && c.signal === wantSignal,
  );
  if (forced && matches(forced)) {
    return { ok: true, best: forced };
  }
  return { ok: false, reason: ORGAN_BEST_MISMATCH };
}

export function shouldBlockPlaceOrderWithoutOrganTake(opts: {
  frozenCcMode: boolean | undefined;
  /** Explicit placeOrder stamp (must already be identity-true). Survives requote. */
  organTake?: boolean;
  /** lastOrganReport — used for live identity check when stamp absent. */
  organReport?: OrganReport | null;
  /** @deprecated bare action without identity — ignored for allow (F2). Kept for call-site compat. */
  organAction?: OrganAction | null;
  strategyId?: string;
  side?: "yes" | "no";
  askCents?: number;
}): boolean {
  if (opts.frozenCcMode === true) return false;
  if (opts.organTake === true) return false;
  if (
    opts.organReport
    && typeof opts.strategyId === "string"
    && (opts.side === "yes" || opts.side === "no")
    && typeof opts.askCents === "number"
  ) {
    return !organTakeIdentityMatches({
      report: opts.organReport,
      strategyId: opts.strategyId,
      side: opts.side,
      askCents: opts.askCents,
    });
  }
  // Fail-closed: bare organAction==="take" without identity does NOT allow.
  void opts.organAction;
  return true;
}

export function snapshotForDirector(tape: TapeInput): TapeSnapshot {
  return snapshotTape(tape);
}

export { decideExit, evaluateSide, pickOneSide, EV_FLOOR };
export type { AdmissionMsg };
