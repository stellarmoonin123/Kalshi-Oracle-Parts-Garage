/**
 * accounts/db.ts — the Postgres handle used by the account system and the
 * owner-scoped chat history. Defaults to the shared `pool` from
 * @workspace/db (lazy import, so pure helpers never require DATABASE_URL at
 * module load). Tests inject an isolated pool (own schema via search_path).
 */
export interface QueryResultLike<R = Record<string, unknown>> {
  rows: R[];
  rowCount: number | null;
}

export interface QueryClientLike {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  query<R = any>(text: string, params?: unknown[]): Promise<QueryResultLike<R>>;
}

export interface PoolClientLike extends QueryClientLike {
  release(err?: Error | boolean): void;
}

export interface AccountsPool extends QueryClientLike {
  connect(): Promise<PoolClientLike>;
}

let override: AccountsPool | null = null;

/** Test hook: route every accounts/chat query through `p` (null = default pool). */
export function setAccountsPool(p: AccountsPool | null): void {
  override = p;
}

export async function accountsPool(): Promise<AccountsPool> {
  if (override) return override;
  const mod = await import("@workspace/db");
  return mod.pool as unknown as AccountsPool;
}

/** Run `fn` inside a transaction on a dedicated client. */
export async function withTransaction<T>(fn: (c: QueryClientLike) => Promise<T>): Promise<T> {
  const pool = await accountsPool();
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const out = await fn(client);
    await client.query("COMMIT");
    return out;
  } catch (err) {
    try { await client.query("ROLLBACK"); } catch { /* connection already broken */ }
    throw err;
  } finally {
    client.release();
  }
}
