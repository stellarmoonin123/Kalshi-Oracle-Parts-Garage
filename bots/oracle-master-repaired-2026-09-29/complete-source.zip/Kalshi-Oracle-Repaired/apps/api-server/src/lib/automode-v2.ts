/**
 * automode-v2.ts
 *
 * GO — STEP 5 autoMode v2 PHASE A (SUGGEST ONLY), 2026-08-22 (task #469
 * reship). Pure compute for a NEW, independent auto-tuning concept — do not
 * confuse with the legacy `BotConfig.autoMode` boolean (the older "composer"
 * that takes condition-adapter's overlay as its own baseline when true; see
 * the "autoMode composer" block in trading-bot.ts's evaluateEntry()). v2
 * never reads or writes that path, and per the ACK spec must NOT restore the
 * old behavior of overriding the operator's minConfidence via Math.max /
 * full per-tick retune.
 *
 * Modes (BotConfig.autoModeV2Mode):
 *   'off'           — no compute at all.
 *   'suggest'       — compute + log a proposed minConfidence/sizeMult; ZERO
 *                     effect on any live gate. Shipped default for Phase A.
 *   'bounded_write' — a FUTURE phase. The actual bounded-write application
 *                     logic (clamped merge into the live entry gate) is
 *                     intentionally NOT implemented here — see the call site
 *                     in trading-bot.ts, which only ever logs a suggestion
 *                     regardless of this mode, until an explicit "PHASE B
 *                     ACK" ships the write path. Setting this value today
 *                     has no live effect.
 *
 * Documented (not-yet-applied) merge order for a future bounded_write phase:
 *   baseline → pack confBump/sizeCap → (auto only if bounded_write) →
 *   uMult × volume → EV
 * Phase A applies no auto write anywhere in that chain — this module's
 * output is observability-only.
 *
 * FORBIDDEN for this module, all phases (enforced by never touching these):
 *   - EV / PATH_GATE floors
 *   - specialistPacksMode or pack eligible lists
 *   - enabling/disabling strategies or clearing quarantine
 *   - maxContracts / portfolioRiskPct
 *   - the BASIS_LAG exemption
 *   - any admit effect while mode='suggest'
 */

import type { RegimeId } from "./regime-engine.js";
import type { VolumeBucket } from "./volume-risk.js";
import type { PackId } from "./specialist-packs.js";

export type AutoModeV2Mode = "off" | "suggest" | "bounded_write";

export interface AutoModeV2Suggestion {
  /** Proposed minConfidence. clamp(baseline + delta, 52, 68), delta in
   *  [0, +8] — tighten-biased only; Phase A never proposes below baseline. */
  proposedMinConf: number;
  /** Proposed position-size multiplier, clamped to [0.7, 1.0]. */
  proposedSizeMult: number;
  reason: string;
}

const MIN_CONF_FLOOR = 52;
const MIN_CONF_CEILING = 68;
const MAX_DELTA = 8;
const SIZE_MULT_FLOOR = 0.7;
const SIZE_MULT_CEILING = 1.0;

export interface AutoModeV2Inputs {
  /** Operator's own configured minConfidence — the baseline this Phase A
   *  suggestion is relative to. Never read or written as a live value here. */
  baselineMinConfidence: number;
  /** Sticky committed regime for this tick (same R_t packs/condition-adapter
   *  read), not an instantaneous/shadow reclassification. */
  regime: RegimeId;
  /** This tick's volume-risk bucket (computeVolumeScore(obs).bucket). */
  vBucket: VolumeBucket;
  /** The active specialist pack id for this tick, if any (getPack output). */
  packId: PackId | null;
}

/**
 * Pure function: given the sticky regime, volume bucket, and active pack,
 * proposes a tighter minConfidence and/or smaller size multiplier for thin,
 * unclear, or high-uncertainty conditions. Tighten-biased only — never
 * proposes loosening below the operator's own baseline in Phase A. Does not
 * read config, DB, or any mutable bot state — the caller is responsible for
 * gating on `autoModeV2Mode` and for logging (this module never logs).
 */
export function computeAutoModeV2Suggestion(inputs: AutoModeV2Inputs): AutoModeV2Suggestion {
  const { baselineMinConfidence, regime, vBucket, packId } = inputs;
  let delta = 0;
  let sizeMult = SIZE_MULT_CEILING;
  const reasons: string[] = [];

  // Thin/dead tape: real edges are rarer and more likely spurious. Tighten
  // confidence and shrink size together (same directional bias as LOW_VOL
  // pack's own sizeCapMult, computed independently here — never derived
  // from the pack's field so a future pack-tuning change can't silently
  // move this suggestion too).
  if (vBucket === "DEAD") {
    delta += 8;
    sizeMult = 0.7;
    reasons.push("DEAD volume");
  } else if (vBucket === "LOW") {
    delta += 5;
    sizeMult = 0.8;
    reasons.push("LOW volume");
  }

  // Regime uncertainty: 'unclear' has no committed directional read at all;
  // 'squeeze' is pre-breakout (direction not yet confirmed). Both warrant a
  // higher confidence bar independent of the volume-driven delta above.
  if (regime === "unclear") {
    delta += 3;
    reasons.push("unclear regime");
  } else if (regime === "squeeze") {
    delta += 2;
    reasons.push("squeeze regime (pre-breakout)");
  }

  // TRANSITION pack already implies a high-bar/defensive stance (per
  // specialist-packs.ts's own thesis) — nudge confidence up a little further
  // so the two signals agree instead of one contradicting the other.
  if (packId === "TRANSITION") {
    delta += 2;
    reasons.push("TRANSITION pack active");
  }

  delta = Math.min(delta, MAX_DELTA);
  sizeMult = Math.min(Math.max(sizeMult, SIZE_MULT_FLOOR), SIZE_MULT_CEILING);

  const proposedMinConf = Math.min(
    Math.max(baselineMinConfidence + delta, MIN_CONF_FLOOR),
    MIN_CONF_CEILING,
  );

  const reason = reasons.length > 0
    ? `${reasons.join(", ")} → +${delta} conf / ${sizeMult.toFixed(2)}x size (suggest-only)`
    : "normal conditions — no adjustment proposed (suggest-only)";

  return { proposedMinConf, proposedSizeMult: sizeMult, reason };
}
