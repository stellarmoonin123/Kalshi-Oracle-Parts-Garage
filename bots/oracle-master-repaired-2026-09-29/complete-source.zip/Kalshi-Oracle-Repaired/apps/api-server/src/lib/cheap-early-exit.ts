/**
 * QUARANTINE — cheap-early-exit.ts
 * DEAD_REMOVE candidate / leftover deny. OFF money-path placeOrder wire.
 * Shadow/replay imports may remain; HARD_NO_FILL + paper-release still block fills.
 * DO NOT ENABLE. DO NOT WIRE as a second entry law beside frozen six-gate / CC|LAG.
 *
 * --- original header follows ---
 */
/**
 * cheap-early-exit.ts — CHEAP_EARLY_EXIT (Stellar + Turbine buy-cheap-sell-green).
 *
 * Entry: cheaper of YES/NO ask in the stillCheap / intra-scalp band 7–55¢
 * (research/intra-scalp-replay-summary.json stillCheap n=57 fills=18 +92¢
 * with scalp exits). Side = whichever ask is cheap. Wrong settle OK.
 *
 * Exit (primary): sell when mark is green +20¢ (INTRA_GREEN_CENTS) or 2× /
 * thesis-break / lag-flip / 90s time-stop. NOT hold-to-settle.
 *
 * NOT eternal buy50/sell70. NOT persist-cheap 19–22 hold-to-settle (killed).
 * PAPER_SCALP velocity path stays HALTED.
 *
 * Dual-gated fail-closed: evaluate() returns null unless cheapEarlyExitEnabled
 * === true. LIVE_APPLY false. Default ENABLE false.
 */
import {
  INTRA_WINDOW_SECS_MAX,
  INTRA_WINDOW_SECS_MIN,
  mtfFightsSide,
} from "./intra-scalp-replay.js";
import { EV_FLOOR } from "./admission.js";
import { isDeadZone } from "./advice-observe.js";
import { cheapSideWinRate } from "./cheap-side-15m.js";
import { LOTTERY_ASK_MAX_CENTS, LOTTERY_ASK_MIN_CENTS, LOTTERY_LAST_SECS } from "./desk-library/skip.js";
import { isKxbct15mTicker } from "./15m-product.js";
import { liveLagSkipReason, SETTLEMENT_SIDE_QUOTE_STALE_MS } from "./settlement-side.js";
import { computeTradeEV } from "./trade-path.js";
import type { StrategyObservation, StrategyResult } from "./strategy-library.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;

/** 7–55¢ from stillCheap / intra-scalp research. Not invented 7–40 / 40–55 split. */
export const CHEAP_EARLY_ASK_MIN_CENTS = 7; // stillCheap / intra-scalp band
export const CHEAP_EARLY_ASK_MAX_CENTS = 55;
export const CHEAP_EARLY_GREEN_CENTS = 20;
export const CHEAP_EARLY_TIME_STOP_SECS = 90;
export const CHEAP_EARLY_STRATEGY_ID = "CHEAP_EARLY_EXIT" as const;

export const CHEAP_EARLY_EXIT_RULE =
  "Sell when mark is green +20¢ or 2× (min 99), or thesis-break / lag-flip / 90s left. Wrong settle can still be a WIN. Never HOLD_SETTLE.";

export function isCheapEarlyExitDualGateOpen(enabled: boolean | undefined): boolean {
  return enabled === true;
}

export function isCheapEarlyAsk(ask: number | undefined | null): boolean {
  return typeof ask === "number" && Number.isFinite(ask)
    && ask >= CHEAP_EARLY_ASK_MIN_CENTS && ask <= CHEAP_EARLY_ASK_MAX_CENTS;
}

export function cheapEarlyExitWinRate(entryPriceCents: number, minutesLeft: number): number {
  return cheapSideWinRate(entryPriceCents, minutesLeft);
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

function lotterySkip(ask: number, secs: number): boolean {
  return ask >= LOTTERY_ASK_MIN_CENTS && ask <= LOTTERY_ASK_MAX_CENTS && secs <= LOTTERY_LAST_SECS;
}

function pickCheapSide(yesAsk: number | undefined, noAsk: number | undefined): { side: "yes" | "no"; ask: number } | null {
  const yOk = isCheapEarlyAsk(yesAsk);
  const nOk = isCheapEarlyAsk(noAsk);
  if (yOk && nOk) {
    if (yesAsk! < noAsk!) return { side: "yes", ask: yesAsk! };
    if (noAsk! < yesAsk!) return { side: "no", ask: noAsk! };
    return null; // tie — never both
  }
  if (yOk) return { side: "yes", ask: yesAsk! };
  if (nOk) return { side: "no", ask: noAsk! };
  return null;
}

function paperLiveGates(obs: StrategyObservation, side: "yes" | "no"): string | null {
  if (obs.quoteAgeMs != null) {
    if (!Number.isFinite(obs.quoteAgeMs) || obs.quoteAgeMs > SETTLEMENT_SIDE_QUOTE_STALE_MS) {
      return "quote_stale";
    }
  }
  if (obs.lagStale !== undefined && obs.lagStale !== false) return "lag_stale";
  if (obs.lagStale === false) {
    const veto = liveLagSkipReason(side, obs.lagDollars);
    if (veto) return veto;
  }
  return null;
}

/**
 * Ungated signal (shadow / would-fire). Dual-gate is applied by evaluate().
 */
export function cheapEarlyExitSignal(obs: StrategyObservation): StrategyResult | null {
  if (LIVE_APPLY || LIVE_APPLY_ENABLED) return null;
  if ((obs.contractDurationMins ?? 15) !== 15) return null;
  if (obs.ticker && !isKxbct15mTicker(obs.ticker)) {
    const t = obs.ticker.toUpperCase();
    if (t.includes("KXBTCD") || t.includes("KXBTCH") || t.includes("PERP")) return null;
  }

  const secs = obs.secsRemaining;
  if (!Number.isFinite(secs)) return null;
  if (isDeadZone(secs)) return null;
  if (secs < INTRA_WINDOW_SECS_MIN || secs > INTRA_WINDOW_SECS_MAX) return null;

  const pick = pickCheapSide(obs.yesAsk, obs.noAsk);
  if (!pick) return null;
  if (lotterySkip(pick.ask, secs)) return null;
  if (mtfFightsSide(pick.side, obs.mtfScore ?? 0)) return null;

  const gate = paperLiveGates(obs, pick.side);
  if (gate) return null;

  const wr = cheapEarlyExitWinRate(pick.ask, secs / 60);
  const sideBid = pick.side === "yes" ? obs.yesBid : obs.noBid;
  const spreadCents = sideBid !== undefined ? pick.ask - sideBid : undefined;
  const ev = computeTradeEV({
    entryPriceCents: pick.ask,
    winRate: wr,
    strategyId: CHEAP_EARLY_STRATEGY_ID,
    secsRemaining: secs,
    velocityDolPerMin: obs.velocityDolPerMin,
    spreadCents,
  });
  if (!(ev.netEV >= EV_FLOOR) || ev.netEV <= 0) return null;

  const signal = pick.side === "yes" ? "YES" : "NO";
  const conf = clamp(0.55 + Math.min(0.12, (CHEAP_EARLY_ASK_MAX_CENTS - pick.ask) / 400), 0.55, 0.67);
  return {
    signal,
    confidence: conf,
    strategyId: CHEAP_EARLY_STRATEGY_ID,
    strategyName: "Cheap Early Exit",
    edgePct: ev.netEV / 100,
    reason: `CHEAP_EARLY_EXIT shadow ${signal} @ ${pick.ask}c band 7-55 sell-green +${CHEAP_EARLY_GREEN_CENTS}c (not hold-to-settle)`,
    earlyExitRule: CHEAP_EARLY_EXIT_RULE,
  };
}

export function evaluateCheapEarlyExit(obs: StrategyObservation): StrategyResult | null {
  if (!isCheapEarlyExitDualGateOpen(obs.cheapEarlyExitEnabled)) return null;
  return cheapEarlyExitSignal(obs);
}
