/**
 * accounts-bootstrap-admin.ts — create the FIRST Administrator (idempotent:
 * does nothing if any ADMIN already exists). The account must change its
 * password at first sign-in. The password is never printed or logged.
 *
 * Non-interactive (env):
 *   ORACLE_ADMIN_USERNAME=stellar ORACLE_ADMIN_EMAIL=me@example.com \
 *   ORACLE_ADMIN_PASSWORD='…' pnpm --filter @workspace/api-server run accounts:bootstrap-admin
 * Interactive: omit ORACLE_ADMIN_PASSWORD and you are prompted (input hidden).
 */
import readline from "node:readline";
import { Writable } from "node:stream";
import { bootstrapFirstAdmin } from "../src/lib/accounts/bootstrap.js";
import { runAccountsMigration } from "../src/lib/accounts/migrate.js";

function ask(question: string, hidden = false): Promise<string> {
  let muted = false;
  const out = new Writable({
    write(chunk, _enc, cb) { if (!muted) process.stdout.write(chunk); cb(); },
  });
  const rl = readline.createInterface({ input: process.stdin, output: out, terminal: true });
  return new Promise((resolve) => {
    rl.question(question, (answer) => { rl.close(); if (hidden) process.stdout.write("\n"); resolve(answer); });
    muted = hidden;
  });
}

try {
  const username = process.env.ORACLE_ADMIN_USERNAME?.trim() || (await ask("Admin username: ")).trim();
  const email = process.env.ORACLE_ADMIN_EMAIL?.trim() || (await ask("Admin email: ")).trim();
  const displayName = process.env.ORACLE_ADMIN_DISPLAY_NAME?.trim() || "Administrator";
  let password = process.env.ORACLE_ADMIN_PASSWORD ?? "";
  if (!password) {
    password = await ask("Temporary admin password (hidden): ", true);
    const again = await ask("Repeat password (hidden): ", true);
    if (password !== again) { console.error("Passwords do not match."); process.exit(1); }
  }
  const r = await bootstrapFirstAdmin({ username, email, password, displayName });
  if (r.created) {
    console.log(`Created first ADMIN "${r.username}" (id ${r.userId}). They must change the password at first sign-in.`);
    console.log(`Legacy conversations assigned to this ADMIN: ${r.legacyAssigned}`);
  } else {
    console.log("An ADMIN already exists — nothing changed.");
  }
  const m = await runAccountsMigration();
  console.log(`Unowned conversations remaining: ${m.unownedRemaining}`);
  process.exit(0);
} catch (err) {
  console.error("bootstrap failed:", (err as Error)?.message ?? err);
  process.exit(1);
}
