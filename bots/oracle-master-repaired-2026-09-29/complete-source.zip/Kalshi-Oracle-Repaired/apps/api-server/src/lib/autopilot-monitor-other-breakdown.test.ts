import { test } from "node:test";
import assert from "node:assert/strict";
import { formatTopRawCodes } from "./autopilot-monitor.js";
import { mapToClosedCode } from "./decision-trace.js";

test("OTHER skips are broken down by raw rejection code (FROZEN_* no longer opaque)", () => {
  assert.equal(mapToClosedCode("FROZEN_TIME_WINDOW"), "OTHER");
  assert.equal(
    formatTopRawCodes({ FROZEN_CC_NOT_FIRED: 8, FROZEN_TIME_WINDOW: 192, FROZEN_PRICE_BAND: 3, X: 1 }),
    "FROZEN_TIME_WINDOW=192, FROZEN_CC_NOT_FIRED=8, FROZEN_PRICE_BAND=3",
  );
  assert.equal(formatTopRawCodes(undefined), "");
  assert.equal(formatTopRawCodes({}), "");
});
