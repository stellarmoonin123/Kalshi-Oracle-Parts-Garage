import { test } from "node:test";
import assert from "node:assert/strict";
import {
  CooldownBook, completeWithFallback, classifyHttpError, parseRetryAfterMs, budgetMessages, userFacingRouteError,
  ChatRouteError, availableRoute, FREE_MODEL_ROUTE, estTokens, CONTEXT_TOKEN_BUDGET, type RouteModel,
  geminiContents, GEMINI_SKIP_SIGNATURE, callModelOnce,
} from "./chat-router.js";

const env = { GROQ_API_KEY: "g", GEMINI_API_KEY: "m" };
const ok = (text: string) => new Response(JSON.stringify({ choices: [{ message: { content: text } }] }), { status: 200 });
const gemOk = (text: string) => new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text }] } }] }), { status: 200 });
const noSleep = async () => {};

test("route: strongest free first; only keyed providers; OpenRouter only with a key and only :free", () => {
  const r = availableRoute(env);
  assert.equal(r[0]!.model, "openai/gpt-oss-120b");
  assert.ok(r.every((m) => m.provider !== "openrouter"));
  const withOr = availableRoute({ ...env, OPENROUTER_API_KEY: "o" });
  assert.ok(withOr.filter((m) => m.provider === "openrouter").every((m) => m.model.endsWith(":free")));
  assert.deepEqual(availableRoute({}), []);
  assert.ok(FREE_MODEL_ROUTE.every((m) => !/pro/.test(m.model)), "no paid-tier Gemini Pro in the free route");
});

test("fallback: 429 on Groq 120B → cooldown with Retry-After → next model answers", async () => {
  const calls: string[] = [];
  const fetchImpl = (async (url: string, init: any) => {
    const body = JSON.parse(init.body);
    calls.push(body.model ?? url);
    if (body.model === "openai/gpt-oss-120b") return new Response("rate limit", { status: 429, headers: { "retry-after": "42" } });
    if (String(url).includes("gemini-3.6-flash")) return gemOk("from gemini");
    return ok("x");
  }) as unknown as typeof fetch;
  const cd = new CooldownBook();
  const r = await completeWithFallback({ system: "s", messages: [{ role: "user", content: "hi" }], tools: [], env, cooldowns: cd, fetchImpl, sleepImpl: noSleep });
  assert.equal(r.model.model, "gemini-3.6-flash");
  assert.equal(r.out.text, "from gemini");
  const c = cd.isCooling(FREE_MODEL_ROUTE[0]!);
  assert.equal(c.cooling, true);
  assert.ok((c.untilMs ?? 0) - Date.now() > 35_000);
  // next turn skips the cooling model without calling it
  calls.length = 0;
  await completeWithFallback({ system: "s", messages: [{ role: "user", content: "hi" }], tools: [], env, cooldowns: cd, fetchImpl, sleepImpl: noSleep });
  assert.ok(!calls.includes("openai/gpt-oss-120b"));
});

test("OpenRouter 402 → whole provider paused 30 min (paid never retried)", async () => {
  const cd = new CooldownBook();
  const orModel: RouteModel = { provider: "openrouter", model: "openai/gpt-oss-120b:free", label: "or" };
  const fetchImpl = (async (url: string) => String(url).includes("openrouter")
    ? new Response('{"error":{"message":"Insufficient credits"}}', { status: 402 })
    : ok("groq ok")) as unknown as typeof fetch;
  const r = await completeWithFallback({ system: "s", messages: [{ role: "user", content: "q" }], tools: [], env: { OPENROUTER_API_KEY: "o", GROQ_API_KEY: "g" }, cooldowns: cd, fetchImpl, route: [orModel, FREE_MODEL_ROUTE[0]!], sleepImpl: noSleep });
  assert.equal(r.model.provider, "groq");
  const c = cd.isCooling({ provider: "openrouter", model: "anything:free", label: "" });
  assert.equal(c.cooling, true);
  assert.equal(c.kind, "payment_required");
  assert.ok((c.untilMs ?? 0) - Date.now() > 29 * 60_000);
});

test("timeout / 5xx: one backoff retry on the same model, then fall through", async () => {
  let n = 0;
  const fetchImpl = (async (url: string, init: any) => {
    const body = JSON.parse(init.body ?? "{}");
    if (body.model === "openai/gpt-oss-120b") { n++; return new Response("busy", { status: 503 }); }
    return ok("second");
  }) as unknown as typeof fetch;
  const sleeps: number[] = [];
  const r = await completeWithFallback({ system: "s", messages: [{ role: "user", content: "q" }], tools: [], env: { GROQ_API_KEY: "g" }, cooldowns: new CooldownBook(), fetchImpl, sleepImpl: async (ms) => { sleeps.push(ms); } });
  assert.equal(n, 2, "retried once");
  assert.equal(sleeps.length, 1);
  assert.equal(r.model.model, "qwen/qwen3.8-27b");
});

test("all fail → clear user-facing message (not a generic hiccup)", async () => {
  const cd = new CooldownBook();
  const fetchImpl = (async (url: string) => String(url).includes("generativelanguage")
    ? new Response('{"error":{"status":"RESOURCE_EXHAUSTED","message":"quota per day"}}', { status: 429 })
    : new Response("slow down", { status: 429, headers: { "retry-after": "12" } })) as unknown as typeof fetch;
  await assert.rejects(
    completeWithFallback({ system: "s", messages: [{ role: "user", content: "q" }], tools: [], env, cooldowns: cd, fetchImpl, sleepImpl: noSleep }),
    (e: unknown) => {
      assert.ok(e instanceof ChatRouteError);
      const msg = userFacingRouteError(e, cd);
      assert.match(msg, /rate-limited/);
      assert.match(msg, /daily quota/);
      assert.doesNotMatch(msg, /hiccup/i);
      return true;
    },
  );
  assert.match(userFacingRouteError(new ChatRouteError("no_keys", [], null), cd), /GROQ_API_KEY or GEMINI_API_KEY/);
});

test("classify + Retry-After parsing", () => {
  assert.equal(classifyHttpError(413, "Request too large", null).kind, "too_large");
  assert.equal(classifyHttpError(404, "", null).kind, "not_found");
  assert.equal(classifyHttpError(401, "", null).kind, "auth");
  assert.equal(parseRetryAfterMs("3", ""), 3000);
  assert.equal(parseRetryAfterMs(null, "Please try again in 7.5s."), 7500);
});

test("budget: keeps system + newest turns within the free-tier budget; last user turn always kept", () => {
  const big = "x".repeat(8_000);
  const turns = Array.from({ length: 30 }, (_, i) => ({ role: (i % 2 ? "assistant" : "user") as "user" | "assistant", content: `${i} ${big}` }));
  turns.push({ role: "user", content: "latest question" });
  const kept = budgetMessages("sys", turns);
  assert.equal(kept[kept.length - 1]!.content, "latest question");
  const total = kept.reduce((a, m) => a + estTokens(m.content), 0);
  assert.ok(total <= CONTEXT_TOKEN_BUDGET, `total ${total}`);
});

test("Gemini 3: thoughtSignature is captured and echoed; Groq-made calls get the skip sentinel; responses grouped", async () => {
  let sent: any = null;
  const fetchImpl = (async (_u: string, init: RequestInit) => {
    sent = JSON.parse(String(init.body));
    return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ thought: true, text: "hidden" }, { functionCall: { name: "get_status", args: {} }, thoughtSignature: "SIG1" }] } }] }), { status: 200 });
  }) as typeof fetch;
  const gem = FREE_MODEL_ROUTE.find((m) => m.provider === "gemini")!;
  const out = await callModelOnce({ model: gem, system: "s", messages: [{ role: "user", content: "q" }], tools: [{ name: "get_status", description: "d", parameters: { type: "object", properties: {} } }], env, fetchImpl });
  assert.equal(out.toolCalls[0]!.thoughtSignature, "SIG1");
  assert.equal(out.text, "", "thought parts are not shown");
  const c = geminiContents([
    { role: "user", content: "q" },
    { role: "assistant", content: "", toolCalls: [out.toolCalls[0]!, { id: "x", name: "tail_log", args: {} }] },
    { role: "tool", content: "a", toolCallId: out.toolCalls[0]!.id, toolName: "get_status" },
    { role: "tool", content: "b", toolCallId: "x", toolName: "tail_log" },
    { role: "assistant", content: "", toolCalls: [{ id: "g1", name: "get_healthz", args: {} }] },
    { role: "tool", content: "c", toolCallId: "g1", toolName: "get_healthz" },
  ]) as any[];
  assert.equal(c.length, 5, "FR1+FR2 merged into one user content");
  assert.equal(c[1].parts[0].thoughtSignature, "SIG1");
  assert.equal(c[1].parts[1].thoughtSignature, undefined, "only the first call of a step needs one");
  assert.equal(c[2].parts.length, 2);
  assert.equal(c[3].parts[0].thoughtSignature, GEMINI_SKIP_SIGNATURE, "Groq-made call replayed to Gemini");
  assert.ok(sent.contents && sent.systemInstruction);
});

test("rate-limit-aware: every model 429 with a short Retry-After → waits once, then succeeds", async () => {
  let t = 1_000_000;
  const cd = new CooldownBook(() => t);
  let calls = 0; const waits: number[] = [];
  const route: RouteModel[] = [FREE_MODEL_ROUTE[0]!, FREE_MODEL_ROUTE[1]!];
  const fetchImpl = (async (u: string) => {
    calls++;
    if (calls <= 2) return new Response("rate limit", { status: 429, headers: { "retry-after": "6" } });
    return String(u).includes("groq") ? ok("after wait") : gemOk("after wait");
  }) as typeof fetch;
  const r = await completeWithFallback({ system: "s", messages: [{ role: "user", content: "q" }], tools: [], env, cooldowns: cd, fetchImpl, route, sleepImpl: async (ms) => { waits.push(ms); t += ms; } });
  assert.equal(r.out.text, "after wait");
  assert.equal(waits.length, 1);
  assert.ok(waits[0]! >= 6000 && waits[0]! <= 7000, `waited ${waits[0]}`);
});

test("rate-limit-aware: long cooldowns fail fast with a clear message and attempt details", async () => {
  const cd = new CooldownBook();
  const attempts: any[] = [];
  const fetchImpl = (async () => new Response("rate limit", { status: 429, headers: { "retry-after": "120" } })) as typeof fetch;
  await assert.rejects(completeWithFallback({ system: "s", messages: [{ role: "user", content: "q" }], tools: [], env, cooldowns: cd, fetchImpl, route: [FREE_MODEL_ROUTE[0]!], sleepImpl: async () => { throw new Error("must not wait"); }, attempts }), ChatRouteError);
  assert.equal(attempts[0].status, 429);
  assert.equal(attempts[0].outcome, "rate_limited");
});
