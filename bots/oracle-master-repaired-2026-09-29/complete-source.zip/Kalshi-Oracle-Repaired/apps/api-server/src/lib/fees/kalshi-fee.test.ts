/**
 * FEE ORGAN unit tests T1–T7.
 * Formula: takerRaw = 0.07 * C * P * (1-P) * 100; feeDollars = ceil(raw - 1e-9)/100.
 * DO NOT use min(P,1-P)*7%.
 */
import assert from "node:assert/strict";
import test from "node:test";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  breakevenWinRate,
  expectedRoundTripFeeCents,
  kalshiFeeCents,
  kalshiMakerFeeCents,
  kalshiMakerFeeDollars,
  kalshiTakerFeeCents,
  kalshiTakerFeeDollars,
} from "./kalshi-fee.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "../../../../../../");
const API_FEE = path.join(HERE, "kalshi-fee.ts");
const TRADER_FEE = path.resolve(
  HERE,
  "../../../../kalshi-trader/src/lib/fees/kalshi-fee.ts",
);

test("T1 C=1 P=50 taker ≥ 0.02 (1.75¢ raw → 2¢)", () => {
  const dollars = kalshiTakerFeeDollars(50, 1);
  assert.ok(dollars >= 0.02, `expected ≥0.02 got ${dollars}`);
  assert.equal(dollars, 0.02);
  assert.equal(kalshiTakerFeeCents(50, 1), 2);
});

test("T2 C=20 P=50 taker = 0.35 exactly", () => {
  assert.equal(kalshiTakerFeeDollars(50, 20), 0.35);
  assert.equal(kalshiTakerFeeCents(50, 20), 35);
});

test("T3 C=41 P=49 taker ≈ 0.72", () => {
  const d = kalshiTakerFeeDollars(49, 41);
  assert.ok(Math.abs(d - 0.72) < 0.015, `expected ≈0.72 got ${d}`);
});

test("T4 C=41 P=78 taker ≈ 0.49", () => {
  const d = kalshiTakerFeeDollars(78, 41);
  // raw ≈ 49.25¢ → ceil → 50¢ = $0.50; ≈0.49 with 2¢ tolerance
  assert.ok(Math.abs(d - 0.49) < 0.02, `expected ≈0.49 got ${d}`);
});

test("T5 P=0 or 100 → 0", () => {
  assert.equal(kalshiTakerFeeDollars(0, 10), 0);
  assert.equal(kalshiTakerFeeDollars(100, 10), 0);
  assert.equal(kalshiTakerFeeCents(0, 1), 0);
  assert.equal(kalshiTakerFeeCents(100, 5), 0);
  assert.equal(kalshiMakerFeeDollars(0, 5), 0);
  assert.equal(kalshiMakerFeeDollars(100, 5), 0);
});

test("T6 maker 50¢ C=20 = 0.09", () => {
  assert.equal(kalshiMakerFeeDollars(50, 20), 0.09);
  assert.equal(kalshiMakerFeeCents(50, 20), 9);
});

test("T7 UI+bot import same module (source identity)", () => {
  assert.ok(fs.existsSync(API_FEE), `missing api fee module: ${API_FEE}`);
  assert.ok(fs.existsSync(TRADER_FEE), `missing trader fee re-export: ${TRADER_FEE}`);
  const traderSrc = fs.readFileSync(TRADER_FEE, "utf8");
  // Trader must re-export from the api-server source (same module), not a fork.
  assert.ok(
    /api-server\/src\/lib\/fees\/kalshi-fee/.test(traderSrc) ||
      /from ['\"]\.\/kalshi-fee/.test(traderSrc) === false &&
        /export \* from/.test(traderSrc) &&
        /kalshi-fee/.test(traderSrc),
    "trader kalshi-fee.ts must re-export the api-server fees/kalshi-fee module",
  );
  assert.ok(
    traderSrc.includes("kalshiTakerFeeDollars") ||
      /export \* from/.test(traderSrc),
    "trader must expose kalshiTakerFeeDollars (re-export ok)",
  );
  // Bot EV path imports constants which delegate to this module; constants must
  // reference fees/kalshi-fee.
  const constantsPath = path.resolve(HERE, "../constants.ts");
  const constantsSrc = fs.readFileSync(constantsPath, "utf8");
  assert.ok(
    /fees\/kalshi-fee/.test(constantsSrc),
    "constants.ts must import from fees/kalshi-fee",
  );
  const tradePathSrc = fs.readFileSync(
    path.resolve(HERE, "../trade-path.ts"),
    "utf8",
  );
  assert.ok(
    /kalshiFeeCents|kalshiTakerFee/.test(tradePathSrc),
    "trade-path computeTradeEV must use kalshi fee helper",
  );
  // Sanity: wrappers + BE + RT exist
  assert.equal(kalshiFeeCents(50), 2);
  assert.ok(breakevenWinRate(50, 1) > 0.5);
  assert.equal(expectedRoundTripFeeCents(50, 60, 1), 2 + kalshiTakerFeeCents(60, 1));
});
