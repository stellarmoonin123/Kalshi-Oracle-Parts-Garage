/**
 * incident-store.ts
 *
 * DB-backed store for subsystem health incidents.
 *
 * Each subsystem (websocket | database | mtf | learner) has at most one
 * "open" incident row (recoveredAt IS NULL) at any time. On init() we load
 * any open incidents from the DB so that degradedSince survives restarts.
 *
 * State transitions:
 *   enterDegraded(subsystem) — inserts a new open incident (no-op if one is
 *                              already open for that subsystem).
 *   exitDegraded(subsystem)  — stamps recoveredAt on the open incident.
 *
 * Reads:
 *   getDegradedSince(subsystem)       → epoch ms or null
 *   getIncidentCount24h(subsystem)    → count of incidents whose startedAt is
 *                                       within the rolling 24 h window
 *   getIncidentTimestamps24h(subsystem) → array of startedAt epoch ms values
 *
 * Pruning:
 *   pruneOldIncidents() deletes incidents whose startedAt is older than the
 *   configured retention window. Called automatically on the configured
 *   interval after init().
 */

import { db, healthIncidents } from "@workspace/db";
import { and, eq, isNull, isNotNull, gte, lt, inArray, count } from "drizzle-orm";

// ── Types ─────────────────────────────────────────────────────────────────────

export type Subsystem = "websocket" | "database" | "orderbook" | "mtf" | "learner" | "auth" | "balance" | "position" | "settlement" | "volfeed" | "strategy" | "modelAccuracy" | "exitConfirmation";

const DEFAULT_INCIDENT_PRUNE_INTERVAL_MS = 60 * 60 * 1000;
const DEFAULT_INCIDENT_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;
const DEFAULT_MAX_INCIDENT_ROWS = 5_000;
const DEFAULT_INCIDENT_ROW_TRIM_TARGET = 4_000;

function positiveIntegerEnv(name: string, fallback: number): number {
  const raw = process.env[name];
  if (raw === undefined || raw.trim() === "") return fallback;

  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value <= 0) {
    console.warn(`[incident-store] ignoring invalid ${name}=${JSON.stringify(raw)}; using ${fallback}`);
    return fallback;
  }
  return value;
}

/**
 * Incident maintenance settings. The defaults preserve the existing policy,
 * while operators can tighten them without a code change via environment
 * variables (for example, INCIDENT_RETENTION_MS=86400000).
 */
export const INCIDENT_PRUNE_INTERVAL_MS = positiveIntegerEnv(
  "INCIDENT_PRUNE_INTERVAL_MS",
  DEFAULT_INCIDENT_PRUNE_INTERVAL_MS,
);
export const INCIDENT_RETENTION_MS = positiveIntegerEnv(
  "INCIDENT_RETENTION_MS",
  DEFAULT_INCIDENT_RETENTION_MS,
);
export const MAX_INCIDENT_ROWS = positiveIntegerEnv(
  "MAX_INCIDENT_ROWS",
  DEFAULT_MAX_INCIDENT_ROWS,
);
export const INCIDENT_ROW_TRIM_TARGET = Math.min(
  positiveIntegerEnv("INCIDENT_ROW_TRIM_TARGET", DEFAULT_INCIDENT_ROW_TRIM_TARGET),
  MAX_INCIDENT_ROWS - 1,
);

interface OpenIncident {
  id:        number;
  startedAt: number; // epoch ms
  reason:    string | null;
}

// ── Repository interface ───────────────────────────────────────────────────────
//
// Isolates IncidentStore from the concrete Drizzle/PostgreSQL implementation so
// that unit tests can supply a lightweight in-memory fake without spinning up a
// real database.

export interface IncidentRepo {
  /** Return all rows that have no recoveredAt (open incidents). */
  findOpenIncidents(): Promise<Array<{ id: number; subsystem: string; startedAt: Date }>>;

  /**
   * Insert a new incident row.  Must honour the partial-unique-index semantics:
   * if a row already exists with the same subsystem and recoveredAt IS NULL,
   * the insert is silently ignored and the method returns undefined.
   */
  insertIncident(subsystem: string, startedAt: Date, reason?: string | null): Promise<{ id: number } | undefined>;

  /** Return the single open incident row for a subsystem, or undefined. */
  findOpenIncident(subsystem: string): Promise<{ id: number; startedAt: Date; reason: string | null } | undefined>;

  /** Stamp recoveredAt on the row identified by id. */
  stampRecovery(id: number, recoveredAt: Date): Promise<void>;

  /** Overwrite the reason on an already-open row (diagnostic only, no-op target if unsupported). */
  updateReason(id: number, reason: string): Promise<void>;

  /**
   * Return all incidents for subsystem whose startedAt is >= since.
   * Used for 24-hour window reads.
   */
  findRecentIncidents(subsystem: string, since: Date): Promise<Array<{ startedAt: Date }>>;

  /** Delete all rows whose startedAt is strictly older than cutoff. */
  deleteOldIncidents(cutoff: Date): Promise<number>;

  /** Total row count in the incidents table. */
  countIncidents(): Promise<number>;

  /**
   * Delete the oldest recovered rows (by startedAt), keeping open incidents
   * intact even if they are older than the trim target.
   */
  deleteOldestRows(count: number): Promise<void>;
}

// ── Default (Drizzle/PostgreSQL) implementation ───────────────────────────────

const drizzleRepo: IncidentRepo = {
  async findOpenIncidents() {
    return db.select().from(healthIncidents).where(isNull(healthIncidents.recoveredAt));
  },

  async insertIncident(subsystem, startedAt, reason) {
    const [row] = await db
      .insert(healthIncidents)
      .values({ subsystem, startedAt, reason: reason ?? null })
      .onConflictDoNothing()
      .returning({ id: healthIncidents.id });
    return row ?? undefined;
  },

  async findOpenIncident(subsystem) {
    const rows = await db
      .select({ id: healthIncidents.id, startedAt: healthIncidents.startedAt, reason: healthIncidents.reason })
      .from(healthIncidents)
      .where(and(eq(healthIncidents.subsystem, subsystem), isNull(healthIncidents.recoveredAt)))
      .limit(1);
    return rows[0] ?? undefined;
  },

  async stampRecovery(id, recoveredAt) {
    await db
      .update(healthIncidents)
      .set({ recoveredAt })
      .where(eq(healthIncidents.id, id));
  },

  async updateReason(id, reason) {
    await db
      .update(healthIncidents)
      .set({ reason })
      .where(eq(healthIncidents.id, id));
  },

  async findRecentIncidents(subsystem, since) {
    return db
      .select({ startedAt: healthIncidents.startedAt })
      .from(healthIncidents)
      .where(
        and(
          eq(healthIncidents.subsystem, subsystem),
          gte(healthIncidents.startedAt, since),
        ),
      );
  },

  async deleteOldIncidents(cutoff) {
    const deleted = await db
      .delete(healthIncidents)
      .where(lt(healthIncidents.startedAt, cutoff))
      .returning({ id: healthIncidents.id });
    return deleted.length;
  },

  async countIncidents() {
    const [row] = await db
      .select({ count: count() })
      .from(healthIncidents);
    return Number(row?.count ?? 0);
  },

  async deleteOldestRows(count) {
    if (count <= 0) return;
    const victims = await db
      .select({ id: healthIncidents.id })
      .from(healthIncidents)
      .where(isNotNull(healthIncidents.recoveredAt))
      .orderBy(healthIncidents.startedAt)
      .limit(count);
    if (victims.length === 0) return;
    const ids = victims.map(v => v.id);
    await db.delete(healthIncidents).where(inArray(healthIncidents.id, ids));
  },
};

// ── IncidentStore ─────────────────────────────────────────────────────────────

export class IncidentStore {
  /** In-memory map: subsystem → currently open incident (if any) */
  private open = new Map<Subsystem, OpenIncident>();
  /**
   * Task #176: subsystems where exitDegraded() was called while enterDegraded()'s
   * insertIncident() was still in flight (id placeholder === -1). exitDegraded
   * can't stamp recovery on a row that doesn't exist in the DB yet, so it
   * records the intent here; once the insert resolves, enterDegraded checks
   * this set and immediately stamps recovery on the just-created row instead
   * of reopening it in `open`. Without this, a subsystem that flaps degraded→
   * healthy faster than one DB round-trip would leave a phantom "still open"
   * incident in both memory and the DB forever.
   */
  private pendingExit = new Set<Subsystem>();
  // 2026-08-25 audit fix: exitDegraded() deletes `open` synchronously, then
  // awaits repo.stampRecovery() — a real gap in which a concurrent
  // enterDegraded() for the SAME subsystem (a fast flap) would see
  // open.has() === false, race its own insertIncident() against the
  // still-in-flight recovery stamp, lose the DB uniqueness conflict, reload
  // the OLD (soon-to-be-recovered) row via findOpenIncident(), and adopt its
  // id/startedAt as if it were the new incident. Net effect: the genuinely
  // new degraded period never gets its own row (undercounts real flaps in
  // getIncidentCount24h) and getDegradedSince() reports the stale OLD start
  // time. enterDegraded() now awaits any in-flight exit for the same
  // subsystem before touching the DB, so its insert always lands after the
  // old row is safely stamped recovered.
  private exiting = new Map<Subsystem, Promise<void>>();
  private ready = false;
  private pruneTimer: NodeJS.Timeout | null = null;
  private pruneRunning = false;  // in-flight guard for the hourly prune loop
  private readonly repo: IncidentRepo;

  constructor(repo: IncidentRepo = drizzleRepo) {
    this.repo = repo;
  }

  // ── Lifecycle ───────────────────────────────────────────────────────────────

  /**
   * Load open incidents from DB. Call once at server startup before serving
   * health requests. Safe to call multiple times (no-op after first call).
   */
  async init(): Promise<void> {
    if (this.ready) return;
    try {
      const rows = await this.repo.findOpenIncidents();

      for (const row of rows) {
        const sub = row.subsystem as Subsystem;
        const ts  = row.startedAt.getTime();
        // If multiple open rows exist (shouldn't happen), take the oldest.
        const existing = this.open.get(sub);
        if (!existing || ts < existing.startedAt) {
          this.open.set(sub, { id: row.id, startedAt: ts, reason: (row as { reason?: string | null }).reason ?? null });
        }
      }
    } catch (err) {
      console.warn("[incident-store] init() failed to load from DB:", (err as Error).message);
    }

    this.ready = true;

    // Prune on startup then on the configured interval.
    // .unref() lets the Node process exit cleanly when the timer is the only
    // remaining handle (e.g. in the test suite after all assertions pass).
    this.pruneRunning = false;
    this.pruneOldIncidents().catch(() => {});
    this.pruneTimer = setInterval(() => {
      // In-flight guard: a slow DB must not stack overlapping prune queries.
      if (this.pruneRunning) return;
      this.pruneRunning = true;
      this.pruneOldIncidents().catch(() => {}).finally(() => { this.pruneRunning = false; });
    }, INCIDENT_PRUNE_INTERVAL_MS);
    this.pruneTimer.unref();
  }

  // ── Mutations ───────────────────────────────────────────────────────────────

  /**
   * Mark a subsystem as degraded. Inserts a new incident row and stores the
   * ID in memory. No-op if the subsystem is already degraded — except that an
   * optional `reason` is refreshed on the already-open row if it changed
   * (diagnostic only; e.g. a balance outage that starts as a network timeout
   * and later becomes an auth rejection should show both, not just the first).
   */
  async enterDegraded(subsystem: Subsystem, reason?: string | null): Promise<void> {
    const normReason = reason ?? null;

    // Wait out any in-flight exitDegraded() for this subsystem first — see
    // the `exiting` field comment above. Once it resolves, `open` no longer
    // has this subsystem (exit already deleted it) and the DB row it was
    // stamping is safely recovered, so the insert below cannot collide with it.
    const inFlightExit = this.exiting.get(subsystem);
    if (inFlightExit) await inFlightExit;

    if (this.open.has(subsystem)) {
      // Already open — just refresh the reason in-memory + DB if it changed.
      const existing = this.open.get(subsystem)!;
      if (normReason && normReason !== existing.reason && existing.id !== -1) {
        existing.reason = normReason;
        try {
          await this.repo.updateReason(existing.id, normReason);
        } catch (err) {
          console.warn(`[incident-store] updateReason(${subsystem}) DB write failed:`, (err as Error).message);
        }
      }
      return;
    }

    const now = new Date();
    // Set in-memory BEFORE the first await so any concurrent call that enters
    // this function after this point sees open.has(subsystem) === true and
    // returns immediately. (Node.js is single-threaded; no preemption between
    // synchronous statements, so the check+set pair is atomic from the
    // perspective of other synchronous callers.)
    this.open.set(subsystem, { id: -1, startedAt: now.getTime(), reason: normReason });
    // Clear any stale flag from a previous enter/exit cycle before this one's
    // insert starts racing against a possible concurrent exitDegraded().
    this.pendingExit.delete(subsystem);

    try {
      const row = await this.repo.insertIncident(subsystem, now, normReason);

      if (row) {
        if (this.pendingExit.has(subsystem)) {
          // Task #176: exitDegraded() already ran while this insert was in
          // flight (it saw id === -1 and could only record intent). Stamp
          // recovery on the row we just created and do NOT reopen it in
          // `open` — otherwise this incident would appear permanently open
          // even though it already recovered.
          this.pendingExit.delete(subsystem);
          try {
            await this.repo.stampRecovery(row.id, new Date());
          } catch (err) {
            console.warn(`[incident-store] deferred exitDegraded(${subsystem}) DB write failed:`, (err as Error).message);
          }
        } else {
          // Update in-memory entry with the real DB id.
          this.open.set(subsystem, { id: row.id, startedAt: now.getTime(), reason: normReason });
          // Task #177: only worth checking the row cap right after a row was
          // actually added — a suppressed-conflict insert (the else branch)
          // didn't grow the table.
          void this.enforceRowCap();
        }
      } else {
        // Conflict suppressed — a row already existed. Reload from DB so our
        // in-memory map reflects the correct id and timestamp.
        const existing = await this.repo.findOpenIncident(subsystem);
        if (existing) {
          if (this.pendingExit.has(subsystem)) {
            this.pendingExit.delete(subsystem);
            try {
              await this.repo.stampRecovery(existing.id, new Date());
            } catch (err) {
              console.warn(`[incident-store] deferred exitDegraded(${subsystem}) DB write failed:`, (err as Error).message);
            }
          } else {
            this.open.set(subsystem, { id: existing.id, startedAt: existing.startedAt.getTime(), reason: existing.reason });
          }
        }
      }
    } catch (err) {
      // Memory-only fallback stays in place so the API remains functional.
      console.warn(`[incident-store] enterDegraded(${subsystem}) DB write failed:`, (err as Error).message);
      this.pendingExit.delete(subsystem);
    }
  }

  private capCheckRunning = false;
  /**
   * Inserts that land while a count/trim query is in flight mark this dirty.
   * The active check then reruns before releasing the guard, so it cannot miss
   * a burst whose first count observed a pre-cap snapshot.
   */
  private capCheckPending = false;

  /**
   * Task #177: independent safety net against unbounded growth between the
   * hourly age-based prunes — e.g. a rapidly flapping subsystem creating a
   * fresh row on every flap. Cheap to call on every insert: it's a single
   * COUNT-equivalent select. Inserts that arrive while one is in flight are
   * coalesced into one follow-up check before the guard is released.
   */
  private async enforceRowCap(): Promise<void> {
    this.capCheckPending = true;
    if (this.capCheckRunning) return;
    this.capCheckRunning = true;
    try {
      do {
        this.capCheckPending = false;
        const total = await this.repo.countIncidents();
        if (total > MAX_INCIDENT_ROWS) {
          const excess = total - INCIDENT_ROW_TRIM_TARGET;
          await this.repo.deleteOldestRows(excess);
          console.warn(`[incident-store] row cap exceeded (${total} > ${MAX_INCIDENT_ROWS}) — trimmed oldest ${excess} rows`);
        }
      } while (this.capCheckPending);
    } catch (err) {
      console.warn("[incident-store] enforceRowCap() failed:", (err as Error).message);
    } finally {
      this.capCheckRunning = false;
    }
  }

  /**
   * Mark a subsystem as recovered. Stamps recoveredAt on the open incident row.
   * No-op if the subsystem wasn't degraded.
   */
  async exitDegraded(subsystem: Subsystem): Promise<void> {
    const incident = this.open.get(subsystem);
    if (!incident) return; // wasn't degraded

    this.open.delete(subsystem);

    if (incident.id === -1) {
      // Task #176: enterDegraded()'s insertIncident() is still in flight (no
      // real row id yet) — there's nothing to stamp recovery on right now.
      // Flag it so enterDegraded stamps recovery itself the moment the row
      // exists, instead of silently reopening a since-recovered incident.
      this.pendingExit.add(subsystem);
      return;
    }

    const recoveryPromise = (async () => {
      try {
        await this.repo.stampRecovery(incident.id, new Date());
      } catch (err) {
        console.warn(`[incident-store] exitDegraded(${subsystem}) DB write failed:`, (err as Error).message);
      }
    })();
    // Published so a concurrent enterDegraded() for the same subsystem waits
    // for this stamp to land before racing its own insert against it.
    this.exiting.set(subsystem, recoveryPromise);
    try {
      await recoveryPromise;
    } finally {
      // Only clear if we're still the current entry — an extremely tight
      // exit→enter→exit sequence could otherwise clobber a newer promise.
      if (this.exiting.get(subsystem) === recoveryPromise) this.exiting.delete(subsystem);
    }
  }

  // ── Reads ────────────────────────────────────────────────────────────────────

  /** Epoch ms when the subsystem first became degraded, or null if healthy. */
  getDegradedSince(subsystem: Subsystem): number | null {
    return this.open.get(subsystem)?.startedAt ?? null;
  }

  /**
   * Count of incidents whose startedAt falls within the rolling 24 h window.
   * Reads from DB to include incidents that started before the last restart.
   */
  async getIncidentCount24h(subsystem: Subsystem): Promise<number> {
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
    try {
      const rows = await this.repo.findRecentIncidents(subsystem, since);
      return rows.length;
    } catch {
      // Fallback: count only in-memory open incident
      const incident = this.open.get(subsystem);
      return incident && incident.startedAt > since.getTime() ? 1 : 0;
    }
  }

  /**
   * Array of startedAt epoch ms values for incidents in the rolling 24 h window.
   * Reads from DB to include history from before the last restart.
   */
  async getIncidentTimestamps24h(subsystem: Subsystem): Promise<number[]> {
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
    try {
      const rows = await this.repo.findRecentIncidents(subsystem, since);
      return rows.map(r => r.startedAt.getTime());
    } catch {
      // Fallback: return in-memory open incident timestamp if within window
      const incident = this.open.get(subsystem);
      return incident && incident.startedAt > since.getTime() ? [incident.startedAt] : [];
    }
  }

  // ── Maintenance ──────────────────────────────────────────────────────────────

  /** Delete incidents whose startedAt is older than the configured retention. */
  async pruneOldIncidents(): Promise<void> {
    const cutoff = new Date(Date.now() - INCIDENT_RETENTION_MS);
    try {
      const deleted = await this.repo.deleteOldIncidents(cutoff);
      console.info(`[incident-store] prune completed: deleted ${deleted} incident row${deleted === 1 ? "" : "s"}`);
    } catch (err) {
      console.warn("[incident-store] pruneOldIncidents() failed:", (err as Error).message);
    }
  }
}

// ── Singleton ─────────────────────────────────────────────────────────────────

export const incidentStore = new IncidentStore();
