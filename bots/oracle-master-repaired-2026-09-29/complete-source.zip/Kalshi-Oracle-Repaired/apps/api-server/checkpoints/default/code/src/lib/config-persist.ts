/**
 * config-persist.ts
 *
 * Read/write helpers for the bot's on-disk config snapshot.  Extracted from
 * trading-bot.ts so that the logic can be unit-tested in isolation without
 * instantiating the full TradingBot class.
 *
 * The JSON file is written atomically (write to tmp → rename) so a mid-write
 * crash cannot leave a half-truncated config behind.
 *
 * Safety on every load/save:
 *  • paperMode always true on disk (LIVE REAL MONEY is not a boot path)
 *  • secret-looking keys never land in .bot-config.json
 *  • SEV1 / OTM / LATE / leftover engine IDs stay in disabledStrategies
 *  • leftover / hourly ENABLE flags forced false (fail-closed)
 *  • EV / Kelly / 9% / 18% floor aliases never persist (immutable constants)
 */
import fs   from "fs";
import path from "path";
import type { BotConfig } from "./trading-bot-types.js";
import {
  PATCH_FAIL_CLOSED_DISABLED,
  PATCH_REFUSE_FLOOR_KEYS,
  PATCH_REFUSE_TRUE_KEYS,
} from "./config-patch-surface.js";

// ── Resolve the config file path ──────────────────────────────────────────────
// Tests may override this by setting process.env.BOT_CONFIG_PATH.
// Production code sets it to a file in the server's working directory.

/**
 * Sweep K1 / item 9 (Sep 25): the config used to live at
 * <cwd>/.bot-config.json, which is dockerignored and NOT on the Fly volume
 * (only <cwd>/data is mounted). Every deploy/restart lost API-patched config
 * and booted from class defaults. It now lives in the desk data dir (the
 * volume). The old path is kept as LEGACY and migrated once when the volume
 * copy is missing.
 */
export const LEGACY_CONFIG_PATH = path.resolve(process.cwd(), ".bot-config.json");

function deskDataDirForConfig(): string {
  const override = process.env.DESK_DATA_DIR;
  return override && override.trim() ? path.resolve(override.trim()) : path.resolve(process.cwd(), "data");
}

export const DEFAULT_CONFIG_PATH = path.join(deskDataDirForConfig(), ".bot-config.json");

export function resolveConfigPath(): string {
  return process.env.BOT_CONFIG_PATH ?? DEFAULT_CONFIG_PATH;
}

/**
 * Path readers (diagnostics, chat inspection) should open: the configured
 * path when it exists, else the legacy cwd file when no override is set.
 * Never used for writes.
 */
export function resolveReadableConfigPath(): string {
  const primary = resolveConfigPath();
  if (process.env.BOT_CONFIG_PATH || fs.existsSync(primary)) return primary;
  return fs.existsSync(LEGACY_CONFIG_PATH) ? LEGACY_CONFIG_PATH : primary;
}

/**
 * One-time migration: copy the legacy cwd config onto the volume path when
 * the volume copy does not exist yet. No-op when BOT_CONFIG_PATH is set
 * (tests) or when the volume copy already exists. Returns what happened.
 */
export function migrateLegacyConfigToVolume(opts: { legacyPath?: string; targetPath?: string } = {}): "migrated" | "exists" | "no-legacy" | "override" | "error" {
  if (!opts.targetPath && process.env.BOT_CONFIG_PATH) return "override";
  const target = opts.targetPath ?? DEFAULT_CONFIG_PATH;
  const legacy = opts.legacyPath ?? LEGACY_CONFIG_PATH;
  try {
    if (fs.existsSync(target)) return "exists";
    if (!fs.existsSync(legacy) || path.resolve(legacy) === path.resolve(target)) return "no-legacy";
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const tmp = `${target}.tmp.${process.pid}`;
    fs.copyFileSync(legacy, tmp);
    fs.renameSync(tmp, target);
    return "migrated";
  } catch {
    return "error";
  }
}

/**
 * Keys that must never be written to / returned from .bot-config.json.
 * Matching is case-insensitive substring on the key name.
 */
export const CONFIG_SECRET_KEY_SUBSTR = [
  "apikey",
  "api_key",
  "secret",
  "privatekey",
  "private_key",
  "passphrase",
  "password",
  "token",
  "oraclekey",
  "authorization",
  "credential",
] as const;

export function isConfigSecretKey(key: string): boolean {
  const lower = key.toLowerCase();
  return (CONFIG_SECRET_KEY_SUBSTR as readonly string[]).some(s => lower.includes(s));
}

/** Leftover / hourly ENABLE flags forced false on disk (fail-closed). */
export const PERSIST_FORCE_FALSE_KEYS = [
  ...PATCH_REFUSE_TRUE_KEYS,
] as const;

/**
 * Strip secrets, force paperMode true, union fail-closed disabledStrategies,
 * force leftover ENABLE flags false, and drop EV/Kelly floor aliases.
 * Pure — does not invent admission EV/Kelly constants.
 */
export function normalizePersistedConfig(
  raw: Record<string, unknown> | Partial<BotConfig> | null | undefined,
): Partial<BotConfig> {
  const out: Record<string, unknown> = {};
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return { paperMode: true, disabledStrategies: [...PATCH_FAIL_CLOSED_DISABLED] } as Partial<BotConfig>;
  }

  for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
    if (isConfigSecretKey(key)) continue;
    if ((PATCH_REFUSE_FLOOR_KEYS as readonly string[]).includes(key)) continue;
    out[key] = value;
  }

  // frozenCcMode: preserve disk presence. true/false both stick; missing stays
  // missing so callers can tell "file never had the key" from "file said false".
  // Never invent false when the key was true on disk (P0 bounce leak).
  if (Object.prototype.hasOwnProperty.call(raw, "frozenCcMode")) {
    out.frozenCcMode = (raw as Record<string, unknown>).frozenCcMode === true;
  }

  out.paperMode = true;

  // Always pin leftover / hourly ENABLE knobs false on disk (fail-closed).
  for (const key of PERSIST_FORCE_FALSE_KEYS) {
    out[key] = false;
  }

  const incoming = Array.isArray(out.disabledStrategies)
    ? (out.disabledStrategies as unknown[]).filter((x): x is string => typeof x === "string")
    : [];
  out.disabledStrategies = [...new Set([...incoming, ...PATCH_FAIL_CLOSED_DISABLED])];

  return out as Partial<BotConfig>;
}

// ── Load ──────────────────────────────────────────────────────────────────────

/**
 * Read and parse the persisted bot config.
 * Returns an empty object when the file does not exist (first run).
 *
 * Defensive normalisation:
 *  • disabledStrategies: guaranteed to be string[] (never null / wrong type)
 *  • secrets stripped; paperMode true; fail-closed engines unioned; ENABLE false
 *  • EV/Kelly floor aliases dropped
 */
export function loadPersistedConfig(configPath?: string): Partial<BotConfig> {
  if (!configPath) migrateLegacyConfigToVolume();
  const filePath = configPath ?? resolveConfigPath();
  try {
    const raw    = fs.readFileSync(filePath, "utf8");
    const parsed = JSON.parse(raw) as Partial<BotConfig>;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("Configuration must be a JSON object");
    }

    // Defensive guard: disabledStrategies must always be a string array.
    // A legacy config file or manual edit could leave it as null / a non-array.
    if (
      parsed.disabledStrategies !== undefined &&
      !Array.isArray(parsed.disabledStrategies)
    ) {
      console.warn(
        "[bot] loadPersistedConfig: disabledStrategies was not an array — resetting to []"
      );
      parsed.disabledStrategies = [];
    }

    return normalizePersistedConfig(parsed as Record<string, unknown>);
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") return {};
    // A damaged/unreadable existing config is not a clean first boot. Preserve
    // the file and stop hydration so defaults cannot overwrite operator state.
    throw new Error("Cannot load persisted bot configuration; preserve the file and repair it before restarting");
  }
}

// ── Save ──────────────────────────────────────────────────────────────────────

/**
 * Atomically write the bot config to disk (normalized).
 * Uses write-to-temp-then-rename so a crash mid-write cannot corrupt the file.
 * paperMode is always persisted true — boot hydration also forces paper.
 * Secrets / EV-Kelly aliases are never written. Fail-closed engines stay disabled.
 */
export function savePersistedConfig(cfg: BotConfig, configPath?: string): void {
  const filePath = configPath ?? resolveConfigPath();
  try {
    const safe    = normalizePersistedConfig(cfg as unknown as Record<string, unknown>);
    const json    = JSON.stringify(safe, null, 2);
    const tmpPath = `${filePath}.tmp.${process.pid}`;
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(tmpPath, json, "utf8");
    fs.renameSync(tmpPath, filePath);
  } catch (err) {
    console.error("[bot] Failed to persist config:", err);
  }
}


/** Risk / mode knobs that must survive restart (#404 / #409). */
export const RESTART_PERSIST_KEYS = [
  "paperMode",
  "autoMode",
  "enabled",
  "dailyLossCapCents",
  "dailyLossCapPct",
  "minConfidence",
  "minVelocity",
  "minEntryPrice",
  "maxEntryPrice",
  "stopLossCents",
  "hardStopCents",
  "maxContractsPerTrade",
  "useKellySizing",
  // P0: disk frozenCcMode must survive bounce — constructor default is false.
  "frozenCcMode",
] as const;

export type RestartPersistDecision = {
  paperMode: boolean;
  enabled: boolean;
  autoMode: boolean;
};

/**
 * Task #409: restart hydration for the 15m paper desk.
 * paperMode stays true (LIVE REAL MONEY is required to leave paper — not a boot path).
 * enabled follows disk (do not silently drop a running desk).
 * autoMode follows disk — ADAPTATION that can stay ON (composer gate-write is fail-closed).
 */
export function restartPersistDecision(saved: {
  paperMode?: boolean;
  enabled?: boolean;
  autoMode?: boolean;
}): RestartPersistDecision {
  return {
    paperMode: true,
    enabled: saved.enabled === true,
    autoMode: saved.autoMode === true,
  };
}

/**
 * Task #404: overlay saved risk knobs onto defaults. Present saved values win.
 * Missing keys keep the default — never wipe a persisted cap/stop/confidence.
 * paperMode is always forced true after overlay (cannot silently go false).
 */

/**
 * Boot / simulated-restart merge: constructor defaults first, then disk.
 * When disk has frozenCcMode (esp. true), it ALWAYS wins over the class-field
 * default false. Missing disk key leaves the default untouched.
 */
export function mergeDiskFrozenCcMode<T extends { frozenCcMode?: boolean }>(
  defaults: T,
  saved: Partial<T> | Record<string, unknown> | null | undefined,
): T {
  const next = { ...defaults };
  if (!saved || typeof saved !== "object") return next;
  if (!Object.prototype.hasOwnProperty.call(saved, "frozenCcMode")) return next;
  (next as { frozenCcMode?: boolean }).frozenCcMode =
    (saved as Record<string, unknown>).frozenCcMode === true;
  return next;
}

export function mergePersistedRisk<T extends Record<string, unknown>>(
  defaults: T,
  saved: Partial<T> | Record<string, unknown>,
): T {
  const next = { ...defaults };
  for (const key of RESTART_PERSIST_KEYS) {
    if (!Object.prototype.hasOwnProperty.call(saved, key)) continue;
    const v = (saved as Record<string, unknown>)[key];
    if (v === undefined) continue;
    (next as Record<string, unknown>)[key] = v;
  }
  const locked = restartPersistDecision({
    paperMode: next.paperMode as boolean | undefined,
    enabled: next.enabled as boolean | undefined,
    autoMode: next.autoMode as boolean | undefined,
  });
  (next as Record<string, unknown>).paperMode = locked.paperMode;
  (next as Record<string, unknown>).enabled = locked.enabled;
  (next as Record<string, unknown>).autoMode = locked.autoMode;
  return next;
}
