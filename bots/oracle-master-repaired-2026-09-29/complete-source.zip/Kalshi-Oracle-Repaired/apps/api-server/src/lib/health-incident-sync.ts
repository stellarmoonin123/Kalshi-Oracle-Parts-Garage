/**
 * health-incident-sync — GET /healthz must not write incidents.
 *
 * The route now only NOTES each subsystem's degraded/ok verdict in memory
 * (noteHealthIncident); a background flusher (15 s, unref'd, started once at
 * import outside tests) applies the enter/exitDegraded transitions to the
 * incident store. incidentStore reads (counts / degradedSince) are unchanged.
 */
import { incidentStore } from "./incident-store.js";

type Subsystem = Parameters<typeof incidentStore.enterDegraded>[0];
type Verdict = { degraded: boolean; reason: string | null; notedAt: number };

const pending = new Map<Subsystem, Verdict>();
const applied = new Map<Subsystem, boolean>();
export const HEALTH_INCIDENT_FLUSH_MS = 15_000;

/** Record the latest verdict (memory only — no I/O). */
export function noteHealthIncident(subsystem: Subsystem, degraded: boolean, reason?: string | null): void {
  pending.set(subsystem, { degraded, reason: reason ?? null, notedAt: Date.now() });
}

export function getPendingHealthIncidents(): ReadonlyMap<Subsystem, Verdict> {
  return pending;
}

export function resetHealthIncidentSyncForTests(): void {
  pending.clear();
  applied.clear();
}

/** Apply noted verdicts that changed since the last flush. */
export async function flushHealthIncidents(
  store: Pick<typeof incidentStore, "enterDegraded" | "exitDegraded"> = incidentStore,
): Promise<number> {
  let writes = 0;
  for (const [sub, v] of [...pending.entries()]) {
    if (applied.get(sub) === v.degraded) continue;
    try {
      if (v.degraded) await store.enterDegraded(sub, v.reason);
      else await store.exitDegraded(sub);
      applied.set(sub, v.degraded);
      writes += 1;
    } catch {
      /* retry next flush */
    }
  }
  return writes;
}

let timer: ReturnType<typeof setInterval> | null = null;
export function startHealthIncidentFlusher(): void {
  if (timer) return;
  timer = setInterval(() => { void flushHealthIncidents(); }, HEALTH_INCIDENT_FLUSH_MS);
  timer.unref?.();
}

const inTest = process.env.NODE_TEST_CONTEXT != null
  || (typeof process.env.BOT_CONFIG_PATH === "string" && process.env.BOT_CONFIG_PATH.includes("/tmp"));
if (!inTest) startHealthIncidentFlusher();
