/**
 * constants.ts — single source of truth for hardcoded values used across the bot.
 *
 * Keep magic numbers here so they appear in one place and can be reasoned about
 * together. Import from this module instead of scattering literals through the codebase.
 */

// ── Kalshi ────────────────────────────────────────────────────────────────────

/**
 * Kalshi fee rates — quadratic P*(1-P) organ (NOT min(P,1-P)×rate).
 * Canonical implementation: ./fees/kalshi-fee.ts
 *   takerRawCents = 0.07   * C * P * (1-P) * 100
 *   makerRawCents = 0.0175 * C * P * (1-P) * 100
 *   feeDollars    = ceil(rawCents - 1e-9) / 100
 * Settlement fee = 0. Early sell = second fee at exit price.
 */
export const KALSHI_TAKER_FEE = 0.07;
/** Maker fee RATE used by the P*(1-P) organ (was wrongly 0.03 flat / min). */
export const KALSHI_MAKER_FEE = 0.0175;

export {
  kalshiTakerFeeDollars,
  kalshiMakerFeeDollars,
  kalshiTakerFeeCents,
  kalshiMakerFeeCents,
  breakevenWinRate as kalshiBreakevenWinRate,
  expectedRoundTripFeeCents,
  feePctOfCost as kalshiFeePctOfCost,
  KALSHI_TAKER_FEE_RATE,
  KALSHI_MAKER_FEE_RATE,
} from "./fees/kalshi-fee.js";

import {
  kalshiTakerFeeCents as _takerFeeCents,
  kalshiMakerFeeCents as _makerFeeCents,
} from "./fees/kalshi-fee.js";

/**
 * Maximum fraction of visible executable order-book depth that one entry may
 * consume. The value is also exposed through BotConfig so operators can tune
 * it without changing code.
 */
export const MAX_DEPTH_FRACTION = 0.50;
/**
 * Kalshi fee in cents. Default: taker, C=1 (per-contract EV).
 * Optional second arg: legacy rate — if ≈ maker rate (0.0175 or old 0.03),
 * uses maker organ; otherwise taker. Prefer kalshiTakerFeeCents(price, C)
 * / kalshiMakerFeeCents(price, C) when order size is known (ceil once).
 */
export function kalshiFeeCents(priceCents: number, rate: number = KALSHI_TAKER_FEE): number {
  const makerish =
    Math.abs(rate - KALSHI_MAKER_FEE) < 1e-9 ||
    Math.abs(rate - 0.03) < 1e-9 ||
    Math.abs(rate - 0.0175) < 1e-9;
  return makerish ? _makerFeeCents(priceCents, 1) : _takerFeeCents(priceCents, 1);
}

/**
 * Net win per contract in cents when held to settlement.
 * = (100 - priceCents) - kalshiFeeCents(priceCents)
 */
export function kalshiNetWinCents(priceCents: number): number {
  return (100 - priceCents) - kalshiFeeCents(priceCents);
}

/**
 * Total cost per contract (entry price + taker fee).
 * This is also the total amount lost if the trade loses.
 */
export function kalshiNetCostCents(priceCents: number): number {
  return priceCents + kalshiFeeCents(priceCents);
}

/**
 * Expected slippage cost per contract (in cents) when entering as a taker.
 * 15-min BTC Kalshi contracts have typical spreads of 2–5¢; a taker pays
 * roughly half the spread above the mid-price. 2¢ matches blotter evidence (honesty).
 * Add this to the fee in EV gate calculations to model real entry cost.
 */
export const KALSHI_EXPECTED_SLIPPAGE_CENTS = 2;

export const KALSHI_MAX_EXPECTED_SLIPPAGE_CENTS = 5;
/**
 * Dynamic slippage estimate (¢/contract) — replaces the flat
 * KALSHI_EXPECTED_SLIPPAGE_CENTS baseline for EV decisions. 2¢ matches blotter;
 * dynamic widen still applies when fills
 * are hardest: the final minutes of a contract (book withdraws), during a
 * high-velocity move (price is moving through the book faster than a
 * resting quote can be trusted), or when the observed spread is already wide
 * (thin book, whatever the cause). Capped at 5¢ so a bad spread reading
 * can't make the model absurdly conservative.
 *
 * `secsRemaining` and `velocityDolPerMin` are required — callers without
 * real-time context (e.g. estimateTradeEV, the hourly poller) should pass
 * `Number.POSITIVE_INFINITY` / `0` respectively via computeTradeEV's
 * optional-field defaulting, which reproduces the flat 2¢ baseline
 * unchanged. `spreadCents` stays optional since not every caller has a live
 * order book to read from.
 */
export function expectedSlippageCents(opts: {
  secsRemaining:      number;
  velocityDolPerMin:  number;
  spreadCents?:       number;
  /**
   * Current-session observed average slippage, supplied only by the live bot
   * after the fill-quality sample threshold has been met. Kept optional so
   * research/backtest callers remain deterministic and use the static model.
   */
  observedSlippageCents?: number;
}): number {
  let slip = KALSHI_EXPECTED_SLIPPAGE_CENTS; // base

  // A bad execution session is evidence that the normal baseline is too
  // optimistic right now. This is a floor, never a discount: a favorable fill
  // sample cannot make the model less conservative than the configured 2¢.
  if (opts.observedSlippageCents != null && Number.isFinite(opts.observedSlippageCents)) {
    slip = Math.max(slip, opts.observedSlippageCents);
  }

  // Final 3 minutes — book thins, adverse selection rises
  if (opts.secsRemaining <= 180) slip = Math.max(slip, 3.0);

  // High velocity — price is moving through the book
  if (Math.abs(opts.velocityDolPerMin) >= 80) slip = Math.max(slip, 2.5);
  if (Math.abs(opts.velocityDolPerMin) >= 120) slip = Math.max(slip, 3.5);

  // Wide spread — use half the spread as a floor when available
  if (opts.spreadCents != null && opts.spreadCents > 0) {
    slip = Math.max(slip, opts.spreadCents * 0.5);
  }

  // Hard cap so we never become absurdly conservative
  return Math.min(slip, KALSHI_MAX_EXPECTED_SLIPPAGE_CENTS);
}

/**
 * Seconds remaining below which the order book on 15-min BTC contracts thins
 * dramatically and adverse selection risk spikes. MULTIPLIER-path trades (OTM,
 * sitting in the thinest part of the book) must not enter below this threshold.
 * Based on: Kalshi microstructure — final 2-3 min liquidity withdrawal pattern.
 */
export const THIN_BOOK_CUTOFF_SECS = 180;

/** Primary BTC 15-minute contract series ticker. */
export const KALSHI_SERIES_15M  = 'KXBTC15M';

/** Kalshi REST API base URL (elections API — market data, contract listings). */
export const KALSHI_REST_BASE     = 'https://api.elections.kalshi.com/trade-api/v2';

/**
 * Kalshi Trading API base URL — the correct base for all authenticated
 * portfolio operations: order placement, cancellation, fill-check, settlement
 * fetch, and balance queries.  Market-data reads (prices, contracts) stay on
 * KALSHI_REST_BASE.
 *
 * NOTE: As of 2026-07, Kalshi migrated trading-api.kalshi.com to
 * api.elections.kalshi.com.  The old domain returns HTTP 401 with
 * "API has been moved to https://api.elections.kalshi.com/".
 */
export const KALSHI_TRADING_BASE  = 'https://api.elections.kalshi.com/trade-api/v2';

/**
 * Task #157/#158/#161 (path-level follow-up 2): domain root with NO
 * '/trade-api/v2' suffix, for pairing with the KALSHI_PATH_* constants below
 * (which already embed the '/trade-api/v2' prefix) when building a fetch()
 * URL. Several call sites computed apiPath from a KALSHI_PATH_* constant for
 * REQUEST SIGNING, then separately re-typed the same path as a literal
 * string suffixed onto KALSHI_TRADING_BASE for the actual fetch() call —
 * two independent copies of the same path that could silently drift apart.
 * Always build order/portfolio fetch URLs as `${KALSHI_API_DOMAIN}${apiPath}`
 * so the signed path and the fetched path are provably the same value.
 */
export const KALSHI_API_DOMAIN = 'https://api.elections.kalshi.com';

/** Kalshi WebSocket URL. */
// Dedicated Trade API WS (CFB 5Hz + ticker). Legacy elections host remains
// supported for ticker but CF Benchmarks channels need this host.
export const KALSHI_WS_URL      = 'wss://external-api-ws.kalshi.com/trade-api/ws/v2';

/** Kalshi WebSocket HTTP path (used for RSA-PSS request signing). */
export const KALSHI_WS_PATH     = '/trade-api/ws/v2';

/**
 * Task #157: Kalshi's separate public API for perpetual futures ("margin" in
 * the API) lives on a different domain (external-api.kalshi.com, not
 * api.elections.kalshi.com) — it was hardcoded identically in both
 * lib/perps/kalshi-perps-client.ts and routes/kalshi.ts. Single source now.
 */
export const KALSHI_PERPS_API_BASE = 'https://external-api.kalshi.com/trade-api/v2/margin';

/**
 * Task #157 (path-level follow-up): the domain/base-URL constants above were
 * already deduplicated, but the *request path* strings appended to
 * KALSHI_TRADING_BASE were still hardcoded independently at every call site
 * across trading-bot.ts and routes/kalshi.ts (balance, positions, fills, and
 * order placement/cancel/status each repeated 2-3x). Centralized here so a
 * future path change (e.g. another Kalshi API migration) is a one-line edit
 * instead of a grep-and-replace across two files.
 */
export const KALSHI_PATH_PORTFOLIO_BALANCE   = '/trade-api/v2/portfolio/balance';
export const KALSHI_PATH_PORTFOLIO_POSITIONS = '/trade-api/v2/portfolio/positions';
export const KALSHI_PATH_PORTFOLIO_FILLS     = '/trade-api/v2/portfolio/fills';
/** Order placement (POST) and bulk listing (GET) — no order ID suffix. */
export const KALSHI_PATH_PORTFOLIO_ORDERS    = '/trade-api/v2/portfolio/events/orders';
/** Resting (unfilled) order listing. */
export const KALSHI_PATH_PORTFOLIO_ORDERS_RESTING = '/trade-api/v2/portfolio/orders?status=resting&limit=50';
/** Cancel (DELETE) or fetch a single order by ID — Kalshi's events/orders/{id} endpoint. */
export function kalshiEventsOrderPath(orderId: string): string {
  return `/trade-api/v2/portfolio/events/orders/${orderId}`;
}
/** Poll a single order's fill status (GET) — Kalshi's orders/{id} endpoint (distinct from events/orders/{id} above). */
export function kalshiOrderStatusPath(orderId: string): string {
  return `/trade-api/v2/portfolio/orders/${orderId}`;
}
export function kalshiSettlementsPath(limit: number): string {
  return `/trade-api/v2/portfolio/settlements?limit=${limit}`;
}

/**
 * Hourly BTC contract series — threshold style ("$62,700 or above"), one event
 * per hour (e.g. KXBTCD-26AUG0114 = Aug 1, 2pm ET close), ~188 strike markets
 * per event, floor-strike only. Settles on the CF Real Time Index (average of
 * the 60 RTI prices in the final minute). Same above/below structure as the
 * 15-minute contracts, so the strategy library transfers directly.
 *
 * NOTE (2026-08): the old KXBTC1H / KXBTCH series no longer exist on Kalshi —
 * they return empty market lists. KXBTCD is the live hourly product.
 */
export const KALSHI_SERIES_1H     = 'KXBTCD';

/**
 * Hourly BTC banded series (floor + cap ranges, e.g. "$68,200–$68,299").
 * Display only — the bot trades the threshold series above.
 */
export const KALSHI_SERIES_1H_ALT = 'KXBTC';

/** Partial series prefix used for broad market queries (matches both 15M and 1H). */
export const KALSHI_SERIES_BTC    = 'KXBTC';

// ── BTC pricing model ─────────────────────────────────────────────────────────

/**
 * Fallback BTC floor strike when the real strike hasn't been fetched yet.
 * Used only during startup before the first Kalshi tick arrives.
 */
export const BTC_FLOOR_FALLBACK = 97_000;

/**
 * Assumed annualised BTC realised volatility used in the closed-form binary
 * option probability model when live vol is unavailable.
 * ~55% has been the long-run BTC annualised vol.
 */
export const BTC_ANNUALISED_VOL = 0.55;

/** Number of 15-min candles in a year — used for Sharpe / Calmar annualisation. */
export const CANDLES_PER_YEAR_15M = (365 * 24 * 60) / 15;

/** Number of 1-min candles in a year — used in the trading-bot probability model. */
export const CANDLES_PER_YEAR_1M  = 365 * 24 * 60;

// ── Volume state thresholds ───────────────────────────────────────────────────

/**
 * If recent speed / all-time speed > HIGH_RATIO → "high" volume (breakout).
 * Below LOW_RATIO → "low" volume (squeeze / coiling).
 */
export const VOLUME_HIGH_RATIO = 1.6;
export const VOLUME_LOW_RATIO  = 0.55;

// ── Price channel / breakout ──────────────────────────────────────────────────

/**
 * Buffer as a fraction of price applied around key levels when detecting
 * breakouts and fakeouts. 0.0005 = 0.05%.
 */
export const BREAKOUT_BUFFER_PCT = 0.0005;

// ── Pre-trade simulation ──────────────────────────────────────────────────────

/**
 * Weighted composite score (0–100) that a trade must exceed to be approved.
 * Lowered 62→55 on 2026-08-05 at the user's explicit request ("too many
 * checks / too strict") — this is the ONLY approval gate on the 8-check
 * composite (see pre-trade-sim.ts's SCORE_THRESHOLD comment: no per-check
 * hard veto exists), so lowering it directly increases trade frequency by
 * letting weaker-but-still-positive setups through. Does not touch the
 * News-Risk hard block, EV floor, or any other independent risk gate.
 */
export const PRETRADE_SCORE_THRESHOLD = 55;

/**
 * A low-priced (multiplier) contract may only enter while price acceleration
 * is both strong and aligned with the intended side. The threshold matches the
 * existing "meaningful acceleration" boundary used by the entry confidence
 * pipeline; a non-zero tick is not enough evidence for a high-multiple bet.
 */
export const MULTIPLIER_STRONG_ACCEL_DOL_PER_MIN = 10;

/** Period-history DB cache TTL in milliseconds (30 seconds). */
export const PERIODS_CACHE_TTL_MS = 30_000;

// ── MTF Analyzer ─────────────────────────────────────────────────────────────

/**
 * How often the MTF analyzer refreshes the SLOW leg (1h/4h, sourced from
 * Kalshi settlement candles). Hourly candles don't move fast enough to
 * justify tighter polling, and this also bounds Kalshi settlement API load.
 */
export const MTF_REFRESH_MS = 5 * 60 * 1_000;

/**
 * How often the MTF analyzer refreshes the FAST leg (1m/5m/15m, sourced from
 * real exchange candles via fetchRealCandles). 2026-08-09: added so 15-minute
 * contract decisions aren't gated on data that's up to 5 minutes stale.
 */
export const MTF_FAST_REFRESH_MS = 30 * 1_000;

/**
 * Maximum age of an MTF summary before it is considered stale.
 * If underlying candle data is unavailable, the bot pauses MTF-dependent decisions.
 */
export const MTF_STALE_MS = 10 * 60 * 1_000;

// ── Trading bot risk ──────────────────────────────────────────────────────────

/**
 * Liquidity regime derived from the New York market clock. This keeps the
 * trading policy stable across Eastern Standard and Daylight Time:
 * - ASIAN_HOURS: midnight–6am ET (thin book, reduced sizing)
 * - OVERLAP: 6–9am ET plus neutral off-window hours
 * - US_HOURS: 9am–9pm ET
 */
export type TimeOfDayRegime = 'US_HOURS' | 'OVERLAP' | 'ASIAN_HOURS';

/**
 * Position-size haircut for the thin Asian-hours Kalshi BTC book. This is a
 * tightening-only execution control, not an adjustable strategy/risk setting.
 */
export const ASIAN_HOURS_SIZE_MULT = 0.70;

const EASTERN_HOUR_FORMATTER = new Intl.DateTimeFormat("en-US", {
  timeZone: "America/New_York",
  hour: "2-digit",
  hourCycle: "h23",
});

/** Classifies the current New York market hour, accounting for DST. */
export function getTimeOfDayRegime(now = new Date()): TimeOfDayRegime {
  const hour = Number(EASTERN_HOUR_FORMATTER.format(now));

  // The handoff window gets neutral sizing where it overlaps the U.S. desk.
  if (hour >= 7 && hour < 9) return 'OVERLAP';
  if (hour >= 0 && hour < 6) return 'ASIAN_HOURS';
  if (hour >= 8 && hour < 21) return 'US_HOURS';
  return 'OVERLAP';
}

/**
 * Applies the mandatory time-of-day size control. A fractional contract is
 * intentionally floored to zero; order admission treats that as no trade.
 */
export function applyTimeOfDaySizeMultiplier(
  contracts: number,
  timeOfDayRegime: TimeOfDayRegime,
): number {
  return timeOfDayRegime === 'ASIAN_HOURS'
    ? Math.floor(contracts * ASIAN_HOURS_SIZE_MULT)
    : contracts;
}

/**
 * Preserves the liquidity haircut as a final ceiling when a later sizing
 * modifier is allowed to increase the contract count.
 */
export function capContractsToLiquidityLimit(
  contracts: number,
  liquidityLimit: number | null,
): number {
  return liquidityLimit === null ? contracts : Math.min(contracts, liquidityLimit);
}

/**
 * Minimum unrealised gain per contract (¢) before the bot considers adding
 * to a position. Below this the trade is not yet profitable enough to scale in.
 */
export const ADD_POSITION_MIN_PROFIT_CENTS = 8;

/**
 * Minimum unrealised gain per contract (¢) required to avoid a time-stop exit
 * when very little time remains in the period.
 */
export const TIME_STOP_MIN_GAIN_CENTS = 5;

/**
 * WebSocket consecutive-failure count that triggers the "degraded" state.
 * In degraded state the bot pauses new entries until WS reconnects.
 */
export const WS_DEGRADED_THRESHOLD = 5;

/**
 * How long a live trade may sit with Kalshi's settlement API unavailable/no
 * match before settlement gives up and marks the trade "unresolved" instead
 * of retrying forever. Generous enough to ride out a real Kalshi API outage
 * (retried every tick + every watchdog forceSettleCheck), bounded so a dead
 * trade doesn't block the bot indefinitely. NEVER used to justify inferring
 * a win/loss from a proxy price — timeout means "give up cleanly", not
 * "guess". See settlement-fallback-unresolved.md.
 */
export const SETTLEMENT_UNRESOLVED_TIMEOUT_MS = 5 * 60 * 1_000;

// ── Velocity acceleration ─────────────────────────────────────────────────────

/**
 * Confidence bonus (pts) when velocity is accelerating IN the trade direction.
 * "Momentum building" — more likely to persist through settlement.
 */
export const ACCEL_CONF_BONUS = 4;

/**
 * Confidence penalty (pts) when velocity is decelerating (fading against the signal).
 * "Fast but slowing" — the move may reverse before settlement.
 */
export const ACCEL_CONF_PENALTY = 5;

// ── Settlement streak (mean-reversion pressure) ───────────────────────────────

/**
 * Number of consecutive same-direction settlements before mean-reversion
 * pressure is applied. BTC 15-min contracts show strong negative serial
 * correlation after runs of 4+ in the same direction.
 */
export const STREAK_FADE_THRESH = 4;

/**
 * Confidence penalty (pts) for trading WITH an over-extended streak.
 * The statistical edge shifts against continuation after STREAK_FADE_THRESH.
 */
export const STREAK_CONF_PENALTY = 5;

/**
 * Confidence bonus (pts) for fading an over-extended streak (trading AGAINST).
 * Mean reversion trades gain structural edge when a streak is historically extended.
 */
export const STREAK_CONF_BONUS = 4;

/**
 * Bonus (pts) when the period pattern is alternating AND the trade fades the
 * last move. Alternating up/down patterns have high fade-win-rates on BTC 15m.
 */
export const ALTERNATING_FADE_BONUS = 4;

// ── Regime clarity ────────────────────────────────────────────────────────────

/**
 * Confidence bonus (pts) when the Grok regime is confirmed trending AND
 * the signal aligns with the trend. Trend-following in a confirmed trend
 * historically outperforms vs entering against regime.
 */
export const REGIME_TREND_CONF_BONUS = 3;

/**
 * Confidence penalty (pts) when the Grok regime is unclear or transitioning
 * without a strong velocity signal. Entering in ambiguous conditions lowers
 * expected win rate.
 */
export const REGIME_UNCLEAR_CONF_PENALTY = 3;

// ── Entry price band (standard, non-OTM strategies) ────────────────────────

/**
 * Live/paper entry-price gate for standard (non-OTM) strategies — mirrors
 * trading-bot.ts's default minEntryPrice/maxEntryPrice BotConfig fields.
 * Any backtest/simulation that scores standard strategies MUST apply this
 * same band, or it will "trade" prices the live bot would never take (e.g.
 * buying a near-certain 90-95¢ outcome for pennies of upside) — this was the
 * root cause of Sim Lab showing high win-rate / negative-EV strategies that
 * don't reflect what actually executes live (Task #368).
 * OTM strategies (OTM_ASYMMETRY, OTM_BREAKOUT_EXPANSION, DEEP_OTM_SNIPER)
 * intentionally trade outside this band and are exempt — they're gated by
 * their own EV/payout-multiple checks instead.
 */
export const STANDARD_ENTRY_MIN_CENTS = 20;
/** PAPER DESK v2: NO ask floor (same 20 as YES). */
export const STANDARD_NO_ENTRY_MIN_CENTS = 20;
export const STANDARD_ENTRY_MAX_CENTS = 55;

/** Strategy IDs that use a non-standard entry-price band (see ENTRY_PRICE_BANDS). */
export const OTM_STRATEGY_IDS: readonly string[] = ['OTM_ASYMMETRY', 'OTM_BREAKOUT_EXPANSION', 'DEEP_OTM_SNIPER'];

// 2026-08-05: LATE_ENTRY_ANCHOR only fires 3-8 min before settlement with a
// designed confidence range of 72-92% (strategy-library.ts) — a real market
// pricing its side at 72-92% naturally quotes 70-92¢, but the standard band's
// 62¢ ceiling structurally blocked almost every signal this strategy could
// ever produce (confirmed via 4 days of skip logs: 35 ENTRY_PRICE_BAND skips,
// entries priced 63-99¢, none ever cleared). This was a gate/strategy design
// mismatch, not a deliberate risk control — EV_FLOOR and OVERPAY_GATE remain
// active downstream and still reject a genuinely bad-priced entry.

/**
 * Per-strategy live entry-price bands (cents), mirroring the exact gates
 * enforced in trading-bot.ts at order-placement time. A blanket "OTM
 * strategies trade anywhere" exemption is WRONG — each OTM strategy has its
 * own tight, research-backed sweet spot, and simulating them at any price
 * from 5-95¢ reintroduces the same unrealistic-trade-universe bug this
 * band gate exists to prevent (Task #368 code review).
 *
 *  - OTM_ASYMMETRY:          5-25¢  (trading-bot.ts OTM_MAX_ENTRY = 25)
 *  - DEEP_OTM_SNIPER:        5-14¢  (trading-bot.ts SNIPER_MAX_ENTRY = 14)
 *  - OTM_BREAKOUT_EXPANSION: 11-38¢ (trading-bot.ts 1H "sweet-spot" gate)
 *  - LATE_ENTRY_ANCHOR:      28-85¢ (matches its 72-92% designed confidence range)
 *  - PAPER_SCALP:            7-55¢  (intra ticket-velocity scalp; size 1, STRATEGY_PAPER_ONLY)
 *  - everything else:        STANDARD_ENTRY_MIN/MAX_CENTS (20-55¢)
 *
 * If trading-bot.ts's gates change, update this map in lockstep or backtests
 * will silently drift from what the live bot actually trades.
 */
export const ENTRY_PRICE_BANDS: Record<string, { min: number; max: number }> = {
  OTM_ASYMMETRY:          { min: 5,  max: 25 },
  DEEP_OTM_SNIPER:        { min: 5,  max: 14 },
  OTM_BREAKOUT_EXPANSION: { min: 11, max: 38 },
  LATE_ENTRY_ANCHOR:      { min: 28, max: 85 },
  // 2026-08-12: BASIS_LAG_EDGE reads an exchange-led projection, so it can
  // have real, persistent, EV-positive edge (its own MIN_EDGE_PTS/persistence
  // gates already require this) while Kalshi's own ask is still priced deep
  // OTM — the whole thesis is "the market hasn't caught up yet". The generic
  // 28¢ standard-band floor was blocking exactly those setups (observed: a
  // 7¢-ask lag setup with a confirmed OTM→ITM projection was skipped by this
  // gate, not by the strategy's own edge/persistence checks). Lowered to 10¢
  // for this strategy only — max aligned to fill-power lock 55¢.
  BASIS_LAG_EDGE:         { min: 20, max: 55 }, // desk door floor 20; side-aware aligned/W2
  CHEAP_SIDE_15M:         { min: 20, max: 47 },
  // Paper scalp fills its own intra band (7–55¢), matching isIntraAskBand.
  // Size stays 1. STRATEGY_PAPER_ONLY still blocks live. Not a standard-band
  // strategy — without this row, getEntryPriceBand falls back to 28–55 and
  // paper-scalp never fills 7–27¢.
  PAPER_SCALP:            { min: 7,  max: 55 },
};

/**
 * Generic band for any NON-breakout strategy trading a 60-minute (hourly)
 * contract — the hourly poller's own comment: "below 15¢ they're fighting an
 * 85%+ implied disagreement they weren't designed for; above 85¢ the edge is
 * gone after fees." This is intentionally wider than the 15-minute standard
 * band (20-55¢) — hourly contracts move more before settlement, so a wider
 * entry range still reflects real tradeable edge.
 */
export const HOURLY_GENERIC_MIN_CENTS = 15;
export const HOURLY_GENERIC_MAX_CENTS = 85;

export interface EntryPriceBandOptions {
  /** 15 (default) or 60 — selects the hourly generic band for non-OTM strategies. */
  contractDurationMins?: number;
  /**
   * The live bot's CURRENT effective minEntryPrice/maxEntryPrice for standard
   * strategies (config value as adjusted by the adaptive-condition overlay /
   * ARIA setup control this tick). When omitted, falls back to the static
   * STANDARD_ENTRY_MIN/MAX_CENTS defaults — which is what both backtest
   * engines use today, since neither replays the live per-tick adaptive/ARIA
   * overlay stack. Passing the real effective values (as trading-bot.ts does)
   * is what keeps the live gate authoritative; the backtest default is a
   * documented approximation, not a claim of full dynamic parity.
   */
  effectiveMin?: number;
  effectiveMax?: number;
  /** PAPER DESK v2: side-aware NO floor 20. */
  side?: "yes" | "no";
  effectiveMinNo?: number;
}

/** Resolves the live entry-price band (cents) for a given strategy id. */
export function getEntryPriceBand(strategyId: string, opts: EntryPriceBandOptions = {}): { min: number; max: number } {
  const fixed = ENTRY_PRICE_BANDS[strategyId];
  if (fixed) {
    // CHEAP YES/NO both use desk floor 20.
    if (strategyId === "CHEAP_SIDE_15M" && opts.side === "yes") {
      return { min: 20, max: fixed.max };
    }
    return fixed;
  }
  if (opts.contractDurationMins === 60) {
    return { min: HOURLY_GENERIC_MIN_CENTS, max: HOURLY_GENERIC_MAX_CENTS };
  }
  const stdMin = opts.side === "no"
    ? (opts.effectiveMinNo ?? STANDARD_NO_ENTRY_MIN_CENTS)
    : (opts.effectiveMin ?? STANDARD_ENTRY_MIN_CENTS);
  return {
    min: stdMin,
    max: opts.effectiveMax ?? STANDARD_ENTRY_MAX_CENTS,
  };
}

// ── Universal price-band gate (master bot upgrade step 2) ──────────────────
// A second, first-class gate on top of getEntryPriceBand()'s per-strategy min/
// max: it screens EVERY non-exempt entry by how expensive the ask actually
// is, independent of which strategy's own band it already cleared. Cheap asks
// (real edge, low cost-of-being-wrong) trade full size; the priciest asks
// (market already agrees with us — little edge left after fees) are skipped
// outright unless a late-anchor/lag strategy has a genuinely extreme,
// freshly-confirmed displacement from fair value AND time is almost up.
export type PriceBandTier = 'full' | 'standard' | 'half' | 'skip';

/** Strategies allowed the strict "late exception" out of the 56¢+ tiers — see getUniversalPriceBandTier. */
export const PRICE_BAND_LATE_EXCEPTION_STRATEGIES: ReadonlySet<string> = new Set([
  'BASIS_LAG_EDGE', 'LATE_ENTRY_ANCHOR', 'FLOOR_DISTANCE', 'EXHAUSTION_ANCHOR', 'LATE_MOMENTUM_CONTINUATION',
]);

/** Same 0.05% fair-displacement bar used for PRESS-tier stack sizing — "extreme" is a real, not marginal, gap from fair value. */
export const PRICE_BAND_EXTREME_DISPLACEMENT_PCT = 0.05;

export const PRICE_BAND_FULL_MAX_CENTS     = 45;
export const PRICE_BAND_STANDARD_MAX_CENTS = 55;
export const PRICE_BAND_HALF_MAX_CENTS     = 70;
export const PRICE_BAND_LATE_MAX_MINS_LEFT = 5;

/**
 * Profit Doctrine Phase 1 — RICH_ASK_BLOCK extra EV margin.
 * Any ask ≥PRICE_BAND_HALF_MAX_CENTS must clear the path's ordinary EV floor
 * by this additional amount (not just the bare floor) before it's admitted,
 * on top of requiring lag/basis agreement with the trade side. A rich ask
 * bleeds fast on any near-miss, so the ordinary floor alone is not enough.
 */
export const RICH_ASK_EXTRA_EV_MARGIN_CENTS = 3;

export interface PriceBandGateInput {
  askCents: number;
  strategyId: string;
  /** Prefer the fresh fair-value anchor (fairDistFromFloorPct); falls back to raw distFromFloorPct when fair value is stale/unavailable. */
  displacementPct: number | undefined;
  minsLeft: number;
}

export interface PriceBandGateResult {
  tier: PriceBandTier;
  /** true when an exempt late-anchor/lag strategy's extreme-displacement exception lifted a would-be half/skip tier. */
  exceptionApplied: boolean;
  /** Size multiplier to fold into the normal sizing chain — 1 for full/standard/exempted, 0.5 for half. skip means no order at all. */
  sizeMult: number;
}

/**
 * Universal ask-price tier gate — evaluated in addition to (never instead of)
 * each strategy's own getEntryPriceBand() min/max. Runs before the EV/
 * PATH_GATE checks so an expensive, EV-marginal ask never even reaches them;
 * a late-anchor/lag strategy's exception only lifts the tier restriction here
 * — the normal EV floor and PATH_GATE downstream still have final say.
 */
export function getUniversalPriceBandTier(input: PriceBandGateInput): PriceBandGateResult {
  const { askCents, strategyId, displacementPct, minsLeft } = input;
  const isLateException = PRICE_BAND_LATE_EXCEPTION_STRATEGIES.has(strategyId);
  const hasExtremeDisplacement = displacementPct != null && Math.abs(displacementPct) >= PRICE_BAND_EXTREME_DISPLACEMENT_PCT;

  if (askCents <= PRICE_BAND_FULL_MAX_CENTS) {
    return { tier: 'full', exceptionApplied: false, sizeMult: 1 };
  }
  if (askCents <= PRICE_BAND_STANDARD_MAX_CENTS) {
    return { tier: 'standard', exceptionApplied: false, sizeMult: 1 };
  }
  if (askCents <= PRICE_BAND_HALF_MAX_CENTS) {
    if (isLateException && hasExtremeDisplacement) {
      return { tier: 'half', exceptionApplied: true, sizeMult: 1 };
    }
    return { tier: 'half', exceptionApplied: false, sizeMult: 0.5 };
  }
  // > 70¢: skip unless extreme displacement + <=5 min left — EV/PATH_GATE
  // downstream still enforce "EV clearly passes" on whatever gets through.
  if (isLateException && hasExtremeDisplacement && minsLeft <= PRICE_BAND_LATE_MAX_MINS_LEFT) {
    return { tier: 'skip', exceptionApplied: true, sizeMult: 1 };
  }
  return { tier: 'skip', exceptionApplied: false, sizeMult: 0 };
}

// ── Hunt vs Harvest session mode (master bot upgrade step 3) ──────────────────
//
// See getSessionMode() in market-intelligence.ts for the HUNT/HARVEST hour
// boundaries. These are the HARVEST-only restrictions layered on top of the
// universal price-band gate above; HUNT makes no changes to family
// eligibility or sizing (regime/counter-trend gates already handle it).

/**
 * Families allowed to trade during HARVEST — the basis-lag and
 * late-displacement families (lag/anchor/continuation strategies). Every
 * other family (momentum, breakout, mean-reversion, pattern,
 * probability-model) is suppressed outright regardless of regime fit.
 * Deliberately the *same* strategy set as PRICE_BAND_LATE_EXCEPTION_STRATEGIES
 * — the strategies allowed to trade thin hours are exactly the ones exempted
 * from the tightest price bands, which is why HARVEST's stricter ask ceiling
 * below reuses that same exception rather than inventing a second list.
 */
export const HARVEST_ALLOWED_FAMILIES: ReadonlySet<string> = new Set([
  'basis-lag', 'late-displacement',
]);

/** Flat position-size multiplier applied to every HARVEST-session trade (0.5–0.7× per spec; 0.6× chosen as the midpoint). */
export const HARVEST_SIZE_MULT = 0.6;

/**
 * Stricter ask ceiling during HARVEST: above this, skip outright unless the
 * strategy is in PRICE_BAND_LATE_EXCEPTION_STRATEGIES AND shows the same
 * extreme (>= PRICE_BAND_EXTREME_DISPLACEMENT_PCT) fair-value displacement
 * required elsewhere — no separate "quality gate" concept, reuses the
 * existing one. Independent of (and evaluated before) the universal
 * full/standard/half/skip tiers, which still apply on top for the strategies
 * that clear this ceiling.
 */
export const HARVEST_ASK_MAX_CENTS = 50;

// ── Stack size tiers: probe/standard/press (master bot upgrade step 4) ────────
//
// Sizes from the quality of the confirming signal *stack* for this trade, not
// from confidence alone. Evaluated once the trade has already cleared EV,
// PATH_GATE, and the universal price-band/HARVEST gates above — this layer
// only adjusts how big the already-approved trade is, it never approves or
// blocks a trade. Combined multiplicatively with priceBandMult/harvestMult at
// the same point in the sizing chain, before the portfolio-risk band clamp
// and the final 9%/absolute hard caps, so it can only ever move a trade
// within limits that already exist.

export type SizeTier = 'probe' | 'standard' | 'press';

/** Lone, non-lag/anchor signal — the default/catch-all tier. */
export const PROBE_SIZE_MULT = 0.5;
/** Full lag+anchor confirmation stack cleared — still bound by the 9%/absolute/maxContracts caps downstream. */
export const PRESS_SIZE_MULT = 1.5;

/**
 * Same-ticker cooldown after a losing exit or a THESIS_BREAK_EXIT/LAG_FLIP_EXIT
 * close (regardless of P&L sign on those two, since both mean "the thesis we
 * traded on just proved wrong"). Unlike thesisBreakCooldownUntil, this does
 * NOT block re-entry — it only prevents PRESS-tier sizing on the next trade
 * for this ticker, so a cautious re-entry is still possible.
 */
export const STACK_PRESS_COOLDOWN_MS = 30 * 60 * 1000;

export interface StackTierInput {
  /** Ask price (cents) already resolved for this trade's side. */
  askCents: number;
  /** Minutes left in the contract. */
  minsLeft: number;
  /** Strategy family of the selected/winning strategy for this trade (see getStrategyFamily()). */
  primaryFamily: string;
  /** True if the primary strategy is in PRICE_BAND_LATE_EXCEPTION_STRATEGIES (an explicit late-window design). */
  isLateWindowStrategy: boolean;
  /**
   * True when this trade was only admitted via the universal price-band's
   * >55¢ half/skip-exception tiers — that layer already priced it, so the
   * stack-tier layer stays neutral (`standard`, ×1) instead of inventing a
   * 4th tier for an ask range PROBE/STANDARD/PRESS were never meant to cover.
   */
  askAboveStandardCeiling: boolean;
  /** Basis-lag projected-settlement direction agrees with this trade's side, with BASIS_LAG_EDGE's own persistence guard (basisStreakSign/Count) — not a fresh concept, its existing gate evaluated independently of which strategy fired as primary. */
  projAgreesWithSide: boolean;
  /** Basis-lag projection exists and points AWAY from this trade's side — hard PRESS block regardless of everything else. */
  projDisagreesWithSide: boolean;
  /** Fair-value displacement from floor, % (fairDistFromFloorPct preferred, distFromFloorPct fallback) — the same field the universal price-band gate uses. */
  displacementPct: number | undefined;
  /** True while this ticker is within STACK_PRESS_COOLDOWN_MS of a losing/THESIS_BREAK/LAG_FLIP close. */
  inPressCooldown: boolean;
  /** Current Hunt/Harvest session mode (see getSessionMode() in market-intelligence.ts). */
  sessionMode: 'HUNT' | 'HARVEST';
  /**
   * HARVEST-only, stricter PRESS bar: true when lag agrees AND a
   * late-displacement-family strategy ALSO fired the same side this tick —
   * real cross-family corroboration, not just the primary strategy's own
   * family. Ignored outside HARVEST.
   */
  harvestExceptionalStack: boolean;
}

export interface StackTierResult {
  tier: SizeTier;
  sizeMult: number;
  reasons: string[];
}

/**
 * Pure classifier — see the master-bot-upgrade-step4 design doc for the
 * approved decision table. Precedence is PRESS, then STANDARD, then PROBE as
 * the catch-all; every condition here reuses an existing signal/threshold
 * (basis-lag projection + persistence guard, the 0.05% displacement bar, the
 * late-exception strategy set) rather than introducing a new one.
 */
export function computeStackTier(input: StackTierInput): StackTierResult {
  const {
    askCents, minsLeft, primaryFamily, isLateWindowStrategy, askAboveStandardCeiling,
    projAgreesWithSide, projDisagreesWithSide, displacementPct, inPressCooldown,
    sessionMode, harvestExceptionalStack,
  } = input;

  if (askAboveStandardCeiling) {
    return {
      tier: 'standard', sizeMult: 1,
      reasons: ['ask above 55¢ standard ceiling — already sized by the universal price-band gate, neutral stack mult'],
    };
  }

  const isLagOrAnchorPrimary = HARVEST_ALLOWED_FAMILIES.has(primaryFamily);
  const pressBlockedReasons: string[] = [];

  if (askCents <= HARVEST_ASK_MAX_CENTS && !projDisagreesWithSide && !inPressCooldown) {
    const displacementOk = displacementPct != null && Math.abs(displacementPct) >= PRICE_BAND_EXTREME_DISPLACEMENT_PCT;
    const timeOk = minsLeft >= PRICE_BAND_LATE_MAX_MINS_LEFT || isLateWindowStrategy;
    if (projAgreesWithSide && displacementOk && timeOk) {
      if (sessionMode === 'HARVEST' && !harvestExceptionalStack) {
        pressBlockedReasons.push('HARVEST: lag+anchor stack not exceptional — press capped to standard');
      } else {
        const reasons = [
          'lag projection agrees with side',
          `fair displacement ${displacementPct!.toFixed(3)}% >= ${PRICE_BAND_EXTREME_DISPLACEMENT_PCT}%`,
          minsLeft >= PRICE_BAND_LATE_MAX_MINS_LEFT ? `${minsLeft.toFixed(1)}min left` : 'explicit late-window strategy',
        ];
        if (sessionMode === 'HARVEST') reasons.push('HARVEST exceptional lag+anchor stack confirmed');
        return { tier: 'press', sizeMult: PRESS_SIZE_MULT, reasons };
      }
    } else {
      if (!projAgreesWithSide) pressBlockedReasons.push('lag does not confirm this side');
      if (!displacementOk) pressBlockedReasons.push('fair displacement below 0.05% gate');
      if (!timeOk) pressBlockedReasons.push(`${minsLeft.toFixed(1)}min left, not a late-window strategy`);
    }
  } else {
    if (askCents > HARVEST_ASK_MAX_CENTS) pressBlockedReasons.push(`ask ${askCents}¢ > ${HARVEST_ASK_MAX_CENTS}¢ press ceiling`);
    if (projDisagreesWithSide) pressBlockedReasons.push('lag disagrees with side — press blocked');
    if (inPressCooldown) pressBlockedReasons.push('post-loss/THESIS_BREAK/LAG_FLIP same-ticker press cooldown active');
  }

  if (askCents <= PRICE_BAND_STANDARD_MAX_CENTS && isLagOrAnchorPrimary) {
    return { tier: 'standard', sizeMult: 1, reasons: [`primary family '${primaryFamily}' is lag/anchor`, ...pressBlockedReasons] };
  }

  return {
    tier: 'probe', sizeMult: PROBE_SIZE_MULT,
    reasons: [
      isLagOrAnchorPrimary
        ? `primary family '${primaryFamily}' is lag/anchor but press conditions not met`
        : `primary family '${primaryFamily}' is not lag/anchor`,
      ...pressBlockedReasons,
    ],
  };
}

/**
 * Execution-quality guardrails. Once the current ET day's live fills provide a
 * minimally useful sample and their average adverse slippage exceeds this
 * threshold, live order admission uses that observed average as a floor for
 * expected slippage. This can only make an EV calculation more conservative.
 */
export const KALSHI_FILL_QUALITY_MIN_SAMPLES = 10;

export function observedSlippageFloorCents(opts: {
  slippageSamples: number;
  averageSlippageCents: number | null;
}): number | null {
  if (
    opts.slippageSamples < KALSHI_FILL_QUALITY_MIN_SAMPLES ||
    opts.averageSlippageCents === null ||
    !Number.isFinite(opts.averageSlippageCents) ||
    opts.averageSlippageCents <= KALSHI_FILL_QUALITY_HIGH_SLIPPAGE_CENTS
  ) {
    return null;
  }
  return Math.min(opts.averageSlippageCents, KALSHI_MAX_EXPECTED_SLIPPAGE_CENTS);
}

export const KALSHI_FILL_QUALITY_HIGH_SLIPPAGE_CENTS = 2.5;
