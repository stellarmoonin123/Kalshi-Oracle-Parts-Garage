/**
 * kalshi-order-body.ts
 *
 * Pure helper that converts the internal KalshiOrderInput representation
 * (contracts / pricePerContract) into the Kalshi V2 REST API body
 * (count / price).  Extracted so it can be unit-tested independently of
 * the HTTP route and the trading bot.
 *
 * Kalshi V2 API conventions:
 *   - side:  "bid" to buy YES; "ask" to buy NO (close YES position)
 *   - count: number of contracts, sent as a string
 *   - price: the YES price expressed in dollars (not cents), e.g. "0.45" = 45¢
 *             For a YES buy this is pricePerContract / 100
 *             For a NO  buy this is (100 - pricePerContract) / 100
 */

export interface KalshiV2OrderBody {
  ticker: string;
  side: "bid" | "ask";
  count: string;
  price: string;
  time_in_force: "good_till_canceled";
  self_trade_prevention_type: "taker_at_cross";
  post_only: false;
  cancel_order_on_pause: false;
  reduce_only: boolean;
  /** D7 — idempotency key: one per order intent, reused on retries of that
   *  intent so a retry after a timeout/5xx cannot double-fill. */
  client_order_id?: string;
}

/**
 * D7 — deterministic client_order_id from intent identity parts (e.g. the
 * trade-intent DB id, or exit journal key + sold count). Same parts → same id,
 * so a re-POST of the same intent is deduped by Kalshi. ≤ 40 chars.
 */
export function stableClientOrderId(kind: "entry" | "exit" | "add" | "manual", ...parts: Array<string | number>): string {
  // FNV-1a 64 → hex, twice with different seeds; no crypto import needed in the pure helper.
  const h = (seed: bigint) => {
    let x = seed;
    for (const ch of [kind, ...parts.map(String)].join("|")) {
      x ^= BigInt(ch.codePointAt(0)!);
      x = (x * 0x100000001b3n) & 0xffffffffffffffffn;
    }
    return x.toString(16).padStart(16, "0");
  };
  return `oc-${kind}-${h(0xcbf29ce484222325n)}${h(0x84222325cbf29ce4n)}`.slice(0, 40);
}

/**
 * Build the Kalshi V2 REST API body for an EXIT (sell/close) order.
 *
 * Exit semantics differ from entry:
 *   - Sell YES → offer YES (ask side).  Price = what we accept per YES contract.
 *                sweepBuf is subtracted from exitPriceCents so we accept slightly
 *                less and guarantee a fill during adverse moves (stop exits).
 *   - Close NO → buy YES to cancel the NO position (bid side).
 *                sweepBuf is added to the YES-equivalent price so our bid
 *                crosses the spread and fills immediately.
 *
 * @param ticker          - Kalshi market ticker
 * @param side            - "yes" or "no" from the bot's perspective (the open position side)
 * @param contracts       - number of contracts to close
 * @param exitPriceCents  - current exit price in whole cents (the YES side price)
 * @param sweepBuf        - sweep buffer in whole cents (0 for profit exits, >0 for stop exits)
 */
export function buildKalshiV2ExitBody(
  ticker: string,
  side: "yes" | "no",
  contracts: number,
  exitPriceCents: number,
  sweepBuf: number,
  clientOrderId?: string,
): KalshiV2OrderBody {
  // YES sell → ask side; accept slightly less than market to guarantee fill on stops
  // NO close → bid side; bid YES-equivalent price + sweep to cross the spread
  const v2Side: "bid" | "ask" = side === "yes" ? "ask" : "bid";
  const rawCents =
    side === "yes"
      ? Math.max(1, exitPriceCents - sweepBuf)
      : Math.min(99, 100 - exitPriceCents + sweepBuf);
  const v2Price = (rawCents / 100).toFixed(2);

  return {
    ticker,
    side: v2Side,
    count: String(contracts),
    price: v2Price,
    time_in_force: "good_till_canceled",
    self_trade_prevention_type: "taker_at_cross",
    post_only: false,
    cancel_order_on_pause: false,
    // 2026-08-18 INCIDENT: `reduce_only: true` was added here on 2026-08-18
    // 01:03 UTC to defend against a real 2026-08-17 duplicate-exit-order
    // incident (see below). It caused Kalshi's V2 order API to reject
    // EVERY exit order placed since then with HTTP 400 "invalid order" —
    // LAG_FLIP_EXIT, THESIS_BREAK_EXIT, and even the unconditional
    // HARD_STOP_EXIT all failed silently, forcing every live position for
    // ~1.5 days to ride to settlement or an externally-inferred close
    // instead of stopping out. Confirmed via bot_trades.exit_reason: zero
    // successful LAG_FLIP_EXIT/THESIS_BREAK_EXIT rows after the commit vs.
    // regular successes before it. Reverted to false, the value that was
    // proven working for weeks before 2026-08-18.
    //
    // The original 2026-08-17 problem this was meant to fix — a duplicate
    // exit retry during a Kalshi confirmation outage got filled as a
    // brand-new opposite-direction position, turning an 11-contract exit
    // into ~$129 (≈40% of the account) of unintended exposure — is still
    // guarded by the in-process pre-order position check in exitEarly()
    // (fetchKalshiPosition before every attempt; aborts if Kalshi already
    // shows the position flat or smaller than tracked). Do not re-add
    // reduce_only:true without first confirming against a real (non-
    // production) order that Kalshi's API actually accepts it — it
    // demonstrably does not on this account/market type today.
    reduce_only: false,
    ...(clientOrderId ? { client_order_id: clientOrderId } : {}),
  };
}

/**
 * Build the Kalshi V2 REST API body from the bot's internal order fields.
 *
 * @param ticker          - Kalshi market ticker
 * @param side            - "yes" or "no" from the bot's perspective
 * @param contracts       - number of contracts (KalshiOrderInput.contracts)
 * @param pricePerContract - price in whole cents 1–99 (KalshiOrderInput.pricePerContract)
 */
/**
 * Returns true when pricePerContract is within Kalshi's accepted 1–99¢ range.
 * Used by the order route and can be imported in tests.
 */
export function isValidKalshiPrice(pricePerContract: number): boolean {
  return Number.isFinite(pricePerContract) && pricePerContract >= 1 && pricePerContract <= 99;
}

export function buildKalshiV2Body(
  ticker: string,
  side: "yes" | "no",
  contracts: number,
  pricePerContract: number,
  clientOrderId?: string,
): KalshiV2OrderBody {
  const v2Side: "bid" | "ask" = side === "yes" ? "bid" : "ask";

  // YES buy: bid at yes ask price in dollars
  // NO  buy: ask at the converted YES equivalent price
  const v2Price =
    side === "yes"
      ? (pricePerContract / 100).toFixed(2)
      : ((100 - pricePerContract) / 100).toFixed(2);

  return {
    ticker,
    side: v2Side,
    count: String(contracts),
    price: v2Price,
    time_in_force: "good_till_canceled",
    self_trade_prevention_type: "taker_at_cross",
    post_only: false,
    cancel_order_on_pause: false,
    reduce_only: false,
    ...(clientOrderId ? { client_order_id: clientOrderId } : {}),
  };
}
