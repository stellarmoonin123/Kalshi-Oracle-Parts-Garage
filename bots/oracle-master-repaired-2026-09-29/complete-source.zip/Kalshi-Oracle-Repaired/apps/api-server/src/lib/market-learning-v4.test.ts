import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  timeBucketFor,
  sigmoid,
  fitStandardizeStats,
  applyStandardize,
  trainLogisticRegression,
  predictLogit,
  fitIsotonic,
  applyIsotonic,
  purgedWalkForwardFolds,
  LIVE_EV_FLOOR_CENTS_MIRROR_V4,
  type WalkForwardRow,
} from "./market-learning-v4.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ── EV-floor parity (source-text regex read — NEVER import trading-bot.ts) ──
// Per .agents/memory/node-test-import-isolation.md: node:test imports must
// not revive the bot singleton, call external feeds, or retain startup
// timers. trading-bot.ts's import graph does all three at module load, so
// this test reads its source text as a plain string and regex-extracts the
// real constant instead of importing it.
test("LIVE_EV_FLOOR_CENTS_MIRROR_V4 matches admission.ts's real EV_FLOOR constant", () => {
  const src = fs.readFileSync(path.join(__dirname, "admission.ts"), "utf8");
  const match = src.match(/export const EV_FLOOR\s*=\s*(\d+)/);
  assert.ok(match, "EV_FLOOR constant not found in admission.ts — has it been renamed?");
  const liveValue = Number(match![1]);
  assert.equal(LIVE_EV_FLOOR_CENTS_MIRROR_V4, liveValue,
    "market-learning-v4.ts's mirrored EV floor has drifted from admission.ts's real EV_FLOOR");
});

test("timeBucketFor assigns the three documented buckets correctly", () => {
  assert.equal(timeBucketFor(900), "12-8m");
  assert.equal(timeBucketFor(481), "12-8m");
  assert.equal(timeBucketFor(480), "8-3m");
  assert.equal(timeBucketFor(181), "8-3m");
  assert.equal(timeBucketFor(180), "<3m");
  assert.equal(timeBucketFor(5), "<3m");
});

test("sigmoid is bounded in (0,1) and monotone", () => {
  // Use a moderate magnitude (not +/-50) — at extreme |z| floating-point
  // precision rounds sigmoid to exactly 0 or 1, which would make a strict
  // "< 1" / "> 0" bound assertion flaky rather than testing real behavior.
  assert.ok(sigmoid(-15) > 0 && sigmoid(-15) < 0.001);
  assert.ok(sigmoid(15) < 1 && sigmoid(15) > 0.999);
  assert.equal(sigmoid(0), 0.5);
  assert.ok(sigmoid(1) > sigmoid(0));
});

test("fitStandardizeStats + applyStandardize zero-centers and unit-scales a column", () => {
  const rows = [[1, 10], [2, 20], [3, 30], [4, 40]];
  const stats = fitStandardizeStats(rows);
  const standardized = rows.map(r => applyStandardize(r, stats));
  const col0Mean = standardized.reduce((s, r) => s + r[0], 0) / standardized.length;
  assert.ok(Math.abs(col0Mean) < 1e-9, "standardized column should have ~zero mean");
});

test("fitStandardizeStats never divides by zero on a constant column", () => {
  const rows = [[5, 1], [5, 2], [5, 3]];
  const stats = fitStandardizeStats(rows);
  const standardized = applyStandardize([5, 2], stats);
  assert.ok(Number.isFinite(standardized[0]));
});

test("trainLogisticRegression separates a trivially separable dataset", () => {
  // Feature 0 alone perfectly predicts the label.
  const X = [[-3], [-2], [-1], [1], [2], [3]];
  const y = [0, 0, 0, 1, 1, 1];
  const model = trainLogisticRegression(X, y, { iters: 800, lr: 0.5 });
  assert.ok(predictLogit(model, [3]) > 0.9, "should confidently predict positive class far above the boundary");
  assert.ok(predictLogit(model, [-3]) < 0.1, "should confidently predict negative class far below the boundary");
});

test("trainLogisticRegression on empty input returns a harmless zero model", () => {
  const model = trainLogisticRegression([], []);
  assert.equal(model.weights.length, 0);
  assert.equal(model.bias, 0);
});

test("fitIsotonic produces a monotone-nondecreasing calibration map", () => {
  const pairs = [
    { x: 0.1, y: 0 }, { x: 0.2, y: 0 }, { x: 0.3, y: 1 }, { x: 0.4, y: 0 },
    { x: 0.5, y: 1 }, { x: 0.6, y: 1 }, { x: 0.7, y: 1 }, { x: 0.8, y: 1 },
  ];
  const cal = fitIsotonic(pairs);
  for (let i = 1; i < cal.ys.length; i++) {
    assert.ok(cal.ys[i] >= cal.ys[i - 1] - 1e-9, "isotonic calibration must never decrease");
  }
});

test("applyIsotonic on empty calibrator returns a neutral 0.5", () => {
  const cal = fitIsotonic([]);
  assert.equal(applyIsotonic(cal, 0.7), 0.5);
});

// ── Purged walk-forward embargo ─────────────────────────────────────────────

function makeRows(n: number, periodWidthMs: number): WalkForwardRow[] {
  return Array.from({ length: n }, (_, i) => ({
    periodStartMs: i * periodWidthMs,
    features: [i],
    label: i % 2,
  }));
}

test("purgedWalkForwardFolds drops train rows inside the embargo window around each OOS fold", () => {
  const periodWidthMs = 15 * 60_000;
  const rows = makeRows(30, periodWidthMs);
  const folds = purgedWalkForwardFolds(rows, 3, 1, periodWidthMs);
  for (const fold of folds) {
    if (fold.trainIdx.length === 0 || fold.oosIdx.length === 0) continue;
    const oosMin = Math.min(...fold.oosIdx.map(i => rows[i].periodStartMs));
    const oosMax = Math.max(...fold.oosIdx.map(i => rows[i].periodStartMs));
    for (const ti of fold.trainIdx) {
      const ts = rows[ti].periodStartMs;
      const withinEmbargo = ts >= oosMin - periodWidthMs && ts <= oosMax + periodWidthMs;
      assert.ok(!withinEmbargo, `train row at ${ts} should have been embargoed out (OOS spans ${oosMin}-${oosMax})`);
    }
  }
});

test("purgedWalkForwardFolds never lets an OOS row leak into its own fold's train set", () => {
  const periodWidthMs = 15 * 60_000;
  const rows = makeRows(30, periodWidthMs);
  const folds = purgedWalkForwardFolds(rows, 3, 1, periodWidthMs);
  for (const fold of folds) {
    const oosSet = new Set(fold.oosIdx);
    for (const ti of fold.trainIdx) assert.ok(!oosSet.has(ti), "a row cannot be in both train and OOS for the same fold");
  }
});

test("purgedWalkForwardFolds handles a too-small dataset by returning everything as OOS with no train (INSUFFICIENT_DATA path)", () => {
  const rows = makeRows(3, 15 * 60_000);
  const folds = purgedWalkForwardFolds(rows, 3, 1);
  assert.equal(folds.length, 1);
  assert.equal(folds[0].trainIdx.length, 0);
  assert.equal(folds[0].oosIdx.length, 3);
});

// ── Feature-shift / poison integrity checks ─────────────────────────────────
// These guard against the two classic leakage bugs this design doc calls out
// explicitly: a feature that peeks at a future period, and a label that gets
// shuffled without the model noticing (i.e. a real accuracy signal exists).

test("poison test: shuffling labels destroys a previously-learnable signal", () => {
  const X = Array.from({ length: 60 }, (_, i) => [Math.sin(i), Math.cos(i)]);
  const yReal: number[] = X.map(r => (r[0] + r[1] > 0 ? 1 : 0));
  const stats = fitStandardizeStats(X);
  const xStd = X.map(r => applyStandardize(r, stats));

  const realModel = trainLogisticRegression(xStd, yReal, { iters: 300 });
  const realAcc = xStd.reduce((acc, x, i) => acc + (Math.round(predictLogit(realModel, x)) === yReal[i] ? 1 : 0), 0) / xStd.length;

  const shuffled = [...yReal];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(((i * 2654435761) % 2 ** 32) / 2 ** 32 * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  const poisonModel = trainLogisticRegression(xStd, shuffled, { iters: 300 });
  const poisonAcc = xStd.reduce((acc, x, i) => acc + (Math.round(predictLogit(poisonModel, x)) === shuffled[i] ? 1 : 0), 0) / xStd.length;

  assert.ok(realAcc > 0.85, `expected the real-label model to learn a clean linear signal, got ${realAcc}`);
  // Shuffled labels are, by construction, independent of X — a model fit to
  // them should not out-perform the real one on the REAL labels.
  const poisonAccOnRealLabels = xStd.reduce((acc, x, i) => acc + (Math.round(predictLogit(poisonModel, x)) === yReal[i] ? 1 : 0), 0) / xStd.length;
  assert.ok(poisonAccOnRealLabels <= realAcc, "a model trained on shuffled labels must not out-predict the real-label model on real labels");
});

test("feature-shift integrity: purged folds keep an OOS period's shifted-by-1 neighbor out of its own train set", () => {
  // Simulates a feature that (buggily) leaked one period into the future by
  // checking that the embargo would still exclude the adjacent row even
  // though its periodStartMs sits just inside one period-width.
  const periodWidthMs = 15 * 60_000;
  const rows = makeRows(20, periodWidthMs);
  const folds = purgedWalkForwardFolds(rows, 2, 1, periodWidthMs);
  const fold = folds[0];
  const oosMin = Math.min(...fold.oosIdx.map(i => rows[i].periodStartMs));
  const adjacentBefore = rows.findIndex(r => r.periodStartMs === oosMin - periodWidthMs);
  if (adjacentBefore !== -1) {
    assert.ok(!fold.trainIdx.includes(adjacentBefore), "the period immediately adjacent to OOS must be embargoed, not just excluded by index order");
  }
});
