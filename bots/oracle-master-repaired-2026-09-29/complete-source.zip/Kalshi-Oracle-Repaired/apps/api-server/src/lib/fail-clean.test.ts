/**
 * fail-clean.test.ts
 *
 * Chat/UI must never see raw HTTP 500 bodies (err.message / stack / String(err)).
 * Source-scan of src/routes plus helper unit tests.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "path";
import { fileURLToPath } from "node:url";
import { failClean } from "./fail-clean.js";
import { LOG_REDACT_PATHS } from "./logger.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const ROUTES = path.resolve(DIR, "../routes");

test("failClean logs the Error and returns a generic body without message/stack", () => {
  const bodies: unknown[] = [];
  const statuses: number[] = [];
  const res = {
    status(code: number) {
      statuses.push(code);
      return this;
    },
    json(body: unknown) {
      bodies.push(body);
      return this;
    },
  };
  const err = new Error("ECONNREFUSED postgres://secret@localhost/db");
  failClean(res as never, 500, "Failed to load trades", err);
  assert.deepEqual(statuses, [500]);
  assert.deepEqual(bodies, [{ error: "Failed to load trades" }]);
  const dumped = JSON.stringify(bodies[0]);
  assert.equal(dumped.includes("ECONNREFUSED"), false);
  assert.equal(dumped.includes("postgres://"), false);
  assert.equal(dumped.includes("secret"), false);
});

test("failClean strips extra.detail so callers cannot leak err.message", () => {
  const bodies: unknown[] = [];
  const res = {
    status() { return this; },
    json(body: unknown) { bodies.push(body); return this; },
  };
  failClean(res as never, 500, "Failed", new Error("raw dump"), {
    detail: "raw dump",
    paperMode: true,
  });
  assert.deepEqual(bodies, [{ error: "Failed", paperMode: true }]);
});

test("logger redacts API keys, cookies, and private-key fields", () => {
  for (const needle of [
    "req.headers.authorization",
    "req.headers.cookie",
    'req.headers["x-api-key"]',
    "*.privateKey",
    "*.private_key",
  ]) {
    assert.ok(LOG_REDACT_PATHS.includes(needle), `logger redact missing ${needle}`);
  }
});

const LEAK_RE = [
  /detail:\s*\(err as Error\)\.message/,
  /error:\s*\(err as Error\)\.message/,
  /error:\s*`[^`]*\$\{\(err as Error\)\.message\}/,
  /error:\s*err instanceof Error \? err\.message/,
  /error:\s*`Network error: \$\{/,
  /res\.status\(500\)\.json\(\{\s*error:\s*\(err/,
];

test("src/routes catch bodies do not leak err.message/stack on 500/detail", () => {
  const files = fs.readdirSync(ROUTES).filter(f => f.endsWith(".ts") && !f.endsWith(".test.ts"));
  const hits: string[] = [];
  for (const fn of files) {
    const src = fs.readFileSync(path.join(ROUTES, fn), "utf8");
    const lines = src.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (/parsed\.error\.message/.test(line)) continue; // zod 400 validation
      if (/chunk\.error\.message/.test(line)) continue; // LLM stream, not HTTP body
      if (/g\.detail/.test(line)) continue;
      if (/authError:\s*true/.test(line)) continue;
      if (/authError:\s*`HTTP/.test(line)) continue;
      for (const re of LEAK_RE) {
        if (re.test(line)) hits.push(`${fn}:${i + 1}:${line.trim()}`);
      }
      if (/res\.status\(\s*500\s*\)/.test(line) && /\.message/.test(line) && /err/.test(line)) {
        hits.push(`${fn}:${i + 1}:${line.trim()}`);
      }
    }
  }
  assert.deepEqual(hits, [], hits.join("\n"));
});

