/**
 * Leftover monitor exit stack is denied on paper/frozen and lives outside host.
 */
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import {
  leftoverExitStackHostDenied,
  leftoverExitStackMayRun,
  leftoverExitStackMayRunOnPathRide,
  leftoverExitStackRun,
} from "./organs/exit-policy.js";
import { FROZEN_EXIT_FUNNEL_MARKERS, LEFTOVER_EXIT_FUNNEL_LOADED } from "./leftover-exit-funnel.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const FUNNEL = fs.readFileSync(path.join(DIR, "leftover-exit-funnel.ts"), "utf8");

test("leftover exit stack may run only off the paper/frozen desk", async () => {
  assert.equal(LEFTOVER_EXIT_FUNNEL_LOADED, true);
  assert.equal(leftoverExitStackMayRunOnPathRide(), false);
  assert.equal(leftoverExitStackMayRun({ paperMode: true }), false);
  assert.equal(leftoverExitStackMayRun({ frozenCcMode: true }), false);
  assert.equal(leftoverExitStackMayRun({ paperMode: false, frozenCcMode: false }), true);
  assert.equal(leftoverExitStackHostDenied({ paperMode: true }), true);
  let ran = false;
  await leftoverExitStackRun({ paperMode: true }, async () => { ran = true; });
  assert.equal(ran, false);
  await leftoverExitStackRun({ frozenCcMode: true }, async () => { ran = true; });
  assert.equal(ran, false);
  await leftoverExitStackRun({ paperMode: false, frozenCcMode: false }, async () => { ran = true; });
  assert.equal(ran, true);
});

test("host monitorOpenTrade does not compile leftover TB/ARIA/trail; funnel does", () => {
  assert.match(BOT, /from "\.\/leftover-exit-funnel\.js"/);
  assert.match(BOT, /leftoverExitStackFunnel\.call/);
  const monAt = BOT.indexOf("private async monitorOpenTrade()");
  const monEnd = BOT.indexOf("async forceExitOpenTrade", monAt);
  const mon = BOT.slice(monAt, monEnd);
  assert.match(mon, /leftoverExitStackMayRun\(this\.config\)/);
  assert.match(mon, /leftoverExitStackRun\(this\.config,/);
  assert.match(mon, /leftover exit stack skipped/);
  assert.doesNotMatch(mon, /this\.checkThesisBreak\(/);
  assert.doesNotMatch(mon, /this\.checkLagFlip\(/);
  assert.doesNotMatch(mon, /this\.checkHardStop\(/);
  assert.doesNotMatch(mon, /ARIA_GATED_EXIT/);
  assert.doesNotMatch(mon, /LATE_LOCK/);
  for (const marker of FROZEN_EXIT_FUNNEL_MARKERS) {
    assert.ok(FUNNEL.includes(marker), `exit funnel still has ${marker}`);
    assert.equal(mon.includes(marker), false, `host monitor must not compile ${marker}`);
  }
});
