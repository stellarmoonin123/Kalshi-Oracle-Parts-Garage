/**
 * Frozen CC six-gate is the only 15m path to placeOrder after feed / halt / obs.
 *
 * Leftover funnel (ARIA composer, auto-policy writes, packs, HARVEST,
 * SETTLEMENT_PREDICTION hijack, paper-desk winner, W2-as-law) is not entry law.
 * W2 / harvest / regime may still be recorded as shadow flags on the fill.
 * Not an edge claim. Does not import trading-bot.
 */
export function frozenSixGateIsOnlyEvaluatePath(cfg: {
  frozenCcMode?: boolean;
}): boolean {
  return cfg.frozenCcMode === true;
}

/**
 * Leftover 15m funnel (packs/harvest/SP/desk/W2-as-law) may run only when
 * six-gate is not the path AND the desk is not paper.
 * Paper desk = frozen-CC / paper-release only — leftover15m stays fail-closed.
 * Does not ENABLE. Not an edge claim.
 */
export function leftover15mEvaluateMayRun(cfg: {
  frozenCcMode?: boolean;
  paperMode?: boolean;
}): boolean {
  if (cfg.paperMode === true) return false;
  return !frozenSixGateIsOnlyEvaluatePath(cfg);
}

/** Host must return from evaluateEntry after lastObservation when the helper is true. */
export const FROZEN_SIX_GATE_JUMPS_AFTER_OBS = true as const;

/** Strings that must not appear on the frozen evaluate path before decideFrozenCcEntry. */
export const FROZEN_LEFTOVER_FUNNEL_MARKERS = [
  "selectPaperDeskWinnerFromPool",
  "classifyDetailedCondition",
  "applyAutoPolicyOverlay",
  "PACK_NOT_ELIGIBLE",
  "SESSION_FAMILY_SUPPRESSED",
  "REGIME_EV_FILTER",
] as const;
