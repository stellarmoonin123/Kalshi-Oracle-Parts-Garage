/**
 * settle-side-score — pure settlement-oriented YES / NO / SKIP scorer.
 *
 * Goal: pick the side that is more likely to match Kalshi 15m *settlement*
 * (spot vs strike at expiry), not the side that looks good for a path-ride TP.
 *
 * Hard lessons (CC_VEL deep-dive + phone blotter):
 *   - CC_VEL_AGAINST_* on a TAKE is the primary wrong-side fee-net bleed
 *   - MTF bull into red 1m vel (or bear into green) is a strong cofactor → SKIP
 *   - Lag unproven / stale → do not lock a settle side
 *   - Ask outside 20–55 door → SKIP (floors untouched)
 *   - constructedNo prefers NO when otherwise clear (sign-safe constructed path)
 *
 * Pure. No network. No placeOrder. No ENABLE. Never hardens six-gate CC_VEL
 * (n≪40 — brainAuth veto / council weight only).
 */

export const SETTLE_SIDE_SCORE_LOADED = "SETTLE_SIDE_SCORE_LOADED" as const;

/** Ask door mirrors MIND_FLOOR_LOCKS / frozen band — do not cut. */
export const SETTLE_ASK_MIN_CENTS = 20 as const;
export const SETTLE_ASK_MAX_CENTS = 55 as const;

/** Same $40/min threshold as brain-center isMtfBullIntoRedVel. */
export const SETTLE_VEL_CONFLICT_ABS = 40 as const;

export type SettleSidePick = "yes" | "no" | "skip";

export type SettleSideScoreInput = {
  /** Proposed / sole side under consideration (optional). */
  side?: "yes" | "no" | null;
  ccVelocityWouldBlock?: string | null;
  velocityDolPerMin?: number | null;
  mtfScore?: number | null;
  lagProven?: boolean | null;
  lagStale?: boolean | null;
  askCents?: number | null;
  /** Sign-safe constructed NO path — lean NO when otherwise clear. */
  constructedNo?: boolean | null;
};

export type SettleSideScoreFactors = {
  velAgainst: boolean;
  mtfVelConflict: boolean;
  lagBad: boolean;
  askDoor: boolean;
  constructedNo: boolean;
  inputsPresent: boolean;
};

export type SettleSideScoreResult = {
  pick: SettleSidePick;
  /** Relative settle affinity (−ve = against that side). */
  scoreYes: number;
  scoreNo: number;
  reasons: string[];
  penalties: string[];
  factors: SettleSideScoreFactors;
};

function finite(n: number | null | undefined): n is number {
  return typeof n === "number" && Number.isFinite(n);
}

/** True when MTF and 1m velocity fight the same settle side. */
export function mtfVelConflict(
  mtfScore: number | null | undefined,
  vel: number | null | undefined,
): "yes" | "no" | null {
  if (!finite(mtfScore) || !finite(vel)) return null;
  // Bull MTF + strong red vel → conflict on YES settle
  if (mtfScore > 0 && vel <= -SETTLE_VEL_CONFLICT_ABS) return "yes";
  // Bear MTF + strong green vel → conflict on NO settle
  if (mtfScore < 0 && vel >= SETTLE_VEL_CONFLICT_ABS) return "no";
  return null;
}

export function parseVelAgainst(
  ccVel: string | null | undefined,
): "yes" | "no" | null {
  if (!ccVel) return null;
  if (ccVel === "CC_VEL_AGAINST_YES" || /AGAINST_YES/i.test(ccVel)) return "yes";
  if (ccVel === "CC_VEL_AGAINST_NO" || /AGAINST_NO/i.test(ccVel)) return "no";
  return null;
}

/**
 * Score settlement side. Returns SKIP when doors/conflicts fire.
 * When inputs are thin, pick=skip with inputsPresent=false (council ignores).
 */
export function scoreSettleSide(input: SettleSideScoreInput): SettleSideScoreResult {
  const reasons: string[] = [];
  const penalties: string[] = [];
  let scoreYes = 0;
  let scoreNo = 0;

  const hasAny =
    input.ccVelocityWouldBlock != null ||
    finite(input.velocityDolPerMin) ||
    finite(input.mtfScore) ||
    input.lagProven != null ||
    input.lagStale != null ||
    finite(input.askCents) ||
    input.constructedNo != null ||
    input.side === "yes" ||
    input.side === "no";

  const against = parseVelAgainst(input.ccVelocityWouldBlock ?? null);
  const conflictSide = mtfVelConflict(input.mtfScore, input.velocityDolPerMin);
  const lagBad =
    input.lagStale === true ||
    (input.lagProven === false && input.lagProven != null);
  const askOk =
    !finite(input.askCents) ||
    (input.askCents >= SETTLE_ASK_MIN_CENTS &&
      input.askCents <= SETTLE_ASK_MAX_CENTS);
  const askDoor = finite(input.askCents) && !askOk;
  const constructedNo = input.constructedNo === true;

  const factors: SettleSideScoreFactors = {
    velAgainst: against != null,
    mtfVelConflict: conflictSide != null,
    lagBad,
    askDoor,
    constructedNo,
    inputsPresent: hasAny,
  };

  if (!hasAny) {
    return {
      pick: "skip",
      scoreYes: 0,
      scoreNo: 0,
      reasons: ["inputs thin — settle-side-score idle"],
      penalties: [],
      factors,
    };
  }

  // Velocity lean (soft): green vel favors YES settle, red favors NO
  if (finite(input.velocityDolPerMin)) {
    const v = input.velocityDolPerMin;
    if (v >= SETTLE_VEL_CONFLICT_ABS) {
      scoreYes += 2;
      reasons.push(`vel +${Math.round(v)}$/min leans YES settle`);
    } else if (v <= -SETTLE_VEL_CONFLICT_ABS) {
      scoreNo += 2;
      reasons.push(`vel ${Math.round(v)}$/min leans NO settle`);
    }
  }

  // MTF lean (soft)
  if (finite(input.mtfScore)) {
    if (input.mtfScore > 0) {
      scoreYes += 1;
      reasons.push(`mtf=${input.mtfScore} leans YES`);
    } else if (input.mtfScore < 0) {
      scoreNo += 1;
      reasons.push(`mtf=${input.mtfScore} leans NO`);
    }
  }

  // constructedNo — prefer NO when clear
  if (constructedNo) {
    scoreNo += 1.5;
    reasons.push("constructedNo → lean NO settle");
  }

  // --- HARD penalties (settlement-oriented) ---

  // Ask door
  if (askDoor) {
    penalties.push(
      `ask ${input.askCents}¢ outside ${SETTLE_ASK_MIN_CENTS}–${SETTLE_ASK_MAX_CENTS}`,
    );
    return {
      pick: "skip",
      scoreYes: 0,
      scoreNo: 0,
      reasons,
      penalties,
      factors,
    };
  }

  // Lag bad → skip lock
  if (lagBad) {
    penalties.push(
      input.lagStale === true ? "lagStale" : "lag unproven",
    );
    return {
      pick: "skip",
      scoreYes,
      scoreNo,
      reasons,
      penalties,
      factors,
    };
  }

  // Vel-against hard penalty on that side
  if (against === "yes") {
    scoreYes -= 5;
    penalties.push("CC_VEL_AGAINST_YES — hard settle penalty on YES");
  } else if (against === "no") {
    scoreNo -= 5;
    penalties.push("CC_VEL_AGAINST_NO — hard settle penalty on NO");
  }

  // MTF+vel conflict → skip (or force opposite-of-conflict lean via vel)
  if (conflictSide === "yes") {
    penalties.push("MTF+vel conflict on YES (bull MTF into red vel) → SKIP/vel");
    // Prefer vel side (NO) only if vel-against didn't also kill NO; else SKIP
    if (against === "no") {
      return {
        pick: "skip",
        scoreYes,
        scoreNo,
        reasons,
        penalties,
        factors,
      };
    }
    scoreYes -= 4;
    scoreNo += 1;
  } else if (conflictSide === "no") {
    penalties.push("MTF+vel conflict on NO (bear MTF into green vel) → SKIP/vel");
    if (against === "yes") {
      return {
        pick: "skip",
        scoreYes,
        scoreNo,
        reasons,
        penalties,
        factors,
      };
    }
    scoreNo -= 4;
    scoreYes += 1;
  }

  // If proposed side is vel-against → SKIP (do not settle-hold that side)
  if (against && input.side && against === input.side) {
    penalties.push(`proposed ${input.side.toUpperCase()} is vel-against → SKIP`);
    return {
      pick: "skip",
      scoreYes,
      scoreNo,
      reasons,
      penalties,
      factors,
    };
  }

  // MTF+vel conflict alone with no clear opposite → SKIP
  if (conflictSide && against == null) {
    // If opposite score is clearly better, allow flip; else SKIP
    const opposite: SettleSidePick = conflictSide === "yes" ? "no" : "yes";
    const oppScore = opposite === "yes" ? scoreYes : scoreNo;
    const conflictScore = conflictSide === "yes" ? scoreYes : scoreNo;
    if (oppScore > conflictScore + 1.5) {
      reasons.push(`conflict → flip to ${opposite.toUpperCase()} via vel lean`);
      return {
        pick: opposite,
        scoreYes,
        scoreNo,
        reasons,
        penalties,
        factors,
      };
    }
    return {
      pick: "skip",
      scoreYes,
      scoreNo,
      reasons,
      penalties,
      factors,
    };
  }

  // Vel-against without proposed side match → prefer opposite or skip
  if (against) {
    const opposite: SettleSidePick = against === "yes" ? "no" : "yes";
    const oppScore = opposite === "yes" ? scoreYes : scoreNo;
    if (oppScore > 0) {
      reasons.push(`vel-against ${against.toUpperCase()} → prefer ${opposite.toUpperCase()}`);
      return {
        pick: opposite,
        scoreYes,
        scoreNo,
        reasons,
        penalties,
        factors,
      };
    }
    penalties.push(`vel-against ${against.toUpperCase()} with weak opposite → SKIP`);
    return {
      pick: "skip",
      scoreYes,
      scoreNo,
      reasons,
      penalties,
      factors,
    };
  }

  // Clear winner
  if (scoreYes > scoreNo + 0.5) {
    reasons.push(`YES settle score ${scoreYes} > NO ${scoreNo}`);
    return { pick: "yes", scoreYes, scoreNo, reasons, penalties, factors };
  }
  if (scoreNo > scoreYes + 0.5) {
    reasons.push(`NO settle score ${scoreNo} > YES ${scoreYes}`);
    return { pick: "no", scoreYes, scoreNo, reasons, penalties, factors };
  }

  reasons.push("scores tied / thin edge → SKIP");
  return { pick: "skip", scoreYes, scoreNo, reasons, penalties, factors };
}

/** True when caller should feed settle-side into council (any real sensor). */
export function settleSideInputsPresent(input: SettleSideScoreInput): boolean {
  return scoreSettleSide(input).factors.inputsPresent;
}
