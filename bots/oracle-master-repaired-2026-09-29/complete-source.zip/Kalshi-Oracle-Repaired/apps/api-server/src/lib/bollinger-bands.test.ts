/**
 * bollinger-bands.test.ts
 *
 * Unit tests for computeBollingerBands() and BollingerSqueezeTracker (Task #445).
 *
 * Run with:
 *   node --experimental-strip-types src/lib/bollinger-bands.test.ts
 */

import { test } from "node:test";
import assert    from "node:assert/strict";
import { computeBollingerBands, BollingerSqueezeTracker } from "./bollinger-bands.js";

// ── computeBollingerBands ────────────────────────────────────────────────────

test("computeBollingerBands: returns null with fewer than `period` closes", () => {
  const closes = Array.from({ length: 19 }, () => 100);
  assert.equal(computeBollingerBands(closes, 20, 2), null);
});

test("computeBollingerBands: exactly `period` closes is enough", () => {
  const closes = Array.from({ length: 20 }, () => 100);
  const bb = computeBollingerBands(closes, 20, 2);
  assert.notEqual(bb, null);
});

test("computeBollingerBands: flat price series has zero stdDev, bandwidth, and %B=0.5", () => {
  const closes = Array.from({ length: 30 }, () => 100);
  const bb = computeBollingerBands(closes, 20, 2)!;
  assert.equal(bb.stdDev, 0);
  assert.equal(bb.bandwidthPct, 0);
  assert.equal(bb.upper, 100);
  assert.equal(bb.lower, 100);
  // width ~0 → percentB falls back to the documented 0.5 midpoint, not NaN/Infinity
  assert.equal(bb.percentB, 0.5);
});

test("computeBollingerBands: price at the upper band reads percentB ~= 1", () => {
  // 19 values at 100, then a spike so the last close sits near mean + 2*stdDev
  const closes = [...Array.from({ length: 19 }, () => 100), 110];
  const bb = computeBollingerBands(closes, 20, 2)!;
  assert.ok(bb.percentB > 0.9, `expected percentB near 1, got ${bb.percentB}`);
});

test("computeBollingerBands: price at the lower band reads percentB ~= 0", () => {
  const closes = [...Array.from({ length: 19 }, () => 100), 90];
  const bb = computeBollingerBands(closes, 20, 2)!;
  assert.ok(bb.percentB < 0.1, `expected percentB near 0, got ${bb.percentB}`);
});

test("computeBollingerBands: only looks at the trailing `period` window, ignoring older history", () => {
  // 100 old wild values, then 20 flat values — only the flat tail should be used
  const wild = Array.from({ length: 100 }, (_, i) => 100 + (i % 2 === 0 ? 50 : -50));
  const flat = Array.from({ length: 20 }, () => 100);
  const bb = computeBollingerBands([...wild, ...flat], 20, 2)!;
  assert.equal(bb.stdDev, 0);
  assert.equal(bb.mean, 100);
});

test("computeBollingerBands: higher stdDevMult widens the bands proportionally", () => {
  const closes = Array.from({ length: 20 }, (_, i) => 100 + (i % 2 === 0 ? 2 : -2));
  const bb2 = computeBollingerBands(closes, 20, 2)!;
  const bb3 = computeBollingerBands(closes, 20, 3)!;
  assert.ok((bb3.upper - bb3.lower) > (bb2.upper - bb2.lower));
});

// ── BollingerSqueezeTracker ──────────────────────────────────────────────────

test("BollingerSqueezeTracker: returns undefined before 30 samples accumulate", () => {
  const tracker = new BollingerSqueezeTracker();
  let last: boolean | undefined = false;
  for (let i = 0; i < 29; i++) last = tracker.update(5);
  assert.equal(last, undefined);
});

test("BollingerSqueezeTracker: returns a boolean once 30+ samples accumulate", () => {
  const tracker = new BollingerSqueezeTracker();
  let last: boolean | undefined;
  for (let i = 0; i < 30; i++) last = tracker.update(5);
  assert.notEqual(last, undefined);
});

test("BollingerSqueezeTracker: a sustained low-bandwidth reading is flagged as a squeeze relative to a wide history", () => {
  const tracker = new BollingerSqueezeTracker();
  // Establish a history of wide bandwidth readings (10-20), then feed in a
  // run of much narrower readings — those should register as squeezes since
  // they sit in the bottom 20th percentile of the accumulated history.
  for (let i = 0; i < 40; i++) tracker.update(10 + (i % 10));
  let sawSqueeze = false;
  for (let i = 0; i < 15; i++) {
    const isSqueeze = tracker.update(0.5);
    if (isSqueeze) sawSqueeze = true;
  }
  assert.ok(sawSqueeze, "expected sustained narrow bandwidth to register as a squeeze");
});

test("BollingerSqueezeTracker: recentlyExpanded is false before any squeeze has occurred", () => {
  const tracker = new BollingerSqueezeTracker();
  for (let i = 0; i < 30; i++) tracker.update(10);
  assert.equal(tracker.recentlyExpanded(), false);
});

test("BollingerSqueezeTracker: recentlyExpanded is true shortly after a squeeze reading, then false once the window elapses", () => {
  const tracker = new BollingerSqueezeTracker();
  // Distinct, non-tied values 40..79 so the 20th-percentile threshold sits
  // near the low end (~47) — well below the "normal" readings used below.
  for (let i = 0; i < 40; i++) tracker.update(40 + i);
  // Force a squeeze reading, clearly below the threshold
  tracker.update(5);
  // A few normal (high, well-above-threshold) readings right after — still
  // within the default 12-update window since the squeeze
  for (let i = 0; i < 5; i++) tracker.update(75);
  assert.equal(tracker.recentlyExpanded(12), true);
  // Push well past the window
  for (let i = 0; i < 20; i++) tracker.update(75);
  assert.equal(tracker.recentlyExpanded(12), false);
});

test("BollingerSqueezeTracker: reset() clears history back to the undefined state", () => {
  const tracker = new BollingerSqueezeTracker();
  for (let i = 0; i < 30; i++) tracker.update(10);
  tracker.reset();
  assert.equal(tracker.update(10), undefined);
});

test("BollingerSqueezeTracker: caps its rolling history at 200 samples (oldest evicted)", () => {
  const tracker = new BollingerSqueezeTracker();
  // Establish a low, narrow baseline (200 identical low readings).
  for (let i = 0; i < 200; i++) tracker.update(10);
  // Against that baseline, a reading of 50 is clearly NOT a squeeze.
  assert.equal(tracker.update(50), false);
  // Push exactly 200 more (high) readings — enough to fully evict every
  // sample from the original low baseline out of the capped 200-window.
  for (let i = 0; i < 200; i++) tracker.update(90);
  // The SAME absolute reading (50) now registers as a squeeze, because it's
  // being compared against the new (90-based) history, not the old evicted
  // one — proof the rolling window actually evicts rather than accumulating
  // unboundedly.
  assert.equal(tracker.update(50), true);
});
