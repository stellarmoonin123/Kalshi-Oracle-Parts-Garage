# Desk library (15-minute contracts)

The old 20 names in `strategy-library.ts` are mediocre. Too many engines. They
fight. They fire in the wrong weather. The live bot still imports that file.
We did **not** delete those names. They are **retired-from-new-library**.

This folder is the 15-minute contract library. One desk. Two books.

- **Settlement book** — buy a cheap or lag side and hold it toward 0 or 100.
- **Scalp book** — buy only when the ticket itself is moving, then sell.

## How the director thinks

1. **Skip first.** Lottery 7–12¢ in the last 150 seconds is skip. A still
   40–65¢ ticket on the green-sell book is skip. Binary pin (`strike-levels.pinRisk`)
   is skip on still-mid 40–65¢ when spot is inside $40 of the floor and the
   floor is within $25 of a $100 psych. Skip/tighten, not a fill.
2. **Pick one side.** Yes or no. Never both. (See `settlement-side.ts`.)
3. **Pick one predicate.** Not twenty. Shadow until fee-net says otherwise.

| Predicate | Book | What it asks |
|---|---|---|
| skip | default | lottery last 150s; still-mid green-sell; binary pin |
| persist-cheap | settlement | 19–22¢, 2–12m, fair-agree persist ≥60s, HA not fighting. Hold to settlement. |
| metered-lag | settlement | persist-lag **and** a live lag-meter. Stale / disagree / tiny $ / ask>55 → skip. |
| trend-confluence | settlement | only a real trend (`strong_uptrend` / `strong_downtrend`). Unclear still 45–55¢ is skip. |
| scalp-velocity | scalp | ticket dMid/dt moving with the trade. Never both sides. One 9% budget per bar. Still = skip. |
| cheap-early-exit | green-sell | cheap 7–22¢, fair persist ≥15s, sell +8¢ / 2× / TB / lag-flip / 90s. Wrong settle OK. LIVE_APPLY false. CHEAP_EARLY_EXIT_PAPER false. |
| panic-fade | green-sell | catalog-only OBSERVE. ≥8¢/8s fade, not 2¢. Not in director take-chain. LIVE_APPLY false. Dual-gate ENABLE false. |
| streak-sat-fade | green-sell | catalog-only OBSERVE. sat≥0.75 AND |streak|≥4, not blind 3-streak. Not in director. LIVE_APPLY false. Dual-gate ENABLE false. |
| streak-channel-bb | green-sell | catalog-only OBSERVE. Labels FAST_TREND / FLIP / CHOP. Not in director. Not a StrategyId. Not an evaluate skip. LIVE_APPLY false. Weak as settlement-hold. |
| structure-reversal | settlement | 30s-median fair flip persist ≥60s at a psych/bounce/HA level. Ticket dMid ≥2¢. Skip still 40–65 and binary pin. LIVE_APPLY false. Not a StrategyId. |

## Locks (do not flip)

- `paperMode` true
- `autoMode` false
- `LIVE_APPLY` false on **every** new predicate
- Never `ENABLE_STRATEGY`
- Never `CHANGE_EV_FLOOR`
- Never register new StrategyIds on `trading-bot.ts` evaluate
- Do not overwrite `strategy-library.ts`
- Do not enable BRTI / SEV1 / hourly / perps
- Do not re-enable SETTLEMENT_PREDICTION, TOP/BOTTOM, BOLLINGER, LATE_ENTRY

Shadow until fee-net. Then we talk.
