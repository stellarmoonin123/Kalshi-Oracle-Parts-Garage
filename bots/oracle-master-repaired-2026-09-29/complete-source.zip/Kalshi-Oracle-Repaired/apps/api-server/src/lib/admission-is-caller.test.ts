/**
 * TradingBot is a caller of admission.ts (2026-08-27 score lift).
 *
 * Source-text + live admission.js. Does NOT import trading-bot.ts
 * (node:test isolation — trading-bot's import graph starts the singleton).
 *
 * Locks: EV 3¢ / OTM 5¢ / 9% / 18% unchanged. paper stays paper.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import test from "node:test";
import assert from "node:assert/strict";
import {
  HARD_RISK_LIMITS,
  EV_FLOOR,
  OTM_EV_FLOOR,
  evaluateEntryEVGate,
  applyHardRiskLimits,
  canScaleIntoPosition,
  computeContracts,
  kellyPayoutRatio,
  computeKellyEdge,
  kellyFraction,
} from "./admission.js";
import { kalshiNetCostCents, kalshiNetWinCents } from "./constants.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const ADM = readFileSync(path.join(DIR, "admission.ts"), "utf8");

test("trading-bot.ts imports admission math and does not redefine it", () => {
  assert.ok(BOT.includes('from "./admission.js"'), "bot must import admission.ts");
  assert.ok(BOT.includes("applyHardRiskLimits"), "bot still calls applyHardRiskLimits");
  assert.ok(BOT.includes("evaluateEntryEVGate"), "bot still calls evaluateEntryEVGate");
  assert.ok(!/export const EV_FLOOR\s*=/.test(BOT), "EV_FLOOR must not be redefined in the god-file");
  assert.ok(!/export const HARD_RISK_LIMITS\s*=/.test(BOT), "HARD_RISK_LIMITS must not be redefined in the god-file");
  assert.ok(!/export const OTM_EV_FLOOR\s*=/.test(BOT), "OTM_EV_FLOOR must not be redefined in the god-file");
  assert.ok(!/export function evaluateEntryEVGate\s*\(/.test(BOT), "evaluateEntryEVGate body must not live in the god-file");
  assert.ok(!/export function applyHardRiskLimits\s*\(/.test(BOT), "applyHardRiskLimits body must not live in the god-file");
  assert.ok(!/export function canScaleIntoPosition\s*\(/.test(BOT), "canScaleIntoPosition body must not live in the god-file");
  assert.ok(!/function scoreStrategyEV\s*\(/.test(BOT), "scoreStrategyEV body must not live in the god-file");
  assert.ok(!/function estimateTradeEV\s*\(/.test(BOT), "estimateTradeEV body must not live in the god-file");
});

test("admission.ts is the single source of EV floors and 9%/18%", () => {
  assert.match(ADM, /export const EV_FLOOR\s*=\s*3/);
  assert.match(ADM, /export const OTM_EV_FLOOR\s*=\s*5/);
  assert.ok(ADM.includes("maxRiskPctPerTrade: 0.09"));
  assert.ok(ADM.includes("maxDailyLossPct:    0.18") || ADM.includes("maxDailyLossPct: 0.18"));
  assert.ok(ADM.includes("export function applyHardRiskLimits"));
  assert.ok(ADM.includes("export function canScaleIntoPosition"));
  assert.ok(ADM.includes("export function evaluateEntryEVGate"));
  assert.equal(EV_FLOOR, 3);
  assert.equal(OTM_EV_FLOOR, 5);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(HARD_RISK_LIMITS.maxDailyLossPct, 0.18);
});

test("applyHardRiskLimits: 9% of $313 binds; 18% day halt zeros", () => {
  const bankroll = 31_300;
  const entry = 53;
  const cost = Math.ceil(kalshiNetCostCents(entry));
  const maxByPct = Math.floor((bankroll * 0.09) / cost);
  const sized = applyHardRiskLimits(bankroll, entry, 10_000, 0);
  assert.equal(sized, maxByPct);
  assert.ok(sized * cost <= bankroll * 0.09 + 1e-9);
  assert.equal(applyHardRiskLimits(bankroll, entry, 10_000, -(bankroll * 0.18)), 0);
});

test("canScaleIntoPosition uses the same 9% cumulative cap", () => {
  const bankroll = 31_300;
  const price = 50;
  const maxFresh = applyHardRiskLimits(bankroll, price, 1_000, 0);
  assert.equal(canScaleIntoPosition({
    balanceCents: bankroll, todayPnlCents: 0,
    existingContracts: 0, existingEntryPriceCents: price,
    addContracts: maxFresh, addPriceCents: price,
  }), true);
  assert.equal(canScaleIntoPosition({
    balanceCents: bankroll, todayPnlCents: 0,
    existingContracts: 0, existingEntryPriceCents: price,
    addContracts: maxFresh + 1, addPriceCents: price,
  }), false);
});

test("evaluateEntryEVGate ignores calibratedWinRate inflation", () => {
  const rich = evaluateEntryEVGate({
    entryPriceCents: 87, strategyWinRate: 0.62, calibratedWinRate: 0.97,
    strategyId: "LATE_ENTRY_ANCHOR", secsRemaining: 200, velocityDolPerMin: 0, spreadCents: 2,
  });
  const plain = evaluateEntryEVGate({
    entryPriceCents: 87, strategyWinRate: 0.62,
    strategyId: "LATE_ENTRY_ANCHOR", secsRemaining: 200, velocityDolPerMin: 0, spreadCents: 2,
  });
  assert.equal(rich.passes, plain.passes);
  assert.equal(rich.modelEstimatedProb, 0.62);
  assert.equal(plain.passes, false);
});

test("ENTRY traces name pWin (winRateAtPrice) separate from signalConfidence and pSize", () => {
  assert.ok(BOT.includes("pWin: strategyWinRate"));
  assert.ok(BOT.includes("signalConfidence: confidence"));
  assert.ok(BOT.includes("pSize: contracts"));
  const pricing = BOT.slice(BOT.indexOf("pWin: strategyWinRate"));
  assert.ok(pricing.includes("signalConfidence: confidence"));
});


test("trading-bot.ts calls admission.computeContracts; Kelly body is not in the god-file", () => {
  assert.ok(BOT.includes('from "./admission.js"'), "bot must import admission.ts");
  assert.ok(BOT.includes("computeKellyContracts") || BOT.includes("computeContracts"), "bot still calls computeContracts");
  assert.ok(ADM.includes("export function computeContracts"), "computeContracts body lives in admission.ts");
  assert.ok(BOT.includes("pWin: (typeof strategyWinRate"), "dormant Kelly must pass pWin=strategyWinRate");
  assert.match(BOT, /const p = \(typeof strategyWinRate === "number"/);
  assert.ok(ADM.includes("export function kellyPayoutRatio"));
  assert.ok(ADM.includes("export function kellyFraction"));
  assert.ok(!/const kellyFrac = \(confidence >= 80 && edge >= 8\) \? 0\.60/.test(BOT),
    "fractional Kelly 0.60 ternary must not be reimplemented in trading-bot.ts");
  assert.match(ADM, /\? 0\.60/);
  assert.equal(kellyFraction(80, 8), 0.60, "0.60 cap lock");
  assert.equal(kellyFraction(99, 99), 0.60, "never above 0.60");
  assert.equal(kellyFraction(70, 5), 0.50);
  assert.equal(kellyFraction(60, 4), 0.40);
});

test("computeContracts: p=pWin (winRateAtPrice), b fee-net, 0.60 frac; Wilson pSizeClamped does not replace p", () => {
  const entry = 53;
  const p = 0.72;
  const bankroll = 31_300;
  const b = kellyPayoutRatio(entry);
  assert.equal(b, Math.min(4.5, kalshiNetWinCents(entry) / kalshiNetCostCents(entry)));
  const kelly = computeKellyEdge(p, b);
  assert.ok(kelly > 0);
  const scaled = kelly * 0.60;
  const netCostCeil = Math.ceil(kalshiNetCostCents(entry));
  const expected = Math.min(999, Math.floor(scaled * 1 * 1 * 1 * bankroll / netCostCeil));
  const wilsonPrior = 0.55; // paper n=0 computePSizeForKelly — must NOT be Kelly p
  const sized = computeContracts({
    pWin: p,
    pSizeClamped: wilsonPrior,
    entryPriceCents: entry,
    confidence: 80,
    edge: 8,
    balanceCents: bankroll,
    maxContracts: 999,
    uMult: 1,
    volumeSizeMult: 1,
    packSizeCapMult: 1,
    guardfactor: 1,
  });
  assert.equal(sized.contracts, expected);
  assert.ok(sized.contracts > 0);
  const wilsonSized = computeContracts({
    pSizeClamped: wilsonPrior,
    entryPriceCents: entry,
    confidence: 80,
    edge: 8,
    balanceCents: bankroll,
    maxContracts: 999,
    uMult: 1,
    volumeSizeMult: 1,
    packSizeCapMult: 1,
    guardfactor: 1,
  });
  assert.notEqual(sized.contracts, wilsonSized.contracts, "pWin 0.72 must not size as Wilson 0.55");
  // Negative edge sizes to 0 (never force 1).
  const noEdge = computeContracts({
    pWin: 0.40,
    pSizeClamped: 0.55,
    entryPriceCents: 80,
    confidence: 80,
    edge: 8,
    balanceCents: bankroll,
    maxContracts: 999,
    uMult: 1,
  });
  assert.equal(noEdge.contracts, 0);
  assert.equal(noEdge.limiter, "KELLY_EDGE_NONPOSITIVE");
});
