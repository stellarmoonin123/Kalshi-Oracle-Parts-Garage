/**
 * Integration tests against the real database for ARIA's persistent lessons
 * store: new-lesson insert, similarity-based reinforcement (no duplicate row),
 * cross-strategy isolation, and the per-strategy prune cap.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { db, ariaLessons } from "@workspace/db";
import { eq } from "drizzle-orm";
import { loadAriaLessons, getRelevantLessons, getAllLessons, recordLessons } from "./aria-lessons-store.js";

// Fake strategy ids so we never collide with real learned lessons.
const TEST_STRATEGY = "__TEST_STRATEGY_ARIA_LESSONS__";
const TEST_STRATEGY_B = "__TEST_STRATEGY_ARIA_LESSONS_B__";

async function cleanup() {
  await db.delete(ariaLessons).where(eq(ariaLessons.strategyId, TEST_STRATEGY));
  await db.delete(ariaLessons).where(eq(ariaLessons.strategyId, TEST_STRATEGY_B));
  await loadAriaLessons();
}

test("aria-lessons-store", async (t) => {
  await cleanup();
  t.after(cleanup);

  await t.test("recordLessons inserts a brand-new lesson", async () => {
    await recordLessons([
      { strategyId: TEST_STRATEGY, lesson: "Underperforms in low-vol regime with unknown win-rate", sourceTradeId: null },
    ]);
    const rows = await db.select().from(ariaLessons).where(eq(ariaLessons.strategyId, TEST_STRATEGY));
    assert.equal(rows.length, 1);
    assert.equal(rows[0].timesReinforced, 1);
  });

  await t.test("a near-duplicate lesson reinforces the existing row instead of inserting a new one", async () => {
    await recordLessons([
      { strategyId: TEST_STRATEGY, lesson: "Underperforms in low-vol regime with unknown win-rate — confirmed again", sourceTradeId: null },
    ]);
    const rows = await db.select().from(ariaLessons).where(eq(ariaLessons.strategyId, TEST_STRATEGY));
    assert.equal(rows.length, 1, "similar lesson must reinforce, not duplicate");
    assert.equal(rows[0].timesReinforced, 2);
  });

  await t.test("a genuinely different lesson for the same strategy inserts a second row", async () => {
    await recordLessons([
      { strategyId: TEST_STRATEGY, lesson: "Exits too early on settlement-hold trades, missing the 85c lock", sourceTradeId: null },
    ]);
    const rows = await db.select().from(ariaLessons).where(eq(ariaLessons.strategyId, TEST_STRATEGY));
    assert.equal(rows.length, 2);
  });

  await t.test("lessons for a different strategy are isolated and don't reinforce cross-strategy", async () => {
    await recordLessons([
      { strategyId: TEST_STRATEGY_B, lesson: "Underperforms in low-vol regime with unknown win-rate", sourceTradeId: null },
    ]);
    const rowsA = await db.select().from(ariaLessons).where(eq(ariaLessons.strategyId, TEST_STRATEGY));
    const rowsB = await db.select().from(ariaLessons).where(eq(ariaLessons.strategyId, TEST_STRATEGY_B));
    assert.equal(rowsA.length, 2, "strategy A's rows must be untouched");
    assert.equal(rowsB.length, 1);
  });

  await t.test("getRelevantLessons / getAllLessons reflect the refreshed cache after a write", async () => {
    const relevant = getRelevantLessons([TEST_STRATEGY]);
    assert.ok(relevant.some(l => l.lesson.startsWith("Underperforms")));
    const all = getAllLessons();
    assert.ok(all.some(l => l.strategyId === TEST_STRATEGY_B));
  });

  await t.test("prune caps a single strategy at MAX_LESSONS_PER_STRATEGY, dropping the weakest first", async () => {
    // Push 8 distinct lessons onto TEST_STRATEGY_B (cap is 6) with staggered
    // reinforcement so the prune has an unambiguous weakest set to drop.
    for (let i = 0; i < 8; i++) {
      await recordLessons([{ strategyId: TEST_STRATEGY_B, lesson: `Distinct synthetic lesson number ${i} about a totally unrelated failure mode`, sourceTradeId: null }]);
    }
    const rows = await db.select().from(ariaLessons).where(eq(ariaLessons.strategyId, TEST_STRATEGY_B));
    assert.ok(rows.length <= 6, `expected prune to cap at 6, got ${rows.length}`);
  });
});
