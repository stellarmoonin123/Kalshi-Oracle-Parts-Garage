/**
 * cash-flow.ts — External cash-flow ledger + Modified Dietz ROI (accounting only)
 *
 * Mission: measure real trading performance across deposits/withdrawals
 * without contaminating trading P&L, the daily target, quarantine, or sizing.
 * Nothing in this file writes bot_trades or changes a trade's outcome/pnl.
 *
 * Detection = BOTH:
 *   - "auto" rows come from the existing balance-reconciliation loop in
 *     trading-bot.ts (unexplained balance move after subtracting settled
 *     trade P&L) — inserted as status="provisional".
 *   - "manual" rows are user-entered and confirmed on creation by default.
 *
 * ROI math (computeModifiedDietz) and the daily-target's own protection both
 * read/adjust independently of this ledger's confirm workflow — see
 * daily-target.ts's computeCashFlowReconciliation for why the target must
 * react immediately (a delayed reaction there already caused a real false
 * "target hit" on an $88 deposit, 2026-08-10). This ledger's job is the
 * AUDIT TRAIL and the REPORTING math: status="confirmed" is required before
 * a flow counts toward Modified Dietz ROI, so a bad auto-detection doesn't
 * silently corrupt a historical performance number — it just leaves the
 * period's ROI "off" until a human confirms or rejects it.
 */
import { db, cashFlowEvents, dailyEquityDays, type CashFlowEvent } from "@workspace/db";
import { and, asc, desc, eq, gt, lte, sql } from "drizzle-orm";
import { logger } from "./logger.js";

export type CashFlowStatus = "provisional" | "confirmed" | "rejected";
export type CashFlowSource = "auto" | "manual";

// ── Schema guarantee (mirrors ensureDailyEquitySchema in daily-target.ts) ────
let schemaReady: Promise<void> | null = null;
export function ensureCashFlowSchema(): Promise<void> {
  if (!schemaReady) {
    schemaReady = (async () => {
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS cash_flow_events (
          id                    serial PRIMARY KEY,
          ts                    timestamp NOT NULL,
          paper_mode            boolean NOT NULL DEFAULT false,
          amount_cents          integer NOT NULL,
          source                text NOT NULL,
          status                text NOT NULL DEFAULT 'provisional',
          balance_before_cents  integer,
          balance_after_cents   integer,
          note                  text,
          client_key            text,
          created_at            timestamp NOT NULL DEFAULT now(),
          updated_at            timestamp NOT NULL DEFAULT now()
        )
      `);
      await db.execute(sql`
        CREATE UNIQUE INDEX IF NOT EXISTS cash_flow_events_client_key_uq
        ON cash_flow_events (client_key)
      `);
    })().catch((err) => {
      schemaReady = null; // allow retry on next call
      throw err;
    });
  }
  return schemaReady;
}

// ── Auto-detection insert (idempotent) ───────────────────────────────────────

/**
 * Buckets detection time to the minute so a retried/duplicate tick can't
 * double-insert the same real-world flow (T5). The caller's own
 * `bal !== lastReconciledBalanceCents` check already prevents re-firing for
 * an unchanged balance; this is a second, DB-level guard for races/retries.
 */
export function autoDetectClientKey(paperMode: boolean, detectedAt: Date, amountCents: number): string {
  const minuteBucket = Math.floor(detectedAt.getTime() / 60_000);
  return `auto:${paperMode ? "paper" : "live"}:${minuteBucket}:${amountCents}`;
}

export async function insertAutoCashFlowEvent(opts: {
  ts: Date; paperMode: boolean; amountCents: number;
  balanceBeforeCents: number; balanceAfterCents: number;
}): Promise<void> {
  await ensureCashFlowSchema();
  const clientKey = autoDetectClientKey(opts.paperMode, opts.ts, opts.amountCents);
  await db.insert(cashFlowEvents).values({
    ts:                  opts.ts,
    paperMode:           opts.paperMode,
    amountCents:         opts.amountCents,
    source:              "auto",
    status:              "provisional",
    balanceBeforeCents:  opts.balanceBeforeCents,
    balanceAfterCents:   opts.balanceAfterCents,
    clientKey,
  }).onConflictDoNothing();
}

// ── Manual controls ───────────────────────────────────────────────────────────

export async function createManualCashFlowEvent(opts: {
  ts: Date; paperMode: boolean; amountCents: number; note?: string | null;
  status?: "provisional" | "confirmed";
}): Promise<CashFlowEvent> {
  await ensureCashFlowSchema();
  const rows = await db.insert(cashFlowEvents).values({
    ts:           opts.ts,
    paperMode:    opts.paperMode,
    amountCents:  opts.amountCents,
    source:       "manual",
    status:       opts.status ?? "confirmed",
    note:         opts.note ?? null,
  }).returning();
  return rows[0];
}

// ── Audit trail ───────────────────────────────────────────────────────────
// Ledger rows (auto-detected AND manually entered) could previously be
// edited or have their status flipped in place with nothing but an
// `updated_at` bump — no record of the prior value, who/what changed it, or
// when. Since this ledger feeds the Modified Dietz ROI number, a silent
// after-the-fact edit could make a reported return look better or worse
// with zero trace. `cash_flow_audit` is append-only: one row per edit/status
// change, capturing the full before/after snapshot.
let auditSchemaReady: Promise<void> | null = null;
function ensureCashFlowAuditSchema(): Promise<void> {
  if (!auditSchemaReady) {
    auditSchemaReady = (async () => {
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS cash_flow_audit (
          id           serial PRIMARY KEY,
          event_id     integer NOT NULL,
          change_type  text NOT NULL,
          before       jsonb NOT NULL,
          after        jsonb NOT NULL,
          changed_at   timestamp NOT NULL DEFAULT now()
        )
      `);
      await db.execute(sql`
        CREATE INDEX IF NOT EXISTS cash_flow_audit_event_id_idx
        ON cash_flow_audit (event_id)
      `);
    })().catch((err) => {
      auditSchemaReady = null;
      throw err;
    });
  }
  return auditSchemaReady;
}

async function recordCashFlowAudit(eventId: number, changeType: "edit" | "status", before: unknown, after: unknown): Promise<void> {
  try {
    await ensureCashFlowAuditSchema();
    await db.execute(sql`
      INSERT INTO cash_flow_audit (event_id, change_type, before, after)
      VALUES (${eventId}, ${changeType}, ${JSON.stringify(before)}::jsonb, ${JSON.stringify(after)}::jsonb)
    `);
  } catch (err) {
    // Audit logging must never block or roll back the underlying ledger
    // change itself — surface loudly (so a persistent failure is visible in
    // logs/diagnostics) rather than throwing into the caller's request path.
    logger.error({ err, eventId, changeType }, "[cash-flow] audit trail insert failed");
  }
}

export async function getCashFlowAuditHistory(eventId: number) {
  await ensureCashFlowAuditSchema();
  return db.execute(sql`
    SELECT id, event_id, change_type, before, after, changed_at
    FROM cash_flow_audit WHERE event_id = ${eventId} ORDER BY changed_at DESC
  `);
}

export async function setCashFlowStatus(id: number, status: "confirmed" | "rejected"): Promise<CashFlowEvent | null> {
  await ensureCashFlowSchema();
  const before = (await db.select().from(cashFlowEvents).where(eq(cashFlowEvents.id, id)))[0] ?? null;
  const rows = await db.update(cashFlowEvents)
    .set({ status, updatedAt: new Date() })
    .where(eq(cashFlowEvents.id, id))
    .returning();
  const after = rows[0] ?? null;
  if (before && after) await recordCashFlowAudit(id, "status", before, after);
  return after;
}

export async function editCashFlowEvent(id: number, patch: {
  ts?: Date; amountCents?: number; note?: string | null;
}): Promise<CashFlowEvent | null> {
  await ensureCashFlowSchema();
  const before = (await db.select().from(cashFlowEvents).where(eq(cashFlowEvents.id, id)))[0] ?? null;
  const rows = await db.update(cashFlowEvents)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(cashFlowEvents.id, id))
    .returning();
  const after = rows[0] ?? null;
  if (before && after) await recordCashFlowAudit(id, "edit", before, after);
  return after;
}

export async function listCashFlowEvents(opts: {
  paperMode: boolean; status?: CashFlowStatus; since?: Date; until?: Date;
}): Promise<CashFlowEvent[]> {
  await ensureCashFlowSchema();
  const conds = [eq(cashFlowEvents.paperMode, opts.paperMode)];
  if (opts.status) conds.push(eq(cashFlowEvents.status, opts.status));
  if (opts.since)  conds.push(gt(cashFlowEvents.ts, opts.since));
  if (opts.until)  conds.push(lte(cashFlowEvents.ts, opts.until));
  return db.select().from(cashFlowEvents).where(and(...conds)).orderBy(asc(cashFlowEvents.ts));
}

/** Confirmed flows within (since, until] for a mode — the only set ROI math may use. */
export async function listConfirmedFlowsInWindow(mode: "live" | "paper", since: Date, until: Date): Promise<CashFlowEvent[]> {
  return listCashFlowEvents({ paperMode: mode === "paper", status: "confirmed", since, until });
}

// ── Equity bounds for the Dietz calc ─────────────────────────────────────────
// V0/V1 are day-bucket approximations from daily_equity_days (documented
// limitation — see computeModifiedDietz doc comment), except V1 prefers the
// bot's live in-memory balance when `until` is effectively "now", since
// today's daily_equity_days row can be up to 60s stale (persist throttle).

export async function findStartEquityCents(since: Date, mode: "live" | "paper"): Promise<number | null> {
  const sinceDate = since.toISOString().slice(0, 10);
  const onOrBefore = await db
    .select()
    .from(dailyEquityDays)
    .where(and(eq(dailyEquityDays.paperMode, mode === "paper"), lte(dailyEquityDays.date, sinceDate)))
    .orderBy(desc(dailyEquityDays.date))
    .limit(1);
  if (onOrBefore[0]) return onOrBefore[0].startEquityCents;

  const earliest = await db
    .select()
    .from(dailyEquityDays)
    .where(eq(dailyEquityDays.paperMode, mode === "paper"))
    .orderBy(asc(dailyEquityDays.date))
    .limit(1);
  return earliest[0]?.startEquityCents ?? null;
}

export async function findEndEquityCents(until: Date, mode: "live" | "paper"): Promise<number | null> {
  const untilDate = until.toISOString().slice(0, 10);
  const rows = await db
    .select()
    .from(dailyEquityDays)
    .where(and(eq(dailyEquityDays.paperMode, mode === "paper"), lte(dailyEquityDays.date, untilDate)))
    .orderBy(desc(dailyEquityDays.date))
    .limit(1);
  const row = rows[0];
  return row ? (row.endEquityCents ?? row.startEquityCents) : null;
}

/**
 * Live in-memory balance for "right now", read via a caller-supplied getter
 * so this module never imports trading-bot.ts (avoids a circular import —
 * trading-bot.ts imports insertAutoCashFlowEvent from here).
 */
export async function findEquityBounds(opts: {
  since: Date; until: Date; mode: "live" | "paper";
  getLiveEquityCents: () => number | null;
}): Promise<{ v0Cents: number | null; v1Cents: number | null }> {
  const v0Cents = await findStartEquityCents(opts.since, opts.mode);
  const now = new Date();
  const untilIsNow = Math.abs(opts.until.getTime() - now.getTime()) < 5 * 60_000;
  if (untilIsNow) {
    const live = opts.getLiveEquityCents();
    if (live != null) return { v0Cents, v1Cents: live };
  }
  const v1Cents = await findEndEquityCents(opts.until, opts.mode);
  return { v0Cents, v1Cents };
}

// ── Modified Dietz return (pure, testable) ───────────────────────────────────

export interface DietzFlow { ts: Date; amountCents: number }

export interface DietzResult {
  /** Modified Dietz return, as a percentage. Null when there's no usable capital base. */
  roiPct:               number | null;
  /** (V1-V0-netExternal)/V0 — ignores flow timing, useful as a sanity cross-check. */
  simpleResidualPct:    number | null;
  sumDepositsCents:     number;
  /** Negative (or zero). */
  sumWithdrawalsCents:  number;
  netExternalCents:     number;
}

/**
 * Modified Dietz return over [t0, t1], given starting/ending equity and any
 * CONFIRMED external cash flows in between (caller must pre-filter to
 * confirmed — see listConfirmedFlowsInWindow). Each flow is weighted by the
 * fraction of the window remaining after it lands — a deposit on day 1 of a
 * 10-day window was working capital for nearly the whole window and counts
 * almost fully toward the denominator; a deposit on the last day barely
 * counts at all.
 *
 *   R = (V1 − V0 − ΣF_i) / (V0 + Σ(w_i × F_i))
 *   w_i = (t1 − t_i) / (t1 − t0)
 *
 * V0/V1 are day-bucket snapshots (see findEquityBounds), not the exact
 * instantaneous equity at t0/t1 — documented approximation, same limitation
 * the pre-existing single-baseline ROI calc already had.
 */
export function computeModifiedDietz(opts: {
  v0Cents: number; v1Cents: number; t0: Date; t1: Date; flows: DietzFlow[];
}): DietzResult {
  const { v0Cents, v1Cents, t0, t1, flows } = opts;
  const totalMs = t1.getTime() - t0.getTime();

  let sumF = 0;
  let weightedF = 0;
  let sumDeposits = 0;
  let sumWithdrawals = 0;
  for (const f of flows) {
    sumF += f.amountCents;
    if (f.amountCents > 0) sumDeposits += f.amountCents;
    else sumWithdrawals += f.amountCents;
    // Clamp a flow outside [t0,t1] to the boundary instead of letting the
    // weight go negative or >1 (shouldn't happen — caller filters by window).
    const clampedTs = Math.min(Math.max(f.ts.getTime(), t0.getTime()), t1.getTime());
    const w = totalMs > 0 ? (t1.getTime() - clampedTs) / totalMs : 0.5;
    weightedF += w * f.amountCents;
  }

  const denominator = v0Cents + weightedF;
  const numerator    = v1Cents - v0Cents - sumF;
  const roiPct            = denominator > 0 ? (numerator / denominator) * 100 : null;
  const simpleResidualPct = v0Cents > 0 ? (numerator / v0Cents) * 100 : null;

  return {
    roiPct,
    simpleResidualPct,
    sumDepositsCents:    sumDeposits,
    sumWithdrawalsCents: sumWithdrawals,
    netExternalCents:    sumF,
  };
}
