/**
 * advice-observe.test.ts — OBSERVE helpers. Never ENABLE.
 */
import assert from "node:assert/strict";
import test from "node:test";
import {
  AUTO_MODE,
  DEAD_ZONE_SECS,
  DUAL_ASK_SUM_MAX_CENTS,
  LATE_NO_CHASE_SECS,
  LIVE_APPLY,
  LIVE_APPLY_ENABLED,
  PAPER_MODE,
  dualAskUnder98,
  isDeadZone,
  isLateNoChase,
} from "./advice-observe.js";
import { EV_FLOOR, HARD_RISK_LIMITS } from "./admission.js";
import { collectAdviceShadow, formatAdviceDeskLine } from "./advice-shadow.js";

test("locks: LIVE_APPLY false, paperMode true, autoMode false", () => {
  assert.equal(LIVE_APPLY, false);
  assert.equal(LIVE_APPLY_ENABLED, false);
  assert.equal(PAPER_MODE, true);
  assert.equal(AUTO_MODE, false);
  assert.equal(DEAD_ZONE_SECS, 120);
  assert.equal(DUAL_ASK_SUM_MAX_CENTS, 98);
  assert.equal(LATE_NO_CHASE_SECS, 180);
  assert.equal(EV_FLOOR, 3);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
});

test("dead zone last 120s", () => {
  assert.equal(isDeadZone(120), true);
  assert.equal(isDeadZone(119), true);
  assert.equal(isDeadZone(121), false);
  assert.equal(isDeadZone(null), false);
});

test("dual-ask under 98 is OBSERVE not a take", () => {
  assert.equal(dualAskUnder98(40, 57), true);
  assert.equal(dualAskUnder98(50, 50), false);
  assert.equal(dualAskUnder98(null, 40), false);
});

test("late NO chase: NO under 180s is chase; YES is not", () => {
  assert.equal(isLateNoChase("no", 179), true);
  assert.equal(isLateNoChase("NO", 100), true);
  assert.equal(isLateNoChase("no", 180), false);
  assert.equal(isLateNoChase("yes", 100), false);
});


test("SHADOW labels never APPROVED; dual-ask is OBSERVE not a fill", () => {
  const labels = collectAdviceShadow({
    currentPrice: 65100, floorStrike: 65000, velocityDolPerMin: 5, threeMinVelocity: 5,
    isStalling: false, stallStrength: "none", distFromFloorPct: 0.1, massAboveFloor: 50,
    secsRemaining: 400, yesAsk: 18, noAsk: 83, yesBid: 16, noBid: 81,
  });
  for (const l of labels) {
    assert.equal(l.approved, false);
  }
  const line = formatAdviceDeskLine({ yesAsk: 40, noAsk: 57, secsRemaining: 400 }, []);
  assert.equal(line, "OBSERVE dual-ask<98");
  assert.equal(line?.includes("APPROVED"), false);
});
