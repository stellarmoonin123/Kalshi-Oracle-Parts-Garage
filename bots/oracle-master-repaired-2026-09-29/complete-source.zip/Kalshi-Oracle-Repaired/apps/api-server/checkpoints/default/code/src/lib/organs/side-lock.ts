/**
 * side-lock organ — side-before-p stack (Heavy B#2 safe extract).
 *
 * Owns the documented admission order. Implementation stays in
 * aligned-take-gate + direction-w2 (+ analog completed-only from direction-lock).
 * No new branches. No W1 starve. No ENTRY/EV cuts. No ENABLE.
 *
 * Side-before-p (strict):
 *   1. alignedTakeGate — TAKE {CC|LAG, side, ask, p, ev} or SKIP
 *      Side lock first; p = P(filled side) only after side chosen.
 *      Constructed NO uses noAsk / P(NO). Leftover cannot beat a TAKE.
 *   2. direction_w2 / lockSide — veto when DEFINED (AFTER side lock)
 *      LOCKSIDE_CONTEXT tags + V5–V10 (PIN/CLEAR, S/R, channel, vol confirm)
 *      lockSide from alignedTakeGate TAKE = Kalshi strike ticket.
 *      NOT W1 require-all starve. Missing sensors ≠ skip.
 *      UNPROVEN lag does not veto CC. Dead venue2 does not skip.
 *      lag_disagree needs explicit lagSide (never invent from 1s proj).
 *      Soft (demoted off fill): ha_disagree, pin_reachable, pack,
*      CHANNEL_FADE / at-R/at-S / pattern_not_clear — tags only.
 *   3. analog completed-only — ANALOG_DEF = completed_15m_close_vs_prior
 *      Forming wick ignored; missing analog = no skip.
 *
 * TradingBot call sites import alignedTakeGate / direction_w2 / overlays
 * from this surface (same semantics as prior direct imports).
 */
import {
  alignedTakeGate,
  overlayAlignedTake,
  formatConstructedNoLog,
  mtfSignToSide,
  isLeftoverStrategyId,
  type AlignedTake,
  type AlignedTakeInput,
  type AlignedMtfSign,
} from "../aligned-take-gate.js";
import {
  direction_w2,
  overlayDirectionW2,
  formatDirectionW2Log,
  snapshotLastW2Log,
  shouldEmitDirectionW2Log,
  createDirectionW2LogThrottleState,
  W2_LOG_THROTTLE_MS,
  strikeStillReachable,
  PACK_SOFT_TAG,
  PATTERN_NOT_CLEAR_SKIP,
  type DirectionW2,
  type DirectionW2Input,
  type DirectionW2Log,
  type DirectionW2LogThrottleState,
  type LastW2LogSnapshot,
  type W2Side,
} from "./direction-w2.js";
import {
  ANALOG_DEF,
  analogCompleted15mSide,
  type Analog15mBar,
} from "./direction-lock.js";
import {
  lockSide,
  buildLockSideTags,
  LOCKSIDE_CONTEXT_LOADED,
  formatLockSideLoadedLog,
  type LockSideObs,
  type LockSideOut,
  type LockSideTags,
} from "./lock-side-context.js";

export const SIDE_LOCK_LOADED = true as const;
/** Durable falsify line when organ is missing from the live wire. */
export const SIDE_LOCK_NOT_LOADED = "[SIDE_LOCK] not loaded";

export function formatSideLockLoadedLog(): string {
  return "[SIDE_LOCK] loaded";
}

export {
  alignedTakeGate,
  overlayAlignedTake,
  formatConstructedNoLog,
  mtfSignToSide,
  isLeftoverStrategyId,
  direction_w2,
  overlayDirectionW2,
  formatDirectionW2Log,
  snapshotLastW2Log,
  shouldEmitDirectionW2Log,
  createDirectionW2LogThrottleState,
  W2_LOG_THROTTLE_MS,
  strikeStillReachable,
  PACK_SOFT_TAG,
  PATTERN_NOT_CLEAR_SKIP,
  ANALOG_DEF,
  analogCompleted15mSide,
  lockSide,
  buildLockSideTags,
  LOCKSIDE_CONTEXT_LOADED,
  formatLockSideLoadedLog,
};
export type {
  AlignedTake,
  AlignedTakeInput,
  AlignedMtfSign,
  DirectionW2,
  DirectionW2Input,
  DirectionW2Log,
  DirectionW2LogThrottleState,
  LastW2LogSnapshot,
  W2Side,
  Analog15mBar,
  LockSideObs,
  LockSideOut,
  LockSideTags,
};
