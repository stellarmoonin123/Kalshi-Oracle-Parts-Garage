/**
 * Money-gate EVALUATING card: real take checklist, not composite 74.
 */
import assert from "node:assert/strict";
import test from "node:test";
import {
  buildMoneyGateCard,
  demoteMoneyGateCardToSit,
  toMoneyGateSitReason,
  sessionClockLabel,
  sessionLabelHasRegimeAdjective,
  MONEY_GATE_THRESHOLD,
} from "./money-gate-card.js";
import type { AlignedTake } from "./aligned-take-gate.js";
import type { DirectionW2, DirectionW2Log } from "./organs/direction-w2.js";
import { HA_DISAGREE_SKIP } from "./organs/direction-w2.js";

function w2Log(over: Partial<DirectionW2Log>): DirectionW2Log {
  return {
    mtf_side: null,
    lock_side: null,
    ha_side: null,
    analog_side: null,
    analog_def: "completed_15m_close_vs_prior",
    brti_side: null,
    brti_defined: false,
    venue2_side: null,
    venue2_live: false,
    lag_proven: false,
    lag_side: null,
    pin_reachable: false,
    ask_cents: null,
    lock_result: "PASS",
    skip_reason: null,
    ...over,
  };
}

function w2Pass(side: "yes" | "no", ask: number): DirectionW2 {
  return {
    kind: "PASS",
    side,
    ask,
    log: {
      mtf_side: side,
      lock_side: side,
      ha_side: side,
      analog_side: side,
      analog_def: "completed_15m_close_vs_prior",
      brti_side: side,
      brti_defined: true,
      venue2_side: null,
      venue2_live: false,
      lag_proven: true,
      lag_side: side,
      pin_reachable: false,
      ask_cents: ask,
      lock_result: "PASS",
      skip_reason: null,
    },
  };
}


function w2PassHaTagged(side: "yes" | "no", ask: number): DirectionW2 {
  const base = w2Pass(side, ask);
  const opp = side === "yes" ? "no" : "yes";
  return {
    ...base,
    log: {
      ...base.log,
      ha_side: opp,
      lockSide_why: HA_DISAGREE_SKIP,
      lockSide: {
        result: "PASS",
        why: HA_DISAGREE_SKIP,
      } as any,
    },
  };
}

function w2Skip(reason: string, side: "yes" | "no" | null = "yes"): DirectionW2 {
  return {
    kind: "SKIP",
    reason,
    log: {
      mtf_side: side,
      lock_side: side,
      ha_side: reason === HA_DISAGREE_SKIP ? (side === "yes" ? "no" : "yes") : side,
      analog_side: null,
      analog_def: "completed_15m_close_vs_prior",
      brti_side: null,
      brti_defined: false,
      venue2_side: null,
      venue2_live: false,
      lag_proven: false,
      lag_side: null,
      pin_reachable: false,
      ask_cents: 31,
      lock_result: "SKIP",
      skip_reason: reason,
    },
  };
}

test("session clock labels have no choppy/regime adjectives", () => {
  for (let h = 0; h < 24; h++) {
    const label = sessionClockLabel(h);
    assert.equal(sessionLabelHasRegimeAdjective(label), false, `hour ${h}: ${label}`);
    assert.doesNotMatch(label, /choppy/i);
  }
  assert.equal(sessionClockLabel(4), "Asia mid");
  assert.equal(sessionClockLabel(1), "Asia open");
});

test("MTF flat → SKIP headline, no SHORT lean, side lock fails", () => {
  const aligned: AlignedTake = { kind: "SKIP", reason: "mtf_sign_null" };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Skip("mtf_sign_null", null),
    mtfSign: 0,
    lagProven: true,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(card.kind, "SKIP");
  assert.match(card.headline, /^SKIP ·/);
  assert.equal(card.direction, "FLAT");
  assert.equal(card.checks.find(c => c.id === "SIDE_LOCK")?.passed, false);
  assert.match(card.checks.find(c => c.id === "SIDE_LOCK")!.value ?? "", /FLAT/);
  // Ask door is N/A when flat — do not paint false ASK_BAND fail / "ask missing".
  assert.equal(card.checks.find(c => c.id === "ASK_BAND")?.passed, true);
  assert.match(card.checks.find(c => c.id === "ASK_BAND")!.value ?? "", /N\/A/);
  // EV unknown until TAKE is N/A pass — not a hard fail that buries SIDE_LOCK.
  assert.equal(card.checks.find(c => c.id === "EV")?.passed, true);
  assert.match(card.checks.find(c => c.id === "EV")!.value ?? "", /N\/A/);
  assert.equal(card.compositeIsFillGate, false);
});

test("session cannot make a CC take into SKIP via money gate (clock is not a check fail)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 31,
    p: 0.62,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: false, // CC — lag not required
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
    sessionClockLabel: sessionClockLabel(4), // Asia mid
  });
  assert.equal(card.kind, "TAKE");
  assert.match(card.headline, /TAKE YES @31¢/);
  assert.match(card.headline, /W2 PASS/);
  assert.ok(!card.checks.some(c => c.id === "SESSION"));
  assert.equal(card.sessionLabel, "Asia mid");
  assert.equal(sessionLabelHasRegimeAdjective(card.sessionLabel!), false);
});

test("composite score theater cannot placeOrder — money gate TAKE needs aligned+W2+EV", () => {
  // High composite would be theater; without aligned TAKE we stay SKIP.
  const aligned: AlignedTake = { kind: "SKIP", reason: "ask_out_of_band" };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Skip("ask_out_of_band"),
    mtfSign: 3,
    lagProven: true,
    secsRemaining: 600,
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.approved, false);
  assert.equal(card.compositeIsFillGate, false);
  assert.equal(card.scoreThreshold, MONEY_GATE_THRESHOLD);
  assert.match(card.headline, /ask_out_of_band|SKIP/);
  // EV unknown is N/A — do not paint false EV fail under ASK_OUT_OF_BAND.
  assert.equal(card.checks.find(c => c.id === "EV")?.passed, true);
  assert.match(card.checks.find(c => c.id === "EV")!.value ?? "", /N\/A/);
});

test("EV unknown until TAKE is N/A pass under rich NO ask (ASK_OUT_OF_BAND)", () => {
  const aligned: AlignedTake = { kind: "SKIP", reason: "ask_out_of_band" };
  const w2: DirectionW2 = {
    ...w2Skip("ask_out_of_band", "no"),
    log: { ...w2Skip("ask_out_of_band", "no").log, ask_cents: 93, mtf_side: "no", lock_side: "no" },
  };
  const card = buildMoneyGateCard({
    aligned,
    w2,
    mtfSign: -4,
    lagProven: false,
    secsRemaining: 400,
    strategyId: null,
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.skipReason, "ASK_OUT_OF_BAND");
  assert.equal(card.headline, "SKIP · ASK_OUT_OF_BAND");
  const ev = card.checks.find(c => c.id === "EV");
  assert.equal(ev?.passed, true);
  assert.match(ev!.value ?? "", /N\/A/);
  assert.match(ev!.detail, /N\/A until aligned TAKE/);
  assert.equal(card.checks.find(c => c.id === "ASK_BAND")?.passed, false);
});

test("TAKE YES @31 EV≥3 · W2 PASS when all money checks clear", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 31,
    p: 0.65,
    ev: 8.2,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: false,
    secsRemaining: 500,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(card.kind, "TAKE");
  assert.equal(card.approved, true);
  assert.equal(card.overallScore, 100);
  assert.ok(card.checks.every(c => c.passed));
  assert.match(card.headline, /TAKE YES @31¢ EV 8¢ · W2 PASS/);
});

test("ha_disagree → tag only; TAKE when hard gates pass (not Gate 74)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 31,
    p: 0.65,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2PassHaTagged("yes", 31),
    mtfSign: 2,
    lagProven: true,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(card.kind, "TAKE");
  assert.match(card.headline, /TAKE YES @31¢/);
  assert.doesNotMatch(card.headline, /Gate 74|\/100/);
  assert.equal(card.checks.find(c => c.id === "HA")?.passed, true);
  assert.match(card.checks.find(c => c.id === "HA")!.detail, /tag only/);
});

test("LAG path requires lagProven; CC does not", () => {
  const alignedLag: AlignedTake = {
    kind: "TAKE",
    strategyId: "BASIS_LAG_EDGE",
    side: "no",
    ask: 33,
    p: 0.6,
    ev: 5,
  };
  const skipLag = buildMoneyGateCard({
    aligned: alignedLag,
    w2: w2Pass("no", 33),
    mtfSign: -2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "BASIS_LAG_EDGE",
  });
  assert.equal(skipLag.kind, "SKIP");
  assert.equal(skipLag.checks.find(c => c.id === "LAG_PROVEN")?.passed, false);

  const takeCc = buildMoneyGateCard({
    aligned: { ...alignedLag, strategyId: "CONFLUENCE_CASCADE", side: "yes", ask: 31 },
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(takeCc.checks.find(c => c.id === "LAG_PROVEN")?.passed, true);
});

test("still-mid ask fails ASK_BAND check", () => {
  const aligned: AlignedTake = { kind: "SKIP", reason: "still_mid_unclear" };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Skip("still_mid_unclear"),
    mtfSign: 1,
    secsRemaining: 600,
  });
  // ask from w2 log is 31 in helper — force via PASS log ask 50 by custom
  const mid: DirectionW2 = {
    kind: "SKIP",
    reason: "still_mid_unclear",
    log: { ...w2Skip("still_mid_unclear").log, ask_cents: 50 },
  };
  const card2 = buildMoneyGateCard({
    aligned,
    w2: mid,
    mtfSign: 1,
    secsRemaining: 600,
  });
  assert.equal(card2.checks.find(c => c.id === "ASK_BAND")?.passed, false);
  assert.equal(card.kind, "SKIP");
});

test("pin_reachable tag-only: TAKE when hard gates pass (demoted like ha_disagree)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "no",
    ask: 34,
    p: 0.62,
    ev: 16.1,
  };
  const w2 = w2Pass("no", 34);
  w2.log.pin_reachable = true;
  w2.log.lockSide_why = "pin_reachable";
  (w2.log as { lockSide?: { result: string; why: string } }).lockSide = {
    result: "PASS",
    why: "pin_reachable",
  };
  const card = buildMoneyGateCard({
    aligned,
    w2,
    mtfSign: -2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(card.kind, "TAKE");
  assert.match(card.headline, /^TAKE NO @34¢/);
  assert.equal(card.w2Result, "PASS");
});

test("hard W2 skip headline stays short — no lockSide dump", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "no",
    ask: 34,
    p: 0.62,
    ev: 16.1,
  };
  const w2 = w2Skip("brti_disagree", "no");
  (w2.log as { lockSide?: { result: string; why: string } }).lockSide = {
    result: "SKIP",
    why: "brti_disagree",
  };
  const card = buildMoneyGateCard({
    aligned,
    w2,
    mtfSign: -2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.headline, "SKIP · brti_disagree");
  assert.equal(card.skipReason, "brti_disagree");
  assert.doesNotMatch(card.headline, /lockSide\.result|lockSide\.why/);
  assert.doesNotMatch(card.skipReason ?? "", /\|/);
});

test("DESK DOOR: LAG ask 15¢ fails ASK_BAND (YES door 20, not LAG 10)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "BASIS_LAG_EDGE",
    side: "yes",
    ask: 15,
    p: 0.70,
    ev: 10,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 15),
    mtfSign: 2,
    lagProven: true,
    secsRemaining: 600,
    strategyId: "BASIS_LAG_EDGE",
  });
  assert.equal(card.checks.find(c => c.id === "ASK_BAND")?.passed, false);
  assert.equal(card.kind, "SKIP");
  assert.match(card.headline, /ask_out_of_band|SKIP/);
});

test("CC ask 15¢ still fails ASK_BAND (CC floor 28 kept)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 15,
    p: 0.70,
    ev: 10,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 15),
    mtfSign: 2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(card.checks.find(c => c.id === "ASK_BAND")?.passed, false);
  assert.equal(card.kind, "SKIP");
});

test("HARVEST + CC → SKIP SESSION_FAMILY (never false TAKE)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 31,
    p: 0.65,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: true,
    lagStale: false,
    sessionMode: "HARVEST",
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.skipReason, "HARVEST_CC_BLOCK");
  assert.equal(card.checks.find(c => c.id === "SESSION_FAMILY")?.passed, false);
});

test("HARVEST + LAG exempt → SESSION_FAMILY passes", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "BASIS_LAG_EDGE",
    side: "yes",
    ask: 31,
    p: 0.7,
    ev: 10,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: true,
    lagStale: false,
    sessionMode: "HARVEST",
    secsRemaining: 600,
    strategyId: "BASIS_LAG_EDGE",
  });
  assert.equal(card.checks.find(c => c.id === "SESSION_FAMILY")?.passed, true);
});

test("CC + short_series: LAG_UNPROVEN is LAG-only (CC LAG_PROVEN passes)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 31,
    p: 0.65,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: false,
    lagStale: false,
    lagReason: "short_series",
    sessionMode: "HUNT",
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  // PAPER DESK v2: assertLagAllowsMoneyMakerFill is LAG-only — CC must not inherit.
  assert.equal(card.checks.find(c => c.id === "LAG_PROVEN")?.passed, true);
  assert.equal(card.kind, "TAKE");
});

test("BUGFIX: headline matches ask_out_of_band not stale opposed_side when ASK_BAND is real fail", () => {
  // Aligned still says opposed_side, but card evaluates rich YES ask → ASK_BAND is the veto.
  const aligned: AlignedTake = { kind: "SKIP", reason: "opposed_side" };
  const w2: DirectionW2 = {
    kind: "SKIP",
    reason: "opposed_side",
    log: {
      ...w2Skip("opposed_side", "yes").log,
      ask_cents: 68,
      mtf_side: "yes",
      lock_side: "yes",
    },
  };
  const card = buildMoneyGateCard({
    aligned,
    w2,
    mtfSign: 2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.checks.find(c => c.id === "ASK_BAND")?.passed, false);
  assert.equal(card.skipReason, "ASK_OUT_OF_BAND");
  assert.equal(card.headline, "SKIP · ASK_OUT_OF_BAND");
  assert.doesNotMatch(card.headline, /opposed_side/);
});

test("BUGFIX: YES rich + NO in-band → money gate evaluates NO wing when aligned TAKE NO", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "no",
    ask: 33,
    p: 0.62,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("no", 33),
    mtfSign: 2, // MTF leaned YES — wing flipped to cheap NO
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(card.kind, "TAKE");
  assert.equal(card.side, "no");
  assert.equal(card.ask, 33);
  assert.match(card.headline, /TAKE NO @33¢/);
  assert.equal(card.checks.find(c => c.id === "ASK_BAND")?.passed, true);
});

test("DESK DOOR: YES@12 fails ASK_BAND (no LAG 10–55 lie)", () => {
  const aligned = {
    kind: "TAKE" as const,
    strategyId: "BASIS_LAG_EDGE" as const,
    side: "yes" as const,
    ask: 12,
    p: 0.55,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: { kind: "PASS", reason: null, log: {
      mtf_side: "yes", lock_side: "yes", ha_side: null, analog_side: "yes",
      analog_def: "completed_15m_close_vs_prior", brti_side: "yes", brti_defined: true,
      venue2_side: null, venue2_live: false, lag_proven: true, lag_side: "yes",
      pin_reachable: false, ask_cents: 12, lock_result: "PASS", skip_reason: null,
    } } as any,
    mtfSign: 2,
    lagProven: true,
    lagStale: false,
    secsRemaining: 400,
  });
  const ask = card.checks.find(c => c.id === "ASK_BAND");
  assert.ok(ask);
  assert.equal(ask!.passed, false);
  assert.match(ask!.name, /20/);
  assert.match(card.headline, /ask_out_of_band|SKIP/);
});

test("DESK DOOR: YES@20 PASS ASK_BAND; YES@19 FAIL", () => {
  const pass20 = buildMoneyGateCard({
    aligned: {
      kind: "TAKE",
      strategyId: "CONFLUENCE_CASCADE",
      side: "yes",
      ask: 20,
      p: 0.62,
      ev: 8,
    },
    w2: w2Pass("yes", 20),
    mtfSign: 2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(pass20.checks.find(c => c.id === "ASK_BAND")?.passed, true);

  const fail19 = buildMoneyGateCard({
    aligned: {
      kind: "TAKE",
      strategyId: "CONFLUENCE_CASCADE",
      side: "yes",
      ask: 19,
      p: 0.62,
      ev: 8,
    },
    w2: w2Pass("yes", 19),
    mtfSign: 2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(fail19.checks.find(c => c.id === "ASK_BAND")?.passed, false);
  assert.equal(fail19.kind, "SKIP");
  assert.equal(fail19.skipReason, "ASK_OUT_OF_BAND");
});

test("DESK DOOR: YES@31 passes ASK_BAND", () => {
  const aligned = {
    kind: "TAKE" as const,
    strategyId: "CONFLUENCE_CASCADE" as const,
    side: "yes" as const,
    ask: 31,
    p: 0.55,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: { kind: "PASS", reason: null, log: {
      mtf_side: "yes", lock_side: "yes", ha_side: "yes", analog_side: "yes",
      analog_def: "completed_15m_close_vs_prior", brti_side: "yes", brti_defined: true,
      venue2_side: null, venue2_live: false, lag_proven: true, lag_side: "yes",
      pin_reachable: false, ask_cents: 31, lock_result: "PASS", skip_reason: null,
    } } as any,
    mtfSign: 2,
    lagProven: true,
    lagStale: false,
    secsRemaining: 400,
  });
  const ask = card.checks.find(c => c.id === "ASK_BAND");
  assert.ok(ask);
  assert.equal(ask!.passed, true);
});

test("DESK DOOR: NO@20 PASS ASK_BAND; NO@19 FAIL", () => {
  const pass20 = buildMoneyGateCard({
    aligned: {
      kind: "TAKE",
      strategyId: "CONFLUENCE_CASCADE",
      side: "no",
      ask: 20,
      p: 0.62,
      ev: 8,
    },
    w2: w2Pass("no", 20),
    mtfSign: -2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(pass20.checks.find(c => c.id === "ASK_BAND")?.passed, true);
  assert.match(pass20.checks.find(c => c.id === "ASK_BAND")!.name, /Ask YES 20–55 \/ NO 20–55/);

  const fail19 = buildMoneyGateCard({
    aligned: {
      kind: "TAKE",
      strategyId: "CONFLUENCE_CASCADE",
      side: "no",
      ask: 19,
      p: 0.62,
      ev: 8,
    },
    w2: w2Pass("no", 19),
    mtfSign: -2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(fail19.checks.find(c => c.id === "ASK_BAND")?.passed, false);
  assert.equal(fail19.kind, "SKIP");
  assert.equal(fail19.skipReason, "ASK_OUT_OF_BAND");
});

test("DESK DOOR: still-mid YES@50 FAIL ASK_BAND", () => {
  const mid = buildMoneyGateCard({
    aligned: {
      kind: "TAKE",
      strategyId: "BASIS_LAG_EDGE",
      side: "yes",
      ask: 50,
      p: 0.7,
      ev: 10,
    },
    w2: w2Pass("yes", 50),
    mtfSign: 2,
    lagProven: true,
    secsRemaining: 600,
    strategyId: "BASIS_LAG_EDGE",
  });
  assert.equal(mid.checks.find(c => c.id === "ASK_BAND")?.passed, false);
  assert.equal(mid.kind, "SKIP");
  assert.equal(mid.skipReason, "STILL_MID");
});

test("Phase2: NO vs +56$/min → SKIP · CC_VEL_AGAINST_NO (never TAKE)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "no",
    ask: 31,
    p: 0.62,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("no", 31),
    mtfSign: -2,
    lagProven: true,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
    velocityDolPerMin: 56,
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.skipReason, "CC_VEL_AGAINST_NO");
  assert.match(card.headline, /CC_VEL_AGAINST/);
  assert.equal(card.checks.find(c => c.id === "CC_VEL")?.passed, false);
});

test("Phase2: LAG path lagProven false → SKIP · LAG_COLD (never TAKE)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "BASIS_LAG_EDGE",
    side: "yes",
    ask: 31,
    p: 0.7,
    ev: 10,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: false,
    lagStale: true,
    lagReason: "short_series",
    secsRemaining: 600,
    strategyId: "BASIS_LAG_EDGE",
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.skipReason, "LAG_COLD");
  assert.equal(card.checks.find(c => c.id === "LAG_PROVEN")?.passed, false);
});

test("Phase2: quote age >5s → SKIP · NO_TAPE (Clock A)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 31,
    p: 0.65,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: false,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
    quoteAgeMs: 5500,
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.skipReason, "NO_TAPE");
  assert.equal(card.checks.find(c => c.id === "NO_TAPE")?.passed, false);
});

test("Phase2 T1: pinHard → SKIP · PIN (never TAKE)", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 50,
    p: 0.55,
    ev: 5,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 50),
    mtfSign: 2,
    lagProven: true,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
    pinHard: true,
    quoteAgeMs: 500,
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.skipReason, "PIN");
  assert.equal(card.checks.find(c => c.id === "PIN")?.passed, false);
});

test("Phase2 Sat HARVEST_CC_BLOCK: N/A under always-HUNT; injected HARVEST maps to HARVEST_CC_BLOCK", () => {
  // Document: getCurrentSessionMode is always HUNT — Sat does not force HARVEST.
  // Card emits HARVEST_CC_BLOCK only when sessionMode==="HARVEST" is injected.
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 31,
    p: 0.65,
    ev: 8,
  };
  const hunt = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: true,
    sessionMode: "HUNT",
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
    quoteAgeMs: 500,
  });
  assert.equal(hunt.kind, "TAKE");
  assert.equal(hunt.checks.find(c => c.id === "SESSION_FAMILY")?.passed, true);

  const injected = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: true,
    sessionMode: "HARVEST",
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
    quoteAgeMs: 500,
  });
  assert.equal(injected.kind, "SKIP");
  assert.equal(injected.skipReason, "HARVEST_CC_BLOCK");
});

test("Phase2: PATH_GATE hard block → SKIP · PATH_GATE", () => {
  const aligned: AlignedTake = {
    kind: "TAKE",
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 31,
    p: 0.65,
    ev: 8,
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: w2Pass("yes", 31),
    mtfSign: 2,
    lagProven: true,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
    pathGateBlocked: true,
    pathGateReason: "overlay reject",
    quoteAgeMs: 500,
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.skipReason, "PATH_GATE");
});


test("demoteMoneyGateCardToSit: TAKE becomes named SKIP for operator honesty", () => {
  const take = buildMoneyGateCard({
    aligned: { kind: "TAKE", side: "yes", ask: 38, strategyId: "CONFLUENCE_CASCADE", p: 0.7, ev: 12.5, constructedNo: false, goldCopy: false },
    w2: { kind: "PASS", side: "yes", ask: 38, log: w2Log({ mtf_side: "yes", lag_proven: true, lock_result: "PASS", pin_reachable: false, skip_reason: null }) },
    mtfSign: 2,
    lagProven: true,
    lagStale: false,
    sessionMode: "HUNT",
    secsRemaining: 400,
    strategyId: "CONFLUENCE_CASCADE",
    sessionClockLabel: "NY+London",
    velocityDolPerMin: 10,
    quoteAgeMs: 500,
    pinHard: false,
    pathGateBlocked: false,
  });
  // If build fails to TAKE (missing fixtures), still demote a synthetic card.
  const base = take.approved
    ? take
    : { ...take, kind: "TAKE" as const, approved: true, headline: "TAKE YES @38¢", skipReason: null };
  const sit = demoteMoneyGateCardToSit(base, "PATH_GATE");
  assert.equal(sit.kind, "SKIP");
  assert.equal(sit.approved, false);
  assert.match(sit.headline, /SKIP/);
  assert.ok(sit.skipReason);
});


test("AND_SIT_HA_REGIME maps to named SIT — demote never leaves TAKE", () => {
  assert.equal(toMoneyGateSitReason("AND_SIT_HA_REGIME"), "AND_SIT_HA_REGIME");
  assert.equal(toMoneyGateSitReason("and_sit_ha_regime"), "AND_SIT_HA_REGIME");
  const take = buildMoneyGateCard({
    aligned: { kind: "TAKE", side: "no", ask: 40, strategyId: "CONFLUENCE_CASCADE", p: 0.6, ev: 8, constructedNo: false, goldCopy: false },
    w2: { kind: "PASS", side: "no", ask: 38, log: w2Log({ mtf_side: "no", ha_side: "yes", lag_proven: true, lock_result: "PASS", pin_reachable: false, skip_reason: null }) },
    mtfSign: -2,
    lagProven: true,
    lagStale: false,
    sessionMode: "HUNT",
    secsRemaining: 400,
    strategyId: "CONFLUENCE_CASCADE",
    sessionClockLabel: "NY+London",
    velocityDolPerMin: -5,
    quoteAgeMs: 500,
    pinHard: false,
    pathGateBlocked: false,
  });
  const base = take.approved
    ? take
    : { ...take, kind: "TAKE" as const, approved: true, headline: "TAKE NO @40¢", skipReason: null };
  const sit = demoteMoneyGateCardToSit(base, "AND_SIT_HA_REGIME");
  assert.equal(sit.kind, "SKIP");
  assert.equal(sit.approved, false);
  assert.equal(sit.skipReason, "AND_SIT_HA_REGIME");
  assert.match(sit.headline, /^SKIP · AND_SIT_HA_REGIME/);
  assert.doesNotMatch(sit.headline, /TAKE/);
});

test("V2 Phase2 card honesty: still-mid → named SIT STILL_MID, never sticky TAKE", () => {
  assert.equal(toMoneyGateSitReason("still_mid_unclear"), "STILL_MID");
  assert.equal(toMoneyGateSitReason("STILL_MID"), "STILL_MID");
  const aligned: AlignedTake = { kind: "SKIP", reason: "still_mid_unclear" };
  const mid: DirectionW2 = {
    kind: "SKIP",
    reason: "still_mid_unclear",
    log: { ...w2Skip("still_mid_unclear").log, ask_cents: 50 },
  };
  const card = buildMoneyGateCard({
    aligned,
    w2: mid,
    mtfSign: 1,
    secsRemaining: 600,
    strategyId: "CONFLUENCE_CASCADE",
    quoteAgeMs: 500,
  });
  assert.equal(card.kind, "SKIP");
  assert.equal(card.approved, false);
  assert.equal(card.skipReason, "STILL_MID");
  assert.match(card.headline, /SKIP/);
  assert.doesNotMatch(card.headline, /\bTAKE\b/);
});

test("V2 Phase2 card honesty: size-0 / later-gate skip → named SIT, no sticky TAKE", () => {
  assert.equal(toMoneyGateSitReason("SIZING_ZERO"), "SIZE_ZERO");
  assert.equal(toMoneyGateSitReason("SIZE_ZERO"), "SIZE_ZERO");
  assert.equal(toMoneyGateSitReason("DAILY_TARGET_SIZE_ZERO"), "SIZE_ZERO");
  assert.equal(toMoneyGateSitReason("PROTECTIVE_SIZE_ZERO"), "SIZE_ZERO");
  assert.equal(toMoneyGateSitReason("DEPTH_SIZE_ZERO"), "SIZE_ZERO");

  const take = buildMoneyGateCard({
    aligned: {
      kind: "TAKE",
      side: "yes",
      ask: 38,
      strategyId: "CONFLUENCE_CASCADE",
      p: 0.7,
      ev: 12.5,
      constructedNo: false,
      goldCopy: false,
    },
    w2: w2Pass("yes", 38),
    mtfSign: 2,
    lagProven: true,
    lagStale: false,
    sessionMode: "HUNT",
    secsRemaining: 400,
    strategyId: "CONFLUENCE_CASCADE",
    sessionClockLabel: "NY+London",
    velocityDolPerMin: 10,
    quoteAgeMs: 500,
    pinHard: false,
    pathGateBlocked: false,
  });
  const base = take.approved
    ? take
    : { ...take, kind: "TAKE" as const, approved: true, headline: "TAKE YES @38¢", skipReason: null };

  const sizeSit = demoteMoneyGateCardToSit(base, "SIZING_ZERO");
  assert.equal(sizeSit.kind, "SKIP");
  assert.equal(sizeSit.approved, false);
  assert.equal(sizeSit.skipReason, "SIZE_ZERO");
  assert.match(sizeSit.headline, /^SKIP · SIZE_ZERO/);
  assert.doesNotMatch(sizeSit.headline, /\bTAKE\b/);

  const pathSit = demoteMoneyGateCardToSit(base, "PATH_GATE");
  assert.equal(pathSit.kind, "SKIP");
  assert.equal(pathSit.approved, false);
  assert.equal(pathSit.skipReason, "PATH_GATE");
  assert.doesNotMatch(pathSit.headline, /\bTAKE\b/);

  const laterSit = demoteMoneyGateCardToSit(base, "EV_FLOOR");
  assert.equal(laterSit.kind, "SKIP");
  assert.equal(laterSit.approved, false);
  assert.ok(laterSit.skipReason);
  assert.doesNotMatch(laterSit.headline, /\bTAKE\b/);
});
