/**
 * CONFLUENCE_CASCADE velocity-against gate (#725).
 *
 * Momentum CC must not fire NO into strongly green 1m velocity (e.g. +$56/min),
 * nor YES into strongly red velocity. Fail-closed only when velocity is present;
 * missing velocity → do not invent a block.
 *
 * Not a new ENABLE. Not an LLM. Does not cut EV/Kelly floors.
 */
export const CC_VEL_AGAINST_ABS_DOL_PER_MIN = 40;

export type CcVelocityGateInput = {
  strategyId: string | null | undefined;
  side: "yes" | "no" | string;
  /** 1m velocity $/min. null/undefined/non-finite → no block. */
  velocityDolPerMin: number | null | undefined;
};

export type CcVelocityGateResult =
  | { block: false }
  | { block: true; reason: "CC_VEL_AGAINST_NO" | "CC_VEL_AGAINST_YES"; size: 0 };

/** Pure organ: SKIP / size 0 when CC side fights strong 1m velocity. */
export function ccVelocityAgainstGate(input: CcVelocityGateInput): CcVelocityGateResult {
  if (input.strategyId !== "CONFLUENCE_CASCADE") return { block: false };
  const vel = input.velocityDolPerMin;
  if (vel == null || !Number.isFinite(vel)) return { block: false };
  const side = typeof input.side === "string" ? input.side.toLowerCase() : "";
  if (side === "no" && vel >= CC_VEL_AGAINST_ABS_DOL_PER_MIN) {
    return { block: true, reason: "CC_VEL_AGAINST_NO", size: 0 };
  }
  if (side === "yes" && vel <= -CC_VEL_AGAINST_ABS_DOL_PER_MIN) {
    return { block: true, reason: "CC_VEL_AGAINST_YES", size: 0 };
  }
  return { block: false };
}
