import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  detectCandlePattern, scanRecentPatterns, isPatternReversalAgainstSide,
  BOTTOM_REVERSAL_PATTERNS, TOP_REVERSAL_PATTERNS, type CandlePatternName, type CandlePatternSignal,
} from './candlestick-patterns.js';
import type { RealCandle } from './market-candles.js';

let t0 = 1_700_000_000;
function candle(open: number, high: number, low: number, close: number): RealCandle {
  const c = { time: t0, open, high, low, close, volume: 100 };
  t0 += 60;
  return c;
}
/** A zero-body (open == close) filler candle. Every two-candle check in the
 *  detector gates on `prevBody > 0`, so this is inert context: it can never
 *  itself trigger an Engulfing/Harami/Piercing/Tweezer match against the
 *  candle that follows it, letting tests isolate the shape under test. */
function flat(n: number, price = 100): RealCandle[] {
  return Array.from({ length: n }, () => candle(price, price + 0.05, price - 0.05, price));
}
/** A candle with a normal, unremarkable body/wick ratio — should never itself
 *  match any pattern. Used only for the "no pattern anywhere" negative test,
 *  which needs a realistic repeating sequence rather than degenerate flats. */
function boring(n: number): RealCandle[] {
  return Array.from({ length: n }, () => candle(100, 107, 98, 105));
}

test('Bullish Marubozu: long solid body with no wicks', () => {
  const candles = [...flat(4), candle(100, 110, 100, 110)];
  const detected = detectCandlePattern(candles);
  assert.equal(detected?.pattern, 'BULLISH_MARUBOZU');
  assert.equal(detected?.signal, 'YES');
});

test('Bearish Marubozu: long solid down body with no wicks', () => {
  const candles = [...flat(4), candle(110, 110, 100, 100)];
  const detected = detectCandlePattern(candles);
  assert.equal(detected?.pattern, 'BEARISH_MARUBOZU');
  assert.equal(detected?.signal, 'NO');
});

test('Bullish Harami: small body engulfed inside a large prior falling candle', () => {
  const candles = [
    ...flat(3),
    candle(110, 111, 99, 100),   // large bearish candle, body 100-110
    candle(103, 106, 102, 105),  // small bullish body fully inside [100,110]
  ];
  const detected = detectCandlePattern(candles);
  assert.equal(detected?.pattern, 'BULLISH_HARAMI');
  assert.equal(detected?.signal, 'YES');
});

test('Morning Star: decline, small-bodied pause, reclaim reversal', () => {
  const candles = [
    ...boring(2),
    candle(130, 131, 119, 120),   // big bearish candle
    candle(119, 120, 117, 118.5), // small pause candle near the low
    candle(119, 132, 118, 131),   // big bullish candle reclaiming midpoint (125)
  ];
  const detected = detectCandlePattern(candles);
  assert.equal(detected?.pattern, 'MORNING_STAR');
  assert.equal(detected?.signal, 'YES');
});

test('Long-Legged Doji: open ≈ close with sizable wicks on both sides', () => {
  const candles = [...flat(4), candle(100, 105, 95, 100.01)];
  const detected = detectCandlePattern(candles);
  assert.equal(detected?.pattern, 'LONG_LEGGED_DOJI');
  assert.equal(detected?.signal, 'STAY_OUT');
});

test('Dragonfly Doji: open ≈ close sitting atop a long lower wick', () => {
  const candles = [...flat(4), candle(100, 100.1, 90, 100.02)];
  const detected = detectCandlePattern(candles);
  assert.equal(detected?.pattern, 'DRAGONFLY_DOJI');
  assert.equal(detected?.signal, 'YES');
});

test('Gravestone Doji: open ≈ close sitting at the bottom of a long upper wick', () => {
  const candles = [...flat(4), candle(100, 110, 99.9, 100.02)];
  const detected = detectCandlePattern(candles);
  assert.equal(detected?.pattern, 'GRAVESTONE_DOJI');
  assert.equal(detected?.signal, 'NO');
});

test('No pattern: an unremarkable candle sequence returns null', () => {
  const candles = boring(6);
  assert.equal(detectCandlePattern(candles), null);
});

test('scanRecentPatterns collapses a persisting shape into one event and reports barsAgo', () => {
  // Three IDENTICAL Bullish Marubozu candles back to back. Identical closes
  // keep Three White Soldiers from also matching (it requires strictly
  // higher closes each bar), isolating the single-candle Marubozu shape so
  // we can verify consecutive re-triggers collapse into one event.
  const marubozu = candle(100, 110, 100, 110);
  const candles = [...boring(4), marubozu, { ...marubozu, time: marubozu.time + 60 }, { ...marubozu, time: marubozu.time + 120 }];
  const events = scanRecentPatterns(candles, { maxBarsBack: 10 });
  const marubozuEvents = events.filter(e => e.pattern === 'BULLISH_MARUBOZU');
  assert.equal(marubozuEvents.length, 1, 'consecutive identical detections should collapse to one event');
  assert.equal(marubozuEvents[0].barsAgo, 0);
});

test('scanRecentPatterns returns [] when nothing recognizable is present', () => {
  const candles = boring(10);
  const events = scanRecentPatterns(candles);
  assert.deepEqual(events, []);
});

test('every detectable pattern name is a valid CandlePatternName union member (compile-time check placeholder)', () => {
  const sample: CandlePatternName = 'MORNING_DOJI_STAR';
  assert.ok(sample);
});

// ── Double Bottom / Double Top (swing structure, added 2026-08-18) ──────────
// These need real multi-candle price structure — two comparable extremes
// separated by a genuine bounce, plus a confirming close through the
// neckline — so they're built candle-by-candle rather than with the
// flat()/boring() helpers above.

test('Double Bottom: two comparable lows with a confirmed neckline breakout', () => {
  const candles = [
    candle(100, 101, 99, 100),
    candle(100, 101, 99, 100),
    candle(100, 101, 99, 100),
    candle(100, 101, 99, 100),
    candle(99, 100, 97, 98),      // decline into first low
    candle(98, 99, 90, 91),       // low #1 (90)
    candle(91, 96, 90.5, 95),     // bounce starts
    candle(95, 99, 94, 98),
    candle(98, 101, 97, 100),
    candle(100, 103, 99, 102),    // neckline peak (103)
    candle(101, 102, 96, 97),     // decline resumes
    candle(97, 98, 93, 94),
    candle(94, 95, 90.1, 91),     // low #2 (90.1) — within 0.15% of low #1
    candle(91, 95, 90.5, 94),     // bounce again, never revisits low #1
    candle(94, 99, 93, 98),
    candle(98, 106, 97, 105),     // confirmation candle: closes above the 103 neckline
  ];
  const detected = detectCandlePattern(candles);
  assert.equal(detected?.pattern, 'DOUBLE_BOTTOM');
  assert.equal(detected?.signal, 'YES');
  assert.ok(detected!.strength > 0 && detected!.strength <= 1);
});

test('Double Top: two comparable highs with a confirmed neckline breakdown', () => {
  const candles = [
    candle(100, 101, 99, 100),
    candle(100, 101, 99, 100),
    candle(100, 101, 99, 100),
    candle(100, 101, 99, 100),
    candle(101, 103, 100, 102),   // advance into first high
    candle(102, 110, 101, 109),   // high #1 (110)
    candle(109, 109.5, 104, 105), // pullback starts
    candle(105, 106, 101, 102),
    candle(102, 103, 99, 100),
    candle(100, 101, 97, 98),     // neckline trough (97)
    candle(99, 104, 98, 103),     // advance resumes
    candle(103, 107, 102, 106),
    candle(106, 109.9, 105, 109), // high #2 (109.9) — within 0.15% of high #1
    candle(109, 109.5, 105, 106), // pullback again, never revisits high #1
    candle(106, 107, 101, 102),
    candle(102, 103, 94, 95),     // confirmation candle: closes below the 97 neckline
  ];
  const detected = detectCandlePattern(candles);
  assert.equal(detected?.pattern, 'DOUBLE_TOP');
  assert.equal(detected?.signal, 'NO');
});

test('Double Bottom: fewer than 16 candles never fires (not enough history for swing structure)', () => {
  const candles = [
    candle(100, 101, 99, 100),
    candle(99, 100, 97, 98),
    candle(98, 99, 90, 91),
    candle(91, 96, 90.5, 95),
    candle(95, 99, 94, 98),
    candle(98, 101, 97, 100),
    candle(100, 103, 99, 102),
    candle(101, 102, 96, 97),
    candle(97, 98, 93, 94),
    candle(94, 95, 90.1, 91),
    candle(91, 95, 90.5, 94),
    candle(94, 99, 93, 98),
    candle(98, 106, 97, 105),
  ];
  assert.equal(candles.length < 16, true);
  const detected = detectCandlePattern(candles);
  assert.notEqual(detected?.pattern, 'DOUBLE_BOTTOM');
});

test('Double Bottom: flat/unremarkable candles never produce a false swing match', () => {
  const candles = boring(20);
  const detected = detectCandlePattern(candles);
  assert.equal(detected, null);
});

// ── isPatternReversalAgainstSide (thesis-break wiring, added 2026-08-18) ────

function patternSignal(pattern: CandlePatternName, updatedAt: number): CandlePatternSignal {
  return { pattern, signal: 'YES', strength: 0.7, reason: 'test', updatedAt };
}

test('isPatternReversalAgainstSide: null/undefined pattern never fires', () => {
  assert.equal(isPatternReversalAgainstSide(null, 'no', 1000), false);
  assert.equal(isPatternReversalAgainstSide(undefined, 'yes', 1000), false);
});

test('isPatternReversalAgainstSide: a pattern already visible at/before entry does not fire', () => {
  const pattern = patternSignal('BULLISH_ENGULFING', 1000);
  assert.equal(isPatternReversalAgainstSide(pattern, 'no', 1000), false); // updatedAt === openedAt
  assert.equal(isPatternReversalAgainstSide(pattern, 'no', 1500), false); // updatedAt < openedAt
});

test('isPatternReversalAgainstSide: a genuine new bottom-reversal pattern breaks a "no" thesis', () => {
  for (const pattern of BOTTOM_REVERSAL_PATTERNS) {
    assert.equal(isPatternReversalAgainstSide(patternSignal(pattern, 2000), 'no', 1000), true, pattern);
  }
});

test('isPatternReversalAgainstSide: a bottom-reversal pattern does not break a "yes" thesis (it agrees with it)', () => {
  for (const pattern of BOTTOM_REVERSAL_PATTERNS) {
    assert.equal(isPatternReversalAgainstSide(patternSignal(pattern, 2000), 'yes', 1000), false, pattern);
  }
});

test('isPatternReversalAgainstSide: a genuine new top-reversal pattern breaks a "yes" thesis', () => {
  for (const pattern of TOP_REVERSAL_PATTERNS) {
    assert.equal(isPatternReversalAgainstSide(patternSignal(pattern, 2000), 'yes', 1000), true, pattern);
  }
});

test('isPatternReversalAgainstSide: weaker/continuation patterns (not in either curated set) never fire', () => {
  for (const pattern of ['TWEEZER_BOTTOM', 'THREE_WHITE_SOLDIERS', 'BULLISH_MARUBOZU'] as CandlePatternName[]) {
    assert.equal(isPatternReversalAgainstSide(patternSignal(pattern, 2000), 'no', 1000), false, pattern);
  }
});
