import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  recordBounceTick,
  getBounceInfo,
  getBounceConfidenceBonus,
  resetBounceLevelsForTest,
  getBounceLevelBandCount,
} from './bounce-level-tracker.js';

const T0 = 1_700_000_000_000; // arbitrary fixed unix-ms anchor

function feed(prices: number[], startTs = T0, stepMs = 1_000): number {
  let ts = startTs;
  for (const p of prices) { recordBounceTick(p, ts); ts += stepMs; }
  return ts;
}

test('bounce-level-tracker: no evidence returns undefined, no bonus', () => {
  resetBounceLevelsForTest();
  assert.equal(getBounceInfo(63750, T0), undefined);
  assert.equal(getBounceConfidenceBonus(63750, T0, 'yes'), 0);
});

test('bounce-level-tracker: a single reversal at a level is not enough evidence (MIN_EVIDENCE=2)', () => {
  resetBounceLevelsForTest();
  // Down leg to 63700, then up past threshold — records ONE 'up' bounce at 63700's band.
  const end = feed([63750, 63740, 63720, 63700, 63705, 63715, 63725]);
  assert.equal(getBounceInfo(63700, end), undefined, 'one bounce alone should not count as trusted evidence');
});

test('bounce-level-tracker: two same-direction bounces at the same band are trusted and produce a boost for an aligned YES trade', () => {
  resetBounceLevelsForTest();
  let ts = T0;
  // First support bounce near $63,700: fall then rally past threshold.
  ts = feed([63750, 63730, 63710, 63700, 63710, 63720, 63735], ts);
  // Rally away, then fall back to ~$63,700 again and bounce a second time.
  ts = feed([63760, 63775, 63790, 63775, 63760, 63740, 63715, 63700, 63715, 63730, 63745], ts);

  const info = getBounceInfo(63700, ts);
  assert.ok(info, 'expected a trusted bounce record at the $63,700 band');
  assert.equal(info!.dominant, 'up');
  assert.ok(info!.bouncedUpCount >= 2);

  const bonusAligned = getBounceConfidenceBonus(63700, ts, 'yes');
  assert.ok(bonusAligned > 0, 'a YES (bullish) reversal call at a support level should get a positive bonus');

  const bonusOpposed = getBounceConfidenceBonus(63700, ts, 'no');
  assert.equal(bonusOpposed, 0, 'a NO (bearish) call against a support level gets no penalty and no bonus');
});

test('bounce-level-tracker: bonus is capped at MAX_BONUS regardless of evidence volume', () => {
  resetBounceLevelsForTest();
  let ts = T0;
  // Repeat the same support bounce many times to blow past the cap.
  for (let i = 0; i < 10; i++) {
    ts = feed([63760, 63745, 63730, 63715, 63700, 63715, 63730, 63745], ts);
  }
  const bonus = getBounceConfidenceBonus(63700, ts, 'yes');
  assert.ok(bonus <= 8, `bonus should never exceed the documented cap, got ${bonus}`);
});

test('bounce-level-tracker: evidence older than the lookback window no longer counts', () => {
  resetBounceLevelsForTest();
  const t1 = feed([63750, 63730, 63710, 63700, 63715, 63730, 63745], T0);
  const t2 = feed([63760, 63775, 63790, 63775, 63760, 63740, 63715, 63700, 63715, 63730, 63745], t1);

  const farFuture = t2 + 22 * 24 * 3600 * 1000; // 22 days later — past the 21-day lookback
  assert.equal(getBounceInfo(63700, farFuture), undefined, 'stale bounce history should stop counting as evidence');
});

test('bounce-level-tracker: a tiny sub-threshold wiggle never registers as a leg reversal', () => {
  resetBounceLevelsForTest();
  const before = getBounceLevelBandCount();
  feed([63750, 63752, 63748, 63751, 63749, 63753, 63747]); // all within the $15 zigzag threshold
  assert.equal(getBounceLevelBandCount(), before, 'noise below the zigzag threshold should not create bounce records');
});
