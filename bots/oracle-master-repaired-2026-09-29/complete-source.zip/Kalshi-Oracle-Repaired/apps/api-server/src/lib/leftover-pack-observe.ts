/**
 * Leftover specialist-pack skip/place observation. Paper KXBTC15M never runs it.
 * Does not size, ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
export const LEFTOVER_PACK_OBSERVE_LOADED = true as const;

export const LEFTOVER_PACK_OBSERVE_HOST_GUARD =
  "leftoverPackObserveRun(this.config";

export const FROZEN_PACK_OBSERVE_MARKERS = [
  "specialistPacksMode === 'enforce'",
  "[pack-shadow]",
  "[pack-enforce]",
  "evaluateSpecialistPackShadow({",
] as const;

export function leftoverPackObserveMayRun(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  if (cfg.paperMode === true || cfg.frozenCcMode === true) return false;
  return true;
}

export function leftoverPackObserveHostDenied(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverPackObserveMayRun(cfg) === false;
}

export function leftoverPackObserveRun<T>(
  cfg: { paperMode?: boolean; frozenCcMode?: boolean },
  run: () => T,
  empty: T,
): T {
  if (!leftoverPackObserveMayRun(cfg)) return empty;
  return run();
}
