/**
 * Confirmed live exit execution against an ExitJournalState.
 * Paper/frozen never invoke (leftoverLiveOrderMayRun deny).
 * Does not ENABLE or cut floors.
 */
import type { ExitJournalState } from "./exit-journal.js";

export type ExitSubmitResult =
  | { kind: "blocked" }
  | { kind: "rejected" }
  | { kind: "unknown" }
  | { kind: "accepted"; orderId: string };

export type ExitReadResult = {
  filled: number;
  avgPriceCents: number | null;
};

export type ExecuteConfirmedExitResult =
  | { kind: "closed"; state: ExitJournalState }
  | { kind: "partial" | "unknown" | "blocked"; state: ExitJournalState & { pending?: boolean; soldContracts: number } };

export function carriedExitEconomics(
  state: ExitJournalState,
  feeFn: (avgPriceCents: number, contracts: number) => number,
): { remainingContracts: number; pnlCents: number; feeCents: number } {
  void feeFn;
  const remaining = Math.max(0, state.originalContracts - state.soldContracts);
  const proceeds = state.proceedsCents;
  const cost = state.entryPriceCents * state.soldContracts;
  return {
    remainingContracts: remaining,
    pnlCents: proceeds - cost - (state.exitFeeCents ?? 0),
    feeCents: state.exitFeeCents ?? 0,
  };
}

export async function executeConfirmedExit(
  journal: ExitJournalState,
  _attempts: number,
  hooks: {
    save: (state: ExitJournalState) => Promise<void>;
    newIntentId: () => string;
    submit: (contracts: number, attempt: number) => Promise<ExitSubmitResult>;
    read: (orderId: string, expectedContracts: number) => Promise<ExitReadResult>;
    cancel: (orderId: string) => Promise<void>;
  },
): Promise<ExecuteConfirmedExitResult> {
  const remaining = Math.max(0, journal.originalContracts - journal.soldContracts);
  if (remaining <= 0) {
    return { kind: "closed", state: journal };
  }
  const submitted = await hooks.submit(remaining, 1);
  if (submitted.kind !== "accepted") {
    return {
      kind: submitted.kind === "blocked" ? "blocked" : "unknown",
      state: { ...journal, pending: true, soldContracts: journal.soldContracts },
    };
  }
  const fill = await hooks.read(submitted.orderId, remaining);
  const sold = Math.max(0, Math.min(remaining, fill.filled));
  const avg = fill.avgPriceCents ?? journal.entryPriceCents;
  const next: ExitJournalState = {
    ...journal,
    soldContracts: journal.soldContracts + sold,
    proceedsCents: journal.proceedsCents + avg * sold,
    completedOrderIds: [...journal.completedOrderIds, submitted.orderId],
  };
  await hooks.save(next);
  if (next.soldContracts >= next.originalContracts) {
    return { kind: "closed", state: next };
  }
  return { kind: "partial", state: { ...next, pending: true, soldContracts: next.soldContracts } };
}
