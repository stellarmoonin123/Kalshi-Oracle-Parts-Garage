/**
 * automode-v2.test.ts
 *
 * GO — STEP 5 autoMode v2 PHASE A (SUGGEST ONLY), 2026-08-22.
 * Pure-function coverage for computeAutoModeV2Suggestion(): tighten-biased
 * bands, per-condition deltas, and clamp behavior. This module never reads
 * config/DB/live state and never logs — the call site in trading-bot.ts
 * owns rate-limiting and logging, covered separately in
 * trading-bot.automode-v2-suggest-only.test.ts.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { computeAutoModeV2Suggestion } from "./automode-v2.js";

test("normal conditions (NORMAL volume, range regime, no pack) proposes the baseline with no adjustment", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 55, regime: "range", vBucket: "NORMAL", packId: null,
  });
  assert.equal(s.proposedMinConf, 55);
  assert.equal(s.proposedSizeMult, 1.0);
  assert.match(s.reason, /no adjustment/);
});

test("DEAD volume proposes +8 confidence (clamped) and 0.7x size", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 55, regime: "range", vBucket: "DEAD", packId: null,
  });
  assert.equal(s.proposedMinConf, 63); // 55 + 8
  assert.equal(s.proposedSizeMult, 0.7);
});

test("LOW volume proposes +5 confidence and 0.8x size", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 55, regime: "range", vBucket: "LOW", packId: null,
  });
  assert.equal(s.proposedMinConf, 60); // 55 + 5
  assert.equal(s.proposedSizeMult, 0.8);
});

test("unclear regime adds +3 confidence on top of NORMAL volume's 0", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 55, regime: "unclear", vBucket: "NORMAL", packId: null,
  });
  assert.equal(s.proposedMinConf, 58);
});

test("squeeze regime adds +2 confidence", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 55, regime: "squeeze", vBucket: "NORMAL", packId: null,
  });
  assert.equal(s.proposedMinConf, 57);
});

test("TRANSITION pack adds +2 confidence independent of regime/volume deltas", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 55, regime: "unclear", vBucket: "NORMAL", packId: "TRANSITION",
  });
  // unclear (+3) + TRANSITION pack (+2) = +5
  assert.equal(s.proposedMinConf, 60);
});

test("stacked worst-case deltas clamp at MAX_DELTA=8, never exceeding baseline+8", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 55, regime: "unclear", vBucket: "DEAD", packId: "TRANSITION",
  });
  // 8 (DEAD) + 3 (unclear) + 2 (TRANSITION) = 13, clamped to 8
  assert.equal(s.proposedMinConf, 63); // 55 + 8, not 55 + 13
});

test("proposedMinConf never exceeds the hard ceiling of 68 even with a high baseline", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 65, regime: "unclear", vBucket: "DEAD", packId: "TRANSITION",
  });
  assert.equal(s.proposedMinConf, 68); // would be 65+8=73, clamped to ceiling 68
});

test("proposedMinConf never drops below the hard floor of 52 even with a low baseline", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 40, regime: "range", vBucket: "NORMAL", packId: null,
  });
  assert.equal(s.proposedMinConf, 52); // baseline+0=40, floored to 52
});

test("proposedMinConf is never below baseline in Phase A (tighten-biased only, never loosens)", () => {
  const s = computeAutoModeV2Suggestion({
    baselineMinConfidence: 55, regime: "range", vBucket: "NORMAL", packId: null,
  });
  assert.ok(s.proposedMinConf >= 55);
});

test("proposedSizeMult is always within [0.7, 1.0]", () => {
  const cases: Array<Parameters<typeof computeAutoModeV2Suggestion>[0]> = [
    { baselineMinConfidence: 55, regime: "range", vBucket: "NORMAL", packId: null },
    { baselineMinConfidence: 55, regime: "range", vBucket: "DEAD", packId: null },
    { baselineMinConfidence: 55, regime: "range", vBucket: "LOW", packId: null },
    { baselineMinConfidence: 55, regime: "unclear", vBucket: "HIGH", packId: "TRANSITION" },
  ];
  for (const c of cases) {
    const s = computeAutoModeV2Suggestion(c);
    assert.ok(s.proposedSizeMult >= 0.7 && s.proposedSizeMult <= 1.0,
      `sizeMult ${s.proposedSizeMult} out of band for ${JSON.stringify(c)}`);
  }
});
