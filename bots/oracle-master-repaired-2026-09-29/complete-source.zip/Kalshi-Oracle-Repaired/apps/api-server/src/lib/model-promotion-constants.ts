/**
 * model-promotion-constants.ts — GO: INSTITUTIONAL PROMOTION + ADMISSION
 * SURVIVAL ANALYSIS, Part I, 2026-08-25.
 *
 * Single source of truth for every fixed threshold the auto-canary gate
 * vector (G1-G9, see model-promotion.ts) and the canary envelope check
 * against. These numbers gate a live-risk transition (shadow -> canary
 * sizes real fee-net trades at CANARY_SIZE_MULT), so changing any of them
 * is exactly as risk-relevant as an EV floor or PATH_GATE change and must
 * get the same scrutiny — even though today's live data volume keeps the
 * gate unreachable (nResolved is two orders of magnitude below N_MIN_RESOLVED).
 *
 * Pre-registered estimand (must not change without a new registration):
 *   delta = mean_per_period( fee_net(shadow) - fee_net(LEAN replay) ),
 *   evaluated only over periods where at least one side has a resolved
 *   outcome (see market-learning-v4.ts evaluateWalkForwardV4()).
 *
 * This file must never be imported by anything that mutates live BotConfig,
 * live entry/exit gates, packs, quarantine, or minConfidence — it feeds the
 * promotion gate evaluator only.
 */

/** G2 — minimum resolved shadow decisions before a verdict is even attempted. Matches market-learning-v4.ts's own MIN_RESOLVED_FOR_VERDICT so the two never silently diverge. */
export const N_MIN_RESOLVED = 150;

/** G3 — the block-bootstrap 90% CI lower bound on delta fee-net must clear this (cents/period). 0 means "we're not confident the shadow model beats LEAN even a little" is disqualifying. */
export const CI_LOW_DELTA_MIN = 0;

/** G4 — LEAN replay must have successfully reconstructed a comparable trade for at least this share of our resolved periods, or the comparison itself is on too thin a base to trust. */
export const LEAN_COVERAGE_MIN = 0.80;

/** G5 — shadow must not be trading dramatically more (or, trivially, appear to badly under-trade) than LEAN over the same periods. Ratio, not a raw count, so it scales with data volume. */
export const TRADE_COUNT_RATIO_MAX = 1.50;

/** G6 — shadow's max drawdown over the comparison window must not exceed LEAN's by more than this ratio — guards against a model that "wins on average" via a fatter tail. */
export const MAXDD_RATIO_MAX = 1.25;

/**
 * G7 — how old the walk-forward snapshot backing a transition decision may
 * be before it's treated as stale and the gate fails closed. Chosen as 2x
 * market-learning-v2's bucket-model refresh cadence (5 min) plus headroom
 * for a slow DB roundtrip: generous enough to never false-positive on
 * ordinary jitter between the promotion evaluator's own tick and the last
 * model refresh, tight enough to catch a genuinely stuck refresh loop
 * before it drives a transition off dead data.
 */
export const SNAPSHOT_STALENESS_MS = 10 * 60_000;

/**
 * Canary envelope for the v4.1 promotion protocol. Deliberately equal to
 * market-learning-v2.ts's own CANARY_ENVELOPE (sizeMult 0.25,
 * maxCanaryTradesPerDay 5, maxCanaryDailyLossPctEquity 2) rather than a new,
 * independently-chosen set of numbers: v2's canary is a live, already-
 * reviewed policy, and running two different "canary" risk envelopes for
 * whichever model happens to hold the mode at the time would be a real
 * hazard, not just an inconsistency. This file re-declares the values (does
 * not import v2's, to keep this doc/protocol module import-independent of
 * v2's file) — a parity test asserts they cannot silently drift apart.
 */
export const CANARY_SIZE_MULT = 0.25;
export const CANARY_MAX_TRADES_DAY = 5;
export const CANARY_MAX_LOSS_PCT = 2;

/**
 * Only the primary (non-ablation) v4.1 model is promotion-eligible. Ablation
 * variants (market-learning-v4.ts ABLATION_FEATURES) exist for feature-
 * importance research only and must never independently trigger a
 * transition — this is the multiple-testing guard for "don't let a
 * side-experiment back into the pipeline through the promotion door."
 */
export const PROMOTION_ELIGIBLE_MODEL_VERSION = "logistic-v4.1";

/** How often the dormant gate evaluator runs and writes one audit-ledger row (transition or not). */
export const EVALUATOR_INTERVAL_MS = 15 * 60_000;
