/**
 * trade-narrative.ts — human-readable trade context (logging/display only).
 *
 * Builds plain-English entry/exit reasons from data already computed
 * elsewhere in the bot, plus a one-off AI "what went right/wrong" note
 * generated once per settled trade. None of this feeds gating, EV, sizing,
 * or quarantine logic — it exists purely to make the trade log readable.
 */

import { getAllStrategyMeta } from "./strategy-library.js";
import { aiComplete } from "./ai-client.js";

// ── Entry reason ─────────────────────────────────────────────────────────────

export function buildEntryReason(opts: {
  strategyId: string | null | undefined;
  signal: "LONG" | "SHORT";
  confidence: number;
  entryPriceCents: number;
  winRate: number;              // strategyWinRate (0–1) used for sizing/EV at entry
  regime?: string | null;
  velocityDolPerMin?: number;
  // Master bot upgrade step 3: HUNT (active US/London hours) vs HARVEST
  // (Asia/Sunday/dead hours) session mode in effect at entry — logging only.
  sessionMode?: "HUNT" | "HARVEST";
  /** Fee/slippage-aware stop/target snapshot selected at final admission. */
  exitPlan?: {
    stopLossCents: number;
    targetProfitCents: number;
    rewardRiskRatio: number;
  } | null;
}): string {
  const meta = getAllStrategyMeta().find(s => s.id === opts.strategyId);
  const stratLabel = meta?.name ?? opts.strategyId ?? "an unnamed strategy";
  const dir = opts.signal === "LONG" ? "an upward" : "a downward";
  const regimeTxt = opts.regime ? ` while the market read as ${opts.regime.replace(/_/g, " ")}` : "";
  const velTxt = opts.velocityDolPerMin != null && Math.abs(opts.velocityDolPerMin) >= 1
    ? `, velocity ${opts.velocityDolPerMin >= 0 ? "+" : ""}${opts.velocityDolPerMin.toFixed(0)}$/min`
    : "";
  const sessionTxt = opts.sessionMode ? ` [session=${opts.sessionMode}]` : "";
  const exitPlanTxt = opts.exitPlan
    ? ` Stop −${opts.exitPlan.stopLossCents.toFixed(1)}¢ / target +${opts.exitPlan.targetProfitCents.toFixed(1)}¢ ` +
      `(net R/R ${opts.exitPlan.rewardRiskRatio.toFixed(2)}x).`
    : "";
  const wr = Math.round(opts.winRate * 100);
  return (
    `${stratLabel} flagged ${dir} move at ${opts.confidence}% confidence${regimeTxt}${velTxt}. ` +
    `Signal at ${opts.entryPriceCents}¢ with an estimated ${wr}% win rate.${exitPlanTxt}${sessionTxt}`
  );
}

// ── Exit / cancel reason ─────────────────────────────────────────────────────

const EXIT_REASON_TEMPLATES: Record<string, (o: ExitCtx) => string> = {
  SETTLEMENT: (o) => `Held to settlement — the contract resolved ${o.outcome === "win" ? "in our favor" : "against us"}.`,
  SETTLED_KALSHI: (o) => `Held to settlement — Kalshi's settlement API confirmed the contract resolved ${o.outcome === "win" ? "in our favor" : "against us"}.`,
  SETTLEMENT_UNRESOLVED: () => `Kalshi's settlement API was unavailable/had no match for this contract past the retry timeout — no win/loss was recorded (outcome left unresolved rather than guessed from a stale price).`,
  SOFT_STOP_PCT: () => `Soft stop triggered — price moved against the position past the configured stop threshold.`,
  HARD_STOP_PCT: () => `Hard stop triggered — price moved sharply against the position.`,
  HARD_STOP: () => `Hard stop triggered on a fast adverse move.`,
  HARD_STOP_EXIT: () => `Hard stop triggered — enforced unconditionally, even under hold-to-settlement or an active settlement hold.`,
  THESIS_BREAK_EXIT: () => `Thesis break confirmed with sustained evidence against the position (velocity, floor/strike cross, or basis projection) — exited immediately rather than risk riding it to a full loss.`,
  LAG_FLIP_EXIT: () => `Exchange-led price projection flipped against the position and stayed there — exited on confirmed lag disagreement rather than wait for the market price to catch up.`,
  TRAILING_STOP: (o) => `Trailing stop locked in gains after price pulled back from its peak${o.maxGainCents ? ` (peak was +${o.maxGainCents}¢/contract)` : ""}.`,
  PROFIT_TAKE: () => `Profit target reached — closed early to lock in gains.`,
  THESIS_BREAK: () => `The original trade thesis broke down (signal reversed) — exited early.`,
  HOLD_HARD_FLOOR: () => `Hold-to-settlement hard floor — the market price sat deep out-of-the-money for a sustained stretch with no strike-break confirmation, so the position was closed to salvage remaining value rather than ride to a total loss.`,
  ARIA_GATED_EXIT: () => `ARIA flagged sustained danger conditions on the open position — closed early on the agent's authority.`,
  FAST_REVERSAL: () => `Price reversed sharply right after entry — exited to limit damage.`,
  MTF_REVERSAL: () => `Multi-timeframe bias flipped against the position — exited early.`,
  TIME_STOP: () => `Time stop — the position wasn't developing as expected as expiry approached.`,
  TIME_STOP_SMALL_ACCT: () => `Time stop (small-account rule) — closed early to protect limited capital.`,
  TIME_STOP_WEAK: () => `Time stop — weak follow-through prompted an early close.`,
  BREAKEVEN_GUARD: () => `Breakeven guard — closed near cost basis to avoid giving back gains.`,
  TIME_DECAY: () => `Time-decay exit — held value was eroding as expiry approached.`,
  LATE_LOCK: () => `Late-window lock — closed in the final stretch to secure the position.`,
  BAD_FILL_PRICE: () => `Fill landed far outside the expected range — exited immediately to avoid an unintended position.`,
  HIGH_ODDS_EXIT: () => `Closed early because the position's odds became overwhelmingly favorable.`,
  UNFILLED_TIMEOUT: () => `Order never filled within the timeout window — cancelled with no position opened (missed).`,
  EXTERNAL_CLOSE: () => `Closed manually outside the bot (e.g. in the Kalshi app) — the bot detected the change and reconciled its records.`,
  EXTERNAL_CLOSE_UNRESOLVED: () => `Closed manually outside the bot, but no matching closing fill or balance snapshot was found to price the exit — marked unresolved.`,
  EXTERNAL_CLOSE_BALANCE_INFERRED: (o) => `Closed manually outside the bot — no matching closing fill was found, so the ${o.outcome === "win" ? "gain" : "loss"} was inferred from the account balance before and after the close.`,
};

interface ExitCtx {
  outcome?: "win" | "loss";
  maxGainCents?: number;
}

export function buildExitReasonText(reasonCode: string, ctx: ExitCtx): string {
  const fn = EXIT_REASON_TEMPLATES[reasonCode];
  return fn ? fn(ctx) : reasonCode;
}

// ── AI postmortem (fired once, after a trade settles) ───────────────────────

export interface PostmortemContext {
  strategyId: string | null;
  signal: string;
  side: string;
  ticker: string;
  entryPriceCents: number;
  confidence: number | null;
  regime: string | null;
  outcome: "win" | "loss";
  pnlCents: number;
  contracts: number;
  exitReasonCode: string;
  timeInTradeSecs: number | null;
  winRateEstimate: number | null;
  /** Task #351: MTF/ARIA tune as it actually stood at entry — the postmortem
   *  is written well after the trade closes, when the live MTF/ARIA feeds
   *  have already moved on, so this must come from the immutable snapshot
   *  captured on OpenTrade at order time, not a fresh read at settlement. */
  mtfScoreAtEntry?: number | null;
  mtfBiasAtEntry?: string | null;
  ariaSignalAtEntry?: string | null;
  ariaConfAdjAtEntry?: number | null;
}

/**
 * Generates a short trade-review report for what went right/wrong on this
 * trade. Never throws — returns null only after a retry also fails, so it
 * can never block or delay settlement bookkeeping. Callers must invoke this
 * fire-and-forget.
 *
 * This report is what ARIA (expert-agent.ts) later reads back — via
 * getRecentPostmortems() — to extract lessons it persists and re-applies to
 * live entries, so a transient AI hiccup here silently means one fewer
 * trade the bot can learn from. One retry on failure closes most of that gap
 * without adding real latency risk (settlement bookkeeping already doesn't
 * wait on this call either way).
 */
export async function generateTradePostmortem(ctx: PostmortemContext): Promise<string | null> {
  const meta = getAllStrategyMeta().find(s => s.id === ctx.strategyId);
  const prompt = `Trade log entry:
- Strategy: ${meta?.name ?? ctx.strategyId ?? "unknown"}${meta?.description ? ` — ${meta.description}` : ""}
- Direction: ${ctx.signal} (${ctx.side.toUpperCase()}) on ${ctx.ticker}
- Entry: ${ctx.entryPriceCents}¢ at ${ctx.confidence ?? "unknown"}% confidence, regime: ${ctx.regime ?? "unknown"}
- MTF/ARIA tune at entry: MTF ${ctx.mtfBiasAtEntry ?? "unknown"} (score ${ctx.mtfScoreAtEntry ?? "unknown"}), ARIA ${ctx.ariaSignalAtEntry ?? "unknown"}${ctx.ariaConfAdjAtEntry != null ? ` (${ctx.ariaConfAdjAtEntry >= 0 ? "+" : ""}${ctx.ariaConfAdjAtEntry} conf adj)` : ""}
- Bot's own win-rate estimate at entry: ${ctx.winRateEstimate != null ? Math.round(ctx.winRateEstimate * 100) + "%" : "unknown"}
- Exit reason code: ${ctx.exitReasonCode}
- Time in trade: ${ctx.timeInTradeSecs != null ? `${ctx.timeInTradeSecs}s` : "unknown"}
- Outcome: ${ctx.outcome.toUpperCase()}, P&L ${ctx.pnlCents >= 0 ? "+" : ""}$${(ctx.pnlCents / 100).toFixed(2)} on ${ctx.contracts} contract(s)

Write a short trade-review report (3-5 sentences, plain prose, no headers/markdown/bullets) covering:
1. What happened in this trade, concretely, using the numbers above.
2. Why it likely won or lost — tie it to the strategy, confidence, regime, or exit reason given.
3. One specific, actionable takeaway for next time (not generic advice — reference this trade's actual setup).
Be direct and concrete. Don't just restate the P&L.`;

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const text = await aiComplete(
        "You are a terse but substantive trading-journal assistant. Reply with plain prose only — no preamble, no markdown, no quotes, no headers.",
        prompt,
        { maxTokens: 260, timeoutMs: 15_000 },
      );
      const trimmed = text?.trim();
      if (trimmed) return trimmed.slice(0, 1200);
    } catch {
      // fall through to retry / final null
    }
  }
  return null;
}
