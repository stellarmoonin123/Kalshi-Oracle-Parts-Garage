import { frozenSixGateIsOnlyEvaluatePath } from "./frozen-six-gate-evaluate.js";
/**
 * Leftover 15m evaluate funnel (packs, HARVEST, SETTLEMENT_PREDICTION,
 * paper-desk winner, W2-as-law, ARIA composer). Not frozen six-gate law.
 *
 * Host evaluateEntry must not contain this body. Paper/frozen never invoke
 * leftover15mEvaluateFunnel (leftover15mEvaluateRun deny).
 * Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
import {
  VOLUME_HIGH_RATIO, VOLUME_LOW_RATIO, ADD_POSITION_MIN_PROFIT_CENTS,
  ACCEL_CONF_BONUS, ACCEL_CONF_PENALTY,
  STREAK_FADE_THRESH, STREAK_CONF_PENALTY, STREAK_CONF_BONUS, ALTERNATING_FADE_BONUS,
  REGIME_TREND_CONF_BONUS, REGIME_UNCLEAR_CONF_PENALTY,
  KALSHI_TAKER_FEE,
  KALSHI_API_DOMAIN,
  KALSHI_PATH_PORTFOLIO_BALANCE, KALSHI_PATH_PORTFOLIO_POSITIONS, KALSHI_PATH_PORTFOLIO_FILLS,
  KALSHI_PATH_PORTFOLIO_ORDERS, kalshiEventsOrderPath, kalshiOrderStatusPath, kalshiSettlementsPath,
  getEntryPriceBand, getUniversalPriceBandTier, PRICE_BAND_HALF_MAX_CENTS,
  RICH_ASK_EXTRA_EV_MARGIN_CENTS,
  HARVEST_ALLOWED_FAMILIES, HARVEST_SIZE_MULT, HARVEST_ASK_MAX_CENTS,
  PRICE_BAND_LATE_EXCEPTION_STRATEGIES, PRICE_BAND_EXTREME_DISPLACEMENT_PCT, PRICE_BAND_LATE_MAX_MINS_LEFT,
  PRICE_BAND_STANDARD_MAX_CENTS, computeStackTier, STACK_PRESS_COOLDOWN_MS, type SizeTier,
  SETTLEMENT_UNRESOLVED_TIMEOUT_MS, KALSHI_EXPECTED_SLIPPAGE_CENTS, expectedSlippageCents,
  observedSlippageFloorCents,
  ASIAN_HOURS_SIZE_MULT, applyTimeOfDaySizeMultiplier, capContractsToLiquidityLimit, getTimeOfDayRegime, type TimeOfDayRegime,
  MAX_DEPTH_FRACTION,
} from "./constants.js";
import { ariaMayGovernOrders, settlementModelMayVetoEntry } from "./fill-authority.js";
import { FROZEN_CC_STRATEGY_ID } from "./frozen-cc.js";
import { kalshiWS, restQuoteBlocksFill } from "./kalshi-ws.js";
import { mtfAnalyzer, getMtfOhlcBars } from "./mtf-analyzer.js";
import {
  applyHtfStructureToSide,
  computeLiveHtfStructure,
  velocitySideFromDollarsPerMin,
  type HtfStructureSnapshot,
} from "./mtf-structure.js";
import { collectAdviceShadow, formatAdviceDeskLine, type AdviceShadowLabel } from "./advice-shadow.js";
import { ticketDeltasFromHistory } from "./intra-scalp-replay.js";
import {
  evaluateAllStrategies,
  FILL_PATH_PLACE_FALSE_STRATEGY_IDS,
  placeableWithoutHaWhenMoneyMakerFires,
  classifyRegimeFromBuffer,
  getAllStrategyMeta,
  computePsychLevel,
  isStrategyAllowedForDuration,
  drainOtmConfluenceSkipEvents,
  getStrategyFamily,
  type OtmConfluenceSkipEvent,
  type StrategyResult as LibStrategyResult,
  type StrategyObservation,
} from "./strategy-library.js";
import { binaryCallPrice } from "./backtest-engine.js";
import { getBotFillLearningWeights, pathPWinFromCurveOrLearner, getLearnerPathWinRateSample } from "./strategy-learner.js";
import { isDecisionSafe, recordSuccess, recordFailure } from "./decision-safety.js";
import { getDbDisabledStrategies, getStrategyMultipliersSync, getLiveTradeStatsSync, computePSizeForKelly, computeSizeUncertaintyMult, onTradeSettled as onTradeSettledForPerformance, ensureFillOriginColumn } from "./strategy-performance.js";
import { adaptiveTuningLog } from "./adaptive-tuning-log.js";
import {
  DEFAULT_AUTO_POLICY_PARAMS, applyAutoPolicyOverlay, derivePolicy, judgeFill, normalizeBounds, normalizeMode,
  policySizeMult, stateIdFor, summarizeShadow,
  type AutoPolicy, type AutoPolicyMode, type PolicyVerdict,
} from "./auto-policy.js";
import { getPatternBoost, fingerprintObs } from "./pattern-learner.js";
import {
  computeMarketIntelligenceObs, computeMIAdjustment,
  getCurrentSessionMode, type SessionMode,
  type MarketIntelligenceData,
} from "./market-intelligence.js";
import {
  canReusePreTradeAdmissionForRequote,
  getPreTradeEntryPath,
  runPreTradeSim,
} from "./pre-trade-sim.js";
import { basisTracker, projectSettlementPrice } from "./basis-tracker.js";
import { shouldSkipConfidenceFloor, resolveMoneyMakerConfFloorSideAgree, ticketEVCentsFromP } from "./confidence-floor.js";
import {
  notePaperBarEvaluate,
  notePaperBarExit,
  notePaperBarFill,
  flushPaperBar,
  flushPaperBarsExcept,
} from "./paper-bar-tape.js";
import {
  findMoneyCandSelectMiss,
  reinjectMoneyCandSelectMiss,
  meterLagSideForW2,
} from "./select-miss-recover.js";
import {
  PATH_RIDE_EXIT_BOOK,
  distanceIsFat,
  haFromRaw,
  isPathRideKellyBook,
  isPathRideFlickerBook,
  isPathRideOpenTrade,
  isPathRideStrategyId,
  PATH_RIDE_RUIN_CENTS,
  holdHardFloorMaySell,
  isStrikePin,
  isGammaGetout,
  last1mRangeDollars,
  pathRidePlus50TargetCents,
  pathRideTwoXTargetCents,
  remainingVolDollars,
  tagPathRideFill,
} from "./path-ride.js";
import { decideSettlementSideLogged, paperMoneyMakerLagMinAbsDollars, paperMoneyMakerHarvestExempt, paperMoneyMakerIgnoresSettlementSideSkip, /* F4_REMAKE_UNSTARVE */ paperPathRidePreservesThroughSettlementSkip, isPathRideKellyStrategyId, isMoneyMakerStrategyId, isRemakeSettlementSideSkip, isOriginalSettlementSideLock, moneyMakerIgnoresOverpayGate, leftoverYesAskIsPoison, leftoverRegimeBlockPlacesMoneyMaker, filterPoolToMtfAlignedCheap, isMtfAlignedCheapTake, mtfAlignedCheapWantSignal } from "./settlement-side.js";
import {
  buildMoneyGateCard,
  sessionClockLabel,
  type MoneyGateCard,
  evaluatePathDecision,
  getPathConfig,
  computeTradeEV,
  moneyMakerIgnoresPathGateSkip,
  evaluateEntryEVGate,
} from "./organs/path-gate.js";
import {
  alignedTakeGate,
  overlayAlignedTake,
  formatConstructedNoLog,
  direction_w2,
  overlayDirectionW2,
  formatDirectionW2Log,
  shouldEmitDirectionW2Log,
  createDirectionW2LogThrottleState,
} from "./organs/side-lock.js";
import {
  inStillMidCoinFlip,
  STILL_MID_UNCLEAR_SKIP,
} from "./aligned-take-gate.js";
import {
  PAPER_SCALP_STRATEGY_ID,
  PAPER_SCALP_FEE_NET_BEATS_SKIP,
  applyPaperScalpAfterSettlement,
  decidePaperScalp,
  obsToTickQuote,
  type TickQuote as PaperScalpTickQuote,
} from "./paper-scalp.js";
import {
  HARD_RISK_LIMITS,
  EV_FLOOR,
  applyHardRiskLimits,
  canScaleIntoPosition,
  computeContracts as computeKellyContracts,
  kellyPayoutRatio,
  computeKellyEdge,
} from "./organs/size.js";
import {
  OTM_EV_FLOOR,
  MIN_EDGE_OVER_MARKET,
  scoreStrategyEV,
  estimateTradeEV,
  pWinFromCurve,
  DAILY_HALT_FLOOR_CENTS,
} from "./admission.js";
import { predictionLearner } from "./prediction-learner.js";
import {
  classifyDetailedCondition,
  getConditionOverrides,
  CONDITION_META,
  type DetailedCondition,
  type AdaptiveConditionResult,
} from "./condition-adapter.js";
import type { PreTradeVerdict } from "./pre-trade-sim.js";
import type { ChannelInfo, StrategyId } from "./strategy-library.js";
import {
  updateRegime, getRegime, getGrokRegimeFromDetailed, getRegimeDebug, getRegimeHeldBy,
  type GrokRegime, type RegimeId,
} from "./regime-engine.js";
import {
  evaluateSpecialistPackShadow, type ShadowPackEvaluation, type SpecialistPacksMode,
  getPack, computeWouldEligible, type SpecialistPack, type PackId,
  filterPoolByPack, computePackConfFloor, computePackCombinedMult,
  computeConsensusDisabledIds,
} from "./specialist-packs.js";
import { computeAutoModeV2Suggestion, type AutoModeV2Suggestion } from "./automode-v2.js";
import { computeAdaptation, echoOperatorFloors, applyBotFillLearning, freshLagDisagreeSkip, type AdaptationResult } from "./automode-adapter.js";
import { lagAgreesWithSide } from "./lag-meter.js";
import { recordBounceTick, getBounceInfo, getBounceConfidenceBonus } from "./bounce-level-tracker.js";
import { settlementPredictor } from "./settlement-predictor.js";
import { expertAgent } from "./expert-agent.js";
import {
  decideMoneyPath,
  directorSkipEmptiesEvaluateResult,
  snapshotTape,
  tagPaperFill,
  pathRideMonitorDisposition,
  sizePathRide,
  pForStrategyAtAsk,
  observeAdaptiveRegime,
  fillPathRegimeTraceFields,
  planMakerEntry,
  bookImbGate,
  direction_lock,
  overlayDirectionLock,
  formatDirectionLockLog,
  type AdaptiveRegimeSnapshot,
  type OrganReport,
  type TapeSnapshot,
} from "./organs/index.js";
import { bindSideWinRateAtPrice } from "./organs/filled-side.js";
import {
  applyPathAwareContracts, applyAsianHoursMoneyMakerFloor, applyAriaPathRules, isAriaDangerVeto,
  buildModeState, applyRiskProfileSizing,
  evaluateEntryGuards, evaluateRichAskBlock, isPathBlockedForTimeOfDay,
} from "./trade-path.js";
import type { AriaAssessment, ModeState, RiskProfile } from "./trade-path.js";
import { computeVolumeScore, getVolumeSizeMult, VOLUME_BUCKET_POLICY, warmVolumeRiskCache, recordVolumeBucketSettlement } from "./volume-risk.js";

import {
  applyStrongMTFDirectionLock,
  basisLagRegimeGateOk,
  detectGrokRegime,
  isReversalCapable,
  isStrategyAllowedInRegime,
  metaLabelConfidence,
  mtfCompositeLockAllowsSide,
  otmAwareMTFThresholds,
  pWinAtPriceRejectingThinLearner,
  passesHardFilters,
  passesStrategyRegimeFilter,
  settlementHoldOverrideEligible,
  settlementVetoOpposes,
} from "./admission.js";
import {
  selectBestEnabled,
  selectPaperDeskWinnerFromPool,
} from "./select-best-enabled.js";
import { effectiveDisabledStrategies } from "./strategy-gates.js";
import {
  CONFIDENCE_CALIBRATION_ENABLED,
  buildAriaInput,
  LEFTOVER_15M_FAST_VEL as FAST_VEL,
  LEFTOVER_15M_SUSTAINED_V3 as SUSTAINED_V3,
  LEFTOVER_15M_SWEEP_PREMIUM as SWEEP_PREMIUM,
} from "./leftover-15m-evaluate.js";
import { admit15m } from "./organs/admit-15m.js";
// unify: imports for names the funnel referenced but never imported (tsc TS2304)
import { isHarvestSessionFamilyAllowed } from "./settlement-side.js";
import { snapshotLastW2Log } from "./organs/direction-w2.js";
import { buildFrozenShadowPreDecision, decideFrozenCcEntry, enrichFrozenShadowPostTake, formatFrozenCcTakeDesc } from "./frozen-cc.js";
import type { FrozenShadowFlags } from "./frozen-cc.js";
import { classifyFrozenCcEntryShadow, maybeAppendEntryShadowDecision, YES_40_55_PIN_SHADOW_V1 } from "./frozen-cc-entry-shadow.js";
import { demoteMoneyGateCardToSit } from "./money-gate-card.js";
import { ccVelocityAgainstGate } from "./cc-velocity-gate.js";
import { sweptFillHitsStillMid } from "./aligned-take-gate.js";
import { binaryCallFairValueCents, complementaryFairValueCents } from "./binary-pricing.js";
import { sanitizeTheoCents } from "./brti-theo-sanity.js";
import { doesPreTradeVerdictMatchEntryPrice } from "./pre-trade-sim.js";
import { entryPathAndSize } from "./organs/entry-path-size.js";
import { stampOrganTakeFromReport } from "./organs/director.js";

export type Leftover15mLocals = {
  annualVol: any;
  channelInfo: any;
  currentPrice: any;
  distFromFloorPct: any;
  edge: any;
  eff: any;
  floorStrike: any;
  logEarlySkip: any;
  miData: any;
  minsLeft: any;
  mtf: any;
  mtfScore: any;
  noAsk: any;
  noBid: any;
  obs: any;
  prob: any;
  quoteAgeMs: any;
  regime: any;
  secs: any;
  skip: any;
  stalling: any;
  tick: any;
  ticker: any;
  traceId: any;
  v: any;
  v3: any;
  volumeState: any;
  window: any;
  yesAsk: any;
  yesBid: any;
};

export async function leftover15mEvaluateFunnel(this: any, L: Leftover15mLocals): Promise<void> {
  const {
    annualVol,
    channelInfo,
    currentPrice,
    distFromFloorPct,
    edge,
    eff,
    floorStrike,
    logEarlySkip,
    miData,
    minsLeft,
    mtf,
    mtfScore,
    noAsk,
    noBid,
    obs,
    prob,
    quoteAgeMs,
    regime,
    secs,
    skip,
    stalling,
    tick,
    ticker,
    traceId,
    v,
    v3,
    volumeState,
    window,
    yesAsk,
    yesBid,
  } = L;

    // ── Grok regime + adaptive condition classifier ──────────────────────────
    // Always runs (not gated by autoMode) so the condition is visible in the UI
    // even when the user is manually controlling the bot, and so it is
    // available below as the sole regime-driven baseline source for the
    // autoMode composer.
    // grokRegime is now derived from the single committed R_t (regime) via
    // the fixed REGIME_TO_GROK table, instead of an independent
    // detectGrokRegime() recompute — the two could previously disagree on
    // the same tick. shadowInstantGrokRegime is kept for comparison logging
    // only, never used for gating.
    const grokRegime = getGrokRegimeFromDetailed(regime);
    const shadowInstantGrokRegime = detectGrokRegime(obs, channelInfo ?? null);
    if (shadowInstantGrokRegime !== grokRegime) {
      this.log("info", `[regime] shadow instant grokRegime disagrees with committed: shadow=${shadowInstantGrokRegime} committed=${grokRegime}`);
    }
    const adaptiveResult = classifyDetailedCondition(obs, grokRegime, mtfScore, this.lastBasisState);
    this.lastAdaptiveCondition = adaptiveResult;
    const condOverlay = adaptiveResult.overlay;

    // ── autoMode composer (Phase 2, adaptive-control-plan.md) ────────────────
    // FAIL-CLOSED: even when autoMode is true, this block MUST NOT copy
    // condition-adapter overlay onto minConfidence / minVelocity / stops /
    // window / minProbEdge / maxContracts. That was the old composer that
    // ate Kelly's inputs. autoMode is now ADAPTATION that can stay ON
    // (skip more when tape lies, size down in DD, learn from BOT fills).
    if (this.config.autoMode) {
      const peak = this.peakBalanceCents;
      const bal = this.effectiveBalance();
      const ddPct = peak > 0 ? (peak - bal) / peak * 100 : 0;
      const volBucket = computeVolumeScore(obs).bucket;
      const adaptation = computeAdaptation({
        autoMode: true,
        tape: {
          volumeBucket: volBucket,
          chaosMode: adaptiveResult.chaosMode,
        },
        drawdownPct: ddPct,
        drawdownGuardPct: this.config.drawdownGuardPct,
      });
      this.lastAdaptation = adaptation;
      const floors = echoOperatorFloors(this.config as unknown as Record<string, unknown>);
      this.lastAutoSettings = {
        minConfidence:        Number(floors.minConfidence),
        minVelocity:          Number(floors.minVelocity),
        maxContractsPerTrade: Number(floors.maxContractsPerTrade),
        stopLossCents:        Number(floors.stopLossCents),
        profitTakeCents:      Number(floors.profitTakeCents),
        tradeWindowMinMin:    Number(floors.tradeWindowMinMin),
        tradeWindowMaxMin:    Number(floors.tradeWindowMaxMin),
        minProbEdge:          Number(floors.minProbEdge),
        reasoning: {
          confidence: `floor held at ${this.config.minConfidence}% (adapter never cuts)`,
          velocity:   `floor held at ${this.config.minVelocity} $/min`,
          contracts:  `sizeMult=${adaptation.sizeMult.toFixed(2)} (DD/thin tape only)`,
          risk:       `stops held at ${this.config.stopLossCents}¢ / ${this.config.profitTakeCents}¢`,
          window:     `window held ${this.config.tradeWindowMinMin}–${this.config.tradeWindowMaxMin} min`,
          edge:       `minProbEdge held at ${this.config.minProbEdge}%`,
          summary:    adaptation.summary,
        },
        adaptation,
      };
      const tickId = String(this.lastObsTs ?? Date.now());
      void adaptiveTuningLog.recordChange({
        parameter: "adaptation", owner: "autoMode", role: "would_apply",
        newValue: adaptation.summary, signal: "regime", condition: adaptiveResult.condition,
        reason: adaptation.summary, tickId,
      }).catch(() => {});
      if (adaptation.skip) {
        this.lastSignalDesc = `[adapter] ${adaptation.summary}`;
        logEarlySkip("TAPE_LIE", adaptation.summary);
        return;
      }
    } else {
      this.lastAdaptation = null;
    }

    // Merge condition overlay into eff, respecting user's manual overrides:
    // • Numeric params (contracts, stops, window, prob edge): only tighten,
    //   never loosen beyond what the user explicitly set. This means the
    //   condition can raise the bar but never let the bot take more risk than
    //   the user's base config allows.
    // • confidence/velocity: 2026-08-03 — no longer tightened by the condition
    //   overlay at all (previously Math.max'd, which meant every one of the 10
    //   conditions silently re-raised the manual minConfidence/minVelocity to
    //   62-73/20-60 regardless of what the operator set, e.g. 52). The
    //   operator's own eff.minConfidence/eff.minVelocity (still subject to
    //   ARIA's tighten-only expert-agent overrides above) are now the sole
    //   source of truth, so a manually-set 52 actually behaves like 52.
    // • suppressStrategies: GO — STEP 3 (2026-08-22) condition-adapter live
    //   disarm. condOverlay's automatic per-condition/chaos suppression list
    //   NO LONGER force-disables strategies on the live path — packs
    //   (specialistPacksMode === 'enforce') are the sole eligibility
    //   allowlist, so a second, silent disable-list from the adapter was
    //   self-interfering with pack eligibility rather than adding
    //   independent safety. What the condition WOULD have suppressed is
    //   still computed and logged below for observation (`would_suppress`)
    //   — nothing here is deleted, only no longer applied.
    // • boostStrategy: used below when selecting the best strategy.
    // NOTE: tradeWindowMinMin/MaxMin below are carried through for
    // completeness but are NOT the live window gate — that already happened
    // above via computeEffectiveWindow() (using last tick's overlay, same
    // one-tick staleness as autoSettings). Don't add a second window check
    // against these fields; it would just re-derive the same bounds.
    const condEff = {
      ...eff,
      minConfidence:        eff.minConfidence,
      minVelocity:          eff.minVelocity,
      maxContractsPerTrade: Math.min(eff.maxContractsPerTrade, condOverlay.maxContractsPerTrade),
      stopLossCents:        Math.min(eff.stopLossCents,        condOverlay.stopLossCents),
      profitTakeCents:      Math.min(eff.profitTakeCents,      condOverlay.profitTakeCents),
      tradeWindowMinMin:    Math.max(eff.tradeWindowMinMin,    condOverlay.tradeWindowMinMin),
      tradeWindowMaxMin:    Math.min(eff.tradeWindowMaxMin,    condOverlay.tradeWindowMaxMin),
      minProbEdge:          Math.max(eff.minProbEdge,          condOverlay.minProbEdge),
      disabledStrategies:   [
        // Phase 1 observability logging is fired just below this array
        // literal (can't sit inline here without a self-invoking hack) —
        // see the `void Promise.all(...)` call right after this object.
        ...effectiveDisabledStrategies(eff),
        // Performance gate: DB-backed (bot_trades-derived) Wilson 95%
        // lower-bound win rate below break-even blocks NEW entries until
        // recent results lift the bound (auto-recovers, no restart needed).
        // See strategy-performance.ts — this replaced the old JSON-file
        // quarantine (strategy-learner.ts's getQuarantinedStrategies) as the
        // single source of truth for "is this strategy allowed to fire?".
        // Duration-scoped: only strategies quarantined ON THE 15-MINUTE bucket
        // are blocked here (a strategy quarantined only on 1H still trades 15m).
        ...getDbDisabledStrategies(15),
      ],
    };

    // Phase 1 observability (adaptive-control-plan.md): log condition-adapter's
    // baseline overlay as-is today, pre-refactor. Fire-and-forget.
    {
      const tickIdCond = String(this.lastObsTs ?? Date.now());
      void Promise.all([
        adaptiveTuningLog.recordChange({
          parameter: "maxContractsPerTrade", owner: "condition-adapter", role: "baseline",
          newValue: condOverlay.maxContractsPerTrade, signal: "regime",
          condition: adaptiveResult.condition, reason: condOverlay.rationale, tickId: tickIdCond,
        }),
        adaptiveTuningLog.recordChange({
          parameter: "stopLossCents", owner: "condition-adapter", role: "baseline",
          newValue: condOverlay.stopLossCents, signal: "regime",
          condition: adaptiveResult.condition, reason: condOverlay.rationale, tickId: tickIdCond,
        }),
        adaptiveTuningLog.recordChange({
          parameter: "profitTakeCents", owner: "condition-adapter", role: "baseline",
          newValue: condOverlay.profitTakeCents, signal: "regime",
          condition: adaptiveResult.condition, reason: condOverlay.rationale, tickId: tickIdCond,
        }),
        adaptiveTuningLog.recordChange({
          parameter: "tradeWindowMinMin", owner: "condition-adapter", role: "baseline",
          newValue: condOverlay.tradeWindowMinMin, signal: "regime",
          condition: adaptiveResult.condition, reason: condOverlay.rationale, tickId: tickIdCond,
        }),
        adaptiveTuningLog.recordChange({
          parameter: "tradeWindowMaxMin", owner: "condition-adapter", role: "baseline",
          newValue: condOverlay.tradeWindowMaxMin, signal: "regime",
          condition: adaptiveResult.condition, reason: condOverlay.rationale, tickId: tickIdCond,
        }),
        adaptiveTuningLog.recordChange({
          parameter: "minProbEdge", owner: "condition-adapter", role: "baseline",
          newValue: condOverlay.minProbEdge, signal: "regime",
          condition: adaptiveResult.condition, reason: condOverlay.rationale, tickId: tickIdCond,
        }),
        // GO — STEP 3 (2026-08-22): would_suppress observability. This
        // strategy list is NO LONGER applied to condEff.disabledStrategies
        // (see the comment above that array) — logged here purely so a
        // human/ARIA can see what the adapter would have blocked, in case a
        // future review wants it back for a specific condition.
        adaptiveTuningLog.recordChange({
          parameter: "suppressStrategies", owner: "condition-adapter", role: "would_suppress",
          newValue: condOverlay.suppressStrategies.length > 0 ? condOverlay.suppressStrategies.join(",") : "none",
          signal: "regime", condition: adaptiveResult.condition, reason: condOverlay.rationale, tickId: tickIdCond,
        }),
      ]).catch(() => {});
    }

    // ── Single safety gate ────────────────────────────────────────────────────
    // Aggregates WS/MTF/balance/auth staleness, ARIA DANGER veto, sustained
    // HIGH risk, and external-API circuit breakers into one check. Only skips
    // NEW-entry evaluation for this tick — open-trade management already
    // returned earlier and is never affected by this gate.
    const safety = isDecisionSafe();
    if (!safety.safe) {
      this.lastSignalDesc = `[${grokRegime}] Trading paused — ${safety.reasons[0]}`;
      logEarlySkip("SAFETY_GATE", this.lastSignalDesc);
      return;
    }

    // ── GO — APPLY PACKS ENFORCE (2026-08-18) ─────────────────────────────────
    // Specialist pack selection, computed once per tick using the SAME
    // committed regime (R_t) and this tick's own volume-risk bucket that the
    // sizing stack further below will also read (computeVolumeScore(obs) is
    // a pure function of `obs`, so recomputing it there is guaranteed to
    // agree — not a second independent read that could disagree tick-to-
    // tick). 15m path ONLY — the hourly path never sets specialistPacksMode
    // and never reads enforcedPack/packEligibleIds. `off`/`shadow` compute
    // nothing here; the existing SKIP/ORDER-path shadow lookups further down
    // are unaffected either way.
    let enforcedPack: SpecialistPack | null = null;
    let packEligibleIds: Set<StrategyId> | null = null;
    if (this.config.specialistPacksMode === 'enforce') {
      const packVBucket = computeVolumeScore(obs).bucket;
      enforcedPack = getPack(regime, packVBucket);
      if (enforcedPack) {
        packEligibleIds = new Set(computeWouldEligible(enforcedPack, condEff.disabledStrategies ?? []));
        this.log("info",
          `📦 [pack-enforce] R=${regime} V=${packVBucket} pack=${enforcedPack.id} ` +
          `eligible=[${[...packEligibleIds].join(',') || 'none'}] confBump=${enforcedPack.confBump} sizeCap=${enforcedPack.sizeCapMult}`
        );
      }
    }
    // Real (not shadow) per-tick pack state — read by logSkippedDecision()'s
    // and placeOrder()'s DecisionTrace calls below/downstream so a trace
    // never re-derives a value that could disagree with what actually gated
    // this tick.
    this.lastEnforcedPack = enforcedPack;
    this.lastPackEligibleIds = packEligibleIds ? [...packEligibleIds] : null;

    // ── GO — STEP 5 autoMode v2 PHASE A, SUGGEST ONLY (2026-08-22) ────────────
    // Rate-limited to a regime change or every AUTOMODE_V2_MIN_RECOMPUTE_MS —
    // never every tick/WS update. Documented (NOT applied) merge order for a
    // future bounded_write phase: baseline → pack confBump/sizeCap →
    // (auto only if bounded_write) → uMult × volume → EV. In Phase A, this
    // block only computes + logs; `eff`/`condEff` below are never touched by
    // it, regardless of `autoModeV2Mode` — including 'bounded_write', whose
    // write-application logic is intentionally unimplemented until an
    // explicit "PHASE B ACK".
    if (this.config.autoModeV2Mode !== 'off') {
      const AUTOMODE_V2_MIN_RECOMPUTE_MS = 10 * 60 * 1000; // 10 min, within the ACK'd 5-15 min band
      const now = this.lastObsTs || Date.now();
      const regimeChanged = this.lastAutoModeV2Regime !== null && this.lastAutoModeV2Regime !== regime;
      const dueForRecompute = now - this.lastAutoModeV2ComputeTs >= AUTOMODE_V2_MIN_RECOMPUTE_MS;
      if (this.lastAutoModeV2Regime === null || regimeChanged || dueForRecompute) {
        const v2VBucket = computeVolumeScore(obs).bucket;
        const v2PackId: PackId | null = enforcedPack?.id ?? getPack(regime, v2VBucket)?.id ?? null;
        const suggestion = computeAutoModeV2Suggestion({
          baselineMinConfidence: this.config.minConfidence,
          regime, vBucket: v2VBucket, packId: v2PackId,
        });
        this.lastAutoModeV2Suggestion = suggestion;
        this.lastAutoModeV2Regime = regime;
        this.lastAutoModeV2ComputeTs = now;
        const tickId = String(this.lastObsTs ?? Date.now());
        void Promise.all([
          adaptiveTuningLog.recordChange({
            parameter: "minConfidence", owner: "autoMode", role: "would_apply",
            newValue: suggestion.proposedMinConf, signal: "regime", condition: `${regime}/${v2VBucket}${v2PackId ? `/${v2PackId}` : ''}`,
            reason: suggestion.reason, tickId,
          }),
          adaptiveTuningLog.recordChange({
            parameter: "positionSizeMult", owner: "autoMode", role: "would_apply",
            newValue: suggestion.proposedSizeMult, signal: "regime", condition: `${regime}/${v2VBucket}${v2PackId ? `/${v2PackId}` : ''}`,
            reason: suggestion.reason, tickId,
          }),
        ]);
        this.log("info",
          `🧪 [autoMode-v2:${this.config.autoModeV2Mode}] R=${regime} V=${v2VBucket} pack=${v2PackId ?? 'none'} ` +
          `proposedMinConf=${suggestion.proposedMinConf} (baseline=${this.config.minConfidence}) proposedSizeMult=${suggestion.proposedSizeMult} ` +
          `— suggest-only, no live effect (${suggestion.reason})`
        );
      }
    }

    // GO PRODUCTION QUALITY 8.0→8.5 Step B: condEff.disabledStrategies (user +
    // condition-suppression + DB quarantine for 15m, assembled above) is now
    // passed straight into the shared enumeration function so a disabled
    // strategy's evaluate() is never invoked for the live 15m entry decision
    // — it is absent from `allResults`/consensus from the start, not
    // evaluated-then-filtered downstream.
    // CONSENSUS MEASUREMENT PURITY (2026-08-16): cache this tick's effective
    // disabled set so backgroundPreTrade()'s independent timer can thread the
    // IDENTICAL expression into its own pre-trade consensus check below.
    //
    // GO — LEAN ADMIT, ITEM D (2026-08-22): packs are the sole eligibility
    // allowlist (item B) — extended here to strategy-CONSENSUS MEASUREMENT,
    // not just selection. Before this, checkStrategyConsensus() measured
    // agreement against every non-disabled strategy in the FULL roster, so a
    // pack with only 1-2 eligible strategies (SQUEEZE: 1, TRANSITION: 2) had
    // its one legal signal diluted by disagreement from strategies the pack
    // had already ruled out — starving exactly the setups the pack exists to
    // trade. When a pack is enforced, strategies outside packEligibleIds are
    // now ALSO excluded from the pre-trade-sim consensus/EV call used for
    // real admission — never from `allResults` below, which is the raw
    // "what the bot's whole strategy stack sees this tick" dashboard feed
    // (Task #445) and is deliberately left unfiltered.
    const consensusDisabledIds = computeConsensusDisabledIds(
      condEff.disabledStrategies ?? [],
      getAllStrategyMeta().map(m => m.id),
      packEligibleIds,
    );
    this.lastEffectiveDisabledSet = consensusDisabledIds;
    const evaluated: ReturnType<typeof evaluateAllStrategies> = this.evaluateStrategiesForBot(obs, condEff.disabledStrategies);
    const { all: allResults, consensus: signalConsensus, consensusConf, best: consensusBest } = evaluated;
    try {
      if (this.config.paperMode === true) {
        const qTs = kalshiWS.getLatest()?.quoteTs;
        notePaperBarEvaluate({
          obs,
          tickSource: tick?.source === "rest" || tick?.source === "ws" ? tick.source : null,
          quoteAgeMs: typeof qTs === "number" && qTs > 0 ? Date.now() - qTs : Number.POSITIVE_INFINITY,
          regime: typeof regime === "string" ? regime : obs.regime ?? null,
          virtualCents: this.paperVirtualBalanceCents,
          wins: this.paperStats.wins,
          losses: this.paperStats.losses,
          pnlCents: this.paperStats.pnlCents,
        });
      }
    } catch { /* observational paper-bar-tape */ }

    // ── Task #445: real strategy consensus for the dashboard ─────────────────
    // Captures what the bot's own strategy stack actually sees this tick —
    // every strategy that fired (before regime/duration/override filtering
    // narrows the field further below) — so the frontend can show real
    // LONG/SHORT/MIXED/NONE + confidence instead of the disconnected 8-
    // condition ReversalHunter heuristic. `decision` collapses MIXED/NONE to
    // STAY_OUT since neither represents a clear directional read.
    this.lastStrategyConsensus = {
      decision: signalConsensus === 'LONG' ? 'LONG' : signalConsensus === 'SHORT' ? 'SHORT' : 'STAY_OUT',
      confidencePct: (signalConsensus === 'LONG' || signalConsensus === 'SHORT') ? Math.round(consensusConf * 100) : 0,
      consensus: signalConsensus,
      totalCount: allResults.length,
      longCount: allResults.filter(r => r.signal === 'YES').length,
      shortCount: allResults.filter(r => r.signal === 'NO').length,
      topReason: consensusBest?.reason ?? null,
      ts: Date.now(),
    };

    // Respect strategyOverride: when set, only that strategy can fire
    this.warnIfDisabledStrategyOverride("15m");
    const pool = this.config.strategyOverride
      ? allResults.filter(r => r.strategyId === this.config.strategyOverride)
      : allResults;
    // Select the highest-confidence enabled strategy, skipping any disabled ones
    // ── Regime allowlist gate ────────────────────────────────────────────────
    // Remove strategies whose edge is structurally negative in the current Grok
    // regime before confidence scoring. This fires BEFORE the EV filter so we
    // never waste a pre-trade sim on a known-bad strategy/regime combination.
    // Duration gate (Priority 2): only strategies deliberately allowlisted for
    // the 15-minute contract may fire here. This is the 15m entry path
    // (contractDurationMins: 15 below). Guarded against emptiness after the
    // regime filter so no market condition is left with zero tradeable strats.
    const durationPool = pool.filter(r => isStrategyAllowedForDuration(r.strategyId, 15));
    // Use the same unclear-regime policy as the final admission check below:
    // while the fine-grained classifier is uncertain, preserve every
    // duration-valid candidate for the remaining (pack, session, EV, and risk)
    // gates. A committed regime still enforces the strategy's coarse
    // enabledInRegimes declaration.
    let regimePool = durationPool.filter(r => passesStrategyRegimeFilter({
      strategyId: r.strategyId,
      currentRegime: regime,
      grokRegime,
    }));
    if (regimePool.length === 0 && durationPool.some(r => r.signal !== 'STAY_OUT')) {
      // Regime allowlist emptied the pool while duration-valid signals exist —
      // fall back to the duration-valid pool so the regime gate never fully
      // silences 15m trading. (The confidence/EV/sim gates downstream still
      // apply.) Logged so this fallback is auditable.
      this.log("info", `[15m] regime allowlist [${grokRegime}] left 0 strategies — falling back to duration-valid pool`);
      regimePool = durationPool;
    }
    // ── Adaptive condition: suppress + boost ─────────────────────────────────
    // condEff.disabledStrategies already merges user + condition suppressions.
    // When the condition specifies a boostStrategy, bump its confidence by 4
    // so it wins selection ties against other valid strategies.
    const boostedRaw = condOverlay.boostStrategy
      ? regimePool.map(r => r.strategyId === condOverlay.boostStrategy
          // Strategy confidence is a 0–1 float, not 0–100 — a "+4" bump (meant
          // to be a small tie-breaking nudge) was 100x too large and the old
          // `Math.min(100, ...)` cap never engaged, so any boosted strategy
          // was forced to ~4.7 confidence and downstream clamps forced it to
          // the maximum possible score regardless of actual signal quality.
          ? { ...r, confidence: Math.min(1.0, r.confidence + 0.04) }
          : r)
      : regimePool;
    // Goose veto: LATE not in boostedPool for money fills. evaluate may exist.
    const boostedPool = boostedRaw.filter(r => !FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has(r.strategyId));
    // MTF-aligned cheap on CC/LAG before selectBestEnabled. ENTRY 28/10 uncut.
    // 37¢ YES / 8¢ NO is KEEP skip (no aligned cheap).
    const alignedCheapPool = filterPoolToMtfAlignedCheap(boostedPool, {
      mtfScore,
      yesAsk,
      noAsk,
      spot: currentPrice,
      floorStrike,
    });
    // ── Strong MTF direction lock (Task #278) ───────────────────────────────
    // In a strong bear/bull trend, only NO/YES respectively may reach
    // selection. This is deliberately applied before session/pack filtering
    // so no downstream selector can re-admit a contradictory signal.
    const trendFilteredPool = applyStrongMTFDirectionLock(
      alignedCheapPool,
      mtfScore,
      this.config.useStrongMTFDirectionLock,
      msg => this.log("info", msg),
      { yesAsk, noAsk, spot: currentPrice, floorStrike },
    );

    // ── Hunt vs Harvest session mode (master bot upgrade step 3) ─────────────
    // HARVEST (Asia/Sunday/dead hours) restricts eligible strategies to the
    // basis-lag + late-displacement families (lag/anchor/continuation) only —
    // deliberately NOT guarded against emptying the pool the way the regime/
    // condition-suppression fail-safes above are: during thin hours the bot
    // is *supposed* to sit out far more often, that is the point of the gate.
    // HUNT makes no family-eligibility change (permissive — see design notes).
    const sessionMode: SessionMode = getCurrentSessionMode();
    this.lastSessionMode = sessionMode;
    // Profit-pass FIX #1 lives in isHarvestSessionFamilyAllowed (paper LAG exempt).
    const isHarvestFamily = (strategyId: StrategyId): boolean =>
      isHarvestSessionFamilyAllowed(this.config.paperMode, strategyId);
    if (this.lastLoggedSessionMode !== sessionMode) {
      this.log("info", `[session] mode=${sessionMode} (15m tick, utcHour=${new Date().getUTCHours()}, utcDay=${new Date().getUTCDay()})`);
      this.lastLoggedSessionMode = sessionMode;
    }
    if (sessionMode === 'HARVEST') {
      for (const r of trendFilteredPool) {
        if (!isHarvestFamily(r.strategyId)) {
          skip("SESSION_FAMILY_SUPPRESSED", [
            `[HARVEST] ${r.strategyId} (family=${getStrategyFamily(r.strategyId) ?? 'unknown'}) suppressed — only basis-lag/late-displacement trade during Asia/Sunday/dead hours`,
          ], {
            ticker, side: r.signal === 'YES' ? 'yes' : 'no', strategyId: r.strategyId,
            entryPriceCents: r.signal === 'YES' ? yesAsk : noAsk, confidence: r.confidence, secsRemaining: secs, floorStrike,
          });
        }
      }
    }
    const sessionFilteredPool = sessionMode === 'HARVEST'
      ? trendFilteredPool.filter(r => isHarvestFamily(r.strategyId))
      : trendFilteredPool;

    // ── Manual-disable visibility (master bot upgrade step 1A) ───────────────
    // condEff.disabledStrategies merges 3 sources (user/config, condition-
    // adapter suppression, DB quarantine) with no distinction downstream —
    // a manually quarantined strategy (e.g. MTF_ALIGNED) that still fires a
    // signal every tick would otherwise vanish silently into that merged set.
    // Surface it under its own code so operators can see manual disable is
    // the active reason, not regime suppression or auto-quarantine.
    const manualDisabledSet = new Set(effectiveDisabledStrategies(this.config));
    for (const r of sessionFilteredPool) {
      if (manualDisabledSet.has(r.strategyId)) {
        skip("STRATEGY_MANUAL_DISABLE", [`${r.strategyId} manually disabled via config — signal ignored`], {
          ticker, side: r.signal === 'YES' ? 'yes' : 'no', strategyId: r.strategyId,
          entryPriceCents: r.signal === 'YES' ? yesAsk : noAsk, confidence: r.confidence, secsRemaining: secs, floorStrike,
        });
      }
    }
    // ── APPLY PACKS ENFORCE: eligibility hard filter ─────────────────────────
    // Once enforced, only the tick's pack's eligible strategies (already ∩
    // disabled/quarantine/deny-family via computeWouldEligible, computed
    // above) may reach consensus/selection — this is now LIVE LAW, not
    // shadow observation. No pack selected this tick (regime not yet
    // reachable, e.g. breakout_up/fakeout/exhaustion/waterfall) means no
    // restriction, matching Phase 2 shadow's NO_PACK semantics.
    if (packEligibleIds) {
      for (const r of sessionFilteredPool) {
        if (!packEligibleIds.has(r.strategyId)) {
          skip("PACK_NOT_ELIGIBLE", [
            `[pack=${enforcedPack!.id}] ${r.strategyId} not in pack's eligible set — blocked by APPLY PACKS ENFORCE`,
          ], {
            ticker, side: r.signal === 'YES' ? 'yes' : 'no', strategyId: r.strategyId,
            entryPriceCents: r.signal === 'YES' ? yesAsk : noAsk, confidence: r.confidence, secsRemaining: secs, floorStrike,
          });
        }
      }
    }
    const packFilteredPool = filterPoolByPack(sessionFilteredPool, packEligibleIds);

    // ── P-FILL LIVE, Part A (2026-08-26): SETTLEMENT_PREDICTION tick-hijack fix ──
    // SETTLEMENT_PREDICTION's own evaluate() can still emit a directional
    // signal on a regime-EV-hostile tick — the "hostile" classification only
    // exists in the regime-conditional EV filter further below, not inside
    // evaluate() itself. When it does fire AND it's the highest-confidence
    // candidate this tick, the old code let it become the leader via
    // selectBestEnabled, then hit the EV filter below and `return`ed
    // immediately — ending the ENTIRE tick before any other already-
    // evaluated, EV-passing specialist (e.g. BASIS_LAG_EDGE) got a chance to
    // be selected instead. Per the 2026-08-26 blocker-dump audit this was the
    // single dominant 6h/24h SKIP reason. Fix: pre-screen SETTLEMENT_
    // PREDICTION's own regime EV *before* selection and drop it from this
    // tick's selection pool only (never from the library, never added to
    // condEff.disabledStrategies — it is fully eligible again the moment its
    // own EV clears) when hostile, so a genuinely EV-passing candidate can
    // still be selected and reach placeOrder this same tick. It therefore
    // also can't be selectBestEnabled's top pick nor contribute to its
    // long/short weight tally on a hostile tick. The SKIP trace for this
    // specific preemption is rate-limited to <=1/min — the underlying
    // condition is re-checked every tick, but logging it every tick while
    // it's the dominant blocker just floods decision_traces with no new
    // information.
    let selectionPool = packFilteredPool;
    const spCandidate = packFilteredPool.find(r => r.strategyId === 'SETTLEMENT_PREDICTION');
    if (spCandidate && spCandidate.signal !== 'STAY_OUT') {
      const spEntryPriceEV = spCandidate.signal === 'YES' ? yesAsk : noAsk;
      const spStratMeta    = getAllStrategyMeta().find(s => s.id === 'SETTLEMENT_PREDICTION');
      const spWinRate = spStratMeta?.winRateAtPrice
        ? spStratMeta.winRateAtPrice(spEntryPriceEV, secs / 60)
        : spStratMeta?.expectedWinRate ?? 0.65;
      const spStratEV = scoreStrategyEV(spCandidate, obs, spEntryPriceEV, spWinRate);
      if (spStratEV <= 0) {
        selectionPool = packFilteredPool.filter(r => r.strategyId !== 'SETTLEMENT_PREDICTION');
        const now = Date.now();
        if (now - this.lastSPHostilePreemptLoggedAt >= 60_000) {
          this.lastSPHostilePreemptLoggedAt = now;
          skip("REGIME_EV_FILTER", [
            `[${regime}] Settlement Prediction Model: EV ${spStratEV.toFixed(2)} — hostile regime, preempted from leader selection (other strategies still eligible this tick; log rate-limited to 1/min)`,
          ], {
            ticker, side: spCandidate.signal === 'YES' ? 'yes' : 'no', strategyId: 'SETTLEMENT_PREDICTION',
            entryPriceCents: spEntryPriceEV, confidence: spCandidate.confidence, secsRemaining: secs, floorStrike,
          });
        }
      }
    }
    selectionPool = selectionPool.filter(r => !FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has(r.strategyId));
    // selectBestEnabled + paper desk + basis refresh BEFORE admit15m (organ owns
    // aligned → overlay → SELECT_MISS reinject → W2 → moneyGateCard → W2 overlay).
    let stratResult = selectBestEnabled(selectionPool, condEff.disabledStrategies ?? []);
    // PAPER DESK v2: one winner by max netEV among the six (door-gated).
    if (this.config.paperMode === true) {
      const deskWin = selectPaperDeskWinnerFromPool(
        selectionPool,
        condEff.disabledStrategies ?? [],
        {
          yesAsk,
          noAsk,
          secsRemaining: secs,
          velocityDolPerMin: this.currentVelocity ?? undefined,
          mtfSide: mtfScore > 0 ? "yes" : mtfScore < 0 ? "no" : null,
        },
      );
      if (deskWin) stratResult = deskWin;
    }
    // Refresh basis before W2 so lagMeter.proven cannot disagree with obs.lagProven.
    const basisSnap = basisTracker.getState();
    if (basisSnap) this.lastBasisState = basisSnap;
    const liveLagProven = basisSnap?.lagProven === true || this.lastBasisState?.lagProven === true;
    const liveLagStale = basisSnap?.lagStale === true || this.lastBasisState?.lagStale === true
      || basisSnap == null;
    // Identity pin for G/A_hat/settlement: CF Benchmarks BRTI only — never
    // estimatedFairBRTI / book-inferred proxy (fail-closed → brtiDefined false).
    const brtiPx = kalshiWS.getFreshBrtiUsd(2_500);
    const venue2Age = basisSnap?.binanceAgeMs;
    const venue2Live = typeof venue2Age === "number" && Number.isFinite(venue2Age) && venue2Age <= 15_000;
    // F3: explicit meter lagSide + lagStale + lagProven into W2 — never invent from 1s proj.
    const w2LagSide = meterLagSideForW2({
      lagProven: liveLagProven,
      lagStale: liveLagStale,
      lagDollars: basisSnap?.lagDollars ?? this.lastBasisState?.lagDollars ?? obs.lagDollars ?? null,
    });
    const admit = admit15m({
      aligned: {
        mtfSign: mtfScore,
        yesAsk,
        noAsk,
        lagProven: obs.lagProven === true,
        quoteStale: false,
        secsRemaining: secs,
        spot: currentPrice,
        floorStrike,
        winRateAtPrice: bindSideWinRateAtPrice({
          yesAsk,
          noAsk,
          minutesLeft: secs / 60,
          curveFor: (strategyId) => {
            const id = strategyId === "BASIS_LAG_EDGE" ? "BASIS_LAG_EDGE" : "CONFLUENCE_CASCADE";
            const meta = getAllStrategyMeta().find(s => s.id === id);
            return meta?.winRateAtPrice ?? null;
          },
        }),
      },
      stratResult,
      selectionPool,
      // Prefer sessionFilteredPool — never reinject HARVEST-suppressed CC from boosted.
      recoverPool: sessionFilteredPool,
      mayRecover: (row) => {
        if (sessionMode !== "HARVEST") return true;
        return paperMoneyMakerHarvestExempt(this.config.paperMode, row.strategyId)
          || isHarvestFamily(row.strategyId);
      },
      w2: {
        lagSide: w2LagSide,
        ohlc1m: obs.ohlc1m,
        ohlc5m: obs.ohlc5m,
        analog15mBars: getMtfOhlcBars(15)?.bars,
        ohlc4h: getMtfOhlcBars(240)?.bars,
        ohlc15m: getMtfOhlcBars(15)?.bars,
        spot: currentPrice,
        floorStrike,
        strike: floorStrike,
        projectedSettlement: obs.projectedSettlementPrice,
        lagProven: liveLagProven,
        lagStale: liveLagStale,
        orderbookImbalance: obs.orderbookImbalance,
        brtiPx,
        brtiDefined: brtiPx != null,
        venue2Live,
        venue2Px: venue2Live ? (basisSnap?.exchangeSource === "binance" ? basisSnap.exchangePrice : null) : null,
        // vol/delta not on MTF OHLC snapshot — leave null → MIX/unknown (never invent)
        deltaSign: null,
      },
      moneyGate: {
        // Card honesty: same live meter as W2 — never paint lagProven from stale obs alone.
        lagProven: liveLagProven,
        lagStale: liveLagStale,
        lagReason: basisSnap?.lagReason ?? obs.lagReason ?? null,
        sessionMode,
        sessionClockLabel: sessionClockLabel(new Date().getUTCHours()),
        velocityDolPerMin: obs.velocityDolPerMin ?? this.currentVelocity,
        quoteAgeMs: (() => {
          const qTs = kalshiWS.getLatest()?.quoteTs;
          return typeof qTs === "number" && qTs > 0 ? Date.now() - qTs : null;
        })(),
        pinHard: false, // binary_pin hard skips arrive via W2 reason / upstream; tag pin_reachable stays soft
      },
      // Defense-in-depth: if six-gate sole, skip leftover admit body (ran:false).
      sixGateOnly: frozenSixGateIsOnlyEvaluatePath(this.config),
    });
    const alignedGate = admit.alignedGate;
    const w2Lock = admit.w2Lock;
    selectionPool = admit.selectionPool;
    stratResult = admit.stratResult;
    const preW2 = admit.preW2StratResult;
    if (admit.recovered) {
      this.log("info",
        `SELECT_MISS_RECOVER ${admit.recovered.strategyId} ${admit.recovered.signal} — select/overlay emptied pool; restoring moneyCand for hard gates`
      );
      this.lastStrategyResult = admit.preW2StratResult;
      if (admit.preW2StratResult && admit.preW2StratResult.signal !== "STAY_OUT") {
        this.lastSignalDesc = `${admit.recovered.strategyId} ${admit.recovered.signal} recovered after select miss`;
      }
    }
    if (alignedGate.kind === "TAKE" && alignedGate.constructedNo === true) {
      this.log("info", formatConstructedNoLog({ p: alignedGate.p, ask: alignedGate.ask }));
    }
    if (alignedGate.kind === "TAKE" && alignedGate.goldCopy === true) {
      this.log("info",
        `🏅 gold-trade-copy ${alignedGate.replitCell ?? "?"} · ${alignedGate.strategyId} ${alignedGate.side.toUpperCase()} @ ${alignedGate.ask}¢ EV=${alignedGate.ev.toFixed(1)} (Replit cell shape; EV≥3 held)`
      );
    }
    {
      const w2Emit = shouldEmitDirectionW2Log(w2Lock.log, this.w2LogThrottle);
      if (w2Emit.emit) this.log("info", formatDirectionW2Log(w2Lock.log) + w2Emit.suppressedSuffix);
    }
    this.lastW2Log = snapshotLastW2Log(w2Lock.log);
    // EVALUATING card = real money gates (not composite 74 / session / consensus).
    this.lastMoneyGateCard = admit.moneyGateCard;

    // ── FROZEN_CC: one hypothesis, six gates, everything else is a shadow flag ──
    // Everything above this line (feed freshness, last-60s, daily halt,
    // observation, CC evaluate, aligned side lock, W2) still ran. Everything
    // below it (W2 veto, HARVEST, regime, MTF filter, HTF, streak, overpay,
    // confidence floor, settlement veto, ARIA, pre-trade sim, ...) is bypassed
    // and, where cheap, recorded on the fill as a shadow verdict instead.
    if (this.config.frozenCcMode === true) {
      const ccResult = allResults.find(r => r.strategyId === FROZEN_CC_STRATEGY_ID) ?? null;
      let regimeWouldBlock: boolean | null = null;
      try {
        regimeWouldBlock = !passesStrategyRegimeFilter({
          strategyId: FROZEN_CC_STRATEGY_ID, currentRegime: regime, grokRegime,
        });
      } catch { regimeWouldBlock = null; }
      let shadow: FrozenShadowFlags = buildFrozenShadowPreDecision({
        w2Kind: w2Lock.kind,
        w2Reason: w2Lock.kind === "SKIP" ? w2Lock.reason : (w2Lock.log.lockSide_why ?? null),
        sessionMode,
        harvestWouldSuppress: sessionMode === "HARVEST"
          && !isHarvestSessionFamilyAllowed(false, FROZEN_CC_STRATEGY_ID),
        regime: String(regime ?? "unclear"),
        grokRegime: String(grokRegime ?? ""),
        regimeWouldBlock,
        mtfScore: Number.isFinite(mtfScore) ? mtfScore : null,
        lagProven: obs.lagProven === true,
        lagStale: this.lastBasisState?.lagStale ?? null,
        lagDollars: this.lastBasisState?.lagDollars ?? obs.lagDollars ?? null,
        velocityDolPerMin: Number.isFinite(this.currentVelocity) ? this.currentVelocity : null,
        consecutiveLosses: this.consecutiveLosses,
        ccConfidence: ccResult?.confidence ?? null,
        ccReason: ccResult?.reason ?? null,
        aligned: alignedGate,
      });

      const frozen = decideFrozenCcEntry({
        secsRemaining: secs,
        yesAsk,
        noAsk,
        cc: ccResult ? { signal: ccResult.signal, confidence: ccResult.confidence, reason: ccResult.reason } : null,
        aligned: alignedGate,
        shadow,
        andSitArmed: this.config.frozenCcAndSit === true,
      });
      // YES_40_55_PIN_SHADOW_V1 — OBSERVE ONLY. Never changes TAKE/SIT.
      let entryShadowDecisionId: string | null = null;
      let entryShadowSit = false;
      let entryShadowProtectedCheapNo = false;
      let entryShadowProtectedCheapYes = false;
      try {
        const sideForShadow: "yes" | "no" =
          frozen.side ?? (alignedGate.kind === "TAKE" ? alignedGate.side : (mtfScore < 0 ? "no" : "yes"));
        const askForShadow =
          typeof frozen.ask === "number" && Number.isFinite(frozen.ask)
            ? frozen.ask
            : (alignedGate.kind === "TAKE" ? alignedGate.ask : (sideForShadow === "yes" ? (yesAsk ?? 0) : (noAsk ?? 0)));
        const feeNetEv =
          frozen.kind === "TAKE" ? frozen.ev
            : (alignedGate.kind === "TAKE" ? alignedGate.ev : 0);
        const shadowClass = classifyFrozenCcEntryShadow({
          paperMode: this.config.paperMode === true,
          frozenCcMode: true,
          market: ticker.startsWith("KXBTC15M") ? "KXBTC15M" : (ticker.split("-")[0] ?? ticker),
          quoteFresh: true,
          secsRemaining: secs,
          side: sideForShadow,
          ask: askForShadow,
          feeNetEvCents: feeNetEv,
          kellyFrac: 0.60,
          positionAndPendingClear: this.openTrade == null && !this.heldPendingFromRestart,
          w2Reason: shadow.w2Reason,
          regimeWouldBlock: shadow.regimeWouldBlock === true,
          brtiSign: this.lastW2Log?.lockSide?.brtiSign ?? null,
          decision: frozen,
        });
        entryShadowSit = shadowClass.shadowSit;
        entryShadowProtectedCheapNo = shadowClass.protectedCheapNo;
        entryShadowProtectedCheapYes = shadowClass.protectedCheapYes;
        entryShadowDecisionId = maybeAppendEntryShadowDecision({
          ticker,
          paperMode: this.config.paperMode === true,
          frozenCcMode: true,
          side: sideForShadow,
          ask: askForShadow,
          secsRemaining: secs,
          feeNetEv,
          kellyFrac: 0.60,
          w2Reason: shadow.w2Reason ?? null,
          regimeWouldBlock: shadow.regimeWouldBlock === true,
          haDisagree: shadow.w2Reason === "ha_disagree",
          pinReachable: shadow.w2Reason === "pin_reachable",
          strikeDisagree: shadow.w2Reason === "strike_disagree",
          brtiSign: shadowClass.brtiSign,
          realDecision: frozen.kind === "TAKE" ? "TAKE" : `SKIP:${frozen.code}`,
          shadowSit: shadowClass.shadowSit,
          protectedCheapNo: shadowClass.protectedCheapNo,
          protectedCheapYes: shadowClass.protectedCheapYes,
          baseEligible: shadowClass.baseEligible,
          quoteFresh: true,
          spread: shadow.spreadCents ?? null,
          reason: shadowClass.reason,
        });
        void YES_40_55_PIN_SHADOW_V1;
      } catch { /* observe-only */ }
      this.lastStrategyResult = ccResult && ccResult.signal !== "STAY_OUT" ? ccResult : stratResult;

      if (frozen.kind === "SKIP") {
        this.lastSignalDesc = `[FROZEN_CC] ${frozen.code}: ${frozen.reason}`;
        // Card honesty: hard frozen SKIP (incl. AND_SIT) must never leave TAKE painted.
        // FROZEN_CC_NOT_FIRED skips skip() below — still demote here.
        if (this.lastMoneyGateCard?.approved === true) {
          this.lastMoneyGateCard = demoteMoneyGateCardToSit(
            this.lastMoneyGateCard,
            frozen.code,
          );
        }
        // Silence the per-tick "CC did not fire" row — it is the normal state
        // and would drown the decision table. Every other frozen skip persists.
        if (frozen.code !== "FROZEN_CC_NOT_FIRED") {
          skip(frozen.code, [frozen.reason], {
            ticker,
            side: frozen.side ?? (mtfScore < 0 ? "no" : "yes"),
            strategyId: FROZEN_CC_STRATEGY_ID,
            entryPriceCents: frozen.ask ?? 0,
            confidence: ccResult?.confidence ?? 0,
            secsRemaining: secs,
            floorStrike,
          });
        }
        return;
      }

      // Side-specific shadow flags that need the chosen side (organ: enrichFrozenShadowPostTake).
      const ccVel = ccVelocityAgainstGate({
        strategyId: FROZEN_CC_STRATEGY_ID, side: frozen.side, velocityDolPerMin: this.currentVelocity,
      });
      let htfBias: string | null = null;
      try {
        htfBias = computeLiveHtfStructure(currentPrice).sideBias;
      } catch { htfBias = null; }
      const rawBidFrozen = frozen.side === "yes" ? yesBid : noBid;
      shadow = enrichFrozenShadowPostTake({
        shadow,
        side: frozen.side,
        ask: frozen.ask,
        ccVelocityWouldBlock: ccVel.block ? (ccVel.reason ?? "CC_VEL_AGAINST") : null,
        htfSideBias: htfBias,
        bidCents: typeof rawBidFrozen === "number" && Number.isFinite(rawBidFrozen) ? rawBidFrozen : null,
      });

      this.lastSignalDesc = formatFrozenCcTakeDesc({
        side: frozen.side, ask: frozen.ask, p: frozen.p, ev: frozen.ev,
        secs, mtfScore, shadow,
      });
      this.log("info", `🧊 ${this.lastSignalDesc}`);
      this.pendingFrozenFill = { shadow, p: frozen.p, ev: frozen.ev, entryShadowDecisionId, shadowSit: entryShadowSit, protectedCheapNo: entryShadowProtectedCheapNo, protectedCheapYes: entryShadowProtectedCheapYes };
      await this.placeOrder({
        signal: frozen.side === "yes" ? "LONG" : "SHORT",
        side: frozen.side,
        entryPrice: frozen.ask,
        floorStrike,
        ticker,
        confidence: Math.round(frozen.confidence * 100),
        secs,
        strategyWinRate: frozen.p,
        strategyId: FROZEN_CC_STRATEGY_ID,
        grokRegime,
        detailedRegime: regime,
        velocityDolPerMin: obs.velocityDolPerMin,
        spreadCents: shadow.spreadCents ?? undefined,
        decisionAskCents: frozen.ask,
        traceId,
        frozenCc: true,
      });
      this.pendingFrozenFill = null;
      return;
    }

    // W2 SKIP vetoes CC/LAG TAKE only (hard gates). ha_disagree / pin_reachable
    // are tag-only. When aligned already SKIP (e.g. opposed_side), do NOT re-kill
    // via ask_out_of_band on the rich MTF wing — let MTF_FILTER own that skip.
    if (alignedGate.kind === "TAKE" && w2Lock.kind === "SKIP" && preW2 && preW2.signal !== "STAY_OUT") {
      const lsWhy = w2Lock.log.lockSide_why ?? w2Lock.log.lockSide?.why ?? null;
      const skipLabel = lsWhy && lsWhy !== w2Lock.reason
        ? `${w2Lock.reason}|lockSide.why=${lsWhy}`
        : w2Lock.reason;
      skip(skipLabel, [
        `W2 veto ${w2Lock.reason}` +
          (lsWhy ? ` lockSide.why=${lsWhy}` : "") +
          ` lockSide.result=${w2Lock.log.lockSide?.result ?? "SKIP"} — admission side lock (strike not analog)`,
      ], {
        ticker,
        side: preW2.signal === "YES" ? "yes" : "no",
        strategyId: preW2.strategyId,
        entryPriceCents: preW2.signal === "YES" ? yesAsk : noAsk,
        confidence: preW2.confidence,
        secsRemaining: secs,
        floorStrike,
      });
      // Hard W2 veto already explained the empty select — do not also stamp
      // NO_ELIGIBLE_STRATEGY on a CC/LAG that evaluate() already fired.
      this.lastStrategyResult = stratResult;
      return;
    }

    // ── Condition-suppression fail-safe: REMOVED (GO — STEP 3, 2026-08-22) ──
    // This used to retry with condOverlay.suppressStrategies excluded from
    // the disabled set whenever the first pass came back empty (Task #355).
    // Now that condOverlay.suppressStrategies is no longer folded into
    // condEff.disabledStrategies at all (see the assembly above — packs are
    // the sole eligibility allowlist), `nonConditionDisabled` would always be
    // byte-identical to `condEff.disabledStrategies` and `stratResult` would
    // always already equal `fallback` — a dual router computing the same
    // answer twice. Deleted rather than left as silent dead code.
    this.lastStrategyResult = stratResult;

    if (!stratResult) {
      // Distinguish user-disabled pools from all other upstream eligibility
      // filters. Session and specialist-pack restrictions can also empty this
      // pool, so do not mislabel every no-candidate result as a regime block.
      const userDisabled = effectiveDisabledStrategies(this.config);
      const allPoolIds   = boostedPool.map(r => r.strategyId);
      const allDisabledByUser = allPoolIds.length > 0
        && allPoolIds.every(id => userDisabled.includes(id));
      if (allDisabledByUser) {
        this.lastSignalDesc = `[${grokRegime}] All strategies disabled — re-enable one to resume`;
      } else {
        this.lastSignalDesc = `[${grokRegime}] No eligible strategy this tick — STAY OUT`;
      }
      if (sessionMode === "HARVEST" && trendFilteredPool.some(r => r.signal !== "STAY_OUT")
          && sessionFilteredPool.length === 0) {
        const sessionCandidate = trendFilteredPool.find(r => r.signal !== "STAY_OUT");
        if (sessionCandidate) {
          skip("SESSION_FILTER", [
            `[HARVEST] all directional candidates were removed by the session family filter`,
          ], {
            ticker,
            side: sessionCandidate.signal === "YES" ? "yes" : "no",
            strategyId: sessionCandidate.strategyId,
            entryPriceCents: sessionCandidate.signal === "YES" ? yesAsk : noAsk,
            confidence: sessionCandidate.confidence,
            secsRemaining: secs,
            floorStrike,
          });
        }
      } else {
        // Early reinject already ran before W2. If still empty here, hard gates
        // (aligned/W2) owned the miss — do NOT SELECT_MISS_CC_LAG starve (104/hr).
        // Only NO_ELIGIBLE when no CC/LAG fire exists to recover.
        const moneyCand = findMoneyCandSelectMiss(sessionFilteredPool);
        const noCandidate = moneyCand
          ?? sessionFilteredPool.find(r => r.signal !== "STAY_OUT")
          ?? boostedPool.find(r => r.signal !== "STAY_OUT");
        if (moneyCand) {
          this.log("info",
            `SELECT_MISS_GATED ${moneyCand.strategyId} ${moneyCand.signal} — moneyCand present but aligned/W2 cleared ticket (not SELECT_MISS starve)`
          );
        } else if (noCandidate) {
          skip("NO_ELIGIBLE_STRATEGY", [this.lastSignalDesc], {
            ticker,
            side: noCandidate.signal === "YES" ? "yes" : "no",
            strategyId: noCandidate.strategyId,
            entryPriceCents: noCandidate.signal === "YES" ? yesAsk : noAsk,
            confidence: noCandidate.confidence,
            secsRemaining: secs,
            floorStrike,
          });
        }
      }
      // Card honesty: STAY OUT / empty select must never leave TAKE painted.
      if (!stratResult) {
        if (this.lastMoneyGateCard?.approved === true) {
          this.lastMoneyGateCard = demoteMoneyGateCardToSit(
            this.lastMoneyGateCard,
            "NO_ELIGIBLE_STRATEGY",
          );
        }
        return;
      }
    }

    // ── MIXED consensus + small equity → STAY OUT (REMOVED 2026-08-06) ────────
    // This used to hard-block any MIXED-consensus signal below $50 equity
    // (Grok finding #10). On accounts in the $10-$50 range it ended up
    // blocking almost every signal, not just the marginal ones it was meant
    // to catch. Removed at user request; PATH_GATE and the EV floors
    // (unchanged) still gate trade quality independent of consensus type.

    // ── Apply learning weight ─────────────────────────────────────────────────
    // autoMode ON: BOT fills only, clamped 0.72–1.18x. Sim/shadow (perfConfMult)
    // is not mixed in. autoMode OFF: keep the existing learner × sim multiplier.
    const learningWeights = getBotFillLearningWeights(15);
    const botFillWeights = getBotFillLearningWeights(15);
    const lw = this.config.autoMode
      ? applyBotFillLearning(botFillWeights[stratResult.strategyId], stratResult.strategyId in botFillWeights)
      : (learningWeights[stratResult.strategyId] ?? 1.0);
    const perfConfMult = this.config.autoMode
      ? 1
      : getStrategyMultipliersSync(stratResult.strategyId).conf;
    const adjustedConf = Math.min(0.94, stratResult.confidence * lw * perfConfMult);
    const boostedStratResult = { ...stratResult, confidence: adjustedConf };

    const signal:    "LONG" | "SHORT" = boostedStratResult.signal === 'YES' ? 'LONG' : 'SHORT';
    let side:      "yes" | "no"     = signal === "LONG" ? "yes" : "no";
    // P5: analog names SIDE only. Band the ALIGNED ask (not YES 92 while NO is 32).
    if (isMoneyMakerStrategyId(boostedStratResult.strategyId)) {
      const alignedBand = isMtfAlignedCheapTake({
        mtfScore: obs.mtfScore,
        yesAsk,
        noAsk,
        minAskCents: boostedStratResult.strategyId === "BASIS_LAG_EDGE" ? 20 : 28,
        spot: currentPrice,
        floorStrike,
      });
      if (alignedBand) side = alignedBand.side;
    }

    // Streak-saturation CONTEXT — one source of truth (conf + skip).
    // Fail-closed: missing sat / unknown sample → NEUTRAL. Do not invent.
    // Soft prior: allTimeMax is not a ceiling. Prefer skip WITH over naked fade.
    const satCtx = this.evaluateLiveStreakSat(side, obs, currentPrice);
    this.lastStreakSatDecision = satCtx;

    // autoMode ADAPTATION: skip more when Coinbase lag is FRESH and disagrees
    // with the selected side. Stale lag is unknown, not a lie — BASIS_LAG
    // already fail-closes itself. CONFLUENCE_CASCADE is never TAPE_LIE starved.
    if (this.config.autoMode) {
      const agrees = lagAgreesWithSide(side, obs.lagDollars ?? null, {
        proven: obs.lagProven === true,
        stale: obs.lagStale !== false,
      });
      if (freshLagDisagreeSkip({
        autoMode: true,
        lagStale: obs.lagStale,
        agreesWithSide: agrees,
        strategyId: boostedStratResult.strategyId,
      })) {
        this.lastSignalDesc = "[adapter] skip LAG_AGAINST";
        skip("TAPE_LIE", ["LAG_AGAINST"], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: side === "yes" ? yesAsk : noAsk, confidence: adjustedConf,
          secsRemaining: secs, floorStrike,
        });
        return;
      }
    }

    // ── OTM flag: Asymmetry Hunter or Deep OTM Sniper ────────────────────────
    // Both bypass the normal 30–62¢ price range and use Kelly-based OTM sizing.
    // DEEP_OTM_SNIPER additionally enforces a 14¢ ceiling (higher multipliers only).
    const isOTMSetup = boostedStratResult.strategyId === 'OTM_ASYMMETRY'
                    || boostedStratResult.strategyId === 'DEEP_OTM_SNIPER';

    // ── THESIS_BREAK_EXIT same-ticker re-entry cooldown (2026-08-14) ──────────
    // checkThesisBreak() just decided the thesis on THIS ticker was broken and
    // exited — re-opening the same contract seconds later on a fresh signal
    // would just be re-fighting the same broken thesis. Unconditional across
    // every setup type (checked before the OTM/non-OTM split), like the ARIA
    // DANGER veto below it.
    if (this.thesisBreakCooldownTicker === ticker && Date.now() < this.thesisBreakCooldownUntil) {
      const remainingMs = this.thesisBreakCooldownUntil - Date.now();
      this.lastSignalDesc = `${boostedStratResult.strategyName} · THESIS_BREAK cooldown (${Math.ceil(remainingMs / 1000)}s left)`;
      skip("THESIS_BREAK_COOLDOWN", [`re-entry cooldown ${Math.ceil(remainingMs / 1000)}s left`], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: side === 'yes' ? yesAsk : noAsk, confidence: adjustedConf, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── Regime-conditional EV filter (Grok upgrade #1) ────────────────────────
    // Skip strategies whose expected value is structurally negative in the
    // current regime — even when confidence passes the threshold. A -0.10
    // buffer avoids over-filtering genuinely borderline setups.
    {
      const entryPriceEV = side === 'yes' ? yesAsk : noAsk;
      const regimeStratMeta = getAllStrategyMeta().find(s => s.id === boostedStratResult.strategyId);
      const regimeWinRate = regimeStratMeta?.winRateAtPrice
        ? regimeStratMeta.winRateAtPrice(entryPriceEV, secs / 60)
        : regimeStratMeta?.expectedWinRate ?? 0.65;
      const stratEV      = scoreStrategyEV(
        boostedStratResult, obs, entryPriceEV, regimeWinRate,
      );
      // Require non-negative regime-adjusted EV. The old -0.10 allowance
      // knowingly admitted negative-EV setups on the theory that later gates
      // would catch them — a gate that accepts losses is not a gate.
      // Grok overlay #1 starved the +$50 path: 9k+ REGIME_EV_FILTER skips
      // on CONFLUENCE_CASCADE / BASIS_LAG_EDGE (even strong_uptrend).
      // Paper = live brain: do not skip-return those two here. Later EV 3¢ /
      // PATH_GATE / FULLY_PRICED / TIME / quote_stale still decide money.
      const moneyMaker =
        boostedStratResult.strategyId === "CONFLUENCE_CASCADE"
        || boostedStratResult.strategyId === "BASIS_LAG_EDGE";
      if (stratEV <= 0 && !moneyMaker) {
        this.lastSignalDesc =
          `[${regime}] ${boostedStratResult.strategyName}: EV ${stratEV.toFixed(2)} — hostile regime, skip`;
        // Profit Doctrine Phase 3: stratEV above is a dimensionless regime
        // score, not a cents figure — compute the same fee/slippage-aware
        // cents EV the EV floor gates use, purely for trace observability
        // (this never feeds back into the stratEV<0 decision above).
        const regimeEvFilterNetEV = computeTradeEV({
          entryPriceCents:   entryPriceEV,
          winRate:           regimeWinRate,
          secsRemaining:     secs,
          velocityDolPerMin: obs.velocityDolPerMin,
        }).netEV;
        const regimeEvFilterVol = computeVolumeScore(obs);
        skip("REGIME_EV_FILTER", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPriceEV, confidence: boostedStratResult.confidence,
          secsRemaining: secs, floorStrike, netEVcents: regimeEvFilterNetEV,
          volumeScoreV: regimeEvFilterVol.V, volumeBucket: regimeEvFilterVol.bucket,
        });
        return;
      }
    }

    // ── Fast-market classification ────────────────────────────────────────────
    // A "fresh spike" is high 1-min velocity that the 3-min average hasn't
    // confirmed — the move just started and reversals are most violent here.
    // "Sustained momentum" means both timeframes agree — safer to chase.
    const absV  = Math.abs(v);
    const absV3 = Math.abs(v3);
    const sameDir = Math.sign(v) === Math.sign(v3);
    const fastMarket        = absV > FAST_VEL;
    const sustainedMomentum = fastMarket && absV3 >= SUSTAINED_V3 && sameDir;
    const freshSpike        = fastMarket && !sustainedMomentum;

    // Naked velocity tip-entries are not confluence. Skip FRESH_SPIKE in BOTH
    // modes so paper proves live — a 1-min spike the 3-min average has not
    // confirmed is the most violent reversal window, paper or live.
    // CONFLUENCE already requires ≥3 aligned factors (v3 is one of them);
    // BASIS_LAG is a persist-streak lag book, not a velocity chase. Exempt
    // those two so this later preserver cannot starve the live +$50 take cell.
    if (freshSpike) {
      const moneyMakerTake =
        boostedStratResult.strategyId === "CONFLUENCE_CASCADE" ||
        boostedStratResult.strategyId === "BASIS_LAG_EDGE";
      if (!moneyMakerTake) {
        this.lastSignalDesc =
          `${stratResult.strategyName}: fresh spike (${v.toFixed(0)} $/min, v3=${v3.toFixed(0)}) — waiting for confirmation`;
        skip("FRESH_SPIKE", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: side === "yes" ? yesAsk : noAsk,
          confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
    }

    // Always add at least 1¢ sweep so the limit order sits above the ask and
    // crosses the spread immediately. Without this, placing exactly at the ask
    // leaves us below Kalshi's actual offer depth and the order sits unfilled.
    // In sustained fast markets add the full SWEEP_PREMIUM (2¢) to stay ahead
    // of a moving book.
    const rawAsk   = side === "yes" ? yesAsk : noAsk;
    const rawBid   = side === "yes" ? yesBid : noBid;
    const sweep    = sustainedMomentum ? SWEEP_PREMIUM : 1;

    // ── Bid-ask spread filter ─────────────────────────────────────────────────
    // A spread > 12¢ signals thin order-book depth: fills are bad, the effective
    // entry cost is far from mid, and exit liquidity will be poor too.
    // Normal Kalshi 15-min BTC spreads are 2–6¢; anything above 12¢ is abnormal.
    const sideSpread = rawAsk - rawBid;
    // A crossed book (bid > ask, sideSpread < 0) is corrupted/stale data —
    // e.g. a transient WS/REST desync during rollover.
    //
    // 2026-08-05 bug fix #2: this used to reject sideSpread === 0 as
    // "crossed" too. A LOCKED market (bid == ask, zero-width spread) is not
    // corrupted — it's a real, valid, thin-book state that happens often in
    // the last few minutes before settlement when the resting quote
    // converges to one price. It's actually the BEST possible fill (buying
    // at the ask costs nothing extra vs. the bid), so gating it out was pure
    // lost opportunity, not a safety measure. Confirmed live: 5 LATE_ENTRY_
    // ANCHOR setups (94-97% confidence) were skipped this way within 2 hours
    // of the stale/fresh-mixing fix above, each logged as "spread 0¢" —
    // proving they were locked markets, not negative-spread corruption.
    // Only a genuinely negative spread (bid > ask) is still treated as bad data.
    if (sideSpread < 0 || sideSpread > 12) {
      this.lastSignalDesc = sideSpread < 0
        ? `${stratResult.strategyName}: crossed book (bid>ask, spread ${sideSpread.toFixed(0)}¢) — corrupted quote, skip`
        : `${stratResult.strategyName}: spread ${sideSpread.toFixed(0)}¢ > 12¢ — illiquid, skip`;
      skip("SPREAD_GATE", [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── Entry price gates (OTM vs normal path) ───────────────────────────────
    //
    // getEntryPriceBand() is the SAME authoritative resolver both backtest
    // engines call (Task #368) — this live gate and the simulations can never
    // silently drift apart again. For OTM strategies it returns their fixed
    // research-backed sweet spot regardless of the effective standard band;
    // for the normal path it returns the current ARIA/adaptive-condition-
    // adjusted eff.minEntryPrice/maxEntryPrice, so live still respects dynamic
    // overrides (backtests fall back to the static default since they don't
    // replay that per-tick overlay stack — see EntryPriceBandOptions).
    const entryBand = getEntryPriceBand(boostedStratResult.strategyId, {
      effectiveMin: eff.minEntryPrice,
      effectiveMax: eff.maxEntryPrice,
      side,
      effectiveMinNo: 22, // PAPER DESK v2 NO floor
    });

    const distPct = floorStrike > 0 ? ((currentPrice - floorStrike) / floorStrike) * 100 : 0;

    if (isOTMSetup) {
      // OTM Asymmetry Hunter: the entire point is that the market is pricing
      // our side at 5–25¢ (or 5–14¢ for the Sniper) — those are the entries we
      // want. No BSM fair-value gate for OTM: Black-Scholes assumes no
      // directional drift and wildly underprices OTM contracts in trending
      // markets. No distance-to-strike block: OTM setups REQUIRE being away
      // from floor.
      if (!(rawAsk >= entryBand.min) || rawAsk > entryBand.max) {
        this.lastSignalDesc =
          `${stratResult.strategyName}: ask ${rawAsk}¢ outside OTM sweet-spot (${entryBand.min}–${entryBand.max}¢) — skip`;
        skip("ENTRY_PRICE_BAND", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
    } else {
      // ── Normal: market plausibility gate ──────────────────────────────────
      // If the market prices our side below minEntryPrice, BTC is far from
      // the strike and the market consensus is >70% against us.
      if (!(rawAsk >= entryBand.min)) {
        this.lastSignalDesc =
          `${stratResult.strategyName}: market implies ${rawAsk}¢ ${side.toUpperCase()} — too far OTM (min ${entryBand.min}¢)`;
        skip("ENTRY_PRICE_BAND", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }

      // ── Normal: hard max cap ────────────────────────────────────────────
      if (rawAsk > entryBand.max) {
        this.lastSignalDesc =
          `${stratResult.strategyName}: ask ${rawAsk}¢ > maxEntryPrice ${entryBand.max}¢ — skip (unfillable limit)`;
        skip("ENTRY_PRICE_BAND", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }

      // ── Normal: distance-to-strike sanity ──────────────────────────────
      // Analog (next close vs last) names SIDE only. Kalshi pays strike.
      // After ENTRY on aligned cheap NO 28–55, do NOT skip-NO / force-YES
      // because spot>strike / aboveFloor / distFromFloorPct. KEEP 8¢ lottery.
      const alignedCheapTake = isMoneyMakerStrategyId(boostedStratResult.strategyId)
        && isMtfAlignedCheapTake({
          mtfScore: obs.mtfScore,
          yesAsk,
          noAsk,
          minAskCents: boostedStratResult.strategyId === "BASIS_LAG_EDGE" ? 20 : 28,
          spot: currentPrice,
          floorStrike,
        });
      if (!alignedCheapTake && side === "yes" && distPct < -0.5) {
        this.lastSignalDesc =
          `${stratResult.strategyName}: BTC ${distPct.toFixed(2)}% below strike — YES blocked`;
        skip("ENTRY_PRICE_BAND", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
      if (!alignedCheapTake && side === "no" && distPct > 0.5) {
        this.lastSignalDesc =
          `${stratResult.strategyName}: BTC ${distPct.toFixed(2)}% above strike — NO blocked`;
        skip("ENTRY_PRICE_BAND", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
    }

    // Compute entry price: ask + sweep.
    // For OTM, no sweep — at 8¢ even 1¢ sweep is a 12% premium; just hit the ask.
    // Paper≡live (2026-09-11): planMakerEntry fail-closed both modes — no paper REST privilege.
    let entryPrice = isOTMSetup ? rawAsk : rawAsk + sweep;
    let makerEntry = false;
    if (isMoneyMakerStrategyId(boostedStratResult.strategyId)) {
      const maker = planMakerEntry({
        paperMode: this.config.paperMode === true,
        strategyId: boostedStratResult.strategyId,
        side,
        bothSides: false,
        ev: this.lastOrganReport?.ev ?? null,
        yesAsk, noAsk, yesBid, noBid,
        secsRemaining: secs,
        maxEntryCents: 62,
      });
      if (maker.action === "REST" && maker.limitCents != null) {
        entryPrice = maker.limitCents;
        makerEntry = true;
      }
    }

    // Fill-power still-mid HARD: executable limit (ask+sweep / maker) must not
    // land in 48–52. Aligned/W2 gate the raw ask; sweep +1/+2 from 46–47 was a leak.
    if (!isOTMSetup && (inStillMidCoinFlip(entryPrice) || sweptFillHitsStillMid(rawAsk, sweep))) {
      this.lastSignalDesc =
        `${stratResult.strategyName}: fill ${entryPrice}¢ still-mid 48–52 (rawAsk ${rawAsk}¢) — skip`;
      skip(STILL_MID_UNCLEAR_SKIP, [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: entryPrice, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }

    if (!isOTMSetup && entryPrice > entryBand.max) {
      this.lastSignalDesc =
        `${stratResult.strategyName}: ask ${rawAsk}¢ + sweep ${sweep}¢ = ${entryPrice}¢ > maxEntryPrice ${entryBand.max}¢ — skip`;
      skip("ENTRY_PRICE_BAND", [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: entryPrice, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── Universal price-band gate (master bot upgrade step 2) ─────────────────
    // A second, strategy-agnostic gate layered on top of the per-strategy band
    // just enforced above: it screens by how expensive the ask itself is,
    // regardless of which strategy's band it already cleared. ≤45¢ trades
    // full size, 46-55¢ standard, 56-70¢ half size (unless a late-anchor/lag
    // strategy shows a genuinely extreme, fresh fair-value displacement),
    // >70¢ is skipped outright unless that same exception holds AND time is
    // almost up — in which case it falls through to the EV_PRE_CHECK/PATH_GATE
    // below, which still have final say on whether the EV actually clears.
    const priceBandDisplacementPct = obs.fairDistFromFloorPct ?? distPct;
    const priceBand = getUniversalPriceBandTier({
      askCents: rawAsk,
      strategyId: boostedStratResult.strategyId,
      displacementPct: priceBandDisplacementPct,
      minsLeft: secs / 60,
    });
    if (priceBand.tier === 'skip' && !priceBand.exceptionApplied) {
      this.lastSignalDesc =
        `${stratResult.strategyName}: ask ${rawAsk}¢ > ${PRICE_BAND_HALF_MAX_CENTS}¢ universal price-band ceiling — skip`;
      skip("PRICE_BAND_SKIP", [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }
    const priceBandSizeMult = priceBand.sizeMult;
    if (priceBand.tier === 'half' && priceBandSizeMult < 1) {
      skip("PRICE_BAND_HALF", [
        `${stratResult.strategyName}: ask ${rawAsk}¢ in 56-70¢ tier — half size (no late-anchor exception)`
      ], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
      });
    } else if (priceBand.exceptionApplied) {
      this.log("info",
        `💲 Price-band exception: ${boostedStratResult.strategyId} ask ${rawAsk}¢ tier=${priceBand.tier} — ` +
        `late-anchor + extreme displacement (${priceBandDisplacementPct?.toFixed(2)}%) lifted the size/skip restriction`
      );
    }

    // ── RICH_ASK_BLOCK (Master Desk Order P3, S4 — shared with the 1h path) ───
    // Global admit-time rule, independent of and stricter than the universal
    // price-band's own late-anchor exception above: any ask ≥70¢ is blocked
    // unless (a) the lag/basis projection agrees with our side AND (b) the
    // fee/slippage-adjusted net EV clears this path's floor by an extra
    // margin (+3¢), not just the bare floor. An ask this rich bleeds on any
    // near-miss, so a plain pass of the ordinary EV floor is not enough here.
    // Now backed by the shared evaluateRichAskBlock() (trade-path.ts) that the
    // hourly path calls too — one implementation, kept at this exact position
    // in the 15m sequence (unchanged) since Phase-4 audited this ordering as
    // load-bearing relative to the cheap price-band/sweep gates above it.
    {
      const rabStratMeta = getAllStrategyMeta().find(s => s.id === boostedStratResult.strategyId);
      const rabFrozen = pWinAtPriceRejectingThinLearner(rabStratMeta?.winRateAtPrice, rabStratMeta?.expectedWinRate, entryPrice, secs / 60, {
        strategyId: boostedStratResult.strategyId,
        paperMode: this.config.paperMode === true,
      });
      const rabWinRate = isMoneyMakerStrategyId(boostedStratResult.strategyId)
        ? rabFrozen
        : (rabStratMeta?.winRateAtPrice
          ? rabStratMeta.winRateAtPrice(entryPrice, secs / 60)
          : rabStratMeta?.expectedWinRate ?? 0.65);
      if (rabWinRate == null) {
        this.lastSignalDesc = `${stratResult.strategyName}: p=winRateAtPrice missing for RICH_ASK — skip (not 0.65)`;
        skip("RICH_ASK_BLOCK", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
      const richAsk = evaluateRichAskBlock({
        askCents:          rawAsk,
        side,
        strategyId:        boostedStratResult.strategyId,
        entryPriceCents:   entryPrice,
        secsRemaining:     secs,
        winRate:           rabWinRate,
        velocityDolPerMin: obs.velocityDolPerMin,
        spreadCents:       sideSpread,
        projectedSettlementPrice: obs.projectedSettlementPrice ?? null,
        basisStreakCount:  obs.basisStreakCount,
        basisStreakSign:   obs.basisStreakSign,
      });
      if (richAsk.blocked) {
        this.lastSignalDesc = `${stratResult.strategyName}: ${richAsk.reason} — skip`;
        skip("RICH_ASK_BLOCK", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
          netEVcents: richAsk.netEV,
        });
        return;
      }
    }

    // ── HARVEST family re-assert + stricter ask ceiling ───────────────────────
    // SELECT_MISS_RECOVER / overlay can resurrect a non-harvest row after the
    // early session filter. Re-check family here before sizing/placeOrder.
    // Paper LAG is harvest-exempt; CC is not (#725). Ask ceiling reuses the
    // same extreme-displacement + <=5min-left exception as the universal
    // price band (PRICE_BAND_LATE_EXCEPTION_STRATEGIES) — addition, not instead.
    if (sessionMode === 'HARVEST' && !isHarvestFamily(boostedStratResult.strategyId)) {
      this.lastSignalDesc =
        `${stratResult.strategyName}: [HARVEST] ${boostedStratResult.strategyId} not harvest family after recover — skip`;
      skip("SESSION_FAMILY_SUPPRESSED", [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }
    if (sessionMode === 'HARVEST' && rawAsk > HARVEST_ASK_MAX_CENTS
        && !paperMoneyMakerHarvestExempt(this.config.paperMode, boostedStratResult.strategyId)) {
      const harvestHasExtremeDisplacement = priceBandDisplacementPct != null && Math.abs(priceBandDisplacementPct) >= PRICE_BAND_EXTREME_DISPLACEMENT_PCT;
      const harvestLateException = PRICE_BAND_LATE_EXCEPTION_STRATEGIES.has(boostedStratResult.strategyId)
        && harvestHasExtremeDisplacement && (secs / 60) <= PRICE_BAND_LATE_MAX_MINS_LEFT;
      if (!harvestLateException) {
        this.lastSignalDesc =
          `${stratResult.strategyName}: [HARVEST] ask ${rawAsk}¢ > ${HARVEST_ASK_MAX_CENTS}¢ HARVEST ceiling — skip`;
        skip("HARVEST_PRICE_BAND", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: rawAsk, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
        });
        return;
      }
    }
    // Flat 0.6× multiplier for every HARVEST-session trade that clears the
    // gates above; combined multiplicatively with the universal price-band
    // multiplier (never replaces it — a HARVEST trade at a half-tier ask is
    // still both discounted).
    const harvestSizeMult = sessionMode === 'HARVEST' ? HARVEST_SIZE_MULT : 1;

    // ── Stack size tiers: probe/standard/press (master bot upgrade step 4) ────
    // Sizes from the quality of the confirming signal stack, not confidence
    // alone. Purely a sizing adjustment on an already-approved trade — never
    // approves or blocks one; combined multiplicatively with priceBandMult/
    // harvestMult above at the same point in the sizing chain below.
    const wantSignal: 'YES' | 'NO' = side === 'yes' ? 'YES' : 'NO';
    const projAgreesWithSide = obs.projectedSettlementPrice != null
      && (obs.basisStreakCount ?? 0) >= 3
      && obs.basisStreakSign === (wantSignal === 'YES' ? 1 : -1);
    const projDisagreesWithSide = obs.projectedSettlementPrice != null
      && Math.sign(obs.projectedSettlementPrice - obs.floorStrike) === (wantSignal === 'YES' ? -1 : 1)
      && Math.sign(obs.projectedSettlementPrice - obs.floorStrike) !== 0;
    const harvestExceptionalStack = projAgreesWithSide
      && allResults.some(r => getStrategyFamily(r.strategyId) === 'late-displacement' && r.signal === wantSignal);
    const inPressCooldown = this.pressCooldownTicker === ticker && Date.now() < this.pressCooldownUntil;
    const stackPrimaryFamily = getStrategyFamily(boostedStratResult.strategyId) ?? 'unknown';
    const stackTierResult = computeStackTier({
      askCents: rawAsk,
      minsLeft: secs / 60,
      primaryFamily: stackPrimaryFamily,
      isLateWindowStrategy: PRICE_BAND_LATE_EXCEPTION_STRATEGIES.has(boostedStratResult.strategyId),
      askAboveStandardCeiling: rawAsk > PRICE_BAND_STANDARD_MAX_CENTS,
      projAgreesWithSide,
      projDisagreesWithSide,
      displacementPct: priceBandDisplacementPct,
      inPressCooldown,
      sessionMode,
      harvestExceptionalStack,
    });
    const sizeTier: SizeTier = stackTierResult.tier;
    const stackSizeMult = stackTierResult.sizeMult;
    if (sizeTier !== 'standard') {
      this.log("info", `📚 SIZE_TIER=${sizeTier} [${boostedStratResult.strategyId} @ ${rawAsk}¢]: ×${stackSizeMult} — ${stackTierResult.reasons.join('; ')}`);
    }

    // ── Early honesty check ───────────────────────────────────────────────────
    // As soon as the real entry price is known, ask the strategy's own
    // winRateAtPrice() curve (same function stratWinRate/Kelly rely on below)
    // whether this specific price+time combination is already net-EV-negative
    // after fee + dynamic slippage. If so, reject now — before the overpay
    // gate, MTF filter, pre-trade sim (8-check composite score), and ARIA
    // assessment (an LLM call) all run on a candidate that can never clear
    // PATH_GATE's positive EV floor anyway. This is intentionally a looser
    // bar than PATH_GATE itself (net EV < 0, vs PATH_GATE's per-path minimum
    // of +3 to +7¢) — it only screens out the obviously-hopeless case, never
    // a borderline one that PATH_GATE's fuller evaluation should still weigh.
    {
      const earlyStratMeta = getAllStrategyMeta().find(s => s.id === boostedStratResult.strategyId);
      const earlyFrozen = pWinAtPriceRejectingThinLearner(earlyStratMeta?.winRateAtPrice, earlyStratMeta?.expectedWinRate, entryPrice, secs / 60, {
        strategyId: boostedStratResult.strategyId,
        paperMode: this.config.paperMode === true,
      });
      const earlyWinRate = isMoneyMakerStrategyId(boostedStratResult.strategyId)
        ? earlyFrozen
        : (earlyStratMeta?.winRateAtPrice
          ? earlyStratMeta.winRateAtPrice(entryPrice, secs / 60)
          : earlyStratMeta?.expectedWinRate ?? 0.65);
      if (earlyWinRate == null) {
        this.lastSignalDesc = `${stratResult.strategyName}: p=winRateAtPrice missing — skip (not 0.65)`;
        skip("EV_PRE_CHECK", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPrice, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
          pWin: null,
        });
        return;
      }
      const earlyEV = computeTradeEV({
        entryPriceCents:    entryPrice,
        winRate:            earlyWinRate,
        secsRemaining:      secs,
        velocityDolPerMin:  obs.velocityDolPerMin,
        spreadCents:        sideSpread,
      });
      if (earlyEV.netEV < 0) {
        this.lastSignalDesc =
          `${stratResult.strategyName}: entry ${entryPrice}¢ already net-EV-negative ` +
          `(${earlyEV.netEV.toFixed(1)}¢ at winRateAtPrice ${(earlyWinRate * 100).toFixed(0)}%) — reject before further evaluation`;
        const evPreCheckVol = computeVolumeScore(obs);
        skip("EV_PRE_CHECK", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPrice, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
          pWin: earlyWinRate,
          netEVcents: earlyEV.netEV,
          volumeScoreV: evPreCheckVol.V, volumeBucket: evPreCheckVol.bucket,
        });
        return;
      }
    }

    // ── Fair-value overpay gate (normal path only) ────────────────────────────
    // BSM dramatically underprices OTM contracts in trending markets, so we skip
    // this gate for OTM_ASYMMETRY. Normal path: reject if paying too far over model.
    //
    // IMPORTANT: Black-Scholes is fundamentally unreliable for ultra-short (5-15 min)
    // binary options on BTC. The model assumes log-normal returns with annualized vol,
    // but real 15-min BTC movements are fat-tailed and much more volatile than BSM
    // predicts. The market is often MORE correct than our theoretical price.
    //
    // Fix: Use a dynamic overpay threshold based on time remaining and model confidence:
    // - With >8 mins left: BSM has more predictive value, use tighter 10¢ threshold
    // - With 3-8 mins left: BSM becomes unreliable, use 18¢ threshold
    // - With <3 mins left: BSM is essentially useless, skip the gate entirely
    // - Also skip if theorPrice is extreme (<10¢ or >90¢) - model is clearly wrong
    let theorSidePrice: number | null = null;
    if (!isOTMSetup && currentPrice > 0 && floorStrike > 0 && annualVol > 0 && minsLeft > 0) {
      // Live overpay theo: fair-value N(d2) path — no binaryCallPrice Math.max(1) floor.
      const theorYes = binaryCallFairValueCents(
        currentPrice, floorStrike, Math.max(0, minsLeft * 60), annualVol,
      );
      const sideFair = side === "yes" ? theorYes : complementaryFairValueCents(theorYes);
      theorSidePrice = sanitizeTheoCents(sideFair).theoCents;
    }

    // Dynamic overpay threshold based on time and model sanity ([10,90] via sanitize)
    const theorPriceIsSane = theorSidePrice !== null;
    const overpayThreshold = minsLeft > 8 ? 10 : minsLeft > 3 ? 18 : 999; // 999 = disabled

    if (theorPriceIsSane && entryPrice > theorSidePrice! + overpayThreshold) {
      // BSM remake starve on desk-door money cell (YES/NO 20–55). Original +$50
      // CC/LAG took cheap-to-mid asks; KEEP OVERPAY outside the door (ask>55).
      // Still-mid 48–52 is a separate SIT. paper=live. EV 3¢ still later. Not ENABLE.
      const ignoreOverpay = moneyMakerIgnoresOverpayGate(
        boostedStratResult.strategyId,
        entryPrice,
      );
      if (ignoreOverpay) {
        this.log("info",
          `[overpay_gate] BSM money-cell ${entryPrice}¢ not skip-returning ${boostedStratResult.strategyId}`,
        );
      } else {
      this.lastSignalDesc =
        `${stratResult.strategyName}: entry ${entryPrice}¢ > theoretical ${theorSidePrice!.toFixed(0)}¢ + ${overpayThreshold}¢ cap — overpaying, skip`;
      skip("OVERPAY_GATE", [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: entryPrice, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
      });
      return;
      }
    }

    // ── Streak saturation context (mean-reversion) ────────────────────────────
    // CONTEXT skip/bias like HTF_STRUCTURE. After side candidate, before
    // MTF/HTF. Rising breakPressure + WITH-streak → skipContinuation.
    // Fade TAKE only with confluence (still needs EV/Kelly). Past hist max is
    // a soft prior — never auto-fade harder / martingale. Friend anti-pattern:
    // 8→11 naked fades. Do NOT cut EV 3¢ / Kelly 0.60 / 9%.
    // Do NOT enable CONFLUENCE / hourly / perps. paperMode stays true.
    if (satCtx.skipContinuation) {
      this.lastSignalDesc = `STREAK_SATURATION: ${satCtx.reasons.join("; ")} — ${satCtx.displayLine ?? ""}`;
      skip("STREAK_SATURATION", [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: entryPrice, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── MTF filter gate ────────────────────────────────────────────────────────
    // OTM_ASYMMETRY already hard-requires MTF ≥3 (or ≤-3 for shorts) inside the
    // strategy's own evaluate() function, stricter than the static config
    // default of ±1/-1 — so under static config this gate is a no-op for OTM
    // (it already passed a tougher requirement to get a signal at all).
    // BUT ARIA's setup control can tighten minMTFScoreForLong/maxMTFScoreForShort
    // beyond ±3, and that tightening must still reach OTM setups — otherwise
    // ARIA's MTF control would silently do nothing for the entire OTM family.
    // We take the stricter of (OTM's own ±3 floor, eff's current value) so a
    // static/weaker eff never re-blocks an OTM trade, but an ARIA-tightened eff
    // still can.
    if (eff.useMTFFilter) {
      const { minLong: effMinLong, maxShort: effMaxShort } =
        otmAwareMTFThresholds(isOTMSetup, eff.minMTFScoreForLong, eff.maxMTFScoreForShort);

      // Composite lock wins. Fast 5m/15m cannot override a ≤−3 composite
      // to admit YES (or ≥+3 to admit NO). Fail-closed: not a new engine.
      const skipMtfFilter = (need: string) => {
        this.lastSignalDesc = `${stratResult.strategyName}: blocked by MTF bias (score=${mtfScore}, need${need})`;
        const mtfMeta = getAllStrategyMeta().find(st => st.id === boostedStratResult.strategyId);
        const mtfPWin = mtfMeta?.winRateAtPrice
          ? mtfMeta.winRateAtPrice(entryPrice, secs / 60)
          : mtfMeta?.expectedWinRate ?? 0.65;
        const mtfEv = computeTradeEV({
          entryPriceCents: entryPrice,
          winRate: mtfPWin,
          secsRemaining: secs,
          velocityDolPerMin: obs.velocityDolPerMin,
          spreadCents: sideSpread,
        }).netEV;
        skip("MTF_FILTER", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPrice, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
          pWin: mtfPWin,
          netEVcents: mtfEv,
        });
      };
      if (side === "yes" && !mtfCompositeLockAllowsSide(side, mtfScore, effMinLong, effMaxShort)) {
        skipMtfFilter(`≥${effMinLong}`);
        return;
      }
      if (side === "no" && !mtfCompositeLockAllowsSide(side, mtfScore, effMinLong, effMaxShort)) {
        skipMtfFilter(`≤${effMaxShort}`);
        return;
      }
    }

    // ── HTF structure context (channel / S&R) ─────────────────────────────────
    // CONTEXT for the 15m side/skip call. Not a strategy ENABLE. Must not
    // bypass EV/Kelly/9%/15% reserve/daily halt. Must not flip paperMode.
    // Must not ENABLE CONFLUENCE/SP/OTM/hourly. Stale HTF → UNKNOWN, do not
    // invent a side; 15m PATH/lag still apply downstream.
    {
      const htf = computeLiveHtfStructure(currentPrice);
      const velSide = velocitySideFromDollarsPerMin(this.currentVelocity);
      const lagDollars = this.lastBasisState?.lagDollars ?? null;
      const lagAgainst = htf.sideBias === "YES" ? !(typeof lagDollars === "number" && lagDollars > 0)
        : htf.sideBias === "NO" ? !(typeof lagDollars === "number" && lagDollars < 0)
        : false;
      const haRejection = (htf.haColor === "red" && htf.sideBias === "YES")
        || (htf.haColor === "green" && htf.sideBias === "NO");
      // EV_PRE_CHECK already passed if we reached here. Cheap ask 7–22¢ is
      // the mid-channel exception (persist-cheap stays OBSERVE; this is not ENABLE).
      const cheapSideEvClears = entryPrice >= 7 && entryPrice <= 22;
      const ctx = applyHtfStructureToSide({
        structure: htf,
        proposedSide: side,
        velocitySide: velSide,
        haRejection,
        lagAgainst,
        cheapSideEvClears,
      });
      if (ctx.action === "skip") {
        // Remake (2026-08-28 linreg 4h/1d). Original +$50 had MTF_FILTER,
        // not HTF_STRUCTURE. Same starve class as mtf_veto. paper=live
        // CC/LAG ignore via REMAKE_SETTLEMENT_SIDE_REASONS HTF_STRUCTURE.
        // MTF_FILTER LAG YES mtf<0 KEEP. quote_stale KEEP. EV/Kelly/9% later.
        const ignoreHtf = paperMoneyMakerIgnoresSettlementSideSkip(
          this.config.paperMode === true,
          boostedStratResult.strategyId,
          "HTF_STRUCTURE",
        );
        if (ignoreHtf) {
          this.log("info",
            `[htf_structure] later-preserver HTF_STRUCTURE ${ctx.reason} not applied to ${boostedStratResult.strategyId} (paper=live CC/LAG)`,
          );
        } else {
          this.lastSignalDesc = `HTF_STRUCTURE: ${ctx.reason} — ${htf.displayLine}`;
          skip("HTF_STRUCTURE", [this.lastSignalDesc], {
            ticker, side, strategyId: boostedStratResult.strategyId,
            entryPriceCents: entryPrice, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
          });
          return;
        }
      }
    }

    // Final range sanity (OTM has its own gate above — skip this check for it)
    // Paper≡live entry band (2026-09-11): no paperCheapPathRide below-min privilege.
    if (!isOTMSetup && (entryPrice < entryBand.min || entryPrice > entryBand.max)) {
      this.lastSignalDesc = `${stratResult.strategyName}: ${entryPrice}¢ out of range`;
      skip("ENTRY_PRICE_BAND", [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: entryPrice, confidence: boostedStratResult.confidence, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── Confidence score ───────────────────────────────────────────────────────
    // ×90 (was ×85): the old multiplier started every entry 15% below the
    // strategy's raw confidence, making the threshold very hard to reach via
    // bonuses alone and creating a persistent under-trading bias.
    let conf = Math.round(stratResult.confidence * 94);
    const confLog: string[] = [];

    // Base edge bonus (prob model) — `edge` is an unsigned magnitude
    // (|prob-0.5|*100), so it must only reward confidence when the model's
    // probability actually agrees with the side we're about to trade (prob>0.5
    // favors YES, prob<0.5 favors NO). Applying it unconditionally let a trade
    // AGAINST the model's own probability estimate (e.g. going NO while
    // prob=0.85 favors YES) still receive the maximum +12 confidence bonus.
    const edgeAligned = (side === "yes" && prob > 0.5) || (side === "no" && prob < 0.5);
    const edgeMagnitude = Math.min(12, edge * 1.0);
    const edgeBonus = edgeAligned ? edgeMagnitude : -edgeMagnitude;
    conf += edgeBonus;
    if (edgeBonus !== 0) confLog.push(`${edgeBonus > 0 ? '+' : ''}${edgeBonus}edge`);

    // Time remaining bonus — more time = more room for price to move in our favor
    // Early entries (>8 min left) get a small boost; late entries get none
    const timeBonus = secs > 480 ? 4 : secs > 360 ? 2 : 0;
    if (timeBonus > 0) { conf += timeBonus; confLog.push(`+${timeBonus}time`); }

    // Floor proximity bonus — when BTC is very close to floor, outcome is predictable
    // Within $20 of floor = high confidence zone for YES/NO decision
    const obsPrice  = obs.currentPrice ?? 0;
    const obsFloor  = obs.floorStrike  ?? 0;
    const floorDist = obsPrice && obsFloor ? Math.abs(obsPrice - obsFloor) : Infinity;
    if (floorDist < 20) {
      const proxBonus = floorDist < 10 ? 5 : 3;
      conf += proxBonus; confLog.push(`+${proxBonus}prox`);
    }

    // Velocity-direction alignment bonus — strong velocity matching our side
    const vel = obs.velocityDolPerMin ?? 0;
    const velAligned = (side === "yes" && vel > 5) || (side === "no" && vel < -5);
    if (velAligned) {
      const velBonus = Math.min(6, Math.floor(Math.abs(vel) / 3));
      if (velBonus > 0) { conf += velBonus; confLog.push(`+${velBonus}vel`); }
    }

    // Theoretical underprice bonus — when the market is underpricing our side
    // vs. the Black-Scholes model, we have genuine alpha: the contract is cheap
    // relative to fair value.  Each cent of underpricing adds 1 conf point (max +7).
    if (theorSidePrice !== null && theorSidePrice > entryPrice) {
      const underBonus = Math.min(7, Math.round(theorSidePrice - entryPrice));
      conf += underBonus;
      confLog.push(`+${underBonus}underprice`);
    }

    // Stall penalty
    if (stalling && stratResult.strategyId !== 'EXHAUSTION_ANCHOR') { conf -= 8; confLog.push('-8stall'); }

    // Loss cooldown REMOVED (Stellar 2026-09-10) — 2-loss velocity/conf cool-down gone.
    // consecutiveLosses still tracked for display / risk reports only.

    // MTF alignment bonus — trading WITH a meaningful MTF bias
    if (Math.abs(mtfScore) >= 2 &&
        ((side === "yes" && mtfScore > 0) || (side === "no" && mtfScore < 0))) {
      const mtfBonus = Math.min(10, Math.abs(mtfScore) * 3);
      conf += mtfBonus; confLog.push(`+${mtfBonus}mtf`);
    }

    // ── [NEW] Bounce-level bonus (Task #341) ────────────────────────────────
    // Reversal-capable strategies (CHANNEL_BOUNCE, MEAN_REVERSION_STRETCH,
    // BOLLINGER_BAND, FAKEOUT_FADE, VELOCITY_STALL_REVERSAL) are betting that
    // price turns around right here. If this exact price zone has a real,
    // recent history (>=2 same-direction bounces within 21 days) of turning
    // the SAME way this trade is betting, that is corroborating evidence —
    // boost-only, capped at +8, no penalty when history disagrees (see
    // bounce-level-tracker.ts header for the reasoning).
    if (isReversalCapable(stratResult.strategyId)) {
      const bounceBonus = getBounceConfidenceBonus(obsPrice, Date.now(), side);
      if (bounceBonus > 0) { conf += bounceBonus; confLog.push(`+${bounceBonus}bounce`); }
    }
    // ── [NEW] Velocity acceleration (requires useAcceleration=true) ────────────
    // Momentum BUILDING in trade direction → higher win probability.
    // Momentum FADING (fast but slowing) → danger zone — momentum exhausting.
    if (this.config.useAcceleration && this.velocityAccel !== 0) {
      const accelInDir = (side === "yes" && this.velocityAccel > 0) ||
                         (side === "no"  && this.velocityAccel < 0);
      if (accelInDir) {
        conf += ACCEL_CONF_BONUS; confLog.push(`+${ACCEL_CONF_BONUS}accel↑`);
      } else if (Math.abs(this.velocityAccel) > 10) {
        // Only penalise meaningful deceleration (>10 $/min change), not noise
        conf -= ACCEL_CONF_PENALTY; confLog.push(`-${ACCEL_CONF_PENALTY}accel↓`);
      }
    }

    // ── [NEW] Settlement streak — mean-reversion pressure ──────────────────────
    // After STREAK_FADE_THRESH consecutive same-direction settlements, the
    // statistical edge shifts. BTC 15m contracts show negative serial correlation
    // in extended runs — continuation gets harder, fades get easier.
    const streak = obs.settlementStreak ?? 0;
    if (Math.abs(streak) >= STREAK_FADE_THRESH) {
      const streakUp    = streak > 0;              // run of UPs
      const tradingWith = (side === "yes" && streakUp) || (side === "no" && !streakUp);
      if (tradingWith) {
        conf -= STREAK_CONF_PENALTY; confLog.push(`-${STREAK_CONF_PENALTY}streak${streak}`);
      } else {
        conf += STREAK_CONF_BONUS;  confLog.push(`+${STREAK_CONF_BONUS}fade_streak${streak}`);
      }
    }

    // ── Streak saturation — folded into streak-saturation.ts (one source) ────
    // Pressure-scaled ±0–6. Fade TAKE +, with-streak skip −. 0 without take/skip.
    if (satCtx.confAdj !== 0) {
      conf += satCtx.confAdj;
      const pressPct = Math.round(satCtx.breakPressure * 100);
      const tag = satCtx.confAdj > 0 ? "sat_fade" : "sat_with";
      confLog.push(`${satCtx.confAdj > 0 ? "+" : ""}${satCtx.confAdj}${tag}${pressPct}%`);
    }

    // Alternating pattern bonus: ABAB pattern → fade the last move with confidence
    if (obs.isAlternating) {
      const lastWasUp   = streak >= 0;  // streak=0 or positive means last settled UP
      const fadingLast  = (side === "yes" && !lastWasUp) || (side === "no" && lastWasUp);
      if (fadingLast) {
        conf += ALTERNATING_FADE_BONUS; confLog.push(`+${ALTERNATING_FADE_BONUS}alt_fade`);
      }
    }

    // ── [NEW] Regime clarity signal ────────────────────────────────────────────
    // Entering in a confirmed trend aligned with the signal → structural edge.
    // Entering in unclear/transitioning regime without strong signals → risk.
    const trendAligned =
      (grokRegime === 'trending') &&
      (( side === "yes" && (obs.velocityDolPerMin ?? 0) > 0) ||
       ( side === "no"  && (obs.velocityDolPerMin ?? 0) < 0));
    if (trendAligned) {
      conf += REGIME_TREND_CONF_BONUS; confLog.push(`+${REGIME_TREND_CONF_BONUS}trend`);
    } else if (grokRegime === 'low_vol') {
      // 'transitioning' removed: it's the fallback regime that fires on most
      // normal ticks, so penalising it created a blanket confidence tax on nearly
      // every entry. Only penalise genuine low-velocity markets.
      conf -= REGIME_UNCLEAR_CONF_PENALTY; confLog.push(`-${REGIME_UNCLEAR_CONF_PENALTY}lowvol`);
    }

    // ── Expert Agent adjustment ───────────────────────────────────────────────
    if (this.config.useExpertAgent) {
      const adj = expertAgent.getConfidenceAdjustment(side);
      if (adj !== 0) { conf += adj; confLog.push(`${adj > 0 ? "+" : ""}${adj}agent`); }
    }

    conf = Math.max(40, Math.min(95, conf));

    // ── Meta-label confidence pass ───────────────────────────────────────────
    // Structural discounts/bonuses that sit on top of all signal-level bonuses:
    // regime uncertainty, velocity disagreement, floor proximity, MTF alignment.
    {
      const metaConf = metaLabelConfidence(conf, obs, grokRegime, boostedStratResult.strategyId);
      if (metaConf !== conf) confLog.push(`→meta:${metaConf}`);
      conf = metaConf;
    }

    // ── Universal lag confidence adjustment (2026-08-14) ──────────────────────
    // Every strategy's confidence gets a small, symmetric nudge from the
    // exchange-led settlement projection — the same signal LATE_MOMENTUM_CONTINUATION
    // already applies to itself alone (±0.04/-0.05 on its own 0-1 scale), generalized
    // here to every trade at the equivalent magnitude on this 0-100 scale.
    // Skipped for BASIS_LAG_EDGE/LATE_MOMENTUM_CONTINUATION: they already embed this
    // exact signal into their own confidence, so applying it again here would
    // double-count. Requires a fresh (non-stale) projection — missing/stale lag
    // data is always a no-op, never a penalty.
    if (
      boostedStratResult.strategyId !== 'BASIS_LAG_EDGE' &&
      boostedStratResult.strategyId !== 'LATE_MOMENTUM_CONTINUATION' &&
      boostedStratResult.strategyId !== 'CHEAP_SIDE_15M' &&
      obs.projectedSettlementPrice !== undefined &&
      obs.floorStrike > 0 &&
      !basisTracker.isFairValueStale()
    ) {
      const projLong = obs.projectedSettlementPrice > obs.floorStrike;
      const sideLong = side === 'yes';
      const lagAdj   = projLong === sideLong ? 4 : -5;
      conf += lagAdj;
      confLog.push(`${lagAdj > 0 ? '+' : ''}${lagAdj}lag`);
      conf = Math.max(40, Math.min(95, conf));
    }

    // ── Pattern memory boost ──────────────────────────────────────────────────
    // Adjusts confidence ±0–15% based on 10,000-scenario historical sim results.
    // Only fires when the pattern has ≥25 samples; otherwise no-op.
    {
      const patBoost = getPatternBoost(obs, signal as 'YES' | 'NO');
      if (patBoost !== 1.0) {
        const adj = Math.round((patBoost - 1.0) * conf);
        if (adj !== 0) {
          conf = Math.max(40, Math.min(95, conf + adj));
          confLog.push(`${adj > 0 ? '+' : ''}${adj}pat[${fingerprintObs(obs)}]`);
        }
      }
    }

    // ── Market intelligence confidence adjustment ────────────────────────────
    // Session bias (London/NY +5, Asia -4, dead zone -5), RSI mean-reversion
    // alignment (±1–5 pts), VWAP deviation (±2–4 pts for reversion strategies),
    // and high-ATR volatility penalty (−1 to −3 pts).
    // Based on: quant session research, Wilder RSI, institutional VWAP anchoring.
    {
      const mi = computeMIAdjustment(obs, miData.sessionBias, boostedStratResult.strategyId, signal as 'YES' | 'NO');
      if (mi.adj !== 0 && mi.logParts.length > 0) {
        conf = Math.max(40, Math.min(95, conf + mi.adj));
        mi.logParts.forEach(p => confLog.push(p));
      }
    }

    // ── Spread tightness bonus ───────────────────────────────────────────────
    // Tight bid-ask spreads indicate high liquidity and better fill quality.
    // Bonus when spread ≤ 3¢, penalty when spread > 8¢.
    {
      const spread = Math.abs((obs.yesAsk ?? 50) - (obs.yesBid ?? 50));
      if (spread <= 2) { conf += 4; confLog.push('+4spread≤2'); }
      else if (spread <= 3) { conf += 2; confLog.push('+2spread≤3'); }
      else if (spread > 8) { conf -= 3; confLog.push('-3spread>8'); }
    }

    // ── Velocity consistency bonus ───────────────────────────────────────────
    // If velocity has been consistent in direction for the last few ticks,
    // confidence in trend continuation is higher.
    {
      const vel = obs.velocity ?? 0;
      const accel = obs.acceleration ?? 0;
      const sameDir = (vel > 0 && accel > 0) || (vel < 0 && accel < 0);
      const strongVel = Math.abs(vel) > 15;
      if (sameDir && strongVel) {
        // Velocity and acceleration aligned + strong movement
        const bonus = Math.min(5, Math.round(Math.abs(vel) / 10));
        if (bonus > 0) { conf += bonus; confLog.push(`+${bonus}velConsist`); }
      }
    }

    // ── Win streak momentum bonus ────────────────────────────────────────────
    // When on a winning streak, slightly boost confidence (hot hand effect).
    // When on losing streak, reduce confidence (cold hand caution).
    {
      const recentWins = this.todayStats.wins;
      const recentLosses = this.todayStats.losses;
      const totalRecent = recentWins + recentLosses;
      if (totalRecent >= 5) {
        const winRate = recentWins / totalRecent;
        if (winRate >= 0.7) { conf += 3; confLog.push('+3hotStreak'); }
        else if (winRate <= 0.3 && totalRecent >= 8) { conf -= 4; confLog.push('-4coldStreak'); }
      }
    }

    // ── Edge-price alignment bonus ───────────────────────────────────────────
    // When edge is high AND entry price is favorable (cheap YES or cheap NO),
    // this is a high-conviction setup.
    {
      const edgePct = (stratResult.edgePct ?? 0) * 100;
      const isCheapEntry = (side === 'yes' && entryPrice < 40) || (side === 'no' && entryPrice < 40);
      if (edgePct > 8 && isCheapEntry) {
        conf += 4;
        confLog.push('+4edgePrice');
      }
    }

    conf = Math.max(40, Math.min(95, conf));

    // ── Realized-outcome confidence calibration — DISABLED (see flag decl) ───
    // Gated OFF: the correction was a GLOBAL settlement-arrow accuracy number
    // being used to scale per-strategy trade confidence into Kelly sizing —
    // wrong quantity, not conditioned on strategy/duration/price, and
    // self-reinforcing. We still COMPUTE and LOG it (below) so the corrected
    // sim_verdicts-based measurement accumulates for a future valid version,
    // but it must not move money until CONFIDENCE_CALIBRATION_ENABLED is proven
    // safe out-of-sample. NEVER let this branch mutate `conf` while off.
    {
      const cal = predictionLearner.getConfidenceCorrection(conf / 100);
      if (cal.applied) {
        const wouldBe = Math.max(40, Math.min(95, Math.round(cal.corrected * 100)));
        this.log("info",
          `🎯 [calibration DISABLED] would adjust ${conf}% → ${wouldBe}% ` +
          `(realized-vs-claimed ${(cal.adjust * 100).toFixed(1)}pts) · ${stratResult.strategyName} · ` +
          `NOT applied (CONFIDENCE_CALIBRATION_ENABLED=false)`);
      }
      if (CONFIDENCE_CALIBRATION_ENABLED && cal.applied) {
        const before = conf;
        conf = Math.max(40, Math.min(95, Math.round(cal.corrected * 100)));
        if (conf !== before) {
          const delta = conf - before;
          confLog.push(`${delta > 0 ? '+' : ''}${delta}calib`);
        }
      }
    }

    // ── GO — VOLUME AS RISK SCALAR (NO HARD VOLUME VETO), 2026-08-18 ─────────
    // Thin volume never rejects a trade on its own: it only (a) nudges the
    // confidence bar up a little via confBump, applied as the LAST adjustment
    // to `conf` before the floor check below (so it's the actual number the
    // floor/EV/sizing all see downstream — no separate shadow variable), and
    // (b) shrinks size via volumeSizeMult, threaded into computeContracts()
    // below, multiplying AFTER uMult per the locked stack order. `volBucket`/
    // `volumeSizeMult` are declared in this function's outer scope so the
    // sizing call further down reuses the SAME per-tick score (a pure
    // function of `obs`, so computing it once here is equivalent to computing
    // it again there — this just avoids doing the work twice and guarantees
    // both sites agree). DEAD/LOW never remove BASIS_LAG_EDGE/other strategies
    // from the allowlist — that's a separate, unrelated allowlist decision
    // (strategy-library.ts enabledInRegimes) untouched by this scalar.
    const volScore = computeVolumeScore(obs);
    const volBucket = volScore.bucket;
    const volumeSizeMult = getVolumeSizeMult(boostedStratResult.strategyId, volBucket);
    const volPolicy = VOLUME_BUCKET_POLICY[volBucket];
    if (volPolicy.confBump > 0) {
      const before = conf;
      conf = Math.max(40, Math.min(95, conf - volPolicy.confBump));
      confLog.push(`-${volPolicy.confBump}vol[${volBucket}]`);
      void before;
    }
    this.log("info",
      `📶 [volume-risk] ${boostedStratResult.strategyId} V=${volScore.V.toFixed(3)} bucket=${volBucket} ` +
      `sizeMult=${volumeSizeMult.toFixed(3)} confBump=${volPolicy.confBump} ` +
      `(state=${volScore.components.volumeState ?? 'n/a'} stateScore=${volScore.components.stateScore.toFixed(2)} ` +
      `intensity=${volScore.components.intensityScore.toFixed(2)} range=${volScore.components.rangeScore.toFixed(2)} spread=${volScore.components.spreadScore.toFixed(2)})`
    );

    // GO — APPLY PACKS ENFORCE: pack.confBump RAISES this tick's effective
    // confidence floor when a pack is live — a stricter admission bar, never
    // a looser one. This is why implementing confBump live does not count as
    // "loosening EV/confidence" under the user's explicit STOP condition.
    const packConfFloor = computePackConfFloor(condEff.minConfidence, enforcedPack);
    // p = winRateAtPrice for ticket EV. Confidence is not p. Do not skip CC/LAG
    // on minConfidence when EV ≥ 3¢ and side agrees. Other strategies still floor.
    {
      const confFloorMeta = getAllStrategyMeta().find(s => s.id === boostedStratResult.strategyId);
      const confFloorP = pWinAtPriceRejectingThinLearner(confFloorMeta?.winRateAtPrice, confFloorMeta?.expectedWinRate, entryPrice, secs / 60, {
        strategyId: boostedStratResult.strategyId,
        paperMode: this.config.paperMode === true,
      });
      const confFloorEV = confFloorP != null
        ? ticketEVCentsFromP({
            entryPriceCents: entryPrice,
            pWin: confFloorP,
            strategyId: boostedStratResult.strategyId,
            secsRemaining: secs,
            velocityDolPerMin: obs.velocityDolPerMin,
            spreadCents: sideSpread,
          })
        : null;
      const confFloorSideAgrees = resolveMoneyMakerConfFloorSideAgree({
        strategyId: boostedStratResult.strategyId,
        side,
        obs,
      });
      if (shouldSkipConfidenceFloor({
        strategyId: boostedStratResult.strategyId,
        confidence: conf,
        minConfidence: packConfFloor,
        ticketEVCents: confFloorEV,
        sideAgrees: confFloorSideAgrees,
      })) {
        this.lastSignalDesc = enforcedPack
          ? `${stratResult.strategyName} (${Math.round(conf)}%) — below pack-adjusted threshold ${packConfFloor}% [${enforcedPack.id}, base ${condEff.minConfidence}%+${enforcedPack.confBump}]`
          : `${stratResult.strategyName} (${Math.round(conf)}%) — below threshold [${adaptiveResult.condition}]`;
        skip("CONFIDENCE_FLOOR", [this.lastSignalDesc], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
          pWin: confFloorP, netEVcents: confFloorEV ?? undefined,
        });
        return;
      }
    }

    // ── Protect mode (target hit, 'reduced' behavior): A+ setups only ────────
    // The daily target engine never loosens gates; in protect mode it TIGHTENS
    // them — after the +target% is banked, only high-conviction setups qualify.
    if (this.lastDailyTarget?.protectActive && conf < 75) {
      this.lastSignalDesc = `Protect mode — ${stratResult.strategyName} (${Math.round(conf)}%) below A+ bar (75%)`;
      skip("PROTECT_MODE", [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── Hard entry filters (Grok) ─────────────────────────────────────────────
    if (!passesHardFilters(secs, obs, stratResult, channelInfo ?? null, grokRegime)) {
      this.lastSignalDesc = `${stratResult.strategyName}: blocked by hard entry filter [${grokRegime}]`;
      skip("HARD_ENTRY_FILTER", [this.lastSignalDesc], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── EV floor gate ────────────────────────────────────────────────────────
    // Require EV ≥ 0.03 (was 0.05, temporary relaxation 2026-08-03) after
    // payout-ratio arithmetic. Secondary check on top of the regime-modifier
    // scoreStrategyEV filter.
    //
    // Task #397: uses the same calibrated winRateAtPrice()/expectedWinRate
    // estimate the early honesty check above (and placeOrder's own EV gates /
    // Kelly sizing downstream) resolve for this exact strategy+price+time —
    // not the fully-adjusted signal confidence. Confidence is a meta-labeled
    // heuristic score, not a win probability, so using it here let this gate
    // diverge from PATH_GATE's own EV floor on a different number for the
    // same trade. Recomputed here (rather than reusing the early check's
    // block-scoped local) because entryPrice/secs can still be refined by
    // gates between the two checks; winRateAtPrice() is a cheap pure lookup.
    {
      const evGateStratMeta = getAllStrategyMeta().find(s => s.id === boostedStratResult.strategyId);
      const evGateWinRate = pWinAtPriceRejectingThinLearner(evGateStratMeta?.winRateAtPrice, evGateStratMeta?.expectedWinRate, entryPrice, secs / 60, {
        strategyId: boostedStratResult.strategyId,
        paperMode: this.config.paperMode === true,
      });
      if (evGateWinRate == null) {
        this.lastSignalDesc = `${stratResult.strategyName}: p=winRateAtPrice missing — skip (not 0.65)`;
        skip("EV_FLOOR", ["p=winRateAtPrice missing"], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
          pWin: null, netEVcents: undefined,
        });
        return;
      }
      const tradeEV = estimateTradeEV(evGateWinRate, entryPrice, boostedStratResult.strategyId);
      if (tradeEV < 0.03) {
        this.lastSignalDesc =
          `${stratResult.strategyName}: EV ${tradeEV.toFixed(2)} < 0.03 floor — skip`;
        this.log("info",
          `📊 EV gate blocked: ${stratResult.strategyName} EV=${tradeEV.toFixed(3)} ` +
          `(winRate=${(evGateWinRate * 100).toFixed(0)}% entry=${entryPrice}¢ strategy=${boostedStratResult.strategyId})`
        );
        skip("EV_FLOOR", [`EV ${tradeEV.toFixed(3)} < 0.03`], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
          pWin: evGateWinRate,
        });
        return;
      }
    }

    this.lastSignalDesc = `${stratResult.strategyName} · ${signal} · ${Math.round(conf)}% [${regime}] MTF:${mtfScore > 0 ? '+' : ''}${mtfScore}`;

    // Deduplicate signal logs — the same strategy/direction/price-band fires every 500 ms.
    // Log once on first fire and whenever anything meaningful changes; skip the rest.
    const signalKey = `${stratResult.strategyId}:${signal}:${Math.round(entryPrice / 2) * 2}:${regime}`;
    if (signalKey !== this.lastSignalKey) {
      this.lastSignalKey = signalKey;
      this.log("signal",
        `🎯 ${stratResult.strategyName} — ${signal} @ ${Math.round(conf)}% conf · ` +
        `regime=${regime} · ${Math.floor(secs / 60)}m left · edge ${edge.toFixed(1)}% · MTF ${mtfScore > 0 ? '+' : ''}${mtfScore} (${mtf?.bias ?? 'n/a'}) · ` +
        `adj: [${confLog.join(' ')}] · ${stratResult.reason}${this.config.paperMode ? " [PAPER]" : ""}`
      );
    }

    // ── Pre-trade simulation ──────────────────────────────────────────────────
    // The background loop (runs every 1 s) keeps a fresh verdict cached.
    // Use the cache when it matches this signal; run inline only as fallback.
    const CACHE_STALE_MS = 2_500;
    const cv = this.cachedVerdict;
    // Provable freshness: the cached verdict must have been simulated against a
    // quote AT LEAST as fresh as the one this decision is acting on. With the
    // event-driven tick, a new quote can arrive and wake a tick before the
    // background loop has re-simulated against it — using the stale verdict
    // would decide on a fresher quote than it was computed for. Require
    // cv.quoteTs >= tick.quoteTs (equal = same quote; newer cache = fine).
    const currentQuoteTs = tick.quoteTs || 0;
    const cacheQuoteFresh = cv !== null && cv.quoteTs >= currentQuoteTs;
    const cacheEntryMatches = cv !== null
      && doesPreTradeVerdictMatchEntryPrice(cv.verdict, entryPrice);
    const cacheHit = cv !== null
      && cv.direction  === signal
      && cv.strategyId === stratResult.strategyId
      && (Date.now() - cv.ts) < CACHE_STALE_MS
      && cacheQuoteFresh
      && cacheEntryMatches;

    // The normal entry guard above rejects a stale price buffer, but the
    // background cache can become stale in the small interval before this
    // inline fallback runs. Compute staleness at the point of simulation so
    // runPreTradeSim never derives realized vol from that now-stale buffer.
    const runInlinePreTradeSim = async (): Promise<PreTradeVerdict> => {
      const lastTickAgeMs = this.prices.length > 0
        ? Date.now() - this.prices[this.prices.length - 1].ts
        : Infinity;
      const volStale = lastTickAgeMs > 30_000;
      const inlineVerdict = await runPreTradeSim({
        obs, direction: signal, priceBuffer: this.prices, secsRemaining: secs,
        entryPriceCents: entryPrice,
        // CONSENSUS MEASUREMENT PURITY + GO — LEAN ADMIT ITEM D: use the
        // pack-eligibility-aware set (this.lastEffectiveDisabledSet), not
        // the raw condEff.disabledStrategies — see its assembly above.
        volStale, disabledIds: this.lastEffectiveDisabledSet,
      });
      if (inlineVerdict.volStaleFallback) {
        this.log("warn",
          `🔬 Pre-trade sim: inline run used conservative vol fallback ` +
          `(BTC price buffer stale for ${(lastTickAgeMs / 1000).toFixed(1)}s)`
        );
      }
      return inlineVerdict;
    };

    let verdict: PreTradeVerdict;
    let simFallback = false;  // synthetic paper approval — exclude from learning
    if (cacheHit) {
      verdict = cv!.verdict;
      this.log("info", `🔬 Pre-trade sim: using cached verdict (${Date.now() - cv!.ts}ms old, quote-fresh)`);
    } else if (cv !== null && !cacheQuoteFresh && cv.direction === signal
               && cv.strategyId === stratResult.strategyId
               && (Date.now() - cv.ts) < CACHE_STALE_MS) {
      // Cache matches on direction/strategy/age but was simulated against an
      // OLDER quote than we're now deciding on — do NOT silently reuse it.
      // Re-run the sim inline against the current quote (fail-closed on error).
      this.log("info",
        `🔬 Pre-trade sim: cached verdict stale vs quote (verdict quoteTs ${cv.quoteTs} < tick ${currentQuoteTs}) — re-simulating inline`);
      try {
        verdict = await runInlinePreTradeSim();
      } catch (simErr) {
        this.log("warn",
          `🔬 Pre-trade sim error — trade blocked (${eff.paperMode ? "paper" : "live"}): ${(simErr as Error).message}`
        );
        simFallback = true;
        verdict = {
          approved: false, overallScore: 0, scoreThreshold: 62,
          entryPath: getPreTradeEntryPath(entryPrice),
          direction: signal, checks: [],
          projectedWinProb: 0.5, strategyConsensusCount: 0, strategyConsensusTotal: getAllStrategyMeta().length,
          consensusFamilySummary: 'none',
          consensusRelaxed: true, consensusRelaxedReason: 'sim error fallback — status unknown',
          historicalWinRate: 0.5, historicalSampleSize: 0, recentMomentumWinRate: 0.5,
          newsRisk: 'none', sessionLabel: 'unknown', dowLabel: 'unknown',
          rejectionReason: 'Pre-trade sim error — blocked (fail-closed)', durationMs: 0, timestamp: Date.now(),
        };
      }
    } else {
      try {
        verdict = await runInlinePreTradeSim();
      } catch (simErr) {
        // FAIL CLOSED in ALL modes. Paper mode is the proving ground for live
        // trading — letting sim errors approve paper entries produced optimistic
        // paper stats that live trading could never reproduce. Behavioral
        // consistency between modes matters more than paper uptime.
        this.log("warn",
          `🔬 Pre-trade sim error — trade blocked (${eff.paperMode ? "paper" : "live"}): ${(simErr as Error).message}`
        );
        simFallback = true;  // synthetic verdict — exclude from learning
        verdict = {
          approved: false, overallScore: 0, scoreThreshold: 62,
          entryPath: getPreTradeEntryPath(entryPrice),
          direction: signal, checks: [],
          projectedWinProb: 0.5, strategyConsensusCount: 0, strategyConsensusTotal: getAllStrategyMeta().length,
          consensusFamilySummary: 'none',
          consensusRelaxed: true, consensusRelaxedReason: 'sim error fallback — status unknown',
          historicalWinRate: 0.5, historicalSampleSize: 0, recentMomentumWinRate: 0.5,
          newsRisk: 'none', sessionLabel: 'unknown', dowLabel: 'unknown',
          rejectionReason: 'Pre-trade sim error — blocked (fail-closed)', durationMs: 0, timestamp: Date.now(),
        };
      }
    }
    // This verdict is now this tick's real, fully-gated decision — whether it
    // came from an inline sim, a sim-error fallback, or a promoted __bg__
    // cache hit — so it must never display as an un-gated background guess.
    verdict.backgroundOnly = false;
    this.lastPreTradeVerdict = verdict;
    // Task #402: stamp the real pipeline's precedence window (see field doc).
    this.lastRealVerdictDirection = signal;
    this.lastRealVerdictTs = Date.now();

    // Learning loop: persist the verdict at decision time (throttled inside)
    // so it can be scored against the actual settlement when the period ends.
    // Synthetic fallback verdicts are excluded — a fabricated score-55 approval
    // is not a real prediction and would contaminate calibration data.
    if (!simFallback) predictionLearner.persistVerdict(verdict, {
      ticker: kalshiWS.getLatest()?.ticker,
      btcPrice: obs.currentPrice,
      floorStrike: obs.floorStrike,
      secsRemaining: secs,
      strategyId: stratResult.strategyId,
      confidence: conf,
    });

    if (!verdict.approved) {
      // ── Settlement-hold override ─────────────────────────────────────────────
      // When BTC is ≥1.5% displaced from the floor with <490s remaining and
      // the Monte Carlo gives a probability that clears the (ARIA-tightenable)
      // settlement-hold bar, the Volatility Regime factor penalises the very
      // fast BTC moves that CREATE these near-certain setups. In these
      // conditions the settlement hold mechanism holds the trade to expiry,
      // so the standard score threshold is overly conservative. It never
      // overrides a reduced-price path: those contracts need the multiplier
      // score, component-score, acceleration, and EV evidence independently.
      const settlementMassWR = signal === 'LONG'
        ? obs.massAboveFloor / 100
        : (100 - obs.massAboveFloor) / 100;
      const isSettlementHoldBacked = settlementHoldOverrideEligible({
        useSettlementHold: eff.useSettlementHold,
        secs, effSecsThreshold: eff.settlementHoldSecsThreshold,
        projectedWinProb: verdict.projectedWinProb,
        settlementMassWR,
        distFromFloorPct: obs.distFromFloorPct,
        newsRisk: verdict.newsRisk,
        effMinProb: eff.settlementHoldMinProb,
      });

      if (isSettlementHoldBacked && verdict.entryPath === 'STANDARD') {
        this.log("info",
          `🔬 Pre-trade sim OVERRIDE (settlement-hold): MC=${(verdict.projectedWinProb * 100).toFixed(0)}% ` +
          `mass=${(settlementMassWR * 100).toFixed(0)}% dist=${obs.distFromFloorPct.toFixed(2)}% ` +
          `(score ${verdict.overallScore}/100 < ${verdict.scoreThreshold} but settlement hold mitigates)`
        );
        // fall through — allow the trade
      } else {
        this.lastSignalDesc =
          `${stratResult.strategyName} · HELD by pre-trade sim · ${verdict.rejectionReason}`;
        this.log("warn",
          `🔬 Pre-trade sim HELD trade (${verdict.overallScore.toFixed(0)}/100): ${verdict.rejectionReason} · ` +
          `consensus ${verdict.strategyConsensusCount}/${verdict.strategyConsensusTotal} · hist ${(verdict.historicalWinRate * 100).toFixed(0)}% ` +
          `(n=${verdict.historicalSampleSize}) · MC ${(verdict.projectedWinProb * 100).toFixed(0)}% · news:${verdict.newsRisk}`
        );
        skip("PRETRADE_SIM", [verdict.rejectionReason ?? "sim held"], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
        });
        return;
      }
    }

    this.log("info",
      `🔬 Pre-trade sim APPROVED (${verdict.overallScore.toFixed(0)}/100) · ` +
      `consensus ${verdict.strategyConsensusCount}/${verdict.strategyConsensusTotal} · hist ${(verdict.historicalWinRate * 100).toFixed(0)}% ` +
      `(n=${verdict.historicalSampleSize}) · MC ${(verdict.projectedWinProb * 100).toFixed(0)}% · ` +
      `${verdict.sessionLabel} · ${verdict.dowLabel} · news:${verdict.newsRisk}`
    );

    // Dynamic strategy win-rate lookup from the library (keeps Kelly sizing in sync
    // with expectedWinRate as strategies are tuned, without touching this file).
    const stratMeta    = getAllStrategyMeta().find(s => s.id === stratResult.strategyId);
    const stratWinRateOrNull = pWinAtPriceRejectingThinLearner(stratMeta?.winRateAtPrice, stratMeta?.expectedWinRate, entryPrice, secs / 60, {
      strategyId: stratResult.strategyId,
      paperMode: this.config.paperMode === true,
    });
    if (stratWinRateOrNull == null) {
      this.lastSignalDesc = `${stratResult.strategyName}: p=winRateAtPrice missing for Kelly — skip (not 0.65)`;
      skip("EV_FLOOR", ["p=winRateAtPrice missing for Kelly"], {
        ticker, side, strategyId: stratResult.strategyId,
        entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
      });
      return;
    }
    const stratWinRate = stratWinRateOrNull;
    // Ticket p = winRateAtPrice at the traded ask. PATH_GATE / Kelly use this.
    // Do not leave lastModelProb as binary P(YES) (or 1-p) labeled as p.
    this.lastModelProb = stratWinRate;

    // ── Mode State (risk profile + path + regime) ─────────────────────────────
    // Determines CONSERVATIVE/BALANCED/AGGRESSIVE/RECOVERY automatically from:
    //   drawdown from peak, consecutive losses, equity size, win streak
    // manualRiskProfile overrides everything when set.
    const currentRegime = obs.regime ?? regime ?? 'unclear';
    const effectiveBalance = this.effectiveBalance();
    const modeState: ModeState = buildModeState({
      entryPriceCents:   entryPrice,
      regime:            currentRegime,
      balanceCents:      effectiveBalance,
      peakBalanceCents:  this.peakBalanceCents,
      todayPnlCents:     this.dayPnlForHalt(),
      consecutiveLosses: this.consecutiveLosses,
      currentStreak:     this.currentStreak,
      manualRiskProfile: this.config.manualRiskProfile ?? null,
    });
    this.recordModeState(modeState);

    // ── Strategy-level regime filter ──────────────────────────────────────────
    // More granular than the path-level regime check — ensures each strategy ID
    // is only triggered in regimes where it is statistically validated.
    // OTM setups skip this filter (they have their own regime awareness).
    //
    // BASIS_LAG_EDGE carve-out for 'ranging'/'unclear' — see basisLagRegimeGateOk().
    // currentRegime here is the fine-grained MarketRegimeTag (from the condition
    // classifier), where "ranging" is spelled 'range', not the coarse GrokRegime's
    // 'ranging' — using the wrong literal would make this branch never fire.
    if (!isOTMSetup) {
      const isBasisLagInRangingOrUnclear =
        stratResult.strategyId === 'BASIS_LAG_EDGE' &&
        (currentRegime === 'range' || currentRegime === 'unclear');

      if (isBasisLagInRangingOrUnclear) {
        const gateOk = basisLagRegimeGateOk(obs);
        this.log("info",
          `[basis-lag-regime-gate] ${gateOk ? 'PASS' : 'BLOCK'} · regime=${currentRegime} · ` +
          `proj=${obs.projectedSettlementPrice?.toFixed(0) ?? 'n/a'} · floor=${obs.floorStrike?.toFixed(0) ?? 'n/a'} · ` +
          `yesAsk=${obs.yesAsk ?? 'n/a'} · noAsk=${obs.noAsk ?? 'n/a'}`
        );
      }

      // Bug fix: this used to pass `currentRegime` (fine-grained MarketRegimeTag,
      // e.g. 'range'/'strong_uptrend'/'breakout_up') into isStrategyAllowedInRegime(),
      // which expects the coarse GrokRegime taxonomy ('ranging'/'trending'/'high_vol'/
      // 'low_vol'/'transitioning'). Since MarketRegimeTag values never match
      // KNOWN_GROK_REGIMES (except 'unclear'), every well-classified tick (a clear
      // range, a strong trend, a breakout — exactly when a real edge exists) silently
      // fell through to the 'transitioning' allowlist bucket instead of the strategy's
      // actual regime allowlist, regime-blocking any strategy not also allowlisted for
      // 'transitioning' even though it had already passed the correct grokRegime-based
      // regime-pool filter above. Use grokRegime (same coarse value, same variable the
      // pool filter used) so this re-check enforces the same taxonomy it was filtered on.
      const regimeBlocked = isBasisLagInRangingOrUnclear
        ? !basisLagRegimeGateOk(obs)
        : !passesStrategyRegimeFilter({
            strategyId: stratResult.strategyId,
            currentRegime,
            grokRegime,
          });

      if (regimeBlocked) {
        if (!leftoverRegimeBlockPlacesMoneyMaker({
          strategyId: stratResult.strategyId,
          paperMode: this.config.paperMode === true,
          evCents: computeTradeEV({
            entryPriceCents: entryPrice,
            winRate: stratWinRate,
            secsRemaining: secs,
            velocityDolPerMin: obs.velocityDolPerMin,
          }).netEV,
          askCents: entryPrice,
        })) {
        this.strategyRegimeBlocks.count++;
        this.strategyRegimeBlocks.lastBlockAt = Date.now();
        this.strategyRegimeBlocks.byRegime[currentRegime] =
          (this.strategyRegimeBlocks.byRegime[currentRegime] ?? 0) + 1;
        this.strategyRegimeBlocks.byStrategy[stratResult.strategyId] =
          (this.strategyRegimeBlocks.byStrategy[stratResult.strategyId] ?? 0) + 1;
        const blockKey = `regime:${currentRegime}:${stratResult.strategyId}`;
        this.lastSignalDesc =
          `${stratResult.strategyName} · Regime block [${currentRegime}] · strategy not validated for this regime`;
        verdict.blockedAfterApproval = `Regime filter [${currentRegime}]: ${stratResult.strategyId} not validated for this regime`;
        if (blockKey !== this.lastBlockKey) {
          this.lastBlockKey = blockKey;
          this.log("info",
            `🚫 Regime filter: ${stratResult.strategyId} not allowed in "${currentRegime}" regime`
          );
        }
        skip("STRATEGY_REGIME_BLOCK", [this.lastSignalDesc], {
          ticker, side, strategyId: stratResult.strategyId,
          entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
        });
        return;
        }
      }
    }

    // ── ARIA DANGER hard veto — unconditional across every setup type ────────
    // OTM plays (isOTMSetup) have their own dedicated gate/sizing path below and
    // skip the general ARIA path-aware veto entirely, which used to let a fresh
    // DANGER read (waterfall move, 6+ consecutive losses, confirmed macro shock)
    // through untouched on OTM setups — a real gap, since DANGER is meant to be
    // an unconditional hard block on every path, not just HIGH_PROB/GRAY/MULTIPLIER.
    // Checked here, before the OTM/non-OTM split, so it can never be bypassed by
    // routing through a different strategy family.
    const dangerAssmt = expertAgent.getFreshAssessment();
    if (isAriaDangerVeto(dangerAssmt)) {
      this.lastSignalDesc =
        `${stratResult.strategyName} · ARIA DANGER veto${isOTMSetup ? ' [OTM]' : ''}`;
      verdict.blockedAfterApproval = `ARIA DANGER veto${isOTMSetup ? ' [OTM]' : ''}: ${dangerAssmt?.reasoning ?? "—"}`;
      this.log("warn",
        `🤖 ARIA DANGER veto${isOTMSetup ? ' [OTM]' : ''} (model: ${dangerAssmt?.modelUsed ?? "—"}): ${dangerAssmt?.reasoning ?? "—"}`
      );
      skip("ARIA_VETO", ["ARIA DANGER signal"], {
        ticker, side, strategyId: boostedStratResult.strategyId,
        entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
      });
      return;
    }

    // ── Settlement prediction hard veto (Task #445) — gated, default OFF ──────
    // Blocks trades that oppose a high-confidence settlement-model call.
    // Mirrors the ARIA DANGER veto's structure and placement (unconditional
    // across every setup type, before the OTM/non-OTM split, so it can't be
    // bypassed by routing through a different strategy family) but is its own
    // independent check: fetches settlementPredictor.getCurrent() fresh here
    // rather than trusting the tick's earlier obs snapshot, since a lot can
    // change between obs-build time and this late-stage veto check.
    if (this.config.settlementVetoEnabled) {
      const freshCall = settlementPredictor.getCurrent();
      if (freshCall) {
        const opposesVeto = settlementVetoOpposes(freshCall, this.config.settlementVetoMinConfidence, side);
        if (opposesVeto) {
          this.lastSignalDesc =
            `${stratResult.strategyName} · SETTLEMENT veto${isOTMSetup ? ' [OTM]' : ''}`;
          verdict.blockedAfterApproval =
            `Settlement veto${isOTMSetup ? ' [OTM]' : ''}: model predicts ${freshCall.predictedDirection} ` +
            `at ${freshCall.confidence}% confidence, opposing this ${signal} trade`;
          this.log("warn",
            `📉 Settlement veto${isOTMSetup ? ' [OTM]' : ''}: predicts ${freshCall.predictedDirection} ` +
            `at ${freshCall.confidence}% vs this ${signal} trade`
          );
          skip("SETTLEMENT_VETO", ["Settlement prediction opposes trade"], {
            ticker, side, strategyId: boostedStratResult.strategyId,
            entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
          });
          return;
        }
      }
    }

    // ── Dual-path gate + Risk Profile + ARIA path-aware veto ─────────────────
    // Classifies the trade as HIGH_PROB (≥39¢), GRAY (29–38¢), or MULTIPLIER
    // (≤28¢) and applies path-specific score gates, hard filters, and ARIA rules.
    // OTM plays (isOTMSetup) have their own dedicated gate so skip this for them.
    const timeOfDayRegime = getTimeOfDayRegime();
    let finalConf = conf; // may be adjusted by ARIA path rules below
    if (!isOTMSetup) {
      // PAPER_SCALP uses the same PATH_GATE as live (evaluatePathDecision) (hard filters + 7¢ MULTIPLIER
      // class). Size stays 1 downstream. Do NOT lower PATH_CONFIGS.MULTIPLIER.
      // ── EV-gate win-rate estimate: strategy's own calibrated edge is PRIMARY ──
      // Historically this blended stratWinRate with `posteriorMean`, a Bayesian
      // shrinkage of verdict.historicalWinRate — but that field is documented
      // (pre-trade-sim.ts) as the win rate "for this hour + DOW": a generic
      // BTC-direction seasonality stat, not this strategy's track record. It
      // hovers near 50% by construction, while every strategy's expectedWinRate
      // is calibrated at 55-78%. `Math.min(stratWinRate, posteriorMean)` was
      // therefore discarding the strategy's real edge on nearly every trade,
      // which made the downstream EV floor fail almost unconditionally
      // regardless of pre-trade-sim score (see PATH_GATE investigation).
      //
      // stratWinRate now drives the EV calc directly. histN/histWR are kept
      // only to power the separate credible-interval check inside
      // passesPathEVGate (which needs a real sample size to gate on).
      const histN  = verdict.historicalSampleSize;
      // P5: filled-side winRateAtPrice only. Hour-of-week ~50% hist is not p.
      const blendedWR = stratWinRate;

      // entry-path-size organ: PATH → EV≥3 → Kelly/9% size compose (CC/LAG overlay).
      const equityForPath = this.config.paperMode === true
        ? this.paperVirtualBalanceCents
        : (this.accountBalance ?? this.paperVirtualBalanceCents);
      const pathSized = entryPathAndSize({
        strategyId:          boostedStratResult.strategyId,
        p:                   blendedWR, // winRateAtPrice — never hour-of-week hist
        ask:                 entryPrice,
        equity:              equityForPath,
        secsRemaining:       secs,
        regime:              currentRegime,
        velocityDolPerMin:   obs.velocityDolPerMin ?? 0,
        threeMinVelocity:    obs.threeMinVelocity  ?? 0,
        isStalling:          obs.isStalling         ?? false,
        volumeState:         obs.volumeState,
        velocityAccel:       obs.velocityAccel,
        distFromFloorPct:    obs.distFromFloorPct,
        preTradeScore:       verdict.overallScore,
        historicalN:         histN,
        mode:                modeState,
        spreadCents:         sideSpread,
        timeOfDayRegime,
        paperMode:           this.config.paperMode === true,
        todayPnlCents:       this.dayPnlForHalt(),
        confidence:          conf,
      });
      this.lastPathSized = pathSized;
      const pathDecision = pathSized.pathDecision;
      if (pathSized.overlayApplied && pathSized.action === "take") {
        this.log("info",
          `🛤️ Path [${pathDecision.path}] overlay not skip-returning ${boostedStratResult.strategyId} @ ${entryPrice}¢ (${pathDecision.reason}) (EV/PATH floors intact)`
        );
      }
      if (pathSized.action === "skip") {
        const skipCode = pathSized.reason === "ev_below_floor" || pathSized.reason === "size_zero"
          ? (pathSized.reason === "ev_below_floor" ? "EV_FLOOR" : "SIZING_ZERO")
          : "PATH_GATE";
        const blockKey = `${pathDecision.path}:${pathSized.reason.slice(0, 60)}`;
        this.lastSignalDesc =
          `${stratResult.strategyName} · HELD by path/size [${pathDecision.path}/${modeState.riskProfile}] · ${pathSized.reason}`;
        verdict.blockedAfterApproval = `Path/size [${pathDecision.path}/${modeState.riskProfile}]: ${pathSized.reason}`;
        if (blockKey !== this.lastBlockKey) {
          this.lastBlockKey = blockKey;
          this.log("info",
            `🛤️ Path/size [${pathDecision.path}/${modeState.riskProfile}] BLOCKED: ${pathSized.reason}` +
            (histN > 0 ? ` | stratWR=${(blendedWR * 100).toFixed(0)}% n=${histN}` : '')
          );
        }
        this.logBreakEvenEval(boostedStratResult.strategyId, entryPrice, blendedWR, secs, obs.velocityDolPerMin, sideSpread, false, pathSized.reason);
        const pathGateNetEV = pathSized.ev;
        const pathGateVol = computeVolumeScore(obs);
        skip(skipCode, [pathSized.reason], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
          pWin: blendedWR,
          netEVcents: pathGateNetEV,
          volumeScoreV: pathGateVol.V, volumeBucket: pathGateVol.bucket,
        });
        return;
      }
      this.lastBlockKey = ""; // clear on successful pass
      this.log("info",
        `🛤️ Path [${pathDecision.path}/${modeState.riskProfile}] cleared ` +
        `score ${verdict.overallScore.toFixed(0)}/${pathDecision.config.minScore} ` +
        `sizeX${pathDecision.config.sizeMultiplier} cap ${pathDecision.config.maxContracts}× ` +
        `EV≥${pathDecision.config.minEVCents}¢ size=${pathSized.size}×` +
        (histN > 0 ? ` | stratWR=${(blendedWR * 100).toFixed(0)}% n=${histN}` : '')
      );
      this.logBreakEvenEval(boostedStratResult.strategyId, entryPrice, blendedWR, secs, obs.velocityDolPerMin, sideSpread, true);

      // ARIA path-aware veto — stronger authority on GRAY and MULTIPLIER trades.
      // applyAriaPathRules now returns a sizeMult (0.4–1.0) instead of a
      // confidence delta. This avoids the non-linear Kelly distortion where
      // -10 pts on a 65% confidence can halve the Kelly fraction.
      // Uses getFreshAssessment() (not the raw lastAssessment field) so a
      // stale ARIA read — expired, missing, or from a crashed cycle — can
      // never keep vetoing/blocking trades indefinitely; it falls back to
      // the "no ARIA assessment" default-allow path instead.
      const ariaAssmt = expertAgent.getFreshAssessment();
      const ariaInput = buildAriaInput(ariaAssmt);
      const ariaDecision = applyAriaPathRules({
        path:           pathDecision.path,
        baseConfidence: conf,
        aria:           ariaInput,
      });
      if (!ariaDecision.allowed) {
        this.lastSignalDesc =
          `${stratResult.strategyName} · ARIA veto [${pathDecision.path}] · ${ariaDecision.reason}`;
        verdict.blockedAfterApproval = `ARIA path veto [${pathDecision.path}]: ${ariaDecision.reason}`;
        this.log("warn",
          `🤖 ARIA path veto [${pathDecision.path}] (model: ${ariaAssmt?.modelUsed ?? "—"}): ${ariaDecision.reason}`
        );
        skip("ARIA_VETO", [ariaDecision.reason], {
          ticker, side, strategyId: boostedStratResult.strategyId,
          entryPriceCents: entryPrice, confidence: conf, secsRemaining: secs, floorStrike,
        });
        return;
      }
      if (ariaDecision.sizeMult < 1 || ariaDecision.finalConfAdj !== 0) {
        this.log("info",
          `🤖 ARIA [${pathDecision.path}] (model: ${ariaAssmt?.modelUsed ?? "—"}): ${ariaDecision.reason}`
        );
      }
    }

    // Thread the ARIA sizing multiplier into placeOrder so it is applied after
    // Kelly contract count, not via confidence distortion.
    const ariaAssmtForSizing = isOTMSetup ? null : expertAgent.getFreshAssessment();
    const ariaSizeMult = ariaAssmtForSizing && !isOTMSetup
      ? (applyAriaPathRules({
          path:           getPathConfig(entryPrice).path,
          baseConfidence: conf,
          aria:           buildAriaInput(ariaAssmtForSizing),
        })).sizeMult
      : 1.0;

    await this.placeOrder({ signal, side, entryPrice, floorStrike, ticker, confidence: finalConf, secs, strategyWinRate: stratWinRate, strategyId: boostedStratResult.strategyId, grokRegime, detailedRegime: currentRegime, isOTMAsymmetry: isOTMSetup, conditionMaxContracts: condEff.maxContractsPerTrade, ariaSizeMult, modeState, timeOfDayRegime, entryBandMin: entryBand.min, entryBandMax: entryBand.max, velocityDolPerMin: obs.velocityDolPerMin, spreadCents: sideSpread, priceBandSizeMult, stackSizeMult, sizeTier, decisionAskCents: rawAsk, volumeSizeMult, volumeBucket: volBucket, volumeScoreV: volScore.V, edgePct: boostedStratResult.edgePct, packSizeCapMult: enforcedPack?.sizeCapMult ?? 1, traceId, verdict, makerEntry, organTake: stampOrganTakeFromReport({
      report: this.lastOrganReport,
      strategyId: boostedStratResult.strategyId,
      side,
      askCents: typeof rawAsk === "number" && Number.isFinite(rawAsk) ? rawAsk : entryPrice,
    }),
    });
  
}
