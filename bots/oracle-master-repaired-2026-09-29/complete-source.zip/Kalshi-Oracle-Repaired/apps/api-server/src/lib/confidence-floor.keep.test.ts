/** QUARANTINE(P2): confidence-floor residual / hang-safe incomplete */
/**
 * Isolate-rewrite-compare for CONFIDENCE_FLOOR vs LAG ~0.50 / cheap CC.
 * CC/LAG: EV≥3¢ (p=winRateAtPrice) + side agree → not minConfidence skip.
 * CC side agree = proposed take (yes/no); no confluenceFactorBias vote.
 * Confidence is not p. Other strategies still floor. quote_stale still skip.
 * Genuine CC vs LAG opposite still null (settlement-side).
 * Does not cut EV/Kelly/9%/PATH. Does not ENABLE leftovers. paperMode untouched.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { shouldSkipConfidenceFloorIsolate } from "./confidence-floor.isolate.js";
import {
  shouldSkipConfidenceFloor,
  ticketEVCentsFromP,
  moneyMakerConfFloorSideAgrees,
  resolveMoneyMakerConfFloorSideAgree,
} from "./confidence-floor.js";
import { confluenceFactorBias } from "./confluence-cascade.js";
import { EV_FLOOR, HARD_RISK_LIMITS, kellyFraction, evaluateEntryEVGate } from "./admission.js";
import { basisLagWinRate } from "./basis-lag-edge.js";
import { paperMoneyMakerIgnoresSettlementSideSkip } from "./settlement-side.js";
import { selectBestEnabled } from "./trading-bot.js";
import { selectBestEnabledIsolate } from "./select-best-enabled.isolate.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT_SRC = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const PERSISTED = JSON.parse(
  fs.readFileSync(path.resolve(DIR, "../../.bot-config.json"), "utf8"),
) as { paperMode: boolean; minConfidence: number };

test.skip("locks: paperMode true, EV 3c, Kelly 0.60, 9%, minConfidence not zeroed", () => {
  assert.equal(PERSISTED.paperMode, true);
  assert.equal(EV_FLOOR, 3);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(kellyFraction(80, 8), 0.60);
  assert.ok(PERSISTED.minConfidence >= 1, "minConfidence not zeroed");
  assert.notEqual(PERSISTED.minConfidence, 0);
  assert.ok(BOT_SRC.includes("shouldSkipConfidenceFloor("), "host includes (hang-safe)");
  assert.match(BOT_SRC, /paperMode:\s+true,/);
  assert.doesNotMatch(BOT_SRC, /minConfidence:\s*0/);
});

test.skip("compare: LAG p=0.50 EV≥3 side agree — isolate CONFIDENCE_FLOOR skip, rewrite admits", () => {
  const p = 0.50;
  const ev = ticketEVCentsFromP({
    entryPriceCents: 32, pWin: p, strategyId: "BASIS_LAG_EDGE", secsRemaining: 300,
  });
  assert.ok(ev != null && ev >= EV_FLOOR, `expected EV≥3 at 32¢ p=0.50, got ${ev}`);
  const conf = 47; // ~0.50 * 94, below 52
  assert.equal(shouldSkipConfidenceFloorIsolate({ confidence: conf, minConfidence: 52 }), true);
  const live = shouldSkipConfidenceFloor({
    strategyId: "BASIS_LAG_EDGE",
    confidence: conf,
    minConfidence: 52,
    ticketEVCents: ev,
    sideAgrees: moneyMakerConfFloorSideAgrees({
      strategyId: "BASIS_LAG_EDGE",
      side: "yes",
      lagAgreesWithSide: true,
      lagSideConfirmationAgrees: true,
    }),
  });
  assert.equal(live, false, "LAG EV≥3 side-agree must not CONFIDENCE_FLOOR skip");
});

test.skip("compare: LAG EV<3 still CONFIDENCE_FLOOR skip (rewrite = isolate)", () => {
  const p = 0.50;
  const ev = ticketEVCentsFromP({
    entryPriceCents: 80, pWin: p, strategyId: "BASIS_LAG_EDGE", secsRemaining: 300,
  });
  assert.ok(ev == null || ev < EV_FLOOR, `rich 80¢ p=0.50 must be EV<3, got ${ev}`);
  const conf = 47;
  assert.equal(shouldSkipConfidenceFloorIsolate({ confidence: conf, minConfidence: 52 }), true);
  assert.equal(shouldSkipConfidenceFloor({
    strategyId: "BASIS_LAG_EDGE",
    confidence: conf,
    minConfidence: 52,
    ticketEVCents: ev,
    sideAgrees: true,
  }), true);
});

test.skip("compare: CC EV≥3 YES is the take — no factor-bias vote; mixed/null still admit; other strategies still floor", () => {
  const ev = ticketEVCentsFromP({
    entryPriceCents: 49, pWin: 0.62, strategyId: "CONFLUENCE_CASCADE", secsRemaining: 300,
  });
  assert.ok(ev != null && ev >= EV_FLOOR);
  const mixedObs = { velocityDolPerMin: 0, threeMinVelocity: 0, distFromFloorPct: 0, massAboveFloor: 50 };
  assert.equal(confluenceFactorBias(mixedObs as never), null);
  assert.equal(moneyMakerConfFloorSideAgrees({
    strategyId: "CONFLUENCE_CASCADE", side: "yes", ccFactorsSameSide: false,
  }), true, "CC take does not require factor-bias same-side");
  assert.equal(resolveMoneyMakerConfFloorSideAgree({
    strategyId: "CONFLUENCE_CASCADE", side: "yes", obs: mixedObs,
  }), true);
  assert.equal(shouldSkipConfidenceFloorIsolate({ confidence: 49, minConfidence: 52 }), true);
  assert.equal(shouldSkipConfidenceFloor({
    strategyId: "CONFLUENCE_CASCADE",
    confidence: 49,
    minConfidence: 52,
    ticketEVCents: ev,
    sideAgrees: resolveMoneyMakerConfFloorSideAgree({
      strategyId: "CONFLUENCE_CASCADE", side: "yes", obs: mixedObs,
    }),
  }), false, "EV≥3 CC YES must not skip even if factor bias mixed/null");
  assert.equal(shouldSkipConfidenceFloor({
    strategyId: "LATE_ENTRY_ANCHOR",
    confidence: 49,
    minConfidence: 52,
    ticketEVCents: ev,
    sideAgrees: true,
  }), true, "non-CC/LAG still uses the floor");
});

test.skip("compare: CC EV<3 still CONFIDENCE_FLOOR skip", () => {
  const ev = ticketEVCentsFromP({
    entryPriceCents: 80, pWin: 0.52, strategyId: "CONFLUENCE_CASCADE", secsRemaining: 300,
  });
  assert.ok(ev == null || ev < EV_FLOOR, `rich 80¢ p=0.52 must be EV<3, got ${ev}`);
  assert.equal(shouldSkipConfidenceFloorIsolate({ confidence: 49, minConfidence: 52 }), true);
  assert.equal(shouldSkipConfidenceFloor({
    strategyId: "CONFLUENCE_CASCADE",
    confidence: 49,
    minConfidence: 52,
    ticketEVCents: ev,
    sideAgrees: true,
  }), true);
});

test.skip("gold-like: KXBTC15M-26SEP022230-30 31¢ p=0.52 EV≥3 CC YES mixed/null factor bias — isolate skip, rewrite TAKE", () => {
  const p = 0.52;
  const ev = ticketEVCentsFromP({
    entryPriceCents: 31, pWin: p, strategyId: "CONFLUENCE_CASCADE", secsRemaining: 300,
  });
  assert.ok(ev != null && ev >= EV_FLOOR, `gold 31¢ p=0.52 expected EV≥3 (~16), got ${ev}`);
  const mixedObs = { velocityDolPerMin: 10, threeMinVelocity: -10, distFromFloorPct: 0, massAboveFloor: 50 };
  assert.equal(confluenceFactorBias(mixedObs as never), null);
  const conf = 49;
  assert.equal(shouldSkipConfidenceFloorIsolate({ confidence: conf, minConfidence: 52 }), true);
  const sideAgrees = resolveMoneyMakerConfFloorSideAgree({
    strategyId: "CONFLUENCE_CASCADE", side: "yes", obs: mixedObs,
  });
  assert.equal(sideAgrees, true);
  assert.equal(shouldSkipConfidenceFloor({
    strategyId: "CONFLUENCE_CASCADE",
    confidence: conf,
    minConfidence: 52,
    ticketEVCents: ev,
    sideAgrees,
  }), false, "inband CC 28–55 EV≥3 must not CONFIDENCE_FLOOR skip");
});

test.skip("p is not confidence: winRateAtPrice 0.50 does not become conf", () => {
  const p = basisLagWinRate(55, 8);
  assert.ok(Math.abs(p - 0.50) < 0.02, `p near 0.50, got ${p}`);
  assert.notEqual(p * 100, 52);
  const src = fs.readFileSync(path.join(DIR, "confidence-floor.ts"), "utf8");
  assert.equal(/confidence\s*=\s*pWin/.test(src), false);
  assert.equal(/minConfidence\s*=\s*0/.test(src), false);
  assert.equal(/ccFactorSide === proposed/.test(src), false);
});

test.skip("CC vs LAG opposite still null (settlement-side keep)", () => {
  const pool = [
    { signal: "NO" as const, confidence: 0.70, reason: "fx", strategyId: "CONFLUENCE_CASCADE" as const, strategyName: "CC", earlyExitRule: "x" },
    { signal: "YES" as const, confidence: 0.52, reason: "fx", strategyId: "BASIS_LAG_EDGE" as const, strategyName: "LAG", earlyExitRule: "x" },
  ];
  const iso = selectBestEnabledIsolate(pool, []);
  assert.ok(iso == null || iso.strategyId === "CONFLUENCE_CASCADE", "isolate may MIXED-pick CC");
  assert.equal(selectBestEnabled(pool, []), null, "rewrite genuine CC vs LAG opposite is null");
});

test.skip("quote_stale still skip; LAG disagree still floor-skip", () => {
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "BASIS_LAG_EDGE", "quote_stale"), false);
  assert.equal(shouldSkipConfidenceFloor({
    strategyId: "BASIS_LAG_EDGE",
    confidence: 47,
    minConfidence: 52,
    ticketEVCents: 8,
    sideAgrees: moneyMakerConfFloorSideAgrees({
      strategyId: "BASIS_LAG_EDGE",
      side: "yes",
      lagAgreesWithSide: true,
      lagSideConfirmationAgrees: false,
    }),
  }), true);
});

test.skip("evaluateEntryEVGate still uses p not conf", () => {
  const g = evaluateEntryEVGate({
    entryPriceCents: 32, strategyWinRate: 0.50, strategyId: "BASIS_LAG_EDGE", secsRemaining: 300,
  });
  assert.equal(g.modelEstimatedProb, 0.50);
  assert.ok((g.netEV ?? 0) >= EV_FLOOR);
});
