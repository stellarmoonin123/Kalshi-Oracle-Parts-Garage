/**
 * Bounded, retry-safe persistence for captured Kalshi L2 snapshots.
 *
 * Capturing an order book is useful only if a temporary database failure does
 * not immediately discard it. Keep failed batches in FIFO order, retry them
 * on the next capture cycle, and surface a sustained failure to operators.
 */

export interface L2SnapshotRow {
  ticker: string;
  yesBids: string;
  yesAsks: string;
  bestYesBid: number | null;
  bestYesAsk: number | null;
  spread: number | null;
  midPrice: number | null;
  bidDepth5: number;
  askDepth5: number;
}

export interface L2SnapshotPersistenceDeps {
  insert(rows: L2SnapshotRow[]): Promise<void>;
  enterDegraded(reason: string): Promise<void>;
  exitDegraded(): Promise<void>;
}

export interface L2SnapshotPersistenceStatus {
  pendingSnapshots: number;
  consecutiveFailures: number;
  degraded: boolean;
}

export const L2_FLUSH_BATCH_SIZE = 3;
export const L2_MAX_BUFFERED_SNAPSHOTS = 50;
export const L2_PERSIST_FAILURE_THRESHOLD = 3;

function errorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  return message.replace(/\s+/g, " ").trim().slice(0, 300) || "unknown database error";
}

export class L2SnapshotPersistence {
  private readonly pending: L2SnapshotRow[] = [];
  private consecutiveFailures = 0;
  private degraded = false;

  constructor(private readonly deps: L2SnapshotPersistenceDeps) {}

  enqueue(snapshot: L2SnapshotRow): void {
    this.pending.push(snapshot);
    if (this.pending.length > L2_MAX_BUFFERED_SNAPSHOTS) {
      const discarded = this.pending.length - L2_MAX_BUFFERED_SNAPSHOTS;
      this.pending.splice(0, discarded);
      console.warn(`[kalshi-ws] L2 persistence buffer full — discarded ${discarded} oldest snapshot(s) after sustained write failures`);
    }
  }

  getStatus(): L2SnapshotPersistenceStatus {
    return {
      pendingSnapshots: this.pending.length,
      consecutiveFailures: this.consecutiveFailures,
      degraded: this.degraded,
    };
  }

  async flushIfReady(): Promise<boolean> {
    if (this.pending.length < L2_FLUSH_BATCH_SIZE) return false;

    // Keep the rows in `pending` until the INSERT succeeds. A connection
    // blip therefore delays writes instead of silently erasing market history.
    const batch = this.pending.slice();
    try {
      await this.deps.insert(batch);
      this.pending.splice(0, batch.length);
      this.consecutiveFailures = 0;

      if (this.degraded) {
        this.degraded = false;
        await this.deps.exitDegraded();
        console.info("[kalshi-ws] L2 snapshot persistence recovered");
      }
      return true;
    } catch (error) {
      this.consecutiveFailures += 1;
      const message = errorMessage(error);

      // Avoid turning a sustained database outage into a log storm. The first
      // failure records the cause; the threshold-crossing failure records the
      // state transition that operators need to act on.
      if (this.consecutiveFailures === 1) {
        console.warn(`[kalshi-ws] L2 snapshot insert failed; retaining ${batch.length} snapshot(s) for retry: ${message}`);
      }

      if (this.consecutiveFailures >= L2_PERSIST_FAILURE_THRESHOLD && !this.degraded) {
        this.degraded = true;
        const reason = `L2 snapshot insert failed ${this.consecutiveFailures} consecutive times: ${message}`;
        console.error(`[kalshi-ws] ${reason} — order-book history persistence is DEGRADED`);
        await this.deps.enterDegraded(reason);
      }
      return false;
    }
  }
}