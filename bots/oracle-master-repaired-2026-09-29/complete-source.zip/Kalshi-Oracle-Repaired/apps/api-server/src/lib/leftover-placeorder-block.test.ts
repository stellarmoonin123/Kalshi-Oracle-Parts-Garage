/**
 * leftover-placeorder-block.test.ts
 *
 * LATE_ENTRY (and SP / OTM / PAPER_SCALP / SEV1) must not placeOrder even if
 * evaluate TAKE, SIZE_RESCUE, or backgroundPreTrade would. CC/LAG still fill.
 * Does not bounce API, paperMode, EV 3¢ / Kelly 0.60 / 9% / 15% / 18%.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "path";
import { fileURLToPath } from "node:url";
import {
  effectiveDisabledStrategies,
  LEFTOVER_PLACEORDER_DENYLIST,
  placeOrderStrategyHardBlockReason,
  PAPER_TIER_A_STRATEGY_IDS,
  selectBestEnabled,
} from "./trading-bot.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");

const persisted = JSON.parse(
  fs.readFileSync(path.resolve(DIR, "../../.bot-config.json"), "utf8"),
) as {
  paperMode: boolean;
  autoMode: boolean;
  frozenCcMode?: boolean;
  disabledStrategies: string[];
};

/** Unit cfg: CC+LAG enabled so placeOrder hard-block tests are not coupled to frozen denylist. */
const cfg = {
  disabledStrategies: persisted.disabledStrategies.filter(
    (id) => id !== "CONFLUENCE_CASCADE" && id !== "BASIS_LAG_EDGE",
  ),
  paperMode: true as const,
  velocityStallReversalEnabled: false as const,
  bollingerBandStrategyEnabled: false as const,
  settlementConsensusVoteEnabled: false as const,
  topReversalEnabled: false as const,
  bottomReversalEnabled: false as const,
  cheapSide15mEnabled: false as const,
  cheapEarlyExitEnabled: false as const,
  panicFadeEnabled: false as const,
  streakSatFadeEnabled: false as const,
};

test("locks: paperMode true, autoMode false, LATE_ENTRY disabled; CC enabled (frozen may disable LAG)", () => {
  assert.equal(persisted.paperMode, true);
  assert.equal(persisted.autoMode, false);
  assert.ok(persisted.disabledStrategies.includes("LATE_ENTRY_ANCHOR"));
  assert.equal(persisted.disabledStrategies.includes("CONFLUENCE_CASCADE"), false);
  // Frozen-CC desk may keep BASIS_LAG_EDGE disabled — that is intentional, not a hole.
  if (persisted.frozenCcMode === true) {
    assert.ok(
      persisted.disabledStrategies.includes("BASIS_LAG_EDGE") ||
        !persisted.disabledStrategies.includes("BASIS_LAG_EDGE"),
      "frozenCcMode: LAG disabled-or-not is operator choice; CC must stay enabled",
    );
  }
});

test("hole: paperTierAMustEvaluate must not strip LATE_ENTRY from disabledStrategies", () => {
  assert.equal(PAPER_TIER_A_STRATEGY_IDS.includes("LATE_ENTRY_ANCHOR"), false,
    "LATE_ENTRY must not be paper-Tier-A unlocked");
  const effective = effectiveDisabledStrategies(cfg);
  assert.ok(effective.includes("LATE_ENTRY_ANCHOR"),
    "LATE_ENTRY stays in effectiveDisabled — do not strip via paperTierAMustEvaluate");
  assert.equal(effective.includes("CONFLUENCE_CASCADE"), false);
  assert.equal(effective.includes("BASIS_LAG_EDGE"), false);
});

test("selectBestEnabled cannot pick LATE_ENTRY when it is disabled", () => {
  const picked = selectBestEnabled([
    { strategyId: "LATE_ENTRY_ANCHOR", strategyName: "LATE", signal: "YES", confidence: 0.90, reason: "test" } as any,
    { strategyId: "BASIS_LAG_EDGE", strategyName: "LAG", signal: "YES", confidence: 0.62, reason: "test" } as any,
  ], effectiveDisabledStrategies(cfg));
  assert.equal(picked?.strategyId, "BASIS_LAG_EDGE");
});

test("placeOrder hard-block: LATE_ENTRY in disabledStrategies even if evaluate TAKE / SIZE_RESCUE", () => {
  const reason = placeOrderStrategyHardBlockReason("LATE_ENTRY_ANCHOR", cfg);
  assert.ok(reason, "LATE_ENTRY must hard-block placeOrder");
  assert.match(reason!, /cannot placeOrder/);
  // Simulate evaluate TAKE + SIZE_RESCUE: helper still blocks; sizing never runs.
  assert.ok(LEFTOVER_PLACEORDER_DENYLIST.includes("LATE_ENTRY_ANCHOR"));
});

test("placeOrder hard-block: SP, OTM family, PAPER_SCALP, SEV1", () => {
  assert.match(placeOrderStrategyHardBlockReason("SETTLEMENT_PREDICTION", cfg) ?? "", /cannot placeOrder/);
  assert.match(placeOrderStrategyHardBlockReason("DEEP_OTM_SNIPER", { disabledStrategies: [] }) ?? "", /LOCKED|cannot placeOrder/);
  assert.match(placeOrderStrategyHardBlockReason("OTM_ASYMMETRY", { disabledStrategies: [] }) ?? "", /LOCKED|cannot placeOrder/);
  assert.match(placeOrderStrategyHardBlockReason("OTM_BREAKOUT_EXPANSION", { disabledStrategies: [] }) ?? "", /LOCKED|cannot placeOrder/);
  assert.match(placeOrderStrategyHardBlockReason("SAKATA_CANDLE_PATTERN", { disabledStrategies: [] }) ?? "", /LOCKED|cannot placeOrder/);
  assert.match(placeOrderStrategyHardBlockReason("MTF_ALIGNED", { disabledStrategies: [] }) ?? "", /LOCKED|cannot placeOrder/);
  // BRTI unlocked PAPER DESK v2 Tier A — not LOCKED when disabledStrategies omits it
  assert.equal(placeOrderStrategyHardBlockReason("BRTI_PROBABILITY", { disabledStrategies: [], paperMode: true }), null);
  assert.match(placeOrderStrategyHardBlockReason("PAPER_SCALP", { disabledStrategies: [] }) ?? "", /cannot placeOrder/);
});

test("user-disabled leftover still cannot fill even if paperTierA still evaluates it", () => {
  const floor = placeOrderStrategyHardBlockReason("FLOOR_DISTANCE", {
    disabledStrategies: ["FLOOR_DISTANCE"],
  });
  assert.match(floor ?? "", /disabledStrategies/);
});

test("LAG + CC can still fill when not disabled; SIZE_RESCUE not expanded", () => {
  assert.equal(placeOrderStrategyHardBlockReason("CONFLUENCE_CASCADE", cfg), null);
  assert.equal(placeOrderStrategyHardBlockReason("BASIS_LAG_EDGE", cfg), null);
  assert.equal(LEFTOVER_PLACEORDER_DENYLIST.includes("CONFLUENCE_CASCADE"), false);
  assert.equal(LEFTOVER_PLACEORDER_DENYLIST.includes("BASIS_LAG_EDGE"), false);
  assert.equal(BOT.includes('limiter: "SIZE_RESCUE_MIN1"'), false,
    "do not expand SIZE_RESCUE; Kelly-zero stays 0");
});

test("source: _placeOrderBody calls leftover hard-block before PATH_GATE", () => {
  const bodyAt = BOT.indexOf("private async _placeOrderBody(");
  const pathAt = BOT.indexOf("Time-of-day path hard block", bodyAt);
  const blockAt = BOT.indexOf("placeOrderStrategyHardBlockReason(strategyId, this.config)", bodyAt);
  assert.ok(bodyAt >= 0 && pathAt > bodyAt && blockAt > bodyAt && blockAt < pathAt,
    "hard-block must sit in _placeOrderBody before PATH_GATE");
  assert.match(BOT, /skip\("LEFTOVER_PLACEORDER_BLOCK"/);
  assert.match(BOT, /HARD RULE: this timer must NEVER call placeOrder/);
});

test("placeOrder HARD_NO_FILL annotates verdict.blockedAfterApproval (single gate)", () => {
  // Params type block is huge — search the whole _placeOrderBody through PATH_GATE.
  const bodyStart = BOT.indexOf("private async _placeOrderBody");
  assert.ok(bodyStart > 0);
  const pathGate = BOT.indexOf("Time-of-day path hard block", bodyStart);
  assert.ok(pathGate > bodyStart);
  const slice = BOT.slice(bodyStart, pathGate);
  assert.match(slice, /blockedAfterApproval = leftoverBlock/);
  assert.match(slice, /lastSignalDesc = leftoverBlock/);
  // Single gate only inside _placeOrderBody before PATH_GATE.
  const first = slice.indexOf("placeOrderStrategyHardBlockReason");
  assert.ok(first > 0);
  const second = slice.indexOf("placeOrderStrategyHardBlockReason", first + 1);
  assert.equal(second, -1, "duplicate hard-block gate must be removed");
});

