/**
 * accounts/bootstrap.ts — create the FIRST Administrator, only if no ADMIN
 * exists yet. Idempotent: once any ADMIN row exists this is a no-op, even if
 * the env vars are still set. The password is never logged or echoed; the
 * account is created with mustChangePassword=true.
 *
 * Env: ORACLE_ADMIN_USERNAME, ORACLE_ADMIN_EMAIL, ORACLE_ADMIN_PASSWORD
 * (optional ORACLE_ADMIN_DISPLAY_NAME). CLI: scripts/accounts-bootstrap-admin.ts.
 */
import { withTransaction } from "./db.js";
import { accountsReady, assignLegacyConversations } from "./migrate.js";
import { hashPassword, passwordPolicyError } from "./passwords.js";
import {
  AccountError,
  normalizeDisplayName,
  normalizeEmail,
  normalizeUsername,
  type UserRow,
} from "./users.js";

export type BootstrapResult =
  | { created: true; userId: string; username: string; legacyAssigned: number }
  | { created: false; reason: "admin_exists" | "not_configured" };

export interface BootstrapInput {
  username: string;
  email: string;
  password: string;
  displayName?: string;
}

export async function bootstrapFirstAdmin(input: BootstrapInput): Promise<BootstrapResult> {
  const username = normalizeUsername(input.username);
  const email = normalizeEmail(input.email);
  const displayName = normalizeDisplayName(input.displayName?.trim() || "Administrator");
  const policy = passwordPolicyError(input.password);
  if (policy) throw new AccountError(400, policy, "WEAK_PASSWORD");
  const passwordHash = await hashPassword(input.password);
  await accountsReady();
  const out = await withTransaction(async (c) => {
    // Serialise concurrent bootstraps (two processes / CLI + boot).
    await c.query("SELECT pg_advisory_xact_lock($1)", [0x0a11_b007]);
    const { rows } = await c.query<{ n: number }>("SELECT COUNT(*)::int AS n FROM oracle_users WHERE role = 'ADMIN'");
    if ((rows[0]?.n ?? 0) > 0) return null;
    const ins = await c.query<UserRow>(
      `INSERT INTO oracle_users (username, email, display_name, password_hash, role, status, must_change_password)
       VALUES ($1, $2, $3, $4, 'ADMIN', 'ACTIVE', true) RETURNING *`,
      [username, email, displayName, passwordHash],
    );
    return ins.rows[0]!;
  });
  if (!out) return { created: false, reason: "admin_exists" };
  const legacy = await assignLegacyConversations();
  return { created: true, userId: out.id, username: out.username, legacyAssigned: legacy.legacyAssigned };
}

export async function bootstrapAdminFromEnv(env: NodeJS.ProcessEnv = process.env): Promise<BootstrapResult> {
  const username = env.ORACLE_ADMIN_USERNAME?.trim();
  const email = env.ORACLE_ADMIN_EMAIL?.trim();
  const password = env.ORACLE_ADMIN_PASSWORD;
  if (!username || !email || !password) return { created: false, reason: "not_configured" };
  return bootstrapFirstAdmin({ username, email, password, displayName: env.ORACLE_ADMIN_DISPLAY_NAME });
}
