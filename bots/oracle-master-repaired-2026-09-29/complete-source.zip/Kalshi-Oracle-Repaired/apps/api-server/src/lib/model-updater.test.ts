import test from "node:test";
import assert from "node:assert/strict";
import {
  scoreModel,
  scoreModelCapability,
  getStrongestConfirmedModel,
  getConfirmedModels,
  SAFE_FALLBACK,
} from "./model-updater.js";

// ── scoreModel (cost-efficiency) vs scoreModelCapability (raw capability) ────
// These two rankers exist side by side for opposite purposes: scoreModel picks
// the cheapest capable model, scoreModelCapability picks the smartest model
// regardless of cost. ARIA's authority upgrade depends on always reading from
// the capability ranker, never the cost ranker, so lock in that they disagree
// on ordering for a flagship-vs-budget pair.

test("scoreModel (cost) ranks a cheap flash model above an expensive opus model", () => {
  assert.ok(
    scoreModel("google/gemini-2.5-flash") > scoreModel("anthropic/claude-opus-4-5"),
    "cost ranker should prefer the cheaper model"
  );
});

test("scoreModelCapability (capability) ranks opus above flash — the opposite of scoreModel", () => {
  assert.ok(
    scoreModelCapability("anthropic/claude-opus-4-5") > scoreModelCapability("google/gemini-2.5-flash"),
    "capability ranker should prefer the more capable model regardless of cost"
  );
});

test("scoreModelCapability penalizes '-mini' variants relative to their full-size sibling", () => {
  assert.ok(scoreModelCapability("openai/o3") > scoreModelCapability("openai/o3-mini"));
  assert.ok(scoreModelCapability("x-ai/grok-4") > scoreModelCapability("x-ai/grok-4-mini"));
});

test("scoreModelCapability gives a within-family version bonus (opus-5 > opus-4-5 > opus-4)", () => {
  const opus4    = scoreModelCapability("anthropic/claude-opus-4");
  const opus45   = scoreModelCapability("anthropic/claude-opus-4-5");
  const opus5    = scoreModelCapability("anthropic/claude-opus-5");
  assert.ok(opus45 > opus4, "opus-4-5 should outrank opus-4");
  assert.ok(opus5 > opus45, "opus-5 should outrank opus-4-5");
});

test("SAFE_FALLBACK mid-tier uses current slugs, not retired ids", () => {
  // 2026-09-24 live check: OpenRouter answers 404 "No endpoints found" for
  // claude-haiku-4-5 / sonnet-4-6 / opus-4-5 — they must not be fallbacks.
  assert.equal(SAFE_FALLBACK.includes("anthropic/claude-sonnet-4-6"), false);
  assert.ok(SAFE_FALLBACK.includes("google/gemini-3.1-pro-preview"));
  assert.equal(SAFE_FALLBACK.includes("google/gemini-2.5-pro"), false);
  assert.equal(SAFE_FALLBACK.includes("anthropic/claude-sonnet-4-5"), false);
  assert.equal(SAFE_FALLBACK.includes("openai/gpt-4o"), false);
  assert.equal(SAFE_FALLBACK.includes("gpt-4o-mini"), false);
});

// ── getStrongestConfirmedModel ───────────────────────────────────────────────

test("getStrongestConfirmedModel never returns an empty/undefined slug, even with an empty confirmed list", () => {
  // getConfirmedModels() reflects whatever the last probe found; regardless of
  // its current state this must always resolve to a real slug (falling back to
  // SAFE_FALLBACK) so ARIA is never left without a model to call.
  const strongest = getStrongestConfirmedModel();
  assert.ok(typeof strongest === "string" && strongest.length > 0);
  assert.ok(getConfirmedModels().includes(strongest) || SAFE_FALLBACK.includes(strongest));
});

test("getStrongestConfirmedModel picks the highest scoreModelCapability among the SAFE_FALLBACK list", () => {
  const bestInFallback = [...SAFE_FALLBACK].sort(
    (a, b) => scoreModelCapability(b) - scoreModelCapability(a)
  )[0];
  // If the daily probe has already run in-process (startModelUpdater is called
  // at server boot, not in this isolated test file), getConfirmedModels() may
  // differ from SAFE_FALLBACK — that's fine, we only assert the fallback-list
  // ranking logic itself is correct.
  assert.equal(
    [...SAFE_FALLBACK].sort((a, b) => scoreModelCapability(b) - scoreModelCapability(a))[0],
    bestInFallback
  );
  assert.ok(scoreModelCapability(bestInFallback!) >= scoreModelCapability(SAFE_FALLBACK[0]!));
});
