/**
 * lag-side-agree.isolate.ts — UNCHANGED copy of lagSideConfirmationAgrees
 * from basis-lag-edge.ts at isolate time.
 */
export function lagSideConfirmationAgrees(opts: {
  projSide: "YES" | "NO" | null;
  haRiverSide: "YES" | "NO" | null;
  ccFactorSide: "YES" | "NO" | null;
}): boolean {
  if (opts.projSide !== "YES" && opts.projSide !== "NO") return false;
  const ha = opts.haRiverSide;
  const cc = opts.ccFactorSide;
  if (ha == null && cc == null) return false;
  return ha === opts.projSide || cc === opts.projSide;
}
