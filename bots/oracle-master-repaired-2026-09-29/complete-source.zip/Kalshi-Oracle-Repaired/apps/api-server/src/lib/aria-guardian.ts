/**
 * aria-guardian.ts — P5: ARIA GUIDE + GUARDIAN (STATE-DRIVEN, NOT VIBES).
 *
 * Pure, consume-only module. ARIA becomes a continuous co-pilot on OPEN risk:
 * it may recommend HOLD / TIGHTEN / EXIT (and an optional SETTLE_HOLD bias)
 * from the SAME MarketState, FamilyPolicy/LiquidityPolicy, and thesis signals
 * the bot already computes every tick — never from a free-form "feel" and
 * never from an LLM call on the hot 500ms tick path.
 *
 * ── Model-vs-rules choice (2026-08-26) ───────────────────────────────────────
 * The spec's Part D explicitly sanctions a two-step hybrid: "Rules layer
 * first (fast) ... Model or scored policy second: produce AriaDecision from
 * AriaContext." This phase ships the deterministic SCORED POLICY only
 * (evaluateAriaGuardianPolicy below) — no new LLM round-trip is added to the
 * per-tick open-trade loop. Reasons: (1) the existing expertAgent LLM path
 * already runs on its own ~45s cadence for the coarse YES/NO/WAIT/DANGER
 * signal and entry filters — adding a SECOND live LLM call, on a much
 * tighter open-trade cadence, for money-exiting decisions is real scope and
 * latency/cost risk the spec did not ask for outright ("if you already have
 * an LLM ARIA path" was conditional); (2) a deterministic policy is
 * exhaustively unit-testable (confidence is a real evidence-strength score,
 * not a self-report you have to trust) which matters more for something that
 * can force-close a live position than model creativity does. parseAriaDecision
 * below still exists and is exercised so a future LLM-backed producer (or a
 * malformed/corrupt decision from any source) is defensively fail-safe.
 *
 * ── Locks (unchanged from P0-P4.1) ───────────────────────────────────────────
 * Never touches EV/PATH_GATE/RICH_ASK/9%/daily-halt/SEV1/size-0/pack
 * membership. TIGHTEN may only shrink stop/trail multipliers (mult ≤ 1,
 * never > 1, never widens). ARIA must never bypass the hard stop or a
 * protective size-0 abort. ARIA never raises size or loosens entry gates.
 */

import { logger } from "./logger.js";
import { decideHoldOrSell } from "./hold-sell.js";

// ── Types ─────────────────────────────────────────────────────────────────

export type AriaGuardianAction = "HOLD" | "TIGHTEN" | "EXIT" | "SETTLE_HOLD";
export type AriaExitCode = "ARIA_THESIS" | "ARIA_LAG_FLIP" | "ARIA_LIQ" | "ARIA_TIME" | "ARIA_TRAIL" | "ARIA_OTHER";
export type BookClass = "FULL" | "DEPTH_NULL" | "BOOK_STALE" | "BOOK_MISSING";
export type LiqAction = "ALLOW" | "HAIRCUT" | "SKIP";

/** Part A — context packet built every open-trade tick (and optionally pre-entry, unused this phase). */
export interface AriaContext {
  trade: {
    side: "yes" | "no";
    strategyId: string;
    family: string | undefined;
    entryAsk: number;
    contracts: number;
    floorStrike: number;
    secsRemaining: number;
    /** One-liner from the strategy reason / pack — no prose dump. */
    entryThesis: string;
  };
  market: {
    velScale: number;
    zVel: number;
    rangeScale: number;
    volScale: number;
    regime: string;
    session: string;
    tau: number;
    stale: boolean;
  };
  book: {
    spreadCents: number | null;
    depthAtAsk: number | null;
    imbalance: number | null;
    liqAction: LiqAction | null;
    bookClass: BookClass;
  };
  lag: {
    projectedSettlement: number | null;
    rollingBasis: number | null;
    /** 1s projectedSettlement vs floor. NOT Coinbase lag-meter. null = unknown/stale. */
    projAgreesWithSide: boolean | null;
  };
  position: {
    unrealizedCents: number;
    distanceToHardStopCents: number | null;
    /** true once the thesis-break persistence counters are actively climbing (not yet at the hard-fire threshold). */
    thesisBreakTicksRising: boolean;
    lagFlipTicks: number;
    /** Peak unrealized ¢ this trade; used for trail-giveback. */
    peakUnrealizedCents?: number;
    /** Mark ¢ (side bid). If omitted, entryAsk + unrealizedCents. */
    markCents?: number;
  };
  gates: {
    netEVAtEntry: number | null;
    primaryBlocker: string | null;
  };
  /** Seconds since this trade was opened — drives the grace-period gate. */
  secsSinceEntry: number;
}

export interface AriaTighten {
  /** Multiplier on the current stop distance; must be in (0, 1] — never widens. */
  stopMult?: number;
  /** Multiplier on the current trailing-profit distance; must be in (0, 1] — never widens. */
  trailMult?: number;
}

/** Part B — strict decision schema. */
export interface AriaDecision {
  action: AriaGuardianAction;
  /** 0-1 self-score / evidence-strength score. NOT a win-rate — never fed to EV as p. */
  confidence: number;
  /** Max 3 short machine-readable tags. */
  reasons: string[];
  tighten?: AriaTighten;
  exitCode?: AriaExitCode;
}

// ── Constants (starters from the spec's ranges) ─────────────────────────────

export const ARIA_EXIT_MIN_CONF = 0.7; // spec range 0.65-0.75
export const ARIA_GRACE_SECS = 20; // spec range 15-30s after entry
export const ARIA_EXIT_MIN_SECS = 10; // avoid EXIT spam this close to expiry unless hard stop would fire anyway
export const ARIA_RATE_LIMIT_SECS = 10; // spec range 5-15s, per open trade, unless hard-stop proximity
export const ARIA_HARD_STOP_PROXIMITY_CENTS = 3; // "unless hard-stop proximity" rate-limit bypass

// Duplicated from trading-bot lag-flip gate — do NOT import trading-bot.ts.
// ARIA_LAG_FLIP EXIT must meet the same 15s + 16-against-samples bar as LAG_FLIP_EXIT.
export const LAG_FLIP_MIN_HOLD_MS = 15_000;
export const LAG_FLIP_MIN_SAMPLES = 16;

const MAX_REASONS = 3;
const VALID_ACTIONS: readonly AriaGuardianAction[] = ["HOLD", "TIGHTEN", "EXIT", "SETTLE_HOLD"];
const VALID_EXIT_CODES: readonly AriaExitCode[] = ["ARIA_THESIS", "ARIA_LAG_FLIP", "ARIA_LIQ", "ARIA_TIME", "ARIA_TRAIL", "ARIA_OTHER"];

const FAIL_SAFE_HOLD: AriaDecision = { action: "HOLD", confidence: 0, reasons: ["PARSE_FAIL"] };

// ── Part B — strict parse/validate, fail-safe HOLD on any bad output ────────
// Invalid / unparseable / timeout must NEVER resolve to EXIT — always HOLD.

export function parseAriaDecision(raw: unknown): AriaDecision {
  try {
    if (raw === null || typeof raw !== "object") return FAIL_SAFE_HOLD;
    const r = raw as Record<string, unknown>;

    if (typeof r.action !== "string" || !VALID_ACTIONS.includes(r.action as AriaGuardianAction)) return FAIL_SAFE_HOLD;
    if (typeof r.confidence !== "number" || !Number.isFinite(r.confidence)) return FAIL_SAFE_HOLD;
    if (!Array.isArray(r.reasons) || !r.reasons.every((x) => typeof x === "string")) return FAIL_SAFE_HOLD;

    const action = r.action as AriaGuardianAction;
    const confidence = Math.min(1, Math.max(0, r.confidence));
    const reasons = (r.reasons as string[]).slice(0, MAX_REASONS);

    let tighten: AriaTighten | undefined;
    if (r.tighten !== undefined) {
      if (r.tighten === null || typeof r.tighten !== "object") return FAIL_SAFE_HOLD;
      tighten = clampTighten(r.tighten as AriaTighten);
    }

    let exitCode: AriaExitCode | undefined;
    if (r.exitCode !== undefined) {
      if (typeof r.exitCode !== "string" || !VALID_EXIT_CODES.includes(r.exitCode as AriaExitCode)) return FAIL_SAFE_HOLD;
      exitCode = r.exitCode as AriaExitCode;
    }

    return { action, confidence, reasons, ...(tighten ? { tighten } : {}), ...(exitCode ? { exitCode } : {}) };
  } catch {
    return FAIL_SAFE_HOLD;
  }
}

/** Part C rule 3 — TIGHTEN may only shrink stops/trails (mult in (0,1]), never widen. Invalid/out-of-range values are dropped, never clamped up to 1 silently passing through a >1 request. */
export function clampTighten(tighten: AriaTighten | undefined | null): AriaTighten | undefined {
  if (!tighten) return undefined;
  const out: AriaTighten = {};
  if (typeof tighten.stopMult === "number" && Number.isFinite(tighten.stopMult) && tighten.stopMult > 0 && tighten.stopMult <= 1) {
    out.stopMult = tighten.stopMult;
  }
  if (typeof tighten.trailMult === "number" && Number.isFinite(tighten.trailMult) && tighten.trailMult > 0 && tighten.trailMult <= 1) {
    out.trailMult = tighten.trailMult;
  }
  return (out.stopMult !== undefined || out.trailMult !== undefined) ? out : undefined;
}

/**
 * Guardian confidence is evidence-strength (0-1), NEVER a win-rate, Kelly p, or pWin.
 * Callers must not feed decision.confidence into EV / PATH_GATE / size as p.
 * True iff the decision carries no pWin/winRate/kellyP field a caller could confuse with p.
 */
export function ariaConfidenceIsNotWinRate(decision: AriaDecision): boolean {
  return !("pWin" in decision) && !("winRate" in decision) && !("kellyP" in decision);
}

/** Same 15s AND 16-sample bar as shouldLagFlipExit. Uses duplicated constants; no trading-bot import. */
export function ariaLagFlipPersistenceMet(ctx: AriaContext): boolean {
  return ctx.position.lagFlipTicks >= LAG_FLIP_MIN_SAMPLES
    && ctx.secsSinceEntry >= LAG_FLIP_MIN_HOLD_MS / 1000;
}

// ── Evidence gate (Part C rule 2) ────────────────────────────────────────────

const Z_VEL_STRONG_AGAINST = 1.5;

export interface AriaEvidence {
  lagDisagrees: boolean;
  thesisBreakRising: boolean;
  liqAdverse: boolean;
  zVelStronglyAgainst: boolean;
}

/** Pure — never invents evidence from stale/missing inputs (mirrors isLagAgainstSide's fail-to-neutral stance). */
export function computeAriaEvidence(ctx: AriaContext): AriaEvidence {
  const lagDisagrees = ctx.lag.projAgreesWithSide === false;
  const thesisBreakRising = ctx.position.thesisBreakTicksRising === true;
  const liqAdverse = ctx.book.liqAction === "SKIP" || ctx.book.liqAction === "HAIRCUT";
  const zVel = ctx.market.stale ? 0 : ctx.market.zVel;
  const zVelStronglyAgainst = ctx.trade.side === "yes"
    ? zVel <= -Z_VEL_STRONG_AGAINST
    : zVel >= Z_VEL_STRONG_AGAINST;
  return { lagDisagrees, thesisBreakRising, liqAdverse, zVelStronglyAgainst };
}

function evidenceCount(e: AriaEvidence): number {
  return (e.lagDisagrees ? 1 : 0) + (e.thesisBreakRising ? 1 : 0) + (e.liqAdverse ? 1 : 0) + (e.zVelStronglyAgainst ? 1 : 0);
}

/** Part C rule 2 — the hard gate an EXIT decision must clear regardless of how it was produced (model or rules). */
export function isAriaExitAllowed(
  ctx: AriaContext,
  decision: AriaDecision,
  opts: { hardStopImminent?: boolean } = {},
): { allowed: boolean; reason: string } {
  if (decision.action !== "EXIT") return { allowed: false, reason: "NOT_EXIT_ACTION" };
  if (decision.confidence < ARIA_EXIT_MIN_CONF) return { allowed: false, reason: "CONF_BELOW_MIN" };
  const evidence = computeAriaEvidence(ctx);
  // Trail giveback is the Expert-Agent-like power: sell a green about to go red
  // even with 0 lag/thesis evidence. Other EXITs still need ≥1 evidence signal.
  const isTrail = decision.exitCode === "ARIA_TRAIL" || decision.reasons.includes("TRAIL_GIVEBACK");
  if (!isTrail && evidenceCount(evidence) < 1) return { allowed: false, reason: "NO_EVIDENCE" };
  if (ctx.secsSinceEntry < ARIA_GRACE_SECS) return { allowed: false, reason: "WITHIN_GRACE" };
  if (!opts.hardStopImminent && ctx.trade.secsRemaining <= ARIA_EXIT_MIN_SECS) return { allowed: false, reason: "TOO_CLOSE_TO_EXPIRY" };
  if (decision.exitCode === "ARIA_LAG_FLIP" && !ariaLagFlipPersistenceMet(ctx)) {
    return { allowed: false, reason: "LAG_FLIP_PERSISTENCE" };
  }
  return { allowed: true, reason: "OK" };
}

// ── Rate limiting (Part C rule 6) ────────────────────────────────────────────

/** At most one ARIA decision per ARIA_RATE_LIMIT_SECS per open trade, unless hard-stop proximity. */
export function shouldEvaluateAriaGuardian(
  lastEvalTs: number | null,
  now: number,
  distanceToHardStopCents: number | null,
): boolean {
  const hardStopProximity = distanceToHardStopCents !== null && distanceToHardStopCents <= ARIA_HARD_STOP_PROXIMITY_CENTS;
  if (hardStopProximity) return true;
  if (lastEvalTs === null) return true;
  return now - lastEvalTs >= ARIA_RATE_LIMIT_SECS * 1000;
}

// ── Part D — deterministic scored policy (the "rules layer" / "scored policy") ──

/**
 * Pure scored policy: AriaContext -> AriaDecision. Confidence is an
 * evidence-strength score (0-1), not a model self-report — this is the
 * documented "scored policy" half of the spec's hybrid, shipped alone this
 * phase (see module doc comment for why no LLM call was added).
 */
export function evaluateAriaGuardianPolicy(ctx: AriaContext): AriaDecision {
  if (ctx.market.stale) {
    return { action: "HOLD", confidence: 0, reasons: ["MARKET_STALE"] };
  }

  const evidence = computeAriaEvidence(ctx);
  let score = 0;
  const reasons: string[] = [];
  const strongest: { exitCode: AriaExitCode } = { exitCode: "ARIA_OTHER" };
  let strongestWeight = 0;

  const consider = (fired: boolean, weight: number, tag: string, exitCode: AriaExitCode) => {
    if (!fired) return;
    score += weight;
    if (reasons.length < MAX_REASONS) reasons.push(tag);
    if (weight > strongestWeight) { strongestWeight = weight; strongest.exitCode = exitCode; }
  };

  consider(evidence.lagDisagrees, 0.35, "LAG_DISAGREES", "ARIA_LAG_FLIP");
  consider(evidence.thesisBreakRising, 0.3, "THESIS_BREAK_RISING", "ARIA_THESIS");
  consider(evidence.liqAdverse, 0.2, "LIQ_ADVERSE", "ARIA_LIQ");
  consider(evidence.zVelStronglyAgainst, 0.3, "ZVEL_AGAINST", "ARIA_OTHER");

  const confidence = Math.min(1, score);
  const nEvidence = evidenceCount(evidence);
  const lagPersistent = ariaLagFlipPersistenceMet(ctx);

  // EXIT needs score + ≥2 signals. ARIA_LAG_FLIP additionally needs lag-flip persistence
  // (16 against samples AND 15s since entry). If lag disagrees but that bar is not met → TIGHTEN.
  let allowExit = confidence >= ARIA_EXIT_MIN_CONF && nEvidence >= 2;
  if (allowExit && strongest.exitCode === "ARIA_LAG_FLIP" && !lagPersistent) {
    allowExit = false;
  }
  if (allowExit) {
    return { action: "EXIT", confidence, reasons, exitCode: strongest.exitCode };
  }

  // Hold-sell consult AFTER evidence scoring. hardStop/thesisBreak/lagFlip already
  // ran earlier in monitorOpenTrade — pass false so we do not double-fire those.
  // hold-sell.ts must NOT import this file (cycle).
  const markCents = ctx.position.markCents ?? (ctx.trade.entryAsk + ctx.position.unrealizedCents);
  const holdSell = decideHoldOrSell({
    strategyId: ctx.trade.strategyId,
    markCents,
    entryCents: ctx.trade.entryAsk,
    peakUnrealizedCents: ctx.position.peakUnrealizedCents ?? ctx.position.unrealizedCents,
    secsRemaining: ctx.trade.secsRemaining,
    projectedSettlement: ctx.lag.projectedSettlement,
    floor: ctx.trade.floorStrike > 0 ? ctx.trade.floorStrike : null,
    side: ctx.trade.side,
    hardStop: false,
    thesisBreak: false,
    lagFlip: false,
    trailingGivebackCents: 12,
  });
  const cheapSide = ctx.trade.strategyId === "CHEAP_SIDE_15M";
  const unrealized = markCents - ctx.trade.entryAsk;

  // LOCKED_ITM → SETTLE_HOLD. Cheap-side never SETTLE_HOLD (sell-before-expiry).
  if (holdSell.action === "HOLD_SETTLE") {
    if (cheapSide) {
      return { action: "HOLD", confidence: 0.3, reasons: ["CHEAP_SIDE_NO_SETTLE_HOLD"] };
    }
    return { action: "SETTLE_HOLD", confidence: Math.max(confidence, 0.55), reasons: ["LOCKED_ITM"] };
  }

  // Trail giveback while still green: EXIT ARIA_TRAIL. This is the power that was
  // LLM DANGER — sell a green that is about to go red, without lag/thesis evidence.
  // DEAD_RED is NOT an EXIT here (lag-flip / thesis-break own that).
  if (holdSell.action === "SELL" && holdSell.reason === "TRAIL_GIVEBACK" && unrealized >= 0) {
    return {
      action: "EXIT",
      confidence: Math.max(confidence, ARIA_EXIT_MIN_CONF),
      reasons: ["TRAIL_GIVEBACK"],
      exitCode: "ARIA_TRAIL",
    };
  }

  if (nEvidence >= 1) {
    // Shrink proportionally to confidence — never below a sane floor, never widens.
    const stopMult = Math.max(0.5, 1 - confidence * 0.5);
    const trailMult = Math.max(0.5, 1 - confidence * 0.5);
    return { action: "TIGHTEN", confidence, reasons, tighten: clampTighten({ stopMult, trailMult }) };
  }

  return { action: "HOLD", confidence, reasons: reasons.length ? reasons : ["NO_EVIDENCE"] };
}

// ── Priority order (Part C rule 1) — pure resolver for enforcement + tests ──

export type ExitPriorityWinner = "HARD_STOP" | "THESIS_BREAK" | "LAG_FLIP" | "ARIA_EXIT" | "SETTLEMENT_HOLD" | "NONE";

/**
 * Stellar thesis-hold: THESIS_BREAK / LAG_FLIP outrank soft/hard % stops
 * when thesis is evaluated. HARD_STOP remains for catastrophic mark≤5¢
 * (or thesis-BROKEN backup) and still outranks ARIA / settlement-hold.
 * Order: thesis-break > lag-flip > hard stop > ARIA EXIT > settlement-hold
 * > soft/trailing. trading-bot.ts's sequential if-chain in monitorOpenTrade()
 * matches this. Kept pure/exported so the order is unit-testable.
 */
export function resolveExitPriority(input: {
  hardStop: boolean;
  thesisBreak: boolean;
  lagFlip: boolean;
  ariaExit: boolean;
  settlementHoldActive: boolean;
}): ExitPriorityWinner {
  if (input.thesisBreak) return "THESIS_BREAK";
  if (input.lagFlip) return "LAG_FLIP";
  if (input.hardStop) return "HARD_STOP";
  if (input.ariaExit) return "ARIA_EXIT";
  if (input.settlementHoldActive) return "SETTLEMENT_HOLD";
  return "NONE";
}

// ── Logging ──────────────────────────────────────────────────────────────────

export interface AriaGuardianLogEntry {
  tradeId: string;
  ticker: string;
  side: "yes" | "no";
  decision: AriaDecision;
  applied: boolean;
  applyReason: string;
}

export function logAriaGuardianDecision(entry: AriaGuardianLogEntry): void {
  const { tradeId, ticker, side, decision, applied, applyReason } = entry;
  logger.info(
    `[aria-guardian] ${ticker} trade=${tradeId} side=${side} action=${decision.action} ` +
    `confidence=${decision.confidence.toFixed(2)} reasons=[${decision.reasons.join(",")}]` +
    (decision.exitCode ? ` exitCode=${decision.exitCode}` : "") +
    (decision.tighten ? ` tighten=${JSON.stringify(decision.tighten)}` : "") +
    ` applied=${applied} (${applyReason})`
  );
}

// ── System constraint text (embedded, available for a future LLM-backed producer) ──

export const ARIA_GUARDIAN_SYSTEM_PROMPT = `You are ARIA, a risk guardian for Kalshi BTC binary positions.
You only output the JSON schema provided.
You never invent prices. You never request larger size.
EXIT only when structure (lag, thesis, liquidity, adverse zVel) breaks.
Prefer HOLD when evidence is mixed. Prefer TIGHTEN before EXIT when stop
can be tightened without violating hard-stop priority.
confidence is your certainty, not a win-rate for Kelly.`;
