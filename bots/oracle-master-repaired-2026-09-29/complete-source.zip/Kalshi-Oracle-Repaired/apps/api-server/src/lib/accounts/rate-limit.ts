/**
 * accounts/rate-limit.ts — in-memory login throttling, keyed per client IP
 * and per submitted identifier (normalised). Identifier keys are applied to
 * unknown identifiers exactly like real ones, so a 429 reveals nothing about
 * whether an account exists. Single-process desk: in-memory is sufficient.
 */
import { createHash } from "node:crypto";

interface Window { start: number; n: number }

// Request-body identifiers can be large. Bound retained key bytes as well as
// entry count, without storing submitted account names in the throttle map.
const fingerprint = (key: string) => createHash("sha256").update(key).digest("hex");

export class FixedWindowCounter {
  private readonly hits = new Map<string, Window>();
  constructor(readonly max: number, readonly windowMs: number, readonly maxKeys = 10_000) {}

  private prune(now: number): void {
    for (const [key, value] of this.hits) {
      if (now - value.start >= this.windowMs) this.hits.delete(key);
    }
  }

  private current(key: string, now: number): Window | null {
    const w = this.hits.get(fingerprint(key));
    if (!w || now - w.start >= this.windowMs) return null;
    return w;
  }

  /** True when `key` has already reached the limit in the current window. */
  isBlocked(key: string, now = Date.now()): boolean {
    const w = this.current(key, now);
    if (!w && this.hits.size >= this.maxKeys) {
      this.prune(now);
      // Fail closed at capacity instead of dropping an active abuse counter.
      return this.hits.size >= this.maxKeys;
    }
    return !!w && w.n >= this.max;
  }

  retryAfterSec(key: string, now = Date.now()): number {
    const w = this.current(key, now);
    if (!w && this.isBlocked(key, now)) return Math.max(1, Math.ceil(this.windowMs / 1000));
    return w ? Math.max(1, Math.ceil((w.start + this.windowMs - now) / 1000)) : 0;
  }

  add(key: string, now = Date.now()): void {
    const w = this.current(key, now);
    if (!w) {
      if (this.hits.size >= this.maxKeys) this.prune(now);
      const slot = fingerprint(key);
      if (!this.hits.has(slot) && this.hits.size >= this.maxKeys) return;
      this.hits.set(slot, { start: now, n: 1 });
    }
    else w.n += 1;
  }

  reset(key: string): void { this.hits.delete(fingerprint(key)); }
  clear(): void { this.hits.clear(); }
}

function envInt(name: string, fallback: number): number {
  const n = Number(process.env[name]);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : fallback;
}

const FIFTEEN_MIN = 15 * 60_000;

export const loginLimits = {
  /** Every attempt from one IP (caps Argon2 CPU burn). */
  ipAttempts: new FixedWindowCounter(envInt("ORACLE_LOGIN_MAX_ATTEMPTS_PER_IP_PER_MIN", 30), 60_000),
  /** Failed attempts from one IP. */
  ipFailures: new FixedWindowCounter(envInt("ORACLE_LOGIN_MAX_FAILURES_PER_IP", 20), FIFTEEN_MIN),
  /** Failed attempts against one identifier (username/email), any IP. */
  identifierFailures: new FixedWindowCounter(envInt("ORACLE_LOGIN_MAX_FAILURES_PER_IDENTIFIER", 5), FIFTEEN_MIN),
};

export function resetLoginRateLimits(): void {
  loginLimits.ipAttempts.clear();
  loginLimits.ipFailures.clear();
  loginLimits.identifierFailures.clear();
}

export const RATE_LIMIT_MESSAGE = "Too many sign-in attempts. Please wait a few minutes and try again.";
