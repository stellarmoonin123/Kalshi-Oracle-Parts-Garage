/**
 * One-sided-safe book mid (cents).
 *
 * Stolen from Krypt crypto15m._mid_up: average ONLY when both sides are present.
 * Never (bid+0)/2 — that halves the implied probability and can trip spurious
 * stop-loss / wrong-side edges when the book is one-sided.
 * Falls back to lastFallback when the book is empty.
 */
export function bookMidCents(
  bid: number,
  ask: number,
  lastFallback: number = 0,
): number {
  const b = Number.isFinite(bid) && bid > 0 ? bid : 0;
  const a = Number.isFinite(ask) && ask > 0 ? ask : 0;
  if (b > 0 && a > 0) return Math.round((b + a) / 2);
  if (b > 0) return Math.round(b);
  if (a > 0) return Math.round(a);
  const last = Number.isFinite(lastFallback) && lastFallback > 0 ? lastFallback : 0;
  return last > 0 ? Math.round(last) : 0;
}
