/** The desk chat context carries the dated standing knowledge note (Sep 25 PM ET). */
import test from "node:test";
import assert from "node:assert/strict";
import { deskAgentSystemPrompt } from "./chat-agent.js";
import { chatSystemPrompt } from "./chat-free-llm.js";
import { DESK_TOOL_SPECS, runDeskTool } from "./chat-desk-tools.js";
import { DESK_KNOWLEDGE_AS_OF, DESK_KNOWLEDGE_SECTIONS, DESK_KNOWLEDGE_SUMMARY } from "./desk-knowledge.js";
import { estTokens } from "./chat-router.js";

test("desk-agent system prompt includes the dated knowledge summary and prefers live tools", () => {
  const sys = deskAgentSystemPrompt({ paperMode: true, state: "WATCHING", balance$: "308.83" });
  assert.ok(sys.includes(DESK_KNOWLEDGE_AS_OF), "dated note present");
  assert.ok(sys.includes("2026-09-26 4:00 AM ET"));
  assert.match(sys, /live tools win/);
  assert.match(sys, /get_desk_knowledge/);
  assert.ok(estTokens(DESK_KNOWLEDGE_SUMMARY) < 350, "summary stays small inside the 3.8k budget");
});

test("fallback chat prompt also carries the knowledge summary", () => {
  const sys = chatSystemPrompt({ paperMode: true, state: "WATCHING", classification: "IDLE", headline: "", paperVirtualCents: 30883, activeBlockers: [], projLine: "" } as never);
  assert.ok(sys.includes(DESK_KNOWLEDGE_AS_OF));
});

test("get_desk_knowledge tool returns every required topic", async () => {
  assert.ok(DESK_TOOL_SPECS.some((t) => t.name === "get_desk_knowledge"));
  const deps = { getStatus: () => ({}), getRecentTrades: async () => [] } as never;
  const index = await runDeskTool("get_desk_knowledge", {}, deps);
  assert.ok(index.includes("Sections:") && index.includes(DESK_KNOWLEDGE_AS_OF));
  let full = "";
  for (const k of Object.keys(DESK_KNOWLEDGE_SECTIONS)) {
    const part = await runDeskTool("get_desk_knowledge", { section: k }, deps);
    assert.ok(!part.includes("[truncated"), `section ${k} fits the tool result limit`);
    full += part;
  }
  for (const needle of [
    "PR #7", "PR #9", "PR #10", "PR #11", "default", "api-server src", "healthz", "paperMode true", "EV floor 3", "Kelly",
    "n>=30", "ECE<=0.08", "shadow-only", "0.097", "OV-SKIP", "PR #5 NOT merged", "typecheck still red", "pre-existing failures",
    "ops/ci/locks.yml", "PR #8", "unique opportunities", "hypothetical", "quotes are not fills", "lower bound", "confidence intervals", "verified-current",
    "#72", "#73", "#74", "30932", "reserve",
  ]) assert.ok(full.includes(needle), `knowledge mentions ${needle}`);
  const one = await runDeskTool("get_desk_knowledge", { section: "calibration" }, { getStatus: () => ({}), getRecentTrades: async () => [] } as never);
  assert.ok(one.includes("[calibration]") && !one.includes("[locks]"));
  assert.ok(Object.keys(DESK_KNOWLEDGE_SECTIONS).length >= 7);
});

test("knowledge note records PR #12 (v34) and the Sep 26 paper daily halt", () => {
  const r = DESK_KNOWLEDGE_SECTIONS.releases;
  for (const k of ["PR #12", "v33", "v34", "daily loss halt", "ET calendar day", "SUSPENDS"]) assert.ok(r.includes(k), k);
});

test("knowledge note records PR #14 (lockSide, fill-price re-check, bootstrap gate)", () => {
  const r = DESK_KNOWLEDGE_SECTIONS.pr14 + DESK_KNOWLEDGE_SECTIONS.calibration + DESK_KNOWLEDGE_SECTIONS.locks;
  for (const k of ["lockSide PASS", "FILL_PRICE_EV_FAIL", "FILL_PRICE_BAND_FAIL", "bootstrap", "one per 15m window", "early-exit", "not evidence", "Min entry stays 20"]) {
    assert.ok(r.includes(k), k);
  }
});

test("knowledge note records PR #17 advisory heave terms and the review rule", () => {
  const r = DESK_KNOWLEDGE_SECTIONS.heave_advisory;
  for (const k of ["OV-SKIP", "coversBoth", "calibration", "advisoryVetoes", "MIND_HEAVE_ADVISORY", "n>=40", "day-block bootstrap", "restore blocking", "+9.2", "[-2.4, +20.0]", "+4.9", "[-10.7, +20.7]", "n=39", "vel_against", "7¢ min edge", "thin book", "Do not claim an edge"]) {
    assert.ok(r.includes(k), k);
  }
  assert.ok(DESK_KNOWLEDGE_SECTIONS.releases.length < 2400, "releases fits");
});
