/** Legacy recovery preflight. Detects corrupt/ambiguous files; never repairs or
 * rewrites them. This is NOT a proof that a legacy integer-cent book is correct.
 * JSON syntax validity is necessary, not sufficient evidence of accounting truth.
 */
export class PaperTapeIntegrityError extends Error {
  constructor(public readonly code: string, public readonly line: number) {
    super(`PAPER_TAPE_INTEGRITY:${code}:line=${line}`);this.name='PaperTapeIntegrityError';
  }
}
export type LegacyRow={ts:number;ticker:string;tradeId?:number;side:'yes'|'no';contracts:number;
  entryPriceCents:number;isPaper:true;event?:'fill'|'close';outcome?:string;pnlCents?:number;[key:string]:unknown};
const rec=(x:unknown):x is Record<string,unknown>=>typeof x==='object'&&x!==null&&!Array.isArray(x);
const safe=(x:unknown):x is number=>typeof x==='number'&&Number.isSafeInteger(x);
export function parseLegacyTape(text:string):LegacyRow[] {
  if(typeof text!=='string')throw new PaperTapeIntegrityError('NOT_TEXT',0);
  if(text.length>0&&!text.endsWith('\n'))throw new PaperTapeIntegrityError('UNTERMINATED_TAIL',text.split('\n').length);
  const rows:LegacyRow[]=[];
  for(const [i,line] of text.split('\n').entries()){
    if(!line.trim())continue;
    let x:unknown;try{x=JSON.parse(line);}catch{throw new PaperTapeIntegrityError('BAD_JSON',i+1);}
    if(!rec(x)||x.isPaper!==true||typeof x.ticker!=='string'||!x.ticker.trim()||x.ticker.length>240||
       !safe(x.ts)||x.ts<0||(x.side!=='yes'&&x.side!=='no')||!safe(x.contracts)||x.contracts<0||
       !safe(x.entryPriceCents)||x.entryPriceCents<0||x.entryPriceCents>100||
       (x.tradeId!==undefined&&(!safe(x.tradeId)||x.tradeId<=0))||
       (x.event!==undefined&&x.event!=='fill'&&x.event!=='close')||
       (x.outcome!==undefined&&typeof x.outcome!=='string'))throw new PaperTapeIntegrityError('INVALID_ROW',i+1);
    const isClose=x.event==='close'||(x.outcome!==undefined&&x.outcome!=='pending');
    if(isClose&&(!safe(x.pnlCents)||!['win','loss','cancelled','canceled','unresolved','void','expired'].includes(x.outcome as string)))
      throw new PaperTapeIntegrityError('INVALID_CLOSE',i+1);
    rows.push(x as LegacyRow);
  }
  return rows;
}
/** Relevant economic payload only: later timestamps cannot erase a disagreement. */
/** R2 — an audited correction row (`correction` object, durable tradeId,
 *  Kalshi-result settle) is the explicit migration for the ID-less void close
 *  it names: same ticker/side/size/price, void outcome, earlier ts. Only such
 *  pairs are exempted; everything else stays fail-closed. */
function supersededByCorrection(r:LegacyRow, rows:readonly LegacyRow[]):boolean {
  if(r.tradeId!==undefined)return false;
  if(r.outcome!=='cancelled'&&r.outcome!=='canceled'&&r.outcome!=='void')return false;
  return rows.some(c=>c!==r&&rec(c.correction)&&c.tradeId!==undefined&&c.exitReason==='ORPHAN_SETTLED_KALSHI'&&
    c.ticker===r.ticker&&c.side===r.side&&c.contracts===r.contracts&&c.entryPriceCents===r.entryPriceCents&&c.ts>r.ts);
}
export function assertLegacyIdentities(allRows:readonly LegacyRow[]):void {
  const rows=allRows.filter(r=>!supersededByCorrection(r,allRows));
  const identities=new Map<string,LegacyRow[]>();
  for(const r of rows){const k=r.tradeId===undefined?'legacy:'+r.ticker:'trade:'+r.tradeId;const group=identities.get(k)??[];group.push(r);identities.set(k,group);}
  for(const [key,rs] of identities){
    const first=rs[0]!;
    if(rs.some(r=>r.ticker!==first.ticker||r.side!==first.side))throw new PaperTapeIntegrityError('CONFLICTING_TRADE_IDENTITY',0);
    const fills=rs.filter(r=>r.event!=='close'&&(r.outcome===undefined||r.outcome==='pending'));
    const closes=rs.filter(r=>r.event==='close'||(r.outcome!==undefined&&r.outcome!=='pending'));
    const economically=(r:LegacyRow)=>JSON.stringify([r.contracts,r.entryPriceCents,r.outcome??'pending',r.pnlCents??null,r.exitPriceCents??null,r.feeCents??null]);
    if(new Set(fills.map(economically)).size>1||new Set(closes.map(economically)).size>1)
      throw new PaperTapeIntegrityError('CONFLICTING_ECONOMIC_RECORDS',0);
    // Without a durable ID, two different entry times may be distinct positions
    // in the same ticker. Never pick latest and silently forget the other one.
    if(key.startsWith('legacy:')&&new Set(fills.map(r=>r.ts)).size>1)
      throw new PaperTapeIntegrityError('AMBIGUOUS_LEGACY_TICKER',0);
    // Mixing ID-less history with ID-bound records on the same market requires
    // an explicit migration; do not guess that these are duplicates or additions.
    if(key.startsWith('legacy:')&&rows.some(r=>r.tradeId!==undefined&&r.ticker===first.ticker))
      throw new PaperTapeIntegrityError('MIXED_LEGACY_IDENTITY',0);
    if(fills.length&&closes.some(c=>c.contracts!==fills[0]!.contracts||c.entryPriceCents!==fills[0]!.entryPriceCents))
      throw new PaperTapeIntegrityError('FILL_CLOSE_ECONOMICS_MISMATCH',0);
    if(fills.length&&closes.some(c=>c.ts<Math.min(...fills.map(f=>f.ts))))
      throw new PaperTapeIntegrityError('CLOSE_BEFORE_ENTRY',0);
  }
}
export type RecoveryInspection={ok:boolean;code:string;rows:number;ordersAuthorized:false};
export function inspectLegacyRecoveryTexts(snapshotText:string|null,tapeText:string|null,startCents:number):RecoveryInspection {
  try{
    if(!safe(startCents)||startCents<=0)throw new Error('INVALID_START_CASH');
    const rows=tapeText===null?[]:parseLegacyTape(tapeText);
    if(snapshotText===null){
      if(rows.length)throw new Error('TAPE_WITHOUT_CASH_SNAPSHOT');
      return {ok:true,code:'NO_LOCAL_FILES_EXISTING_DB_CHECK_STILL_REQUIRED',rows:0,ordersAuthorized:false};
    }
    let raw:unknown;try{raw=JSON.parse(snapshotText);}catch{throw new Error('CORRUPT_CASH_SNAPSHOT');}
    if(!rec(raw)||!safe(raw.virtualCents)||raw.virtualCents<0||!safe(raw.peakCents)||raw.peakCents<raw.virtualCents||
      !safe(raw.pnlCents)||!safe(raw.wins)||raw.wins<0||!safe(raw.losses)||raw.losses<0||!safe(raw.trades)||raw.trades<0||
      raw.wins+raw.losses!==raw.trades||
      (raw.reserveCents!==undefined&&(!safe(raw.reserveCents)||raw.reserveCents<0))||
      (raw.sessionStartTs!==undefined&&(!safe(raw.sessionStartTs)||raw.sessionStartTs<=0))||
      (raw.virtualCents===100000&&raw.sessionStartTs===undefined))throw new Error('INVALID_CASH_SNAPSHOT');
    assertLegacyIdentities(rows.filter(r=>raw.sessionStartTs===undefined||r.ts>=(raw.sessionStartTs as number)));
    return {ok:true,code:'LOCAL_FILES_PARSEABLE_NOT_RECONCILED',rows:rows.length,ordersAuthorized:false};
  }catch(e){return {ok:false,code:e instanceof Error?e.message:'UNKNOWN_RECOVERY_ERROR',rows:0,ordersAuthorized:false};}
}
