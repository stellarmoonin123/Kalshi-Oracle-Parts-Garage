/**
 * kalshi-price.ts — Kalshi-native BTC (BRTI) price provider
 *
 * Replaces Kraken as the BTC price source across the entire system.
 *
 * Sources:
 *  - Real-time spot  : Black-Scholes inversion of YES probability + floor strike.
 *                      Every Kalshi WS tick updates the inferred price.
 *  - Historical OHLC : Settled KXBTC15M market floor strikes.
 *                      floorStrike[N] = BRTI at the open of period N
 *                      ≈ settlement BRTI of period N-1.
 *                      Aggregated to any higher interval (1h, 4h, etc.)
 *                      or sub-divided into shorter intervals (5m, 1m).
 *
 * Why floor strikes ≈ settlement prices:
 *   Kalshi sets each period's floor based on the current BRTI at period open.
 *   The floor for period N is therefore the market's best approximation of the
 *   BRTI at the close of period N-1. The sequence of floor strikes across
 *   settled markets is thus a faithful 15-min sampled BRTI price series.
 */

import { KALSHI_REST_BASE, KALSHI_SERIES_15M, BTC_FLOOR_FALLBACK, BTC_ANNUALISED_VOL } from "./constants.js";
import type { KalshiTick } from "./kalshi-ws.js";
import { kalshiAuthHeaders } from "./kalshi-auth.js";
import { bookMidCents } from "./kalshi-book-mid.js";

// ── OHLC candle types ─────────────────────────────────────────────────────────

export interface OHLC {
  time:   number;  // unix seconds (start of candle)
  open:   number;
  high:   number;
  low:    number;
  close:  number;
  volume: number;  // 0 for synthetic candles
}

// Alias used by backtest-engine (same shape)
export type OHLCCandle = OHLC;

// ── Kalshi settlement record ──────────────────────────────────────────────────

export interface KalshiSettlement {
  ts:          number;            // unix seconds (settle_time, falling back to close_time)
  openTs:      number;            // unix seconds of the contract's open_time = period START (unambiguous key)
  floorStrike: number;            // BRTI at period open (= settledPrice of previous period)
  result:      'yes' | 'no';
  ticker:      string;
  volume:      number;            // real contracts traded on this market (Kalshi's own volume_fp), 0 if absent
}

// ── Inverse normal CDF (Abramowitz & Stegun 26.2.17 rational approximation) ──
// Maximum absolute error < 4.5 × 10^-4 over (0, 1).
// Formula verified: normInv(0.5) ≈ 0, normInv(0.975) ≈ 1.96.

function normInv(p: number): number {
  p = Math.max(0.0001, Math.min(0.9999, p));
  if (p < 0.5) return -normInv(1 - p);
  const t   = Math.sqrt(-2 * Math.log(1 - p));
  const num = 2.515517 + t * (0.802853 + t * 0.010328);
  const den = 1 + t * (1.432788 + t * (0.189269 + t * 0.001308));
  return t - num / den;
}

// ── Real-time BTC price inference ─────────────────────────────────────────────
//
// Inverts the Black-Scholes digital call formula:
//   P = N(d2)  where  d2 = [ln(S/K) − 0.5·σ²·T] / (σ·√T)
//   ⟹  S = K · exp(N⁻¹(P) · σ·√T + 0.5·σ²·T)
//
//   K = floorStrike (the fixed floor for this 15-min period)
//   P = YES mid probability (0–1), clamped to avoid instability
//   T = time remaining until close (years)
//   σ = annualised BTC realised vol (constant from constants.ts)
//
// Accuracy degrades for very short T (< 10 s), so we clamp T to 10 s.
// At mid-period (≈7.5 min remaining, P=60%) this typically gives ±$150 of
// the actual BRTI — sufficient for velocity trend detection.

export function inferBtcPrice(tick: KalshiTick, vol = BTC_ANNUALISED_VOL): number {
  const { floorStrike, yesAsk, yesBid, closeTime } = tick;
  if (!floorStrike || floorStrike <= 0) return BTC_FLOOR_FALLBACK;

  // One-sided-safe mid (Krypt _mid_up): never (bid+0)/2.
  const midCents = bookMidCents(yesBid, yesAsk, tick.lastPrice ?? 0);
  if (!(midCents > 0)) return floorStrike;
  const p        = Math.max(0.01, Math.min(0.99, midCents / 100));

  // Guard: new Date("").getTime() returns NaN — clamp to at least 10 s.
  const closeMs   = closeTime ? new Date(closeTime).getTime() : NaN;
  const msToClose = Number.isFinite(closeMs) ? closeMs - Date.now() : 0;
  const tYears    = Math.max(10_000, msToClose) / (365.25 * 24 * 60 * 60 * 1000);

  const sqrtT = Math.sqrt(tYears);
  const d2    = normInv(p);
  const lnSK  = d2 * vol * sqrtT + 0.5 * vol * vol * tYears;
  const spot  = floorStrike * Math.exp(lnSK);

  // Sanity guard: inversion breaks down on illiquid / zero-spread books.
  // If the result is more than 5× or less than 20% of floor, fall back to floor.
  if (spot < floorStrike * 0.2 || spot > floorStrike * 5) return floorStrike;
  return Math.round(spot * 100) / 100;
}

// ── Settlement fetch ──────────────────────────────────────────────────────────
//
// Fetches the most recently settled KXBTC15M markets from the Kalshi REST API.
// Each market record contains floor_strike (BRTI at period open) and result
// ("yes"/"no"). Results are sorted oldest → newest.
//
// Caches for SETTLE_CACHE_TTL_MS to avoid hammering the API.

const SETTLE_CACHE_TTL_MS = 10 * 60_000;   // 10-minute cache
const SETTLE_PAGE_SIZE    = 1000;          // Kalshi's max page size for this endpoint
const SETTLE_MAX_PAGES    = 25;            // safety cap: 25k settlements ≈ 260 days of 15-min history
export const SETTLE_MAX_TOTAL = SETTLE_PAGE_SIZE * SETTLE_MAX_PAGES;
let settleCache: { data: KalshiSettlement[]; ts: number; exhausted: boolean } | null = null;

/** Coalesce concurrent settlement paginations into one walk. */
let settleFetchInFlight: Promise<KalshiSettlement[]> | null = null;
/** After page-1 429/503, pause new walks so we do not rate-limit the live book. */
let settle429UntilMs = 0;
let settle429WarnedAt = 0;
const SETTLE_429_COOLDOWN_MS = 90_000;

/** Wait up to `ms` for an in-flight settlements walk (or existing cache). */
export async function awaitSettlementWarm(ms: number): Promise<boolean> {
  if (settleCache && settleCache.data.length > 0) return true;
  if (!settleFetchInFlight) return false;
  await new Promise<void>((resolve) => {
    const t = setTimeout(() => resolve(), ms);
    void settleFetchInFlight!.then(
      () => { clearTimeout(t); resolve(); },
      () => { clearTimeout(t); resolve(); },
    );
  });
  return !!(settleCache && settleCache.data.length > 0);
}

/** Read-only snapshot of the in-memory settlement cache (for klines partials). */
export function peekSettlementCache(): KalshiSettlement[] {
  return settleCache?.data ? settleCache.data.slice() : [];
}

/**
 * Build OHLC from whatever settlements are already cached — sync, no network.
 * Used by GET /btc/klines so 4h/1d never return [] just because pagination
 * exceeded KLINES_WAIT_MS on a cold multi-page fetch.
 */
export function candlesFromSettlementCache(intervalMins: number, limit: number): OHLC[] {
  const settlements = settleCache?.data;
  if (!settlements || settlements.length === 0) return [];
  if (intervalMins >= 15) {
    return buildOHLCFromSettlements(settlements, intervalMins).slice(-limit);
  }
  // Sub-15m: same linear subdivision as fetchKalshiCandles (display only).
  const bucketsIn15m = Math.round(15 / intervalMins);
  const points = settlements.map((s, i) => ({
    ts:     s.openTs > 0 ? s.openTs : s.ts - 15 * 60,
    open:   s.floorStrike,
    close:  i + 1 < settlements.length ? settlements[i + 1].floorStrike : s.floorStrike,
    volume: s.volume,
  }));
  const subCandles: OHLC[] = [];
  const subSec = intervalMins * 60;
  for (const p of points) {
    const priceRange = p.close - p.open;
    const periodStart = p.ts;
    const subVolume = p.volume / bucketsIn15m;
    for (let b = 0; b < bucketsIn15m; b++) {
      const fracStart = b / bucketsIn15m;
      const fracEnd = (b + 1) / bucketsIn15m;
      const subOpen = p.open + priceRange * fracStart;
      const subClose = p.open + priceRange * fracEnd;
      subCandles.push({
        time: periodStart + b * subSec,
        open: Math.round(subOpen * 100) / 100,
        high: Math.max(subOpen, subClose),
        low: Math.min(subOpen, subClose),
        close: Math.round(subClose * 100) / 100,
        volume: subVolume,
      });
    }
  }
  return subCandles.slice(-limit);
}

// 2026-08-04 fix: this used to fetch a single page (capped at 1000 rows) and
// return `items.slice(0, limit)` — the FIRST `limit` rows of an oldest→newest
// array. For any `limit` smaller than the cached page (i.e. every sub-1h chart
// timeframe), that sliced off the *most recent* settlements and served the
// *oldest* ones in the page instead — so 1m/5m/15m/30m/1h charts were showing
// real but multi-day-STALE data while longer timeframes (whose `limit` happened
// to saturate the whole cached page) looked current. Longer timeframes were
// separately capped to whatever fit in one page (~10 days), even though weeks
// of real settlement history exist. Fixed via: (a) always returning the most
// recent `limit` rows (`.slice(-limit)`), and (b) paginating through Kalshi's
// `cursor` to actually fetch that deeper history when a caller needs more than
// one page's worth.
export type FetchSettlementsOpts = {
  /** Override SETTLE_MAX_PAGES. Full-history backfill passes a higher cap and pages until exhausted. */
  maxPages?: number;
};

export async function fetchKalshiSettlements(
  limit  = 720,
  series = KALSHI_SERIES_15M,
  forceRefresh = false,
  opts?: FetchSettlementsOpts,
): Promise<KalshiSettlement[]> {
  const maxPages = opts?.maxPages ?? SETTLE_MAX_PAGES;
  // Cache hit: serve immediately if fresh, AND either it already holds enough
  // rows to satisfy this request or we've already confirmed (via `exhausted`)
  // that no more real history exists to page in. Without the `exhausted`
  // escape hatch, a small early caller (e.g. a 720-row backfill request)
  // would cache exactly 1000 rows and every later caller asking for deeper
  // history (e.g. a 60-day chart needing 5760) would be silently capped to
  // that same 1000 for the rest of the TTL window.
  // Data is sorted oldest → newest, so the most recent `limit` rows are the tail.
  if (
    !forceRefresh &&
    settleCache &&
    Date.now() - settleCache.ts < SETTLE_CACHE_TTL_MS &&
    (settleCache.data.length >= limit || settleCache.exhausted)
  ) {
    return settleCache.data.slice(-limit);
  }

  // 429 cooldown: serve stale cache (or []) — do not start another page-1 walk.
  if (!forceRefresh && Date.now() < settle429UntilMs) {
    if (settleCache?.data?.length) return settleCache.data.slice(-limit);
    return [];
  }

  // Coalesce: if another caller is already paging Kalshi, wait for it then
  // re-check the cache instead of starting a competing walk (cold 4h+1m races).
  if (settleFetchInFlight) {
    try { await settleFetchInFlight; } catch { /* ignore */ }
    if (
      settleCache &&
      Date.now() - settleCache.ts < SETTLE_CACHE_TTL_MS &&
      (settleCache.data.length >= limit || settleCache.exhausted)
    ) {
      return settleCache.data.slice(-limit);
    }
    // Cache still short — fall through to extend (will coalesce again below).
  }

  // Kalshi paginates settled markets newest → oldest via an opaque `cursor`.
  // Page backward in time until we have enough rows to satisfy `limit`, we run
  // out of real history (a page comes back short/empty), or we hit the safety cap.
  const collected: KalshiSettlement[] = [];
  let cursor: string | undefined;
  let pages = 0;
  let exhausted = false;   // true once a short/empty page confirms real history has run out

  // Mark in-flight so concurrent callers await this walk instead of racing Kalshi.
  let resolveInflight!: (rows: KalshiSettlement[]) => void;
  settleFetchInFlight = new Promise<KalshiSettlement[]>((resolve) => {
    resolveInflight = resolve;
  });

  try {
    do {
      const params = new URLSearchParams({
        series_ticker: series,
        status: "settled",
        limit: String(SETTLE_PAGE_SIZE),
      });
      if (cursor) params.set("cursor", cursor);
      const qs   = params.toString();
      const path = `/trade-api/v2/markets?${qs}`;
      const url  = `${KALSHI_REST_BASE}/markets?${qs}`;

      let headers: Record<string, string> = { Accept: "application/json" };
      try {
        headers = { ...headers, ...kalshiAuthHeaders("GET", path) };
      } catch {
        // Market data is public; auth failure is non-fatal here
      }

      let r: Response | null = null;
      for (let attempt = 0; attempt < 3; attempt++) {
        r = await fetch(url, { headers, signal: AbortSignal.timeout(15_000) });
        if (r.ok) break;
        if (r.status !== 429 && r.status !== 503) break;
        const waitMs = Math.min(120_000, 15_000 * 2 ** attempt);
        const now = Date.now();
        if (now - settle429WarnedAt > 60_000) {
          console.warn(`[kalshi-price] settlements page ${pages + 1} → ${r.status}, backoff ${waitMs}ms (cooldown ${SETTLE_429_COOLDOWN_MS}ms)`);
          settle429WarnedAt = now;
        }
        settle429UntilMs = Math.max(settle429UntilMs, now + SETTLE_429_COOLDOWN_MS);
        await new Promise(res => setTimeout(res, waitMs));
      }
      if (!r || !r.ok) {
        if (r && (r.status === 429 || r.status === 503)) {
          settle429UntilMs = Math.max(settle429UntilMs, Date.now() + SETTLE_429_COOLDOWN_MS);
        }
        console.debug(`[kalshi-price] settlements page ${pages + 1} → ${r?.status ?? "no-response"}`);
        break;
      }

      const body = (await r.json()) as {
        cursor?: string;
        markets?: Array<{
          ticker:       string;
          floor_strike: number;
          result?:      string;
          open_time?:   string;
          close_time?:  string;
          settle_time?: string;
          volume_fp?:   string;   // real contracts traded on this market, Kalshi-reported
        }>;
      };

      const rawMarkets = body.markets ?? [];
      const pageItems: KalshiSettlement[] = rawMarkets
        .filter(m => m.floor_strike > 0 && (m.result === "yes" || m.result === "no"))
        .map(m => {
          // Safely parse timestamps — missing fields produce NaN (not epoch 0).
          const rawTs   = m.settle_time ?? m.close_time;
          const rawOpen = m.open_time;
          const ts     = rawTs   ? Math.round(new Date(rawTs).getTime()   / 1000) : 0;
          const openTs = rawOpen ? Math.round(new Date(rawOpen).getTime() / 1000) : 0;
          const volume = m.volume_fp ? parseFloat(m.volume_fp) : 0;
          return {
            ts, openTs, floorStrike: m.floor_strike, result: m.result as 'yes' | 'no', ticker: m.ticker,
            volume: Number.isFinite(volume) && volume > 0 ? volume : 0,
          };
        })
        .filter(m => m.ts > 0);

      pages++;
      if (maxPages > SETTLE_MAX_PAGES) await new Promise(res => setTimeout(res, 2500));
      // A RAW page shorter than the full page size means we've reached the true
      // start of this series' settlement history — no cursor will produce more.
      // Must check the raw (pre-filter) count: a handful of markets missing a
      // valid result/timestamp can shrink `pageItems` below SETTLE_PAGE_SIZE on
      // a page that is otherwise mid-history, which previously set `exhausted`
      // too early and silently capped every deeper (longer-timeframe) request
      // for the rest of the cache TTL.
      if (rawMarkets.length < SETTLE_PAGE_SIZE) exhausted = true;
      if (pageItems.length === 0 && rawMarkets.length === 0) break;
      collected.push(...pageItems);
      // Publish after every page so /btc/klines can serve settle-partial mid-fetch
      // instead of waiting for the full multi-page walk (4h cold was timing out empty).
      {
        const prior = exhausted ? [] : (settleCache?.data ?? []);
        const byTicker = new Map(prior.map(c => [c.ticker, c]));
        for (const c of collected) byTicker.set(c.ticker, c);
        settleCache = {
          data: Array.from(byTicker.values()).sort((a, b) => a.ts - b.ts),
          ts: Date.now(),
          exhausted: exhausted || (settleCache?.exhausted === true),
        };
      }
      cursor = body.cursor;
    } while (cursor && !exhausted && collected.length < limit && pages < maxPages);
  } catch (err) {
    console.debug(`[kalshi-price] fetchKalshiSettlements error: ${(err as Error).message}`);
    const fallback = settleCache?.data.slice(-limit) ?? [];
    resolveInflight(fallback);
    settleFetchInFlight = null;
    return fallback;
  }

  if (collected.length === 0) {
    console.debug(`[kalshi-price] settlements fetch returned nothing — returning cache (${settleCache?.data.length ?? 0} rows)`);
    const fallback = settleCache?.data.slice(-limit) ?? [];
    resolveInflight(fallback);
    settleFetchInFlight = null;
    return fallback;
  }

  // De-dupe + merge with prior cache so a concurrent smaller fetch cannot
  // wipe deeper history another caller already paged in.
  // When this walk exhausted from the series start, `collected` IS the full
  // history — do not retain prior-cache tickers the exhausted walk never saw
  // (stale deeper pages from a different fake/universe or aborted walk).
  const prior = exhausted ? [] : (settleCache?.data ?? []);
  const byTicker = new Map(prior.map(c => [c.ticker, c]));
  for (const c of collected) byTicker.set(c.ticker, c);
  const items = Array.from(byTicker.values()).sort((a, b) => a.ts - b.ts);

  settleCache = {
    data: items,
    ts: Date.now(),
    exhausted: exhausted || (settleCache?.exhausted === true),
  };
  console.debug(`[kalshi-price] fetched ${items.length} settlements across ${pages} page(s) (${series})${exhausted ? ' — reached start of history' : ''}`);
  const out = items.slice(-limit);
  resolveInflight(out);
  settleFetchInFlight = null;
  return out;
}

// ── OHLC builder ──────────────────────────────────────────────────────────────
//
// Constructs synthetic OHLC candles from a sorted array of 15-min settlements.
//
// Price mapping per 15-min period N:
//   open[N]  = floorStrike[N]         (BRTI at period open)
//   close[N] = floorStrike[N+1]       (next period's floor ≈ BRTI at period close)
//   high/low = range of open/close values within the bucket
//
// For the last period we have no N+1 floor, so close ≈ open (same price).

export function buildOHLCFromSettlements(
  settlements: KalshiSettlement[],  // sorted oldest → newest
  intervalMins: number,
): OHLC[] {
  if (settlements.length === 0) return [];

  // Build synthetic price points: close[N] = floorStrike of next period.
  // Use openTs (period START, always a clean UTC boundary) as the time key,
  // not ts (settle_time, which is ≈ period END). Using settle_time pushes the
  // last 15-min period of every higher-resolution bucket (1h, 4h, 1d) into the
  // NEXT bucket — e.g. the 14:45–15:00 period's settle_time is 15:00, which
  // falls into the 15:00 1h bucket instead of the correct 14:00 bucket, silently
  // dropping it from the 14:00 candle and causing higher-interval candles to
  // include only 3 of every 4 periods.
  const points = settlements.map((s, i) => ({
    ts:     s.openTs > 0 ? s.openTs : s.ts - 15 * 60,  // period START; fall back to ts-900 if openTs missing
    open:   s.floorStrike,
    close:  i + 1 < settlements.length ? settlements[i + 1].floorStrike : s.floorStrike,
    volume: s.volume,
  }));

  const intervalSec = intervalMins * 60;
  const candles: OHLC[] = [];
  let i = 0;

  while (i < points.length) {
    const bucketStart = points[i].ts - (points[i].ts % intervalSec);
    const group: typeof points = [];

    while (i < points.length && points[i].ts < bucketStart + intervalSec) {
      group.push(points[i++]);
    }
    if (group.length === 0) continue;

    const allPx = group.flatMap(p => [p.open, p.close]);
    candles.push({
      time:   bucketStart,
      open:   group[0].open,
      high:   Math.max(...allPx),
      low:    Math.min(...allPx),
      close:  group[group.length - 1].close,
      // Real per-market volume (Kalshi's own volume_fp), summed across every
      // 15-min settlement that falls in this bucket.
      volume: group.reduce((sum, p) => sum + p.volume, 0),
    });
  }

  return candles;
}

// ── Convenience wrapper: fetch + build ────────────────────────────────────────
//
// Drop-in replacement for fetchKrakenCandles(intervalMins, limit).
//
// For intervals >= 15m: fetches Kalshi settlements and aggregates to the
//   requested granularity via buildOHLCFromSettlements.
//
// For sub-15m intervals (e.g. 5m, 1m): each 15-min settlement is subdivided
//   into equal synthetic sub-candles using linear interpolation. OHLC values
//   represent smooth price paths within the period. Real per-market volume
//   is split evenly across the sub-candles (no finer-grained volume exists).

export async function fetchKalshiCandles(
  intervalMins: number,
  limit        = 500,
  opts?: FetchSettlementsOpts,
): Promise<OHLC[]> {
  if (intervalMins >= 15) {
    // Need enough 15m settlements to build the requested number of candles.
    // Capped at SETTLE_MAX_TOTAL (not a single Kalshi page) so longer
    // timeframes can actually pull the real multi-week history via pagination
    // instead of silently truncating to whatever fit in one page.
    // opts.maxPages lets /btc/klines bound the wait (serve partial, refresh deeper).
    const settlementsNeeded = limit * Math.ceil(intervalMins / 15);
    const settlements = await fetchKalshiSettlements(
      Math.min(settlementsNeeded, SETTLE_MAX_TOTAL),
      KALSHI_SERIES_15M,
      false,
      opts,
    );
    const candles = buildOHLCFromSettlements(settlements, intervalMins);
    return candles.slice(-limit);
  }

  // Sub-15m: subdivide each 15m settlement into equal sub-candles
  const bucketsIn15m  = Math.round(15 / intervalMins);   // e.g. 3 for 5m, 15 for 1m
  const settlementsNeeded = Math.ceil(limit / bucketsIn15m) + 2;
  const settlements = await fetchKalshiSettlements(
    Math.min(settlementsNeeded, SETTLE_MAX_TOTAL),
    KALSHI_SERIES_15M,
    false,
    opts,
  );

  const points = settlements.map((s, i) => ({
    ts:     s.openTs > 0 ? s.openTs : s.ts - 15 * 60,  // period START (openTs preferred; fallback ts-900)
    open:   s.floorStrike,
    close:  i + 1 < settlements.length ? settlements[i + 1].floorStrike : s.floorStrike,
    volume: s.volume,
  }));

  const subCandles: OHLC[] = [];
  const subSec = intervalMins * 60;

  for (const p of points) {
    const priceRange  = p.close - p.open;
    const periodStart = p.ts;  // p.ts is already the period START (openTs or ts-900 fallback)
    // No finer-grained volume data exists within a 15-min period, so split
    // the period's real traded volume evenly across its sub-candles.
    const subVolume = p.volume / bucketsIn15m;
    for (let b = 0; b < bucketsIn15m; b++) {
      const fracStart = b / bucketsIn15m;
      const fracEnd   = (b + 1) / bucketsIn15m;
      const subOpen   = p.open + priceRange * fracStart;
      const subClose  = p.open + priceRange * fracEnd;
      subCandles.push({
        time:   periodStart + b * subSec,
        open:   Math.round(subOpen * 100) / 100,
        high:   Math.max(subOpen, subClose),
        low:    Math.min(subOpen, subClose),
        close:  Math.round(subClose * 100) / 100,
        volume: subVolume,
      });
    }
  }

  return subCandles.slice(-limit);
}

// ── Convenience: current BTC price from Kalshi WS tick ────────────────────────
//
// Intended for callers that don't have direct access to the WS singleton
// (e.g. route handlers).  Returns BTC_FLOOR_FALLBACK if no fresh tick is
// available within 30 s.

/**
 * Quote-clock freshness for BRTI inference. WS heartbeats re-stamp `ts` while
 * carrying forward an old book — `quoteTs` is the last real bid/ask. Prefer
 * quoteTs; fall back to ts only when quoteTs is missing (legacy ticks).
 */
export function kalshiTickQuoteAgeMs(tick: Pick<KalshiTick, "ts"> & { quoteTs?: number }, nowMs = Date.now()): number {
  const q = typeof tick.quoteTs === "number" && tick.quoteTs > 0 ? tick.quoteTs : tick.ts;
  return Math.max(0, nowMs - q);
}

export function getCurrentBtcPriceFromKalshi(
  getLatestTick: () => KalshiTick | null,
  staleMs = 30_000,
): number {
  const tick = getLatestTick();
  // BRTI-vs-last: never treat a heartbeat-refreshed `ts` as a fresh book.
  // inferBtcPrice reads bid/ask — those are quoteTs-aged, not message-aged.
  if (tick && kalshiTickQuoteAgeMs(tick) < staleMs) {
    return inferBtcPrice(tick);
  }
  return BTC_FLOOR_FALLBACK;
}

// ── Cache invalidation (called when the WS rolls over to a new period) ────────

export function lastSettlementsFetchExhausted(): boolean {
  return settleCache?.exhausted === true;
}

export function invalidateSettlementCache(): void {
  if (settleCache) {
    // Keep the data but mark as stale so the next fetch refreshes
    settleCache.ts = 0;
  }
}

/** Test-only: drop in-memory settlements so pagination cases cannot bleed. */
export function resetSettlementCacheForTests(): void {
  settleCache = null;
  settleFetchInFlight = null;
}
