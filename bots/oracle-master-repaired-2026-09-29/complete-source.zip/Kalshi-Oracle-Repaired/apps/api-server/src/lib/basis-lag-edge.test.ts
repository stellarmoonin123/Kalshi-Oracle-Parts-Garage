import assert from "node:assert/strict";
import test from "node:test";
import { getStrategy, type StrategyObservation } from "./strategy-library.js";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  classifyLagUnprovenGate,
  evaluateBasisLagEdge,
  lagSideConfirmationAgrees,
  basisLagWinRate,
  basisLagEvidenceConfidence,
  LAG_CHEAP_ASK_CENTS,
  emptyOrigLagProjStreak,
  updateOrigLagProjStreak,
  liveOrigLagStreakOnObs,
  BASIS_LAG_MIN_TIME_MINS,
  BASIS_LAG_MAX_TIME_MINS,
} from "./basis-lag-edge.js";
import { computeTradeEV } from "./trade-path.js";
import { EV_FLOOR } from "./admission.js";
import { shouldSkipConfidenceFloor, ticketEVCentsFromP, moneyMakerConfFloorSideAgrees } from "./confidence-floor.js";
import { withWinCurveModel, WIN_CURVE_LEGACY_MODEL_VERSION } from "./win-curve-refit.js";

const strategy = getStrategy('BASIS_LAG_EDGE');
if (!strategy) throw new Error("BASIS_LAG_EDGE strategy not found");

function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: 'none',
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60, // 5 min left — inside the 3-10 min preferred window
    projectedSettlementPrice: 65130,     // +0.20% from floor -> isLong
    rollingBasis: 8,                     // > 5 -> structural-basis confidence boost
    basisShort: 8,                       // agrees with the long direction
    basisStreakCount: 4,
    basisStreakSign: 1,
    lagStale: false,
    lagProven: true,
    lagDollars: 40,
    leaderName: "coinbase",
    leadSeconds: 8,
    leadDollars: 40,
    proofHitRate: 0.8,
    yesAsk: 30,
    yesBid: 28,
    noAsk: 68,
    noBid: 66,
    ...overrides,
  };
}

test("BASIS_LAG_EDGE fires on a persistent, well-priced, positive-EV lag", () => {
  const result = strategy.evaluate(baseObs());
  assert.ok(result, "expected the strategy to fire");
  assert.equal(result!.signal, 'YES');
  assert.equal(result!.strategyId, 'BASIS_LAG_EDGE');
});

test("BASIS_LAG_EDGE blocks a single-tick spike (streak below the persistence threshold)", () => {
  const result = strategy.evaluate(baseObs({ basisStreakCount: 1 }));
  assert.equal(result, null, "a 1-tick streak must not be enough to trade");
});

test("BASIS_LAG_EDGE blocks when the streak sign disagrees with the trade direction", () => {
  // Projection says long (exchange should be leading upward), but the basis
  // tracker's confirmed streak is currently on the opposite side — the lag
  // isn't actually confirmed in the direction we'd be trading.
  const result = strategy.evaluate(baseObs({ basisStreakSign: -1, basisStreakCount: 5 }));
  assert.equal(result, null);
});

test("BASIS_LAG_EDGE blocks when fee/slippage-adjusted EV is negative even with a nominal edge", () => {
  // Expensive side (>=80c) with just-barely-enough nominal edge to clear the
  // graduated MIN_EDGE_PTS floor, but the win-rate curve for an 82c entry is
  // far too low to produce positive EV at that price.
  const result = strategy.evaluate(baseObs({
    projectedSettlementPrice: 65102, // ~0.157% -> impliedProb ~97
    yesAsk: 82,
    yesBid: 80,
  }));
  assert.equal(result, null, "a negative-EV setup must never fire even if the raw point-edge looks large enough");
});

test("BASIS_LAG_EDGE requires a larger edge outside the preferred 3-10 minute window", () => {
  const outsideWindow = baseObs({
    secsRemaining: 12 * 60, // inside the hard 2-15min bound, outside preferred 3-10
    projectedSettlementPrice: 65065, // ~0.10% -> impliedProb ~80c
    yesAsk: 68, yesBid: 66, // edge ~12pt: clears the base 8pt floor but not the 18pt large-edge override
  });
  const blocked = strategy.evaluate(outsideWindow);
  assert.equal(blocked, null, "a modest edge should not be enough to trade outside the preferred window");

  const strongerEdge = baseObs({
    secsRemaining: 12 * 60,
    projectedSettlementPrice: 65200, // ~0.31% -> large edge, allowed to override the window preference
  });
  const fired = strategy.evaluate(strongerEdge);
  assert.ok(fired, "a large enough edge should still be allowed to trade outside the preferred window");
});

test("BASIS_LAG_EDGE respects the hard 2-15 minute bounds regardless of edge size", () => {
  assert.equal(strategy.minTimeMins, BASIS_LAG_MIN_TIME_MINS);
  assert.equal(strategy.maxTimeMins, BASIS_LAG_MAX_TIME_MINS, "meta max=15; stale 13 starved evaluateAllStrategies");
  const tooLate = baseObs({ secsRemaining: 60 }); // 1 min left, below the hard minTimeMins
  assert.equal(strategy.evaluate(tooLate), null);

  const tooEarly = baseObs({ secsRemaining: 16 * 60 }); // 16 min left, above the hard maxTimeMins
  assert.equal(strategy.evaluate(tooEarly), null);

  // Fill-power: gold 14–15m must not be hard-nulled (old max=13 starved bar-open).
  assert.ok(strategy.evaluate(baseObs({ secsRemaining: 15 * 60 })), "15m inclusive hard max");
  assert.ok(strategy.evaluate(baseObs({ secsRemaining: 14 * 60 })), "14m gold window fires with large edge");
});

test("gold 14–15m hard window open; preferred 3–10 still requires large edge", () => {
  // Hard max=15 un-starves evaluate at bar-open. Preferred stays 3–10:
  // modest edge at 14m still OUTSIDE_WINDOW (do not loosen preferred / EV).
  const modest14 = baseObs({
    secsRemaining: 14 * 60,
    projectedSettlementPrice: 65065, // ~0.10% -> impliedProb ~80c
    yesAsk: 68, yesBid: 66, // edge ~12pt: clears 8pt floor but not 18pt large-edge
  });
  assert.equal(strategy.evaluate(modest14), null, "14m modest edge must not bypass preferred");
  const large14 = baseObs({
    secsRemaining: 14 * 60,
    projectedSettlementPrice: 65200, // large edge override
  });
  assert.ok(strategy.evaluate(large14), "14m + large edge fires after fill-power widen");
});

// Gate mechanics pinned to the legacy hand-tuned curve (refit covered in win-curve-refit.test.ts).
test("BASIS_LAG_EDGE winRateAtPrice is monotonically non-increasing in entry price", () => withWinCurveModel(WIN_CURVE_LEGACY_MODEL_VERSION, () => {
  const wrCheap = strategy.winRateAtPrice!(25, 5);
  const wrMid   = strategy.winRateAtPrice!(60, 5);
  const wrRich  = strategy.winRateAtPrice!(85, 5);
  assert.ok(wrCheap >= wrMid && wrMid >= wrRich, `expected non-increasing curve, got ${wrCheap}, ${wrMid}, ${wrRich}`);
  assert.ok(wrCheap <= 0.58 && wrRich >= 0.40 && wrRich < 0.52, "tape-calibrated bounds, not confidence 0.52–0.72");
  assert.ok(strategy.winRateAtPrice!(42, 5) < 0.62, "must not track the 0.62 confidence baseline");
}));

test("BASIS_LAG_EDGE proven+stale+lead proceeds even with lagStale (live pid 2706289)", () => {
  const liveSkipWas = baseObs({
    lagStale: true, lagProven: true, leadSeconds: 19, leadDollars: -17, lagDollars: 40,
  });
  const g = classifyLagUnprovenGate({
    lagProven: true, lagStale: true, leadSeconds: 19, leadDollars: -17,
  });
  assert.equal(g.kind, "PROVEN");
  assert.equal(g.proceed, true);
  assert.ok(strategy.evaluate(liveSkipWas), "live pid ORIGINAL_LOCK on lagStale alone must not skip proven+lead");
  assert.ok(strategy.evaluate({ ...liveSkipWas, paperMode: true }), "paper=live proven+stale+lead");
  const provenNoLead = classifyLagUnprovenGate({
    lagProven: true, lagStale: true, leadSeconds: undefined, leadDollars: undefined,
  });
  assert.equal(provenNoLead.kind, "PROVEN");
  assert.equal(provenNoLead.proceed, true, "ORIGINAL_LOCK only if no proven AND no lead");
  assert.ok(strategy.evaluate(baseObs({
    lagStale: true, lagProven: true, leadSeconds: undefined, leadDollars: undefined, lagDollars: 40,
  })), "proven+stale+no-lead still proceeds");
});

test("BASIS_LAG_EDGE skips when lagDollars disagrees with YES", () => {
  const result = strategy.evaluate(baseObs({ lagStale: false, lagDollars: -40 }));
  assert.equal(result, null);
});

test("BASIS_LAG_EDGE skips when |lagDollars| < $16", () => {
  const result = strategy.evaluate(baseObs({ lagStale: false, lagDollars: 5 }));
  assert.equal(result, null);
});

test("BASIS_LAG_EDGE lagStale omitted + proven proceeds (ORIGINAL_LOCK needs !proven and !lead)", () => {
  assert.ok(strategy.evaluate(baseObs({ lagStale: undefined, lagDollars: 40, lagProven: true, leadSeconds: 19, leadDollars: -17 })));
  assert.ok(strategy.evaluate(baseObs({
    lagStale: undefined, lagProven: true, leadSeconds: undefined, leadDollars: undefined, lagDollars: 40,
  })));
  assert.equal(strategy.evaluate(baseObs({
    lagStale: undefined, lagProven: false, leadSeconds: undefined, leadDollars: undefined, lagDollars: 40,
  })), null, "unproven skip even with finite Coinbase $");
  assert.equal(strategy.evaluate(baseObs({
    lagStale: undefined, lagProven: false, leadSeconds: undefined, leadDollars: undefined, lagDollars: undefined,
  })), null);
});

test("paper=live: |lagDollars| 8.51 skips both; |lag$|>=16 fires both", () => {
  assert.equal(strategy.evaluate(baseObs({ lagStale: false, lagDollars: 8.51 })), null);
  assert.equal(strategy.evaluate(baseObs({ lagStale: false, lagProven: true, lagDollars: 8.51, paperMode: true })), null);
  const paper = strategy.evaluate(baseObs({ lagStale: false, lagProven: true, lagDollars: 20, paperMode: true }));
  assert.ok(paper, "paper |lag$|>=16 fires");
  assert.equal(paper!.strategyId, "BASIS_LAG_EDGE");
  assert.ok(strategy.evaluate(baseObs({ lagStale: false, lagProven: true, lagDollars: 20, paperMode: false })));
});

test("KEEP lag_disagrees when lagStale==false and live lag$ fights (paper+live)", () => {
  const paper = strategy.evaluate(baseObs({ lagStale: false, lagProven: true, lagDollars: -40, paperMode: true }));
  assert.equal(paper, null, "paper KEEP lag_disagrees on proven live lag$");
  assert.equal(strategy.evaluate(baseObs({ lagStale: false, lagProven: true, lagDollars: -40 })), null, "live disagree still skip");
});

test("classifyLagUnprovenGate: PROVEN proceeds", () => {
  const g = classifyLagUnprovenGate({
    lagProven: true, lagStale: false, leadSeconds: 8, leadDollars: 40, proofHitRate: 0.8, sideAsk: 30,
  });
  assert.equal(g.kind, "PROVEN");
  assert.equal(g.proceed, true);
  const fired = evaluateBasisLagEdge(baseObs({ lagProven: true, lagStale: false, paperMode: false }));
  assert.ok(fired, "proven proceeds live");
  assert.ok(evaluateBasisLagEdge(baseObs({ lagProven: true, lagStale: false, paperMode: true })), "proven proceeds paper");
});

test("classifyLagUnprovenGate: remake overlay <=55 is unproven skip paper=live", () => {
  const overlay = {
    lagProven: false as const,
    lagStale: false as const,
    leadSeconds: 5,
    leadDollars: 15,
    proofHitRate: 0.5,
    lagDollars: 40,
    yesAsk: 30,
  };
  const g = classifyLagUnprovenGate({ ...overlay, sideAsk: 30 });
  assert.equal(g.kind, "ORIGINAL_LOCK");
  assert.equal(g.proceed, false);
  assert.equal(g.reasonCode, "LAG_UNPROVEN");
  const live = evaluateBasisLagEdge(baseObs({ ...overlay, paperMode: false }));
  const paper = evaluateBasisLagEdge(baseObs({ ...overlay, paperMode: true }));
  assert.equal(live, null, "unproven remake overlay skip live");
  assert.equal(paper, null, "unproven remake overlay skip paper");
});

test("classifyLagUnprovenGate: remake overlay >55 still blocked (do not widen fully priced)", () => {
  const overlay = {
    lagProven: false as const,
    lagStale: false as const,
    leadSeconds: 5,
    leadDollars: 15,
    proofHitRate: 0.5,
    lagDollars: 40,
    yesAsk: 68,
    yesBid: 66,
  };
  const g = classifyLagUnprovenGate({ ...overlay, sideAsk: 68 });
  assert.equal(g.kind, "ORIGINAL_LOCK");
  assert.equal(g.proceed, false);
  assert.ok(g.reasonCode === "LAG_UNPROVEN");
  assert.ok(68 > LAG_CHEAP_ASK_CENTS);
  assert.equal(evaluateBasisLagEdge(baseObs({ ...overlay, paperMode: false })), null);
  assert.equal(evaluateBasisLagEdge(baseObs({ ...overlay, paperMode: true })), null);
});

test("classifyLagUnprovenGate: ORIGINAL_LOCK only if no proven AND no lead", () => {
  const staleProven = classifyLagUnprovenGate({
    lagProven: true, lagStale: true, leadSeconds: undefined, leadDollars: undefined, sideAsk: 30,
  });
  assert.equal(staleProven.kind, "PROVEN");
  assert.equal(staleProven.proceed, true);
  const dollarsOnly = classifyLagUnprovenGate({
    lagProven: false, lagStale: false, leadSeconds: 0, leadDollars: 15, proofHitRate: 0, sideAsk: 30,
  });
  assert.equal(dollarsOnly.kind, "ORIGINAL_LOCK");
  assert.equal(dollarsOnly.proceed, false, "unproven skip even with finite lead$");
  const noLead = classifyLagUnprovenGate({
    lagProven: false, lagStale: false, leadSeconds: 0, leadDollars: undefined, proofHitRate: 0, sideAsk: 30,
  });
  assert.equal(noLead.kind, "ORIGINAL_LOCK");
  assert.equal(noLead.proceed, false);
  for (const paperMode of [true, false]) {
    assert.ok(evaluateBasisLagEdge(baseObs({
      paperMode, lagStale: true, lagProven: true, lagDollars: 40, leadSeconds: undefined, leadDollars: undefined,
    })), `proven+stale proceeds paperMode=${paperMode}`);
    const missing = evaluateBasisLagEdge(baseObs({
      paperMode, lagStale: true, lagProven: false, lagDollars: undefined, leadSeconds: undefined, leadDollars: undefined,
    }));
    assert.equal(missing, null, `unproven skip paperMode=${paperMode}`);
    const noLeadEval = evaluateBasisLagEdge(baseObs({
      paperMode, lagStale: false, lagProven: false, leadSeconds: 0, leadDollars: undefined, lagDollars: undefined,
    }));
    assert.equal(noLeadEval, null, `unproven no-lead skip paperMode=${paperMode}`);
    assert.equal(evaluateBasisLagEdge(baseObs({
      paperMode, lagStale: false, lagProven: false, leadSeconds: 0, leadDollars: undefined, lagDollars: 40,
    })), null, `unproven skip even with Coinbase $ paperMode=${paperMode}`);
  }
});

test("never fake lag seconds on ORIGINAL_LOCK", () => {
  const g = classifyLagUnprovenGate({ lagProven: false, lagStale: true });
  assert.equal(g.proceed, false);
  assert.equal(/5–15s|5-15s/.test(g.reason) && /never fake/.test(g.reason), true);
  assert.equal(g.reason.includes("invent") || g.reason.includes("missing") || g.reason.includes("ORIGINAL_LOCK"), true);
});

test("lagGate0 omits sideAsk: unproven still ORIGINAL_LOCK (no remake defer)", () => {
  const noAsk = classifyLagUnprovenGate({
    lagProven: false, lagStale: true, leadSeconds: 19, leadDollars: -17, proofHitRate: 0.6,
  });
  assert.equal(noAsk.kind, "ORIGINAL_LOCK");
  assert.equal(noAsk.proceed, false);
  const cheap = classifyLagUnprovenGate({
    lagProven: false, lagStale: true, leadSeconds: 19, leadDollars: -17, proofHitRate: 0.6, sideAsk: 30,
  });
  assert.equal(cheap.proceed, false);
  const rich = classifyLagUnprovenGate({
    lagProven: false, lagStale: true, leadSeconds: 19, leadDollars: -17, proofHitRate: 0.6, sideAsk: 68,
  });
  assert.equal(rich.proceed, false);
  assert.equal(evaluateBasisLagEdge(baseObs({
    lagProven: false, lagStale: true, leadSeconds: 19, leadDollars: -17, lagDollars: 40, yesAsk: 30, paperMode: true,
  })), null, "paper unproven skip");
  assert.equal(evaluateBasisLagEdge(baseObs({
    lagProven: false, lagStale: true, leadSeconds: 19, leadDollars: -17, lagDollars: 40, yesAsk: 30, paperMode: false,
  })), null, "live unproven skip");
});

test("never invent 5–15s in classifier reasons", () => {
  const g = classifyLagUnprovenGate({ lagProven: true, lagStale: true, leadSeconds: 19, leadDollars: -17 });
  assert.equal(/\b5-15s\b|invented 5/.test(g.reason), false);
});

test("BASIS_LAG_EDGE fires NO when proj is below floor and NO is cheap (P(side) not P(YES))", () => {
  // 111000 vs 111200 floor: projDistPct ≈ −0.180%. Signed impliedProb used to
  // clamp at 5c, then 5 − noAsk 36 → negative edge and cheap NO starved.
  // P(our side settles) = clamp(50 + abs(dist)*300, 5, 95) ≈ 95c → ~59pt edge.
  const result = strategy.evaluate(baseObs({
    paperMode: true,
    currentPrice: 111000,
    floorStrike: 111200,
    distFromFloorPct: ((111000 - 111200) / 111200) * 100,
    projectedSettlementPrice: 111000,
    rollingBasis: -8,
    basisShort: -8,
    basisStreakCount: 4,
    basisStreakSign: -1,
    lagDollars: -40,
    leadDollars: -40,
    yesAsk: 64,
    yesBid: 62,
    noAsk: 36,
    noBid: 34,
  }));
  assert.ok(result, "cheap NO 36c with proj below floor must FIRE, not starve");
  assert.equal(result!.signal, "NO");
  assert.equal(result!.strategyId, "BASIS_LAG_EDGE");
  const edgePts = (result!.edgePct ?? 0) * 100;
  assert.ok(edgePts > 40, `expected large positive edge vs 36c NO ask, got ${edgePts}pt`);
});

const EDGE_SRC = fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), "basis-lag-edge.ts"), "utf8");

test("local EV uses winRateAtPrice (basisLagWinRate), not confidence-boosted conf", () => {
  assert.match(EDGE_SRC, /const pWin = basisLagWinRate\(sideAsk, minLeft\)/);
  assert.match(EDGE_SRC, /winRate:\s+pWin/);
  assert.equal(/winRate:\s+conf/.test(EDGE_SRC), false);
  assert.match(EDGE_SRC, /Math\.abs\(projDistPct\)/);
  const ask = 30;
  const p = basisLagWinRate(ask, 5);
  const boosted = Math.min(0.80, p + 0.12 + 0.03 + 0.02);
  assert.ok(boosted > p, "confidence boost must not leak into p");
  const evP = computeTradeEV({
    entryPriceCents: ask, winRate: p, strategyId: "BASIS_LAG_EDGE", secsRemaining: 300,
  });
  const evConf = computeTradeEV({
    entryPriceCents: ask, winRate: boosted, strategyId: "BASIS_LAG_EDGE", secsRemaining: 300,
  });
  assert.ok(evConf.netEV > evP.netEV, "boosted conf would inflate local EV");
});

test("classifyLagUnprovenGate: down lead is not PROVEN for a YES ticket", () => {
  const yesDown = classifyLagUnprovenGate({
    lagProven: true, lagStale: false, leadSeconds: 19, leadDollars: -17, sideAsk: 30, side: "yes",
  });
  assert.notEqual(yesDown.kind, "PROVEN", "do not call a down lead PROVEN for YES");
  const yesUp = classifyLagUnprovenGate({
    lagProven: true, lagStale: false, leadSeconds: 19, leadDollars: 40, sideAsk: 30, side: "yes",
  });
  assert.equal(yesUp.kind, "PROVEN");
  const noDown = classifyLagUnprovenGate({
    lagProven: true, lagStale: false, leadSeconds: 19, leadDollars: -17, sideAsk: 30, side: "no",
  });
  assert.equal(noDown.kind, "PROVEN");
  const unlabeled = classifyLagUnprovenGate({
    lagProven: true, lagStale: true, leadSeconds: 19, leadDollars: -17,
  });
  assert.equal(unlabeled.kind, "PROVEN", "no side → keep live-pid proven overlay");
});


test("corr_junk + leadDollars +40 cheap YES 36 no fill (tau null, no fake seconds)", () => {
  const g = classifyLagUnprovenGate({
    lagProven: false, lagStale: true, leadSeconds: null, leadDollars: 40,
    lagDollars: null, lagReason: "corr_junk", sideAsk: 36, side: "yes",
  });
  assert.equal(g.kind, "ORIGINAL_LOCK");
  assert.equal(g.reasonCode, "LAG_UNPROVEN");
  assert.equal(g.proceed, false);
  assert.equal(/\b5-15s\b|invented 5/.test(g.reason), false);
  const fired = evaluateBasisLagEdge(baseObs({
    lagProven: false,
    lagStale: true,
    lagReason: "corr_junk",
    lagDollars: null,
    lagSeconds: null,
    leadSeconds: null,
    leadDollars: 40,
    yesAsk: 36,
    yesBid: 34,
    noAsk: 64,
    noBid: 62,
    paperMode: true,
  }));
  assert.equal(fired, null, "corr_junk no fill");
  const live = evaluateBasisLagEdge(baseObs({
    lagProven: false, lagStale: true, lagReason: "corr_junk",
    lagDollars: null, lagSeconds: null, leadSeconds: null, leadDollars: 40,
    yesAsk: 36, yesBid: 34, noAsk: 64, noBid: 62, paperMode: false,
  }));
  assert.equal(live, null, "paper=live corr_junk no fill");
});

test("leadDollars -40 vs YES is not proven (sign-aware)", () => {
  const g = classifyLagUnprovenGate({
    lagProven: true, lagStale: true, leadSeconds: null, leadDollars: -40,
    lagDollars: null, lagReason: "corr_junk", sideAsk: 36, side: "yes",
  });
  assert.notEqual(g.kind, "PROVEN");
  const fired = evaluateBasisLagEdge(baseObs({
    lagProven: true, lagStale: true, lagReason: "corr_junk",
    lagDollars: null, lagSeconds: null, leadSeconds: null, leadDollars: -40,
    yesAsk: 36, yesBid: 34, noAsk: 64, noBid: 62, paperMode: true,
  }));
  assert.equal(fired, null, "opposite-sign lead$ vs YES is not a cheap YES fire");
});

test("split-brain live vs snapshot projs SKIP — do not fill evaluate YES", () => {
  // #508: evaluate 77471 YES vs basisState 77024 NO. Fail-closed.
  const obs = baseObs({
    floorStrike: 77_200,
    currentPrice: 77_250,
    projectedSettlementPrice: 77_024, // snapshot NO
    estimatedFairBRTI: 77_471,
  basisLeadUsd: 77_471,        // live YES with vel 0
    velocityDolPerMin: 0,
    threeMinVelocity: 0,
    yesAsk: 30,
    yesBid: 28,
    noAsk: 70,
    noBid: 68,
    basisStreakSign: 1,
    basisStreakCount: 4,
    lagDollars: 40,
    lagProven: true,
    lagStale: false,
  });
  const result = evaluateBasisLagEdge(obs);
  assert.equal(result, null, "disagreeing projs must skip, not YES fill");
});

test("agreeing live+snapshot still can fire YES", () => {
  const obs = baseObs({
    projectedSettlementPrice: 65_130,
    estimatedFairBRTI: 65_130,
  basisLeadUsd: 65_130,
    velocityDolPerMin: 0,
    threeMinVelocity: 0,
  });
  const result = evaluateBasisLagEdge(obs);
  assert.ok(result, "same-side live+snapshot must still be able to fire");
  assert.equal(result!.signal, "YES");
});

test("lagSideConfirmationAgrees fail-closed when HA and CC missing", () => {
  assert.equal(lagSideConfirmationAgrees({ projSide: "YES", haRiverSide: null, ccFactorSide: null }), false);
  assert.equal(lagSideConfirmationAgrees({ projSide: "NO", haRiverSide: null, ccFactorSide: null }), false);
  assert.equal(lagSideConfirmationAgrees({ projSide: "YES", haRiverSide: "YES", ccFactorSide: null }), true);
  assert.equal(lagSideConfirmationAgrees({ projSide: "YES", haRiverSide: null, ccFactorSide: "YES" }), true);
  assert.equal(lagSideConfirmationAgrees({ projSide: "YES", haRiverSide: "NO", ccFactorSide: "NO" }), false);
  assert.equal(lagSideConfirmationAgrees({ projSide: "NO", haRiverSide: "YES", ccFactorSide: "YES" }), false);
});

test("LAG skips when proj YES and HA/CC NO", () => {
  const result = evaluateBasisLagEdge(baseObs({
    velocityDolPerMin: -90,
    threeMinVelocity: -85,
    distFromFloorPct: -1.2,
    massAboveFloor: 20,
    recentUpPct: 0.30,
    ohlc1m: undefined,
    ohlc5m: undefined,
  }));
  assert.equal(result, null, "proj YES vs CC/HA NO must SKIP not fill YES");
});

test("LAG skips when proj NO and HA/CC YES", () => {
  const result = evaluateBasisLagEdge(baseObs({
    projectedSettlementPrice: 64_800, // snapshot NO vs floor 65000
    estimatedFairBRTI: undefined,
  basisLeadUsd: undefined,     // do not live-proj the side back to YES
    velocityDolPerMin: 90,
    threeMinVelocity: 85,
    distFromFloorPct: 1.2,
    massAboveFloor: 80,
    recentUpPct: 0.60,
    basisStreakSign: -1,
    basisStreakCount: 4,
    lagDollars: -40,
    leadDollars: -40,
    yesAsk: 70,
    yesBid: 68,
    noAsk: 30,
    noBid: 28,
  }));
  assert.equal(result, null, "proj NO vs CC/HA YES must SKIP not fill NO");
});

test("LAG still fires YES when proj YES and CC factors same sign (HA missing)", () => {
  const result = evaluateBasisLagEdge(baseObs({
    ohlc1m: undefined,
    ohlc5m: undefined,
    velocityDolPerMin: 90,
    threeMinVelocity: 85,
    distFromFloorPct: 1.2,
    massAboveFloor: 80,
    recentUpPct: 0.60,
  }));
  assert.ok(result, "side-agree CC YES + proj YES must still fire");
  assert.equal(result!.signal, "YES");
});

test("LAG confidence is evidence, not basisLagWinRate; no 0.55 floor bandage", () => {
  const p = basisLagWinRate(18, 11);
  assert.ok(p < 0.55);
  const conf = basisLagEvidenceConfidence({
    edgePts: 8, minEdgePts: 8, isLong: true, streakCount: 3,
  });
  assert.notEqual(conf, p);
  assert.ok(conf < 0.55, "min-evidence must not be floored to 0.55");
  assert.equal(/let conf = basisLagWinRate\(sideAsk, minLeft\)/.test(EDGE_SRC), false);
});

test("LAG p=winRateAtPrice is not conf; EV≥3 side agree does not CONFIDENCE_FLOOR skip", () => {
  const p = basisLagWinRate(32, 5);
  const conf = basisLagEvidenceConfidence({ edgePts: 8, minEdgePts: 8, isLong: true, streakCount: 3 });
  assert.notEqual(conf, p);
  const ev = ticketEVCentsFromP({
    entryPriceCents: 32, pWin: 0.50, strategyId: "BASIS_LAG_EDGE", secsRemaining: 300,
  });
  assert.ok(ev != null && ev >= EV_FLOOR);
  assert.equal(shouldSkipConfidenceFloor({
    strategyId: "BASIS_LAG_EDGE",
    confidence: Math.round(conf * 94),
    minConfidence: 52,
    ticketEVCents: ev,
    sideAgrees: moneyMakerConfFloorSideAgrees({
      strategyId: "BASIS_LAG_EDGE", side: "yes", lagAgreesWithSide: true, lagSideConfirmationAgrees: true,
    }),
  }), false);
  assert.equal(lagSideConfirmationAgrees({ projSide: "YES", haRiverSide: "NO", ccFactorSide: "NO" }), false);
});

test("orig-LAG analog advances on distinct proj; live obs wiring fail-closed if meter missing/disagree", () => {
  let st = emptyOrigLagProjStreak();
  st = updateOrigLagProjStreak(st, { projectedSettlement: 65130, floor: 65000 });
  st = updateOrigLagProjStreak(st, { projectedSettlement: 65130, floor: 65000 });
  assert.equal(st.count, 1);
  st = updateOrigLagProjStreak(st, { projectedSettlement: 65140, floor: 65000 });
  st = updateOrigLagProjStreak(st, { projectedSettlement: 65150, floor: 65000 });
  assert.equal(st.sign, 1);
  assert.equal(st.count, 3);

  const missing = liveOrigLagStreakOnObs({ analog: st, lagDollars: null, lagStale: false });
  assert.equal(missing.wired, false);
  assert.equal(missing.reason, "meter_missing");
  assert.equal(missing.basisStreakCount, 0);

  const stale = liveOrigLagStreakOnObs({ analog: st, lagDollars: 40, lagStale: true });
  assert.equal(stale.wired, false);
  assert.equal(stale.reason, "meter_missing");

  const disagree = liveOrigLagStreakOnObs({ analog: st, lagDollars: -40, lagStale: false });
  assert.equal(disagree.wired, false);
  assert.equal(disagree.reason, "analog_meter_disagree");
  assert.equal(disagree.basisStreakCount, 0);

  const wired = liveOrigLagStreakOnObs({ analog: st, lagDollars: 40, lagStale: false });
  assert.equal(wired.wired, true);
  assert.equal(wired.basisStreakSign, 1);
  assert.equal(wired.basisStreakCount, 3);
});

test("LAG evaluate-and-fill: analog persist on obs FIRE when Coinbase agrees; missing/disagree stay null", () => {
  const analog = liveOrigLagStreakOnObs({
    analog: { sign: 1, count: 4, lastDistinctProj: 65130 },
    lagDollars: 40,
    lagStale: false,
  });
  const fired = evaluateBasisLagEdge(baseObs({
    basisStreakSign: analog.basisStreakSign,
    basisStreakCount: analog.basisStreakCount,
    lagStale: false,
    lagDollars: 40,
    lagProven: true,
    yesAsk: 30,
  }));
  assert.ok(fired, "proj+streak+EV+side-agree AND Coinbase agree must FIRE");
  assert.equal(fired!.strategyId, "BASIS_LAG_EDGE");
  assert.equal(fired!.signal, "YES");
  assert.ok(evaluateBasisLagEdge(baseObs({
    basisStreakSign: analog.basisStreakSign,
    basisStreakCount: analog.basisStreakCount,
    lagStale: false,
    lagDollars: 40,
    lagProven: true,
    yesAsk: 30,
    paperMode: true,
  })), "paper=live same FIRE");

  const noMeter = liveOrigLagStreakOnObs({
    analog: { sign: 1, count: 4, lastDistinctProj: 65130 },
    lagDollars: null,
    lagStale: false,
  });
  assert.equal(evaluateBasisLagEdge(baseObs({
    basisStreakSign: noMeter.basisStreakSign,
    basisStreakCount: noMeter.basisStreakCount,
    lagStale: false,
    lagDollars: undefined,
    lagProven: false,
    leadDollars: undefined,
    leadSeconds: undefined,
  })), null, "meter missing must not invent analog FIRE");

  const vsMeter = liveOrigLagStreakOnObs({
    analog: { sign: 1, count: 4, lastDistinctProj: 65130 },
    lagDollars: -40,
    lagStale: false,
  });
  assert.equal(evaluateBasisLagEdge(baseObs({
    basisStreakSign: vsMeter.basisStreakSign,
    basisStreakCount: vsMeter.basisStreakCount,
    lagStale: false,
    lagDollars: -40,
    lagProven: true,
  })), null, "analog vs Coinbase disagree fail-closed");

  assert.equal(evaluateBasisLagEdge(baseObs({
    basisStreakSign: analog.basisStreakSign,
    basisStreakCount: analog.basisStreakCount,
    projectedSettlementPrice: 65001,
    estimatedFairBRTI: undefined,
  basisLeadUsd: undefined,
    velocityDolPerMin: 0,
    yesAsk: 30,
  })), null, "flat proj stays honest skip");

  assert.equal(LAG_CHEAP_ASK_CENTS, 55);
  assert.equal(evaluateBasisLagEdge(baseObs({
    basisStreakSign: analog.basisStreakSign,
    basisStreakCount: analog.basisStreakCount,
    lagProven: false,
    lagStale: false,
    lagDollars: 40,
    yesAsk: 70,
    yesBid: 68,
    noAsk: 32,
    noBid: 30,
  })), null, "cheap>55 remake overlay stays locked");
});


test("lagSideConfirmationAgrees: MTF same-sign confirms when HA/CC disagree", () => {
  assert.equal(
    lagSideConfirmationAgrees({
      projSide: "YES", haRiverSide: "NO", ccFactorSide: "NO", mtfSide: "YES",
    }),
    true,
    "lag+MTF agree must not false LAG_SIDE_DISAGREE",
  );
  assert.equal(
    lagSideConfirmationAgrees({
      projSide: "NO", haRiverSide: "YES", ccFactorSide: "YES", mtfSide: "NO",
    }),
    true,
  );
  assert.equal(
    lagSideConfirmationAgrees({
      projSide: "YES", haRiverSide: null, ccFactorSide: null, mtfSide: "YES",
    }),
    true,
    "MTF alone is enough confirmation when HA/CC missing",
  );
  assert.equal(
    lagSideConfirmationAgrees({
      projSide: "YES", haRiverSide: "NO", ccFactorSide: "NO", mtfSide: "NO",
    }),
    false,
    "MTF opposing still disagrees",
  );
});

test("LAG fires when proj+MTF agree despite CC/HA oppose (in-band ask)", () => {
  // Bearish factors would make CC oppose YES; MTF long + proj YES should confirm.
  const result = evaluateBasisLagEdge(baseObs({
    mtfScore: 3,
    velocityDolPerMin: -90,
    threeMinVelocity: -85,
    distFromFloorPct: -1.2,
    massAboveFloor: 20,
    recentUpPct: 0.30,
    ohlc1m: undefined,
    ohlc5m: undefined,
    yesAsk: 30,
    noAsk: 70,
  }));
  assert.ok(result, "lag+MTF agree must not be buried by false LAG_SIDE_DISAGREE");
  assert.equal(result!.signal, "YES");
});
