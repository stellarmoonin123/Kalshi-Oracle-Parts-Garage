/**
 * Fresh Mind interpret + bind helpers for placeOrder under frozenCc.
 * No LLM. Soft CC_VEL alone stays soft until n≥40 (not a hard gate by itself).
 * Captain HEAVE_TO / preferSkip / BRAIN_CENTER hard veto → bind TAKE → SKIP.
 */
import type { BrainCenterReport } from "./brain-center.js";
import { decideBrainCenterAction } from "./brain-center.js";

/** Soft measurement conflicts — observe until n≥40; never sole hard gate. */
export const SOFT_CC_VEL_CONFLICT_CODES = new Set<string>([
  "CC_VEL_AGAINST_SOLE_TAKE",
]);

export const MIND_HEAVE_BIND = "MIND_HEAVE_BIND" as const;
export const BRAIN_CENTER_VETO = "BRAIN_CENTER_VETO" as const;

export type MindPlaceBindStamp = typeof MIND_HEAVE_BIND | typeof BRAIN_CENTER_VETO;

/** True when every conflict is soft CC_VEL (or no conflicts). */
export function conflictsAreSoftCcVelOnly(
  conflicts: ReadonlyArray<{ code: string }> | null | undefined,
): boolean {
  const list = conflicts ?? [];
  if (list.length === 0) return false;
  return list.every((c) => SOFT_CC_VEL_CONFLICT_CODES.has(c.code));
}

export function hardVetoConflicts(
  conflicts: ReadonlyArray<{ code: string }> | null | undefined,
): Array<{ code: string }> {
  return (conflicts ?? []).filter((c) => !SOFT_CC_VEL_CONFLICT_CODES.has(c.code));
}

/**
 * Captain HEAVE_TO / PhD preferSkip / education heave that rose to captain.
 * Does NOT bind on raw CC_VEL alone.
 */
export function mindHeaveWouldBind(
  report: BrainCenterReport | null | undefined,
): string | null {
  if (!report) return null;
  const captain = report.captain;
  if (captain?.heaveTo === true || captain?.voyageOrder === "HEAVE_TO") {
    const why =
      captain.heaveReasons?.slice(0, 2).join("; ") ||
      captain.voyageOrder ||
      "HEAVE_TO";
    return `captain HEAVE_TO — ${why}`;
  }
  if (report.phd?.optionValueSkip?.preferSkip === true) {
    const score = report.phd.optionValueSkip.score;
    const reasons = report.phd.optionValueSkip.reasons?.slice(0, 2).join("; ") ?? "preferSkip";
    return `PhD preferSkip OV=${score} — ${reasons}`;
  }
  // Education / specialist heaves that did not yet promote to captain stay advisory
  // unless captain already heaved (covered above).
  return null;
}

/**
 * PR #16 option B — advisory heave terms at placeOrder / agent entry gate.
 *
 * Since F1 (Sep 19 12:15 ET) any captain HEAVE_TO blocked the order. Most
 * blocks were driven by three soft research terms (OV-SKIP score, coversBoth,
 * unreliable calibration). Those three are now ADVISORY: they tag the trade
 * (`advisoryVetoes`) and log MIND_HEAVE_ADVISORY instead of blocking.
 *
 * Everything else that can raise a heave KEEPS BLOCKING (fail closed):
 *   oracle risk vetoes (min_edge 7¢, hard EV floor, thin book, gates_failed,
 *   MISSING_INPUTS, settle-side SKIP, paperMode), SelfDrive blind / no index,
 *   stale feed, vel_against, thin_book, storm, floors, sizeZero, G_* fails,
 *   captain FACT floors, PhD education / KXBTC15M specialist heaves, fog from
 *   missing inputs / band / weather, "officers lean skip", and any heave reason
 *   this classifier does not recognise.
 * Review rule (desk-knowledge [pr16]): after n≥40 closed trades compare fee-net
 * per contract flagged vs unflagged (day-block bootstrap CI); restore blocking
 * for a term that is significantly worse. Not an edge claim.
 */
export const MIND_HEAVE_ADVISORY = "MIND_HEAVE_ADVISORY" as const;

export type MindHeaveAdvisoryTerm = "OV_SKIP" | "COVERS_BOTH" | "CALIBRATION";

export type MindHeaveValue = {
  voyageOrder: string | null;
  heaveTo: boolean;
  ovScore: number | null;
  preferSkip: boolean;
  reasons: string[];
};

export type MindHeaveClassification = {
  /** Would the pre-PR16 (F1) rule have blocked? */
  heave: boolean;
  /** Blocking reason when a hard term is present; null when allowed. */
  block: string | null;
  hardReasons: string[];
  /** Advisory terms that WOULD have blocked under F1 (empty when no heave). */
  advisoryVetoes: MindHeaveAdvisoryTerm[];
  heaveValue: MindHeaveValue | null;
};

const ADVISORY_REASON_PATTERNS: Array<[MindHeaveAdvisoryTerm, RegExp]> = [
  ["OV_SKIP", /^OV-SKIP score=/i],
  ["COVERS_BOTH", /^coversBoth\b|^band80 covers both sides$/i],
  ["CALIBRATION", /^calibration unreliable( ECE)?$/i],
];

function advisoryTermOf(reason: string): MindHeaveAdvisoryTerm | null {
  const r = reason.trim();
  for (const [term, re] of ADVISORY_REASON_PATTERNS) {
    if (re.test(r)) return term;
  }
  return null;
}

/** Pure — split a fresh Mind heave into hard (blocking) and advisory terms. */
export function classifyMindHeave(
  report: BrainCenterReport | null | undefined,
): MindHeaveClassification {
  const original = mindHeaveWouldBind(report);
  if (!report || !original) {
    return { heave: false, block: null, hardReasons: [], advisoryVetoes: [], heaveValue: null };
  }
  const captain = report.captain;
  const phd = report.phd;
  const sd = report.selfDrive;
  const ov = report.oracleV2;
  const hard: string[] = [];
  const adv = new Set<MindHeaveAdvisoryTerm>();

  // Structural advisory signals (whatever organ carried them).
  if (phd?.optionValueSkip?.preferSkip === true || sd?.prediction?.ovPreferSkip === true) adv.add("OV_SKIP");
  if (phd?.uncertainty?.coversBoth === true) adv.add("COVERS_BOTH");
  if (phd?.calibration?.reliable === false) adv.add("CALIBRATION");

  const captainHeave = captain?.heaveTo === true || captain?.voyageOrder === "HEAVE_TO";
  if (captainHeave) {
    const reasons = captain?.heaveReasons ?? [];
    if (reasons.length === 0) hard.push(`captain ${captain?.voyageOrder ?? "HEAVE_TO"} without reasons`);
    for (const raw of reasons) {
      const r = String(raw);
      if (/^INFERENCE: SelfDrive\.brake/.test(r)) {
        const br = sd?.safety?.brakeReasons ?? sd?.brakeReasons;
        if (!Array.isArray(br) || br.length === 0) {
          hard.push("SelfDrive.brake (reasons unavailable)");
          continue;
        }
        for (const b of br) {
          const t = advisoryTermOf(String(b));
          if (t) adv.add(t);
          else hard.push(`SelfDrive: ${b}`);
        }
      } else if (/^INFERENCE: oracleV2\.risk_veto/.test(r)) {
        const rr = ov?.risk_veto_reasons;
        if (!Array.isArray(rr) || rr.length === 0) {
          hard.push("oracleV2.risk_veto (reasons unavailable)");
          continue;
        }
        for (const v of rr) {
          const t = advisoryTermOf(String(v));
          if (t) adv.add(t);
          else hard.push(`oracle RISK: ${v}`);
        }
      } else if (/^INFERENCE: PhD preferSkip OV=/.test(r)) {
        adv.add("OV_SKIP");
      } else if (/^MEASUREMENT: PhD coversBoth/.test(r)) {
        adv.add("COVERS_BOTH");
      } else if (/^MEASUREMENT: unreliable ECE/.test(r)) {
        adv.add("CALIBRATION");
      } else if (/^ESTIMATE: fog\/weather/.test(r)) {
        const missing =
          (ov?.missing_inputs?.length ?? 0) > 0 || (ov?.gates_failed?.length ?? 0) > 0;
        const weather = sd?.perception?.weather;
        if (missing) hard.push(`fog: missing inputs/band [${[...(ov?.gates_failed ?? []), ...(ov?.missing_inputs ?? [])].slice(0, 4).join(",")}]`);
        else if (weather === "storm" || weather === "haze") hard.push(`fog: weather=${weather}`);
        else if (phd?.uncertainty?.coversBoth === true || phd?.calibration?.reliable === false) {
          if (phd?.uncertainty?.coversBoth === true) adv.add("COVERS_BOTH");
          if (phd?.calibration?.reliable === false) adv.add("CALIBRATION");
        } else hard.push(r);
      } else {
        // FACT floors, education, specialist, officers-lean-skip, unknown → hard.
        hard.push(r);
      }
    }
  }
  // PhD preferSkip without a captain heave (second F1 clause) is advisory.

  const advisoryVetoes = (["OV_SKIP", "COVERS_BOTH", "CALIBRATION"] as const).filter((t) => adv.has(t));
  const uniqHard = [...new Set(hard)];
  const heaveValue: MindHeaveValue = {
    voyageOrder: captain?.voyageOrder ?? null,
    heaveTo: captainHeave,
    ovScore: typeof phd?.optionValueSkip?.score === "number" ? phd.optionValueSkip.score : null,
    preferSkip: phd?.optionValueSkip?.preferSkip === true,
    reasons: (captain?.heaveReasons ?? []).slice(0, 4).map(String),
  };
  return {
    heave: true,
    block: uniqHard.length > 0 ? `captain HEAVE_TO (hard) — ${uniqHard.slice(0, 3).join("; ")}` : null,
    hardReasons: uniqHard,
    advisoryVetoes: [...advisoryVetoes],
    heaveValue,
  };
}

/**
 * BRAIN_CENTER hard veto with soft-CC_VEL filter.
 * CC_VEL_AGAINST_SOLE_TAKE alone does not veto (n≪40 doctrine).
 * Reflex hard + other hard conflicts still veto.
 */
export function brainCenterHardVetoReason(
  report: BrainCenterReport | null | undefined,
  brainCenterAuthority: boolean,
): string | null {
  if (brainCenterAuthority !== true) return null;
  if (!report) return null;

  // Soft-only shadow: never BRAIN_CENTER_VETO on CC_VEL alone.
  if (conflictsAreSoftCcVelOnly(report.conflicts)) {
    const reflex = report.mind?.layers?.find((l) => l.id === "reflex");
    if (reflex?.hard === true) {
      return `reflex hard-block: ${reflex.why}`;
    }
    return null;
  }

  const d = decideBrainCenterAction({
    brainCenterAuthority: true,
    report,
  });
  if (d.action === "VETO") return d.reason;
  return null;
}

/**
 * Combined placeOrder bind under frozenCc after a fresh interpret.
 * Order: heave bind → hard brain veto (soft CC_VEL excluded).
 */
export function decideFrozenCcMindBind(input: {
  report: BrainCenterReport | null | undefined;
  brainCenterAuthority: boolean;
}):
  | { action: "ALLOW"; advisory?: MindHeaveClassification }
  | { action: "BLOCK"; stamp: MindPlaceBindStamp; reason: string; advisory?: MindHeaveClassification } {
  const cls = classifyMindHeave(input.report);
  if (cls.block) {
    return { action: "BLOCK", stamp: MIND_HEAVE_BIND, reason: cls.block, advisory: cls };
  }
  const veto = brainCenterHardVetoReason(
    input.report,
    input.brainCenterAuthority,
  );
  if (veto) {
    return { action: "BLOCK", stamp: BRAIN_CENTER_VETO, reason: veto, advisory: cls };
  }
  return cls.heave ? { action: "ALLOW", advisory: cls } : { action: "ALLOW" };
}

/** Honesty tags for close/settle — sold-early vs held-wrong (not side skill). */
export function settleHonestyTags(input: {
  exitReason?: string | null;
  side?: string | null;
  officialSettle?: "YES" | "NO" | null;
}): {
  soldEarly: boolean;
  heldWrongSide: boolean;
  holdToSettlement: boolean;
} {
  const er = (input.exitReason ?? "").trim().toUpperCase();
  // Match trade-story HOLD_EXIT_CODES — PATH_RIDE_TP etc. are sold-early (not side skill).
  const hold = !er || er === "SETTLEMENT" || er === "SETTLED_KALSHI";
  const soldEarly = !hold;
  const sideRaw = (input.side ?? "").trim().toLowerCase();
  const side =
    sideRaw === "yes" || sideRaw === "long" ? "YES"
    : sideRaw === "no" || sideRaw === "short" ? "NO"
    : (input.side ?? "").trim().toUpperCase();
  const settle = input.officialSettle;
  const heldWrongSide =
    hold &&
    (settle === "YES" || settle === "NO") &&
    (side === "YES" || side === "NO") &&
    side !== settle;
  return { soldEarly, heldWrongSide, holdToSettlement: hold };
}

/**
 * R3 — the placeOrder bind must judge the order actually being placed.
 * A cached organ admission is reusable only when it is a TAKE for the same
 * side, strategy and ask as the pending frozen order; otherwise (SKIP, other
 * engine, other side, stale ask) the caller re-stamps from the order params.
 * Same rules, right inputs — never loosens a gate.
 */
export function admissionMatchesPlaceOrder(
  admission: { decision?: string; identity?: { side?: string | null; strategyId?: string | null; askCents?: number | null } } | null | undefined,
  order: { side: "yes" | "no"; strategyId: string; askCents: number },
): boolean {
  if (!admission || admission.decision !== "TAKE") return false;
  const id = admission.identity;
  if (!id) return false;
  if (id.side !== order.side) return false;
  if (id.strategyId != null && id.strategyId !== order.strategyId) return false;
  if (typeof id.askCents !== "number" || id.askCents !== order.askCents) return false;
  return true;
}
