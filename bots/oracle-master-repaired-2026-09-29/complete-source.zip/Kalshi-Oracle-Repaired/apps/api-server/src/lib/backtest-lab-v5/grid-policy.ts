/**
 * backtest-lab-v5/grid-policy.ts
 *
 * GO — BOUNDED WALK-FORWARD POLICY SEARCH (2026-08-23).
 *
 * Additive extension of the existing backtest-lab-v5 causal engine that adds
 * the two dimensions causal-sim.ts explicitly documents as out of scope
 * (Limitation #3): variable contract sizing and an in-trade early-exit
 * proxy. Deliberately does NOT modify sim-policy.ts / causal-sim.ts /
 * validation.ts — those files are a "hard contract" with their own poison
 * test proving decision-time causal safety, and are reused here byte-for-
 * byte via their exported primitives (buildDecisionObservation,
 * decideAtPoint). Only the SETTLEMENT/GRADING step is extended.
 *
 * HARD CONTRACT: nothing in this file writes to `.bot-config.json`, calls
 * any BotConfig setter, or otherwise touches live trading behavior. It only
 * reads real market data passed in by the caller and returns plain data.
 *
 * Sizing model (`sizeModel: 'halfKellyCapped'`):
 *   contracts = max(1, min(maxContracts, halfKellyContracts, portfolioRiskCapContracts, hardRiskCapContracts))
 *   - halfKellyContracts derives from the standard binary-Kelly formula
 *     f* = (b*q - (1-q)) / b, where q = strategy confidence (win-prob
 *     estimate) and b = netWin/netCost at the actual entry price, halved for
 *     the conventional half-Kelly safety margin.
 *   - portfolioRiskCapContracts caps risk at policy.portfolioRiskPct of a
 *     FIXED reference bankroll (NOTIONAL_BASE_CENTS — a comparison constant,
 *     not the $313 paper-desk start) so every grid candidate is sized
 *     against the same base for a fair comparison.
 *   - hardRiskCapContracts mirrors trading-bot.ts's HARD_RISK_LIMITS.
 *     maxRiskPctPerTrade (9%) — hardcoded here, NOT imported from
 *     trading-bot.ts, because that module has eager startup side effects
 *     (see .agents/memory/control-tool-state-assumptions.md and related
 *     entries) and must never be imported from an offline research script.
 *   This is a deliberate approximation of live sizing (no stack tiers,
 *   ARIA overlay, or compound-mode balance tracking) — good enough to rank
 *   sizing policies against each other, not a claim of full live parity.
 *
 * Early-exit model (`earlyExitEnabled: true`, sensitivity-only, never part
 * of the main grid per the bounded-search spec):
 *   A causally-safe "thesis broke" proxy. Only applies to trades admitted
 *   at minute 5 (the only case with a further causal checkpoint before
 *   settlement in this 3-candle-per-period model): at the minute-10 mark,
 *   candle c1 (5-10m) is already known. If the position is currently
 *   underwater relative to the floor strike by a genuinely non-trivial
 *   margin, the trade is graded as exiting early at a flat stop-loss
 *   (EARLY_EXIT_STOP_LOSS_CENTS, matching .bot-config.json's live
 *   stopLossCents=22) instead of holding to full settlement. This is a
 *   coarse proxy for the live bot's real thesis-break/stop-loss exits (no
 *   continuous quote stream exists in this lab to model a real stop
 *   trigger) — reported honestly as a limitation, not treated as a precise
 *   replay of live exit logic.
 */

import type { RealCandle } from '../market-candles.js';
import { kalshiNetWinCents, kalshiNetCostCents } from '../constants.js';
import type { SimPolicy, ConsensusMode, PackMode, SimPolicyFlags } from './sim-policy.js';
import { clonePolicy } from './sim-policy.js';
import type { CausalPeriod, SimDecision, SimTrade } from './causal-sim.js';
import { buildDecisionObservation, decideAtPoint } from './causal-sim.js';
import type { StrategyObservation, StrategyId } from '../strategy-library.js';
import { PHASE2_ALWAYS_DISABLED } from '../specialist-packs.js';

/**
 * GO — BOUNDED WALK-FORWARD POLICY SEARCH quarantine list ("BRTI/MTF/SAKATA/
 * OTM families stay excluded" — fixed, not searched). causal-sim.ts's
 * decideAtPoint does NOT apply specialist-packs.ts's PHASE2_ALWAYS_DISABLED
 * set today (a real gap — that set is only consumed by
 * historical-backtester.ts elsewhere), and OTM_BREAKOUT_EXPANSION /
 * DEEP_OTM_SNIPER aren't in PHASE2_ALWAYS_DISABLED at all (only
 * OTM_ASYMMETRY is). This grid module enforces the FULL requested
 * quarantine as a post-selection override (see runGridPolicyOverPeriods):
 * if the pipeline's own selection lands on a quarantined strategy, that
 * decision is forced to non-admitted and the next minute mark (or no
 * trade for the period) is used instead. This can only ever REDUCE trade
 * count relative to letting the strategy fire — a conservative, not lax,
 * enforcement.
 */
export const GRID_QUARANTINED_STRATEGY_IDS: ReadonlySet<StrategyId> = new Set<StrategyId>([
  ...PHASE2_ALWAYS_DISABLED as ReadonlySet<StrategyId>,
  'OTM_BREAKOUT_EXPANSION' as StrategyId,
  'DEEP_OTM_SNIPER' as StrategyId,
]);

export type SizeModel = 'fixed1' | 'halfKellyCapped';

export interface GridPolicy extends SimPolicy {
  sizeModel: SizeModel;
  /** Hard ceiling on contracts per trade — only binds under halfKellyCapped. */
  maxContracts: number;
  /** Fraction of NOTIONAL_BASE_CENTS risked per trade (e.g. 0.06 = 6%) — only binds under halfKellyCapped. */
  portfolioRiskPct: number;
  /** Sensitivity-only flag — never varied inside the bounded main grid. */
  earlyExitEnabled: boolean;
}

export function makeGridPolicy(
  base: SimPolicy,
  extra: { id: string; label: string; sizeModel: SizeModel; maxContracts: number; portfolioRiskPct: number; earlyExitEnabled: boolean },
): GridPolicy {
  return { ...clonePolicy(base), ...extra };
}

// Reference bankroll for sizing comparisons across grid candidates.
// Fixed $1,000 notional so rankings are independent of the CURRENT paper
// balance (which drifts). This is NOT the live desk start — production
// paperStartingBalanceCents is 31_300 ($313). Do not treat this as a UI/live default.
export const NOTIONAL_BASE_CENTS = 100_000;

// Mirrors trading-bot.ts's HARD_RISK_LIMITS.maxRiskPctPerTrade. See module
// doc above for why this is hardcoded rather than imported.
export const LIVE_HARD_RISK_PCT_PER_TRADE = 0.09;

// Matches .bot-config.json's live stopLossCents default.
export const EARLY_EXIT_STOP_LOSS_CENTS = 22;

// "Genuinely non-trivial adverse move" bar — same magnitude as constants.ts's
// PRICE_BAND_EXTREME_DISPLACEMENT_PCT (0.05%), reused here for the same
// qualitative judgment ("this is a real move, not noise").
export const EARLY_EXIT_ADVERSE_MOVE_PCT = 0.0005;

/** Computes contracts for one admitted trade under a GridPolicy's sizeModel. Never exceeds the live 9% hard risk ceiling regardless of policy.portfolioRiskPct. */
export function computeGridContracts(policy: GridPolicy, entryPriceCents: number, confidence: number): number {
  if (policy.sizeModel === 'fixed1') return 1;

  const netWin  = kalshiNetWinCents(entryPriceCents);
  const netCost = kalshiNetCostCents(entryPriceCents);
  if (netCost <= 0 || netWin <= 0) return 1;

  const q = Math.min(0.99, Math.max(0.01, confidence));
  const b = netWin / netCost;
  const kellyFraction = (b * q - (1 - q)) / b;
  const halfKelly = Math.max(0, kellyFraction / 2);

  const kellyContracts    = Math.floor((halfKelly * NOTIONAL_BASE_CENTS) / netCost);
  const riskCapContracts  = Math.floor((policy.portfolioRiskPct * NOTIONAL_BASE_CENTS) / netCost);
  const hardCapContracts  = Math.floor((LIVE_HARD_RISK_PCT_PER_TRADE * NOTIONAL_BASE_CENTS) / netCost);

  const contracts = Math.min(policy.maxContracts, kellyContracts, riskCapContracts, hardCapContracts);
  // Admission already required positive EV, so a >=1-contract floor mirrors
  // the live compound-mode-live-paper-mismatch fix (never round a positive-
  // EV trade down to zero contracts).
  return Math.max(1, contracts);
}

export interface GridTrade extends SimTrade {
  contracts: number;
  exitedEarly: boolean;
}

/** Precomputes buildDecisionObservation for every period x minuteMark ONCE,
 *  shared across every grid candidate — buildDecisionObservation does not
 *  depend on policy at all, so this turns the dominant cost (quote
 *  synthesis / regime classification inside buildSimObs) from O(policies x
 *  periods) into O(periods), the single biggest lever for a ~120-combo
 *  bounded grid to run in reasonable time. */
export function precomputeObservations(
  fullSeries: RealCandle[],
  periods: CausalPeriod[],
): Map<string, StrategyObservation> {
  const map = new Map<string, StrategyObservation>();
  for (const period of periods) {
    for (const minuteMark of [5, 10] as const) {
      map.set(`${period.periodStartMs}:${minuteMark}`, buildDecisionObservation(fullSeries, period, minuteMark));
    }
  }
  return map;
}

/**
 * Grid-search grading loop. Decision-time logic is IDENTICAL to
 * causal-sim.ts's runPolicyOverPeriods (same decideAtPoint /
 * buildDecisionObservation calls, unmodified) — only settlement grading is
 * extended with variable sizing and the optional early-exit proxy.
 */
export function runGridPolicyOverPeriods(
  fullSeries: RealCandle[],
  periods: CausalPeriod[],
  policy: GridPolicy,
  precomputedObs?: Map<string, StrategyObservation>,
): { decisions: SimDecision[]; trades: GridTrade[] } {
  const decisions: SimDecision[] = [];
  const trades: GridTrade[] = [];

  for (const period of periods) {
    let admittedDecision: SimDecision | null = null;
    let admittedMinute: 5 | 10 = 5;
    for (const minuteMark of [5, 10] as const) {
      const key = `${period.periodStartMs}:${minuteMark}`;
      const obs = precomputedObs?.get(key) ?? buildDecisionObservation(fullSeries, period, minuteMark);
      const decision = decideAtPoint(obs, policy);
      decision.periodStartMs = period.periodStartMs;
      decision.minuteMark = minuteMark;
      if (decision.admitted && decision.strategyId && GRID_QUARANTINED_STRATEGY_IDS.has(decision.strategyId)) {
        // Quarantine override — see GRID_QUARANTINED_STRATEGY_IDS doc above.
        decision.admitted = false;
      }
      decisions.push(decision);
      if (decision.admitted) { admittedDecision = decision; admittedMinute = minuteMark; break; }
    }

    if (admittedDecision && admittedDecision.side && admittedDecision.entryPriceCents != null) {
      const entryPriceCents = admittedDecision.entryPriceCents;
      const contracts = computeGridContracts(policy, entryPriceCents, admittedDecision.confidence ?? 0.5);
      const extraFrictionPerContract = policy.feeCents + policy.slipCents;

      let exitedEarly = false;
      let won: boolean;
      let pnlPerContract: number;

      const settleAboveFloor = period.settlementClose > period.floorStrike;
      const holdToSettlement = () => {
        won = (admittedDecision!.side === 'YES') === settleAboveFloor;
        pnlPerContract = won
          ? kalshiNetWinCents(entryPriceCents) - extraFrictionPerContract
          : -kalshiNetCostCents(entryPriceCents) - extraFrictionPerContract;
      };

      if (policy.earlyExitEnabled && admittedMinute === 5) {
        const c1 = period.candles[1]; // 5-10m candle — causally known by minute 10, still strictly before period close
        const stillAboveFloor = c1.close > period.floorStrike;
        const currentlyLosing = (admittedDecision.side === 'YES') !== stillAboveFloor;
        const adverseMovePct = Math.abs(c1.close - period.floorStrike) / period.floorStrike;
        if (currentlyLosing && adverseMovePct >= EARLY_EXIT_ADVERSE_MOVE_PCT) {
          exitedEarly = true;
          won = false;
          pnlPerContract = -EARLY_EXIT_STOP_LOSS_CENTS - extraFrictionPerContract;
        } else {
          holdToSettlement();
        }
      } else {
        holdToSettlement();
      }

      trades.push({ ...admittedDecision, won: won!, pnlCents: pnlPerContract! * contracts, contracts, exitedEarly });
    }
  }
  return { decisions, trades };
}

export { type ConsensusMode, type PackMode, type SimPolicyFlags };
