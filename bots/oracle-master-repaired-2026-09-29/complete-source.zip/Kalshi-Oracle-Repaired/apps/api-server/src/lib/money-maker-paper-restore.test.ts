/**
 * Paper-restore CONFLUENCE_CASCADE + BASIS_LAG_EDGE (the live +$50 engines).
 * paperMode stays true. SEV1 stays locked. EV 3¢ / Kelly 0.60 / 9% / 15% /
 * daily halt stay. PAPER_SCALP stays halted. LATE_ENTRY / SP stay off.
 *
 * Does not bounce the API. Does not flip paperMode false.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  EV_FLOOR,
  OTM_EV_FLOOR,
  HARD_RISK_LIMITS,
  DAILY_HALT_FLOOR_CENTS,
  DAILY_HALT_PCT,
  computeTradeEV,
  evaluateEntryEVGate,
  kellyFraction,
  pWinFromCurve,
} from "./admission.js";
import { PATCH_FAIL_CLOSED_DISABLED, refuseToggleStrategy } from "./config-patch-surface.js";
import {
  confluenceWinRate,
  evaluateConfluenceCascade,
  CONFLUENCE_STILL_MID_UNCLEAR_SKIP,
  confluenceStillMidUnclearReason,
} from "./confluence-cascade.js";
import { evaluateBasisLagEdge } from "./basis-lag-edge.js";
import {
  evaluateAllStrategies,
  FAIL_CLOSED_WITHOUT_WINRATE_CURVE,
  getStrategy,
  type StrategyObservation,
} from "./strategy-library.js";
import { PAPER_SCALP_FEE_NET_BEATS_SKIP, PAPER_MODE, LIVE_APPLY } from "./paper-scalp.js";
import { effectiveDisabledStrategies } from "./trading-bot.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const PERSISTED = JSON.parse(
  fs.readFileSync(path.resolve(DIR, "../../.bot-config.json"), "utf8"),
) as { paperMode: boolean; holdToSettlement: boolean; specialistPacksMode: string; disabledStrategies: string[]; reservePct: number };
const BOT_SRC = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");

function confluenceFireObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 63500,
    floorStrike: 63000,
    velocityDolPerMin: 90,
    threeMinVelocity: 85,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 1.2,
    massAboveFloor: 80,
    secsRemaining: 5 * 60,
    recentUpPct: 0.60,
    regime: "strong_uptrend",
    yesAsk: 49,
    noAsk: 51,
    contractDurationMins: 15,
    ticker: "KXBTC15M-26AUG271615-15",
    ...overrides,
  };
}

function basisLagObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60,
    projectedSettlementPrice: 65130,
    rollingBasis: 8,
    basisShort: 8,
    basisStreakCount: 4,
    basisStreakSign: 1,
    lagStale: false,
    lagProven: true,
    lagDollars: 40,
    yesAsk: 42,
    yesBid: 40,
    noAsk: 58,
    noBid: 56,
    regime: "unclear",
    contractDurationMins: 15,
    ticker: "KXBTC15M-26AUG271630-00",
    ...overrides,
  };
}

test("paperMode still true (code default + persisted file)", () => {
  assert.equal(PERSISTED.paperMode, true);
  assert.match(BOT_SRC, /paperMode:\s+true,/);
  assert.equal(PERSISTED.holdToSettlement, false);
  assert.equal(PERSISTED.specialistPacksMode, "off");
});

test("SEV1 stays locked; LATE_ENTRY and SP stay off; PAPER_SCALP halted", () => {
  const disabled = effectiveDisabledStrategies({
    disabledStrategies: PERSISTED.disabledStrategies,
    cheapSide15mEnabled: true,
  });
  for (const id of [
    "SAKATA_CANDLE_PATTERN", "MTF_ALIGNED",
    "DEEP_OTM_SNIPER", "OTM_ASYMMETRY", "OTM_BREAKOUT_EXPANSION",
  ]) {
    assert.ok(disabled.includes(id), `${id} must stay SEV1-disabled`);
  }
  // FROZEN_CC: BRTI stays disabled. Paper Tier A (frozenCcMode false) unlocks BRTI — do not rewrite live disk.
  const frozenCc = (PERSISTED as { frozenCcMode?: boolean }).frozenCcMode === true;
  if (frozenCc) {
    assert.ok(disabled.includes("BRTI_PROBABILITY"), "BRTI_PROBABILITY disabled under frozen-cc");
  }
  assert.ok(disabled.includes("LATE_ENTRY_ANCHOR"));
  assert.ok(disabled.includes("SETTLEMENT_PREDICTION"));
  assert.ok(refuseToggleStrategy("LATE_ENTRY_ANCHOR", true));
  assert.equal(refuseToggleStrategy("BRTI_PROBABILITY", true), null, "BRTI not SEV1 patch-locked; frozen disk denylist is the gate");
  assert.equal(PAPER_SCALP_FEE_NET_BEATS_SKIP, false);
  assert.equal(PAPER_MODE, true);
  assert.equal(LIVE_APPLY, false);
  assert.match(BOT_SRC, /cheapEarlyExitEnabled:\s+false/);
  assert.match(BOT_SRC, /panicFadeEnabled:\s+false/);
  assert.match(BOT_SRC, /streakSatFadeEnabled:\s+false/);
  assert.match(BOT_SRC, /enable1HContracts:\s+false/);
});

test("EV 3¢ / Kelly 0.60 / 9% / 15% / daily halt untouched; EV still blocks −EV", () => {
  assert.equal(EV_FLOOR, 3);
  assert.equal(OTM_EV_FLOOR, 5);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(kellyFraction(80, 8), 0.60);
  assert.equal(PERSISTED.reservePct, 15);
  assert.equal(DAILY_HALT_FLOOR_CENTS, 3000);
  assert.equal(DAILY_HALT_PCT, 0.10);

  const minusEv = evaluateEntryEVGate({
    entryPriceCents: 80,
    strategyWinRate: 0.40,
    strategyId: "CONFLUENCE_CASCADE",
    secsRemaining: 300,
  });
  assert.equal(minusEv.passes, false);
  assert.ok((minusEv.netEV ?? 0) < EV_FLOOR);

  const rich = computeTradeEV({
    entryPriceCents: 80,
    winRate: confluenceWinRate(80, 5),
    strategyId: "CONFLUENCE_CASCADE",
    secsRemaining: 300,
    minEVCents: EV_FLOOR,
  });
  assert.equal(rich.passes, false);
});

test("CONFLUENCE_CASCADE can TAKE a qualifying paper fill (trend, cheap-to-mid)", () => {
  assert.equal(PERSISTED.disabledStrategies.includes("CONFLUENCE_CASCADE"), false);
  assert.equal((PATCH_FAIL_CLOSED_DISABLED as readonly string[]).includes("CONFLUENCE_CASCADE"), false);
  assert.equal(refuseToggleStrategy("CONFLUENCE_CASCADE", true), null);
  const eff = effectiveDisabledStrategies({
    disabledStrategies: PERSISTED.disabledStrategies,
    cheapSide15mEnabled: true,
  });
  assert.equal(eff.includes("CONFLUENCE_CASCADE"), false);
  assert.ok(FAIL_CLOSED_WITHOUT_WINRATE_CURVE.has("CONFLUENCE_CASCADE"));
  assert.ok(getStrategy("CONFLUENCE_CASCADE")!.winRateAtPrice);

  const obs = confluenceFireObs();
  const named = evaluateConfluenceCascade(obs);
  assert.ok(named, "strong_uptrend 49¢ with ≥3 factors must fire");
  assert.equal(named!.strategyId, "CONFLUENCE_CASCADE");
  const { all } = evaluateAllStrategies(obs);
  assert.equal(all.some(r => r.strategyId === "CONFLUENCE_CASCADE"), true);
  const p = pWinFromCurve(confluenceWinRate, 49, 5);
  assert.ok(p != null && p !== 0.75);
  const ev = computeTradeEV({
    entryPriceCents: 49,
    winRate: p!,
    strategyId: "CONFLUENCE_CASCADE",
    secsRemaining: 300,
    minEVCents: EV_FLOOR,
  });
  assert.equal(ev.passes, true, "money-cell 49¢ must clear EV 3¢ on the live-calibrated curve");

  const unclear = confluenceFireObs({ regime: "unclear", yesAsk: 49, noAsk: 51 });
  assert.equal(confluenceStillMidUnclearReason(unclear, 49), CONFLUENCE_STILL_MID_UNCLEAR_SKIP);
  assert.equal(evaluateConfluenceCascade(unclear), null);
});

test("BASIS_LAG_EDGE stays disabled under frozen-cc (CONFLUENCE-only placeable)", () => {
  const frozenCc = (PERSISTED as { frozenCcMode?: boolean }).frozenCcMode === true;
  if (frozenCc) {
    assert.equal(PERSISTED.disabledStrategies.includes("BASIS_LAG_EDGE"), true);
    const eff = effectiveDisabledStrategies({
      disabledStrategies: PERSISTED.disabledStrategies,
      cheapSide15mEnabled: true,
    });
    assert.equal(eff.includes("BASIS_LAG_EDGE"), true);
  } else {
    // Paper Tier A: LAG may be enabled on disk; evaluator still identity-checks.
    assert.equal(PERSISTED.disabledStrategies.includes("CONFLUENCE_CASCADE"), false);
  }
  // Pure evaluator may still fire for research/shadow.
  const fired = evaluateBasisLagEdge(basisLagObs());
  assert.ok(fired == null || fired.strategyId === "BASIS_LAG_EDGE");
});

test("FROZEN_CC money path keeps PATH/EV floors; freshSpike/TIME/STALE hosts peeled OK", () => {
  // Do not assert.match giant trading-bot.ts blobs (hang risk). Prefer includes.
  assert.equal(BOT_SRC.includes("const freshSpike"), false, "freshSpike host peeled");
  assert.ok(BOT_SRC.includes("PATH_GATE"), "PATH_GATE still referenced");
  assert.ok(/holdToSettlement:\s*false/.test(BOT_SRC), "holdToSettlement false");
  assert.ok(BOT_SRC.includes("evaluateOpenThesis"));
  assert.equal(/directionConfluenceEnabled:\s*true/.test(BOT_SRC), false);
  assert.equal(PERSISTED.disabledStrategies.includes("CONFLUENCE_CASCADE"), false);
  assert.equal(EV_FLOOR, 3);
  assert.equal(kellyFraction(80, 8), 0.60);
});
