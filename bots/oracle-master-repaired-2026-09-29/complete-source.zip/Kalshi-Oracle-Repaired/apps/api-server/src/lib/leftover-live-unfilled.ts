import { leftoverLiveOrderMayRun, leftoverLiveOrderRun } from "./leftover-live-order.js";
import { resolveEntryFillOutcome } from "./orderbook-depth.js";
import { getSecsRemaining } from "./admission.js";
import type { LeftoverLiveUnfilledHelpers } from "./leftover-live-unfilled-funnel.js";

export const LEFTOVER_LIVE_UNFILLED_LOADED = true as const;

export const LEFTOVER_LIVE_UNFILLED_HOST_GUARD =
  "if (!leftoverLiveOrderMayRun(this.config))";

export const FROZEN_LIVE_UNFILLED_MARKERS = [
  "unfilled after 12 s",
  "Re-quoting",
  "cancelUnfilledOrder ran on its own",
] as const;

/** Same chase/sweep floors host historically passed into the unfilled funnel. */
export const LEFTOVER_UNFILLED_MAX_CHASE = 5;
export const LEFTOVER_UNFILLED_SWEEP_PREMIUM = 2;

/**
 * Thin DI bag for leftoverLiveUnfilledFunnel. Pure wiring — no judgment.
 * Host may override MAX_CHASE / SWEEP_PREMIUM to keep a single source of truth.
 */
export function leftoverLiveUnfilledHelpers(
  overrides?: Partial<LeftoverLiveUnfilledHelpers>,
): LeftoverLiveUnfilledHelpers {
  return {
    resolveEntryFillOutcome,
    getSecsRemaining,
    MAX_CHASE: LEFTOVER_UNFILLED_MAX_CHASE,
    SWEEP_PREMIUM: LEFTOVER_UNFILLED_SWEEP_PREMIUM,
    ...overrides,
  };
}

export function leftoverLiveUnfilledMayRun(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverLiveOrderMayRun(cfg);
}

export function leftoverLiveUnfilledHostDenied(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverLiveUnfilledMayRun(cfg) === false;
}

export function leftoverLiveUnfilledRun(
  cfg: { paperMode?: boolean; frozenCcMode?: boolean },
  run: () => Promise<void>,
): Promise<void> {
  if (!leftoverLiveUnfilledMayRun(cfg)) return Promise.resolve();
  return leftoverLiveOrderRun(cfg, run).then(() => undefined);
}
