/**
 * Leftover live Kalshi fill-status poll + partial-entry remainder cancel.
 * Paper fills never call these. Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
import { KALSHI_API_DOMAIN, kalshiEventsOrderPath, kalshiOrderStatusPath } from "./constants.js";
import { fetchWithRetry } from "./fetch-retry.js";
import { kalshiAuthHeadersAsync } from "./kalshi-auth.js";
import { observedFilledContracts } from "./settlement-commit.js";
import {
  leftoverIsTerminalEntryOrderStatus as isTerminalEntryOrderStatus,
  leftoverResolveEntryFillOutcome as resolveEntryFillOutcome,
} from "./leftover-live-fill-status.js";

export const LEFTOVER_LIVE_FILL_STATUS_FUNNEL_LOADED = true as const;

export const FROZEN_LIVE_FILL_STATUS_MARKERS = [
  "kalshiOrderStatusPath(orderId)",
  "executed-without-count",
  "Partial entry",
  "remainder cancellation outcome is unknown",
] as const;

export type LeftoverEntryOrderStatusSnapshot = {
  filled: number;
  status: string;
  avgPriceCents: number | null;
};

/**
 * GO EXECUTION INTEGRITY BATCH — A1 (order lifecycle durability).
 *
 * A 2xx response from Kalshi's order-placement endpoint means the order was
 * ACCEPTED, not that it filled. Every caller that needs to know whether a
 * position actually changed (exit, add-to-position) must poll this real
 * order-status endpoint and treat the result as the source of truth — never
 * assume a fill from the placement response alone.
 *
 * `confirmed: false` means every poll attempt failed to get a definitive
 * read from Kalshi (network/API failure throughout the window). Callers
 * MUST treat that as unknown/unresolved — NOT as filled and NOT as
 * failed-to-fill. A timeout is never a success.
 */
export async function leftoverLivePollOrderFillStatus(this: any, 
  orderId: string,
  opts: { attempts?: number; intervalMs?: number; expectedContracts?: number; timeoutMs?: number } = {},
): Promise<{ confirmed: boolean; filled: number; status: string; avgPriceCents: number | null }> {
  const attempts   = opts.attempts   ?? 3;
  const intervalMs = opts.intervalMs ?? 700;
  const timeoutMs  = opts.timeoutMs  ?? 4_000;
  const statusPath = kalshiOrderStatusPath(orderId);
  for (let i = 0; i < attempts; i++) {
    await new Promise(r => setTimeout(r, intervalMs));
    try {
      const sr = await fetchWithRetry(
        `${KALSHI_API_DOMAIN}${statusPath}`,
        { headers: { ...await kalshiAuthHeadersAsync("GET", statusPath), Accept: "application/json" } },
        { attempts: 1, timeoutMs },
      );
      if (!sr.ok) continue; // no definitive read this attempt — keep polling
      const data = (await sr.json()) as { order?: { filled_count?: number; status?: string; avg_price?: number } };
      const filled = observedFilledContracts(data.order?.filled_count);
      const status = (data.order?.status ?? "").toLowerCase();
      const avgPriceCents = data.order?.avg_price != null ? data.order.avg_price * 100 : null;
      // "executed" = FILLED even when filled_count lags/omits (see
      // live-order-fill-stop-bugs memory); canceled/rejected are equally
      // definitive terminal states (0 fill — stop polling, don't wait out
      // the full window for a dead order).
      // Never substitute requested quantity for missing/contradictory fill count.
      // The exit organ treats executed-without-count as reconciliation pending.
      if (filled > 0 || status === "executed" || status === "canceled" || status === "cancelled" || status === "rejected") {
        return { confirmed: true, filled, status, avgPriceCents };
      }
      // still resting — keep polling
    } catch {
      // network hiccup this attempt — keep polling within budget
    }
  }
  return { confirmed: false, filled: 0, status: "unknown", avgPriceCents: null };
}

/** Re-reads a single entry order after a cancellation race. `null` means
 * Kalshi did not give us a definitive snapshot, never that the order is
 * unfilled. */
export async function leftoverLiveFetchEntryOrderStatus(this: any, orderId: string): Promise<LeftoverEntryOrderStatusSnapshot | null> {
  try {
    const statusPath = kalshiOrderStatusPath(orderId);
    const response = await fetchWithRetry(`${KALSHI_API_DOMAIN}${statusPath}`, {
      headers: { ...await kalshiAuthHeadersAsync("GET", statusPath), Accept: "application/json" },
    });
    if (!response.ok) return null;
    const data = (await response.json()) as { order?: { filled_count?: number; status?: string; avg_price?: number } };
    return {
      filled: data.order?.filled_count ?? 0,
      status: (data.order?.status ?? "").toLowerCase(),
      avgPriceCents: data.order?.avg_price != null ? Math.round(data.order.avg_price * 100) : null,
    };
  } catch {
    return null;
  }
}

/**
 * Cancels the still-resting portion of a partial entry. A failed cancellation
 * is inherently ambiguous: the remainder may have filled just before the
 * DELETE reached Kalshi. Re-poll before changing tracked size; when Kalshi
 * cannot confirm a terminal/final size, return null so the caller preserves
 * its original requested size instead of silently under-tracking exposure.
 */
export async function leftoverLiveCancelPartialEntryRemainder(this: any, 
  orderId: string,
  snapshot: LeftoverEntryOrderStatusSnapshot,
  requestedContracts: number,
): Promise<LeftoverEntryOrderStatusSnapshot | null> {
  if (isTerminalEntryOrderStatus(snapshot.status)) return snapshot;

  const cancelPath = kalshiEventsOrderPath(orderId);
  try {
    const cancelResponse = await fetch(`${KALSHI_API_DOMAIN}${cancelPath}`, {
      method: "DELETE",
      headers: { ...await kalshiAuthHeadersAsync("DELETE", cancelPath), Accept: "application/json" },
      signal: AbortSignal.timeout(4_000),
    });
    if (cancelResponse.ok) {
      const decision = resolveEntryFillOutcome(snapshot.filled, requestedContracts);
      this.log("info",
        `✅ Partial entry ${orderId}: cancelled ${decision.remainingContracts} resting contract(s).`
      );
      return snapshot;
    }

    const errText = await cancelResponse.text().catch(() => "");
    this.log("warn",
      `⚠️ Partial entry ${orderId}: cancel remainder returned ${cancelResponse.status}; ` +
      `re-polling before reconciling exposure. ${errText.slice(0, 120)}`
    );
  } catch (cancelErr) {
    this.log("warn",
      `⚠️ Partial entry ${orderId}: cancel remainder errored; re-polling before reconciling exposure. ` +
      `${(cancelErr as Error).message}`
    );
  }

  const rePolled = await this.fetchEntryOrderStatus(orderId);
  if (!rePolled) {
    this.log("warn",
      `🚨 Partial entry ${orderId}: remainder cancellation outcome is unknown. ` +
      `Keeping the original ${requestedContracts}-contract position tracked until Kalshi confirms final size.`
    );
    return null;
  }

  // A later terminal snapshot must not erase contracts we already observed
  // filled. Preserve the higher count if Kalshi's fields are still catching
  // up independently.
  const reconciledSnapshot: LeftoverEntryOrderStatusSnapshot = {
    ...rePolled,
    filled: Math.max(snapshot.filled, rePolled.filled),
  };
  const effectiveFilled = reconciledSnapshot.status === "executed"
    ? requestedContracts
    : reconciledSnapshot.filled;
  const decision = resolveEntryFillOutcome(effectiveFilled, requestedContracts);
  if (isTerminalEntryOrderStatus(reconciledSnapshot.status) || decision.action === "full") {
    this.log("info",
      `📋 Partial entry ${orderId}: re-poll reconciled ${decision.filled}/${requestedContracts} ` +
      `filled (status=${reconciledSnapshot.status || "unknown"}).`
    );
    return reconciledSnapshot;
  }

  this.log("warn",
    `🚨 Partial entry ${orderId}: re-poll remains non-terminal ` +
    `(${decision.filled}/${requestedContracts}, status=${reconciledSnapshot.status || "unknown"}). ` +
    `Keeping the original requested size tracked until a final Kalshi snapshot is available.`
  );
  return null;
}

