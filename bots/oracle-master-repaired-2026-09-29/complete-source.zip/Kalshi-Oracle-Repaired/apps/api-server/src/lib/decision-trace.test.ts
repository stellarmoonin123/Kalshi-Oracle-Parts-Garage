/**
 * decision-trace.test.ts
 *
 * GO — SPECIALIST REGIME SYSTEM, Phase 0 (DecisionTrace).
 *
 * Proves the two behavior-neutral guarantees from the spec:
 *   1. Every existing skip code in the live decision pipeline maps onto a
 *      valid closed code (never undefined, never throws) — "every skip path
 *      sets a closed code".
 *   2. persistDecisionTrace() never throws (fail-closed, logging must never
 *      affect trading) and applies the spec's persistence rule: unconditional
 *      for ORDER, and for SKIP only when the closed code is EV_FAIL or
 *      SIZE_ZERO.
 *
 * Run with:  tsx --test src/lib/decision-trace.test.ts
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import {
  mapToClosedCode, generateTraceId, persistDecisionTrace, namedTracePricing,
  CLOSED_SKIP_CODES, type ClosedSkipCode,
} from "./decision-trace.js";

// Every raw rejection code string passed to logSkippedDecision(...) anywhere
// in trading-bot.ts as of Phase 0 (grep-audited). If a future call site adds
// a new code, this list — and the exhaustiveness this test enforces — should
// be updated alongside it; an unmapped code still safely falls through to
// OTHER (see mapToClosedCode), it just won't be exercised by this test.
const KNOWN_RAW_CODES = [
  "SESSION_FAMILY_SUPPRESSED", "STRATEGY_MANUAL_DISABLE", "ENTRY_PRICE_BAND",
  "HARVEST_PRICE_BAND", "PATH_GATE", "LAG_DISAGREE", "THESIS_BREAK_COOLDOWN",
  "REGIME_EV_FILTER", "SPREAD_GATE", "PRICE_BAND_SKIP", "PRICE_BAND_HALF",
  "EV_PRE_CHECK", "OVERPAY_GATE", "MTF_FILTER", "CONFIDENCE_FLOOR",
  "PROTECT_MODE", "HARD_ENTRY_FILTER", "EV_FLOOR", "PRETRADE_SIM",
  "STRATEGY_REGIME_BLOCK", "ARIA_VETO", "SETTLEMENT_VETO",
  "QUOTE_STALE_POST_SIM", "QUOTE_MOVED_POST_SIM", "STRATEGY_PAPER_ONLY",
  "BALANCE_STALE", "DAILY_TARGET_LATE_BLOCK", "SIZING_ZERO", "RISK_PROFILE",
  "DAILY_TARGET_SIZE_ZERO", "DRAWDOWN_GUARD", "ENTRY_GUARDS",
  "OTM_EV_NO_EDGE", "OTM_EV_FLOOR",
];

test("T1: every known raw skip code maps to a valid closed code", () => {
  for (const code of KNOWN_RAW_CODES) {
    const closed = mapToClosedCode(code);
    assert.ok(
      (CLOSED_SKIP_CODES as readonly string[]).includes(closed),
      `${code} mapped to invalid closed code ${closed}`
    );
  }
});

test("T2: an unrecognized raw code falls through to OTHER, never throws", () => {
  assert.equal(mapToClosedCode("SOME_FUTURE_CODE_NOT_YET_MAPPED"), "OTHER");
});

test("T3: PATH_GATE content-sniffs FEED_DEAD from a vol-buffer-stale reason", () => {
  assert.equal(
    mapToClosedCode("PATH_GATE", ["vol buffer stale for 3 consecutive cycles — blocked"]),
    "FEED_DEAD"
  );
});

test("T4: PATH_GATE content-sniffs CONSENSUS from a consensus/score reason", () => {
  assert.equal(
    mapToClosedCode("PATH_GATE", ["pre-trade sim rejected: consensus score 42 < 60"]),
    "CONSENSUS"
  );
});

test("T5: PATH_GATE defaults to EV_FAIL for an unrecognized sub-reason", () => {
  assert.equal(mapToClosedCode("PATH_GATE", ["something else entirely"]), "EV_FAIL");
});

test("T6: direct-mapped codes are stable and exact", () => {
  const expectations: Array<[string, ClosedSkipCode]> = [
    ["CONFIDENCE_FLOOR", "CONF_FLOOR"],
    ["EV_FLOOR", "EV_FAIL"],
    ["STRATEGY_REGIME_BLOCK", "REGIME_HOLD"],
    ["QUOTE_STALE_POST_SIM", "QUOTE_STALE"],
    ["QUOTE_MOVED_POST_SIM", "QUOTE_STALE"],
    ["SIZING_ZERO", "SIZE_ZERO"],
    ["DAILY_TARGET_LATE_BLOCK", "DAILY_HALT"],
    ["BALANCE_STALE", "FEED_DEAD"],
  ];
  for (const [raw, expected] of expectations) {
    assert.equal(mapToClosedCode(raw), expected, `${raw} should map to ${expected}`);
  }
});

test("T7: generateTraceId produces unique, non-empty ids", () => {
  const a = generateTraceId();
  const b = generateTraceId();
  assert.ok(a.length > 0);
  assert.ok(b.length > 0);
  assert.notEqual(a, b);
});

test("T8: persistDecisionTrace never throws for an ORDER outcome", async () => {
  await assert.doesNotReject(persistDecisionTrace({
    traceId: generateTraceId(), ts: Date.now(), ticker: "KXBTC15M-TEST",
    side: "yes", outcome: "ORDER", contracts: 3, ask: 55, chain: ["test"],
  }));
});

test("T9: persistDecisionTrace never throws for a SKIP outcome, any closed code", async () => {
  for (const code of CLOSED_SKIP_CODES) {
    await assert.doesNotReject(persistDecisionTrace({
      traceId: generateTraceId(), ts: Date.now(), ticker: "KXBTC15M-TEST",
      side: "no", outcome: "SKIP", code, rawCode: "TEST_CODE", chain: ["test"],
    }));
  }
});

test("namedTracePricing keeps pWin, signalConfidence, and pSizeContracts distinct", () => {
  const pricing = namedTracePricing({
    pWin: 0.72,
    signalConfidence: 61,
    pSize: 4,
    evCents: 8.5,
  });
  assert.equal(pricing.pWin, 0.72);
  assert.equal(pricing.signalConfidence, 61);
  assert.equal(pricing.pSizeContracts, 4);
  assert.equal(pricing.evCents, 8.5);
  assert.ok(!("p" in pricing), "must not emit a bare p field");
  assert.notEqual(pricing.pWin, pricing.signalConfidence);
  assert.notEqual(pricing.pWin, pricing.pSizeContracts);
});

test("namedTracePricing null-fills missing fields (never confuses p with contracts)", () => {
  const pricing = namedTracePricing({});
  assert.equal(pricing.pWin, null);
  assert.equal(pricing.signalConfidence, null);
  assert.equal(pricing.pSizeContracts, null);
});
