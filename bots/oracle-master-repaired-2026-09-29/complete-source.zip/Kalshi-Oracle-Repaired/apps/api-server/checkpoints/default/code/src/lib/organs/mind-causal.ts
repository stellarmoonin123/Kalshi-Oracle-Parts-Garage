/**
 * mind-causal — causal settle attribution on close.
 *
 * Attribute pnl to side-pick vs exit-timing:
 *   PATH_RIDE_TP (or early exit) with settledSide ≠ side → exit-timing saved wrong side.
 * Learning: weight settle-side mistakes higher than TP-saved wrong sides for side-picker.
 * Pure. No LLM. No floor cuts.
 */
export const MIND_CAUSAL_LOADED = "MIND_CAUSAL_LOADED" as const;

/** Weight for side-picker updates when side was wrong and held to settle. */
export const CAUSAL_WEIGHT_SETTLE_MISTAKE = 1.0 as const;

/** Weight when early exit saved a wrong side (less blame on side-picker). */
export const CAUSAL_WEIGHT_EXIT_SAVED = 0.25 as const;

/** Weight when side matched settle. */
export const CAUSAL_WEIGHT_SIDE_CORRECT = 0.5 as const;

export type CausalAttribution = {
  sideCorrect: boolean | null;
  exitSavedWrongSide: boolean;
  attribution: "side-pick" | "exit-timing" | "mixed" | "unknown";
  /** Relative weight for side-picker learning updates. */
  weightForSidePicker: number;
  causalNote: string;
  settledSide: "yes" | "no" | null;
  exitReason: string | null;
};

function normSide(s: string | null | undefined): "yes" | "no" | null {
  if (!s) return null;
  const u = String(s).trim().toUpperCase();
  if (u === "YES" || u === "Y") return "yes";
  if (u === "NO" || u === "N") return "no";
  if (u === "yes" || u === "no") return s as "yes" | "no";
  return null;
}

function isEarlyExit(exitReason: string | null | undefined): boolean {
  if (!exitReason) return false;
  const r = String(exitReason).toUpperCase();
  return (
    r.includes("PATH_RIDE_TP") ||
    r.includes("PATH_RIDE_TRAIL") ||
    r.includes("EARLY") ||
    r === "TP" ||
    r.includes("SOFT_TP")
  );
}

function isSettlementExit(exitReason: string | null | undefined): boolean {
  if (!exitReason) return true;
  const r = String(exitReason).toUpperCase();
  return (
    r === "SETTLEMENT" ||
    r === "SETTLED_KALSHI" ||
    r.includes("EXPIRY") ||
    r === "SETTLE"
  );
}

/**
 * Attribute a closed trade's pnl cause for side-picker learning.
 *
 * Rules:
 * 1. settledSide known + side === settledSide → sideCorrect=true
 * 2. settledSide known + side ≠ settledSide + early exit (PATH_RIDE_TP…)
 *    → exitSavedWrongSide=true, attribution=exit-timing, weight=0.25
 * 3. settledSide known + side ≠ settledSide + settlement hold
 *    → sideCorrect=false, attribution=side-pick, weight=1.0
 * 4. settledSide unknown → unknown
 */
export function attributeSettleCausal(input: {
  side: "yes" | "no";
  settledSide?: string | null;
  exitReason?: string | null;
  pnlCents?: number | null;
}): CausalAttribution {
  const settled = normSide(input.settledSide);
  const exitReason = input.exitReason ?? null;
  const early = isEarlyExit(exitReason);
  const settleExit = isSettlementExit(exitReason);

  if (settled == null) {
    return {
      sideCorrect: null,
      exitSavedWrongSide: false,
      attribution: "unknown",
      weightForSidePicker: 0.35,
      causalNote: "settledSide unknown — causal attribution deferred",
      settledSide: null,
      exitReason,
    };
  }

  const sideCorrect = input.side === settled;

  if (sideCorrect) {
    return {
      sideCorrect: true,
      exitSavedWrongSide: false,
      attribution: early ? "mixed" : "side-pick",
      weightForSidePicker: CAUSAL_WEIGHT_SIDE_CORRECT,
      causalNote: early
        ? `side matched settle (${settled.toUpperCase()}) + early exit — mixed credit`
        : `side matched settle (${settled.toUpperCase()}) — side-pick correct`,
      settledSide: settled,
      exitReason,
    };
  }

  // Wrong side
  if (early) {
    return {
      sideCorrect: false,
      exitSavedWrongSide: true,
      attribution: "exit-timing",
      weightForSidePicker: CAUSAL_WEIGHT_EXIT_SAVED,
      causalNote: `PATH_RIDE early exit saved wrong side (side=${input.side} settle=${settled}) — exit-timing; side-picker weight ${CAUSAL_WEIGHT_EXIT_SAVED}`,
      settledSide: settled,
      exitReason,
    };
  }

  if (settleExit) {
    return {
      sideCorrect: false,
      exitSavedWrongSide: false,
      attribution: "side-pick",
      weightForSidePicker: CAUSAL_WEIGHT_SETTLE_MISTAKE,
      causalNote: `held to settle wrong side (side=${input.side} settle=${settled}) — side-pick mistake weight ${CAUSAL_WEIGHT_SETTLE_MISTAKE}`,
      settledSide: settled,
      exitReason,
    };
  }

  // Other exits (hard stop / catastrophic) with wrong side — mixed
  return {
    sideCorrect: false,
    exitSavedWrongSide: false,
    attribution: "mixed",
    weightForSidePicker: 0.7,
    causalNote: `wrong side under ${exitReason ?? "exit"} — mixed attribution weight 0.7`,
    settledSide: settled,
    exitReason,
  };
}
