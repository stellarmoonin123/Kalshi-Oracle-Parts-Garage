/** QUARANTINE(P2): lag-proof research theater */
/**
 * lag-proof.test.ts
 *
 * Catch-up proof + leader race. Not ENABLE_STRATEGY. Does not cut EV/Kelly.
 * Does not bounce. paperMode stays true. LOCKED engines stay off.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  CatchupProof,
  LagMeter,
  lagAgreesWithSide,
  pickLagLeader,
  leaderBeats,
  persistLagProof,
  LAG_PROOF_MIN_EVENTS,
  LAG_CATCHUP_MOVE_USD,
  LAG_LEADER_SWITCH_CONFIRM,
  DEFAULT_LAG_LEADER,
  type LagTick,
  type LeaderScore,
  type LeaderPickState,
} from "./lag-meter.js";
import { classifyLagUnprovenGate } from "./basis-lag-edge.js";

const LIB = path.dirname(fileURLToPath(import.meta.url));
const T0 = 1_724_000_000_000;

function staircaseLeader(n: number, lagSec: number, jumpEvery = 10, jump = 40, start = 80_000): {
  leader: LagTick[];
  follow: LagTick[];
} {
  const leader: LagTick[] = [];
  let px = start;
  for (let i = 0; i < n; i++) {
    if (i > 0 && i % jumpEvery === 0) px += jump;
    leader.push({ tMs: T0 + i * 1000, px });
  }
  const follow: LagTick[] = [];
  for (let i = lagSec; i < leader.length; i++) {
    follow.push({ tMs: leader[i].tMs, px: leader[i - lagSec].px });
  }
  return { leader, follow };
}

test.skip("catch-up proof: delayed follower records leadSeconds/~$jump, proven", () => {
  const { leader, follow } = staircaseLeader(120, 8);
  const proof = new CatchupProof("coinbase");
  let last = proof.snapshot("init");
  const followByMs = new Map(follow.map((t) => [t.tMs, t.px]));
  for (const tick of leader) {
    const f = followByMs.get(tick.tMs);
    if (f == null) continue;
    last = proof.update(tick.tMs, tick.px, f);
  }
  assert.ok(last.events >= LAG_PROOF_MIN_EVENTS, `events ${last.events}`);
  assert.equal(last.proven, true, last.reason);
  assert.ok(last.hitRate != null && last.hitRate >= 0.5, `hitRate ${last.hitRate}`);
  assert.ok(last.medianLeadSeconds != null);
  assert.ok(Math.abs(last.medianLeadSeconds! - 8) <= 2, `median lead ${last.medianLeadSeconds}`);
  assert.ok(last.lastProof != null);
  assert.ok(Math.abs(last.lastProof!.leadDollars) >= LAG_CATCHUP_MOVE_USD);
  assert.equal(last.lastProof!.source, "coinbase");
});

test.skip("unproven → lag_unproven / do not fake 5–15s", () => {
  const { leader } = staircaseLeader(240, 8);
  const proof = new CatchupProof("coinbase");
  let last = proof.snapshot("init");
  for (const tick of leader) {
    last = proof.update(tick.tMs, tick.px, 80_000);
  }
  assert.ok(last.events >= LAG_PROOF_MIN_EVENTS, `events ${last.events}`);
  assert.equal(last.proven, false);
  assert.ok(last.hitRate != null && last.hitRate < 0.5, `hitRate ${last.hitRate}`);

  const meter = new LagMeter();
  const nowMs = leader[leader.length - 1].tMs;
  const kalshiImplied = leader.map((t) => ({ tMs: t.tMs, px: 80_000 }));
  const reading = meter.update({ coinbase: leader, kalshiImplied }, { nowMs });
  assert.equal(reading.proven, false);
  assert.equal(reading.stale, true);
  assert.ok(reading.reason === "lag_unproven" || reading.stale, reading.reason);
  assert.equal(reading.proven, false);
  assert.equal(reading.lagSeconds, null, "must not fake 5–15s");
  assert.equal(reading.lagDollars, null);
});

test.skip("leader hysteresis: does not flicker every tick; switches after confirm", () => {
  const coinbase: LeaderScore = {
    name: "coinbase",
    latencyMs: 20,
    corr: 0.7,
    hitRate: 0.8,
    medianLeadSeconds: 8,
    medianAbsDollars: 25,
    proven: true,
    stale: false,
  };
  const binanceFaster: LeaderScore = {
    name: "binance",
    latencyMs: 10,
    corr: 0.82,
    hitRate: 0.85,
    medianLeadSeconds: 3,
    medianAbsDollars: 28,
    proven: true,
    stale: false,
  };
  assert.equal(leaderBeats(binanceFaster, coinbase), true);
  let state: LeaderPickState = { leaderName: DEFAULT_LAG_LEADER, challenger: null, votes: 0 };
  const scores = [coinbase, binanceFaster];
  for (let i = 0; i < LAG_LEADER_SWITCH_CONFIRM - 1; i++) {
    state = pickLagLeader(scores, state);
    assert.equal(state.leaderName, "coinbase", `must not switch on vote ${i + 1}`);
    assert.equal(state.challenger, "binance");
  }
  state = pickLagLeader(scores, state);
  assert.equal(state.leaderName, "binance");

  const coinbaseFlicker: LeaderScore = { ...coinbase, corr: 0.83, medianLeadSeconds: 7.5 };
  let flicker: LeaderPickState = { leaderName: "binance", challenger: null, votes: 0 };
  flicker = pickLagLeader([coinbaseFlicker, binanceFaster], flicker);
  assert.equal(flicker.leaderName, "binance", "hysteresis holds the faster proven leader");
});

test.skip("Coinbase-only still works when Binance series is empty", () => {
  const { leader, follow } = staircaseLeader(180, 8);
  const meter = new LagMeter();
  const last = meter.update({ coinbase: leader, kalshiImplied: follow, binance: [] }, { nowMs: leader[leader.length - 1].tMs });
  assert.equal(last.leaderName, "coinbase");
  assert.equal(meter.getLeaderName(), "coinbase");
});

test.skip("lagAgreesWithSide fail-closed if !proven or stale", () => {
  assert.equal(lagAgreesWithSide("yes", 12), true);
  assert.equal(lagAgreesWithSide("yes", 12, { proven: true, stale: false }), true);
  assert.equal(lagAgreesWithSide("yes", 12, { proven: false, stale: false }), false);
  assert.equal(lagAgreesWithSide("yes", 12, { proven: true, stale: true }), false);
});

test.skip("persist last N proofs to json/jsonl (no secrets)", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "lag-proof-"));
  persistLagProof({ leadSeconds: 8, leadDollars: 40, source: "coinbase", ts: T0 }, dir);
  persistLagProof({ leadSeconds: 3, leadDollars: -22, source: "binance", ts: T0 + 1000 }, dir);
  const json = JSON.parse(fs.readFileSync(path.join(dir, "lag-proofs.json"), "utf8")) as { n: number; proofs: unknown[] };
  assert.equal(json.n, 2);
  const lines = fs.readFileSync(path.join(dir, "lag-proofs.jsonl"), "utf8").trim().split("\n");
  assert.equal(lines.length, 2);
  assert.equal(JSON.stringify(json).includes("secret"), false);
  assert.equal(JSON.stringify(json).includes("apiKey"), false);
});

test.skip("LOCKED engines still off; no EV floor edits", () => {
  const bot = fs.readFileSync(path.join(LIB, "trading-bot.ts"), "utf8");
  const lockedStart = bot.indexOf("const LOCKED_DISABLED_STRATEGIES");
  assert.ok(lockedStart >= 0);
  const locked = bot.slice(lockedStart, lockedStart + 1800);
  for (const id of ["SAKATA_CANDLE_PATTERN", "MTF_ALIGNED", "DEEP_OTM_SNIPER", "OTM_ASYMMETRY", "OTM_BREAKOUT_EXPANSION"]) {
    assert.ok(locked.includes("'" + id + "'"), id);
  }
  // BRTI unlocked PAPER DESK v2 Tier A — not in LOCKED_DISABLED_STRATEGIES
  assert.equal(locked.includes("'BRTI_PROBABILITY'"), false);
  assert.equal(/SETTLEMENT_LAG/.test(locked), false);
  const adm = fs.readFileSync(path.join(LIB, "admission.ts"), "utf8");
  assert.match(adm, /export const EV_FLOOR = 3;/);
  assert.match(adm, /export const OTM_EV_FLOOR = 5;/);
  assert.equal(/export const EV_FLOOR\s*=\s*[012]\b/.test(adm), false);
  const edgeLocks = fs.readFileSync(path.join(LIB, "basis-lag-edge.ts"), "utf8");
  assert.match(edgeLocks, /BASIS_LAG_FULLY_PRICED_ASK = 90/);
  const edge = fs.readFileSync(path.join(LIB, "basis-lag-edge.ts"), "utf8");
  assert.match(edge, /BASIS_LAG_FULLY_PRICED_ASK = 90/);
});

test.skip("LAG_UNPROVEN classifier never fakes 5–15s; original lock both modes", () => {
  const proven = classifyLagUnprovenGate({ lagProven: true, lagStale: false, leadSeconds: 8, leadDollars: 40, sideAsk: 30 });
  assert.equal(proven.kind, "PROVEN");
  assert.equal(proven.proceed, true);
  const remake = classifyLagUnprovenGate({
    lagProven: false, lagStale: false, leadSeconds: 5, leadDollars: 15, proofHitRate: 0.5, sideAsk: 30,
  });
  assert.equal(remake.kind, "ORIGINAL_LOCK");
  assert.equal(remake.proceed, false, "unproven skip even cheap");
  const rich = classifyLagUnprovenGate({
    lagProven: false, lagStale: false, leadSeconds: 5, leadDollars: 15, proofHitRate: 0.5, sideAsk: 68,
  });
  assert.equal(rich.proceed, false);
  const lock = classifyLagUnprovenGate({ lagProven: false, lagStale: true, leadSeconds: undefined, leadDollars: undefined, sideAsk: 30 });
  assert.equal(lock.kind, "ORIGINAL_LOCK");
  assert.equal(lock.proceed, false);
  assert.equal(lock.reasonCode, "LAG_UNPROVEN");
  assert.match(lock.reason, /never fake 5–15s|inventing 5–15s/);
});
