import { test } from "node:test";
import assert from "node:assert/strict";
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import {
  ALL_STRATEGY_IDS,
  FROZEN_CC_STRATEGY_ID,
  appendFrozenLedgerRow,
  applyFrozenCcLocks,
  buildFrozenShadowPreDecision,
  enrichFrozenShadowPostTake,
  formatFrozenCcTakeDesc,
  decideFrozenCcEntry,
  decideFrozenCcExit,
  FROZEN_CC_CATASTROPHIC_SUSTAIN_MS,
  emptyShadowFlags,
  holdToSettlementPnlCents,
  readFrozenLedger,
  shouldBlockPlaceOrderWithoutFrozenDecision,
  summarizeFrozenLedger,
  uniqueFrozenSettledCloses,
  computePromoteVerdict,
  FROZEN_CC_TARGET_N,
  AND_SIT_HA_REGIME,
  andSitWouldBlockLive,
  andSitHardBlocksEntry,
  type FrozenLedgerCloseRow,
  type FrozenLedgerFillRow,
  type FrozenCcEntryInput,
} from "./frozen-cc.js";
import { shouldBlockPlaceOrderWithoutOrganTake } from "./organs/director.js";
import { applyComposerLocks } from "./composer-lock.js";
import type { AlignedTake } from "./aligned-take-gate.js";
import { fileURLToPath } from "node:url";

const take = (side: "yes" | "no", ask: number, extra: Partial<Extract<AlignedTake, { kind: "TAKE" }>> = {}): AlignedTake =>
  ({ kind: "TAKE", strategyId: "CONFLUENCE_CASCADE", side, ask, p: 0.6, ev: 4.2, ...extra });

const base: FrozenCcEntryInput = {
  secsRemaining: 8 * 60,
  yesAsk: 40,
  noAsk: 62,
  cc: { signal: "YES" as const, confidence: 0.7, reason: "3/3 aligned" },
  aligned: take("yes", 40),
  shadow: emptyShadowFlags(),
};

test("frozen entry: TAKE when CC fires, aligned agrees, band + window ok", () => {
  const d = decideFrozenCcEntry(base);
  assert.equal(d.kind, "TAKE");
  if (d.kind === "TAKE") {
    assert.equal(d.side, "yes");
    assert.equal(d.ask, 40);
    assert.equal(d.strategyId, FROZEN_CC_STRATEGY_ID);
  }
});

test("frozen entry: time window 3..13 min is hard", () => {
  assert.equal(decideFrozenCcEntry({ ...base, secsRemaining: 179 }).kind, "SKIP");
  assert.equal(decideFrozenCcEntry({ ...base, secsRemaining: 781 }).kind, "SKIP");
  assert.equal(decideFrozenCcEntry({ ...base, secsRemaining: 180 }).kind, "TAKE");
  assert.equal(decideFrozenCcEntry({ ...base, secsRemaining: 780 }).kind, "TAKE");
  const d = decideFrozenCcEntry({ ...base, secsRemaining: 60 });
  assert.equal(d.kind === "SKIP" && d.code, "FROZEN_TIME_WINDOW");
});

test("frozen entry: CC must actually fire", () => {
  const d1 = decideFrozenCcEntry({ ...base, cc: null });
  assert.equal(d1.kind === "SKIP" && d1.code, "FROZEN_CC_NOT_FIRED");
  const d2 = decideFrozenCcEntry({ ...base, cc: { signal: "STAY_OUT", confidence: 0 } });
  assert.equal(d2.kind === "SKIP" && d2.code, "FROZEN_CC_NOT_FIRED");
});

test("frozen entry: aligned SKIP / other strategy / side disagreement all skip", () => {
  const d1 = decideFrozenCcEntry({ ...base, aligned: { kind: "SKIP", reason: "ev_below_3" } });
  assert.equal(d1.kind === "SKIP" && d1.code, "FROZEN_ALIGNED_SKIP");
  const d2 = decideFrozenCcEntry({ ...base, aligned: take("yes", 40, { strategyId: "BASIS_LAG_EDGE" }) });
  assert.equal(d2.kind === "SKIP" && d2.code, "FROZEN_ALIGNED_NOT_CC");
  const d3 = decideFrozenCcEntry({ ...base, aligned: take("no", 62), noAsk: 62 });
  assert.equal(d3.kind === "SKIP" && d3.code, "FROZEN_SIDE_DISAGREE");
});

test("frozen entry: band 20..55 both sides, coin-flip 48..52 excluded (C-money)", () => {
  const at = (ask: number) => decideFrozenCcEntry({ ...base, yesAsk: ask, aligned: take("yes", ask) });
  assert.equal(at(19).kind, "SKIP");
  assert.equal(at(20).kind, "TAKE");
  assert.equal(at(27).kind, "TAKE");
  assert.equal(at(28).kind, "TAKE");
  assert.equal(at(47).kind, "TAKE");
  const mid = at(48);
  assert.equal(mid.kind === "SKIP" && mid.code, "FROZEN_STILL_MID");
  assert.equal(at(52).kind, "SKIP");
  assert.equal(at(53).kind, "TAKE");
  assert.equal(at(55).kind, "TAKE");
  assert.equal(at(56).kind, "SKIP");
  // NO side uses the same 20 floor (C-money desk door).
  const noLow = decideFrozenCcEntry({ ...base, cc: { signal: "NO", confidence: 0.6 }, noAsk: 19, aligned: take("no", 19) });
  assert.equal(noLow.kind === "SKIP" && noLow.code, "FROZEN_PRICE_BAND");
  const noOk = decideFrozenCcEntry({ ...base, cc: { signal: "NO", confidence: 0.6 }, noAsk: 25, aligned: take("no", 25) });
  assert.equal(noOk.kind, "TAKE");
});

test("frozen exit: single-wick catastrophic does NOT sell; sustained does", () => {
  const common = {
    entryCents: 40, secsRemaining: 300, catastrophicCents: 5, takeProfitCents: null,
    shadowRideKind: "SELL", shadowRideReason: "THESIS_BREAK",
    moneyMachinePathRide: false,
  };
  const hold = decideFrozenCcExit({ ...common, markCents: 30 });
  assert.equal(hold.action, "HOLD");
  assert.equal(hold.action === "HOLD" && hold.shadowWouldSell, "THESIS_BREAK");
  // Single wick ≤5¢ must NOT dump (Stellar wipe: 42→3 one tick).
  const wick = decideFrozenCcExit({ ...common, markCents: 3, catastrophicBelowMs: 0 });
  assert.equal(wick.action, "HOLD");
  const brief = decideFrozenCcExit({
    ...common, markCents: 3, catastrophicBelowMs: FROZEN_CC_CATASTROPHIC_SUSTAIN_MS - 1,
  });
  assert.equal(brief.action, "HOLD");
  const cat = decideFrozenCcExit({
    ...common, markCents: 5, catastrophicBelowMs: FROZEN_CC_CATASTROPHIC_SUSTAIN_MS,
  });
  assert.equal(cat.action === "SELL" && cat.reason, "PATH_RIDE_CATASTROPHIC");
  const tp = decideFrozenCcExit({ ...common, markCents: 90, takeProfitCents: 85 });
  assert.equal(tp.action === "SELL" && tp.reason, "FROZEN_TAKE_PROFIT");
  const noTp = decideFrozenCcExit({ ...common, markCents: 90 });
  assert.equal(noTp.action, "HOLD");
});

test("money-machine: defer to real PATH_RIDE; sustained cat also DEFER (gated cat)", () => {
  const mm = {
    entryCents: 42, secsRemaining: 300, catastrophicCents: 5, takeProfitCents: null,
    shadowRideKind: "SELL", shadowRideReason: "PATH_RIDE_TP",
    moneyMachinePathRide: true,
  };
  const defer = decideFrozenCcExit({ ...mm, markCents: 50 });
  assert.equal(defer.action, "DEFER_PATH_RIDE");
  // Wick: HOLD (not DEFER) so same-tick PATH_RIDE cannot instant-cat.
  const wick = decideFrozenCcExit({ ...mm, markCents: 3, catastrophicBelowMs: 1000 });
  assert.equal(wick.action, "HOLD");
  assert.equal(wick.action === "HOLD" && wick.shadowWouldSell, "PATH_RIDE_CATASTROPHIC");
  // Sustained cat defers to PATH_RIDE gated cat (BROKEN+persist ONLY) — no VALID/UNKNOWN dump here.
  const cat = decideFrozenCcExit({
    ...mm, markCents: 3, catastrophicBelowMs: FROZEN_CC_CATASTROPHIC_SUSTAIN_MS,
  });
  assert.equal(cat.action, "DEFER_PATH_RIDE");
  const tp = decideFrozenCcExit({ ...mm, markCents: 90, takeProfitCents: 85 });
  assert.equal(tp.action === "SELL" && tp.reason, "FROZEN_TAKE_PROFIT");
});

test("hold-to-settlement counterfactual is fee-aware", () => {
  // 1 contract at 40¢: raw fee 0.07*0.4*0.6*100 = 1.68¢ -> ceil 2¢
  assert.equal(holdToSettlementPnlCents({ side: "yes", entryCents: 40, contracts: 1, settledSide: "yes" }), 58);
  assert.equal(holdToSettlementPnlCents({ side: "yes", entryCents: 40, contracts: 1, settledSide: "no" }), -42);
  assert.equal(holdToSettlementPnlCents({ side: "yes", entryCents: 40, contracts: 1, settledSide: null }), null);
});

test("config lock forces every re-enable path off while frozen and leaves it alone otherwise", () => {
  const cfg = {
    frozenCcMode: true,
    autoMode: true,
    autoModeV2Mode: "suggest" as const,
    useExpertAgent: true,
    ariaModel: "x",
    paperMode: true,
    specialistPacksMode: "enforce",
    useDailyTarget: true,
    enable1HContracts: true,
    enable1HLive: false,
    holdToSettlement: false,
    strategyOverride: "VELOCITY_MOMENTUM",
    disabledStrategies: [] as string[],
    frozenCcFixedContracts: 0,
    frozenCcTakeProfitCents: 30,
    frozenCcCatastrophicCents: 40,
  };
  const { config, notes } = applyComposerLocks(cfg, { openRouterKey: "k" });
  assert.equal(config.autoMode, false);
  assert.equal(config.autoModeV2Mode, "off");
  assert.equal(config.useExpertAgent, false);
  assert.equal(config.specialistPacksMode, "off");
  assert.equal(config.useDailyTarget, false);
  assert.equal(config.enable1HContracts, false);
  assert.equal(config.holdToSettlement, false); // C-money money-machine: PATH_RIDE sell-green
  assert.equal(config.strategyOverride, null);
  assert.equal(config.disabledStrategies.length, ALL_STRATEGY_IDS.length - 1);
  assert.ok(!config.disabledStrategies.includes("CONFLUENCE_CASCADE"));
  assert.equal(config.frozenCcFixedContracts, null);
  assert.equal(config.frozenCcTakeProfitCents, null);
  assert.equal(config.frozenCcCatastrophicCents, 5);
  assert.ok(notes.some((n) => n.startsWith("FROZEN_CC")));

  const off = applyFrozenCcLocks({ ...cfg, frozenCcMode: false });
  assert.equal(off.notes.length, 0);
  assert.equal(off.config.autoMode, true);
});

test("ledger append/read roundtrip and go/no-go summary", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "frozen-cc-"));
  const file = path.join(dir, "ledger.jsonl");
  const close = (pnl: number, i: number): FrozenLedgerCloseRow => ({
    kind: "CLOSE", ruleset: "t", gitSha: null, ts: i, ticker: `T${i}`, strategyId: "CONFLUENCE_CASCADE",
    side: "yes", askCents: 40, contracts: 1, exitReason: "SETTLEMENT", exitPriceCents: null, holdMs: 1000,
    outcome: pnl > 0 ? "win" : "loss", pnlCents: pnl,
    feeNetCents: pnl, skipPnlCents: 0, feeNetVsSkip: pnl - 0,
    entryFeeCents: 2, exitFeeCents: 0, settledSide: "yes",
    holdToSettlePnlCents: pnl, exitVsHoldCents: 0, shadowExitWouldSell: null, shadowExitFirstAtMs: null,
    shadow: emptyShadowFlags(),
  });
  appendFrozenLedgerRow(close(58, 1), file);
  appendFrozenLedgerRow(close(-42, 2), file);
  const rows = readFrozenLedger(file);
  assert.equal(rows.length, 2);
  const c0 = rows[0] as FrozenLedgerCloseRow;
  assert.equal(c0.feeNetCents, 58);
  assert.equal(c0.skipPnlCents, 0);
  assert.equal(c0.feeNetVsSkip, 58);
  const s = summarizeFrozenLedger(rows, 200);
  assert.equal(s.closes, 2);
  assert.equal(s.pnlCents, 16);
  assert.equal(s.verdict, "INSUFFICIENT_DATA");

  const many = Array.from({ length: 200 }, (_, i) => close(i % 3 === 0 ? -42 : 58, i));
  const go = summarizeFrozenLedger(many, 200);
  assert.equal(go.verdict, "GO");
  const bad = summarizeFrozenLedger(Array.from({ length: 200 }, (_, i) => close(i % 2 === 0 ? -42 : 30, i)), 200);
  assert.equal(bad.verdict, "NO_GO");
  fs.rmSync(dir, { recursive: true, force: true });
});

const BOT_SRC = fs.readFileSync(
  path.join(path.dirname(fileURLToPath(import.meta.url)), "trading-bot.ts"),
  "utf8",
);

test("FrozenLedger CLOSE writer stamps feeNetCents/feeNetVsSkip/skipPnlCents", () => {
  // CLOSE row may be stamped in trading-bot settle path and/or trade-story peel.
  const STORY_SRC = fs.readFileSync(
    path.join(path.dirname(fileURLToPath(import.meta.url)), "trade-story.ts"),
    "utf8",
  );
  const hasBotClose =
    /kind:\s*"CLOSE"/.test(BOT_SRC) &&
    /feeNetCents/.test(BOT_SRC) &&
    /skipPnlCents:\s*0/.test(BOT_SRC) &&
    /feeNetVsSkip:\s*feeNetCents\s*-\s*0/.test(BOT_SRC);
  const hasStoryClose =
    /skipPnlCents:\s*0/.test(STORY_SRC) &&
    /feeNetVsSkip:\s*feeNetCents\s*-\s*0/.test(STORY_SRC);
  assert.ok(hasBotClose || hasStoryClose, "CLOSE fee-net vs skip baseline must be stamped");
  assert.match(BOT_SRC, /feeNetCents/);
  assert.match(BOT_SRC, /skipPnlCents:\s*0/);
});

test("frozenCcMode true → placeOrder requires frozen TAKE path (dual-brain kill)", () => {
  assert.equal(shouldBlockPlaceOrderWithoutFrozenDecision({ frozenCcMode: false, frozenCc: false }), false);
  assert.equal(shouldBlockPlaceOrderWithoutFrozenDecision({ frozenCcMode: undefined, frozenCc: undefined }), false);
  assert.equal(shouldBlockPlaceOrderWithoutFrozenDecision({ frozenCcMode: true, frozenCc: true }), false,
    "decideFrozenCcEntry TAKE stamps frozenCc:true — allow");
  assert.equal(shouldBlockPlaceOrderWithoutFrozenDecision({ frozenCcMode: true, frozenCc: false }), true,
    "legacy funnel without frozen stamp — BLOCK");
  assert.equal(shouldBlockPlaceOrderWithoutFrozenDecision({ frozenCcMode: true, frozenCc: undefined }), true,
    "omitted frozenCc is not a frozen decision — BLOCK");
  assert.match(BOT_SRC, /shouldBlockPlaceOrderWithoutFrozenDecision\(/);
  assert.match(BOT_SRC, /FROZEN_CC_SOLE_TAKE/);
  assert.match(BOT_SRC, /decideFrozenCcEntry\(/);
  assert.match(BOT_SRC, /frozenCc:\s*true/);
  // When frozenCcMode, evaluateEntry must short-circuit (return) after frozen place/skip —
  // legacy funnel placeOrder at end of evaluateEntry must not be reachable without the stamp.
  // Prefer evaluateEntry short-circuit (decideFrozenCcEntry), not F-B1 advisory gate.
  const frozenBlock = BOT_SRC.indexOf("const frozen = decideFrozenCcEntry(");
  assert.ok(frozenBlock > 0, "frozenCcMode evaluateEntry decideFrozenCcEntry present");
  // +8k: YES_40_55_PIN_SHADOW_V1 observe hook sits between decide and placeOrder.
  const blockEnd = BOT_SRC.indexOf("// ──", frozenBlock + 1);
  const after = BOT_SRC.slice(Math.max(0, frozenBlock - 5000), blockEnd > frozenBlock ? blockEnd : undefined);
  assert.ok(
    /this\.config\.frozenCcMode === true/.test(after) ||
      /frozenSixGateIsOnlyEvaluatePath\(this\.config\)/.test(after),
    "frozenCcMode door (direct or frozenSixGateIsOnlyEvaluatePath) must guard decideFrozenCcEntry",
  );
  assert.match(after, /decideFrozenCcEntry\(/);
  assert.match(after, /await this\.placeOrder\(/);
  assert.match(after, /frozenCc:\s*true/);
  assert.match(after, /andSitArmed:\s*this\.config\.frozenCcAndSit === true/);
  assert.match(after, /return;/);
  // Observe-only: classify is called but must not rewrite frozen.kind / gate placeOrder.
  assert.match(after, /classifyFrozenCcEntryShadow\(/);
  assert.match(after, /OBSERVE ONLY/);
  const classifyAt = after.indexOf("classifyFrozenCcEntryShadow(");
  const placeAt = after.indexOf("await this.placeOrder(");
  assert.ok(classifyAt >= 0 && placeAt > classifyAt, "shadow classify before placeOrder");
  assert.equal(/if\s*\(\s*shadowClass\.shadowSit/.test(after), false, "shadowSit must not gate placeOrder");
  assert.equal(/frozen\.kind\s*=(?!=)/.test(after), false, "must not assign frozen.kind after decide");
});

test("buildFrozenShadowPreDecision stamps aligned + W2 before decideFrozenCcEntry", () => {
  const shadow = buildFrozenShadowPreDecision({
    w2Kind: "SKIP",
    w2Reason: "ha_disagree",
    sessionMode: "HARVEST",
    harvestWouldSuppress: true,
    regime: "range",
    grokRegime: "ranging",
    regimeWouldBlock: true,
    mtfScore: -0.4,
    lagProven: false,
    lagStale: true,
    lagDollars: 5,
    velocityDolPerMin: 40,
    consecutiveLosses: 2,
    ccConfidence: 0.7,
    ccReason: "3/3",
    aligned: take("yes", 40),
  });
  assert.equal(shadow.w2Kind, "SKIP");
  assert.equal(shadow.w2Reason, "ha_disagree");
  assert.equal(shadow.alignedKind, "TAKE");
  assert.equal(shadow.alignedStrategyId, "CONFLUENCE_CASCADE");
  assert.equal(shadow.harvestWouldSuppress, true);
  assert.match(BOT_SRC, /buildFrozenShadowPreDecision\(/);
});

test("enrichFrozenShadowPostTake stamps ccVel / HTF / spread after TAKE", () => {
  const base = buildFrozenShadowPreDecision({
    w2Kind: "PASS",
    w2Reason: null,
    sessionMode: "HUNT",
    harvestWouldSuppress: false,
    regime: "trend",
    grokRegime: "trending",
    regimeWouldBlock: false,
    mtfScore: 0.5,
    lagProven: true,
    lagStale: false,
    lagDollars: -12,
    velocityDolPerMin: -80,
    consecutiveLosses: 0,
    ccConfidence: 0.8,
    ccReason: "3/3",
    aligned: take("no", 34),
  });
  const enriched = enrichFrozenShadowPostTake({
    shadow: base,
    side: "no",
    ask: 34,
    ccVelocityWouldBlock: "CC_VEL_AGAINST_NO",
    htfSideBias: "YES",
    bidCents: 30,
  });
  assert.equal(enriched.ccVelocityWouldBlock, "CC_VEL_AGAINST_NO");
  assert.equal(enriched.htfWouldBlock, true, "NO take vs YES HTF → would block");
  assert.equal(enriched.spreadCents, 4);
  const desc = formatFrozenCcTakeDesc({
    side: "no", ask: 34, p: 0.62, ev: 4.5, secs: 400, mtfScore: 0.5, shadow: enriched,
  });
  assert.match(desc, /\[FROZEN_CC\] TAKE NO @ 34¢/);
  assert.match(desc, /ccVel=CC_VEL_AGAINST_NO/);
  assert.match(BOT_SRC, /enrichFrozenShadowPostTake\(/);
  assert.match(BOT_SRC, /formatFrozenCcTakeDesc\(/);
});

test("organ take gate idle when frozenCcMode true (FROZEN_CC_SOLE_TAKE sole)", () => {
  assert.equal(shouldBlockPlaceOrderWithoutOrganTake({ frozenCcMode: true, organAction: null }), false);
  assert.equal(shouldBlockPlaceOrderWithoutOrganTake({ frozenCcMode: true, organAction: "skip" }), false);
  assert.equal(shouldBlockPlaceOrderWithoutOrganTake({ frozenCcMode: false, organAction: null }), true,
    "non-frozen without take stamp fail-closed");
  assert.match(BOT_SRC, /shouldBlockPlaceOrderWithoutOrganTake\(/);
  assert.match(BOT_SRC, /DIRECTOR_TAKE_REQUIRED/);
});


test("F-L: progressLabel always shows goNoGoTargetN=200; ccVel null excluded; skipBaseline labeled", () => {
  const close = (shadow: Record<string, unknown>, pnl: number): FrozenLedgerCloseRow => ({
    kind: "CLOSE",
    ruleset: "frozen-cc-v1",
    gitSha: null,
    ts: Date.now(),
    ticker: `T-${pnl}-${Math.random().toString(16).slice(2, 6)}`,
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    askCents: 40,
    contracts: 1,
    exitReason: "SETTLEMENT",
    exitPriceCents: null,
    holdMs: 60_000,
    outcome: pnl >= 0 ? "win" : "loss",
    pnlCents: pnl,
    entryFeeCents: 1,
    exitFeeCents: 0,
    settledSide: "yes",
    holdToSettlePnlCents: pnl,
    exitVsHoldCents: 0,
    shadowExitWouldSell: null,
    shadowExitFirstAtMs: null,
    feeNetCents: pnl,
    skipPnlCents: 0,
    feeNetVsSkip: pnl,
    shadow: { ...emptyShadowFlags(), ...shadow } as ReturnType<typeof emptyShadowFlags>,
  });
  // N=10 starvation fixture — progress must mention target 200
  const rows = Array.from({ length: 10 }, (_, i) =>
    close({ ccVelocityWouldBlock: i < 3 ? "CC_VEL" : null, harvestWouldSuppress: false }, i % 2 === 0 ? 40 : -30),
  );
  const v = computePromoteVerdict(rows);
  assert.equal(v.goNoGoTargetN, FROZEN_CC_TARGET_N);
  assert.equal(FROZEN_CC_TARGET_N, 200);
  assert.match(v.progressLabel, /200/);
  assert.match(v.progressLabel, /INSUFFICIENT_DATA|goNoGo=/);
  assert.equal(v.readyToPromote, false);
  assert.equal(v.skipBaselineCents, 0);
  assert.equal(v.skipBaselineSource, "never_took");
  assert.equal(v.feeNetVsSkip, v.feeNetCents - v.skipBaselineCents);
  // null ccVel excluded from WITHOUT — nWithout counts only explicit false/absence-as-false no longer
  const velGate = v.gates.find((g) => g.gate === "ccVelocityWouldBlock");
  assert.ok(velGate);
  assert.equal(velGate!.nWith, 3, "only non-null blocks in WITH");
  assert.equal(velGate!.nWithout, 0, "nulls excluded — not coerced into WITHOUT");
});


test("AND sit helpers: only true∧true; OR not used for hard block", () => {
  assert.equal(andSitWouldBlockLive(true, true), true);
  assert.equal(andSitWouldBlockLive(true, false), false);
  assert.equal(andSitWouldBlockLive(false, true), false);
  assert.equal(andSitWouldBlockLive(false, false), false);
  assert.equal(andSitHardBlocksEntry({ armed: true, haDisagree: true, regimeWouldBlock: true }), true);
  assert.equal(andSitHardBlocksEntry({ armed: true, haDisagree: true, regimeWouldBlock: false }), false);
  assert.equal(andSitHardBlocksEntry({ armed: true, haDisagree: false, regimeWouldBlock: true }), false);
  assert.equal(andSitHardBlocksEntry({ armed: true, haDisagree: false, regimeWouldBlock: false }), false);
  assert.equal(andSitHardBlocksEntry({ armed: false, haDisagree: true, regimeWouldBlock: true }), false);
});

test("decideFrozenCcEntry AND sit: armed true+true → AND_SIT_HA_REGIME; singles/OR not wired", () => {
  const both: typeof base = {
    ...base,
    andSitArmed: true,
    shadow: { ...emptyShadowFlags(), w2Reason: "ha_disagree", regimeWouldBlock: true },
  };
  const blocked = decideFrozenCcEntry(both);
  assert.equal(blocked.kind, "SKIP");
  if (blocked.kind === "SKIP") {
    assert.equal(blocked.code, AND_SIT_HA_REGIME);
    assert.match(blocked.reason, /AND sit/);
  }

  // ha only — must TAKE (not OR, not ha-alone)
  const haOnly = decideFrozenCcEntry({
    ...base,
    andSitArmed: true,
    shadow: { ...emptyShadowFlags(), w2Reason: "ha_disagree", regimeWouldBlock: false },
  });
  assert.equal(haOnly.kind, "TAKE", "ha_disagree alone must not hard-sit");

  // regime only — must TAKE
  const regOnly = decideFrozenCcEntry({
    ...base,
    andSitArmed: true,
    shadow: { ...emptyShadowFlags(), w2Reason: null, regimeWouldBlock: true },
  });
  assert.equal(regOnly.kind, "TAKE", "regimeWouldBlock alone must not hard-sit");

  // clean — TAKE
  const clean = decideFrozenCcEntry({
    ...base,
    andSitArmed: true,
    shadow: { ...emptyShadowFlags(), w2Reason: null, regimeWouldBlock: false },
  });
  assert.equal(clean.kind, "TAKE");

  // both but flag OFF historically — TAKE (observe shadow only)
  const flagOff = decideFrozenCcEntry({
    ...base,
    andSitArmed: false,
    shadow: { ...emptyShadowFlags(), w2Reason: "ha_disagree", regimeWouldBlock: true },
  });
  assert.equal(flagOff.kind, "TAKE", "flag false: AND never blocks");

  // omit andSitArmed — TAKE (default unarmed)
  const omit = decideFrozenCcEntry({
    ...base,
    shadow: { ...emptyShadowFlags(), w2Reason: "ha_disagree", regimeWouldBlock: true },
  });
  assert.equal(omit.kind, "TAKE", "omitted andSitArmed defaults off");
});

test("BOT_SRC + routes: frozenCcAndSit wired; hardSits reflects AND; OR not armed", () => {
  assert.match(BOT_SRC, /frozenCcAndSit/);
  assert.match(BOT_SRC, /andSitArmed:\s*this\.config\.frozenCcAndSit === true/);
  const routes = fs.readFileSync(
    path.join(path.dirname(fileURLToPath(import.meta.url)), "../routes/bot.ts"),
    "utf8",
  );
  assert.match(routes, /hardSits:\s*cfg\.frozenCcAndSit === true \? "AND" : "OFF"/);
  // Must not arm OR as LIVE hard sit
  assert.equal(/hardSits:\s*"OR"/.test(routes), false);
  assert.equal(/orSitArmed:\s*true/.test(BOT_SRC), false);
});

test("uniqueFrozenSettledCloses collapses spam CLOSE and prefers PATH_RIDE over SETTLEMENT", () => {
  const fill = (ts: number, ticker: string): FrozenLedgerFillRow => ({
    kind: "FILL", ruleset: "t", gitSha: null, ts, ticker, strategyId: "CONFLUENCE_CASCADE",
    side: "yes", askCents: 40, contracts: 1, secsRemaining: 600, p: 0.6, evCents: 5,
    confidence: 70, entryFeeCents: 2, paper: true,
    entryTheoCents: 40, entryTheoMissing: false, shadow: emptyShadowFlags(),
  });
  const close = (ts: number, ticker: string, outcome: "win" | "loss", pnl: number, exitReason: string): FrozenLedgerCloseRow => ({
    kind: "CLOSE", ruleset: "t", gitSha: null, ts, ticker, strategyId: "CONFLUENCE_CASCADE",
    side: "yes", askCents: 40, contracts: 1, exitReason, exitPriceCents: 50, holdMs: 1000,
    outcome, pnlCents: pnl,
    feeNetCents: pnl, skipPnlCents: 0, feeNetVsSkip: pnl,
    entryFeeCents: 2, exitFeeCents: 1, settledSide: null,
    holdToSettlePnlCents: null, exitVsHoldCents: null, shadowExitWouldSell: null, shadowExitFirstAtMs: null,
    shadow: emptyShadowFlags(),
  });
  const rows = [
    fill(1000, "T-A"),
    close(2000, "T-A", "loss", -400, "SETTLEMENT"),
    close(2100, "T-A", "win", 100, "PATH_RIDE_TP"),
    close(2110, "T-A", "win", 100, "PATH_RIDE_TP"),
    close(2120, "T-A", "win", 100, "PATH_RIDE_TP"),
  ];
  const uniq = uniqueFrozenSettledCloses(rows);
  assert.equal(uniq.length, 1);
  assert.equal(uniq[0]!.exitReason, "PATH_RIDE_TP");
  assert.equal(uniq[0]!.pnlCents, 100);
  const s = summarizeFrozenLedger(rows, 200);
  assert.equal(s.closes, 1);
  assert.equal(s.wins, 1);
  assert.equal(s.fills, 1);
  assert.equal(s.pnlCents, 100);
  // Promote must not call 104 spam closes "strong"
  assert.ok(s.closes < 40);
});

