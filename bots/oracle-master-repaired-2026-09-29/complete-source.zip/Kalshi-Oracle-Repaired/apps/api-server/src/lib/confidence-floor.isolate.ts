/**
 * confidence-floor.isolate.ts — UNCHANGED CONFIDENCE_FLOOR gate from
 * evaluateEntry at isolate time: skip whenever conf < minConfidence.
 * Compare-only. Does not know EV, side-agree, or strategy id.
 */
export function shouldSkipConfidenceFloorIsolate(opts: {
  confidence: number;
  minConfidence: number;
}): boolean {
  return opts.confidence < opts.minConfidence;
}
