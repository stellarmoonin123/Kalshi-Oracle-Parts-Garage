/**
 * kalshi-auth.ts
 *
 * Shared RSA-PSS signing utilities for Kalshi API authentication.
 *
 * Problem: Kalshi generates private keys with the id-RSASSA-PSS OID
 * (1.2.840.113549.1.1.10) in the PKCS#8 AlgorithmIdentifier.  OpenSSL 3.x
 * (Node ≥ 17) rejects these with ERR_OSSL_UNSUPPORTED / DECODER::unsupported.
 *
 * Fix: four loading strategies tried in order:
 *   1. Plain PEM load (works for standard PKCS#8 and PKCS#1 PEM)
 *   2a. DER rewrap: extract inner RSAPrivateKey, wrap in rsaEncryption PKCS#8
 *   2b. DER direct: load the raw DER bytes as PKCS#1 (covers bare-base64 PKCS#1 keys)
 *   2c. Inner extraction: pull OCTET STRING content and load as PKCS#1
 *   3. PKCS#1 header swap: replace PKCS#8 PEM header with RSA PRIVATE KEY
 */

import crypto from "crypto";
import { db, settingsTable } from "@workspace/db";

// ── DER helpers ───────────────────────────────────────────────────────────────

/** Read a DER TLV at `pos`, return tag, content length, and start of content. */
function derRead(buf: Buffer, pos: number): { tag: number; len: number; contentStart: number } {
  const tag = buf[pos++];
  let len = buf[pos++];
  if (len & 0x80) {
    const nb = len & 0x7f;
    len = 0;
    for (let i = 0; i < nb; i++) len = (len << 8) | buf[pos++];
  }
  return { tag, len, contentStart: pos };
}

/** Encode a DER length field. */
function derLen(length: number): Buffer {
  if (length < 0x80) return Buffer.from([length]);
  if (length < 0x100) return Buffer.from([0x81, length]);
  return Buffer.from([0x82, (length >> 8) & 0xff, length & 0xff]);
}

/** Wrap content in a DER TLV. */
function derTLV(tag: number, content: Buffer): Buffer {
  return Buffer.concat([Buffer.from([tag]), derLen(content.length), content]);
}

// ── Key conversion ────────────────────────────────────────────────────────────

/**
 * Given a PKCS#8 DER buffer (RSA or RSA-PSS), extract the inner RSAPrivateKey
 * bytes from the OCTET STRING and return them as a raw PKCS#1 DER buffer.
 */
function extractPkcs1Der(der: Buffer): Buffer {
  const outer = derRead(der, 0);
  if (outer.tag !== 0x30) throw new Error("kalshi-auth: expected outer SEQUENCE");
  let pos = outer.contentStart;

  // Skip version INTEGER
  const ver = derRead(der, pos);
  pos = ver.contentStart + ver.len;

  // Skip algorithmIdentifier SEQUENCE (any OID — we don't care)
  const algId = derRead(der, pos);
  pos = algId.contentStart + algId.len;

  // Read privateKey OCTET STRING content — this is the raw PKCS#1 RSAPrivateKey
  const octet = derRead(der, pos);
  return der.slice(octet.contentStart, octet.contentStart + octet.len);
}

/**
 * Given a PKCS#8 RSA (or RSA-PSS) private key DER buffer, extract the inner
 * RSAPrivateKey and re-wrap it with a plain rsaEncryption AlgorithmIdentifier.
 * Returns the new PKCS#8 DER buffer.
 */
function rewrapAsPkcs8(pkcs1Der: Buffer): Buffer {
  // 30 0d 06 09 2a86 4886 f70d 0101 01 05 00  → rsaEncryption OID + NULL
  const rsaAlgId  = Buffer.from("300d06092a864886f70d0101010500", "hex");
  const version   = Buffer.from("020100", "hex"); // INTEGER 0
  const octetStr  = derTLV(0x04, pkcs1Der);
  return derTLV(0x30, Buffer.concat([version, rsaAlgId, octetStr]));
}

// ── PEM normalisation ────────────────────────────────────────────────────────

/**
 * Accept a PEM or bare-base64 private key string and return a normalised PEM.
 * Handles escaped newlines that may appear when an env var stores the key.
 */
export function normalisePem(raw: string): string {
  let pem = raw.replace(/\\n/g, "\n").trim();
  if (pem.startsWith("-----")) return pem;
  // bare base64 — wrap in PKCS#8 headers
  const b64   = pem.replace(/\s+/g, "");
  const lines = (b64.match(/.{1,64}/g) ?? []).join("\n");
  return `-----BEGIN PRIVATE KEY-----\n${lines}\n-----END PRIVATE KEY-----`;
}

// ── Structural key-format detection ─────────────────────────────────────────
//
// normalisePem() wraps ANY bare base64 input in "-----BEGIN PRIVATE KEY-----"
// (PKCS#8) headers purely by string shape — it never inspects the actual DER
// bytes. That means a bare-base64-encoded PKCS#1 RSAPrivateKey (no PEM
// headers at all) comes out of normalisePem() *looking* like PKCS#8, even
// though loadPrivateKey() only manages to load it via its PKCS#1 DER
// fallback (strategy 2b above). A header-text check like
// `pem.includes("-----BEGIN PRIVATE KEY-----")` is therefore NOT a reliable
// way to tell PKCS#8 apart from PKCS#1 — it only reflects what normalisePem()
// guessed, not what the bytes really are. Any PKCS#1/PKCS#8 compatibility
// decision (paste-key validation, keyCompatible flags, live-signing guards)
// must go through detectKeyFormat() below instead, which validates the
// underlying DER structure with Node's own ASN.1 decoder.

export type KeyFormat = "pkcs8" | "pkcs1" | "unknown";

/** True if `der` is a structurally valid PKCS#8 private-key container. */
function looksLikePkcs8Der(der: Buffer): boolean {
  try {
    // Standard case: Node's own PKCS#8 decoder accepts it outright.
    crypto.createPrivateKey({ key: der, format: "der", type: "pkcs8" });
    return true;
  } catch {
    // RSA-PSS OID case: structurally a valid PKCS#8 wrapper (version +
    // AlgorithmIdentifier + OCTET STRING), but Node rejects the
    // id-RSASSA-PSS OID. extractPkcs1Der() pulls the inner OCTET STRING
    // positionally (it doesn't check the algId OID) — if that inner content
    // is itself a genuine RSAPrivateKey (validated via Node, not just a
    // byte-length guess), the outer container really was PKCS#8-shaped.
    try {
      const inner = extractPkcs1Der(der);
      crypto.createPrivateKey({ key: inner, format: "der", type: "pkcs1" });
      return true;
    } catch {
      return false;
    }
  }
}

/** True if `der` is a structurally valid PKCS#1 RSAPrivateKey. */
function looksLikePkcs1Der(der: Buffer): boolean {
  try {
    crypto.createPrivateKey({ key: der, format: "der", type: "pkcs1" });
    return true;
  } catch {
    return false;
  }
}

/**
 * Determine the *real* key format (pkcs8 / pkcs1 / unknown) from raw user
 * input — a full PEM (either header), a bare-base64 body, or an env-secret
 * value with escaped newlines. Always inspects the actual DER bytes rather
 * than trusting PEM header text, so it correctly classifies bare-base64
 * PKCS#1 keys that normalisePem() would otherwise mislabel as PKCS#8.
 */
export function detectKeyFormat(raw: string): KeyFormat {
  const s = raw.replace(/\\n/g, "\n").trim();
  if (!s) return "unknown";

  if (s.includes("-----BEGIN RSA PRIVATE KEY-----")) return "pkcs1";

  if (s.includes("-----BEGIN PRIVATE KEY-----")) {
    try {
      const b64 = s.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
      const der = Buffer.from(b64, "base64");
      return looksLikePkcs8Der(der) ? "pkcs8" : "unknown";
    } catch {
      return "unknown";
    }
  }

  // Bare base64 (no PEM headers at all): could be raw PKCS#8 or raw PKCS#1
  // DER — string shape alone cannot tell them apart, so decode and check
  // the actual ASN.1 structure.
  const bare = s.replace(/\s+/g, "");
  if (!/^[A-Za-z0-9+/=]+$/.test(bare)) return "unknown";
  try {
    const der = Buffer.from(bare, "base64");
    if (looksLikePkcs8Der(der)) return "pkcs8";
    if (looksLikePkcs1Der(der)) return "pkcs1";
    return "unknown";
  } catch {
    return "unknown";
  }
}

// ── Key loader ───────────────────────────────────────────────────────────────

/**
 * Load a Kalshi private key into a Node.js KeyObject, trying four strategies:
 *
 *   1. Standard PEM load  — PKCS#8 or PKCS#1 PEM (most keys work here)
 *   2. DER-based fallbacks for RSA-PSS OID and format mismatches:
 *      2a. Rewrap as plain rsaEncryption PKCS#8
 *      2b. Load raw DER bytes as PKCS#1 directly
 *      2c. Extract inner OCTET STRING and load as PKCS#1
 *   3. PKCS#1 header swap — replace PKCS#8 PEM header with RSA PRIVATE KEY
 *
 * Throws only if all strategies fail.
 */
export function loadPrivateKey(pem: string): crypto.KeyObject {
  // ── Strategy 1: plain PEM ──────────────────────────────────────────────────
  try {
    return crypto.createPrivateKey({ key: pem, format: "pem" });
  } catch (e1) {
    const msg1 = (e1 as Error).message ?? "";

    // ── Strategy 2: DER-based (runs for any Strategy 1 failure) ───────────
    try {
      const b64 = pem.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
      const der = Buffer.from(b64, "base64");

      // 2a: rewrap PKCS#8 PSS → PKCS#8 plain rsaEncryption
      try {
        const pkcs1Der = extractPkcs1Der(der);
        const newDer   = rewrapAsPkcs8(pkcs1Der);
        return crypto.createPrivateKey({ key: newDer, format: "der", type: "pkcs8" });
      } catch {}

      // 2b: treat the raw DER as PKCS#1 directly
      //     (covers bare-base64 PKCS#1 keys that normalisePem wrapped in PKCS#8 headers)
      try {
        return crypto.createPrivateKey({ key: der, format: "der", type: "pkcs1" });
      } catch {}

      // 2c: extract inner OCTET STRING content and load as PKCS#1
      const pkcs1Der = extractPkcs1Der(der);
      return crypto.createPrivateKey({ key: pkcs1Der, format: "der", type: "pkcs1" });

    } catch (e2) {
      console.warn("[kalshi-auth] DER strategies failed:", (e2 as Error).message);
    }

    // ── Strategy 3: PKCS#1 header swap ────────────────────────────────────
    try {
      const pkcs1 = pem
        .replace("-----BEGIN PRIVATE KEY-----",  "-----BEGIN RSA PRIVATE KEY-----")
        .replace("-----END PRIVATE KEY-----",    "-----END RSA PRIVATE KEY-----");
      return crypto.createPrivateKey({ key: pkcs1, format: "pem" });
    } catch (e3) {
      throw new Error(
        `kalshi-auth: all key-load strategies failed.\n` +
        `  Strategy 1 (PEM):       ${msg1}\n` +
        `  Strategy 3 (PKCS#1 hdr): ${(e3 as Error).message}`,
      );
    }
  }
}

// ── Signing ──────────────────────────────────────────────────────────────────

/**
 * Sign a Kalshi API request string: `<timestamp><METHOD><path>`
 * Returns the base64-encoded RSA-PSS/SHA-256 signature.
 */
export function signKalshi(privateKeyPem: string, ts: string, method: string, path: string): string {
  // Kalshi verifies over path WITHOUT query string (Sep 9 debug #20).
  const pathNoQuery = path.split("?")[0];
  const msg    = ts + method.toUpperCase() + pathNoQuery;
  const keyObj = loadPrivateKey(privateKeyPem);
  return crypto.sign("sha256", Buffer.from(msg), {
    key:        keyObj,
    padding:    crypto.constants.RSA_PKCS1_PSS_PADDING,
    saltLength: 32,
  }).toString("base64");
}

/**
 * Build authenticated headers from an explicit key pair.
 *
 * Keeping timestamp generation here ensures route-level REST requests and
 * env/DB-resolved callers all share the same UNIX-seconds contract.
 * Throws if signing fails so callers cannot silently send an unsigned request.
 */
export function buildKalshiAuthHeaders(
  keyId: string,
  privateKeyPem: string,
  method: string,
  path: string,
): Record<string, string> {
  // Kalshi expects the timestamp in UNIX SECONDS (10-digit integer), not milliseconds.
  // A milliseconds timestamp is always outside Kalshi's ±30 s window and causes HTTP 401.
  const ts = Math.floor(Date.now() / 1000).toString();
  return {
    "KALSHI-ACCESS-KEY":       keyId,
    "KALSHI-ACCESS-SIGNATURE": signKalshi(privateKeyPem, ts, method, path),
    "KALSHI-ACCESS-TIMESTAMP": ts,
    "Content-Type":            "application/json",
  };
}

// ── Auth-header factory ───────────────────────────────────────────────────────

/**
 * Build Kalshi authentication headers for a REST or WS request.
 * Returns an empty object if credentials are absent.
 * Throws if credentials are present but signing fails — callers must NOT
 * silently fall back to an unauthenticated request in that case.
 */
export function kalshiAuthHeaders(method: string, path: string): Record<string, string> {
  const keyId   = process.env.oracle    ?? "";
  const privKey = process.env.oraclekey ?? "";
  if (!keyId || !privKey) return {};

  const pem = normalisePem(privKey);

  // Reject PKCS#1 keys before attempting to sign — they cannot produce a valid
  // RSA-PSS signature and will fail with a cryptic OpenSSL error.  Throw here
  // so callers receive an explicit auth-configuration error rather than a
  // mysterious signing failure further down the stack. Uses detectKeyFormat()
  // (structural DER check), not a header-text check — a bare-base64 PKCS#1
  // key normalises to a "BEGIN PRIVATE KEY" header despite being PKCS#1.
  if (detectKeyFormat(privKey) !== "pkcs8") {
    throw new Error(
      "PKCS#1 key detected in env secret (oraclekey): this key uses the legacy " +
      "RSA PRIVATE KEY format and cannot be used for RSA-PSS signing. " +
      "Please regenerate a PKCS#8 key in Settings → API Key.",
    );
  }

  // Intentionally NOT caught — a signing failure must propagate so callers can
  // return an explicit auth-failure response instead of an unauthenticated request.
  return buildKalshiAuthHeaders(keyId, pem, method, path);
}

// ── DB-aware credential resolution (Task #163) ─────────────────────────────────
//
// The env-only `kalshiAuthHeaders()` above is what the live bot (trading-bot.ts)
// used exclusively until now. Problem: a user who rotates their key via
// Settings → API Key (or paste-key) writes the new keyId/privateKey to the
// `settings` DB row, which routes/kalshi.ts's getKalshiAuth() reads fresh on
// every request — so the SMOKE TEST picks up a rotation immediately, but the
// live bot's order placement, auth probe, and balance refresh kept signing
// with the (possibly stale/absent) env secret until the process restarted.
//
// Fix: resolve credentials with the same priority order routes/kalshi.ts uses
// (env secret first, then DB) on every call — no caching, so a rotation is
// picked up on the very next tick, matching the smoke-test's behavior.
async function resolveKalshiCredentials(): Promise<{ keyId: string; privateKey: string } | null> {
  const envKeyId   = process.env.oracle;
  const envPrivKey = process.env.oraclekey;
  if (envKeyId && envPrivKey) {
    return { keyId: envKeyId, privateKey: normalisePem(envPrivKey) };
  }
  try {
    const rows = await db.select().from(settingsTable).limit(1);
    const settings = rows[0];
    if (settings?.kalshiKeyId && settings?.kalshiPrivateKey) {
      return { keyId: settings.kalshiKeyId, privateKey: normalisePem(settings.kalshiPrivateKey) };
    }
  } catch (e) {
    console.warn("[kalshi-auth] DB credential lookup failed, falling back to no-auth:", (e as Error).message);
  }
  return null;
}

/**
 * DB-aware counterpart to `kalshiAuthHeaders()` — used by the live bot so a
 * key rotated via Settings/paste-key (DB-only, no env secret) takes effect on
 * the very next call, without a server restart. Returns {} if no credentials
 * are configured anywhere, or if signing fails (PKCS#1 key etc.) — callers
 * detect this via the missing "KALSHI-ACCESS-KEY" header, same contract as
 * the sync version.
 */
export async function kalshiAuthHeadersAsync(method: string, path: string): Promise<Record<string, string>> {
  const creds = await resolveKalshiCredentials();
  if (!creds) return {};

  if (detectKeyFormat(creds.privateKey) !== "pkcs8") {
    // Same PKCS#1 guard as the sync version (structural DER check via
    // detectKeyFormat(), not a header-text check), but non-throwing here —
    // the live bot's callers already treat "{}" as "auth failed, block live
    // orders" uniformly across every call site, so surfacing this as a
    // thrown error would require touching all 15+ call sites for no
    // behavioral gain.
    console.warn("[kalshi-auth] PKCS#1 key detected — cannot sign RSA-PSS requests. Regenerate a PKCS#8 key in Settings → API Key.");
    return {};
  }

  try {
    return buildKalshiAuthHeaders(creds.keyId, creds.privateKey, method, path);
  } catch (e) {
    console.warn("[kalshi-auth] Signing failed:", (e as Error).message);
    return {};
  }
}
