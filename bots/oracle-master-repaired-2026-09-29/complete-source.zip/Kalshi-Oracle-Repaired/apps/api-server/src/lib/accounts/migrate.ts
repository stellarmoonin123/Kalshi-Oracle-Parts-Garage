/**
 * accounts/migrate.ts — idempotent, non-destructive schema + data migration
 * for multi-user accounts. Safe to run on every boot and from the CLI.
 *
 *  1. Create oracle_users / oracle_sessions / oracle_account_migrations
 *     (CREATE ... IF NOT EXISTS; mirrors packages/db/src/schema/oracle-users.ts).
 *  2. Ensure chat tables exist, then BACK UP legacy chat storage once into
 *     <backup schema>.chat_conversations_pre_accounts_backup /
 *     <backup schema>.chat_messages_pre_accounts_backup (plain table copies,
 *     never dropped or rewritten). The backup lives in its own Postgres schema
 *     (default `oracle_accounts_backup`, env ORACLE_ACCOUNTS_BACKUP_SCHEMA) so
 *     `drizzle-kit push` — which manages only `public` and drops unknown
 *     tables there — can never remove it. Taken once, keyed on the
 *     oracle_account_migrations record.
 *  3. ALTER chat_conversations ADD COLUMN IF NOT EXISTS owner_user_id.
 *  4. When an ADMIN exists, assign every conversation with no owner to the
 *     bootstrap (earliest-created) ADMIN. There is no reliable per-person
 *     ownership in the legacy single-user desk, so ADMIN is the only safe owner.
 *
 * Nothing here deletes or updates trades, reports, bot history, learning data,
 * settings or messages. Runs under a transaction-scoped advisory lock so two
 * processes booting at once cannot race the DDL.
 */
import { accountsPool, withTransaction, type QueryClientLike } from "./db.js";

const ADVISORY_LOCK_KEY = 0x0a11_0c0d; // arbitrary constant for this migration

export const ACCOUNTS_DDL = `
CREATE TABLE IF NOT EXISTS oracle_users (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username             text NOT NULL,
  email                text NOT NULL,
  display_name         text NOT NULL,
  password_hash        text NOT NULL,
  role                 text NOT NULL DEFAULT 'USER',
  status               text NOT NULL DEFAULT 'ACTIVE',
  must_change_password boolean NOT NULL DEFAULT true,
  created_at           timestamp with time zone NOT NULL DEFAULT now(),
  updated_at           timestamp with time zone NOT NULL DEFAULT now(),
  last_login_at        timestamp with time zone,
  CONSTRAINT oracle_users_username_unique UNIQUE (username),
  CONSTRAINT oracle_users_email_unique UNIQUE (email),
  CONSTRAINT oracle_users_role_check CHECK (role IN ('ADMIN', 'USER')),
  CONSTRAINT oracle_users_status_check CHECK (status IN ('ACTIVE', 'DISABLED'))
);

CREATE TABLE IF NOT EXISTS oracle_sessions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL,
  token_hash   text NOT NULL,
  created_at   timestamp with time zone NOT NULL DEFAULT now(),
  last_seen_at timestamp with time zone NOT NULL DEFAULT now(),
  expires_at   timestamp with time zone NOT NULL,
  CONSTRAINT oracle_sessions_token_hash_unique UNIQUE (token_hash),
  CONSTRAINT oracle_sessions_user_id_oracle_users_id_fk
    FOREIGN KEY (user_id) REFERENCES oracle_users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS oracle_sessions_user_idx ON oracle_sessions (user_id);

CREATE TABLE IF NOT EXISTS oracle_account_migrations (
  name       text PRIMARY KEY,
  applied_at timestamp with time zone NOT NULL DEFAULT now(),
  details    jsonb
);
`;

/** Same DDL chat-history.ts has always used (kept here so ordering is deterministic). */
export const CHAT_DDL = `
CREATE TABLE IF NOT EXISTS chat_conversations (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title      TEXT NOT NULL DEFAULT 'New conversation',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS chat_messages (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
  role            TEXT NOT NULL,
  content         TEXT NOT NULL,
  attachments     JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_chat_messages_conv ON chat_messages(conversation_id, created_at);
`;

export const BACKUP_MIGRATION = "2026-09-26-backup-legacy-chat";
export const OWNER_COLUMN_MIGRATION = "2026-09-26-chat-owner-column";
export const LEGACY_OWNER_MIGRATION = "2026-09-26-legacy-chat-owner";

/** Postgres schema holding the one-time legacy chat backup (outside drizzle's `public`). */
export function backupSchemaName(): string {
  const raw = (process.env.ORACLE_ACCOUNTS_BACKUP_SCHEMA ?? "").trim().toLowerCase();
  const name = raw || "oracle_accounts_backup";
  if (!/^[a-z_][a-z0-9_]{0,62}$/.test(name)) throw new Error("ORACLE_ACCOUNTS_BACKUP_SCHEMA must be a plain lowercase identifier");
  return name;
}

async function migrationRecorded(c: QueryClientLike, name: string): Promise<boolean> {
  const { rows } = await c.query<{ ok: boolean }>("SELECT EXISTS (SELECT 1 FROM oracle_account_migrations WHERE name = $1) AS ok", [name]);
  return rows[0]?.ok === true;
}

async function recordMigration(c: QueryClientLike, name: string, details: unknown): Promise<void> {
  await c.query(
    "INSERT INTO oracle_account_migrations (name, details) VALUES ($1, $2) ON CONFLICT (name) DO NOTHING",
    [name, JSON.stringify(details)],
  );
}

export interface MigrationReport {
  backupCreated: boolean;
  backedUpConversations: number | null;
  backedUpMessages: number | null;
  legacyAssigned: number;
  legacyOwnerId: string | null;
  unownedRemaining: number;
}

/** Steps 1–3: schema + one-time backup. Idempotent. */
export async function ensureAccountsSchema(): Promise<Pick<MigrationReport, "backupCreated" | "backedUpConversations" | "backedUpMessages">> {
  return withTransaction(async (c) => {
    await c.query("SELECT pg_advisory_xact_lock($1)", [ADVISORY_LOCK_KEY]);
    await c.query(ACCOUNTS_DDL);
    await c.query(CHAT_DDL);

    let backupCreated = false;
    let backedUpConversations: number | null = null;
    let backedUpMessages: number | null = null;
    if (!(await migrationRecorded(c, BACKUP_MIGRATION))) {
      const bs = backupSchemaName();
      await c.query(`CREATE SCHEMA IF NOT EXISTS ${bs}`);
      // Never overwrite an existing copy: suffix with a timestamp if present.
      const { rows: ex } = await c.query<{ ok: boolean }>("SELECT to_regclass($1) IS NOT NULL AS ok", [`${bs}.chat_conversations_pre_accounts_backup`]);
      const suffix = ex[0]?.ok ? `_${Date.now()}` : "";
      const convT = `${bs}.chat_conversations_pre_accounts_backup${suffix}`;
      const msgT = `${bs}.chat_messages_pre_accounts_backup${suffix}`;
      await c.query(`CREATE TABLE ${convT} AS TABLE chat_conversations`);
      await c.query(`CREATE TABLE ${msgT} AS TABLE chat_messages`);
      const a = await c.query<{ n: number }>(`SELECT COUNT(*)::int AS n FROM ${convT}`);
      const b = await c.query<{ n: number }>(`SELECT COUNT(*)::int AS n FROM ${msgT}`);
      backedUpConversations = a.rows[0]?.n ?? 0;
      backedUpMessages = b.rows[0]?.n ?? 0;
      backupCreated = true;
      await recordMigration(c, BACKUP_MIGRATION, { conversationsTable: convT, messagesTable: msgT, conversations: backedUpConversations, messages: backedUpMessages });
    }

    await c.query("ALTER TABLE chat_conversations ADD COLUMN IF NOT EXISTS owner_user_id uuid");
    await c.query("CREATE INDEX IF NOT EXISTS idx_chat_conversations_owner ON chat_conversations (owner_user_id, updated_at)");
    await recordMigration(c, OWNER_COLUMN_MIGRATION, { column: "chat_conversations.owner_user_id" });
    return { backupCreated, backedUpConversations, backedUpMessages };
  });
}

/** Step 4: unowned (legacy) conversations → bootstrap ADMIN. No-op until an ADMIN exists. */
export async function assignLegacyConversations(): Promise<Pick<MigrationReport, "legacyAssigned" | "legacyOwnerId" | "unownedRemaining">> {
  return withTransaction(async (c) => {
    await c.query("SELECT pg_advisory_xact_lock($1)", [ADVISORY_LOCK_KEY]);
    const admin = await c.query<{ id: string }>(
      "SELECT id FROM oracle_users WHERE role = 'ADMIN' ORDER BY created_at ASC, id ASC LIMIT 1",
    );
    const ownerId = admin.rows[0]?.id ?? null;
    let assigned = 0;
    if (ownerId) {
      const upd = await c.query("UPDATE chat_conversations SET owner_user_id = $1 WHERE owner_user_id IS NULL", [ownerId]);
      assigned = upd.rowCount ?? 0;
      await recordMigration(c, LEGACY_OWNER_MIGRATION, { ownerUserId: ownerId, assignedOnFirstRun: assigned });
    }
    const rem = await c.query<{ n: number }>("SELECT COUNT(*)::int AS n FROM chat_conversations WHERE owner_user_id IS NULL");
    return { legacyAssigned: assigned, legacyOwnerId: ownerId, unownedRemaining: rem.rows[0]?.n ?? 0 };
  });
}

export async function runAccountsMigration(): Promise<MigrationReport> {
  const a = await ensureAccountsSchema();
  const b = await assignLegacyConversations();
  return { ...a, ...b };
}

let readyPromise: Promise<void> | null = null;

/** Memoised boot-time schema ensure used by routes (never throws to callers twice). */
export function accountsReady(): Promise<void> {
  if (!readyPromise) {
    readyPromise = ensureAccountsSchema().then(() => undefined, (err) => {
      readyPromise = null; // allow retry on next request
      throw err;
    });
  }
  return readyPromise;
}

/** Test hook. */
export function resetAccountsReady(): void { readyPromise = null; }

export { accountsPool };
