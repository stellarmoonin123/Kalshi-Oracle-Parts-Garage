/**
 * desk-library/panic-fade.ts — catalog row only (OBSERVE).
 *
 * LIVE_APPLY false. Not wired into evaluateDeskLibrary take-chain
 * (director stays skip → persist-cheap / metered-lag / trend / scalp /
 * cheap-early-exit). Strategy evaluator lives in ../panic-fade.ts
 * (PANIC_FADE dual-gate, ENABLE default false). Not 2¢ turnover.
 */
export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;
