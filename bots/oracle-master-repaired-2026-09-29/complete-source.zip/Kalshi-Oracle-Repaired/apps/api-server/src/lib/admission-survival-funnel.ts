/**
 * admission-survival-funnel.ts — GO: INSTITUTIONAL PROMOTION + ADMISSION
 * SURVIVAL ANALYSIS, Part II, 2026-08-25.
 *
 * READ-ONLY. This file queries existing tables only — it never adds a new
 * counter to trading-bot.ts's tick/entry loop, never changes a gate,
 * threshold, quarantine, or strategy-enable value, and is never imported by
 * any live decision path. "Read-only" in the spec means exactly this: no
 * live-pipeline code changes, reporting only.
 *
 * ── Why the funnel is reconstructed, not directly counted ──────────────
 * No existing table records "N candidates entered stage K" for any stage.
 * `bot_trade_skips` and `decision_traces` record DEATHS (which single gate
 * rejected a candidate), not stage-entry cohort sizes — and because the
 * live pipeline's gates are sequential and mutually exclusive (a candidate
 * dies at exactly the first gate that rejects it), a stage's "entered"
 * count can be reconstructed bottom-up:
 *
 *   entered(stage_k) = attemptedCount + sum(deaths(stage_j) for j >= k)
 *
 * starting from `attemptedCount` (S7, the one directly-countable cohort:
 * bot_trades rows, which are written before every live placeOrder() POST).
 * This is a standard right-censored/competing-risks reconstruction, valid
 * as long as every death is attributed to exactly one stage and none are
 * double-counted — which the pipeline's fail-fast/return-early structure
 * guarantees for `decision_traces`, but NOT strictly for `bot_trade_skips`,
 * which throttles to 1 write/sec per (ticker, strategyId, side,
 * rejectionCode). Under a hot skip loop, the true death count for a stage
 * can exceed what's logged — this UNDERCOUNTS deaths, which makes the
 * reconstructed survival rates for stages upstream of a heavily-throttled
 * code look OPTIMISTIC (better than reality). This caveat is surfaced in
 * every report via `throttlingCaveat`, never hidden.
 *
 * S0 (ticks observed) and S1 (>=1 strategy candidate produced) have NO
 * persisted denominator at all — market_observations gives an honest upper
 * bound for "ticks in the window" but is not a candidate count, so it is
 * reported separately as context, never spliced into the S2-S8 survival
 * chain as if it were S0/S1's real entered count.
 */

import { db, botTradeSkips, decisionTraces, botTrades, marketObservations } from "@workspace/db";
import { and, gte, sql } from "drizzle-orm";
import { getSessionBias } from "./market-intelligence.js";

const WINDOW_MS = 72 * 60 * 60_000;

// ── Stage taxonomy (raw code -> funnel stage) ───────────────────────────────
// Grep-audited against trading-bot.ts's logSkippedDecision/skip() call sites
// (see .agents/memory entry-pipeline-funnel exploration, 2026-08-24/25).
// Anything not listed here is reported under UNMAPPED rather than silently
// merged into a stage — a new call site added later must show up there
// until this table is updated, not get miscounted.

export type FunnelStage = "S2_REGIME_SESSION_PACK" | "S3_CONSENSUS_CONF_VELOCITY" | "S4_ENTRY_BAND_ASK_QUALITY" | "S5_PATH_GATE_EV" | "S6_SIZING";

const STAGE_MAP: Record<string, FunnelStage> = {
  // S2 — regime / session / pack allow
  STRATEGY_MANUAL_DISABLE: "S2_REGIME_SESSION_PACK",
  STRATEGY_REGIME_BLOCK: "S2_REGIME_SESSION_PACK",
  SESSION_FAMILY_SUPPRESSED: "S2_REGIME_SESSION_PACK",
  HARD_ENTRY_FILTER: "S2_REGIME_SESSION_PACK",
  // S3 — consensus / confidence / velocity
  CONFIDENCE_FLOOR: "S3_CONSENSUS_CONF_VELOCITY",
  PROTECT_MODE: "S3_CONSENSUS_CONF_VELOCITY",
  MTF_FILTER: "S3_CONSENSUS_CONF_VELOCITY",
  PRETRADE_SIM: "S3_CONSENSUS_CONF_VELOCITY",
  // S4 — entry price band / ask quality
  SPREAD_GATE: "S4_ENTRY_BAND_ASK_QUALITY",
  ENTRY_PRICE_BAND: "S4_ENTRY_BAND_ASK_QUALITY",
  PRICE_BAND_SKIP: "S4_ENTRY_BAND_ASK_QUALITY",
  HARVEST_PRICE_BAND: "S4_ENTRY_BAND_ASK_QUALITY",
  OVERPAY_GATE: "S4_ENTRY_BAND_ASK_QUALITY",
  // S5 — PATH_GATE + fee/slippage EV
  PATH_GATE: "S5_PATH_GATE_EV",
  EV_PRE_CHECK: "S5_PATH_GATE_EV",
  EV_FLOOR: "S5_PATH_GATE_EV",
  REGIME_EV_FILTER: "S5_PATH_GATE_EV",
  OTM_EV_NO_EDGE: "S5_PATH_GATE_EV",
  OTM_EV_FLOOR: "S5_PATH_GATE_EV",
  // S6 — sizing collapses to zero
  SIZING_ZERO: "S6_SIZING",
  RISK_PROFILE: "S6_SIZING",
  DAILY_TARGET_SIZE_ZERO: "S6_SIZING",
  DRAWDOWN_GUARD: "S6_SIZING",
};

/** Pre-condition / global-halt codes are NOT part of the sequential S2-S6 chain (they can fire independent of pipeline position) — reported separately for context, never folded into stage survival math. */
const GLOBAL_HALT_CODES = new Set([
  "DAILY_LOSS_HALT", "DAILY_TARGET_LATE_BLOCK", "BALANCE_STALE",
  "QUOTE_STALE_POST_SIM", "QUOTE_MOVED_POST_SIM", "STRATEGY_PAPER_ONLY",
]);

const STAGE_ORDER: FunnelStage[] = ["S2_REGIME_SESSION_PACK", "S3_CONSENSUS_CONF_VELOCITY", "S4_ENTRY_BAND_ASK_QUALITY", "S5_PATH_GATE_EV", "S6_SIZING"];
const STAGE_LABELS: Record<FunnelStage, string> = {
  S2_REGIME_SESSION_PACK: "S2 regime/session/pack allow",
  S3_CONSENSUS_CONF_VELOCITY: "S3 consensus/confidence/velocity",
  S4_ENTRY_BAND_ASK_QUALITY: "S4 entry price band/ask quality",
  S5_PATH_GATE_EV: "S5 PATH_GATE + fee/slippage EV",
  S6_SIZING: "S6 sizing >= 1 contract",
};

function classify(code: string): FunnelStage | "GLOBAL_HALT" | "UNMAPPED" {
  if (GLOBAL_HALT_CODES.has(code)) return "GLOBAL_HALT";
  return STAGE_MAP[code] ?? "UNMAPPED";
}

// ── Report shape ─────────────────────────────────────────────────────────

export interface StageRow {
  stage: FunnelStage;
  label: string;
  enteredCount: number;
  deathCount: number;
  survivedCount: number;
  survivalRatePct: number;
  topDeathReasons: Array<{ rawCode: string; count: number }>;
}

export interface StratumRow {
  key: string;
  deathCount: number;
  shareOfAllDeathsPct: number;
}

export interface RankedHypothesis {
  mechanism: string;
  evidence: string;
  probe: string;
  blastRadius: string;
}

export interface AdmissionSurvivalFunnelReport {
  windowHours: 72;
  windowStart: string;
  windowEnd: string;
  observedTicksContext: { marketObservationRows: number; note: string };
  attemptedCount: number;
  filledCount: number;
  unfilledOrCancelledCount: number;
  stages: StageRow[];
  globalHaltDeaths: Array<{ rawCode: string; count: number }>;
  unmappedDeaths: Array<{ rawCode: string; count: number }>;
  stage5Decomposition: {
    note: string;
    byRawCode: StratumRow[];
    nearFloorVsDeeplyNegative: { nearFloor: number; deeplyNegative: number; note: string };
  };
  stage6Decomposition: {
    note: string;
    byRawCode: StratumRow[];
  };
  stratification: {
    bySession: StratumRow[];
    byStrategyId: StratumRow[];
    byTimeLeftBucket: StratumRow[];
  };
  rankedHypotheses: RankedHypothesis[];
  forbiddenFixes: string[];
  throttlingCaveat: string;
}

// ── Query helpers ────────────────────────────────────────────────────────

function tallyByKey<T>(rows: T[], keyFn: (r: T) => string): Map<string, number> {
  const m = new Map<string, number>();
  for (const r of rows) {
    const k = keyFn(r);
    m.set(k, (m.get(k) ?? 0) + 1);
  }
  return m;
}

function toStratumRows(counts: Map<string, number>, total: number, topN = 10): StratumRow[] {
  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, topN)
    .map(([key, deathCount]) => ({ key, deathCount, shareOfAllDeathsPct: total > 0 ? (deathCount / total) * 100 : 0 }));
}

function sessionLabelFor(ts: Date): string {
  return getSessionBias(ts.getUTCHours()).label;
}

function timeLeftBucketFor(secsRemaining: number | null): string {
  if (secsRemaining == null) return "unknown";
  if (secsRemaining > 480) return "12-8m";
  if (secsRemaining > 180) return "8-3m";
  return "<3m";
}

/**
 * Runs the full read-only 72h admission survival analysis. Every number in
 * this report is derived from a plain SELECT against existing tables — this
 * function contains zero writes.
 */
export async function getAdmissionSurvivalFunnelReport(): Promise<AdmissionSurvivalFunnelReport> {
  const windowStart = new Date(Date.now() - WINDOW_MS);
  const windowEnd = new Date();

  const [skipsRaw, tracesRaw, tradesRaw, obsCountRow] = await Promise.all([
    db.select().from(botTradeSkips).where(gte(botTradeSkips.ts, windowStart)),
    db.select().from(decisionTraces).where(gte(decisionTraces.ts, windowStart)),
    db.select().from(botTrades).where(gte(botTrades.createdAt, windowStart)),
    db.select({ count: sql<number>`count(*)::int` }).from(marketObservations).where(gte(marketObservations.snapshotTs, windowStart)),
  ]);

  // Exclude synthetic rows written by the test suite (every test file that
  // exercises a DB-writing function uses a ticker containing "-TEST", e.g.
  // "KXBTC15M-TEST", "KXBTCD-TEST", "KXBTC-SIM-TEST" — grep-audited across
  // src/**/*.test.ts). Those tests write to the SAME live tables this report
  // reads (no separate test DB/schema exists in this project — see
  // .agents/memory/test-config-file-pollution.md for the analogous
  // JSON-config version of this problem), so without this filter a test run
  // during the report's 72h window silently inflates death counts with
  // fake rows. This is a read-side filter only — it does not touch how the
  // tests themselves write.
  const isTestRow = (ticker: string) => ticker.includes("-TEST");
  const skips = skipsRaw.filter(s => !isTestRow(s.ticker));
  const traces = tracesRaw.filter(t => !isTestRow(t.ticker));
  const trades = tradesRaw.filter(t => !isTestRow(t.ticker));

  const attemptedCount = trades.length;
  const filledCount = trades.filter(t => (t.contractsFilled ?? 0) > 0 || t.outcome === "win" || t.outcome === "loss").length;
  const unfilledOrCancelledCount = trades.filter(t => t.outcome === "cancelled" || (t.contractsFilled != null && t.contractsFilled === 0)).length;

  // Classify every skip event once.
  const classified = skips.map(s => ({ ...s, stage: classify(s.rejectionCode) }));
  const globalHaltRows = classified.filter(s => s.stage === "GLOBAL_HALT");
  const unmappedRows = classified.filter(s => s.stage === "UNMAPPED");
  const stageDeaths = new Map<FunnelStage, typeof classified>();
  for (const stage of STAGE_ORDER) stageDeaths.set(stage, classified.filter(s => s.stage === stage));

  // ── Stage5/Stage6 (EV_FAIL/SIZE_ZERO) — sourced from decision_traces, which
  // is UNTHROTTLED/unconditional for these two closed codes (unlike
  // bot_trade_skips, which throttles to 1 write/sec per ticker/strategy/
  // side/code and can silently undercount a sustained hot-skip stretch).
  // Every STAGE_MAP entry feeding S5 (PATH_GATE/EV_PRE_CHECK/EV_FLOOR/
  // REGIME_EV_FILTER/OTM_EV_*) closes to "EV_FAIL", and every S6 entry
  // (SIZING_ZERO/RISK_PROFILE/DAILY_TARGET_SIZE_ZERO/DRAWDOWN_GUARD) closes
  // to "SIZE_ZERO" (see mapToClosedCode's DIRECT_CLOSED_CODE_MAP), so this is
  // a like-for-like swap of the death SOURCE, not a redefinition of the stage.
  const ev5Traces = traces.filter(t => t.code === "EV_FAIL");
  const ev5ByRaw = tallyByKey(ev5Traces, t => t.rawCode ?? "unknown");
  const nearFloor = ev5Traces.filter(t => t.evCents != null && t.evCents >= -2 && t.evCents < 3).length; // within 2c of the live 3c EV floor mirror — "friction cost it the trade" territory
  const deeplyNegative = ev5Traces.filter(t => t.evCents != null && t.evCents < -2).length;

  const size6Traces = traces.filter(t => t.code === "SIZE_ZERO");
  const size6ByRaw = tallyByKey(size6Traces, t => t.rawCode ?? "unknown");

  // Profit Doctrine Phase 3 (2026-08-24): the funnel's S5 death COUNT must be
  // distinct-contract-sourced from decision_traces, not a raw bot_trade_skips
  // event count — a single contract can rack up many same-reason skip
  // ticks/rows across its lifetime, and counting every row would inflate the
  // death count relative to attemptedCount (which is one row per contract
  // that actually reached an order attempt). "Distinct contract" = distinct
  // ticker within the window.
  const ev5DistinctTickers = new Set(ev5Traces.map(t => t.ticker)).size;
  const size6DistinctTickers = new Set(size6Traces.map(t => t.ticker)).size;
  const decisionTraceDeathCount: Partial<Record<FunnelStage, number>> = {
    S5_PATH_GATE_EV: ev5DistinctTickers,
    S6_SIZING: size6DistinctTickers,
  };
  const decisionTraceTopReasons: Partial<Record<FunnelStage, Array<{ rawCode: string; count: number }>>> = {
    S5_PATH_GATE_EV: Array.from(ev5ByRaw.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([rawCode, count]) => ({ rawCode, count })),
    S6_SIZING: Array.from(size6ByRaw.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([rawCode, count]) => ({ rawCode, count })),
  };

  // Bottom-up reconstruction: entered(k) = attempted + sum(deaths(j) for j>=k).
  let runningEntered = attemptedCount;
  const stagesReversed: StageRow[] = [];
  for (let i = STAGE_ORDER.length - 1; i >= 0; i--) {
    const stage = STAGE_ORDER[i];
    const deaths = stageDeaths.get(stage)!;
    const deathCount = decisionTraceDeathCount[stage] ?? deaths.length;
    const entered = runningEntered + deathCount;
    const survived = runningEntered; // whatever remains after this stage's deaths is exactly what fed the next stage down
    const codeCounts = tallyByKey(deaths, d => d.rejectionCode);
    const topDeathReasons = decisionTraceTopReasons[stage]
      ?? Array.from(codeCounts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([rawCode, count]) => ({ rawCode, count }));
    stagesReversed.push({
      stage, label: STAGE_LABELS[stage],
      enteredCount: entered, deathCount, survivedCount: survived,
      survivalRatePct: entered > 0 ? (survived / entered) * 100 : 0,
      topDeathReasons,
    });
    runningEntered = entered;
  }
  const stages = stagesReversed.reverse();

  // ── Stratification (over the funnel-mapped skip events only — global-halt
  // and unmapped rows are pre-condition/taxonomy-gap noise for this cut).
  const funnelDeaths = classified.filter(s => s.stage !== "GLOBAL_HALT" && s.stage !== "UNMAPPED");
  const bySession = tallyByKey(funnelDeaths, d => sessionLabelFor(d.ts));
  const byStrategyId = tallyByKey(funnelDeaths, d => d.strategyId ?? "unknown");
  const byTimeLeft = tallyByKey(funnelDeaths, d => timeLeftBucketFor(d.secsRemaining));

  // ── Ranked hypotheses (data-driven, mechanism/evidence/probe/blast-radius) ─
  const rankedHypotheses: RankedHypothesis[] = [];
  const worstStage = [...stages].sort((a, b) => b.deathCount - a.deathCount)[0];
  if (worstStage && worstStage.deathCount > 0) {
    rankedHypotheses.push({
      mechanism: `${worstStage.label} accounts for the largest single death count in the 72h window (${worstStage.deathCount} of ${stages.reduce((s, x) => s + x.deathCount, 0)} funnel deaths), top raw code: ${worstStage.topDeathReasons[0]?.rawCode ?? "n/a"}.`,
      evidence: `Reconstructed entered=${worstStage.enteredCount}, survived=${worstStage.survivedCount}, survival=${worstStage.survivalRatePct.toFixed(1)}% (bottom-up reconstruction from bot_trade_skips; see throttlingCaveat).`,
      probe: `Pull the last 20 raw ${worstStage.topDeathReasons[0]?.rawCode ?? "top-code"} rows from bot_trade_skips and inspect their reasons text for a common, fixable sub-cause before touching any threshold.`,
      blastRadius: `Any change to a gate inside ${worstStage.label} touches live entry admission for every strategy that passes through it — treat as a NON-NEGOTIABLE-protected surface requiring explicit human sign-off, not an autonomous fix.`,
    });
  }
  const sessionEntries = Array.from(bySession.entries()).sort((a, b) => b[1] - a[1]);
  if (sessionEntries.length > 0 && funnelDeaths.length > 0) {
    const [topSession, topCount] = sessionEntries[0];
    const share = (topCount / funnelDeaths.length) * 100;
    if (share > 40) {
      rankedHypotheses.push({
        mechanism: `Funnel deaths concentrate disproportionately in the '${topSession}' session (${share.toFixed(1)}% of all mapped deaths) — could be a genuine session-specific edge gap, OR a seasonality artifact of that session simply having more raw tick volume.`,
        evidence: `${topCount} of ${funnelDeaths.length} mapped deaths tagged '${topSession}' by UTC-hour session bucket.`,
        probe: `Compare '${topSession}'-session death SHARE against '${topSession}'-session share of total market_observations volume over the same window before concluding this is a real effect and not just more ticks happening then.`,
        blastRadius: `Read-only until proven — .agents/memory/family-suppression-and-session-gating-findings-2026-08-12.md already found no significant session/weekday effect at 50k-scenario scale; do not re-introduce session gating without a comparably powered re-test.`,
      });
    }
  }
  if (ev5Traces.length > 0 && nearFloor / ev5Traces.length > 0.5) {
    rankedHypotheses.push({
      mechanism: `Over half of EV_FAIL (S5) deaths are "near-floor" (net EV within 2c of the live EV floor) rather than deeply negative — suggests fee/slippage friction is the marginal decider for a majority of these, not a fundamentally bad signal.`,
      evidence: `${nearFloor} of ${ev5Traces.length} decision_traces EV_FAIL rows have evCents in [-2, 3).`,
      probe: `For a sample of near-floor rows, compare the strategy's raw (pre-fee) signal edge against the live fee+slippage estimate at that ask price/secsRemaining to confirm friction (not signal quality) is the marginal cause.`,
      blastRadius: `Do NOT lower the EV floor to "fix" this — that is explicitly forbidden (see forbiddenFixes). Any legitimate fix here is fee-model or entry-timing research, reviewed before any live change.`,
    });
  }

  return {
    windowHours: 72,
    windowStart: windowStart.toISOString(),
    windowEnd: windowEnd.toISOString(),
    observedTicksContext: {
      marketObservationRows: obsCountRow[0]?.count ?? 0,
      note: "Upper-bound context only — market_observations is a per-tick snapshot of the active contract, NOT a candidate-generation (S1) count. No S0/S1 cohort denominator exists in this codebase today; the reconstructed funnel below starts at S2.",
    },
    attemptedCount, filledCount, unfilledOrCancelledCount,
    stages,
    globalHaltDeaths: Array.from(tallyByKey(globalHaltRows, r => r.rejectionCode).entries()).sort((a, b) => b[1] - a[1]).map(([rawCode, count]) => ({ rawCode, count })),
    unmappedDeaths: Array.from(tallyByKey(unmappedRows, r => r.rejectionCode).entries()).sort((a, b) => b[1] - a[1]).map(([rawCode, count]) => ({ rawCode, count })),
    stage5Decomposition: {
      note: "true-negative-EV vs. friction vs. seasonality-artifact per the spec's mandate. 'nearFloor' (evCents in [-2,3)) is a friction-territory proxy, not a certain classification — see rankedHypotheses for the follow-up probe before concluding either way. Seasonality is NOT separately quantified here (no gross-vs-net EV split exists in decision_traces); see stratification.bySession instead.",
      byRawCode: toStratumRows(ev5ByRaw, ev5Traces.length),
      nearFloorVsDeeplyNegative: { nearFloor, deeplyNegative, note: "Based on decision_traces.evCents (net, fee/slippage-inclusive) at decision time — the only EV figure persisted; a true gross-vs-net friction split is not available with current instrumentation." },
    },
    stage6Decomposition: {
      note: "Kelly-zero vs portfolio%-zero vs risk-profile-zero vs maxContracts vs balance, per the spec's mandate. maxContracts/balance-driven collapses are NOT separately distinguishable from Kelly-zero with current instrumentation (both fall under rawCode SIZING_ZERO) — reported honestly as a combined bucket rather than guessed apart.",
      byRawCode: toStratumRows(size6ByRaw, size6Traces.length),
    },
    stratification: {
      bySession: toStratumRows(bySession, funnelDeaths.length),
      byStrategyId: toStratumRows(byStrategyId, funnelDeaths.length),
      byTimeLeftBucket: toStratumRows(byTimeLeft, funnelDeaths.length),
    },
    rankedHypotheses,
    forbiddenFixes: [
      "Do not lower any EV floor (LIVE_EV_FLOOR_CENTS_MIRROR_V4, trading-bot.ts EV_FLOOR, OTM EV floors) to reduce S5 deaths.",
      "Do not loosen PATH_GATE, minConfidence, or minVelocity to reduce S3/S5 deaths.",
      "Do not widen or remove any per-strategy or universal entry price band to reduce S4 deaths.",
      "Do not add a Math.max(1) sizing rescue or relax RISK_PROFILE/DRAWDOWN_GUARD to reduce S6 deaths.",
      "Do not re-enable BRTI_PROBABILITY, MTF_ALIGNED, SAKATA, or any OTM_* strategy as a response to this report.",
      "Do not treat 'fewer deaths at stage X' as a success metric on its own — the objective is fee-net P&L / ruin-risk, not trade count (same non-negotiable as Part I).",
      "Do not add session/weekday gating based on the stratification above without a re-test at the scale of the existing 50k-scenario null result (see family-suppression-and-session-gating-findings-2026-08-12.md).",
    ],
    throttlingCaveat: "bot_trade_skips throttles to 1 write/sec per (ticker, strategyId, side, rejectionCode); under a sustained hot-skip condition the true death count for a stage can exceed what is counted here, which makes this report's survival rates for stages upstream of a heavily-throttled code optimistic (better than reality), never pessimistic. decision_traces (used for the Stage5/Stage6 raw-code decomposition) is NOT throttled for EV_FAIL/SIZE_ZERO and is the more trustworthy source for those two breakdowns specifically.",
  };
}
