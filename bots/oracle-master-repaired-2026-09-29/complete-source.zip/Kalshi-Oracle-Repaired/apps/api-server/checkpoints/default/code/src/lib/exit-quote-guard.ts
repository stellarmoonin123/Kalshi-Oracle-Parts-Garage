/**
 * exit-quote-guard.ts: SEV0 phantom post-close exits (full sweep S1, Sep 25).
 *
 * monitorOpenTrade priced exits off kalshiWS.getLatest() with no ticker check.
 * At close_time the WS adopts the NEXT contract (D10), so a still-open trade on
 * the dead contract could "exit" (PATH_RIDE_TP etc.) at the new market's bid.
 * On the older local tape this booked 7 losing trades as wins.
 *
 * Rule: a 15m trade may only be exit-evaluated/executed against a quote for its
 * own ticker, and never at/after its contract close. After close, the only
 * valid path is settlement (Kalshi result). Removes exits only; no EV/sizing.
 */
import { kxbtc15mCloseUtcIso } from "./kxbtc15m-ticker.js";

export type ExitQuoteVerdict =
  | { ok: true }
  | { ok: false; reason: "AFTER_CLOSE" | "TICKER_MISMATCH" | "NO_QUOTE_TICKER" };

/** Contract close (epoch ms) from the stored close time, else parsed from a KXBTC15M ticker. */
export function resolveTradeCloseMs(trade: { ticker: string; closeTimeMs?: number | null }): number | null {
  if (typeof trade.closeTimeMs === "number" && Number.isFinite(trade.closeTimeMs) && trade.closeTimeMs > 0) {
    return trade.closeTimeMs;
  }
  const iso = kxbtc15mCloseUtcIso(trade.ticker);
  if (!iso) return null;
  const ms = Date.parse(iso);
  return Number.isFinite(ms) ? ms : null;
}

export function exitQuoteGuard(opts: {
  tradeTicker: string;
  tradeCloseMs: number | null;
  quoteTicker: string | null | undefined;
  nowMs: number;
}): ExitQuoteVerdict {
  if (opts.tradeCloseMs != null && opts.nowMs >= opts.tradeCloseMs) return { ok: false, reason: "AFTER_CLOSE" };
  if (!opts.quoteTicker) return { ok: false, reason: "NO_QUOTE_TICKER" };
  if (opts.quoteTicker !== opts.tradeTicker) return { ok: false, reason: "TICKER_MISMATCH" };
  return { ok: true };
}

/**
 * S2 aggravator: an early (non-settlement) close stamped at/after the contract
 * closed cannot be a real exit (the market no longer trades). Tape rebuilds
 * must ignore it in favour of the settlement/official close.
 */
const BINARY_CLOSE_REASONS = new Set([
  "SETTLEMENT", "SETTLED_KALSHI", "ORPHAN_SETTLED_KALSHI", "STARTUP_RECOVERY",
  "STARTUP_RECOVERY_UNRESOLVED", "STARTUP_RECOVERY_NEVER_FILLED", "ORPHAN_OPEN_CLEARED_VOID",
]);
export function isPostCloseEarlyExit(row: { ticker?: string | null; exitReason?: string | null; ts?: number | null; settledAt?: number | null }): boolean {
  const reason = String(row.exitReason ?? "");
  if (!reason || BINARY_CLOSE_REASONS.has(reason)) return false;
  if (!row.ticker) return false;
  const closeMs = resolveTradeCloseMs({ ticker: row.ticker });
  if (closeMs == null) return false;
  const stamp = typeof row.settledAt === "number" && Number.isFinite(row.settledAt) ? row.settledAt
    : typeof row.ts === "number" && Number.isFinite(row.ts) ? row.ts : null;
  return stamp != null && stamp >= closeMs;
}
