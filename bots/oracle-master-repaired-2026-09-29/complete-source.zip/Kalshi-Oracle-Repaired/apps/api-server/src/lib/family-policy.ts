/**
 * family-policy.ts — P3: MARKETSTATE + FAMILY POLICY (ADAPTIVE TACTICS), Part B.
 *
 * Maps each P2-eligible strategy to exactly one tactical family, then
 * provides shared, MarketState-normalized gate helpers so strategies stop
 * comparing raw $/min or fixed $/% distances against constants tuned for one
 * volatility regime. Strategies call these helpers from within their own
 * evaluate() — this module does not run its own gate loop and does not
 * change strategy eligibility/selection (packs, regime allowlist, disabled
 * sets are all untouched, see strategy-library.ts / condition-adapter.ts).
 *
 * P3 locks (do not touch here): EV/PATH/RICH/9%/SEV1 floors, SEV1 /
 * VELOCITY_STALL_REVERSAL enablement, specialist pack membership, ARIA
 * system prompt/DecisionTrace/desk API/LiquidityPolicy, and never treat
 * confidence/signalQuality as a probability `p` for EV/Kelly.
 *
 * ── Family map (16 P2-eligible strategies) ──────────────────────────────────
 * Spec-named directly: BASIS_LAG_EDGE=lag; LATE_ENTRY_ANCHOR/FLOOR_DISTANCE/
 * EXHAUSTION_ANCHOR=anchor; VELOCITY_MOMENTUM=momentum; BREAKOUT_CAPTURE/
 * SQUEEZE_EXPANSION=breakout; CHANNEL_BOUNCE/MEAN_REVERSION_STRETCH/
 * TOP_REVERSAL/BOTTOM_REVERSAL=mean_reversion; CONFLUENCE_CASCADE=confluence.
 * Reasoned (not spec-given, documented in the P3 attestation):
 *   - LATE_MOMENTUM_CONTINUATION → momentum (its v1/v3 sign-agreement gate
 *     has the same shape as VELOCITY_MOMENTUM's speed=min(|v1|,|v3|) gate).
 *   - FAKEOUT_FADE → mean_reversion (counter-move/fade thesis, despite gating
 *     on probability mass rather than a $/min velocity magnitude).
 *   - BOLLINGER_BAND → mean_reversion (matches its own existing
 *     `family: 'mean-reversion'` tag in strategy-library.ts; band-extreme
 *     reversion dominates its minor squeeze-breakout sub-thesis).
 *   - SETTLEMENT_PREDICTION → confluence (has zero velocity/distance gates —
 *     only a confidence threshold — so no FamilyPolicy behavior actually
 *     applies to it; placed in the most general/no-op bucket purely for
 *     taxonomy completeness).
 */

import type { StrategyId } from './strategy-library.js';
import type { MarketState } from './market-state.js';
import { logger } from './logger.js';

export type Family = 'lag' | 'anchor' | 'momentum' | 'breakout' | 'mean_reversion' | 'confluence';

export const STRATEGY_FAMILY_POLICY: Partial<Record<StrategyId, Family>> = {
  BASIS_LAG_EDGE:             'lag',
  CHEAP_SIDE_15M:             'lag',
  LATE_ENTRY_ANCHOR:          'anchor',
  FLOOR_DISTANCE:             'anchor',
  EXHAUSTION_ANCHOR:          'anchor',
  VELOCITY_MOMENTUM:          'momentum',
  LATE_MOMENTUM_CONTINUATION: 'momentum',
  BREAKOUT_CAPTURE:           'breakout',
  SQUEEZE_EXPANSION:          'breakout',
  CHANNEL_BOUNCE:             'mean_reversion',
  MEAN_REVERSION_STRETCH:     'mean_reversion',
  TOP_REVERSAL:               'mean_reversion',
  BOTTOM_REVERSAL:            'mean_reversion',
  FAKEOUT_FADE:               'mean_reversion',
  BOLLINGER_BAND:             'mean_reversion',
  CONFLUENCE_CASCADE:         'confluence',
  SETTLEMENT_PREDICTION:      'confluence',
  CHEAP_EARLY_EXIT:           'mean_reversion',
  PANIC_FADE:                 'mean_reversion',
  STREAK_SAT_FADE:            'mean_reversion',
  HA_RIVER:                   'momentum',
  HA_FLIP:                    'momentum',
  TICKET_WAVE:                'mean_reversion',
  NO_CROSS:                   'anchor',
};

export function getFamilyPolicy(id: StrategyId): Family | undefined {
  return STRATEGY_FAMILY_POLICY[id];
}

// ── Starter constants (finalized values documented verbatim in the P3 attestation) ──
export const FAMILY_POLICY_CONSTANTS = {
  /** Opposing-velocity floor multiplier applied to velScale for the ANCHOR family. */
  K_OPP:            0.85,
  /** Absolute floor under k_opp*velScale — an anchor gate never gets looser than this even on a dead-quiet tape. */
  OPP_FLOOR:        35,
  /** Minimum |zVel| for MOMENTUM family entries. */
  ZMIN_MOMENTUM:    0.70,
  /** Minimum |zVel| for BREAKOUT family entries (stricter than momentum — breakouts need conviction, not just drift). */
  ZMIN_BREAKOUT:    0.85,
  /** Absolute floor-distance percentage under the range-normalized anchor distance check. */
  ABS_FLOOR_DIST_PCT: 0.06,
  /** Minimum distance-in-range-units for the ANCHOR family (d_R = |price-strike|/rangeScale). */
  D_ANCHOR:         0.9,
  /** Minimum distance-in-range-units for the MEAN_REVERSION family (stretch must be more pronounced than a bare anchor). */
  D_MR:             1.35,
} as const;

/**
 * ANCHOR family opposing-velocity gate. Replaces LATE_ENTRY_ANCHOR/
 * CHANNEL_BOUNCE-style fixed ±65/±55 $/min opposing-velocity checks with a
 * tape-speed-scaled floor: never below OPP_FLOOR even when velScale is tiny
 * (dead-quiet tape), scales up with k_opp*velScale on a fast tape so a real
 * $150/min move doesn't get treated as "just noise vs. a fixed 65 gate".
 */
export function opposeBar(velScale: number): number {
  return Math.max(FAMILY_POLICY_CONSTANTS.OPP_FLOOR, FAMILY_POLICY_CONSTANTS.K_OPP * velScale);
}

/** Distance from strike expressed in "range units" (rangeScale-normalized), always ≥ 0. */
export function distanceInRangeUnits(currentPrice: number, floorStrike: number, rangeScale: number): number {
  return Math.abs(currentPrice - floorStrike) / Math.max(rangeScale, 1e-6);
}

/** True when a signed velocity value opposes the anchor's implied direction beyond the tape-scaled floor. */
export function opposesAnchor(velocity: number, directionSign: 1 | -1, velScale: number): boolean {
  const bar = opposeBar(velScale);
  return Math.sign(velocity) === -directionSign && Math.abs(velocity) > bar;
}

/** ANCHOR family distance check: real distance from the strike, not just a fixed % of price. */
export function passesAnchorDistance(dR: number): boolean {
  return dR >= FAMILY_POLICY_CONSTANTS.D_ANCHOR;
}

/** MOMENTUM family: minimum tape-normalized velocity magnitude (zVel), replacing a fixed $/min "speed" gate. */
export function passesMomentumZVel(zVel: number): boolean {
  return Math.abs(zVel) >= FAMILY_POLICY_CONSTANTS.ZMIN_MOMENTUM;
}

/** BREAKOUT family: stricter tape-normalized velocity minimum than plain momentum. */
export function passesBreakoutZVel(zVel: number): boolean {
  return Math.abs(zVel) >= FAMILY_POLICY_CONSTANTS.ZMIN_BREAKOUT;
}

/** MEAN_REVERSION family: stretch/distance must exceed a stricter range-normalized bar than a bare anchor. */
export function passesMeanReversionDistance(dR: number): boolean {
  return dR >= FAMILY_POLICY_CONSTANTS.D_MR;
}

/**
 * MEAN_REVERSION family: the reversal thesis fades as continuation velocity
 * strengthens in the ORIGINAL (pre-reversal) direction — i.e. still-expanding
 * moves should not be faded yet. `zVel` is the tape-normalized velocity;
 * `continuingSign` is the sign of the pre-reversal move being faded.
 */
export function meanReversionStillExpanding(zVel: number, continuingSign: 1 | -1, zMinContinue = FAMILY_POLICY_CONSTANTS.ZMIN_MOMENTUM): boolean {
  return Math.sign(zVel) === continuingSign && Math.abs(zVel) >= zMinContinue;
}

/**
 * BASIS_LAG_EDGE / CHEAP_SIDE_15M (family: lag) are exempt from the operator's global
 * minVelocity hard-fail — its edge comes from exchange-vs-Kalshi projection
 * distance/streak/EV, not tape velocity, so gating it on raw $/min would
 * reject a perfectly good lag signal on a quiet tape. It remains fail-closed
 * on its OWN precondition instead: missing or stale basis data.
 */
export function isLagFamilyExemptFromMinVelocity(strategyId: StrategyId): boolean {
  return getFamilyPolicy(strategyId) === 'lag';
}

export interface GateLogEntry {
  strategyId:      StrategyId;
  family:          Family;
  gate:            string;       // e.g. "opposeBar", "zVel_momentum", "d_R_anchor"
  rawValue:        number;
  policyThreshold: number;
  velScale:        number;
  zVel:            number;
  rangeScale:      number;
  pass:            boolean;
}

/** Structured pass/fail logging for every FamilyPolicy-migrated velocity/distance gate (P3 Part C requirement). */
export function logFamilyGate(entry: GateLogEntry): void {
  const { strategyId, family, gate, rawValue, policyThreshold, velScale, zVel, rangeScale, pass } = entry;
  logger.info(
    `[family-policy] ${strategyId} family=${family} gate=${gate} raw=${rawValue.toFixed(2)} ` +
    `threshold=${policyThreshold.toFixed(2)} velScale=${velScale.toFixed(1)} zVel=${zVel.toFixed(2)} ` +
    `rangeScale=${rangeScale.toFixed(1)} → ${pass ? 'PASS' : 'FAIL'}`,
  );
}

/** Convenience: builds a MarketState-shaped log entry without repeating field destructuring at every call site. */
export function logFamilyGateFromState(
  strategyId: StrategyId, family: Family, gate: string,
  rawValue: number, policyThreshold: number, state: Pick<MarketState, 'velScale' | 'zVel' | 'rangeScale'>,
  pass: boolean,
): void {
  logFamilyGate({ strategyId, family, gate, rawValue, policyThreshold, velScale: state.velScale, zVel: state.zVel, rangeScale: state.rangeScale, pass });
}
