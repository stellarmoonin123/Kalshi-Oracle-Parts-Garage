/**
 * YES_40_55_PIN_SHADOW_V1 — OBSERVE-ONLY entry shadow for FROZEN_CC paper desk.
 *
 * classifyFrozenCcEntryShadow is pure (no fs, no bot imports, no mutation of
 * FrozenCcEntryDecision). Protected labels NEVER bypass a real hard gate.
 * Shadow sit never arms OR, never sits D, never gates PIN globally.
 *
 * Append-only jsonl helpers below are best-effort telemetry only.
 */

import * as fs from "node:fs";
import * as path from "node:path";
import { randomUUID } from "node:crypto";
import {
  FROZEN_CC_MIN_SECS,
  FROZEN_CC_MAX_SECS,
  FROZEN_CC_ASK_MIN,
  FROZEN_CC_ASK_MAX,
  FROZEN_CC_STILL_MID_MIN,
  FROZEN_CC_STILL_MID_MAX,
  inFrozenAskBand,
  inFrozenStillMid,
  inFrozenTimeWindow,
  runningGitSha,
  type FrozenCcEntryDecision,
  type FrozenSide,
} from "./frozen-cc.js";

export const YES_40_55_PIN_SHADOW_V1 = "YES_40_55_PIN_SHADOW_V1" as const;

export const FROZEN_CC_ENTRY_SHADOW_V1_FILENAME = "frozen-cc-entry-shadow-v1.jsonl";

/** EV floor (alignedTakeGate) — reuse, do not cut. */
export const SHADOW_V1_EV_FLOOR_CENTS = 3;
/** Kelly cap in config — reuse, do not cut. */
export const SHADOW_V1_KELLY_CAP = 0.60;

export const SHADOW_V1_YES_ASK_MIN = 40;
export const SHADOW_V1_YES_ASK_MAX = 55;
export const SHADOW_V1_CHEAP_NO_ASK_MIN = 28;
export const SHADOW_V1_CHEAP_NO_ASK_MAX = 40;
export const SHADOW_V1_CHEAP_YES_ASK_MIN = 31;
export const SHADOW_V1_CHEAP_YES_ASK_MAX = 35;

export type FrozenCcEntryShadowInput = {
  paperMode: boolean;
  frozenCcMode: boolean;
  market: string;
  quoteFresh: boolean;
  secsRemaining: number;
  side: FrozenSide;
  ask: number;
  feeNetEvCents: number;
  kellyFrac: number;
  positionAndPendingClear: boolean;
  w2Reason: string | null | undefined;
  regimeWouldBlock: boolean;
  /** Stratum echo only — never a gate. */
  brtiSign?: string | null;
  /**
   * Optional FrozenCcEntryDecision for observe-only tests.
   * classify MUST NOT mutate it (deep-freeze safe).
   */
  decision?: FrozenCcEntryDecision;
};

export type FrozenCcEntryShadowResult = {
  predicate: typeof YES_40_55_PIN_SHADOW_V1;
  baseEligible: boolean;
  shadowSit: boolean;
  protectedCheapNo: boolean;
  protectedCheapYes: boolean;
  reason: string;
  /** Stratum echo only. */
  brtiSign: string | null;
};

export type ShadowV1CloseRow = {
  predicate?: string;
  shadowSit?: boolean;
  protectedCheapNo?: boolean;
  protectedCheapYes?: boolean;
  pnlCents: number;
  outcome?: "win" | "loss";
};

export type ShadowV1BucketSummary = {
  n: number;
  wins: number;
  losses: number;
  pnlCents: number;
};

export type ShadowV1Summary = {
  n: number;
  wins: number;
  losses: number;
  pnlCents: number;
  winnersGivenUpCents: number;
  losersSavedCents: number;
  netImprovementCents: number;
  ci95: [number, number] | null;
  protectedCheapNo: ShadowV1BucketSummary;
  protectedCheapYes: ShadowV1BucketSummary;
};

function haDisagree(w2Reason: string | null | undefined): boolean {
  return w2Reason === "ha_disagree";
}

function pinReachable(w2Reason: string | null | undefined): boolean {
  return w2Reason === "pin_reachable";
}

function strikeDisagree(w2Reason: string | null | undefined): boolean {
  return w2Reason === "strike_disagree";
}

/**
 * Pure classifier. UNKNOWN / missing w2Reason → fail-OPEN (shadowSit=false).
 * Does not mutate input.decision.
 */
export function classifyFrozenCcEntryShadow(
  input: FrozenCcEntryShadowInput,
): FrozenCcEntryShadowResult {
  // Touch decision only via read of a frozen reference — never write.
  void input.decision;

  const ask = input.ask;
  const ha = haDisagree(input.w2Reason);
  const pin = pinReachable(input.w2Reason);
  const strike = strikeDisagree(input.w2Reason);
  const andSit = ha && input.regimeWouldBlock === true;

  const baseEligible =
    input.paperMode === true &&
    input.frozenCcMode === true &&
    input.market === "KXBTC15M" &&
    input.quoteFresh === true &&
    inFrozenTimeWindow(input.secsRemaining) &&
    inFrozenAskBand(ask) &&
    !inFrozenStillMid(ask) &&
    Number.isFinite(input.feeNetEvCents) &&
    input.feeNetEvCents >= SHADOW_V1_EV_FLOOR_CENTS &&
    Number.isFinite(input.kellyFrac) &&
    input.kellyFrac <= SHADOW_V1_KELLY_CAP &&
    input.positionAndPendingClear === true &&
    !andSit;

  const shadowSit =
    baseEligible &&
    input.side === "yes" &&
    ask >= SHADOW_V1_YES_ASK_MIN &&
    ask <= SHADOW_V1_YES_ASK_MAX &&
    pin === true &&
    ha !== true &&
    strike !== true;

  const protectedCheapNo =
    baseEligible &&
    input.side === "no" &&
    ask >= SHADOW_V1_CHEAP_NO_ASK_MIN &&
    ask <= SHADOW_V1_CHEAP_NO_ASK_MAX;

  const protectedCheapYes =
    baseEligible &&
    input.side === "yes" &&
    ask >= SHADOW_V1_CHEAP_YES_ASK_MIN &&
    ask <= SHADOW_V1_CHEAP_YES_ASK_MAX;

  let reason: string;
  if (!baseEligible) {
    if (andSit) reason = "AND_SIT_HA_REGIME";
    else if (!input.paperMode) reason = "not_paper";
    else if (!input.frozenCcMode) reason = "not_frozen";
    else if (input.market !== "KXBTC15M") reason = "market_not_kxbtc15m";
    else if (!input.quoteFresh) reason = "quote_stale";
    else if (!inFrozenTimeWindow(input.secsRemaining)) reason = "secs_out";
    else if (!inFrozenAskBand(ask)) reason = "ask_out_of_band";
    else if (inFrozenStillMid(ask)) reason = "still_mid";
    else if (!(input.feeNetEvCents >= SHADOW_V1_EV_FLOOR_CENTS)) reason = "ev_below_floor";
    else if (!(input.kellyFrac <= SHADOW_V1_KELLY_CAP)) reason = "kelly_above_cap";
    else if (!input.positionAndPendingClear) reason = "position_or_pending";
    else reason = "base_ineligible";
  } else if (shadowSit) {
    reason = "SHADOW_SIT";
  } else if (protectedCheapNo) {
    reason = "PROTECTED_CHEAP_NO";
  } else if (protectedCheapYes) {
    reason = "PROTECTED_CHEAP_YES";
  } else {
    reason = "BASE_ELIGIBLE_UNSAT";
  }

  return {
    predicate: YES_40_55_PIN_SHADOW_V1,
    baseEligible,
    shadowSit,
    protectedCheapNo,
    protectedCheapYes,
    reason,
    brtiSign: input.brtiSign ?? null,
  };
}

function emptyBucket(): ShadowV1BucketSummary {
  return { n: 0, wins: 0, losses: 0, pnlCents: 0 };
}

function accumulate(bucket: ShadowV1BucketSummary, pnl: number): void {
  bucket.n += 1;
  bucket.pnlCents += pnl;
  if (pnl > 0) bucket.wins += 1;
  else bucket.losses += 1;
}

function ci95Mean(pnls: number[]): [number, number] | null {
  const n = pnls.length;
  if (n < 2) return null;
  const mean = pnls.reduce((a, b) => a + b, 0) / n;
  const varSum = pnls.reduce((a, x) => a + (x - mean) * (x - mean), 0);
  const sd = Math.sqrt(varSum / (n - 1));
  const half = 1.96 * sd / Math.sqrt(n);
  return [mean - half, mean + half];
}

/**
 * Summarise CLOSE rows tagged with YES_40_55_PIN_SHADOW_V1 (or shadowSit=true).
 * Candidate closes = shadowSit === true.
 */
export function summarizeShadowV1(rows: ShadowV1CloseRow[]): ShadowV1Summary {
  const candidates = rows.filter(
    (r) =>
      r.shadowSit === true &&
      (r.predicate == null || r.predicate === YES_40_55_PIN_SHADOW_V1),
  );
  const pnls = candidates.map((c) => c.pnlCents);
  const n = candidates.length;
  const wins = candidates.filter((c) => c.pnlCents > 0).length;
  const losses = n - wins;
  const pnlCents = pnls.reduce((a, b) => a + b, 0);
  let winnersGivenUpCents = 0;
  let losersSavedCents = 0;
  for (const p of pnls) {
    if (p > 0) winnersGivenUpCents += p;
    else losersSavedCents += p;
  }
  const netImprovementCents = -pnlCents;

  const protectedCheapNo = emptyBucket();
  const protectedCheapYes = emptyBucket();
  for (const r of rows) {
    if (r.predicate != null && r.predicate !== YES_40_55_PIN_SHADOW_V1) continue;
    if (r.protectedCheapNo === true) accumulate(protectedCheapNo, r.pnlCents);
    if (r.protectedCheapYes === true) accumulate(protectedCheapYes, r.pnlCents);
  }

  return {
    n,
    wins,
    losses,
    pnlCents,
    winnersGivenUpCents,
    losersSavedCents,
    netImprovementCents,
    ci95: ci95Mean(pnls),
    protectedCheapNo,
    protectedCheapYes,
  };
}

// ── Append-only jsonl (telemetry; never throws into tick loop) ───────────────

export type EntryShadowDecisionRow = {
  kind: "DECISION";
  decisionId: string;
  ticker: string;
  ts: number;
  patchEra: typeof YES_40_55_PIN_SHADOW_V1;
  gitSha: string | null;
  paperMode: boolean;
  frozenCcMode: boolean;
  side: FrozenSide;
  ask: number;
  secsRemaining: number;
  feeNetEv: number;
  kellyFrac: number;
  w2Reason: string | null;
  regimeWouldBlock: boolean;
  haDisagree: boolean;
  pinReachable: boolean;
  strikeDisagree: boolean;
  brtiSign: string | null;
  realDecision: string;
  shadowSit: boolean;
  protectedCheapNo: boolean;
  protectedCheapYes: boolean;
  baseEligible: boolean;
  quoteFresh: boolean;
  spread?: number | null;
  reason: string;
};

export type EntryShadowCloseRow = {
  kind: "CLOSE";
  decisionId: string;
  canonicalTradeId: string;
  ticker: string;
  ts: number;
  patchEra: typeof YES_40_55_PIN_SHADOW_V1;
  side: FrozenSide;
  ask: number;
  pnlCents: number;
  grossPnlCents?: number;
  entryFeeCents: number;
  exitFeeCents: number;
  feeNetCents: number;
  exitReason: string;
  officialKalshi: string | null;
  settledSide: FrozenSide | null;
  holdToSettlementPnlCents: number | null;
  soldEarly: boolean;
  shadowSit: boolean;
  protectedCheapNo: boolean;
  protectedCheapYes: boolean;
  predicate: typeof YES_40_55_PIN_SHADOW_V1;
};

/** D3(c) — outcome of the Mind/brain bind for a DECISION row stamped "TAKE"
 *  before placeOrder. Readers keyed on DECISION/CLOSE ignore this kind. */
export type EntryShadowVetoRow = {
  kind: "VETO";
  decisionId: string;
  ticker: string;
  side: FrozenSide;
  ts: number;
  patchEra: typeof YES_40_55_PIN_SHADOW_V1;
  realDecision: string;
  reason: string;
};

export type EntryShadowRow = EntryShadowDecisionRow | EntryShadowCloseRow | EntryShadowVetoRow;

export function frozenCcEntryShadowPath(): string {
  if (process.env.FROZEN_CC_ENTRY_SHADOW_V1_PATH) {
    return path.resolve(process.env.FROZEN_CC_ENTRY_SHADOW_V1_PATH);
  }
  return path.resolve(process.cwd(), "data", FROZEN_CC_ENTRY_SHADOW_V1_FILENAME);
}

const decisionRateKeys = new Set<string>();

/** ticker+side unique per 15m contract window (ticker encodes the window). */
export function shadowDecisionRateKey(ticker: string, side: string): string {
  return `${ticker}|${side}`;
}

export function appendEntryShadowRow(row: EntryShadowRow, filePath = frozenCcEntryShadowPath()): void {
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.appendFileSync(filePath, JSON.stringify(row) + "\n");
  } catch {
    // Observational only.
  }
}

/**
 * Rate-limited DECISION append: at most one per ticker+side per process life
 * for that contract window (ticker is the window id).
 */
export function maybeAppendEntryShadowDecision(
  partial: Omit<EntryShadowDecisionRow, "kind" | "decisionId" | "patchEra" | "gitSha" | "ts"> & {
    decisionId?: string;
    ts?: number;
  },
): string | null {
  const key = shadowDecisionRateKey(partial.ticker, partial.side);
  if (decisionRateKeys.has(key)) return null;
  // Only log when there is something to observe (eligible / sit / protected / AND).
  if (
    !partial.baseEligible &&
    !partial.shadowSit &&
    !partial.protectedCheapNo &&
    !partial.protectedCheapYes &&
    partial.realDecision !== `SKIP:${"AND_SIT_HA_REGIME"}` &&
    !String(partial.realDecision).includes("AND_SIT")
  ) {
    return null;
  }
  decisionRateKeys.add(key);
  const decisionId = partial.decisionId ?? randomUUID();
  appendEntryShadowRow({
    kind: "DECISION",
    decisionId,
    ts: partial.ts ?? Date.now(),
    patchEra: YES_40_55_PIN_SHADOW_V1,
    gitSha: runningGitSha(),
    ticker: partial.ticker,
    paperMode: partial.paperMode,
    frozenCcMode: partial.frozenCcMode,
    side: partial.side,
    ask: partial.ask,
    secsRemaining: partial.secsRemaining,
    feeNetEv: partial.feeNetEv,
    kellyFrac: partial.kellyFrac,
    w2Reason: partial.w2Reason,
    regimeWouldBlock: partial.regimeWouldBlock,
    haDisagree: partial.haDisagree,
    pinReachable: partial.pinReachable,
    strikeDisagree: partial.strikeDisagree,
    brtiSign: partial.brtiSign,
    realDecision: partial.realDecision,
    shadowSit: partial.shadowSit,
    protectedCheapNo: partial.protectedCheapNo,
    protectedCheapYes: partial.protectedCheapYes,
    baseEligible: partial.baseEligible,
    quoteFresh: partial.quoteFresh,
    spread: partial.spread ?? null,
    reason: partial.reason,
  });
  return decisionId;
}

export function appendEntryShadowClose(row: Omit<EntryShadowCloseRow, "kind" | "patchEra" | "predicate"> & {
  predicate?: typeof YES_40_55_PIN_SHADOW_V1;
}): void {
  appendEntryShadowRow({
    kind: "CLOSE",
    patchEra: YES_40_55_PIN_SHADOW_V1,
    predicate: YES_40_55_PIN_SHADOW_V1,
    ...row,
  });
}

export function readEntryShadowRows(filePath = frozenCcEntryShadowPath()): EntryShadowRow[] {
  try {
    if (!fs.existsSync(filePath)) return [];
    const lines = fs.readFileSync(filePath, "utf8").trim().split("\n").filter(Boolean);
    return lines.map((l) => JSON.parse(l) as EntryShadowRow);
  } catch {
    return [];
  }
}

export function summarizeEntryShadowFromJsonl(filePath = frozenCcEntryShadowPath()): ShadowV1Summary & {
  predicate: typeof YES_40_55_PIN_SHADOW_V1;
  observeOnly: true;
  goNoGo: "INSUFFICIENT_DATA" | "GO" | "NO_GO";
} {
  const rows = readEntryShadowRows(filePath);
  const closes = rows.filter((r): r is EntryShadowCloseRow => r.kind === "CLOSE");
  const summary = summarizeShadowV1(closes);
  const goNoGo =
    summary.n < 40
      ? "INSUFFICIENT_DATA"
      : summary.netImprovementCents > 0 && summary.ci95 != null && summary.ci95[0] > 0
        ? "GO"
        : summary.n >= 40
          ? "NO_GO"
          : "INSUFFICIENT_DATA";
  return {
    predicate: YES_40_55_PIN_SHADOW_V1,
    observeOnly: true,
    ...summary,
    goNoGo: summary.n < 40 ? "INSUFFICIENT_DATA" : goNoGo,
  };
}

/** Test helper: clear in-memory rate-limit set. */
export function _resetEntryShadowRateLimitForTests(): void {
  decisionRateKeys.clear();
}

// Re-export band helpers used by tests (constants live in frozen-cc).
export {
  FROZEN_CC_MIN_SECS,
  FROZEN_CC_MAX_SECS,
  FROZEN_CC_ASK_MIN,
  FROZEN_CC_ASK_MAX,
  FROZEN_CC_STILL_MID_MIN,
  FROZEN_CC_STILL_MID_MAX,
};

/** D3(c) — record that the TAKE for `decisionId` was vetoed at the place-bind. */
export function appendEntryShadowVeto(row: { decisionId: string; ticker: string; side: FrozenSide; realDecision: string; reason: string; ts?: number }, filePath = frozenCcEntryShadowPath()): void {
  appendEntryShadowRow({ kind: "VETO", patchEra: YES_40_55_PIN_SHADOW_V1, ts: row.ts ?? Date.now(), decisionId: row.decisionId, ticker: row.ticker, side: row.side, realDecision: row.realDecision, reason: row.reason }, filePath);
}
