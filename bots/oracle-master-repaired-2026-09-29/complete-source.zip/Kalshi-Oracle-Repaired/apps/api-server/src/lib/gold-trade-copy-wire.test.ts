/**
 * gold-trade-copy — preferGoldStrategyId is advisory/shadow under alignedTakeGate.
 * Must not bypass six-gate / EV≥3. Frozen sole path does not require gold for place.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { preferGoldStrategyId } from "./gold-trade-copy.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));

test("gold-trade-copy: preferGoldStrategyId wired via aligned-take-gate (advisory)", () => {
  const gate = fs.readFileSync(path.join(HERE, "aligned-take-gate.ts"), "utf8");
  assert.ok(/preferGoldStrategyId/.test(gate));
  assert.ok(/from ["']\.\/gold-trade-copy\.js["']/.test(gate));
});

test("gold-trade-copy: trading-bot frozen path does not import gold-trade-copy directly", () => {
  const bot = fs.readFileSync(path.join(HERE, "trading-bot.ts"), "utf8");
  assert.equal(/from ["']\.\/gold-trade-copy\.js["']/.test(bot), false);
});

test("gold-trade-copy: preferGoldStrategyId returns null without matching cell", () => {
  assert.equal(
    preferGoldStrategyId({
      side: "yes",
      ask: 1,
      lagProven: false,
    }),
    null,
  );
});
