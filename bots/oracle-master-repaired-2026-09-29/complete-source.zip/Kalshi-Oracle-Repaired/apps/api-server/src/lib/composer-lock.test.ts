import { test } from "node:test";
import assert from "node:assert/strict";
import { applyComposerLocks, clampAriaConfidenceAdj, CONFIRM_AUTO_MODE_PHRASE } from "./composer-lock.js";

const base = {
  autoMode: false as boolean,
  autoModeV2Mode: "suggest" as const,
  useExpertAgent: false as boolean,
  ariaModel: "",
  paperMode: true as boolean,
};

test("applyComposerLocks: already-correct config is a no-op", () => {
  const r = applyComposerLocks(base, {});
  assert.equal(r.config.autoMode, false);
  assert.equal(r.config.autoModeV2Mode, "suggest");
  assert.equal(r.config.useExpertAgent, false);
  assert.equal(r.config.paperMode, true);
  assert.equal(r.notes.length, 0);
});

test("applyComposerLocks: autoMode true forced false on paper without confirm", () => {
  const r = applyComposerLocks({ ...base, autoMode: true }, {});
  assert.equal(r.config.autoMode, false);
  assert.equal(r.config.paperMode, true);
  assert.match(r.notes.join(" "), /CONFIRM AUTO MODE/);
});

test("applyComposerLocks: autoMode true kept on paper with CONFIRM AUTO MODE", () => {
  const r = applyComposerLocks(
    { ...base, autoMode: true },
    { confirmAutoMode: CONFIRM_AUTO_MODE_PHRASE },
  );
  assert.equal(r.config.autoMode, true);
  assert.equal(r.config.paperMode, true);
});

test("applyComposerLocks: v2 bounded_write is coerced to suggest", () => {
  const r = applyComposerLocks({ ...base, autoModeV2Mode: "bounded_write" }, {});
  assert.equal(r.config.autoModeV2Mode, "suggest");
  assert.match(r.notes.join(" "), /suggest-only/);
});

test("applyComposerLocks: useExpertAgent without model/key is coerced false", () => {
  const r = applyComposerLocks({ ...base, useExpertAgent: true, ariaModel: "" }, {});
  assert.equal(r.config.useExpertAgent, false);
  const r2 = applyComposerLocks(
    { ...base, useExpertAgent: true, ariaModel: "openai/gpt-5" },
    { openRouterKey: "" },
  );
  assert.equal(r2.config.useExpertAgent, false);
});

test("applyComposerLocks: useExpertAgent stays true only when model AND key exist", () => {
  const r = applyComposerLocks(
    { ...base, useExpertAgent: true, ariaModel: "openai/gpt-5" },
    { openRouterKey: "sk-test" },
  );
  assert.equal(r.config.useExpertAgent, true);
  assert.equal(r.notes.length, 0);
});

test("clampAriaConfidenceAdj: positive boosts become 0 (tighten-only)", () => {
  assert.equal(clampAriaConfidenceAdj(15), 0);
  assert.equal(clampAriaConfidenceAdj(1), 0);
  assert.equal(clampAriaConfidenceAdj(0), 0);
  assert.equal(clampAriaConfidenceAdj(-8), -8);
  assert.equal(clampAriaConfidenceAdj(-15), -15);
  assert.equal(clampAriaConfidenceAdj(Number.NaN), 0);
});

test("applyComposerLocks: paperMode false is coerced true (LIVE REAL MONEY lock)", () => {
  const r = applyComposerLocks({ ...base, paperMode: false }, {});
  assert.equal(r.config.paperMode, true);
  assert.match(r.notes.join(" "), /paperMode forced true — paper-only desk/);
});

test("applyComposerLocks: paperMode true + autoMode true still forces autoMode off without confirm", () => {
  const r = applyComposerLocks({ ...base, paperMode: true, autoMode: true }, {});
  assert.equal(r.config.paperMode, true);
  assert.equal(r.config.autoMode, false);
  assert.ok(!r.notes.some(n => n.includes("paperMode")));
});

test("applyComposerLocks: paper-only desk — paperMode false never kept, even with LIVE REAL MONEY", () => {
  const blocked = applyComposerLocks({ ...base, paperMode: false }, {});
  assert.equal(blocked.config.paperMode, true);

  const phrase = applyComposerLocks(
    { ...base, paperMode: false, autoMode: true },
    { confirmLiveRealMoney: "LIVE REAL MONEY", confirmAutoMode: CONFIRM_AUTO_MODE_PHRASE },
  );
  assert.equal(phrase.config.paperMode, true);

  for (const v of [0, null, "", "false", undefined]) {
    const r = applyComposerLocks({ ...base, paperMode: v as unknown as boolean }, {});
    assert.equal(r.config.paperMode, true, `paperMode=${JSON.stringify(v)} must coerce to true`);
  }
});
