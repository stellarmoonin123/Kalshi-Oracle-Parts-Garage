/**
 * accounts/passwords.ts — Argon2id hashing (via @node-rs/argon2, prebuilt
 * binaries, no node-gyp). Plaintext passwords are never stored, returned or
 * logged; only the PHC-format hash is persisted.
 */
import { randomBytes, randomInt } from "node:crypto";
import { hash as argonHash, verify as argonVerify } from "@node-rs/argon2";

/** @node-rs/argon2 `Algorithm.Argon2id` (ambient const enum; inlined for isolatedModules). */
const ARGON2ID = 2;

/** OWASP 2024 Argon2id baseline: m=19 MiB, t=2, p=1. */
export const ARGON2_OPTIONS = {
  algorithm: ARGON2ID,
  memoryCost: 19_456,
  timeCost: 2,
  parallelism: 1,
  outputLen: 32,
} as const;

export const PASSWORD_MIN_LENGTH = 10;
export const PASSWORD_MAX_LENGTH = 200;

export async function hashPassword(plain: string): Promise<string> {
  return argonHash(plain, ARGON2_OPTIONS);
}

/** Never throws: malformed hash / input → false. */
export async function verifyPassword(storedHash: string, plain: string): Promise<boolean> {
  if (typeof storedHash !== "string" || typeof plain !== "string" || !storedHash.startsWith("$argon2")) return false;
  try {
    return await argonVerify(storedHash, plain);
  } catch {
    return false;
  }
}

let dummyHashPromise: Promise<string> | null = null;

/**
 * A real Argon2id hash of a random secret. Verified against when the account
 * is unknown so unknown / disabled / wrong-password logins take the same time.
 */
export function dummyPasswordHash(): Promise<string> {
  if (!dummyHashPromise) dummyHashPromise = hashPassword(randomBytes(24).toString("base64url"));
  return dummyHashPromise;
}

/** Returns an error message, or null when the password is acceptable. */
export function passwordPolicyError(pw: unknown): string | null {
  if (typeof pw !== "string") return "Password is required.";
  if (pw.length < PASSWORD_MIN_LENGTH) return `Password must be at least ${PASSWORD_MIN_LENGTH} characters.`;
  if (pw.length > PASSWORD_MAX_LENGTH) return `Password must be at most ${PASSWORD_MAX_LENGTH} characters.`;
  if (pw.trim().length === 0) return "Password cannot be blank.";
  return null;
}

// No look-alike characters (0/O, 1/l/I) so a temp password can be read aloud.
const TEMP_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";

/** Cryptographically random temporary password (shown to the admin once). */
export function generateTemporaryPassword(length = 16): string {
  let out = "";
  for (let i = 0; i < length; i++) out += TEMP_ALPHABET[randomInt(TEMP_ALPHABET.length)];
  // Group for readability: xxxx-xxxx-xxxx-xxxx
  return out.match(/.{1,4}/g)!.join("-");
}
