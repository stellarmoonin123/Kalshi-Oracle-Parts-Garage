/**
 * admission-survival-funnel.test.ts — GO: INSTITUTIONAL PROMOTION +
 * ADMISSION SURVIVAL ANALYSIS, Part II, 2026-08-25.
 *
 * Proves: (1) getAdmissionSurvivalFunnelReport() never throws and returns a
 * structurally valid, self-consistent report against real (possibly sparse)
 * live data; (2) the bottom-up funnel reconstruction is internally
 * consistent (entered = survived + died at every stage, and each stage's
 * survivedCount equals the next stage down's enteredCount); (3) the report
 * is genuinely read-only — it never imports a DB write path.
 *
 * Run with: tsx --test src/lib/admission-survival-funnel.test.ts
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { getAdmissionSurvivalFunnelReport } from "./admission-survival-funnel.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

test("read-only guarantee: admission-survival-funnel.ts contains no db.insert/update/delete call", () => {
  const src = fs.readFileSync(path.join(__dirname, "admission-survival-funnel.ts"), "utf8");
  assert.ok(!/db\.(insert|update|delete)/.test(src),
    "admission-survival-funnel.ts must remain strictly read-only — found a DB write call");
});

test("getAdmissionSurvivalFunnelReport: returns a structurally valid report", async () => {
  const report = await getAdmissionSurvivalFunnelReport();
  assert.equal(report.windowHours, 72);
  assert.ok(new Date(report.windowStart).getTime() < new Date(report.windowEnd).getTime());
  assert.equal(report.stages.length, 5, "expected exactly the 5 sequential funnel stages (S2-S6)");
  assert.ok(report.attemptedCount >= 0);
  assert.ok(report.filledCount >= 0);
  assert.ok(report.filledCount <= report.attemptedCount + report.unfilledOrCancelledCount + 1,
    "sanity bound: filled should not wildly exceed attempted+unfilled (allows for edge rounding, not a strict invariant)");
});

test("getAdmissionSurvivalFunnelReport: bottom-up reconstruction is internally consistent at every stage", async () => {
  const report = await getAdmissionSurvivalFunnelReport();
  for (const stage of report.stages) {
    assert.equal(stage.enteredCount, stage.deathCount + stage.survivedCount,
      `${stage.stage}: entered must equal deaths + survived`);
    assert.ok(stage.survivalRatePct >= 0 && stage.survivalRatePct <= 100,
      `${stage.stage}: survival rate must be a valid percentage`);
  }
  // Chained consistency: each stage's survivedCount must equal the next
  // stage DOWN the funnel's enteredCount (S2 -> S3 -> S4 -> S5 -> S6), and
  // the last stage's survivedCount must equal attemptedCount exactly (the
  // bottom of the reconstruction is anchored to the one directly-countable
  // cohort, bot_trades rows).
  const order = ["S2_REGIME_SESSION_PACK", "S3_CONSENSUS_CONF_VELOCITY", "S4_ENTRY_BAND_ASK_QUALITY", "S5_PATH_GATE_EV", "S6_SIZING"];
  const byStage = new Map(report.stages.map(s => [s.stage, s]));
  for (let i = 0; i < order.length - 1; i++) {
    const upper = byStage.get(order[i] as any)!;
    const lower = byStage.get(order[i + 1] as any)!;
    assert.equal(upper.survivedCount, lower.enteredCount,
      `${order[i]}'s survivedCount must feed exactly into ${order[i + 1]}'s enteredCount`);
  }
  const last = byStage.get("S6_SIZING")!;
  assert.equal(last.survivedCount, report.attemptedCount,
    "the innermost stage's survivedCount must equal attemptedCount — the funnel's one directly-countable anchor");
});

test("getAdmissionSurvivalFunnelReport: forbiddenFixes is non-empty and stratification/decomposition sections are present", async () => {
  const report = await getAdmissionSurvivalFunnelReport();
  assert.ok(report.forbiddenFixes.length >= 5);
  assert.ok(report.throttlingCaveat.length > 0);
  assert.ok(Array.isArray(report.stratification.bySession));
  assert.ok(Array.isArray(report.stratification.byStrategyId));
  assert.ok(Array.isArray(report.stratification.byTimeLeftBucket));
  assert.ok(Array.isArray(report.stage5Decomposition.byRawCode));
  assert.ok(Array.isArray(report.stage6Decomposition.byRawCode));
});
