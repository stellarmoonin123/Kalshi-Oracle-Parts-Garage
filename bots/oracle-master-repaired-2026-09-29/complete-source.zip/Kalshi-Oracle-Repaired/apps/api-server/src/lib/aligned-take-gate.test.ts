/**
 * alignedTakeGate isolate-rewrite-compare.
 * CC YES 31¢ MTF long TAKE; CC does not skip on !lagProven; LAG !lagProven SKIP;
 * leftover id SKIP; opposed YES 29¢ MTF short SKIP unless NO 28–55 TAKE NO;
 * p is P(NO) when taking NO; EV<3 SKIP.
 * analog long + strike cheap NO 33¢ → TAKE NO not analog YES.
 * Leftover SETTLEMENT_SIDE cannot beat CC/LAG TAKE. Does not cut EV 3¢.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  alignedTakeGate,
  overlayAlignedTake,
  constructedNoSignCheck,
  formatConstructedNoLog,
  LAST_60S_BRTI_AVG_SKIP,
  STILL_MID_UNCLEAR_SKIP,
  sweptFillHitsStillMid,
  inStrategyAskBand,
  stillMidUnclearBlocksEntry,
  STILL_MID_MIN_CENTS,
  STILL_MID_MAX_CENTS,
  ALIGNED_ASK_MAX_CENTS,
  ALIGNED_ASK_MIN_CENTS,
  ALIGNED_NO_ASK_MIN_CENTS,
  LAG_ALIGNED_ASK_MIN_CENTS,
  LAG_ASK_BELOW_MIN_SKIP,
} from "./aligned-take-gate.js";
import {
  alignedTakeGateIsolate,
  overlayAlignedTakeIsolate,
  analogHaColorToSide,
  analogSpotVsLastCloseToSide,
} from "./aligned-take-gate.isolate.js";
import { confluenceWinRate } from "./confluence-cascade.js";
import { computeTradeEV } from "./trade-path.js";
import { EV_FLOOR } from "./admission.js";
import { kalshiStrikeContractSide } from "./settlement-side.js";

const wr = (side: "yes" | "no", ask: number) => confluenceWinRate(ask, 7);

/** #518 / analog-agree YES: spot above Kalshi floor. */
const STRIKE_YES = { spot: 65_100, floorStrike: 65_000 } as const;
/** analog long but Kalshi cheap ticket is NO (spot below floor). */
const STRIKE_NO = { spot: 64_900, floorStrike: 65_000 } as const;

test("locks: EV_FLOOR 3; band 20-55; LAG desk min 20; CC TAKE does not require lagProven", () => {
  assert.equal(EV_FLOOR, 3);
  assert.equal(ALIGNED_ASK_MIN_CENTS, 20);
  assert.equal(ALIGNED_NO_ASK_MIN_CENTS, 20);
  assert.equal(ALIGNED_ASK_MAX_CENTS, 55);
  assert.equal(LAG_ALIGNED_ASK_MIN_CENTS, 20);
});

test("CC YES 31c MTF long TAKE", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    winRateAtPrice: wr,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "TAKE");
  if (g.kind !== "TAKE") return;
  assert.equal(g.strategyId, "CONFLUENCE_CASCADE");
  assert.equal(g.side, "yes");
  assert.equal(g.ask, 31);
  assert.equal(g.p, confluenceWinRate(31, 7));
  assert.ok(g.ev >= 3);
});

test("CC does not skip on !lagProven", () => {
  const g = alignedTakeGate({
    mtfSign: 4,
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    strategyId: "CONFLUENCE_CASCADE",
    winRateAtPrice: wr,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "TAKE");
  const iso = alignedTakeGateIsolate({
    mtfSign: 4,
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    strategyId: "CONFLUENCE_CASCADE",
    winRateAtPrice: wr,
    ...STRIKE_YES,
  });
  assert.equal(iso.kind, "SKIP");
  if (iso.kind === "SKIP") assert.equal(iso.reason, "LAG_UNPROVEN");
});

test("LAG !lagProven SKIP", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    strategyId: "BASIS_LAG_EDGE",
    winRateAtPrice: wr,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "SKIP");
  if (g.kind === "SKIP") assert.equal(g.reason, "LAG_UNPROVEN");
});

test("leftover id SKIP", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: true,
    strategyId: "SETTLEMENT_PREDICTION",
    winRateAtPrice: wr,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "SKIP");
  if (g.kind === "SKIP") assert.equal(g.reason, "leftover_id");
});

test("opposed YES 29c MTF short SKIP unless NO ask 28-55 TAKE NO; p is P(NO)", () => {
  const skipOpposed = alignedTakeGate({
    mtfSign: "short",
    yesAsk: 29,
    noAsk: 71,
    lagProven: false,
    winRateAtPrice: wr,
    ...STRIKE_YES,
  });
  assert.equal(skipOpposed.kind, "SKIP");
  if (skipOpposed.kind === "SKIP") assert.equal(skipOpposed.reason, "opposed_side");

  const takeNo = alignedTakeGate({
    mtfSign: "short",
    yesAsk: 29,
    noAsk: 33,
    lagProven: false,
    winRateAtPrice: (side, ask) => side === "no" ? 0.61 : 0.41,
    ...STRIKE_YES,
  });
  assert.equal(takeNo.kind, "TAKE");
  if (takeNo.kind !== "TAKE") return;
  assert.equal(takeNo.strategyId, "CONFLUENCE_CASCADE");
  assert.equal(takeNo.side, "no");
  assert.equal(takeNo.ask, 33);
  assert.equal(takeNo.p, 0.61);
  assert.notEqual(takeNo.p, 0.41);

  const iso = alignedTakeGateIsolate({
    mtfSign: "short",
    yesAsk: 29,
    noAsk: 33,
    lagProven: true,
    winRateAtPrice: wr,
    ...STRIKE_YES,
  });
  assert.equal(iso.kind, "SKIP", "isolate vetoes opposed YES and does not construct NO");
});

test("EV<3 SKIP", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: true,
    p: 0.40,
    ev: 2,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "SKIP");
  if (g.kind === "SKIP") assert.equal(g.reason, "ev_below_3");
});

test("quote_stale / p_null / ask out of band fail-closed", () => {
  assert.equal(alignedTakeGate({
    mtfSign: "long", yesAsk: 31, noAsk: 69, quoteStale: true, winRateAtPrice: wr, ...STRIKE_YES,
  }).kind, "SKIP");
  const pNull = alignedTakeGate({
    mtfSign: "long", yesAsk: 31, noAsk: 69, winRateAtPrice: () => null, ...STRIKE_YES,
  });
  assert.equal(pNull.kind, "SKIP");
  if (pNull.kind === "SKIP") assert.equal(pNull.reason, "p_null");
  const band = alignedTakeGate({
    mtfSign: "long", yesAsk: 70, noAsk: 80, winRateAtPrice: wr, ...STRIKE_YES,
  });
  assert.equal(band.kind, "SKIP");
  if (band.kind === "SKIP") assert.equal(band.reason, "ask_out_of_band");
  // Fill-power lock: CC 56–62 may TAG gold but must NOT TAKE (max 55).
  const rich = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 58,
    noAsk: 70,
    lagProven: false,
    strategyId: "CONFLUENCE_CASCADE",
    p: 0.72,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(rich.kind, "SKIP");
  if (rich.kind === "SKIP") assert.equal(rich.reason, "ask_out_of_band");
});

test("leftover SETTLEMENT_SIDE cannot beat CC TAKE overlay; isolate leftover stands", () => {
  const gate = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    winRateAtPrice: wr,
    ...STRIKE_YES,
  });
  assert.equal(gate.kind, "TAKE");
  const leftover = { strategyId: "SETTLEMENT_PREDICTION", signal: "YES" as const, confidence: 0.99 };
  const cc = { strategyId: "CONFLUENCE_CASCADE", signal: "NO" as const, confidence: 0.62 };
  const pool = [leftover, cc];
  const win = overlayAlignedTake(leftover, pool, gate);
  assert.equal(win?.strategyId, "CONFLUENCE_CASCADE");
  assert.equal(win?.signal, "YES");
  const iso = overlayAlignedTakeIsolate(leftover, pool, gate);
  assert.equal(iso?.strategyId, "SETTLEMENT_PREDICTION");
});

test("isolate-rewrite-compare: rewrite wins CC 31c !lagProven TAKE vs isolate LAG_UNPROVEN", () => {
  const input = { mtfSign: "long" as const, yesAsk: 31, noAsk: 69, lagProven: false, winRateAtPrice: wr, ...STRIKE_YES };
  const rew = alignedTakeGate(input);
  const iso = alignedTakeGateIsolate(input);
  assert.equal(rew.kind, "TAKE");
  assert.equal(iso.kind, "SKIP");
  assert.ok(rew.kind === "TAKE" && rew.ev >= 3);
  const feeNet = computeTradeEV({ entryPriceCents: 31, winRate: confluenceWinRate(31, 7) }).netEV;
  assert.ok(feeNet >= 3);
});

test("strike unknown fail-closed (no analog last-close-vs-next-close fallback)", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    winRateAtPrice: wr,
  });
  assert.equal(g.kind, "SKIP");
  if (g.kind === "SKIP") assert.equal(g.reason, "strike_unknown");
  assert.equal(kalshiStrikeContractSide(undefined, 65_000), null);
  assert.equal(kalshiStrikeContractSide(65_100, 0), null);
});

test("analog long + strike cheap NO 33c → TAKE NO not YES; isolate analog skips NO", () => {
  assert.equal(analogSpotVsLastCloseToSide(65_100, 65_000), "yes");
  assert.equal(analogHaColorToSide("green"), "yes");
  assert.equal(kalshiStrikeContractSide(STRIKE_NO.spot, STRIKE_NO.floorStrike), "no");

  const input = {
    mtfSign: "long" as const,
    yesAsk: 67,
    noAsk: 33,
    lagProven: true,
    winRateAtPrice: (side: "yes" | "no", ask: number) => side === "no" ? 0.61 : 0.41,
    ...STRIKE_NO,
  };
  const rew = alignedTakeGate(input);
  const iso = alignedTakeGateIsolate(input);
  assert.equal(rew.kind, "TAKE");
  if (rew.kind !== "TAKE") return;
  assert.equal(rew.side, "no");
  assert.equal(rew.ask, 33);
  assert.equal(rew.p, 0.61);
  assert.notEqual(rew.side, "yes");
  assert.equal(iso.kind, "SKIP", "isolate analog long ignores strike cheap NO");
});

test("#518 YES 31c MTF long still TAKE YES", () => {
  const input = {
    mtfSign: "long" as const,
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    winRateAtPrice: wr,
    ...STRIKE_YES,
  };
  const rew = alignedTakeGate(input);
  const iso = alignedTakeGateIsolate({ ...input, lagProven: true });
  assert.equal(rew.kind, "TAKE");
  if (rew.kind !== "TAKE") return;
  assert.equal(rew.side, "yes");
  assert.equal(rew.ask, 31);
  assert.equal(rew.p, confluenceWinRate(31, 7));
  assert.ok(rew.ev >= 3);
  assert.equal(iso.kind, "TAKE");
  if (iso.kind === "TAKE") {
    assert.equal(iso.side, "yes");
    assert.equal(iso.ask, 31);
  }
  assert.equal(kalshiStrikeContractSide(STRIKE_YES.spot, STRIKE_YES.floorStrike), "yes");
});

test("MTF long YES 31c TAKE even when strike wick below floor (FLOOR_CROSS mirror)", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    winRateAtPrice: wr,
    spot: 64_900,
    floorStrike: 65_000, // strike NO — wick below floor
  });
  assert.equal(g.kind, "TAKE", "aligned cheap YES must not opposed_side on strike wick");
  if (g.kind !== "TAKE") return;
  assert.equal(g.side, "yes");
  assert.equal(g.ask, 31);
  assert.ok(g.ev >= 3);
});


test("45s left, aligned CC 31c EV>=3 → SKIP LAST_60S_BRTI_AVG (no new take)", () => {
  const input = {
    mtfSign: "long" as const,
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    winRateAtPrice: wr,
    secsRemaining: 45,
    ...STRIKE_YES,
  };
  const rew = alignedTakeGate(input);
  assert.equal(rew.kind, "SKIP");
  if (rew.kind === "SKIP") assert.equal(rew.reason, LAST_60S_BRTI_AVG_SKIP);
  const iso = alignedTakeGateIsolate({ ...input, lagProven: true });
  assert.equal(iso.kind, "TAKE", "isolate has no last-60s entry skip");
  const leftover = { strategyId: "CONFLUENCE_CASCADE", signal: "YES" as const };
  assert.equal(overlayAlignedTake(leftover, [leftover], rew), null, "overlay vetoes last-60s new take");
});

test("180s left, 31c aligned MTF long → TAKE", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    winRateAtPrice: wr,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "TAKE");
  if (g.kind !== "TAKE") return;
  assert.equal(g.strategyId, "CONFLUENCE_CASCADE");
  assert.equal(g.side, "yes");
  assert.equal(g.ask, 31);
  assert.ok(g.ev >= 3);
});

test("ask 50 SKIP still-mid HARD for CC and lagProven LAG; 28-47 and 53-55 still allowed", () => {
  assert.equal(STILL_MID_MIN_CENTS, 48);
  assert.equal(STILL_MID_MAX_CENTS, 52);
  const mid = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 50,
    noAsk: 50,
    lagProven: false,
    winRateAtPrice: wr,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(mid.kind, "SKIP");
  if (mid.kind === "SKIP") assert.equal(mid.reason, STILL_MID_UNCLEAR_SKIP);
  // Fill-power lock: lagProven LAG exemption removed — still-mid always blocks.
  const midLag = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 50,
    noAsk: 50,
    lagProven: true,
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(midLag.kind, "SKIP");
  if (midLag.kind === "SKIP") assert.equal(midLag.reason, STILL_MID_UNCLEAR_SKIP);
  const midCcOnly = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 50,
    noAsk: 50,
    lagProven: true,
    strategyId: "CONFLUENCE_CASCADE",
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(midCcOnly.kind, "SKIP");
  if (midCcOnly.kind === "SKIP") assert.equal(midCcOnly.reason, STILL_MID_UNCLEAR_SKIP);
  const isoMid = alignedTakeGateIsolate({
    mtfSign: "long",
    yesAsk: 50,
    noAsk: 50,
    lagProven: true,
    winRateAtPrice: wr,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(isoMid.kind, "TAKE", "isolate still takes 50c (frozen hole)");
  const cc = { strategyId: "CONFLUENCE_CASCADE", signal: "YES" as const };
  assert.equal(overlayAlignedTake(cc, [cc], mid), null);

  const cheap = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    winRateAtPrice: wr,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(cheap.kind, "TAKE");
  if (cheap.kind === "TAKE") assert.equal(cheap.ask, 31);

  const a47 = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 47,
    noAsk: 53,
    lagProven: false,
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(a47.kind, "TAKE");
  if (a47.kind === "TAKE") assert.equal(a47.ask, 47);

  const a53 = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 53,
    noAsk: 47,
    lagProven: false,
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(a53.kind, "TAKE");
  if (a53.kind === "TAKE") assert.equal(a53.ask, 53);

  const a55 = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 55,
    noAsk: 45,
    lagProven: false,
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(a55.kind, "TAKE");
  if (a55.kind === "TAKE") assert.equal(a55.ask, 55);

  const a48 = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 48,
    noAsk: 52,
    lagProven: true,
    strategyId: "BASIS_LAG_EDGE",
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(a48.kind, "SKIP");
  if (a48.kind === "SKIP") assert.equal(a48.reason, STILL_MID_UNCLEAR_SKIP);
});

test("Heavy R1#2: NO ticket cannot use P(YES) or yesAsk for green/EV", () => {
  const pYes = 0.41;
  const pNo = 0.61;
  const takeNo = alignedTakeGate({
    mtfSign: "short",
    yesAsk: 29,
    noAsk: 33,
    lagProven: false,
    // Leaked P(YES) must NOT override side-bound P(NO).
    p: pYes,
    winRateAtPrice: (side, ask) => side === "no" ? pNo : pYes,
    ...STRIKE_YES,
  });
  assert.equal(takeNo.kind, "TAKE");
  if (takeNo.kind !== "TAKE") return;
  assert.equal(takeNo.side, "no");
  assert.equal(takeNo.ask, 33);
  assert.equal(takeNo.p, pNo);
  assert.notEqual(takeNo.p, pYes);
  assert.equal(takeNo.constructedNo, true);
  assert.notEqual(takeNo.ask, 29);

  const badAsk = constructedNoSignCheck({
    side: "no", ask: 29, yesAsk: 29, noAsk: 33, p: pNo, pYes, pNo,
  });
  assert.equal(badAsk.ok, false);
  if (!badAsk.ok) assert.equal(badAsk.reason, "ask_not_noAsk");

  const badP = constructedNoSignCheck({
    side: "no", ask: 33, yesAsk: 29, noAsk: 33, p: pYes, pYes, pNo,
  });
  assert.equal(badP.ok, false);
  if (!badP.ok) assert.equal(badP.reason, "p_is_P_YES");

  const ok = constructedNoSignCheck({
    side: "no", ask: 33, yesAsk: 29, noAsk: 33, p: pNo, pYes, pNo,
  });
  assert.equal(ok.ok, true);
  assert.equal(
    formatConstructedNoLog({ p: pNo, ask: 33 }),
    "[CONSTRUCTED_NO] side=no p=0.61 ask=33",
  );
});

test("fill-power: LAG desk floor 20; LAG 38/44 TAKE; LAG ask 19 SKIP; CC 38 still allowed", () => {
  assert.equal(LAG_ALIGNED_ASK_MIN_CENTS, 20);
  const belowLag = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 19,
    noAsk: 81,
    lagProven: true,
    strategyId: "BASIS_LAG_EDGE",
    p: 0.70,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(belowLag.kind, "SKIP");
  if (belowLag.kind === "SKIP") {
    assert.ok(
      belowLag.reason === LAG_ASK_BELOW_MIN_SKIP || belowLag.reason === "ask_out_of_band",
      belowLag.reason,
    );
  }

  const okLag38 = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 38,
    noAsk: 62,
    lagProven: true,
    strategyId: "BASIS_LAG_EDGE",
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(okLag38.kind, "TAKE");
  if (okLag38.kind === "TAKE") {
    assert.equal(okLag38.strategyId, "BASIS_LAG_EDGE");
    assert.equal(okLag38.ask, 38);
  }

  const okLag = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 44,
    noAsk: 56,
    lagProven: true,
    strategyId: "BASIS_LAG_EDGE",
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(okLag.kind, "TAKE");
  if (okLag.kind === "TAKE") {
    assert.equal(okLag.strategyId, "BASIS_LAG_EDGE");
    assert.equal(okLag.ask, 44);
  }

  const cheapCc = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 38,
    noAsk: 62,
    lagProven: false,
    strategyId: "CONFLUENCE_CASCADE",
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(cheapCc.kind, "TAKE");
  if (cheapCc.kind === "TAKE") {
    assert.equal(cheapCc.strategyId, "CONFLUENCE_CASCADE");
    assert.equal(cheapCc.ask, 38);
  }
});


test("DESK DOOR: strategyId null + lagProven + ask 15 → SKIP ask_out_of_band (no LAG 10 lottery)", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 15,
    noAsk: 85,
    lagProven: true,
    p: 0.70,
    ev: 10,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "SKIP", `expected SKIP @15, got ${JSON.stringify(g)}`);
  if (g.kind === "SKIP") assert.equal(g.reason, "ask_out_of_band");

  const noLag = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 15,
    noAsk: 85,
    lagProven: false,
    p: 0.70,
    ev: 10,
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(noLag.kind, "SKIP");
  if (noLag.kind === "SKIP") {
    assert.ok(
      noLag.reason === "ask_out_of_band" || noLag.reason === "LAG_UNPROVEN",
      noLag.reason,
    );
  }
});

test("BUGFIX SIGN-SAFE: winRateAtPrice P(NO) ignores leaked YES-side EV", () => {
  // Low P(NO) → computed EV < 3; leaked ev:20 must NOT green the NO ticket.
  const g = alignedTakeGate({
    mtfSign: "short",
    yesAsk: 29,
    noAsk: 33,
    lagProven: false,
    p: 0.41,
    ev: 20,
    winRateAtPrice: (side) => (side === "no" ? 0.40 : 0.70),
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "SKIP");
  if (g.kind === "SKIP") assert.equal(g.reason, "ev_below_3");

  // High P(NO) still TAKEs with EV derived from P(NO), not leaked junk.
  const ok = alignedTakeGate({
    mtfSign: "short",
    yesAsk: 29,
    noAsk: 33,
    lagProven: false,
    ev: 1, // leaked below floor — must be ignored when winRateAtPrice sets p
    winRateAtPrice: (side) => (side === "no" ? 0.61 : 0.41),
    secsRemaining: 180,
    ...STRIKE_YES,
  });
  assert.equal(ok.kind, "TAKE");
  if (ok.kind === "TAKE") {
    assert.equal(ok.side, "no");
    assert.equal(ok.p, 0.61);
    assert.ok(ok.ev >= 3);
    assert.notEqual(ok.ev, 1);
  }
});

test("fill-power proof: ask~38 CC with ha_disagree tag path still TAKEs under aligned hard gates", () => {
  // Scripted evaluate stand-in: aligned hard gates only (W2 ha is tag-only).
  const g = alignedTakeGate({
    mtfSign: "short",
    yesAsk: 62,
    noAsk: 38,
    lagProven: false,
    strategyId: "CONFLUENCE_CASCADE",
    p: 0.60,
    ev: 8,
    secsRemaining: 14 * 60,
    spot: 64_900,
    floorStrike: 65_000,
  });
  assert.equal(g.kind, "TAKE");
  if (g.kind === "TAKE") {
    assert.equal(g.strategyId, "CONFLUENCE_CASCADE");
    assert.equal(g.side, "no");
    assert.equal(g.ask, 38);
    assert.ok(g.ev >= 3);
  }
  // stillMid / max55 / last60 remain hard:
  assert.equal(stillMidUnclearBlocksEntry({ ask: 50, lagProven: true, strategyId: "BASIS_LAG_EDGE" }), true);
  assert.equal(ALIGNED_ASK_MAX_CENTS, 55);
  assert.equal(LAG_ALIGNED_ASK_MIN_CENTS, 20);
});

test("BUGFIX: swept fill 47+1 / 46+2 hits still-mid; 45+1 and 53+1 do not", () => {
  assert.equal(sweptFillHitsStillMid(47, 1), true);
  assert.equal(sweptFillHitsStillMid(46, 2), true);
  assert.equal(sweptFillHitsStillMid(45, 1), false);
  assert.equal(sweptFillHitsStillMid(53, 1), false);
  assert.equal(sweptFillHitsStillMid(50, 0), true);
});

test("BUGFIX ask band: yesAsk 56 / noAsk 70 → ask_out_of_band (max 55; not opposed remap)", () => {
  // Both wings above max — must not TAKE; tryTake max guard + anyMoneyMakerAskInBand.
  const rich = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 56,
    noAsk: 70,
    lagProven: true,
    p: 0.7,
    ev: 10,
    secsRemaining: 400,
    spot: 65_100,
    floorStrike: 65_000,
  });
  assert.equal(rich.kind, "SKIP");
  if (rich.kind === "SKIP") assert.equal(rich.reason, "ask_out_of_band");
  assert.equal(inStrategyAskBand(56, "CONFLUENCE_CASCADE"), false);
  assert.equal(inStrategyAskBand(56, "BASIS_LAG_EDGE"), false);
});

test("BUGFIX: MTF YES lean @68–69 out of band + NO@33 in-band → TAKE NO when EV passes", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 68,
    noAsk: 33,
    lagProven: false,
    winRateAtPrice: (side, ask) => side === "no" ? 0.62 : 0.40,
    secsRemaining: 400,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "TAKE", "must select in-band cheap NO wing, not SKIP opposed_side");
  if (g.kind !== "TAKE") return;
  assert.equal(g.side, "no");
  assert.equal(g.ask, 33);
  assert.ok(g.ev >= 3, "EV floor unchanged");
  assert.equal(g.strategyId, "CONFLUENCE_CASCADE");
});

test("BUGFIX: MTF YES @69 + NO@33 still SKIP when NO EV < 3 (do not cut EV floor)", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 69,
    noAsk: 33,
    lagProven: false,
    // 100*0.30 - 33 = -3 → netEV below floor 3
    winRateAtPrice: () => 0.30,
    secsRemaining: 400,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "SKIP");
  if (g.kind === "SKIP") assert.equal(g.reason, "ev_below_3");
});


test("DESK DOOR: NO@20 TAKE; NO@19 SKIP; YES@20 TAKE; YES@19 SKIP", () => {
  const no20 = alignedTakeGate({
    mtfSign: "short",
    yesAsk: 80,
    noAsk: 20,
    lagProven: false,
    winRateAtPrice: (side, ask) => side === "no" ? 0.70 : 0.30,
    ...STRIKE_NO,
  });
  assert.equal(no20.kind, "TAKE", "NO@20 in desk door");
  if (no20.kind === "TAKE") assert.equal(no20.side, "no");

  const no19 = alignedTakeGate({
    mtfSign: "short",
    yesAsk: 81,
    noAsk: 19,
    lagProven: false,
    winRateAtPrice: (side, ask) => side === "no" ? 0.70 : 0.30,
    ...STRIKE_NO,
  });
  assert.equal(no19.kind, "SKIP");
  if (no19.kind === "SKIP") assert.equal(no19.reason, "ask_out_of_band");

  const yes20 = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 20,
    noAsk: 80,
    lagProven: false,
    winRateAtPrice: (side, ask) => side === "yes" ? 0.70 : 0.30,
    ...STRIKE_YES,
  });
  assert.equal(yes20.kind, "TAKE", "YES@20 in desk door");
  if (yes20.kind === "TAKE") assert.equal(yes20.side, "yes");

  const yes19 = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 19,
    noAsk: 81,
    lagProven: false,
    winRateAtPrice: (side, ask) => side === "yes" ? 0.70 : 0.30,
    ...STRIKE_YES,
  });
  assert.equal(yes19.kind, "SKIP");
  if (yes19.kind === "SKIP") assert.equal(yes19.reason, "ask_out_of_band");
});
