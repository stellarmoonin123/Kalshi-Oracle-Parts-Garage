/**
 * strategy-learner.ts
 *
 * Persists per-strategy win/loss stats from paper/simulation trades.
 * Feeds back as confidence multipliers when evaluateAllStrategies is called.
 *
 * Storage: JSON file at ./data/strategy-learning.json (created automatically).
 *
 * Architecture: in-memory store (read once on startup), debounced async writes.
 * This means recordOutcome() never blocks the event loop — writes happen 500 ms
 * after the last mutation without blocking the trading tick.
 */

import fs   from 'fs';
import path from 'path';

import { getAllStrategyMeta, durationBucket } from './strategy-library.js';
import type { Duration } from './strategy-library.js';

// process.cwd()-based, NOT __dirname-based. esbuild bundles every module
// (this file included) into a single dist/index.mjs, which collapses
// __dirname to dist/ regardless of this file's original depth under
// src/lib/ — an __dirname-relative '../../data' then resolves one level too
// high (artifacts/data instead of artifacts/api-server/data), but only in
// the bundled/production run, not under a plain tsx/dev run. That mismatch
// silently split this store into two copies that diverged over time: the
// bundled runtime kept writing real trade outcomes to artifacts/data/
// strategy-learning.json while artifacts/api-server/data/strategy-learning
// .json sat frozen with old data (including a phantom VELOCITY_MOMENTUM
// record with 51 wins / 0 losses that has zero corresponding rows in
// bot_trades — never real, and no longer reachable code). process.cwd() is
// stable because the workflow always launches from the package root
// (artifacts/api-server), matching the convention already used correctly by
// prediction-learner.ts's CAL_FILE. Tests can opt into an isolated directory
// so resetLearning() fixtures never mutate the live learning history.
const DATA_DIR  = process.env.STRATEGY_LEARNING_DATA_DIR
  ? path.resolve(process.env.STRATEGY_LEARNING_DATA_DIR)
  : path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'strategy-learning.json');

// ── Constants ──────────────────────────────────────────────────────────────────

const MIN_TRADES_BEFORE_WEIGHT = 40;
const RECENT_RESULTS_CAP = 50; // must match the shift() cap enforced in recordOutcome()

/** Never rewrite winRateAtPrice from the current paper sample. n<20 fail-close. Do not cut existing curves. */
export const WRITE_WINRATE_CURVE = false as const;
export const WRITE_WINRATE_CURVE_MIN_N = 20;

export type PathPLearnerSample = {
  n: number;
  isPaper?: boolean;
  realBotSettlesN?: number;
};

export function shouldWriteWinRateCurve(sample: PathPLearnerSample): boolean {
  if (WRITE_WINRATE_CURVE === false) return false;
  if (sample.isPaper) return false;
  const n = sample.realBotSettlesN ?? sample.n;
  if (!Number.isFinite(n) || n < WRITE_WINRATE_CURVE_MIN_N) return false;
  return false;
}

/**
 * PATH p may use learner WR only after n≥20 REAL (is_paper=false) CC/LAG settles.
 * Paper + thin n (CC 0.20 n=5, LAG 0.143 n=7) must not replace the calibrated curve.
 * Missing curve stays null (skip) — never invent 0.65.
 */
export function shouldApplyLearnerWinRateAsPathP(sample: PathPLearnerSample): boolean {
  const realN = sample.realBotSettlesN ?? (sample.isPaper ? 0 : sample.n);
  if (sample.isPaper === true) {
    if (!Number.isFinite(realN) || realN < WRITE_WINRATE_CURVE_MIN_N) return false;
  }
  if (!Number.isFinite(realN) || realN < WRITE_WINRATE_CURVE_MIN_N) return false;
  if (!Number.isFinite(sample.n) || sample.n < WRITE_WINRATE_CURVE_MIN_N) return false;
  return true;
}

export function pathPWinFromCurveOrLearner(opts: {
  curveP: number | null;
  learnerWR?: number | null;
  learnerN?: number;
  paperMode: boolean;
  realBotSettlesN: number;
}): number | null {
  const apply = shouldApplyLearnerWinRateAsPathP({
    n: opts.learnerN ?? opts.realBotSettlesN,
    isPaper: opts.paperMode,
    realBotSettlesN: opts.realBotSettlesN,
  });
  if (apply) {
    const wr = opts.learnerWR;
    if (typeof wr === "number" && Number.isFinite(wr) && wr > 0 && wr <= 1) return wr;
  }
  return opts.curveP;
}

export function getLearnerPathWinRateSample(strategyId: string, durationMins: number = 15): { n: number; winRate: number } {
  const store = getStore();
  const rec = store[storeKey(strategyId, durationBucket(durationMins))];
  if (!rec) return { n: 0, winRate: 0 };
  const n = typeof rec.trades === "number" && Number.isFinite(rec.trades) ? rec.trades : 0;
  const winRate = typeof rec.winRate === "number" && Number.isFinite(rec.winRate) ? rec.winRate : 0;
  return { n, winRate };
}
const MAX_WEIGHT = 1.18;
const MIN_WEIGHT = 0.72;
const DECAY      = 0.92;   // exponential decay factor — recent results count more

// ── Types ─────────────────────────────────────────────────────────────────────

export interface StrategyLearningRecord {
  strategyId:     string;
  /**
   * Contract-duration dimension ('15M' | '1H' | 'PERP'). Added so 15-minute
   * and 1-hour outcomes are no longer pooled into one blended win rate. Legacy
   * records (written before this field existed) are migrated to '15M' on first
   * load — the system traded 15m-only historically. Optional in the type so
   * old JSON on disk still parses; migrateDurationKeys() fills it in.
   */
  duration?:      Duration;
  trades:         number;
  wins:           number;
  losses:         number;
  totalPnlCents:  number;
  avgPnlCents:    number;
  winRate:        number;
  learningWeight: number;
  recentResults:  boolean[];   // rolling last-50 outcomes (true = win)
  /**
   * Durable identifiers for authoritative outcomes already applied to this
   * strategy. A bot-trades row can be retried after a restart or an async
   * settlement race; retaining every applied ID makes that retry a no-op
   * rather than silently inflating wins, losses, or P&L.
   *
   * Optional for backward compatibility with learning files written before
   * outcome-level idempotency existed.
   */
  recordedOutcomeKeys?: string[];
  lastUpdated:    number;
  /** expectedWinRate from the strategy definition — used as Bayesian Beta prior. */
  priorWinRate:   number;
  /**
   * Unix timestamp (ms) of the last time reconcilePriorWinRates confirmed this
   * record's priorWinRate matches the current strategy library value.
   * Used to detect stale priors when expectedWinRate is revised in the library.
   */
  lastPriorSyncedAt?: number;
}

export type LearningStore = Record<string, StrategyLearningRecord>;

/** Thesis-broken / time-stop / hold-floor exits are risk management, not a losing strategy. */
export type ExitClass = 'strategy' | 'risk_exit';


// ── Duration-keyed store helpers ────────────────────────────────────────────
// The store is now keyed by `${strategyId}::${duration}` so each strategy has
// SEPARATE realized stats per contract duration. A bare `strategyId` (no `::`)
// is a legacy key from before this change; it is migrated to `::15M`.

const KEY_SEP = '::';

/** Compose the store key for a (strategyId, duration) pair. */
function storeKey(strategyId: string, duration: Duration): string {
  return `${strategyId}${KEY_SEP}${duration}`;
}

/** Split a store key back into its parts. Legacy bare keys → duration '15M'. */
function parseKey(key: string): { strategyId: string; duration: Duration } {
  const idx = key.indexOf(KEY_SEP);
  if (idx < 0) return { strategyId: key, duration: '15M' };
  return { strategyId: key.slice(0, idx), duration: key.slice(idx + KEY_SEP.length) as Duration };
}

/**
 * One-time migration: rewrite any legacy bare-strategyId keys to
 * `${strategyId}::15M`, preserving all accumulated history. If both a bare key
 * and its ::15M key somehow exist, the ::15M key wins (already-migrated data)
 * and the bare record is dropped rather than double-counted.
 */
function migrateDurationKeys(store: LearningStore): boolean {
  let changed = false;
  for (const key of Object.keys(store)) {
    if (key.includes(KEY_SEP)) {
      // Already duration-keyed — just backfill the `duration` field if missing.
      const rec = store[key];
      if (rec && rec.duration === undefined) { rec.duration = parseKey(key).duration; changed = true; }
      continue;
    }
    const rec = store[key];
    if (!rec) continue;
    const newKey = storeKey(key, '15M');
    if (store[newKey]) {
      // Already-migrated data takes precedence; drop the stale bare record.
      delete store[key];
      changed = true;
      continue;
    }
    rec.duration = '15M';
    store[newKey] = rec;
    delete store[key];
    changed = true;
    console.log(`[strategy-learner] Migrated legacy record ${key} → ${newKey} (treated as 15M)`);
  }
  return changed;
}

// ── In-memory store ───────────────────────────────────────────────────────────
// Loaded once on first access; writes are debounced and async.

let _store: LearningStore | null = null;

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

/**
 * Trim any record's recentResults to the last RECENT_RESULTS_CAP entries, and
 * (Task #147/#152) drop any non-boolean entries a hand-edited or corrupted
 * disk file might carry (e.g. null, a stringified "true", a number).
 *
 * recordOutcome() enforces the length cap on every push via shift() and only
 * ever pushes an actual boolean, but a record written by an older build
 * (before the cap existed), edited by hand, or corrupted on disk could carry
 * an oversized and/or non-boolean-polluted array. Either defect silently
 * inflates any consumer that treats recentResults.length (or a truthy count
 * over it) as a trade-count/confidence/win-rate signal, so both must be
 * sanitized immediately on load, not just on the next write.
 *
 * Returns true if any record was changed (used to schedule a persisted fix-up).
 */
export function sanitizeRecentResults(store: LearningStore): boolean {
  let changed = false;
  for (const key of Object.keys(store)) {
    const rec = store[key];
    if (!Array.isArray(rec.recentResults)) continue;
    const cleaned = rec.recentResults
      .filter((r): r is boolean => typeof r === 'boolean')
      .slice(-RECENT_RESULTS_CAP);
    if (cleaned.length !== rec.recentResults.length) {
      rec.recentResults = cleaned;
      changed = true;
    }
  }
  return changed;
}

/**
 * Remove malformed or repeated durable outcome keys from older/hand-edited
 * learning files. Keys intentionally have no retention cap: dropping an old
 * key would reopen the exact duplicate-settlement path this ledger closes.
 */
function sanitizeRecordedOutcomeKeys(store: LearningStore): boolean {
  let changed = false;
  for (const record of Object.values(store)) {
    if (record.recordedOutcomeKeys === undefined) continue;
    const cleaned = [...new Set(
      Array.isArray(record.recordedOutcomeKeys)
        ? record.recordedOutcomeKeys.filter((key): key is string => typeof key === 'string' && key.length > 0)
        : [],
    )];
    if (
      !Array.isArray(record.recordedOutcomeKeys)
      || cleaned.length !== record.recordedOutcomeKeys.length
      || cleaned.some((key, index) => key !== record.recordedOutcomeKeys![index])
    ) {
      record.recordedOutcomeKeys = cleaned;
      changed = true;
    }
  }
  return changed;
}

// Task #151: surfaces whether the one-time reconcilePriorWinRates() pass on
// the most recent getStore() init succeeded, failed, or hasn't run yet, so
// /api/healthz can report a stale/corrupted prior-sync instead of it being
// silently swallowed. A thrown getAllStrategyMeta() (e.g. a bad import after
// a code change) must never prevent getStore() from returning a usable store
// — trading with the raw (unsynced) priors is strictly safer than the bot
// failing to boot at all.
let _lastReconcileOk: boolean | null = null;
let _lastReconcileError: string | null = null;
let _lastReconcileAt: number | null = null;

export function getReconcileHealth(): { ok: boolean | null; error: string | null; at: number | null } {
  return { ok: _lastReconcileOk, error: _lastReconcileError, at: _lastReconcileAt };
}

// Task #153: getStore()'s existing corrupt-JSON catch silently discarded the
// whole learning history and started from {} with only a console.warn — no
// operator-facing signal. Worse, /api/healthz's "learner file" check only
// verified the file EXISTS and has a nonzero size, so a truncated/corrupted
// file (still present, still nonzero bytes) reported healthy while every
// strategy's learningWeight/priorWinRate/recentResults had just been reset to
// defaults underneath it. Track that distinctly so healthz can surface it.
let _lastLoadCorrupted: boolean = false;
let _lastLoadError: string | null = null;
let _lastLoadBackupPath: string | null = null;

export function getLoadHealth(): { corrupted: boolean; error: string | null; backupPath: string | null } {
  return { corrupted: _lastLoadCorrupted, error: _lastLoadError, backupPath: _lastLoadBackupPath };
}

type StrategyMetaLoader = () => ReturnType<typeof getAllStrategyMeta>;

/**
 * Load the singleton store. The optional metadata loader is intentionally
 * injectable so the startup fail-open path can be tested without mutating an
 * imported ES module binding.
 */
export function getStore(strategyMetaLoader: StrategyMetaLoader = getAllStrategyMeta): LearningStore {
  if (_store !== null) return _store;
  ensureDir();
  try {
    if (fs.existsSync(DATA_FILE)) {
      _store = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) as LearningStore;
      _lastLoadCorrupted = false;
      _lastLoadError = null;
    } else {
      // Missing file: start empty AND schedule an immediate persist so healthz
      // (fileExists) and strategy scoring see a real path on disk without
      // waiting for the first recordOutcome(). Fresh Fly images ship a seed
      // copy; this path covers wiped volumes / local first boot.
      _store = {};
      scheduleWrite();
    }
  } catch (err) {
    console.warn('[strategy-learner] Could not load learning data, starting fresh:', (err as Error).message);
    _lastLoadCorrupted = true;
    _lastLoadError = (err as Error).message;
    // Preserve the corrupt file for forensics instead of letting the very
    // next scheduleWrite() silently overwrite it with a fresh {} — a
    // corrupted disk file is exactly the moment a human may want to inspect
    // or hand-recover it.
    try {
      _lastLoadBackupPath = `${DATA_FILE}.corrupt-${Date.now()}.json`;
      fs.copyFileSync(DATA_FILE, _lastLoadBackupPath);
    } catch (backupErr) {
      console.warn('[strategy-learner] Could not back up corrupt learning file:', (backupErr as Error).message);
      _lastLoadBackupPath = null;
    }
    _store = {};
  }
  const migrated  = migrateDurationKeys(_store);
  const sanitized = sanitizeRecentResults(_store);
  const sanitizedOutcomeKeys = sanitizeRecordedOutcomeKeys(_store);
  try {
    reconcilePriorWinRates(_store, strategyMetaLoader);
    _lastReconcileOk = true;
    _lastReconcileError = null;
  } catch (err) {
    // Fail-open on the SYNC PASS ONLY: the raw (possibly stale-prior) store is
    // still returned below rather than left null, so a code-change regression
    // here degrades to "priors didn't get the latest expectedWinRate update"
    // rather than "the bot can't start" or "getStore() re-throws forever".
    _lastReconcileOk = false;
    _lastReconcileError = (err as Error).message;
    console.warn('[strategy-learner] reconcilePriorWinRates failed — continuing with un-synced priors:', (err as Error).message);
  }
  _lastReconcileAt = Date.now();
  if (migrated || sanitized || sanitizedOutcomeKeys) scheduleWrite();
  return _store;
}

/**
 * Sync pass: ensure every record's priorWinRate matches the current
 * expectedWinRate in the strategy library.
 *
 * Rules:
 *   - Every record for a known strategy is checked unconditionally — there is
 *     no sentinel guard.  This means future revisions to expectedWinRate (e.g.
 *     FLOOR_DISTANCE moving from 0.73 → 0.76) are automatically picked up on
 *     the next server start without any manual migration.
 *   - Records whose stored prior already matches the library value are stamped
 *     with lastPriorSyncedAt but otherwise left untouched (no write scheduled).
 *   - wins, losses, trades, totalPnlCents, and recentResults are NEVER changed.
 *   - Derived fields (winRate, avgPnlCents, learningWeight) are recomputed from
 *     the corrected prior so Bayesian warm-start immediately reflects the right
 *     strategy-specific expectation.
 *   - Records for unknown strategy IDs (removed from the library) are left as-is.
 *
 * This runs once on first store access (inside getStore) and schedules a write
 * only when it actually modifies at least one record.
 */
export function reconcilePriorWinRates(
  store: LearningStore,
  strategyMetaLoader: StrategyMetaLoader = getAllStrategyMeta,
): void {
  const strategyMeta = strategyMetaLoader();
  const metaById = new Map(strategyMeta.map(m => [m.id, m.expectedWinRate]));

  let changed = false;
  const now = Date.now();

  for (const [key, record] of Object.entries(store)) {
    const { strategyId: id } = parseKey(key);
    const correctPrior = metaById.get(id as any);
    if (correctPrior === undefined) continue;  // unknown strategy — leave untouched

    const storedPrior = record.priorWinRate ?? 0.65;

    if (Math.abs(storedPrior - correctPrior) > 0.0001) {
      // Prior is stale — update it and recompute derived fields.
      console.log(
        `[strategy-learner] Syncing priorWinRate for ${id}: ` +
        `${storedPrior} → ${correctPrior}`,
      );
      record.priorWinRate = correctPrior;
      const d = derive(record, correctPrior);
      record.winRate        = d.winRate;
      record.avgPnlCents    = d.avgPnlCents;
      record.learningWeight = d.learningWeight;
      record.lastPriorSyncedAt = now;
      changed = true;
    } else if (!record.lastPriorSyncedAt) {
      // Prior is already correct but was never stamped — stamp it now.
      // This avoids re-checking on every subsequent restart once the field exists.
      record.lastPriorSyncedAt = now;
      changed = true;
    }
    // If lastPriorSyncedAt is already set AND prior matches → nothing to do.
  }

  if (changed) scheduleWrite();
}

// ── Debounced async writer ────────────────────────────────────────────────────

let _writeTimer: NodeJS.Timeout | null = null;

function scheduleWrite() {
  if (_writeTimer) return;  // already queued
  _writeTimer = setTimeout(async () => {
    _writeTimer = null;
    const snapshot = _store;
    if (!snapshot) return;
    try {
      ensureDir();
      await fs.promises.writeFile(DATA_FILE, JSON.stringify(snapshot, null, 2), 'utf8');
    } catch (err) {
      console.error('[strategy-learner] Failed to persist learning data:', (err as Error).message);
    }
  }, 500);  // coalesce rapid writes into one disk operation
}

// ── Derived fields ────────────────────────────────────────────────────────────

/**
 * Derive win rate, avg P&L, and learning weight from raw stats.
 *
 * Warm-start Bayesian Beta update (replaces the old weight=1.0 default):
 * Before 40 trades we use a Beta posterior whose prior is the strategy's
 * expectedWinRate (priorWinRate).  PRIOR_STRENGTH = 10 virtual trades gives a
 * confident prior that actual data quickly overrides.
 *
 *   posterior_mean = (α₀ + wins) / (α₀ + β₀ + trades)
 *   where α₀ = priorWinRate × 10, β₀ = (1 - priorWinRate) × 10
 *
 * The weight's deviation from 1.0 is scaled by confidence = trades / 40 so
 * the bot doesn't over-steer on a single trade.
 */
export function derive(
  raw: Pick<StrategyLearningRecord, 'trades' | 'wins' | 'losses' | 'totalPnlCents' | 'recentResults'>,
  priorWinRate = 0.65,
): Pick<StrategyLearningRecord, 'avgPnlCents' | 'winRate' | 'learningWeight'> {
  const winRate = raw.trades > 0 ? raw.wins / raw.trades : 0;
  const avgPnl  = raw.trades > 0 ? raw.totalPnlCents / raw.trades : 0;

  // Bayesian Beta posterior (useful from trade #1)
  const PRIOR_STRENGTH = 10;
  const alpha0     = priorWinRate * PRIOR_STRENGTH;
  const beta0      = (1 - priorWinRate) * PRIOR_STRENGTH;
  const bayesianWR = (alpha0 + raw.wins) / (alpha0 + beta0 + raw.trades);

  let weight = 1.0;

  // Task #152: same hardening as getQuarantinedStrategies()'s recordQuarantined()
  // — a hand-edited or disk-corrupted recentResults array can carry non-boolean
  // entries. Counting every element into weightedTotal (regardless of type) and
  // treating any truthy garbage as a win would distort learningWeight (the
  // confidence multiplier applied to every future trade of this strategy) off
  // real evidence. Only real booleans count.
  const cleanRecent = Array.isArray(raw.recentResults)
    ? raw.recentResults.filter((r): r is boolean => typeof r === 'boolean')
    : [];
  if (raw.trades >= MIN_TRADES_BEFORE_WEIGHT && cleanRecent.length > 0) {
    // Mature strategy: exponentially-weighted recent results
    const relevant = cleanRecent.slice(-25);
    let weightedWins  = 0;
    let weightedTotal = 0;
    relevant.forEach((win, i) => {
      const w = Math.pow(DECAY, relevant.length - 1 - i);
      weightedTotal += w;
      if (win) weightedWins += w;
    });
    const recentWR = weightedTotal > 0 ? weightedWins / weightedTotal : bayesianWR;
    const blended  = recentWR * 0.65 + winRate * 0.35;

    if (blended >= 0.72)      weight = MAX_WEIGHT;
    else if (blended <= 0.42) weight = MIN_WEIGHT;
    else                      weight = MIN_WEIGHT + ((blended - 0.42) / 0.30) * (MAX_WEIGHT - MIN_WEIGHT);
  } else if (raw.trades > 0) {
    // Warm-start: Bayesian posterior drives weight, scaled by confidence
    let rawWeight: number;
    if (bayesianWR >= 0.72)      rawWeight = MAX_WEIGHT;
    else if (bayesianWR <= 0.42) rawWeight = MIN_WEIGHT;
    else                         rawWeight = MIN_WEIGHT + ((bayesianWR - 0.42) / 0.30) * (MAX_WEIGHT - MIN_WEIGHT);
    // Scale: 0 → 1.0 at 0 trades, full weight signal at MIN_TRADES_BEFORE_WEIGHT
    const confidence = raw.trades / MIN_TRADES_BEFORE_WEIGHT;
    weight = 1.0 + (rawWeight - 1.0) * confidence;
  }

  return { winRate, avgPnlCents: avgPnl, learningWeight: weight };
}

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Pooled realized win rate for a strategy across ALL duration buckets, or null
 * when the strategy has no trades in any bucket. Used to warm-start a new
 * duration bucket's prior (cold-start fallback) instead of assuming zero
 * evidence — the pooled estimate is a much better starting guess than the
 * generic library prior alone.
 */
function pooledWinRate(strategyId: string): number | null {
  const store = getStore();
  let wins = 0, trades = 0;
  for (const [k, rec] of Object.entries(store)) {
    if (parseKey(k).strategyId !== strategyId) continue;
    wins += rec.wins; trades += rec.trades;
  }
  return trades > 0 ? wins / trades : null;
}

/**
 * Record the outcome of a completed trade for a specific strategy.
 * Updates in-memory immediately; schedules an async disk write.
 *
 * @param priorWinRate - strategy's expectedWinRate from its definition.
 *   Stored on first call for a strategyId; subsequent calls may omit it.
 *   Used as the Bayesian Beta prior when fewer than 40 trades are recorded.
 * @param outcomeKey - durable ID for an authoritative source outcome (normally
 *   `bot_trades:<id>`). When repeated, this call is a no-op and returns false.
 *   Calls without a key retain the existing simulation/manual-record behavior.
 * @param exitClass - 'risk_exit' (THESIS_BREAK / LAG_FLIP / TIME_STOP / HOLD_HARD_FLOOR)
 *   still records the durable outcome key for idempotency but does NOT increment
 *   wins/losses/trades or push into recentResults that drive learningWeight.
 *   A 3s LAG_FLIP on LATE_ENTRY that then settled YES is a risk exit, not
 *   "LATE_ENTRY is dead". Default 'strategy'.
 */
export function recordOutcome(
  strategyId: string,
  won: boolean,
  pnlCents: number,
  priorWinRate = 0.65,
  durationMins?: number | null,
  outcomeKey?: string,
  exitClass: ExitClass = 'strategy',
): boolean {
  if (!strategyId) return false;
  const store = getStore();
  const duration = durationBucket(durationMins);
  const key = storeKey(strategyId, duration);
  const normalizedOutcomeKey = typeof outcomeKey === 'string' && outcomeKey.length > 0
    ? outcomeKey
    : null;

  // A strategy should only ever receive one result from one bot_trades row,
  // even if a faulty retry labels the same row with a different duration.
  // Search all duration buckets before mutating the target bucket so this
  // remains true across config migrations and restart recovery.
  if (normalizedOutcomeKey) {
    const alreadyRecorded = Object.entries(store).some(([storeRecordKey, record]) =>
      parseKey(storeRecordKey).strategyId === strategyId
      && Array.isArray(record.recordedOutcomeKeys)
      && record.recordedOutcomeKeys.includes(normalizedOutcomeKey),
    );
    if (alreadyRecorded) return false;
  }

  // ── Cold-start prior for a NEW duration bucket ────────────────────────────
  // If this strategy has rich history in OTHER durations but none in this one,
  // seed the Bayesian warm-start with the strategy's *pooled* realized win rate
  // (across all durations) instead of pretending it has zero evidence — but
  // widen the uncertainty by blending the pooled estimate halfway toward the
  // library prior. The virtual-trade Beta prior (PRIOR_STRENGTH=10 in derive)
  // then lets real per-duration outcomes override it quickly.
  let effectivePrior = priorWinRate;
  if (!store[key]) {
    const pooled = pooledWinRate(strategyId);
    if (pooled !== null) {
      // Widen uncertainty: halfway between pooled realized and the library prior.
      effectivePrior = pooled * 0.5 + priorWinRate * 0.5;
    }
    store[key] = {
      strategyId,
      duration,
      trades: 0, wins: 0, losses: 0,
      totalPnlCents: 0, avgPnlCents: 0,
      winRate: 0, learningWeight: 1.0,
      recentResults: [],
      lastUpdated: Date.now(),
      priorWinRate: effectivePrior,
    };
  }

  const s = store[key];
  if (s.duration === undefined) s.duration = duration;
  // Persist prior on first encounter; don't overwrite with the default on later calls
  if (s.priorWinRate === undefined || s.priorWinRate === null) s.priorWinRate = effectivePrior;
  if (normalizedOutcomeKey) {
    if (!Array.isArray(s.recordedOutcomeKeys)) s.recordedOutcomeKeys = [];
    s.recordedOutcomeKeys.push(normalizedOutcomeKey);
  }

  // Thesis-broken / time-stop / hold-floor: PnL lives on the trade row.
  // Do not punish (or reward) the strategy's winRate / learningWeight.
  if (exitClass === 'risk_exit') {
    s.lastUpdated = Date.now();
    scheduleWrite();
    return true;
  }

  s.trades++;
  if (won) s.wins++; else s.losses++;
  s.totalPnlCents += pnlCents;
  s.lastUpdated    = Date.now();

  if (!Array.isArray(s.recentResults)) s.recentResults = [];
  // Task #147/#152: only ever push a real boolean — a caller passing a
  // truthy/falsy non-boolean (e.g. from a loosely-typed call site) must not
  // silently pollute the array with a value sanitizeRecentResults() would
  // otherwise have to strip on the next load.
  if (typeof won === 'boolean') {
    s.recentResults.push(won);
  }
  if (s.recentResults.length > RECENT_RESULTS_CAP) s.recentResults.shift();

  const d           = derive(s, s.priorWinRate ?? 0.65);
  s.avgPnlCents     = d.avgPnlCents;
  s.winRate         = d.winRate;
  s.learningWeight  = d.learningWeight;

  scheduleWrite();
  return true;
}

/**
 * Returns a map of strategyId → confidence multiplier (MIN_WEIGHT–MAX_WEIGHT)
 * for the given contract duration. Strategies with
 * < MIN_TRADES_BEFORE_WEIGHT trades in that duration return 1.0 (no adjustment).
 *
 * When `durationMins` is omitted, returns the pooled/legacy behaviour: the
 * weight from whichever duration bucket has the most trades for each strategy.
 * The live tick loop passes the actual contract duration so 15m and 1h use
 * SEPARATE weights.
 */
export function getLearningWeights(durationMins?: number | null): Record<string, number> {
  const store = getStore();
  const weights: Record<string, number> = {};

  if (durationMins !== undefined && durationMins !== null) {
    const wantBucket = durationBucket(durationMins);
    for (const [k, s] of Object.entries(store)) {
      const { strategyId, duration } = parseKey(k);
      if (duration === wantBucket) weights[strategyId] = s.learningWeight;
    }
    return weights;
  }

  // Pooled/legacy: pick the most-traded bucket per strategy.
  const bestTrades: Record<string, number> = {};
  for (const [k, s] of Object.entries(store)) {
    const { strategyId } = parseKey(k);
    if (s.trades >= (bestTrades[strategyId] ?? -1)) {
      bestTrades[strategyId] = s.trades;
      weights[strategyId] = s.learningWeight;
    }
  }
  return weights;
}

/**
 * Learning weights sourced only from records that have at least one
 * `bot_trades:<id>` outcome key. Shadow / sim / manual-only rows are ignored
 * so autoMode adaptation cannot learn from non-BOT fills.
 */
export function getBotFillLearningWeights(durationMins?: number | null): Record<string, number> {
  const store = getStore();
  const weights: Record<string, number> = {};
  const wantBucket = durationMins !== undefined && durationMins !== null
    ? durationBucket(durationMins)
    : null;
  const bestTrades: Record<string, number> = {};
  for (const [k, rec] of Object.entries(store)) {
    const { strategyId, duration } = parseKey(k);
    if (wantBucket && duration !== wantBucket) continue;
    const keys = Array.isArray(rec.recordedOutcomeKeys) ? rec.recordedOutcomeKeys : [];
    if (!keys.some(id => typeof id === "string" && id.startsWith("bot_trades:"))) continue;
    if (wantBucket) {
      weights[strategyId] = rec.learningWeight;
      continue;
    }
    if (rec.trades >= (bestTrades[strategyId] ?? -1)) {
      bestTrades[strategyId] = rec.trades;
      weights[strategyId] = rec.learningWeight;
    }
  }
  return weights;
}

// ── Quarantine gate ──────────────────────────────────────────────────────────
// Uncertainty-aware underperformance check: a strategy is quarantined when its
// Wilson 95% lower-bound win rate is demonstrably below break-even quality.
// This blocks strategies like a 16/45 (35.6%) performer that a soft 0.72
// learning weight would keep trading.

const QUARANTINE_MIN_TRADES = 20;
const QUARANTINE_WILSON_LB  = 0.45;   // lower bound must clear this to keep trading
// A strategy can pass the win-rate gate above while still losing money on
// average — e.g. a 95% win rate at a rich entry price nets a tiny payout that
// the fee + spread eats into. That "high win rate, negative EV" pattern is
// invisible to a win-rate-only gate, so it also needs its own floor: once a
// strategy has a large-enough sample, its average P&L per trade must clear a
// small negative buffer (allows normal variance without ignoring a
// structural, sustained bleed).
const QUARANTINE_MIN_TRADES_FOR_PNL = 20;
const QUARANTINE_AVG_PNL_FLOOR_CENTS = -0.5;

/** Wilson score interval lower bound (z = 1.96). */
function wilsonLowerBound(wins: number, n: number): number {
  if (n <= 0) return 0;
  const z = 1.96, p = wins / n;
  const denom  = 1 + (z * z) / n;
  const center = p + (z * z) / (2 * n);
  const margin = z * Math.sqrt((p * (1 - p) + (z * z) / (4 * n)) / n);
  return (center - margin) / denom;
}

/**
 * Strategy IDs that should not open NEW trades: enough samples exist to say,
 * with 95% confidence, that the true win rate is below QUARANTINE_WILSON_LB —
 * or the strategy is deeply negative-P&L on a moderate sample.
 * A strategy exits quarantine automatically if recent results lift the bound.
 *
 * Now operates PER DURATION: a strategy can be quarantined on 1H (its 1H bucket
 * has enough evidence of underperformance) while still trading 15M. When
 * `durationMins` is provided, only that duration's bucket is evaluated. When
 * omitted (legacy callers / dual-run comparison), a strategy is returned if ANY
 * of its duration buckets is quarantined — the strictest, safest union.
 */
export function getQuarantinedStrategies(durationMins?: number | null): string[] {
  const store = getStore();
  const wantBucket = durationMins != null ? durationBucket(durationMins) : null;

  // Does one learning record independently earn a quarantine on its own stats?
  const recordQuarantined = (s: StrategyLearningRecord): boolean => {
    if (s.trades < QUARANTINE_MIN_TRADES) return false;
    // Weight recent form: judge on the last 30 results when available so a
    // strategy that recovers can un-quarantine itself.
    // Task #152: a hand-edited or disk-corrupted recentResults array can carry
    // non-boolean entries (e.g. a stray string/number/null from a bad JSON
    // edit). `.filter(Boolean)` would silently count any truthy garbage entry
    // as a WIN, and `.length` would count it as a resolved trade either way —
    // both distort the quarantine gate. Only real booleans count as evidence.
    const rawRecent = Array.isArray(s.recentResults) ? s.recentResults.slice(-30) : [];
    const recent = rawRecent.filter((r): r is boolean => typeof r === 'boolean');
    const n    = recent.length >= QUARANTINE_MIN_TRADES ? recent.length : s.trades;
    const wins = recent.length >= QUARANTINE_MIN_TRADES ? recent.filter(Boolean).length : s.wins;
    if (wilsonLowerBound(wins, n) < QUARANTINE_WILSON_LB && (wins / n) < 0.50) return true;
    // P&L floor: catches the inverse failure mode — a high win rate that
    // still bleeds money because entries are too rich for their payout
    // (fee + spread eats a thin win, and the strategy sails through the
    // win-rate gate above every time). Judged on lifetime avgPnlCents since
    // recentResults only tracks win/loss booleans, not per-trade P&L.
    if (s.trades >= QUARANTINE_MIN_TRADES_FOR_PNL && s.avgPnlCents < QUARANTINE_AVG_PNL_FLOOR_CENTS) return true;
    return false;
  };

  // A bucket "earns release" only with enough of its own evidence that clears
  // the policy — mirrors strategy-performance.ts. Below the sample floor we do
  // NOT trust an enabled call enough to lift an inherited pooled quarantine.
  const bucketEarnsRelease = (s: StrategyLearningRecord): boolean =>
    s.trades >= QUARANTINE_MIN_TRADES && !recordQuarantined(s);

  const out = new Set<string>();

  // ── Pooled-quarantine carry-forward (money-safety guard) ─────────────────
  // Aggregate every duration bucket for a strategy into pooled stats. If the
  // POOLED record independently quarantines the strategy, that block is carried
  // forward into the requested bucket UNLESS that bucket independently earns
  // release. The split may only ever ADD quarantines, never silently remove one
  // until per-bucket evidence exists. Fail CLOSED on ambiguity.
  const pooledByStrategy = new Map<string, StrategyLearningRecord>();
  const bucketByKey = new Map<string, StrategyLearningRecord>();
  for (const [k, s] of Object.entries(store)) {
    const { strategyId } = parseKey(k);
    bucketByKey.set(k, s);
    const acc = pooledByStrategy.get(strategyId);
    if (!acc) {
      pooledByStrategy.set(strategyId, {
        ...s,
        recentResults: Array.isArray(s.recentResults) ? [...s.recentResults] : [],
      });
    } else {
      acc.trades += s.trades;
      acc.wins   += s.wins;
      acc.losses += s.losses;
      acc.totalPnlCents += s.totalPnlCents;
      acc.avgPnlCents = acc.trades > 0 ? acc.totalPnlCents / acc.trades : 0;
      if (Array.isArray(s.recentResults)) acc.recentResults = acc.recentResults.concat(s.recentResults);
    }
  }

  const pooledQuarantined = new Set<string>();
  for (const [strategyId, pooled] of pooledByStrategy) {
    if (recordQuarantined(pooled)) pooledQuarantined.add(strategyId);
  }

  for (const [k, s] of Object.entries(store)) {
    const { strategyId, duration } = parseKey(k);
    if (wantBucket !== null && duration !== wantBucket) continue;

    // 1) Earned in this bucket → quarantine.
    if (recordQuarantined(s)) { out.add(strategyId); continue; }

    // 2) Inherited from pooled history → quarantine unless this bucket earned
    //    its own release.
    if (pooledQuarantined.has(strategyId) && !bucketEarnsRelease(s)) {
      out.add(strategyId);
    }
  }

  // 3) When a specific bucket is requested, a strategy quarantined on pooled
  //    history may have NO record in that bucket at all (never traded it).
  //    Fail closed: keep it quarantined until that bucket earns release.
  if (wantBucket !== null) {
    for (const strategyId of pooledQuarantined) {
      const bucketRec = bucketByKey.get(storeKey(strategyId, wantBucket));
      if (!bucketRec || !bucketEarnsRelease(bucketRec)) out.add(strategyId);
    }
  }

  return [...out];
}

/** Returns all learning records sorted by trade count descending. */
export function getAllStats(): StrategyLearningRecord[] {
  const store = getStore();
  return Object.values(store).sort((a, b) => b.trades - a.trades);
}

/**
 * Clear all learning data. Irreversible.
 *
 * Also re-runs the same reconcile-tracking pass getStore() performs on a true
 * cold start: resetLearning() is used both as a real "wipe everything" action
 * and as the standard test-suite fixture for "simulate a fresh boot in
 * memory". Without re-running reconcilePriorWinRates() here, getReconcileHealth()
 * would only ever reflect the process's very first getStore() call — stale
 * for every test/reset after the first one, and never exercised again in a
 * long-running process that calls resetLearning() (e.g. an admin "wipe
 * learning" action) after its initial boot already reconciled once.
 */
export function resetLearning() {
  _store = {};
  try {
    reconcilePriorWinRates(_store);
    _lastReconcileOk = true;
    _lastReconcileError = null;
  } catch (err) {
    _lastReconcileOk = false;
    _lastReconcileError = (err as Error).message;
    console.warn('[strategy-learner] reconcilePriorWinRates failed during resetLearning:', (err as Error).message);
  }
  _lastReconcileAt = Date.now();
  scheduleWrite();
}

// ── DB reconciliation ─────────────────────────────────────────────────────────
// The JSON learning store and the bot_trades table are two independent write
// paths (recordOutcome() above vs. the DB update in trading-bot.ts's
// recordSettlement()). They can drift apart — e.g. a strategy can accumulate
// wins/losses here with zero matching rows in bot_trades if trades were ever
// recorded before the DB write landed, or if bot_trades was pruned/reset
// independently of this file. A record with trades > 0 here but 0 settled
// rows in the DB is unverifiable against the source of truth and should not
// silently keep steering live confidence (learningWeight, quarantine checks).
//
// This does NOT try to fully reconcile partial mismatches (legacy trades
// predating strategy_id tracking make exact counts unrecoverable) — it only
// resets records that have zero corroborating DB evidence at all, which is
// unambiguous.

export interface ReconciliationResult {
  strategyId: string;
  storeTrades: number;
  dbTrades: number;
  action: "reset" | "flagged" | "ok";
}

/**
 * Compares each learning-store record's trade count against the number of
 * settled (win/loss) bot_trades rows for that strategyId. Call once at
 * startup with counts already queried from the DB.
 *
 * - storeTrades > 0 and dbTrades === 0 → phantom record, reset to neutral
 *   (trades/wins/losses/recentResults cleared, learningWeight back to 1.0).
 *   The priorWinRate is preserved so the next real trade still warm-starts
 *   correctly.
 * - storeTrades > dbTrades (partial mismatch) → flagged only (logged), not
 *   auto-modified, since legacy pre-tracking trades can legitimately explain
 *   some gap.
 */
export function reconcileAgainstTradeLog(dbTradeCountsByStrategy: Record<string, number>): ReconciliationResult[] {
  const store = getStore();
  const results: ReconciliationResult[] = [];
  let changed = false;

  // The store is now keyed per (strategyId, duration), but the DB counts passed
  // in are keyed by bare strategyId (aggregated across durations). Compare each
  // duration bucket's trade count against the strategy's TOTAL DB count: a
  // bucket is only a phantom if the strategy has zero DB rows at all. This
  // avoids falsely resetting a real 1H bucket just because the count was
  // aggregated across durations upstream.
  for (const [key, record] of Object.entries(store)) {
    const { strategyId: id } = parseKey(key);
    const dbTrades = dbTradeCountsByStrategy[id] ?? 0;
    if (record.trades > 0 && dbTrades === 0) {
      console.warn(
        `[strategy-learner] PHANTOM RECORD: ${key} has ${record.trades} trades ` +
        `(${record.wins}W/${record.losses}L, weight ${record.learningWeight}) in the ` +
        `learning store but 0 matching rows in bot_trades — resetting to neutral. ` +
        `This record was influencing live strategy confidence without any auditable trade evidence.`
      );
      record.trades = 0;
      record.wins = 0;
      record.losses = 0;
      record.totalPnlCents = 0;
      record.avgPnlCents = 0;
      record.winRate = 0;
      record.learningWeight = 1.0;
      record.recentResults = [];
      record.lastUpdated = Date.now();
      changed = true;
      results.push({ strategyId: id, storeTrades: 0, dbTrades, action: "reset" });
    } else if (record.trades > dbTrades) {
      results.push({ strategyId: id, storeTrades: record.trades, dbTrades, action: "flagged" });
    } else {
      results.push({ strategyId: id, storeTrades: record.trades, dbTrades, action: "ok" });
    }
  }

  if (changed) scheduleWrite();
  return results;
}
