import assert from "node:assert/strict";
import test from "node:test";
import { updateRollingBasis, estimateFairBRTI, projectSettlementPrice, basisTracker, isRecentBasisSignFlip, BasisTracker } from "./basis-tracker.js";

test("updateRollingBasis seeds from the first sample and then EWMA-blends", () => {
  const seeded = updateRollingBasis(null, 100, 90, 1000);
  assert.equal(seeded, 10);
  const blended = updateRollingBasis(10, 100, 80, 1000, 5 * 60_000);
  assert.ok(blended > 10 && blended < 20, `expected partial blend toward 20, got ${blended}`);
});

test("estimateFairBRTI subtracts the smoothed basis from the exchange price", () => {
  assert.equal(estimateFairBRTI(63500, 12), 63488);
});

test("projectSettlementPrice caps a large velocity extrapolation to a bounded % of fair BRTI", () => {
  const fairBRTI = 63400;
  // A noisy velocity reading (-113 $/min) stretched over ~14 minutes would
  // move the naive estimate by ~$790 (2026-08-04 settlement-predictor bug) —
  // the cap must keep the projection close to fairBRTI instead.
  const projected = projectSettlementPrice(fairBRTI, -113, 14 * 60);
  const cap = fairBRTI * (0.35 / 100);
  assert.ok(fairBRTI - projected <= cap + 0.01, `expected capped adjustment <= $${cap.toFixed(2)}, got $${(fairBRTI - projected).toFixed(2)}`);
});

test("projectSettlementPrice barely adjusts for small velocity or little time remaining", () => {
  const fairBRTI = 63400;
  const projected = projectSettlementPrice(fairBRTI, -5, 30);
  assert.ok(Math.abs(projected - fairBRTI) < 5, `expected a tiny adjustment, got ${projected - fairBRTI}`);
});

test("isRecentBasisSignFlip is true just inside the window and false just outside it", () => {
  const now = 1_000_000;
  assert.equal(isRecentBasisSignFlip({ signFlippedAt: now - 5_000 }, 12_000, now), true);
  assert.equal(isRecentBasisSignFlip({ signFlippedAt: now - 12_000 }, 12_000, now), true);
  assert.equal(isRecentBasisSignFlip({ signFlippedAt: now - 12_001 }, 12_000, now), false);
});

test("isRecentBasisSignFlip is false when no flip has ever been recorded", () => {
  assert.equal(isRecentBasisSignFlip({ signFlippedAt: null }, 12_000), false);
});

test("isFairValueStale() fails closed before the tracker has ever received an update", () => {
  // Mirrors trading-bot.ts's isBalanceStale(): with no data yet, staleness
  // must default to true, not silently pass a null/undefined fair value
  // through as if it were fresh.
  assert.equal(basisTracker.isFairValueStale(), true);
  const s = basisTracker.getState();
  assert.equal(s.estimatedFairBRTI, null);
  assert.equal(s.lagSeconds, null);
  assert.equal(s.lagDollars, null);
  assert.equal(s.lagCorr, null);
  assert.equal(s.lagStale, true);
  assert.equal(s.lagSampleN, 0);
  assert.equal(s.lagResidualDollars, null);
  assert.equal(s.lagProven, false);
  assert.equal(s.leaderName, null);
});

const T0 = 1_724_000_000_000;

function lcg(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}

function randomWalkPrices(n: number, start: number, seed: number): number[] {
  const rng = lcg(seed);
  const px: number[] = [];
  let p = start;
  for (let i = 0; i < n; i++) {
    p += (rng() - 0.5) * 24;
    px.push(p);
  }
  return px;
}

function quoteAt(clock: { nowMs: number }, coinbase: number[], t0: number): number {
  const idx = Math.round((clock.nowMs - t0) / 1000);
  const px = coinbase[idx];
  if (px == null) throw new Error(`no coinbase sample at idx ${idx}`);
  return px;
}

function makeTracker(clock: { nowMs: number }, coinbase: number[]): BasisTracker {
  return new BasisTracker({
    now: () => clock.nowMs,
    fetchQuote: async () => ({ price: quoteAt(clock, coinbase, T0), source: "coinbase" }),
  });
}

async function tickTrackerThrough(
  tracker: BasisTracker,
  coinbase: number[],
  lagSec: number,
  t0: number,
  clock: { nowMs: number },
): Promise<ReturnType<BasisTracker["getState"]>> {
  let last = tracker.getState();
  for (let i = lagSec; i < coinbase.length; i++) {
    clock.nowMs = t0 + i * 1000;
    last = await tracker.tick({
      brtiProxy: coinbase[i - lagSec],
      floorStrike: 80_000,
      velocityPerMin: 0,
      secsRemaining: 600,
    });
  }
  return last;
}

test("lag fields are stale/null until the 1s ring has enough samples", async () => {
  const clock = { nowMs: T0 };
  const coinbase = randomWalkPrices(20, 80_000, 42);
  const tracker = makeTracker(clock, coinbase);
  for (let i = 0; i < coinbase.length; i++) {
    clock.nowMs = T0 + i * 1000;
    await tracker.tick({
      brtiProxy: coinbase[i],
      floorStrike: 80_000,
      velocityPerMin: 0,
      secsRemaining: 600,
    });
  }
  const s = tracker.getState();
  assert.equal(s.lagStale, true);
  assert.equal(s.lagSeconds, null);
  assert.ok(s.lagSampleN < 60, `expected short n, got ${s.lagSampleN}`);
});

test("synthetic 8s delay through the tracker ring → lagSeconds ~8, lagStale false", async () => {
  const lagSec = 8;
  const n = 180;
  const clock = { nowMs: T0 };
  const coinbase = randomWalkPrices(n, 80_000, 42);
  const tracker = makeTracker(clock, coinbase);
  const s = await tickTrackerThrough(tracker, coinbase, lagSec, T0, clock);
  assert.equal(s.lagStale, false, s.lagReason);
  assert.equal(s.lagReason, "ok");
  assert.ok(s.lagSeconds != null, "lagSeconds should be set");
  assert.ok(Math.abs(s.lagSeconds! - 8) <= 1, `expected ~8s, got ${s.lagSeconds}`);
  assert.ok(s.lagCorr != null && s.lagCorr >= 0.25, `corr ${s.lagCorr}`);
  assert.ok(s.lagSampleN >= 60, `lagSampleN ${s.lagSampleN}`);
  assert.ok(s.lagDollars != null, "lagDollars should be set");
  // fairBRTI / projectedSettlement formulas unchanged: still exchange − rollingBasis.
  assert.ok(s.exchangePrice != null && s.rollingBasis != null);
  assert.equal(s.estimatedFairBRTI, s.exchangePrice! - s.rollingBasis!);
  assert.ok(s.projectedSettlementPrice != null);
});

test("isFairValueStale fail-closes lagSeconds even after a live lag reading", async () => {
  const lagSec = 8;
  const n = 180;
  const clock = { nowMs: T0 };
  const coinbase = randomWalkPrices(n, 80_000, 42);
  const tracker = makeTracker(clock, coinbase);
  const live = await tickTrackerThrough(tracker, coinbase, lagSec, T0, clock);
  assert.equal(live.lagStale, false, live.lagReason);
  assert.ok(live.lagSeconds != null);

  clock.nowMs += 46_000;
  assert.equal(tracker.isFairValueStale(), true);
  const s = tracker.getState();
  assert.equal(s.lagStale, true);
  assert.equal(s.lagProven, false, "never invent lagProven=true when Coinbase/fair-value aged out");
  assert.equal(s.lagSeconds, live.lagSeconds, "last-observed tau stays visible");
  assert.equal(s.lagDollars, live.lagDollars, "last-observed lag$ stays visible, marked STALE — not a fake mid");
  assert.ok(s.coinbaseAgeMs != null && s.coinbaseAgeMs >= 46_000);
  assert.equal(s.lagCorr, live.lagCorr);
  // Fair-value numbers stay on the last tick; staleness is the caller-visible flag.
  assert.equal(s.estimatedFairBRTI, live.estimatedFairBRTI);
});

test("Coinbase die: last-good lag kept, marked STALE immediately, no invented mid", async () => {
  const lagSec = 8;
  const n = 180;
  const clock = { nowMs: T0 };
  const coinbase = randomWalkPrices(n, 80_000, 42);
  let liveQuotes = true;
  const tracker = new BasisTracker({
    now: () => clock.nowMs,
    fetchQuote: async () => {
      if (!liveQuotes) return null;
      return { price: quoteAt(clock, coinbase, T0), source: "coinbase" };
    },
  });
  const live = await tickTrackerThrough(tracker, coinbase, lagSec, T0, clock);
  assert.equal(live.lagStale, false, live.lagReason);
  assert.ok(live.lagDollars != null);

  liveQuotes = false;
  clock.nowMs += 1_000;
  const dead = await tracker.tick({
    brtiProxy: coinbase[coinbase.length - 1 - lagSec],
    floorStrike: 80_000,
    velocityPerMin: 0,
    secsRemaining: 600,
  });
  assert.equal(dead.lagStale, true);
  assert.equal(dead.lagProven, false, "Coinbase die must not keep lagProven=true");
  assert.match(dead.lagReason, /coinbase_stale|coinbase_missing/);
  assert.equal(dead.lagDollars, live.lagDollars);
  assert.equal(dead.lagSeconds, live.lagSeconds);
  assert.equal(dead.exchangePrice, live.exchangePrice);
  assert.ok(dead.coinbaseAgeMs != null && dead.coinbaseAgeMs >= 1_000);
});

test("non-Coinbase quote does not un-stale lag or invent a Coinbase print", async () => {
  const clock = { nowMs: T0 };
  const tracker = new BasisTracker({
    now: () => clock.nowMs,
    fetchQuote: async () => ({ price: 81_000, source: "binance" }),
  });
  const s = await tracker.tick({
    brtiProxy: 80_000,
    floorStrike: 80_000,
    velocityPerMin: 0,
    secsRemaining: 600,
  });
  assert.equal(s.lagStale, true);
  assert.equal(s.coinbaseObservedAt, null);
  assert.equal(s.lagDollars, null);
});

test("missing leader → lagProven false (never invent)", async () => {
  const clock = { nowMs: T0 };
  const tracker = new BasisTracker({
    now: () => clock.nowMs,
    fetchQuote: async () => null,
  });
  const s = await tracker.tick({
    brtiProxy: 80_000,
    floorStrike: 80_000,
    velocityPerMin: 0,
    secsRemaining: 600,
    quoteTs: T0,
  });
  assert.equal(s.lagProven, false);
  assert.equal(s.lagStale, true);
  assert.equal(s.lagDollars, null);
  assert.match(s.lagReason, /coinbase_missing/);
});

test("fresh Coinbase vs lagged Kalshi can set lagProven true", async () => {
  const clock = { nowMs: T0 };
  let px = 80_000;
  const coinbase: number[] = [];
  for (let i = 0; i < 140; i++) {
    if (i > 0 && i % 10 === 0) px += 40;
    coinbase.push(px);
  }
  const lagSec = 8;
  const tracker = new BasisTracker({
    now: () => clock.nowMs,
    fetchQuote: async () => ({ price: quoteAt(clock, coinbase, T0), source: "coinbase" }),
  });
  const s = await tickTrackerThrough(tracker, coinbase, lagSec, T0, clock);
  assert.equal(s.lagProven, true, `expected proven, reason=${s.lagReason} hit=${s.proofHitRate}`);
  assert.equal(s.leaderName, "coinbase");
  assert.ok(s.coinbaseObservedAt != null);
  assert.ok(s.coinbaseAgeMs != null && s.coinbaseAgeMs < 2_000);
});

test("aged Coinbase or aged Kalshi quoteTs → lagProven false", async () => {
  const clock = { nowMs: T0 };
  let px = 80_000;
  const coinbase: number[] = [];
  for (let i = 0; i < 140; i++) {
    if (i > 0 && i % 10 === 0) px += 40;
    coinbase.push(px);
  }
  const lagSec = 8;
  const tracker = new BasisTracker({
    now: () => clock.nowMs,
    fetchQuote: async () => ({ price: quoteAt(clock, coinbase, T0), source: "coinbase" }),
  });
  const live = await tickTrackerThrough(tracker, coinbase, lagSec, T0, clock);
  assert.equal(live.lagProven, true, live.lagReason);

  clock.nowMs += 46_000;
  const agedLead = tracker.getState();
  assert.equal(agedLead.lagProven, false, "aged Coinbase must not keep lagProven=true");
  assert.equal(agedLead.lagStale, true);

  clock.nowMs = T0 + (coinbase.length - 1) * 1000;
  const still = await tracker.tick({
    brtiProxy: coinbase[coinbase.length - 1 - lagSec],
    floorStrike: 80_000,
    velocityPerMin: 0,
    secsRemaining: 600,
    quoteTs: clock.nowMs,
  });
  assert.equal(still.lagProven, true, still.lagReason);

  const staleBook = await tracker.tick({
    brtiProxy: coinbase[coinbase.length - 1 - lagSec],
    floorStrike: 80_000,
    velocityPerMin: 0,
    secsRemaining: 600,
    quoteTs: clock.nowMs - 20_000,
  });
  assert.equal(staleBook.lagProven, false, "stale Kalshi quoteTs must clear lagProven");
  assert.equal(staleBook.lagStale, true);
  assert.equal(staleBook.exchangePrice, still.exchangePrice, "last Coinbase print stays visible");
});
