/**
 * Admission math — EV floors, PATH_GATE wrappers, Kelly, 9%/18% hard risk limits.
 *
 * Extracted from trading-bot.ts so TradingBot is a caller, not the home of
 * these protected invariants. Numeric floors are unchanged:
 *   EV_FLOOR 3¢, OTM_EV_FLOOR 5¢, PATH MULTIPLIER 7¢ (trade-path.ts),
 *   maxRiskPctPerTrade 9%, maxDailyLossPct 18%,
 *   fractional Kelly 0.60 cap, b from fee-net, p = winRateAtPrice (same as PATH_GATE).
 *   Wilson/uMult shrink f* or size only — never replace p. No 0.50 floor on p.
 *
 * PATH_GATE's own implementation (evaluatePathDecision / passesPathEVGate /
 * computeTradeEV) still lives in trade-path.ts; this module is the
 * trading-bot-facing wrapper layer plus the final entry EV gate and Kelly.
 */
import { computeTradeEV, evaluatePathDecision, passesPathEVGate, getPathConfig } from "./trade-path.js";
import { kalshiNetCostCents, kalshiNetWinCents } from "./constants.js";
import type { StrategyObservation, ChannelInfo, StrategyId } from "./strategy-library.js";
import { getStrategy, getAllStrategyMeta, FILL_PATH_PLACE_FALSE_STRATEGY_IDS } from "./strategy-library.js";
import type { GrokRegime } from "./regime-engine.js";
import type { VolumeBucket } from "./volume-risk.js";
import {
  decideSettlementSideLogged,
  paperMoneyMakerLagMinAbsDollars,
  paperPathRidePreservesThroughSettlementSkip,
  isMoneyMakerStrategyId,
  mtfAlignedCheapWantSignal,
} from "./settlement-side.js";
import { pathPWinFromCurveOrLearner, getLearnerPathWinRateSample } from "./strategy-learner.js";
import { getLiveTradeStatsSync } from "./strategy-performance.js";
export { computeTradeEV, evaluatePathDecision, passesPathEVGate, getPathConfig };

// ── Hard risk limits ──────────────────────────────────────────────────────────
// Absolute safety net applied before every order, regardless of what Kelly or
// tiered sizing computed. Protects an account from:
//   1. A single trade exceeding 9% of equity — the sole per-trade ceiling
//   2. 18% daily drawdown — halt further entries for the day
//
// Previously this also enforced a flat $2.50 absolute-dollar cap and a hard
// 1-contract ceiling below a $45 balance. Both were fixed-dollar/fixed-count
// floors that didn't scale with equity: the $2.50 cap silently became the
// *binding* constraint (not the 9% rule) for any account above ~$28, capping
// a $10,000 account to the same ~4 contracts as a $30 one — and the 1-contract
// floor forced every account under $45 to size 1 contract regardless of what
// Kelly/win-rate/edge actually justified, effectively disabling Kelly sizing
// at small balances entirely. Both are now removed in favor of the single
// percentage-of-equity cap below (maxByPct), which scales correctly at any
// account size by construction — a $10 account and a $10,000 account both get
// floor(balance × 9% / cost-per-contract), just at different absolute counts.
// PROTECTED INVARIANT (see risk-invariants.test.ts): these two ratios, the
// PATH_CONFIGS EV floors in trade-path.ts, and the standard/OTM EV_FLOOR
// constants below are the trading system's hard risk ceiling. They must
// never be loosened silently — any change here requires a deliberate,
// reviewed update to risk-invariants.test.ts in the same change.
export const HARD_RISK_LIMITS = {
  maxRiskPctPerTrade: 0.09,   // 9% of equity max risk per trade — governs every account size
  maxDailyLossPct:    0.18,   // daily halt trigger (% of current balance)
} as const;

// PROTECTED INVARIANT (see risk-invariants.test.ts): fee-adjusted EV floors,
// in cents per contract. Standard strategies must clear EV_FLOOR; OTM/deep-
// probability-model plays must clear the higher OTM_EV_FLOOR.
export const EV_FLOOR = 3;      // ¢ minimum expected value per contract (standard strategies)
export const OTM_EV_FLOOR = 5;  // ¢ minimum expected value per contract (OTM / deep-probability-model plays)

export const MIN_EDGE_OVER_MARKET = 0.05; // minimum OTM strategy edge over market-implied probability

// ── Regime-conditional EV scorer (Grok upgrade #1) ────────────────────────────
// Computes expected value of a strategy in the current regime.
// Used as a post-hoc filter: even a high-confidence signal is skipped when
// the regime is structurally hostile to that strategy's edge.

export function scoreStrategyEV(
  r: { strategyId: string },
  obs: { secsRemaining: number; velocityDolPerMin: number; spreadCents?: number },
  entryPriceCents: number,
  calibratedWinRate: number,
): number {
  // Confidence is a signal score, not a probability.  The regime filter must
  // use the same calibrated win rate and fee/slippage-aware cents EV as the
  // downstream path gate and sizing code.
  return computeTradeEV({
    entryPriceCents,
    winRate: calibratedWinRate,
    strategyId: r.strategyId,
    secsRemaining: obs.secsRemaining,
    velocityDolPerMin: obs.velocityDolPerMin,
    spreadCents: obs.spreadCents,
  }).netEV;
}

// ── EV floor gate (legacy ratio API) ──────────────────────────────────────────
// Returns fee-net EV as a ratio (netEV¢ / totalCost¢) for historical call sites
// that compare to 0.03. The cents lock is EV_FLOOR=3¢ (evaluateEntryEVGate /
// organs/edge / sizePathRide) — never cut below 3. Ratio 0.03 is NOT a floor cut;
// for money-path asks it is weaker than 3¢, so cents EV_FLOOR remains binding.
//
// Task #397: takes a calibrated win-rate estimate (winRateAtPrice()/
// expectedWinRate) directly rather than deriving one from raw signal
// confidence. Confidence is a meta-labeled 0-100 heuristic score (regime/
// velocity/MTF adjustments stacked on top of a strategy's base signal) — it
// is not itself a probability of winning, and PATH_GATE / Kelly sizing never
// treat it as one downstream. Both call sites now pass the same
// winRateAtPrice-resolved number those other consumers use for this exact
// trade, so a trade can no longer pass PATH_GATE's EV floor on one win-rate
// number while this earlier gate blocks (or wrongly approves) it using a
// different one.
export function estimateTradeEV(
  winRate:         number,   // 0–1 calibrated win-rate estimate (NOT raw confidence)
  entryPriceCents: number,
  strategyId:      string,
): number {
  // Delegates to the same computeTradeEV() used by PATH_GATE's
  // passesPathEVGate(), so the two checks can no longer diverge on fee/
  // slippage math. Fee + slippage-aware economics: total cost per contract
  // includes the Kalshi taker fee and expected entry slippage. A win nets
  // 100¢ minus the total cost; a loss forfeits the total cost (entry fee is
  // not refunded). strategyId enables the same strategy-family EV discounts
  // this function always applied — unchanged behavior, just centralized.
  const { netEV, totalFriction } = computeTradeEV({ entryPriceCents, winRate, strategyId });
  const totalCost = entryPriceCents + totalFriction;
  if (totalCost <= 0 || totalCost >= 100) return -1;
  // Normalize the cents-denominated netEV into the historical "EV per $1
  // risked" ratio scale, so the existing `< 0.03` floor at both call sites
  // keeps meaning exactly what it used to.
  return netEV / totalCost;
}

export type EntryEVGateCode = "OTM_EV_NO_EDGE" | "OTM_EV_FLOOR" | "EV_FLOOR";

export interface EntryEVGateResult {
  passes: boolean;
  code?: EntryEVGateCode;
  isOTMPlay: boolean;
  modelEstimatedProb: number;
  marketImpliedProb: number | null;
  minEVCents: number;
  netEV: number | null;
  evResult: ReturnType<typeof computeTradeEV> | null;
}

/**
 * Pure shared implementation of the final fee/slippage-aware EV gate used by
 * _placeOrderBody(). Keeping the OTM edge comparison here makes its inclusive
 * boundary explicit: win-rate equal to market probability + 5pp is not a real
 * edge and must be rejected.
 *
 * `strategyId` is included as a defensive fallback for callers that do not
 * thread the legacy boolean flags. The flags remain supported because the
 * normal 15m/hourly callers already compute them before reaching placeOrder.
 *
 * PATH_GATE wrapper: same p = strategyWinRate (winRateAtPrice). calibratedWinRate
 * is ignored so a massAboveFloor / N(d2) swap cannot inflate a rich ask.
 */
export function evaluateEntryEVGate(opts: {
  entryPriceCents: number;
  strategyWinRate: number;
  calibratedWinRate?: number;
  strategyId?: string;
  isOTMAsymmetry?: boolean;
  isOTMExpansion?: boolean;
  secsRemaining?: number;
  velocityDolPerMin?: number;
  spreadCents?: number;
  /** Observed live fill cost after the session quality guard trips. */
  observedSlippageCents?: number;
  /** D13 — real order size for the exact whole-order fee (floor unchanged). */
  contracts?: number;
}): EntryEVGateResult {
  const isOTMStrategy = opts.strategyId === "OTM_ASYMMETRY"
    || opts.strategyId === "OTM_BREAKOUT_EXPANSION"
    || opts.strategyId === "DEEP_OTM_SNIPER";
  const isOTMPlay = Boolean(opts.isOTMAsymmetry || opts.isOTMExpansion || isOTMStrategy);
  // calibratedWinRate is ignored. PATH_GATE and this final gate must share
  // the same p = strategyWinRate (winRateAtPrice). A massAboveFloor / N(d2)
  // settlement-hold swap must never inflate p to pass a rich ask.
  const modelEstimatedProb = opts.strategyWinRate;
  const marketImpliedProb = isOTMPlay ? opts.entryPriceCents / 100 : null;
  const minEVCents = isOTMPlay ? OTM_EV_FLOOR : EV_FLOOR;

  // Compare whole basis points rather than decimal floats. Values such as
  // 0.17 and 0.12 + 0.05 are not represented exactly in IEEE-754, which can
  // otherwise allow an exact 5pp boundary through this inclusive no-edge
  // rejection. Model priors are rounded to the nearest basis point (0.01pp);
  // an edge smaller than that reporting precision is deliberately treated as
  // no edge.
  const modelProbabilityBps = Math.round(modelEstimatedProb * 10_000);
  const minimumOtmProbabilityBps = opts.entryPriceCents * 100 + MIN_EDGE_OVER_MARKET * 10_000;

  if (isOTMPlay && modelProbabilityBps <= minimumOtmProbabilityBps) {
    return {
      passes: false,
      code: "OTM_EV_NO_EDGE",
      isOTMPlay,
      modelEstimatedProb,
      marketImpliedProb,
      minEVCents,
      netEV: null,
      evResult: null,
    };
  }

  const evResult = computeTradeEV({
    entryPriceCents: opts.entryPriceCents,
    winRate: modelEstimatedProb,
    strategyId: opts.strategyId,
    secsRemaining: opts.secsRemaining,
    velocityDolPerMin: opts.velocityDolPerMin,
    spreadCents: opts.spreadCents,
    observedSlippageCents: opts.observedSlippageCents,
    minEVCents,
    contracts: opts.contracts,
  });

  return {
    passes: evResult.passes,
    code: evResult.passes ? undefined : (isOTMPlay ? "OTM_EV_FLOOR" : "EV_FLOOR"),
    isOTMPlay,
    modelEstimatedProb,
    marketImpliedProb,
    minEVCents,
    netEV: evResult.netEV,
    evResult,
  };
}

// ── 9% per-trade / 18% day-halt (single source; TradingBot is a caller) ─────
export function applyHardRiskLimits(
  balanceCents:     number,
  entryPriceCents:  number,
  desiredContracts: number,
  todayPnlCents:    number,
): number {
  // Invalid numeric state is not permission to size. Return a finite zero so
  // callers cannot accidentally ignore a NaN ceiling (e.g. sizePathRide).
  if (![balanceCents, entryPriceCents, desiredContracts, todayPnlCents].every(Number.isFinite)
      || balanceCents <= 0 || balanceCents > Number.MAX_SAFE_INTEGER
      || entryPriceCents <= 0 || entryPriceCents >= 100
      || desiredContracts < 0 || desiredContracts > Number.MAX_SAFE_INTEGER
      || Math.abs(todayPnlCents) > Number.MAX_SAFE_INTEGER) {
    return 0;
  }
  // Daily loss circuit breaker — existing threshold unchanged.
  if (balanceCents > 0 && todayPnlCents <= -(balanceCents * HARD_RISK_LIMITS.maxDailyLossPct)) {
    return 0;
  }
  // Capital at risk per contract = entry price PLUS the unavoidable taker fee
  // (kalshiNetCostCents). Caps computed on bare entry understate true risk by
  // the fee — e.g. a "9%" cap at 50¢ is really 9.6% (risk critic #4).
  const entry = Math.ceil(kalshiNetCostCents(Math.max(1, entryPriceCents)));
  // Percentage-of-equity cap — the sole ceiling, scales correctly at any balance.
  const maxByPct = Math.floor((balanceCents * HARD_RISK_LIMITS.maxRiskPctPerTrade) / entry);
  return Math.max(0, Math.min(Math.floor(desiredContracts), maxByPct));
}

/**
 * Same 9%/18% invariants as a fresh entry, applied to existing + add notional.
 * A scale-in cannot push cumulative exposure past what applyHardRiskLimits
 * would allow a brand-new entry.
 */
export function canScaleIntoPosition(opts: {
  balanceCents:          number;
  todayPnlCents:         number;
  existingContracts:     number;
  existingEntryPriceCents: number;
  addContracts:          number;
  addPriceCents:         number;
}): boolean {
  const { balanceCents, todayPnlCents, existingContracts, existingEntryPriceCents, addContracts, addPriceCents } = opts;
  if (![balanceCents, todayPnlCents, existingEntryPriceCents, addPriceCents].every(Number.isFinite)
      || balanceCents <= 0 || balanceCents > Number.MAX_SAFE_INTEGER
      || Math.abs(todayPnlCents) > Number.MAX_SAFE_INTEGER
      || !Number.isSafeInteger(existingContracts) || existingContracts < 0
      || !Number.isSafeInteger(addContracts) || addContracts <= 0
      || existingEntryPriceCents <= 0 || existingEntryPriceCents >= 100
      || addPriceCents <= 0 || addPriceCents >= 100) {
    return false;
  }
  if (balanceCents > 0 && todayPnlCents <= -(balanceCents * HARD_RISK_LIMITS.maxDailyLossPct)) {
    return false;
  }
  if (balanceCents <= 0) return false;
  const existingCostCents = existingContracts * Math.ceil(kalshiNetCostCents(Math.max(1, existingEntryPriceCents)));
  const addCostCents      = addContracts * Math.ceil(kalshiNetCostCents(Math.max(1, addPriceCents)));
  const cumulativeCostCents = existingCostCents + addCostCents;
  const capCents = balanceCents * HARD_RISK_LIMITS.maxRiskPctPerTrade;
  return cumulativeCostCents <= capCents;
}

// ── Kelly sizing (pure math; TradingBot is a caller) ─────────────────────────
// Fractional Kelly with a 0.60 cap. b is fee-net (kalshiNetWin / kalshiNetCost).
// p is winRateAtPrice / strategyWinRate — the SAME p PATH_GATE / evaluateEntryEVGate
// used for this ticket. Wilson-clamped pSizeClamped and uMult shrink f* or size
// only; they never replace p. Do not invent a 0.50 floor on p. Do not substitute
// raw confidence or a massAboveFloor swap.
export interface SizingResult {
  contracts: number;
  /** "NONE" when not the binding constraint on the final count. */
  limiter: string;
  /** Human-readable breakdown of the inputs that produced `contracts`. */
  detail: string;
  uMult?: number;
}

export interface KellyContractsInput {
  /**
   * winRateAtPrice / strategyWinRate used at PATH_GATE / evaluateEntryEVGate
   * for this ticket. Kelly f* = p − (1−p)/b uses this p when provided.
   * Wilson-clamped pSizeClamped must never replace it.
   */
  pWin?: number;
  /**
   * Wilson / prior-clamped p. Shrink-only via uMult on size — never Kelly p
   * when pWin is present. Fallback only if pWin is omitted (legacy callers).
   */
  pSizeClamped: number;
  entryPriceCents: number;
  confidence: number;
  edge: number;
  balanceCents: number;
  maxContracts: number;
  uMult: number;
  volumeSizeMult?: number;
  packSizeCapMult?: number;
  /** Canonical shrink-only Kelly sizing multiplier. */
  guardrail?: number;
  /** Legacy serialized spelling, retained for backwards compatibility. */
  guardfactor?: number;
}

/** Fee-net payout ratio b = net_win / net_cost, capped at 4.5× (OTM oversize guard).
 *  Invalid / no-edge books (cost≤0, win≤0, entry∉(0,100)) return b=0 so Kelly sizes 0
 *  instead of dividing by zero or flipping the sign into an oversize f*.
 */
export function kellyPayoutRatio(entryPriceCents: number): number {
  if (!(entryPriceCents > 0) || !(entryPriceCents < 100)) return 0;
  const cost = kalshiNetCostCents(entryPriceCents);
  const win = kalshiNetWinCents(entryPriceCents);
  if (!(cost > 0) || !(win > 0) || !Number.isFinite(cost) || !Number.isFinite(win)) return 0;
  return Math.min(4.5, win / cost);
}

/** Kelly edge f = p − (1−p)/b. Identical to the previous in-bot `p - q / b`.
 *  Non-finite / non-positive b → 0 (never Inf/NaN oversize).
 */
export function computeKellyEdge(p: number, b: number): number {
  if (!(b > 0) || !Number.isFinite(b) || !Number.isFinite(p)) return 0;
  return p - (1 - p) / b;
}

/**
 * Conviction-scaled fractional Kelly. Cap is 0.60 (never full Kelly).
 *   conf≥80 and edge≥8 → 0.60
 *   conf≥70 and edge≥5 → 0.50
 *   else               → 0.40
 */

/**
 * PAPER DESK v2: Kelly λ from netEV bands (NOT confidence).
 *   3→0.40 / 5→0.50 / 8→0.60. Below EV_FLOOR → 0.
 */
export function kellyLambdaFromNetEV(netEV: number): number {
  if (!(Number.isFinite(netEV)) || netEV < EV_FLOOR) return 0;
  if (netEV >= 8) return 0.60;
  if (netEV >= 5) return 0.50;
  return 0.40;
}

export function kellyFraction(confidence: number, edge: number): number {
  // When edge is fee-net EV cents (≥3), prefer netEV bands (PAPER DESK v2).
  // Legacy confidence×edge path kept for callers that pass conf pts + edge pts.
  if (Number.isFinite(edge) && edge >= EV_FLOOR && edge < 100 && !(confidence >= 70)) {
    const fromEv = kellyLambdaFromNetEV(edge);
    if (fromEv > 0) return fromEv;
  }
  return (confidence >= 80 && edge >= 8) ? 0.60
       : (confidence >= 70 && edge >= 5)  ? 0.50
       : 0.40;
}

/** Same pack-cap law as trading-bot applyPackSizeCap (shrink-only). */
function packCapContracts(contracts: number, packSizeCapMult: number): number {
  if (!Number.isFinite(contracts) || contracts <= 0) return 0;
  if (!Number.isFinite(packSizeCapMult) || packSizeCapMult >= 1) return contracts;
  return Math.max(0, Math.floor(contracts * packSizeCapMult));
}

/** Shrink-only size mult: finite, in [0, 1]. >1 would oversize past Kelly. */
function shrinkOnlyMult(x: number | undefined, fallback = 1): number {
  const v = typeof x === "number" && Number.isFinite(x) ? x : fallback;
  return Math.max(0, Math.min(1, v));
}

/**
 * True fractional-Kelly contract count. p = pWin (winRateAtPrice), b from
 * fee-net, fraction capped at 0.60, fee-inclusive denominator, then
 * maxContracts and pack-size cap. uMult shrinks size only — never replaces p.
 *
 * Portfolio-% / tiered / SIZE_RESCUE orchestration stays in TradingBot; this is
 * the dormant-Kelly (useKellyFraction) branch's pure math.
 */
export function computeContracts(opts: KellyContractsInput): SizingResult {
  // uMult / volume / guardrail are SHRINK-ONLY (doc lock). Never amplify past Kelly.
  const volumeSizeMult = shrinkOnlyMult(opts.volumeSizeMult, 1);
  const packSizeCapMult = opts.packSizeCapMult ?? 1;
  const guardrail = shrinkOnlyMult(opts.guardrail ?? opts.guardfactor, 1);
  const uMult = shrinkOnlyMult(opts.uMult, 1);
  // p = winRateAtPrice when finite; clamp to (0,1] so bogus p>1 cannot push
  // bankroll fraction above the Kelly cap (0.60).
  const rawP = (typeof opts.pWin === "number" && Number.isFinite(opts.pWin))
    ? opts.pWin
    : opts.pSizeClamped;
  const p = (typeof rawP === "number" && Number.isFinite(rawP))
    ? Math.max(0, Math.min(1, rawP))
    : 0;
  const b = kellyPayoutRatio(opts.entryPriceCents);
  const kelly = computeKellyEdge(p, b);
  if (kelly <= 0) {
    return {
      contracts: 0, limiter: "KELLY_EDGE_NONPOSITIVE",
      detail: `kelly=${kelly.toFixed(3)} <= 0 (winRate=${(p * 100).toFixed(0)}%, payoutRatio=${b.toFixed(2)}x)`,
    };
  }

  const kellyFrac = kellyFraction(opts.confidence, opts.edge);
  // Cap bet fraction at kellyFrac (≤0.60): f*·λ must never exceed λ of bankroll.
  const scaledKelly = Math.min(kellyFrac, Math.max(0, kelly * kellyFrac));
  const netCostCeil = Math.ceil(kalshiNetCostCents(opts.entryPriceCents));
  if (!(netCostCeil > 0)) {
    return {
      contracts: 0, limiter: "KELLY_EDGE_NONPOSITIVE",
      detail: `netCost=${netCostCeil}¢ invalid — refuse size`,
    };
  }
  const preClamp = Math.floor(scaledKelly * uMult * volumeSizeMult * guardrail * opts.balanceCents / netCostCeil);
  const preCapContracts = Math.min(opts.maxContracts, preClamp);
  const contracts = packCapContracts(preCapContracts, packSizeCapMult);

  let limiter = "NONE";
  let detail = `bal=${opts.balanceCents}¢ scaledKelly=${scaledKelly.toFixed(3)} uMult=${uMult.toFixed(3)} volumeSizeMult=${volumeSizeMult.toFixed(3)} netCost=${netCostCeil}¢ preCapContracts=${preCapContracts} packSizeCapMult=${packSizeCapMult.toFixed(3)} contracts=${contracts} guardrail=${guardrail.toFixed(2)} max=${opts.maxContracts}`;
  if (contracts <= 0) {
    limiter = "KELLY_BUDGET_TOO_SMALL";
    detail = `half-Kelly ${(scaledKelly * 100).toFixed(1)}% of $${(opts.balanceCents / 100).toFixed(2)} can't afford 1 contract at ${netCostCeil}¢ (guardrail=${guardrail.toFixed(2)})`;
  } else if (contracts < preCapContracts) {
    limiter = "PACK_SIZE_CAP";
    detail = `sized ${preCapContracts}x by half-Kelly, capped to ${contracts}x by enforced pack (packSizeCapMult=${packSizeCapMult.toFixed(3)})`;
  } else if (preCapContracts < preClamp) {
    limiter = "MAX_CONTRACTS_CAP";
    detail = `sized ${preClamp}x by half-Kelly, capped to ${preCapContracts}x by maxContractsPerTrade=${opts.maxContracts}`;
  }
  return { contracts, limiter, detail };
}

// ── Daily halt waterfall (#370) ───────────────────────────────────────────────
// Operator flash-crash halt: max($30 floor, 10% of cash). Distinct from
// HARD_RISK_LIMITS.maxDailyLossPct (18%) which stays the last-resort
// applyHardRiskLimits circuit breaker. Do not cut 9% / 18%.
export const DAILY_HALT_FLOOR_CENTS = 3000;
export const DAILY_HALT_PCT = 0.10;

/**
 * Effective daily-loss cap in cents: max(floor, pct of cash).
 * $313 cash → max(3000, 3130) = 3130. $200 cash → max(3000, 2000) = 3000.
 */
export function effectiveDailyHaltCapCents(
  balanceCents: number,
  floorCents: number = DAILY_HALT_FLOOR_CENTS,
  pct: number = DAILY_HALT_PCT,
): number {
  const floor = Number.isFinite(floorCents) && floorCents > 0 ? floorCents : DAILY_HALT_FLOOR_CENTS;
  if (!Number.isFinite(balanceCents) || balanceCents <= 0) return floor;
  const pctCents = Math.round(balanceCents * pct);
  return Math.max(floor, pctCents);
}

/** True once today's realized PnL is at or below -cap. Exact boundary trips. */
export function dailyHaltTrips(
  todayPnlCents: number,
  balanceCents: number,
  floorCents: number = DAILY_HALT_FLOOR_CENTS,
  pct: number = DAILY_HALT_PCT,
): boolean {
  return todayPnlCents <= -effectiveDailyHaltCapCents(balanceCents, floorCents, pct);
}

/**
 * p = winRateAtPrice curve only. No expectedWinRate, no 0.75, no 0.65, no confidence.
 * Missing/invalid curve → null → skip. Side picker must never invent p.
 * Extra leftover args (expectedWinRate / confidence / calibratedWinRate) are ignored.
 */
export function pWinFromCurve(
  winRateAtPrice: ((entryPriceCents: number, minutesLeft: number) => number) | undefined,
  entryPriceCents: number | null | undefined,
  minutesLeft: number,
  _neverInvent?: { expectedWinRate?: number; confidence?: number; calibratedWinRate?: number },
): number | null {
  void _neverInvent;
  if (!winRateAtPrice || typeof entryPriceCents !== "number" || !Number.isFinite(entryPriceCents)) {
    return null;
  }
  const p = winRateAtPrice(entryPriceCents, minutesLeft);
  return typeof p === "number" && Number.isFinite(p) && p > 0 && p <= 1 ? p : null;
}

/** Fee-net EV in cents. p must already be winRateAtPrice. Never confidence. */
export function feeNetEVCents(opts: {
  entryPriceCents: number;
  pWin: number;
  strategyId?: string;
  secsRemaining?: number;
  velocityDolPerMin?: number;
  spreadCents?: number;
  observedSlippageCents?: number;
}): number {
  return computeTradeEV({
    entryPriceCents: opts.entryPriceCents,
    winRate: opts.pWin,
    strategyId: opts.strategyId,
    secsRemaining: opts.secsRemaining,
    velocityDolPerMin: opts.velocityDolPerMin,
    spreadCents: opts.spreadCents,
    observedSlippageCents: opts.observedSlippageCents,
  }).netEV;
}


// ═══════════════════════════════════════════════════════════════════════════
// Uppity R3 Arch peel (2026-09-11) — pure pre-class helpers from trading-bot.ts
// TradingBot re-exports for back-compat. No decideMoneyPath / settle / fee-net.
// ═══════════════════════════════════════════════════════════════════════════

/** p = winRateAtPrice curve only. Null if missing/invalid. Never expectedWinRate. Never confidence. */
export function pWinAtPrice(
  winRateAtPrice: ((entryPriceCents: number, minutesLeft: number) => number) | undefined,
  _expectedWinRate: number | undefined,
  entryPriceCents: number | null | undefined,
  minutesLeft: number,
): number | null {
  void _expectedWinRate;
  return pWinFromCurve(winRateAtPrice, entryPriceCents, minutesLeft);
}

/**
 * Fill-path p for the traded ask. Always winRateAtPrice of the TRADED side.
 * Never lastModelProb (binary P(YES)). Never 1-p swap. Never confidence.
 */
export function fillPathPWin(winRateAtTradedAsk: number | null | undefined): number | null {
  return typeof winRateAtTradedAsk === "number"
    && Number.isFinite(winRateAtTradedAsk)
    && winRateAtTradedAsk > 0
    && winRateAtTradedAsk <= 1
    ? winRateAtTradedAsk
    : null;
}


/**
 * Seconds remaining for a specific open trade. Hourly trades carry their
 * market close time and must NOT use the 15-minute ET-clock — that clock
 * resets every quarter hour and would fire time-stops / near-expiry logic
 * up to 3 times inside one hourly contract.
 */

/** 15m paper/live trades must carry their own close time (Sep 9 #1). */
export function resolve15mCloseTimeMs(ticker: string, secsRemaining: number, nowMs: number): number {
  void ticker;
  const secs = Number.isFinite(secsRemaining) && secsRemaining > 0 ? secsRemaining : 900;
  const close = nowMs + Math.min(secs, 900) * 1000;
  return close > nowMs ? close : nowMs + 1_000;
}

/** Last valid BTC print at/before a known close. Missing evidence stays unresolved.
 * This is a paper reference price, NOT the exchange's official settlement result.
 */
export function paperSettlementRefPrice(
  prices: ReadonlyArray<{ price: number; ts: number }>,
  closeTimeMs: number | undefined,
): number | null {
  if (typeof closeTimeMs !== "number" || !Number.isFinite(closeTimeMs) || closeTimeMs <= 0) return null;
  let best: { price: number; ts: number } | null = null;
  for (const p of prices) {
    if (!p || !Number.isFinite(p.price) || p.price <= 0
        || !Number.isFinite(p.ts) || p.ts < 0 || p.ts > closeTimeMs) continue;
    if (!best || p.ts >= best.ts) best = p;
  }
  return best?.price ?? null;
}

/** VWAP cost basis when adding to a position (Sep 9 #6). */
export function blendedEntryPriceCents(
  entryCents: number, contracts: number, addCents: number, addContracts: number,
): number {
  if (!(contracts > 0) || !(addContracts > 0) || !Number.isFinite(addCents)) return entryCents;
  const total = contracts + addContracts;
  if (!(total > 0)) return entryCents;
  return Math.round((entryCents * contracts + addCents * addContracts) / total);
}

/**
 * PATH / Kelly / conf-floor p for CC/LAG. Thin paper learner WR (n<20 real)
 * does not replace the calibrated curve. Missing curve → null → skip. Not 0.65.
 */
export function pWinAtPriceRejectingThinLearner(
  winRateAtPrice: ((entryPriceCents: number, minutesLeft: number) => number) | undefined,
  _expectedWinRate: number | undefined,
  entryPriceCents: number | null | undefined,
  minutesLeft: number,
  opts: { strategyId?: string | null; paperMode: boolean; realBotSettlesN?: number },
): number | null {
  const curveP = pWinAtPrice(winRateAtPrice, _expectedWinRate, entryPriceCents, minutesLeft);
  if (!isMoneyMakerStrategyId(opts.strategyId)) return curveP;
  const id = opts.strategyId as string;
  const sample = getLearnerPathWinRateSample(id);
  const realN = opts.realBotSettlesN ?? getLiveTradeStatsSync(id, 15).n;
  return pathPWinFromCurveOrLearner({
    curveP,
    learnerWR: sample.winRate,
    learnerN: sample.n,
    paperMode: opts.paperMode,
    realBotSettlesN: realN,
  });
}

/**
 * Composite MTF lock. Fast 5m/15m green cannot admit the other side.
 * Typical OTM: composite ≤−3 NO only, ≥+3 YES only. Fail-closed.
 */
export function mtfCompositeLockAllowsSide(
  side: "yes" | "no",
  compositeScore: number,
  minLong: number,
  maxShort: number,
): boolean {
  if (side === "yes") return compositeScore >= minLong;
  return compositeScore <= maxShort;
}

/**
 * 15m evaluate caller: decide side, then maybe place. Skip short-circuits size.
 * Log fields: pWin (winRateAtPrice) vs signalConfidence (heuristic) — separate.
 */
export function apply15mSettlementSideBeforeSize(input: {
  pYes: number | null;
  pNo: number | null;
  mtf: number;
  signalConfidence?: number | null;
  /** BasisState.lagStale. Live always passes (true if missing). */
  lagStale?: boolean;
  /** BasisState.lagDollars. Coinbase $ over tau, never 1s proj. */
  lagDollars?: number | null;
  quoteAgeMs?: number | null;
  /** BotConfig.paperMode. Fail-closed missing/false keeps $16 magnitude. */
  paperMode?: boolean;
  /** result.best strategyId. Only CONFLUENCE/LAG drop $16 on paper. */
  strategyId?: string | null;
  /**
   * Fired ids this bar (yesR/noR/all PATH_RIDE). MIXED leftover-as-best used
   * to pass only FLOOR/TW here so remake both_sides/lag_stale skipped CC.
   */
  strategyIds?: readonly (string | null | undefined)[];
}) {
  const ids = [input.strategyId, ...(input.strategyIds ?? [])];
  const moneyId = ids.find(id => isMoneyMakerStrategyId(id)) ?? input.strategyId;
  const lagMinAbsDollars = paperMoneyMakerLagMinAbsDollars(input.paperMode, moneyId);
  const { decision, log } = decideSettlementSideLogged(
    {
      pYes: input.pYes,
      pNo: input.pNo,
      mtf: input.mtf,
      lagStale: input.lagStale,
      lagDollars: input.lagDollars,
      quoteAgeMs: input.quoteAgeMs,
      lagMinAbsDollars,
    },
    { signalConfidence: input.signalConfidence },
  );
  // Paper≡live CC/LAG/HA PATH_RIDE later-preserver: remake SETTLEMENT_SIDE must not
  // empty a cheap take. quote_stale / lag_disagrees / p_null still block.
  const preserve = paperPathRidePreservesThroughSettlementSkip(
    input.paperMode,
    ids,
    decision.reason,
  );
  return { place: decision.side !== "skip" || preserve, decision, log };
}

/** MIN-BAND vs PROTECTIVE-SHRINK FIX (2026-08-19, SEV2). Pure predicate: does
 *  this trade currently carry an active, deliberate size-DOWN signal from one
 *  of the three multipliers that exist specifically to shrink a trade below
 *  what confidence/edge alone would size (uMult: estimation uncertainty;
 *  volumeSizeMult / a DEAD-or-LOW volume bucket: thin/dead order book;
 *  packSizeCapMult: specialist-pack cap)? Extracted standalone (rather than
 *  inlined in the placeOrder band block) so it's unit-testable without
 *  instantiating the bot class or mocking balance/entryPrice — same
 *  fail-closed-paths-testability convention as evaluateDailyLossHalt() and
 *  resolveSettlementFallbackOutcome() elsewhere in this file. */
export function isProtectiveShrinkActive(
  uMult: number | undefined,
  volumeSizeMult: number | undefined,
  packSizeCapMult: number | undefined,
  volumeBucket: VolumeBucket | null | undefined,
  pricePathSizeMult = 1,
  timeOfDaySizeMult = 1,
): boolean {
  return (
    (uMult !== undefined && uMult < 1) ||
    (volumeSizeMult !== undefined && volumeSizeMult < 1) ||
    (packSizeCapMult !== undefined && packSizeCapMult < 1) ||
    pricePathSizeMult < 1 ||
    timeOfDaySizeMult < 1 ||
    volumeBucket === "DEAD" || volumeBucket === "LOW"
  );
}

/** MIN-BAND vs PROTECTIVE-SHRINK FIX (2026-08-19, SEV2). Pure decision core
 *  for the placeOrder 2-5%-of-equity portfolio-risk band: when a protective
 *  shrink is active, the minBand floor is skipped entirely (contracts may
 *  still be trimmed DOWN by maxBandContracts, but is never raised UP) — the
 *  floor's whole job (rescue an under-target size) is exactly what a
 *  deliberate protective shrink must NOT be rescued from. Also re-clamps to
 *  effectiveMaxContracts so the band can never raise a count past a ceiling
 *  enforced earlier in the pipeline (the 9%-of-equity hard cap re-checks
 *  independently further downstream regardless, as a coarser backstop). */
/** PACK-CAP-ON-ALL-BRANCHES FIX (2026-08-19, SEV2). Single application point
 *  for an enforced specialist pack's `sizeCapMult` "size law" — used at the
 *  END of every live sizing branch (portfolio-risk, tiered, Kelly), after
 *  that branch has computed its own contracts count (already reflecting
 *  uMult/volumeSizeMult where that branch applies them). Deliberately NOT
 *  folded into any branch's pre-floor combined multiplier — one helper,
 *  applied once, is easier to audit than the same scalar entering 3
 *  differently-shaped formulas. packSizeCapMult defaults to 1.0 (no-op) when
 *  packs are off/shadow-mode or no pack applies this tick, so this is a
 *  true no-op on every path with no live pack. Floors (never rounds up, so
 *  this can only shrink a count, matching "cap" semantics) and clamps to a
 *  non-negative integer. Pure — unit-testable without instantiating the bot
 *  class. */
export function applyPackSizeCap(contracts: number, packSizeCapMult: number): number {
  if (!Number.isFinite(contracts) || contracts <= 0) return 0;
  if (!Number.isFinite(packSizeCapMult) || packSizeCapMult >= 1) return contracts; // off/shadow/no pack -> no-op
  return Math.max(0, Math.floor(contracts * packSizeCapMult));
}

export function evaluatePortfolioRiskBand(
  contracts: number,
  minBandContracts: number,
  maxBandContracts: number,
  protectiveShrinkActive: boolean,
  effectiveMaxContracts: number,
): number {
  const flooredOrNot = protectiveShrinkActive
    ? contracts
    : Math.max(minBandContracts, contracts);
  return Math.min(maxBandContracts, flooredOrNot, effectiveMaxContracts);
}

// ── Grok regime classifier ────────────────────────────────────────────────────
export function detectGrokRegime(obs: StrategyObservation, channelInfo?: ChannelInfo | null): GrokRegime {
  const av = Math.abs(obs.velocityDolPerMin), av3 = Math.abs(obs.threeMinVelocity);
  if (av > 140 || av3 > 110) return 'high_vol';
  if (av > 58 && av3 > 42 && Math.sign(obs.velocityDolPerMin) === Math.sign(obs.threeMinVelocity)) return 'trending';
  if ((channelInfo?.channelWidth ?? 9999) < 280 && av < 45 && channelInfo && channelInfo.confidence > 0.55) return 'ranging';
  if (av < 28 && av3 < 25) return 'low_vol';
  return 'transitioning';
}

// ── Hard entry filters ────────────────────────────────────────────────────────
// Strategy-specific and regime-specific guards applied just before order
// placement. These block entries the confidence score alone would allow
// but which have poor structural backing.

export function passesHardFilters(
  secs: number, obs: StrategyObservation,
  stratResult: { strategyId: string }, channelInfo: ChannelInfo | null, regime: GrokRegime,
): boolean {
  const id = stratResult.strategyId, adf = Math.abs(obs.distFromFloorPct);
  if (secs < 150 && adf < 0.18) return false;
  // Removed: adf < 0.045 near-floor block — this killed the best YES/NO entries
  // at 40-55¢ where BTC hovers within $30 of the strike. The ±0.5% dist gate
  // downstream already handles extreme cases.
  if (id === 'CHANNEL_BOUNCE' && (!channelInfo || channelInfo.confidence < 0.62 || channelInfo.channelWidth > 420)) return false;
  if (id === 'VELOCITY_MOMENTUM' && regime === 'ranging') return false;
  if ((id === 'BREAKOUT_CAPTURE' || id === 'SQUEEZE_EXPANSION') && regime === 'low_vol') return false;
  return true;
}

export function detectBreakoutFakeout(
  prices: { price: number; ts: number }[],
  floorStrike: number,
): { recentlyBrokeLevel: boolean; quickReclaim: boolean } {
  if (prices.length < 12) return { recentlyBrokeLevel: false, quickReclaim: false };

  const n       = prices.length;
  const curr    = prices[n - 1].price;
  const round   = Math.round(curr / 500) * 500;
  const levels  = [...new Set([floorStrike, round, round + 500, round - 500].filter(l => l > 0))];

  const cutoff    = Math.floor(n * 0.6);
  const older     = prices.slice(0, cutoff);
  const recent    = prices.slice(cutoff);
  if (older.length < 4 || recent.length < 3) return { recentlyBrokeLevel: false, quickReclaim: false };

  const olderHigh  = Math.max(...older.map(p => p.price));
  const olderLow   = Math.min(...older.map(p => p.price));
  const recentHigh = Math.max(...recent.map(p => p.price));
  const recentLow  = Math.min(...recent.map(p => p.price));

  let recentlyBrokeLevel = false;
  let quickReclaim       = false;

  for (const lvl of levels) {
    const buf = lvl * 0.0005; // 0.05% buffer to avoid noise
    if (olderLow > lvl + buf && recentLow < lvl - buf) {
      recentlyBrokeLevel = true;
      if (curr > lvl + buf) quickReclaim = true; // spring: dipped below then recovered
    }
    if (olderHigh < lvl - buf && recentHigh > lvl + buf) {
      recentlyBrokeLevel = true;
      if (curr < lvl - buf) quickReclaim = true; // upthrust: spiked above then rejected
    }
  }
  return { recentlyBrokeLevel, quickReclaim };
}

// ── OTM-aware MTF thresholds ──────────────────────────────────────────────────
// OTM_ASYMMETRY / DEEP_OTM_SNIPER already hard-require MTF ≥3 (or ≤-3 for
// shorts, DEEP_OTM_SNIPER actually requires ≥4/≤-4) inside their own
// evaluate() functions — stricter than the static config default of ±1/-1.
// Under static config this makes the config-level MTF gate a no-op for the
// OTM family (they already passed a tougher requirement to produce a signal
// at all). But ARIA's setup control can tighten the effective thresholds
// (`effMinLong`/`effMaxShort`, which already fold in any AI override) beyond
// ±3, and that tightening must still reach OTM setups or ARIA's MTF control
// would silently do nothing for the entire OTM family. Taking the stricter of
// (OTM's own ±3 floor, the effective threshold) means a static/weaker
// effective threshold never re-blocks an OTM trade, but an ARIA-tightened one
// still can. Exported as a pure function so this exact invariant is directly
// testable without needing to drive the full evaluateEntry() pipeline.
export function otmAwareMTFThresholds(
  isOTMSetup: boolean,
  effMinLong: number,
  effMaxShort: number,
): { minLong: number; maxShort: number } {
  // 2026-08-03: OTM floor lowered 3→2 / -3→-2 as part of the drought-relief
  // relaxation. Still stricter than the normal ±0 default, just less so.
  return {
    minLong:  isOTMSetup ? Math.max(effMinLong, 2)   : effMinLong,
    maxShort: isOTMSetup ? Math.min(effMaxShort, -2) : effMaxShort,
  };
}

// ── Settlement-hold eligibility (pure, single source per consumer) ───────────
// Both settlement-hold consumers below take an already-effective (ARIA-
// tightened) secsThreshold/minProb pair from getEffectiveSettlementHold() —
// neither one is allowed to read `this.config.settlementHold*` directly, so a
// raised ARIA probability bar can never be "seen" by one consumer while
// another (weaker) implicit bar still lets the trade through. Exported as
// pure functions so the exact eligibility math is directly testable without
// driving the full evaluateEntry()/_placeOrderBody() pipelines.

/**
 * Pre-trade-sim "settlement-hold override" (evaluateEntry, when the standard
 * score threshold rejects a near-certain, hold-to-expiry setup). The 90%
 * floor is this override's own hard safety baseline — Math.max with the
 * effective minProb means ARIA can only raise the bar further, never use a
 * lower hold-engagement bar to loosen this stricter override.
 */
export function settlementHoldOverrideEligible(p: {
  useSettlementHold: boolean; secs: number; effSecsThreshold: number;
  projectedWinProb: number; settlementMassWR: number; distFromFloorPct: number;
  newsRisk: string; effMinProb: number;
}): boolean {
  const bar = Math.max(0.90, p.effMinProb);
  return p.useSettlementHold
    && p.secs < p.effSecsThreshold
    && p.projectedWinProb  >= bar
    && p.settlementMassWR  >= bar
    && Math.abs(p.distFromFloorPct) >= 1.5
    && p.newsRisk !== 'high';
}

/**
 * _placeOrderBody()'s EV-gate calibration branch: whether this trade gets the
 * generous model-probability win-rate treatment (assumes hold to expiry) vs.
 * the standard backtest-capped win rate. Requires BOTH that ARIA's window
 * would still let a hold engage AND that the model is confident enough to
 * clear ARIA's probability bar — a trade the monitor would decline to hold
 * (too far out, or below the confidence bar) must not get the favorable
 * treatment here.
 */
export function settlementHoldEVEligible(p: {
  useSettlementHold: boolean; secs: number; effSecsThreshold: number;
  modelWR: number; effMinProb: number;
}): boolean {
  return p.useSettlementHold && p.secs < p.effSecsThreshold && p.modelWR >= p.effMinProb;
}


/**
 * Trades that must not ride hold-to-settlement / settlement-hold to expiry.
 * OTM stays exempt (unchanged). CHEAP_SIDE_15M doctrine is "sell before expiry"
 * — exempt it the same way, without enabling OTM live.
 */
export function isHoldToSettlementExempt(trade: { isOTMAsymmetry?: boolean; strategyId?: string | null }): boolean {
  if (trade.isOTMAsymmetry) return true;
  return trade.strategyId === "CHEAP_SIDE_15M"
    || trade.strategyId === "PAPER_SCALP"
    || trade.strategyId === "CHEAP_EARLY_EXIT"
    || trade.strategyId === "PANIC_FADE"
    || trade.strategyId === "STREAK_SAT_FADE"
    || trade.strategyId === "TICKET_WAVE";
}

// ── Regime / strategy allowlist ───────────────────────────────────────────────
// Hard-blocks regime/strategy mismatches. Strategies whose edge is structural-
// ly negative in the current regime are removed from the candidate pool before
// confidence scoring — so we never waste a pre-trade sim on a legitimately bad
// combination. Keys are the five GrokRegime values.
//
// NOTE: this is a DIFFERENT, coarser taxonomy than each strategy's own
// `targetRegimes` field in strategy-library.ts (which uses the fine-grained
// MarketRegimeTag set: strong_uptrend, fakeout, squeeze, etc., and is purely
// descriptive — nothing reads it back for gating). Don't "reconcile" the two
// by editing this allowlist to match a strategy's targetRegimes; the actual
// fine-grained boost/suppress logic for those tags lives in condition-adapter.ts.
// Task #367: the per-regime strategy allowlist used to live here as a
// separate top-level map (REGIME_STRATEGY_ALLOWLIST), duplicating every
// strategy ID a second time in a file the strategy definition itself doesn't
// live in. It's now colocated as `enabledInRegimes` on each StrategyDefinition
// in strategy-library.ts — a new strategy declares its regime membership once,
// there, instead of also editing this file. See that field's doc comment for
// why it stays a separate taxonomy from the fine-grained targetRegimes tags.
const KNOWN_GROK_REGIMES = ['trending', 'ranging', 'high_vol', 'low_vol', 'transitioning'];

export function isStrategyAllowedInRegime(strategyId: string, grokRegime: string): boolean {
  // Unrecognized regime label falls back to 'transitioning' — same default
  // the old REGIME_STRATEGY_ALLOWLIST[grokRegime] ?? [...]['transitioning'] used.
  const regime = KNOWN_GROK_REGIMES.includes(grokRegime) ? grokRegime : 'transitioning';
  const strat  = getStrategy(strategyId as StrategyId);
  return strat?.enabledInRegimes?.includes(regime) ?? false;
}

/**
 * The strategy filter intentionally does not block a candidate while the
 * fine-grained regime classifier is unclear. During that brief transition,
 * applying a coarse allow-list would turn a classifier uncertainty into a
 * silent no-trade rule. Once a concrete regime is committed, use the matching
 * coarse GrokRegime membership declared on the strategy itself.
 *
 * BASIS_LAG_EDGE has an additional range/unclear quality gate and is handled
 * separately at its call site because it needs the full live observation.
 */
export function passesStrategyRegimeFilter(opts: {
  strategyId: string;
  currentRegime: string;
  grokRegime: string;
}): boolean {
  return opts.currentRegime === 'unclear'
    || isStrategyAllowedInRegime(opts.strategyId, opts.grokRegime);
}
export function isReversalCapable(strategyId: string): boolean {
  return getStrategy(strategyId as StrategyId)?.reversalCapable === true;
}

/**
 * Filters a strategy-result pool against the strong-trend direction lock.
 * A strong MTF score is an explicit directional safety boundary: in a strong
 * bear market only NO entries are admissible, and in a strong bull market
 * only YES entries are admissible. STAY_OUT/non-directional results remain in
 * the pool so the normal selector can still report no trade.
 *
 * This intentionally does not fall back to the unfiltered pool when every
 * directional result contradicts the trend. Re-admitting that pool would make
 * the lock observational instead of protective and could allow exactly the
 * wrong-direction entry this gate is meant to prevent.
 *
 * Lock constructs CC/LAG aligned cheap when quotes are in band (28 CC / 10 LAG, ≤55).
 * Opposed CC/LAG with no aligned cheap are kept so MTF_FILTER skip-returns
 * (skip-tape hygiene — empty pool was false NO_ELIGIBLE / silent starve).
 */
export function applyStrongMTFDirectionLock<T extends { strategyId: string; signal: string }>(
  pool: T[],
  mtfScore: number,
  enabled: boolean,
  log: (msg: string) => void,
  quotes?: { yesAsk?: number; noAsk?: number; spot?: number; floorStrike?: number },
): T[] {
  if (!enabled || !Number.isFinite(mtfScore) || Math.abs(mtfScore) < 3) return pool;
  const mtfBias = mtfScore <= -3 ? 'strong_bear' : 'strong_bull';
  const allowedSignal = mtfBias === 'strong_bear' ? 'NO' : 'YES';
  // Construct aligned cheap (CC 28 / LAG 10, ≤55). Do not only delete opposed YES.
  // Opposed CC/LAG with no aligned cheap KEEP so MTF_FILTER skip-returns.
  // Ghost leftover 1¢ YES must not participate. Side lock KEEP.
  const lockPool = pool.filter(r => !FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has(r.strategyId as never));
  const constructed = lockPool.map(r => {
    if (!quotes) return r;
    const want = mtfAlignedCheapWantSignal({
      strategyId: r.strategyId,
      mtfScore,
      yesAsk: quotes.yesAsk,
      noAsk: quotes.noAsk,
      spot: quotes.spot,
      floorStrike: quotes.floorStrike,
    });
    if (!want || r.signal === want || (r.signal !== 'YES' && r.signal !== 'NO')) return r;
    log(`🧭 Direction lock: MTF ${mtfBias} — construct ${want} from ${r.signal} (${r.strategyId})`);
    return { ...r, signal: want };
  });
  const hasAlignedMoney = constructed.some(r =>
    (r.strategyId === 'CONFLUENCE_CASCADE' || r.strategyId === 'BASIS_LAG_EDGE')
    && r.signal === allowedSignal,
  );
  const filtered = constructed.filter(r => {
    if (r.signal !== 'YES' && r.signal !== 'NO') return true;
    if (r.signal === allowedSignal) return true;
    // Opposed CC/LAG reach MTF_FILTER unless an aligned money-maker is already in pool.
    if ((r.strategyId === 'CONFLUENCE_CASCADE' || r.strategyId === 'BASIS_LAG_EDGE') && !hasAlignedMoney) return true;
    return false;
  });
  for (const result of constructed) {
    if (result.signal !== 'YES' && result.signal !== 'NO') continue;
    if (result.signal === allowedSignal) continue;
    if (filtered.includes(result)) continue;
    log(
      `🧭 Direction lock: MTF ${mtfBias} — ${allowedSignal} only, ` +
      `skipping ${result.signal} signal (${result.strategyId})`,
    );
  }
  return filtered;
}

/**
 * Startup-only friction reducer (Architecture design item #4 / task #367):
 * a strategy whose `enabledInRegimes` (strategy-library.ts) is empty/missing
 * for every regime is silently unreachable forever — no error, no trade,
 * nothing. This has already happened twice by accident (see the 2026-08-03
 * and 2026-08-06 comments in strategy-library.ts's regime-membership data
 * needing after-the-fact fixes back when this lived in a separate
 * trading-bot.ts allowlist). This does NOT reconcile enabledInRegimes with
 * targetRegimes (deliberately kept separate — see enabledInRegimes' doc
 * comment) — it only logs a loud warning at boot so a forgotten registration
 * is caught immediately instead of discovered weeks later as "this strategy
 * never fires." Never blocks startup and never changes gating behavior.
 */
export function warnOnOrphanedStrategiesAtStartup(): void {
  try {
    const orphaned = getAllStrategyMeta()
      .map(m => m.id)
      .filter(id => !(getStrategy(id)?.enabledInRegimes?.length));
    if (orphaned.length > 0) {
      console.warn(
        `[trading-bot] STRATEGY REGISTRATION GAP: ${orphaned.join(', ')} ` +
        `${orphaned.length === 1 ? 'is' : 'are'} not present in enabledInRegimes for ANY ` +
        `regime — the strategy is defined but can never be selected. Add enabledInRegimes to its ` +
        `definition in strategy-library.ts if it should ever trade.`
      );
    }
  } catch (err) {
    console.debug(`[trading-bot] orphaned-strategy startup check failed: ${(err as Error).message}`);
  }
}

// Deferred: strategy-library imports cheap-*-exit → admission while STRATEGIES
// is still in TDZ. Calling here caused restart log
// "Cannot access 'STRATEGIES' before initialization". TradingBot.start()
// invokes this after the module graph has finished initializing.


/**
 * BASIS_LAG_EDGE-only regime gate for 'ranging'/'unclear' (2026-08-09, per
 * explicit instruction). The coarse allowlist above already includes
 * BASIS_LAG_EDGE unconditionally in 'ranging', and 'unclear' bypasses the
 * whole strategy-level regime filter for every strategy — so today this
 * strategy is effectively unrestricted by regime in both. This replaces that
 * blanket pass, for BASIS_LAG_EDGE only, with a conditional one: require a
 * real, still-open exchange-led edge — projected displacement from the floor
 * strike >= 0.05% and the entry-side ask <= 55c — before it's even
 * considered. Layered ON TOP of, never a replacement for, BASIS_LAG_EDGE's
 * own persistence-streak guard and fee/slippage-aware EV check in
 * strategy-library.ts, both left untouched. No other strategy or regime is
 * affected.
 */
/**
 * Resolves which regime string gets persisted onto bot_trades.regime for
 * regime-ev-stats.ts's empirical strategyId×regime EV tier to key off later.
 * Must return the fine-grained RegimeId the live tick actually evaluated
 * this trade against (the same `regime` argument scoreStrategyEV() and
 * evaluatePathDecision() were called with) — not the coarse GrokRegime
 * ('trending'|'ranging'|'transitioning'|'high_vol'|'low_vol'). The two
 * taxonomies don't share vocabulary (e.g. 'range' vs 'ranging', 'unclear'
 * has no GrokRegime equivalent at all), so if this ever regresses back to
 * writing grokRegime, getEmpiricalRegimeAdjustment()'s regime×strategy
 * lookup — always called with the fine-grained id — silently can never
 * match a historical row again, permanently stuck on its strategy-only or
 * neutral fallback tier no matter how much history accumulates.
 * `grokRegime` is kept only as a last-resort fallback for a caller that
 * predates the `detailedRegime` field.
 */
export function resolveTradeRegimeForPersistence(
  detailedRegime?: string | null,
  grokRegime?: string | null,
): string | null {
  return detailedRegime ?? grokRegime ?? null;
}

export function basisLagRegimeGateOk(obs: StrategyObservation): boolean {
  const proj = obs.projectedSettlementPrice;
  if (proj === undefined || !obs.floorStrike || obs.floorStrike <= 0) return false;
  const projDistPct = Math.abs(((proj - obs.floorStrike) / obs.floorStrike) * 100);
  if (projDistPct < 0.05) return false;
  const isLong = proj > obs.floorStrike;
  const sideAsk = isLong ? obs.yesAsk : obs.noAsk;
  return sideAsk !== undefined && sideAsk <= 55;
}

/**
 * Task #445 — pure predicate for the settlement hard-veto's core opposition
 * check, extracted from evaluateEntry() so it's independently unit-testable
 * (same rationale/pattern as basisLagRegimeGateOk above). Returns true only
 * when a real (non-NEUTRAL), sufficiently-confident settlement call opposes
 * the side we're about to trade.
 */
export function settlementVetoOpposes(
  call: { predictedDirection: 'UP' | 'DOWN' | 'NEUTRAL'; confidence: number } | null,
  minConfidence: number,
  side: 'yes' | 'no',
): boolean {
  if (!call || call.predictedDirection === 'NEUTRAL') return false;
  if (call.confidence < minConfidence) return false;
  const wantsLong = side === 'yes';
  return (call.predictedDirection === 'UP'   && !wantsLong) ||
         (call.predictedDirection === 'DOWN' &&  wantsLong);
}

// ── Meta-label confidence adjustment ─────────────────────────────────────────
// Final multiplicative pass after all bonuses/penalties are applied (0–100
// integer scale). Applies structural discounts that signal-level scoring misses:
//   • regime uncertainty                → discount
//   • short/long velocity disagreement  → discount
//   • price too close to floor          → discount (low edge zone)
//   • strong MTF alignment              → small bonus
//   • OTM strategy in weak conditions   → extra discount
// Clamped to [40, 95] to preserve existing floor/ceiling semantics.
export function metaLabelConfidence(
  conf:       number,           // integer 0–100, already fully adjusted
  obs:        StrategyObservation,
  grokRegime: string,
  strategyId: string,
): number {
  let c = conf;

  // NOTE: 'transitioning' discount REMOVED. 'transitioning' is the default
  // fallback regime that fires on ~60% of ticks; multiplying by 0.93 here
  // created a systematic under-confidence bias on nearly every entry. The
  // signal pipeline already handles transitioning via additive penalties.
  // low_vol: genuine momentum absence — retain a small discount.
  if (grokRegime === 'low_vol') c *= 0.90;

  // Velocity sign mismatch: changed from multiplicative ×0.85 (harsh, stacks
  // with other discounts) to flat −6 points. A 75 conf no longer collapses to
  // 64 just because 1m/3m velocity disagree momentarily.
  if (Math.sign(obs.velocityDolPerMin) !== Math.sign(obs.threeMinVelocity)) c = Math.max(40, c - 6);

  if (Math.abs(obs.distFromFloorPct) < 0.06) c *= 0.82;

  // MTF bonus removed — already applied in the main conf pipeline (+3 pts/score level,
  // lines 2417-2421). Keeping it here double-counted MTF alignment and gave false certainty.

  if (strategyId === 'OTM_BREAKOUT_EXPANSION' || strategyId === 'OTM_ASYMMETRY') {
    const weakVol = obs.volumeState !== 'high' && Math.abs(obs.velocityDolPerMin) < 110;
    const weakMTF = Math.abs(obs.mtfScore ?? 0) < 1;
    if (weakVol || weakMTF) c *= 0.78;
  }

  return Math.max(40, Math.min(95, Math.round(c)));
}

// Uppity R3: ET clock helpers
export function getETParts(d = new Date()) {
  const et = new Date(d.toLocaleString("en-US", { timeZone: "America/New_York" }));
  return { hours: et.getHours(), minutes: et.getMinutes(), seconds: et.getSeconds() };
}

export function getSecsRemaining() {
  const { minutes, seconds } = getETParts();
  const bMin = Math.floor(minutes / 15) * 15;
  return 15 * 60 - ((minutes - bMin) * 60 + seconds);
}

export function getPeriodKey() {
  const { hours, minutes } = getETParts();
  return `${hours}-${Math.floor(minutes / 15) * 15}`;
}


/** Seconds remaining for an open trade (hourly uses closeTimeMs; else 15m ET clock). */
export function tradeSecsRemaining(trade: { closeTimeMs?: number }): number {
  if (trade.closeTimeMs && trade.closeTimeMs > 0) {
    return Math.max(0, (trade.closeTimeMs - Date.now()) / 1000);
  }
  return getSecsRemaining();
}
