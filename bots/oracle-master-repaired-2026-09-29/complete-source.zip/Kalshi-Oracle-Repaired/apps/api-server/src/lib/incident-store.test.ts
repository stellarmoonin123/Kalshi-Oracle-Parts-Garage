/**
 * incident-store.test.ts
 *
 * Integration-style unit tests for IncidentStore.  All tests use an in-memory
 * fake IncidentRepo so no real database is needed.
 *
 * Covered behaviours:
 *   (a) enterDegraded() inserts a row and records in memory
 *   (b) enterDegraded() is idempotent — second call is a no-op
 *   (c) exitDegraded() stamps recoveredAt and clears in-memory state
 *   (d) exitDegraded() on a healthy subsystem is a no-op
 *   (e) getIncidentCount24h() counts rows from before a restart (DB-backed)
 *   (f) getIncidentCount24h() excludes rows older than 24 h
 *   (g) getIncidentTimestamps24h() returns correct epoch ms values
 *   (h) pruneOldIncidents() removes rows whose startedAt is older than 7 days
 *   (i) init() restores in-memory state from open DB rows on restart
 *   (j) getDegradedSince() reflects live in-memory state
 *   (k) a committed row is restored if the process crashes before the insert
 *       call returns
 *   (l) concurrent stores rely on the database uniqueness constraint to keep
 *       one open row per subsystem
 *
 * Run with:
 *   node --experimental-strip-types src/lib/incident-store.test.ts
 */

import 
{
 test 
}
 from "node:test"
;

import assert from "node:assert/strict"
;

import 
{

  INCIDENT_ROW_TRIM_TARGET,
  MAX_INCIDENT_ROWS,
  IncidentStore,
  type IncidentRepo,
  type Subsystem,
}
 from "./incident-store.js"
;

import 
{
 getIncidentDurationSecs 
}
 from "./incident-duration.js"
;


// ── Fake in-memory IncidentRepo ───────────────────────────────────────────────

interface FakeRow 
{

  id:          number
;

  subsystem:   string
;

  startedAt:   Date
;

  recoveredAt: Date | null
;

  reason?:     string | null
;

}


/**
 * Create a fresh fake repo backed by a plain JS array.
 * Honour the partial-unique-index semantics: at most one open row per subsystem.
 */
function makeFakeRepo(seed: FakeRow[] = []): IncidentRepo & 
{
 rows: FakeRow[] 
}
 
{

  let nextId = seed.length + 1
;

  const rows: FakeRow[] = seed.map((r, i) => (
{
 ...r, id: r.id ?? i + 1 
}
))
;


  return {

    rows,

    async findOpenIncidents() 
{

      return rows
        .filter(r => r.recoveredAt === null)
        .map(r => (
{
 id: r.id, subsystem: r.subsystem, startedAt: r.startedAt 
}
))
;

    
}
,

    async insertIncident(subsystem, startedAt, reason) 
{

      // Honour partial-unique-index: reject if an open row already exists.
      const conflict = rows.find(r => r.subsystem === subsystem && r.recoveredAt === null)
;

      if (conflict) return undefined
;


      const row: FakeRow = 
{
 id: nextId++, subsystem, startedAt, recoveredAt: null, reason: reason ?? null 
}
;

      rows.push(row)
;

      return {
 id: row.id 
}
;

    
}
,

    async findOpenIncident(subsystem) 
{

      const row = rows.find(r => r.subsystem === subsystem && r.recoveredAt === null)
;

      return row ? 
{
 id: row.id, startedAt: row.startedAt, reason: row.reason ?? null 
}
 : undefined
;

    
}
,

    async stampRecovery(id, recoveredAt) 
{

      const row = rows.find(r => r.id === id)
;

      if (row) row.recoveredAt = recoveredAt
;

    
}
,

    async updateReason(id, reason) 
{

      const row = rows.find(r => r.id === id)
;

      if (row) row.reason = reason
;

    
}
,

    async findRecentIncidents(subsystem, since) 
{

      return rows
        .filter(r => r.subsystem === subsystem && r.startedAt >= since)
        .map(r => (
{
 startedAt: r.startedAt 
}
))
;

    
}
,

    async deleteOldIncidents(cutoff) 
{

      const toDelete = rows.filter(r => r.startedAt < cutoff).map(r => r.id)
;

      for (const id of toDelete) 
{

        const idx = rows.findIndex(r => r.id === id)
;

        if (idx !== -1) rows.splice(idx, 1)
;

      
}

      return toDelete.length
;

    
}
,

    async countIncidents() 
{

      return rows.length
;

    
}
,

    async deleteOldestRows(count) 
{

      if (count <= 0) return
;

      const victims = [...rows]
        .filter(r => r.recoveredAt !== null)
        .sort((a, b) => a.startedAt.getTime() - b.startedAt.getTime())
        .slice(0, count)
        .map(r => r.id)
;

      for (const id of victims) 
{

        const idx = rows.findIndex(r => r.id === id)
;

        if (idx !== -1) rows.splice(idx, 1)
;

      
}

    
}
,
  
}
;

}


/** Create a store wired to a fresh fake repo (no seed data). */
function makeStore(seed: FakeRow[] = []): 
{
 store: IncidentStore
;
 repo: ReturnType<typeof makeFakeRepo> 
}
 
{

  const repo  = makeFakeRepo(seed)
;

  const store = new IncidentStore(repo)
;

  return {
 store, repo 
}
;

}


// Helper: a Date that is `offsetMs` milliseconds relative to now.
const msAgo  = (ms: number)  => new Date(Date.now() - ms)
;

const msLater = (ms: number) => new Date(Date.now() + ms)
;

const HOUR   = 60 * 60 * 1000
;

const DAY    = 24 * HOUR
;


// ── (a) enterDegraded inserts a row and records in memory ─────────────────────

test("enterDegraded inserts a row into the repo", async () => 
{

  const 
{
 store, repo 
}
 = makeStore()
;


  await store.enterDegraded("websocket")
;


  assert.equal(repo.rows.length, 1, "one row must have been inserted")
;

  assert.equal(repo.rows[0].subsystem,   "websocket")
;

  assert.equal(repo.rows[0].recoveredAt, null, "incident should still be open")
;

  assert.ok(repo.rows[0].id > 0, "row should have a real DB id")
;

}
)
;


test("enterDegraded sets getDegradedSince in memory", async () => 
{

  const 
{
 store 
}
 = makeStore()
;


  const before = Date.now()
;

  await store.enterDegraded("websocket")
;

  const after  = Date.now()
;


  const since = store.getDegradedSince("websocket")
;

  assert.ok(since !== null,       "getDegradedSince should be non-null")
;

  assert.ok(since! >= before,     "startedAt should be >= before-timestamp")
;

  assert.ok(since! <= after,      "startedAt should be <= after-timestamp")
;

}
)
;


// ── (b) enterDegraded is idempotent ───────────────────────────────────────────

test("enterDegraded is a no-op when the subsystem is already degraded", async () => 
{

  const 
{
 store, repo 
}
 = makeStore()
;


  await store.enterDegraded("websocket")
;

  const firstTs = store.getDegradedSince("websocket")
;


  await store.enterDegraded("websocket")
;
 // second call

  assert.equal(repo.rows.length, 1, "only one row should exist after two calls")
;

  assert.equal(store.getDegradedSince("websocket"), firstTs, "timestamp must not change")
;

}
)
;


// ── (c) exitDegraded stamps recoveredAt and clears in-memory state ────────────

test("exitDegraded stamps recoveredAt on the open row", async () => 
{

  const 
{
 store, repo 
}
 = makeStore()
;


  await store.enterDegraded("websocket")
;

  const rowId = repo.rows[0].id
;


  const before = Date.now()
;

  await store.exitDegraded("websocket")
;

  const after  = Date.now()
;


  const row = repo.rows.find(r => r.id === rowId)!
;

  assert.ok(row.recoveredAt !== null, "recoveredAt must be stamped")
;

  assert.ok(row.recoveredAt!.getTime() >= before, "recoveredAt should be >= before")
;

  assert.ok(row.recoveredAt!.getTime() <= after,  "recoveredAt should be <= after")
;

}
)
;


// ── Task #176: exitDegraded racing enterDegraded's in-flight insert ───────────
//
// If a subsystem flaps degraded→healthy faster than one DB round-trip,
// exitDegraded() runs while `open.get(subsystem).id` is still the -1
// placeholder. It must not silently drop the recovery — the row that
// enterDegraded's insert eventually creates has to end up recovered too,
// not left open forever.

test("exitDegraded called while enterDegraded's insert is still in flight stamps recovery once the row exists", async () => 
{

  const repo = makeFakeRepo()
;

  // Wrap insertIncident so the test can control exactly when it resolves,
  // simulating a slow DB write that exitDegraded races against.
  let releaseInsert!: () => void
;

  const insertGate = new Promise<void>(resolve => 
{
 releaseInsert = resolve
;
 
}
)
;

  const realInsert = repo.insertIncident.bind(repo)
;

  repo.insertIncident = async (subsystem, startedAt) => 
{

    await insertGate
;

    return realInsert(subsystem, startedAt)
;

  
}
;


  const store = new IncidentStore(repo)
;


  const enterPromise = store.enterDegraded("websocket")
;
 // insert now pending
  await store.exitDegraded("websocket")
;
 // races the in-flight insert

  // The subsystem must already read as healthy in memory even though the
  // insert hasn't resolved yet.
  assert.equal(store.getDegradedSince("websocket"), null, "should read healthy immediately after the race");

  releaseInsert();
  await enterPromise; // let the deferred insert + deferred stampRecovery complete

  assert.equal(repo.rows.length, 1, "exactly one incident row should exist");
  assert.ok(repo.rows[0].recoveredAt !== null, "the row must end up recovered, not left open forever");
  assert.equal(store.getDegradedSince("websocket"), null, "still healthy after the deferred write settles");

  // A fresh enterDegraded afterwards must open a brand-new incident, not
  // reuse or resurrect stale race-condition state.
  await store.enterDegraded("websocket");
  assert.equal(repo.rows.length, 2, "a later real degrade opens a new row");
  assert.ok(store.getDegradedSince("websocket") !== null, "newly degraded state must be visible");
});

test("exitDegraded clears getDegradedSince", async () => {
  const { store } = makeStore();

  await store.enterDegraded("websocket");
  await store.exitDegraded("websocket");

  assert.equal(store.getDegradedSince("websocket"), null, "getDegradedSince should return null after recovery");
});

// ── (d) exitDegraded on a healthy subsystem is a no-op ────────────────────────

test("exitDegraded is a no-op when the subsystem is healthy", async () => {
  const { store, repo } = makeStore();

  // Should not throw and should leave the repo untouched.
  await store.exitDegraded("websocket");

  assert.equal(repo.rows.length, 0, "no rows should be inserted or modified");
});

// ── (e) getIncidentCount24h counts rows from before a restart ─────────────────

test("getIncidentCount24h counts rows seeded from before a restart", async () => {
  // Simulate 3 incidents from 2 h ago (all within the 24 h window).
  const seed: FakeRow[] = [
    { id: 1, subsystem: "websocket", startedAt: msAgo(2 * HOUR), recoveredAt: new Date() },
    { id: 2, subsystem: "websocket", startedAt: msAgo(3 * HOUR), recoveredAt: new Date() },
    { id: 3, subsystem: "websocket", startedAt: msAgo(4 * HOUR), recoveredAt: new Date() },
  ];
  const { store } = makeStore(seed);

  const count = await store.getIncidentCount24h("websocket");
  assert.equal(count, 3, "all 3 seed rows are within 24 h");
});

// ── (f) getIncidentCount24h excludes rows older than 24 h ─────────────────────

test("getIncidentCount24h excludes rows older than 24 h", async () => {
  const seed: FakeRow[] = [
    // Within window
    { id: 1, subsystem: "websocket", startedAt: msAgo(1 * HOUR),  recoveredAt: new Date() },
    { id: 2, subsystem: "websocket", startedAt: msAgo(23 * HOUR), recoveredAt: new Date() },
    // Outside window (25 h ago)
    { id: 3, subsystem: "websocket", startedAt: msAgo(25 * HOUR), recoveredAt: new Date() },
  ];
  const { store } = makeStore(seed);

  const count = await store.getIncidentCount24h("websocket");
  assert.equal(count, 2, "only 2 of 3 rows fall within the 24 h window");
});

test("getIncidentCount24h returns 0 when no incidents exist", async () => {
  const { store } = makeStore();
  const count = await store.getIncidentCount24h("websocket");
  assert.equal(count, 0);
});

test("getIncidentCount24h does not mix up subsystems", async () => {
  const seed: FakeRow[] = [
    { id: 1, subsystem: "database", startedAt: msAgo(1 * HOUR), recoveredAt: new Date() },
    { id: 2, subsystem: "mtf",      startedAt: msAgo(1 * HOUR), recoveredAt: new Date() },
  ];
  const { store } = makeStore(seed);

  assert.equal(await store.getIncidentCount24h("websocket"), 0, "websocket count should be 0");
  assert.equal(await store.getIncidentCount24h("database"),  1, "database count should be 1");
  assert.equal(await store.getIncidentCount24h("mtf"),       1, "mtf count should be 1");
});

// ── (g) getIncidentTimestamps24h returns correct epoch ms values ──────────────

test("getIncidentTimestamps24h returns startedAt epoch values within 24 h", async () => {
  const t1 = msAgo(1 * HOUR);
  const t2 = msAgo(2 * HOUR);
  const t3 = msAgo(25 * HOUR); // outside window
  const seed: FakeRow[] = [
    { id: 1, subsystem: "websocket", startedAt: t1, recoveredAt: new Date() },
    { id: 2, subsystem: "websocket", startedAt: t2, recoveredAt: new Date() },
    { id: 3, subsystem: "websocket", startedAt: t3, recoveredAt: new Date() },
  ];
  const { store } = makeStore(seed);

  const timestamps = await store.getIncidentTimestamps24h("websocket");
  assert.equal(timestamps.length, 2, "only 2 of 3 rows are within the 24 h window");
  assert.ok(timestamps.includes(t1.getTime()), "t1 should be present");
  assert.ok(timestamps.includes(t2.getTime()), "t2 should be present");
  assert.ok(!timestamps.includes(t3.getTime()), "t3 should NOT be present (outside window)");
});

test("getIncidentTimestamps24h returns [] when no incidents exist", async () => {
  const { store } = makeStore();
  const timestamps = await store.getIncidentTimestamps24h("websocket");
  assert.deepEqual(timestamps, []);
});

// ── (h) pruneOldIncidents removes rows older than 7 days ─────────────────────

test("pruneOldIncidents removes rows older than 7 days", async () => {
  const seed: FakeRow[] = [
    // Should survive (within 7 days)
    { id: 1, subsystem: "websocket", startedAt: msAgo(6 * DAY),  recoveredAt: new Date() },
    { id: 2, subsystem: "websocket", startedAt: msAgo(1 * DAY),  recoveredAt: new Date() },
    // Should be pruned (older than 7 days)
    { id: 3, subsystem: "websocket", startedAt: msAgo(8 * DAY),  recoveredAt: new Date() },
    { id: 4, subsystem: "database",  startedAt: msAgo(10 * DAY), recoveredAt: new Date() },
  ];
  const { store, repo } = makeStore(seed);

  await store.pruneOldIncidents();

  assert.equal(repo.rows.length, 2, "only the 2 recent rows should survive");
  assert.ok(repo.rows.every(r => r.id === 1 || r.id === 2), "surviving rows must be id 1 and 2");
});

test("pruneOldIncidents keeps all rows when none are older than 7 days", async () => {
  const seed: FakeRow[] = [
    { id: 1, subsystem: "websocket", startedAt: msAgo(1 * HOUR), recoveredAt: new Date() },
    { id: 2, subsystem: "database",  startedAt: msAgo(2 * DAY),  recoveredAt: new Date() },
  ];
  const { store, repo } = makeStore(seed);

  await store.pruneOldIncidents();

  assert.equal(repo.rows.length, 2, "no rows should have been pruned");
});

test("pruneOldIncidents is a no-op on an empty repo", async () => {
  const { store, repo } = makeStore();
  await store.pruneOldIncidents(); // must not throw
  assert.equal(repo.rows.length, 0);
});

test("row cap trims oldest recovered rows without deleting open incidents", async () => {
  const historicalRows: FakeRow[] = Array.from({ length: MAX_INCIDENT_ROWS }, (_, i) => ({
    id: i + 1,
    subsystem: `historical-${i}`,
    startedAt: new Date(Date.now() - (MAX_INCIDENT_ROWS - i) * 1000),
    recoveredAt: new Date(),
  }));
  const openRow: FakeRow = {
    id: MAX_INCIDENT_ROWS + 1,
    subsystem: "database",
    startedAt: new Date(Date.now() - 10 * DAY),
    recoveredAt: null,
  };
  const { store, repo } = makeStore([...historicalRows, openRow]);

  await store.enterDegraded("websocket");
  // Cap enforcement is intentionally asynchronous so incident writes do not
  // wait on a potentially slow count/trim query.
  for (let attempt = 0; attempt < 20 && repo.rows.length > INCIDENT_ROW_TRIM_TARGET + 1; attempt++) {
    await new Promise<void>(resolve => setImmediate(resolve));
  }

  assert.equal(repo.rows.length, INCIDENT_ROW_TRIM_TARGET, "trim should leave the configured total row target");
  assert.ok(repo.rows.some(r => r.id === openRow.id && r.recoveredAt === null), "open incidents must survive trimming");
  assert.ok(repo.rows.some(r => r.subsystem === "websocket" && r.recoveredAt === null), "newly opened incident must survive trimming");
});

test("row cap reruns after an insert lands while its count query is in flight", async () => {
  const seed: FakeRow[] = Array.from({ length: MAX_INCIDENT_ROWS - 1 }, (_, i) => ({
    id: i + 1,
    subsystem: `historical-${i}`,
    startedAt: new Date(Date.now() - (MAX_INCIDENT_ROWS - i) * 1000),
    recoveredAt: new Date(),
  }));
  const { store, repo } = makeStore(seed);
  const realCount = repo.countIncidents.bind(repo);
  let countCalls = 0;
  let firstCountStarted!: () => void;
  const firstCountStartedPromise = new Promise<void>(resolve => { firstCountStarted = resolve; });
  let releaseFirstCount!: () => void;
  const firstCountGate = new Promise<void>(resolve => { releaseFirstCount = resolve; });

  repo.countIncidents = async () => {
    countCalls++;
    if (countCalls !== 1) return realCount();

    const snapshot = await realCount();
    firstCountStarted();
    await firstCountGate;
    return snapshot;
  };

  const firstInsert = store.enterDegraded("websocket");
  await firstCountStartedPromise;
  await store.enterDegraded("database");
  releaseFirstCount();
  await firstInsert;

  for (let attempt = 0; attempt < 20 && repo.rows.length > INCIDENT_ROW_TRIM_TARGET; attempt++) {
    await new Promise<void>(resolve => setImmediate(resolve));
  }

  assert.equal(countCalls, 2, "an insert during a pending count must schedule one follow-up check");
  assert.equal(repo.rows.length, INCIDENT_ROW_TRIM_TARGET, "the burst must still be trimmed to the configured total target");
});

// ── (i) init() restores in-memory state from open DB rows ────────────────────

test("init() loads open incidents into memory so getDegradedSince works after restart", async () => {
  const openedAt = msAgo(2 * HOUR);
  const seed: FakeRow[] = [
    // Open incident — no recoveredAt
    { id: 1, subsystem: "websocket", startedAt: openedAt, recoveredAt: null },
    // Closed incident — should not surface
    { id: 2, subsystem: "database",  startedAt: msAgo(5 * HOUR), recoveredAt: new Date() },
  ];
  const { store } = makeStore(seed);
  await store.init();

  assert.equal(
    store.getDegradedSince("websocket"),
    openedAt.getTime(),
    "websocket should be degraded with the correct startedAt",
  );
  assert.equal(
    store.getDegradedSince("database"),
    null,
    "database has a closed incident and should NOT appear degraded",
  );
});

test("a recovered incident reloaded after restart reports the full positive outage duration", async () => {
  const outageDurationMs = 5 * 60 * 1000;
  const openedAt = new Date(Date.now() - outageDurationMs);
  const repo = makeFakeRepo([
    { id: 1, subsystem: "websocket", startedAt: openedAt, recoveredAt: null },
  ]);
  const storeAfterRestart = new IncidentStore(repo);

  await storeAfterRestart.init();
  assert.equal(
    storeAfterRestart.getDegradedSince("websocket"),
    openedAt.getTime(),
    "the restarted store must retain the persisted outage start",
  );

  await storeAfterRestart.exitDegraded("websocket");

  const row = repo.rows[0];
  assert.ok(row.recoveredAt !== null, "recovery must be persisted after restart");
  const durationSecs = getIncidentDurationSecs(row.startedAt, row.recoveredAt);
  assert.ok(
    durationSecs !== null && durationSecs >= outageDurationMs / 1000,
    `duration should include the restart gap, got ${durationSecs}s`,
  );
});

test("incident duration is never negative when persisted timestamps span clock skew", () => {
  const startedAt = new Date("2026-08-23T12:00:00.000Z");
  const recoveredAt = new Date("2026-08-23T11:59:59.000Z");

  assert.equal(
    getIncidentDurationSecs(startedAt, recoveredAt),
    0,
    "clock skew must be clamped to a zero-second duration",
  );
  assert.equal(
    getIncidentDurationSecs(startedAt, null),
    null,
    "open incidents must keep a null duration",
  );
});

test("init() restores a committed incident after a crash before enterDegraded() returns", async () => {
  const repo = makeFakeRepo();
  const realInsert = repo.insertIncident.bind(repo);
  let rowWritten!: () => void;
  const written = new Promise<void>(resolve => { rowWritten = resolve; });
  let releaseInsertReturn!: () => void;
  const insertReturnGate = new Promise<void>(resolve => { releaseInsertReturn = resolve; });

  // A database commit can complete before the request which performed it
  // returns to the process. Hold that return open to model a SIGKILL/OOM at
  // precisely that point; the row remains durable in the shared repository.
  repo.insertIncident = async (subsystem, startedAt, reason) => {
    const result = await realInsert(subsystem, startedAt, reason);
    rowWritten();
    await insertReturnGate;
    return result;
  };

  const storeBeforeCrash = new IncidentStore(repo);
  const enterBeforeCrash = storeBeforeCrash.enterDegraded("websocket", "feed stopped");
  await written;

  // This is the new process after restart. It must reconstruct the open
  // incident from the durable row rather than depending on the old map.
  const storeAfterRestart = new IncidentStore(repo);
  await storeAfterRestart.init();

  assert.equal(repo.rows.length, 1, "the committed row must survive the simulated crash");
  assert.equal(repo.rows[0].recoveredAt, null, "the restored incident must still be open");
  assert.equal(
    storeAfterRestart.getDegradedSince("websocket"),
    repo.rows[0].startedAt.getTime(),
    "restart must restore the durable incident timestamp",
  );

  // Release the held call so the test does not leave an unresolved operation
  // behind; the restart assertion above already occurred before this point.
  releaseInsertReturn();
  await enterBeforeCrash;
});

test("concurrent stores write only one open row through the uniqueness constraint", async () => {
  const repo = makeFakeRepo();
  const realInsert = repo.insertIncident.bind(repo);
  let insertAttempts = 0;
  let conflictCount = 0;
  let bothCallsReachedDb!: () => void;
  const bothReachedDb = new Promise<void>(resolve => { bothCallsReachedDb = resolve; });
  let releaseDb!: () => void;
  const dbGate = new Promise<void>(resolve => { releaseDb = resolve; });

  // Separate stores model concurrent callers that do not share the same
  // in-memory map. Both calls are held until they have reached the repository,
  // then the fake applies the partial-unique-index semantics at commit time.
  repo.insertIncident = async (subsystem, startedAt, reason) => {
    insertAttempts++;
    if (insertAttempts === 2) bothCallsReachedDb();
    await dbGate;
    const result = await realInsert(subsystem, startedAt, reason);
    if (!result) conflictCount++;
    return result;
  };

  const firstStore = new IncidentStore(repo);
  const secondStore = new IncidentStore(repo);
  const firstEnter = firstStore.enterDegraded("websocket");
  const secondEnter = secondStore.enterDegraded("websocket");

  await bothReachedDb;
  releaseDb();
  await Promise.all([firstEnter, secondEnter]);

  assert.equal(insertAttempts, 2, "both concurrent callers must reach the database");
  assert.equal(conflictCount, 1, "one insert must be rejected by the open-row uniqueness constraint");
  assert.equal(repo.rows.length, 1, "only one open incident row may be written");
  assert.equal(repo.rows[0].recoveredAt, null, "the surviving incident must remain open");
  assert.notEqual(firstStore.getDegradedSince("websocket"), null);
  assert.notEqual(secondStore.getDegradedSince("websocket"), null);
});

test("init() is idempotent — multiple calls do not duplicate state", async () => {
  const seed: FakeRow[] = [
    { id: 1, subsystem: "websocket", startedAt: msAgo(1 * HOUR), recoveredAt: null },
  ];
  const { store } = makeStore(seed);

  await store.init();
  await store.init(); // second call is a no-op

  // In-memory map should still reflect the single open incident.
  assert.ok(store.getDegradedSince("websocket") !== null, "still degraded after double init");
});

test("init() picks the oldest open row when multiple exist (data-integrity edge case)", async () => {
  const older  = msAgo(5 * HOUR);
  const newer  = msAgo(2 * HOUR);
  // Two open rows for the same subsystem — shouldn't happen in production but
  // init() must be resilient.
  const seed: FakeRow[] = [
    
{
 id: 1, subsystem: "websocket", startedAt: newer, recoveredAt: null 
}
,
    
{
 id: 2, subsystem: "websocket", startedAt: older, recoveredAt: null 
}
,
  ]
;

  const 
{
 store 
}
 = makeStore(seed)
;

  await store.init()
;


  assert.equal(
    store.getDegradedSince("websocket"),
    older.getTime(),
    "init() should keep the oldest startedAt when multiple open rows exist",
  )
;

}
)
;


test("restored volfeed incident clears when the first fresh tick resumes", async () => 
{

  const openedAt = msAgo(2 * HOUR)
;

  const 
{
 store, repo 
}
 = makeStore([
    
{
 id: 1, subsystem: "volfeed", startedAt: openedAt, recoveredAt: null 
}
,
  ])
;


  await store.init()
;

  assert.equal(store.getDegradedSince("volfeed"), openedAt.getTime())
;


  await store.exitDegraded("volfeed")
;


  assert.equal(store.getDegradedSince("volfeed"), null)
;

  assert.ok(repo.rows[0].recoveredAt !== null, "restored volfeed row must be marked recovered")
;

}
)
;


// ── (j) getDegradedSince reflects live in-memory state ────────────────────────

test("getDegradedSince returns null for a healthy subsystem", () => 
{

  const 
{
 store 
}
 = makeStore()
;

  assert.equal(store.getDegradedSince("websocket"), null)
;

}
)
;


test("full lifecycle: enter → exit → getDegradedSince transitions correctly", async () => 
{

  const 
{
 store 
}
 = makeStore()
;


  assert.equal(store.getDegradedSince("websocket"), null, "initially healthy")
;


  await store.enterDegraded("websocket")
;

  assert.ok(store.getDegradedSince("websocket") !== null, "degraded after enterDegraded")
;


  await store.exitDegraded("websocket")
;

  assert.equal(store.getDegradedSince("websocket"), null, "healthy again after exitDegraded")
;

}
)
;


// ── (l) database unreachable at startup — graceful degradation ───────────────
//
// Task #182: if the DB is down when the server boots, init() must still
// complete (not hang or throw and block server startup), and the store must
// keep working in memory-only mode afterward — enterDegraded/exitDegraded
// should never throw even though every DB call underneath them fails.

/** A repo whose every method rejects, simulating a fully unreachable database. */
function makeUnreachableRepo(): IncidentRepo 
{

  const dbDown = () => Promise.reject(new Error("ECONNREFUSED: database unreachable"))
;

  return {

    findOpenIncidents:   dbDown,
    insertIncident:      dbDown,
    findOpenIncident:    dbDown,
    stampRecovery:       dbDown,
    updateReason:        dbDown,
    findRecentIncidents: dbDown,
    deleteOldIncidents:  dbDown,
    countIncidents:      dbDown,
    deleteOldestRows:    dbDown,
  
}
;

}

test("init() stays ready after the DB is unreachable at startup", async () => {
  const repo = makeUnreachableRepo();
  let loadAttempts = 0;
  repo.findOpenIncidents = async () => {
    loadAttempts++;
    throw new Error("ECONNREFUSED: database unreachable");
  };
  const store = new IncidentStore(repo);

  // Must not reject — a startup DB outage must not crash server boot.
  await assert.doesNotReject(store.init());

  // A second call must be a no-op, proving init() marked the store ready even
  // though loading open incidents failed.
  await store.init();
  assert.equal(loadAttempts, 1, "a failed startup load must still leave init() complete and idempotent");
});


test("init() with an unreachable DB leaves every subsystem healthy (no state to restore)", async () => 
{

  const store = new IncidentStore(makeUnreachableRepo())
;

  await store.init()
;


  assert.equal(store.getDegradedSince("websocket"), null)
;

  assert.equal(store.getDegradedSince("database"),  null)
;

}
)
;


test("enterDegraded still updates in-memory state after an unreachable-DB init (memory-only mode)", async () => 
{

  const store = new IncidentStore(makeUnreachableRepo())
;

  await store.init()
;


  // Must not throw even though repo.insertIncident() rejects underneath it.
  await assert.doesNotReject(store.enterDegraded("database"))
;


  assert.ok(
    store.getDegradedSince("database") !== null,
    "enterDegraded must record degraded state in memory even when the DB write fails",
  )
;

}
)
;


test("exitDegraded still clears in-memory state after an unreachable-DB init (memory-only mode)", async () => 
{

  const store = new IncidentStore(makeUnreachableRepo())
;

  await store.init()
;


  await store.enterDegraded("database")
;

  assert.ok(store.getDegradedSince("database") !== null, "precondition: subsystem is degraded")
;


  // Must not throw even though repo.stampRecovery() would reject underneath it
  // (in this case it's never reached: the incident's id stays -1 because the
  // insert never succeeded, so exitDegraded takes the memory-only early return).
  await assert.doesNotReject(store.exitDegraded("database"))
;


  assert.equal(
    store.getDegradedSince("database"),
    null,
    "exitDegraded must clear in-memory state even in full memory-only mode",
  )
;

}
)
;


test("getIncidentCount24h and getIncidentTimestamps24h fall back gracefully when the DB is unreachable", async () => 
{

  const store = new IncidentStore(makeUnreachableRepo())
;

  await store.init()
;

  await store.enterDegraded("websocket")
;


  // Both reads catch internally and fall back to the in-memory open incident
  // rather than propagating the DB error.
  const count = await store.getIncidentCount24h("websocket")
;

  const timestamps = await store.getIncidentTimestamps24h("websocket")
;


  assert.equal(count, 1, "falls back to counting the single in-memory open incident")
;

  assert.equal(timestamps.length, 1, "falls back to returning the single in-memory timestamp")
;

}
)
;


test("pruneOldIncidents does not throw when the DB is unreachable", async () => 
{

  const store = new IncidentStore(makeUnreachableRepo())
;

  await store.init()
;
 // already runs an initial prune internally
  await assert.doesNotReject(store.pruneOldIncidents())
;

}
)
;


// ── (m) multiple subsystems are independent ───────────────────────────────────

test("multiple subsystems operate independently", async () => 
{

  const 
{
 store, repo 
}
 = makeStore()
;


  await store.enterDegraded("websocket")
;

  await store.enterDegraded("database")
;


  assert.equal(repo.rows.length, 2, "two separate rows should exist")
;

  assert.ok(store.getDegradedSince("websocket") !== null, "websocket degraded")
;

  assert.ok(store.getDegradedSince("database")  !== null, "database degraded")
;


  await store.exitDegraded("websocket")
;


  assert.equal(store.getDegradedSince("websocket"), null, "websocket recovered")
;

  assert.ok(store.getDegradedSince("database") !== null,  "database still degraded")
;


  const wsRow = repo.rows.find(r => r.subsystem === "websocket")!
;

  const dbRow = repo.rows.find(r => r.subsystem === "database")!
;


  assert.ok(wsRow.recoveredAt !== null, "websocket row should have recoveredAt")
;

  assert.equal(dbRow.recoveredAt, null, "database row should still be open")
;

}
)
;
