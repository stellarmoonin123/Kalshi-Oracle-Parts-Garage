/**
 * Regression coverage for the low-price contract admission path. These tests
 * exercise the price boundaries and the hard evidence that sits on top of the
 * weighted scorecard, without requiring a database-backed simulation run.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  canReusePreTradeAdmissionForRequote,
  doesPreTradeVerdictMatchEntryPrice,
  getPreTradeEntryPath,
  getLowPricePathFailure,
} from "./pre-trade-sim.js";
import { classifyTradePath, PATH_CONFIGS } from "./trade-path.js";

test("price paths use the exact 30¢ / 44¢ boundaries", () => {
  assert.equal(classifyTradePath(30), "MULTIPLIER");
  assert.equal(classifyTradePath(31), "GRAY");
  assert.equal(classifyTradePath(44), "GRAY");
  assert.equal(classifyTradePath(45), "HIGH_PROB");

  assert.equal(getPreTradeEntryPath(30), "MULTIPLIER");
  assert.equal(getPreTradeEntryPath(31), "INTERMEDIATE");
  assert.equal(getPreTradeEntryPath(45), "STANDARD");
});

test("multiplier and intermediate paths carry their stricter score, size, and EV settings", () => {
  assert.equal(PATH_CONFIGS.MULTIPLIER.minScore, 74);
  assert.equal(PATH_CONFIGS.MULTIPLIER.sizeMultiplier, 0.4);
  assert.equal(PATH_CONFIGS.MULTIPLIER.minEVCents, 7);
  // P-FILL LIVE, Part C (2026-08-26): lowered 68 -> 60 (clamped [55,68]).
  assert.equal(PATH_CONFIGS.GRAY.minScore, 60);
  assert.equal(PATH_CONFIGS.GRAY.sizeMultiplier, 0.75);
});

test("multiplier contracts need both 85-point component scores and aligned strong acceleration", () => {
  const base = {
    entryPath: "MULTIPLIER" as const,
    direction: "LONG" as const,
    momentumScore: 85,
    volatilityScore: 85,
    velocityAccel: 10,
  };
  assert.equal(getLowPricePathFailure(base), undefined);
  assert.match(
    getLowPricePathFailure({ ...base, momentumScore: 84 }) ?? "",
    /Recent Momentum 84\/100/,
  );
  assert.match(
    getLowPricePathFailure({ ...base, volatilityScore: 84 }) ?? "",
    /Volatility Regime 84\/100/,
  );
  assert.match(
    getLowPricePathFailure({ ...base, velocityAccel: -10 }) ?? "",
    /strong upward acceleration/,
  );
  assert.match(
    getLowPricePathFailure({ ...base, velocityAccel: 9 }) ?? "",
    /strong upward acceleration/,
  );
});

test("intermediate contracts do not inherit the deep multiplier component hard-gates", () => {
  assert.equal(getLowPricePathFailure({
    entryPath: "INTERMEDIATE",
    direction: "SHORT",
    momentumScore: 50,
    volatilityScore: 50,
    velocityAccel: 0,
  }), undefined);
});

test("a warmed verdict cannot cross an entry-price path boundary", () => {
  assert.equal(
    doesPreTradeVerdictMatchEntryPrice({ entryPriceCents: 45, entryPath: "STANDARD" }, 30),
    false,
  );
  assert.equal(
    doesPreTradeVerdictMatchEntryPrice({ entryPriceCents: 31, entryPath: "INTERMEDIATE" }, 30),
    false,
  );
  assert.equal(
    doesPreTradeVerdictMatchEntryPrice({ entryPriceCents: 30, entryPath: "MULTIPLIER" }, 30),
    true,
  );
});

test("a cancelled order cannot re-quote across a price-path boundary on its prior admission", () => {
  assert.equal(
    canReusePreTradeAdmissionForRequote(45, 30, { entryPriceCents: 45, entryPath: "STANDARD" }),
    false,
  );
  assert.equal(
    canReusePreTradeAdmissionForRequote(31, 30, { entryPriceCents: 31, entryPath: "INTERMEDIATE" }),
    false,
  );
  assert.equal(
    canReusePreTradeAdmissionForRequote(30, 29, { entryPriceCents: 30, entryPath: "MULTIPLIER" }),
    false,
    "same-tier multiplier re-quotes still need a fresh score and EV evaluation",
  );
  assert.equal(
    canReusePreTradeAdmissionForRequote(31, 32, { entryPriceCents: 31, entryPath: "INTERMEDIATE" }),
    false,
    "intermediate re-quotes also need a fresh entry evaluation",
  );
  assert.equal(
    canReusePreTradeAdmissionForRequote(45, 46, { entryPriceCents: 45, entryPath: "STANDARD" }),
    true,
    "the existing Standard-only re-quote behavior remains available",
  );
});