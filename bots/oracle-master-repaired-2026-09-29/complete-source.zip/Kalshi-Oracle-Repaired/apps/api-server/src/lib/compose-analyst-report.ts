/**
 * Oracle Analyst report from the live desk snapshot already on the page.
 * No Grok key. p = winRateAtPrice only. Chat stays Oracle.
 */
export const DESK_SNAPSHOT_MISSING = 'Desk snapshot missing — skip';

export type AnalystComposeMeta = {
  extraContext?: string | null;
  btcPrice?: number | null;
  timeframe?: string | null;
  minutesRemaining?: number | null;
  marketTicker?: string | null;
  contractStrike?: number | null;
};

const dash = '—';

function grab(ctx: string, re: RegExp): string | null {
  const m = ctx.match(re);
  if (!m) return null;
  const v = (m[1] ?? m[0]).trim();
  return v.length ? v : null;
}

function numFrom(s: string | null, re: RegExp): number | null {
  if (!s) return null;
  const m = s.replace(/,/g, '').match(re);
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isFinite(n) ? n : null;
}

export function hasDeskSnapshot(meta: AnalystComposeMeta): boolean {
  const ctx = meta.extraContext?.trim() ?? '';
  if (/## Desk Snapshot/i.test(ctx)) return true;
  const px = meta.btcPrice;
  return typeof px === 'number' && Number.isFinite(px) && px > 0 && /YES mid|secs left|paperMode:/i.test(ctx);
}

function parseSide(ctx: string): 'YES' | 'NO' | 'skip' {
  const m = ctx.match(/settlement-side call:\s*(YES|NO|skip)/i);
  if (!m) return 'skip';
  const v = m[1].toUpperCase();
  if (v === 'YES' || v === 'NO') return v;
  return 'skip';
}

function parseP(ctx: string): { raw: string; value: number | null } {
  const raw = grab(ctx, /p = winRateAtPrice:\s*(.+)$/m) ?? 'n/a';
  if (/n\/a/i.test(raw)) return { raw: 'n/a', value: null };
  const n = numFrom(raw, /(-?\d+(?:\.\d+)?)/);
  if (n == null) return { raw, value: null };
  const value = n > 1 ? n / 100 : n;
  return { raw, value };
}

function parseTicket(ctx: string): 'moving' | 'still' | 'unknown' {
  const t = (grab(ctx, /ticket:\s*(moving|still|unknown)/i) ?? 'unknown').toLowerCase();
  if (t === 'moving' || t === 'still') return t;
  return 'unknown';
}

function parseEdge(ctx: string, which: 'YES' | 'NO'): number | null {
  const re = which === 'YES'
    ? /YES edge\s+([-\d.]+)¢/
    : /NO edge\s+([-\d.]+)¢/;
  return numFrom(ctx, re);
}

function srLines(ctx: string): string[] {
  const block = ctx.split(/## Support & Resistance/i)[1];
  if (!block) return [];
  const next = block.split(/^## /m)[0];
  return next.split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('#'));
}

function momentumLine(ctx: string): string | null {
  return grab(ctx, /^Momentum:\s*(.+)$/m);
}

export function composeAnalystReport(meta: AnalystComposeMeta): string {
  const ctx = meta.extraContext?.trim() ?? '';
  if (!hasDeskSnapshot(meta)) {
    throw new Error(DESK_SNAPSHOT_MISSING);
  }

  const paperRaw = grab(ctx, /paperMode:\s*(.+)$/m);
  const paperMode = paperRaw ? !/false/i.test(paperRaw.split(' ')[0]) : true;
  const cash = grab(ctx, /cash:\s*(.+)$/m) ?? dash;
  const quotes = grab(ctx, /^(YES mid .+)$/m) ?? dash;
  const secsStrike = grab(ctx, /secs left:\s*(.+)$/m) ?? dash;
  const secsLeft = numFrom(secsStrike, /^(-?\d+)/)
    ?? (typeof meta.minutesRemaining === 'number' ? Math.round(meta.minutesRemaining * 60) : null);
  const strikeFromMeta = meta.contractStrike != null && Number.isFinite(meta.contractStrike)
    ? `$${meta.contractStrike.toLocaleString()}`
    : null;
  const btc = grab(ctx, /BTC proxy:\s*(.+)$/m)
    ?? (meta.btcPrice != null && meta.btcPrice > 0
      ? `$${meta.btcPrice.toLocaleString(undefined, { maximumFractionDigits: 2 })}`
      : dash);
  const exchanges = grab(ctx, /^(Coinbase .+)$/m) ?? dash;
  const lag = grab(ctx, /lag meter:\s*(.+)$/m) ?? dash;
  const pathConf = grab(ctx, /path conf:\s*(.+)$/m) ?? dash;
  const settleNote = grab(ctx, /settlement-side call:\s*(.+)$/m) ?? 'skip';
  const side = parseSide(ctx);
  const p = parseP(ctx);
  const evLine = grab(ctx, /EV ¢:\s*(.+)$/m) ?? dash;
  const kelly = grab(ctx, /Kelly:\s*(.+)$/m) ?? 'frac cap 0.60 (locked). Contracts: sized at entry, not this tick';
  const ticket = parseTicket(ctx);
  const openPos = grab(ctx, /open position:\s*(.+)$/m) ?? 'none';
  const failClosed = grab(ctx, /fail-closed:\s*(.+)$/m)
    ?? 'engines skip on stale book / lag disagree / missing p; never cut EV 3¢ / OTM 5¢ / PATH MULT 7¢';
  const evYes = parseEdge(ctx, 'YES');
  const evNo = parseEdge(ctx, 'NO');
  const lastEdge = numFrom(ctx, /lastEdge\s+([-\d.]+)/);
  const yesAsk = grab(quotes, /YES mid.*?ask\s+(\d+¢)/)
    ?? grab(ctx, /YES \d+¢ bid \d+¢ ask (\d+¢)/);
  const mom = momentumLine(ctx);
  const sr = srLines(ctx);
  const ticker = meta.marketTicker?.trim() || grab(ctx, /Kalshi market:\s*(.+)$/m) || 'KXBTC15M';
  const tf = meta.timeframe?.trim() || '15m';
  const stale = /STALE/i.test(lag);
  const pMissing = p.value == null;
  const late = secsLeft != null && secsLeft < 90;
  const edgeForSide = side === 'YES' ? evYes : side === 'NO' ? evNo : null;
  const edgeOk = edgeForSide != null && edgeForSide >= 3;

  const risks: string[] = [];
  if (pMissing) risks.push('p = winRateAtPrice is n/a — do not substitute path conf / bot score / liveModelProb / fill-path.');
  if (ticket === 'still') risks.push('Still ticket — skip.');
  if (ticket === 'unknown') risks.push('Ticket velocity unknown — skip is valid.');
  if (stale) risks.push('Stale quote — engines fail closed.');
  if (late) risks.push(`${secsLeft}s left (<90s) — skip / wait.`);
  if (side === 'skip') risks.push('Settlement-side is skip.');
  if (edgeForSide != null && edgeForSide < 3) {
    risks.push(`EV ${edgeForSide.toFixed(1)}¢ is below the 3¢ floor — do not cut EV / Kelly.`);
  }
  if (evYes != null && evNo != null && Math.sign(evYes) !== Math.sign(evNo) && Math.abs(evYes) < 3 && Math.abs(evNo) < 3) {
    risks.push('Mixed / thin edges — skip is valid.');
  }
  if (!risks.length) risks.push('No hard skip named from this snapshot; still paper-only.');

  let rec: 'TRADE YES' | 'TRADE NO' | 'SKIP' | 'WAIT' = 'SKIP';
  let why: string;
  if (late && (pMissing || side === 'skip' || ticket !== 'moving')) {
    rec = 'WAIT';
    why = 'Clock is late and the snapshot is not a clean moving ticket with p — wait this period.';
  } else if (
    (side === 'YES' || side === 'NO')
    && !pMissing
    && ticket === 'moving'
    && !stale
    && !late
    && edgeOk
  ) {
    rec = side === 'YES' ? 'TRADE YES' : 'TRADE NO';
    why = `Settlement-side ${side}, p given, EV ${edgeForSide!.toFixed(1)}¢ ≥ 3¢, ticket moving, paper only.`;
  } else {
    rec = 'SKIP';
    why = risks[0] ?? 'Skip is valid. Paper first.';
  }

  const recBody = rec.startsWith('TRADE')
    ? `- ${rec.replace('TRADE ', '')} paper only. Limit ${yesAsk ?? 'ask'} or better. Never live. Never loosen floors. Size: Kelly cap 0.60, contracts sized at entry.`
    : `- No order. Size: none this tick (Kelly cap 0.60 stays locked).`;

  const snapshotLines = [
    `- paperMode: ${paperMode ? 'true (LOCKED paper — never recommend paperMode false)' : 'true (desk lock is paper; never go live)'}`,
    `- cash: ${cash}`,
    `- ${quotes}`,
    `- secs left / strike: ${secsStrike}${strikeFromMeta && !/strike/i.test(secsStrike) ? ` | strike ${strikeFromMeta}` : ''}`,
    `- BTC: ${btc}`,
    `- ${exchanges}`,
    `- lag: ${lag}`,
    `- ticket: ${ticket} (still tickets skip)`,
    `- open position: ${openPos}`,
    `- market: ${ticker} · tf ${tf}`,
  ];
  if (mom) snapshotLines.push(`- velocity: ${mom}`);
  if (sr.length) snapshotLines.push(`- S/R: ${sr.slice(0, 4).join(' · ')}`);

  return [
    '**Snapshot**',
    ...snapshotLines,
    '',
    '**Side call**',
    `- Settlement-side: ${side}${settleNote && settleNote !== side ? ` — ${settleNote}` : ''}`,
    `- p = winRateAtPrice: ${pMissing ? 'n/a (not path conf, not hunter, not liveModelProb, not fill-path)' : p.raw}`,
    `- Path conf: ${pathConf} — NOT p`,
    '',
    '**Numbers**',
    `- EV ¢: ${evLine}`,
    `- ask: YES ${yesAsk ?? dash}`,
    `- Kelly: ${kelly}`,
    `- lastEdge: ${lastEdge == null ? dash : lastEdge.toFixed(1)}`,
    `- Fail-closed: ${failClosed}`,
    '',
    '**Risks / skips**',
    ...risks.map((r) => `- ${r}`),
    '- Never cut EV 3¢ / OTM 5¢ / PATH MULT 7¢. Never turn on unproven strategies.',
    '',
    '**Oracle recommendation**',
    `- ${rec}`,
    `- ${why}`,
    recBody,
    '',
    `**Best action right now: ${rec}.**`,
  ].join('\n');
}
