/**
 * Feed stall reset + locked freshness stack (2026-09-07).
 * No live socket. EV/Kelly/ask door untouched.
 */
import assert from "node:assert/strict";
import test from "node:test";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  shouldApplyRestQuote,
  hasExecutableKalshiAsk,
  isWsSideAskFresh,
  REST_REFRESH_QUOTE_MS,
  PRICE_POLL_HEALTHY_MS,
  PRICE_POLL_DEGRADED_MS,
  kalshiWS,
  type KalshiTick,
} from "./kalshi-ws.js";
import { nextInvalidKalshiPriceTicks } from "./strategy-gates.js";
import { MONEY_GATE_NO_TAPE_MS } from "./money-gate-card.js";

test("freshness constants: NO_TAPE 5s; REST 250/200; refresh 1s; bot tick 250/100", () => {
  assert.equal(MONEY_GATE_NO_TAPE_MS, 5_000);
  assert.equal(PRICE_POLL_HEALTHY_MS, 250);
  assert.equal(PRICE_POLL_DEGRADED_MS, 200);
  assert.equal(REST_REFRESH_QUOTE_MS, 1_000);
  const botSrc = fs.readFileSync(
    path.join(path.dirname(fileURLToPath(import.meta.url)), "trading-bot.ts"),
    "utf8",
  );
  assert.ok(botSrc.includes("TICK_IDLE_INTERVAL_MS"), "bot imports/uses TICK_IDLE_INTERVAL_MS");
  assert.ok(botSrc.includes("TICK_MIN_INTERVAL_MS"), "bot imports/uses TICK_MIN_INTERVAL_MS");
  const guards = fs.readFileSync(
    path.join(path.dirname(fileURLToPath(import.meta.url)), "organs/entry-guards.ts"),
    "utf8",
  );
  assert.ok(guards.includes("export const TICK_IDLE_INTERVAL_MS = 250"));
  assert.ok(guards.includes("export const TICK_MIN_INTERVAL_MS = 100"));
  assert.ok(PRICE_POLL_DEGRADED_MS < PRICE_POLL_HEALTHY_MS);
});

test("hasExecutableKalshiAsk: either side 1–99¢; rejects 0/100 and missing", () => {
  assert.equal(hasExecutableKalshiAsk({ yesAsk: 36, noAsk: 100 }), true);
  assert.equal(hasExecutableKalshiAsk({ yesAsk: 0, noAsk: 42 }), true);
  assert.equal(hasExecutableKalshiAsk({ yesAsk: 0, noAsk: 100 }), false);
  assert.equal(hasExecutableKalshiAsk(null), false);
  assert.equal(isWsSideAskFresh(36), true);
  assert.equal(isWsSideAskFresh(0), false);
  assert.equal(isWsSideAskFresh(100), false);
});

test("shouldApplyRestQuote: invalid 0/100 WS book forces REST even if quoteTs fresh", () => {
  const now = 5_000_000_000;
  assert.equal(shouldApplyRestQuote({
    lastWsMessageTs: now - 50,
    latest: {
      source: "ws",
      quoteTs: now - 50,
      yesBid: 0,
      yesAsk: 0,
      noBid: 0,
      noAsk: 100,
    },
    restHasQuotes: true,
    nowMs: now,
  }), "apply_fallback");
});

test("shouldApplyRestQuote: live executable WS <1s still skips REST", () => {
  const now = 5_000_000_000;
  assert.equal(shouldApplyRestQuote({
    lastWsMessageTs: now - 100,
    latest: {
      source: "ws",
      quoteTs: now - 400,
      yesBid: 35,
      yesAsk: 36,
      noBid: 63,
      noAsk: 65,
    },
    restHasQuotes: true,
    nowMs: now,
  }), "skip_ws_live");
});

test("nextInvalidKalshiPriceTicks: resets immediately when either ask is 1–99¢", () => {
  let n = 0;
  n = nextInvalidKalshiPriceTicks(n, { yesAsk: 0, noAsk: 100 });
  assert.equal(n, 1);
  n = nextInvalidKalshiPriceTicks(n, { yesAsk: 0, noAsk: 100 });
  assert.equal(n, 2);
  for (let i = 0; i < 83; i++) n = nextInvalidKalshiPriceTicks(n, { yesAsk: 0, noAsk: 100 });
  assert.equal(n, 85);
  n = nextInvalidKalshiPriceTicks(n, { yesAsk: 36, noAsk: 100 });
  assert.equal(n, 0, "must not latch 85 after recovery");
  n = nextInvalidKalshiPriceTicks(7, { yesAsk: 0, noAsk: 55 });
  assert.equal(n, 0);
});

test("WS one-sided valid ask (bid=0) adopts ask — does not keep prior 0/100", async () => {
  type WsInternals = {
    active: { ticker: string; floorStrike: number; closeTime: string };
    latest: KalshiTick | null;
    handleMessage: (raw: string) => void;
    _lastQuoteSig: string;
  };
  const internals = kalshiWS as unknown as WsInternals;
  const originalActive = internals.active;
  const originalLatest = internals.latest;
  const originalQuoteSig = internals._lastQuoteSig;
  try {
    internals.active = {
      ticker: "KXBTC15M-STALL-TEST",
      floorStrike: 79_000,
      closeTime: new Date(Date.now() + 10 * 60_000).toISOString(),
    };
    internals.latest = null;
    internals._lastQuoteSig = "";
    const readTick = (): KalshiTick | null => internals.latest;

    internals.handleMessage(JSON.stringify({
      type: "ticker",
      msg: {
        market_ticker: "KXBTC15M-STALL-TEST",
        yes_bid: 0, yes_ask: 0, no_bid: 0, no_ask: 100,
        volume: 1, open_interest: 1,
      },
    }));
    assert.equal(readTick()?.noAsk, 100);
    assert.equal(hasExecutableKalshiAsk(readTick()), false);
    assert.equal(readTick()?.quoteTs ?? 0, 0);

    await new Promise(r => setTimeout(r, 5));
    internals.handleMessage(JSON.stringify({
      type: "ticker",
      msg: {
        market_ticker: "KXBTC15M-STALL-TEST",
        yes_bid: 0, yes_ask: 36, no_bid: 0, no_ask: 0,
        volume: 2, open_interest: 2,
      },
    }));
    assert.equal(readTick()?.yesAsk, 36, "must adopt valid ask without requiring bid");
    assert.equal(hasExecutableKalshiAsk(readTick()), true);
    assert.ok((readTick()?.quoteTs ?? 0) > 0);
  } finally {
    internals.active = originalActive;
    internals.latest = originalLatest;
    internals._lastQuoteSig = originalQuoteSig;
  }
});
