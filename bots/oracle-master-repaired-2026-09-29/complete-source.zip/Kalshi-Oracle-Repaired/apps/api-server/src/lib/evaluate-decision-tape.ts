/**
 * Evaluate skip/take tape. Observational. Does not gate fills.
 * Every evaluate writes one jsonl line: R_t, packId, side-or-skip, pWin, EV, asks.
 * Junk lastModelProb=1 / lastEdge=50 / yesAsk-as-fillAsk=91 is stripped.
 */
import fs from "node:fs";
import path from "node:path";
import { fillPathPWin } from "./organs/probability.js";
import type { LoggedPackId, RegimeDecisionTrace, VolBucket, ShapeId, CycleMicro, CycleHtf } from "./organs/regime.js";
import { maybeRotateJsonl, DECISION_TRACE_ROTATE } from "./jsonl-rotate.js";

export const EVALUATE_DECISION_KIND = "evaluate_decision" as const;
export const LIVE_APPLY = false as const;

export type SideOrSkip = "yes" | "no" | "skip";

export type EvaluateRt = {
  vol: VolBucket;
  shape: ShapeId;
  cycleMicro: CycleMicro;
  cycleHtf: CycleHtf;
  confidence: number;
  lagUsed: boolean;
};

export type EvaluateDecisionRow = {
  kind: typeof EVALUATE_DECISION_KIND;
  ts: number;
  ticker: string;
  R_t: EvaluateRt | null;
  packId: LoggedPackId | string | null;
  sideOrSkip: SideOrSkip;
  outcome: "TAKE" | "SKIP";
  pWin: number | null;
  evCents: number | null;
  yesAsk: number | null;
  noAsk: number | null;
  fillAsk: number | null;
  strategyId: string | null;
  skipReason: string | null;
  rawCode: string | null;
  liveApply: false;
};

const JUNK_P_MAX = 0.95; // fill-path curves never emit 1.0 / mass-as-p
const JUNK_EDGE_PCT_EV = 50; // lastEdge percent was logged as ev

export function finiteOrNull(n: unknown): number | null {
  return typeof n === "number" && Number.isFinite(n) ? n : null;
}

/** winRateAtPrice only. Never confidence, never P(YES)=1, never lastModelProb default. */
export function honestPWin(p: unknown): number | null {
  const v = fillPathPWin(typeof p === "number" ? p : null);
  if (v == null) return null;
  if (v >= JUNK_P_MAX) return null;
  return v;
}

/** Fee-net EV cents. Never lastEdge percent (50). */
export function honestEvCents(ev: unknown, pWin: number | null): number | null {
  const v = finiteOrNull(ev);
  if (v == null) return null;
  if (pWin == null && Math.abs(v) === JUNK_EDGE_PCT_EV) return null;
  return v;
}

export function honestAsk(ask: unknown): number | null {
  const v = finiteOrNull(ask);
  if (v == null) return null;
  if (v < 0 || v > 100) return null;
  return v;
}

export function fillAskForSide(
  side: SideOrSkip | "yes" | "no" | undefined,
  yesAsk: number | null,
  noAsk: number | null,
): number | null {
  if (side === "yes") return yesAsk;
  if (side === "no") return noAsk;
  return null;
}

export function sanitizeEvaluatePricing(input: {
  pWin?: unknown;
  evCents?: unknown;
  yesAsk?: unknown;
  noAsk?: unknown;
  side?: SideOrSkip | "yes" | "no" | null;
}): {
  pWin: number | null;
  evCents: number | null;
  yesAsk: number | null;
  noAsk: number | null;
  fillAsk: number | null;
  sideOrSkip: SideOrSkip;
} {
  const yesAsk = honestAsk(input.yesAsk);
  const noAsk = honestAsk(input.noAsk);
  const sideOrSkip: SideOrSkip =
    input.side === "yes" || input.side === "no" ? input.side : "skip";
  const pWin = honestPWin(input.pWin);
  return {
    pWin,
    evCents: honestEvCents(input.evCents, pWin),
    yesAsk,
    noAsk,
    fillAsk: fillAskForSide(sideOrSkip, yesAsk, noAsk),
    sideOrSkip,
  };
}

export function isEvaluateDecisionRow(x: unknown): x is EvaluateDecisionRow {
  if (!x || typeof x !== "object") return false;
  const r = x as Record<string, unknown>;
  if (r.kind !== EVALUATE_DECISION_KIND) return false;
  if (r.liveApply !== false) return false;
  if (r.outcome !== "TAKE" && r.outcome !== "SKIP") return false;
  if (r.sideOrSkip !== "yes" && r.sideOrSkip !== "no" && r.sideOrSkip !== "skip") return false;
  if (typeof r.ts !== "number") return false;
  if (typeof r.ticker !== "string") return false;
  if (!("R_t" in r) || !("packId" in r) || !("pWin" in r) || !("evCents" in r)) return false;
  if (!("yesAsk" in r) || !("noAsk" in r) || !("fillAsk" in r)) return false;
  if (r.pWin === 1) return false;
  return true;
}

export function resolveEvaluateDecisionPath(): string {
  if (process.env.EVALUATE_DECISION_TRACE_PATH) {
    return path.resolve(process.env.EVALUATE_DECISION_TRACE_PATH);
  }
  return path.resolve(process.cwd(), "data", "evaluate-decision-trace.jsonl");
}


/** Tail-read evaluate-decision-trace.jsonl for desk/traces PG fallback. Newest-first. */
export function readRecentEvaluateDecisions(opts?: {
  limit?: number;
  offset?: number;
  strategyId?: string;
  ticker?: string;
}): { traces: EvaluateDecisionRow[]; total: number; source: "evaluate-decision-trace.jsonl" } {
  const limit = Math.min(Math.max(opts?.limit ?? 50, 1), 500);
  const offset = Math.max(opts?.offset ?? 0, 0);
  const file = resolveEvaluateDecisionPath();
  let raw = "";
  try {
    if (!fs.existsSync(file)) {
      return { traces: [], total: 0, source: "evaluate-decision-trace.jsonl" };
    }
    const st = fs.statSync(file);
    const maxBytes = 2_500_000;
    const fd = fs.openSync(file, "r");
    try {
      const start = Math.max(0, st.size - maxBytes);
      const buf = Buffer.alloc(st.size - start);
      fs.readSync(fd, buf, 0, buf.length, start);
      raw = buf.toString("utf8");
    } finally {
      fs.closeSync(fd);
    }
  } catch {
    return { traces: [], total: 0, source: "evaluate-decision-trace.jsonl" };
  }
  const lines = raw.split("\n");
  // Drop possibly-truncated first line when we mid-seeked into the file.
  if (lines.length > 0 && lines[0] && !lines[0].trim().startsWith("{")) lines.shift();
  const rows: EvaluateDecisionRow[] = [];
  for (const line of lines) {
    const t = line.trim();
    if (!t) continue;
    try {
      const parsed = JSON.parse(t) as unknown;
      if (!isEvaluateDecisionRow(parsed)) continue;
      if (opts?.strategyId && parsed.strategyId !== opts.strategyId) continue;
      if (opts?.ticker && parsed.ticker !== opts.ticker) continue;
      rows.push(parsed);
    } catch {
      /* skip bad line */
    }
  }
  rows.sort((a, b) => b.ts - a.ts);
  const total = rows.length;
  return {
    traces: rows.slice(offset, offset + limit),
    total,
    source: "evaluate-decision-trace.jsonl",
  };
}

export function appendEvaluateDecision(row: EvaluateDecisionRow): void {
  if (process.env.EVALUATE_DECISION_TRACE_DISABLE === "1") return;
  try {
    const file = resolveEvaluateDecisionPath();
    const dir = path.dirname(file);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const priced = sanitizeEvaluatePricing({
      pWin: row.pWin,
      evCents: row.evCents,
      yesAsk: row.yesAsk,
      noAsk: row.noAsk,
      side: row.outcome === "TAKE" ? row.sideOrSkip : row.sideOrSkip,
    });
    const safe: EvaluateDecisionRow = {
      ...row,
      kind: EVALUATE_DECISION_KIND,
      liveApply: false,
      pWin: priced.pWin,
      evCents: priced.evCents,
      yesAsk: priced.yesAsk,
      noAsk: priced.noAsk,
      fillAsk: row.outcome === "SKIP" && row.sideOrSkip === "skip"
        ? null
        : (priced.fillAsk ?? honestAsk(row.fillAsk)),
    };
    maybeRotateJsonl(file, DECISION_TRACE_ROTATE);
    fs.appendFileSync(file, `${JSON.stringify(safe)}\n`, "utf8");
  } catch {
    /* observational */
  }
}

export function rowFromRegimeTrace(
  trace: RegimeDecisionTrace,
  extra: {
    ticker?: string;
    outcome?: "TAKE" | "SKIP";
    sideOrSkip?: SideOrSkip;
    strategyId?: string | null;
    rawCode?: string | null;
    yesAsk?: number | null;
    noAsk?: number | null;
    pWin?: number | null;
    evCents?: number | null;
  } = {},
): EvaluateDecisionRow {
  const priced = sanitizeEvaluatePricing({
    pWin: extra.pWin ?? trace.p,
    evCents: extra.evCents ?? trace.ev,
    yesAsk: extra.yesAsk,
    noAsk: extra.noAsk,
    side: extra.sideOrSkip,
  });
  const side = extra.sideOrSkip ?? "skip";
  return {
    kind: EVALUATE_DECISION_KIND,
    ts: trace.ts,
    ticker: extra.ticker ?? "UNKNOWN",
    R_t: trace.R_t,
    packId: trace.packId,
    sideOrSkip: side,
    outcome: extra.outcome ?? "SKIP",
    pWin: priced.pWin,
    evCents: priced.evCents,
    yesAsk: priced.yesAsk,
    noAsk: priced.noAsk,
    fillAsk: fillAskForSide(side, priced.yesAsk, priced.noAsk),
    strategyId: extra.strategyId ?? null,
    skipReason: trace.skipReason,
    rawCode: extra.rawCode ?? null,
    liveApply: false,
  };
}
