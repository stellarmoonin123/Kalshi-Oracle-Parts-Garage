/**
 * market-learning-v2.test.ts — GO: MARKET-LEARNING v2 (SHADOW EV + STATE
 * MACHINE, ZERO LIVE APPLY), 2026-08-24.
 *
 * Covers the pure, DB-free functions: shadow EV tiering/side-selection,
 * displacement tracking, spread/volume-score proxies, and the canary
 * admission envelope.
 *
 * Deliberately does NOT exercise applyLearningMode()/getLearningState()
 * against the real database: learning_state is a live singleton row this
 * same test run's api-server process reads concurrently, and flipping it
 * to canary/full even briefly — however quickly restored — would violate
 * this feature's own "zero live behavior change" requirement. State
 * machine transition rules are instead verified by direct code review of
 * VALID_TRANSITIONS (see the module) plus the manual verification steps
 * recorded in the accompanying docs file.
 *
 * Run with:
 *   node --experimental-strip-types src/lib/market-learning-v2.test.ts
 */

import test from "node:test";
import assert from "node:assert/strict";
import {
  computeShadowDecision,
  trackDisplacement,
  computeSpreadCents,
  proxyVolumeScore,
  evaluateCanaryAdmission,
  CANARY_ENVELOPE,
  type ShadowDecisionInput,
} from "./market-learning-v2.js";

function baseInput(overrides: Partial<ShadowDecisionInput> = {}): ShadowDecisionInput {
  return {
    ticker: "KXBTC15M-TEST",
    periodOpenTs: new Date("2026-08-24T21:00:00Z"),
    secsRemaining: 600,
    yesAskCents: 50,
    noAskCents: 50,
    leadExchangeDelta: null,
    distFromFloorPct: null,
    spreadCents: 0,
    ...overrides,
  };
}

test("computeShadowDecision: neutral p_up (no bucket history) at 50/50 asks skips (fee/slippage make it a loser)", () => {
  const result = computeShadowDecision(baseInput());
  assert.ok(result, "expected a result when both asks are present");
  assert.equal(result!.action, "SKIP");
  assert.equal(result!.sampleSize, 0, "unseeded bucket cache must report sampleSize 0, never a fabricated count");
});

test("computeShadowDecision: missing an ask price returns null (cannot evaluate either side)", () => {
  const result = computeShadowDecision(baseInput({ yesAskCents: null }));
  assert.equal(result, null);
});

test("computeShadowDecision: never returns TAKE_PROBE/TAKE_BASE below the mirrored live EV floor", () => {
  // Even with a deliberately generous ask spread, a 50/50 model can't clear
  // fee+slippage — this pins down that the floor is enforced, not skipped.
  for (const yesAskCents of [10, 30, 50, 70, 90]) {
    const result = computeShadowDecision(baseInput({ yesAskCents, noAskCents: 100 - yesAskCents }));
    assert.ok(result);
    if (result!.action !== "SKIP") {
      assert.ok(result!.evHatCents >= 3, `action ${result!.action} logged with evHatCents ${result!.evHatCents} below the 3c live floor`);
    }
  }
});

test("computeShadowDecision: picks the higher-EV side, not always YES", () => {
  // Cheap NO ask with a neutral model should still be a losing trade net of
  // fee, but the side comparison itself must prefer whichever ask is cheaper
  // when p_up is neutral (symmetric fee curve) — verify no side bias exists.
  const cheapYes = computeShadowDecision(baseInput({ yesAskCents: 20, noAskCents: 80 }));
  const cheapNo  = computeShadowDecision(baseInput({ yesAskCents: 80, noAskCents: 20 }));
  assert.ok(cheapYes && cheapNo);
  assert.equal(cheapYes!.side, "YES");
  assert.equal(cheapNo!.side, "NO");
});

test("trackDisplacement: first observation of a period anchors at 0", () => {
  const d = trackDisplacement("__TEST_TICKER_DISP__", 1_000_000, 79_000);
  assert.equal(d, 0);
});

test("trackDisplacement: later observations in the same period return the delta from the anchor", () => {
  trackDisplacement("__TEST_TICKER_DISP_2__", 2_000_000, 79_000);
  const d = trackDisplacement("__TEST_TICKER_DISP_2__", 2_000_000, 79_050);
  assert.equal(d, 50);
});

test("trackDisplacement: a new periodOpenTs for the same ticker resets the anchor", () => {
  trackDisplacement("__TEST_TICKER_DISP_3__", 3_000_000, 79_000);
  trackDisplacement("__TEST_TICKER_DISP_3__", 3_000_000, 79_100); // displacement +100 in period A
  const resetToZero = trackDisplacement("__TEST_TICKER_DISP_3__", 4_000_000, 80_000); // new period
  assert.equal(resetToZero, 0);
});

test("trackDisplacement: null fairPrice returns null without disturbing the cached anchor", () => {
  trackDisplacement("__TEST_TICKER_DISP_4__", 5_000_000, 79_000);
  const nullResult = trackDisplacement("__TEST_TICKER_DISP_4__", 5_000_000, null);
  assert.equal(nullResult, null);
  const stillAnchored = trackDisplacement("__TEST_TICKER_DISP_4__", 5_000_000, 79_010);
  assert.equal(stillAnchored, 10);
});

test("computeSpreadCents: standard binary-market overround formula", () => {
  assert.equal(computeSpreadCents(52, 51), 3);
  assert.equal(computeSpreadCents(50, 50), 0);
  assert.equal(computeSpreadCents(null, 50), null);
});

test("proxyVolumeScore: narrower spread scores higher, unknown spread is neutral", () => {
  assert.equal(proxyVolumeScore(null), 0.5);
  assert.ok(proxyVolumeScore(1) > proxyVolumeScore(8));
  assert.equal(proxyVolumeScore(0), 1);
  assert.equal(proxyVolumeScore(20), 0, "must clamp at 0, never go negative");
});

test("evaluateCanaryAdmission: blocks at the daily trade cap", () => {
  const result = evaluateCanaryAdmission({ canaryTradesToday: CANARY_ENVELOPE.maxCanaryTradesPerDay, canaryPnlPctEquityToday: 0 });
  assert.equal(result.allowed, false);
});

test("evaluateCanaryAdmission: blocks at the daily loss cap", () => {
  const result = evaluateCanaryAdmission({ canaryTradesToday: 0, canaryPnlPctEquityToday: -CANARY_ENVELOPE.maxCanaryDailyLossPctEquity });
  assert.equal(result.allowed, false);
});

test("evaluateCanaryAdmission: allows a trade well inside both caps", () => {
  const result = evaluateCanaryAdmission({ canaryTradesToday: 1, canaryPnlPctEquityToday: -0.5 });
  assert.equal(result.allowed, true);
});

test("CANARY_ENVELOPE: sizeMult stays well inside the live 9%-of-equity hard cap band", () => {
  assert.ok(CANARY_ENVELOPE.sizeMult > 0 && CANARY_ENVELOPE.sizeMult <= 1);
  assert.ok(CANARY_ENVELOPE.maxCanaryDailyLossPctEquity < 9, "canary envelope must be strictly tighter than the live 9% hard cap, not equal to or looser than it");
});
