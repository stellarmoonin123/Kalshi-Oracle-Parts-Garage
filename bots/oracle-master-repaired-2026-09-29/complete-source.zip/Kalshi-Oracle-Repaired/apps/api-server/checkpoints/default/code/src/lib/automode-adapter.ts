/**
 * automode-adapter.ts
 *
 * autoMode true = ADAPTATION that can stay ON.
 *   - skip more when FRESH Coinbase lag disagrees (exempt CONFLUENCE_CASCADE)
 *   - size down in drawdown / thin tape (multiplier ≤ 1, never up)
 *   - DEAD/LOW tape haircuts size; does not starve CC via global TAPE_LIE
 *   - learn skip/size/regime from BOT fills only, clamped 0.72–1.18x
 *
 * NEVER: cut EV / Kelly / 9% / minConfidence / minEntry
 * NEVER: enable engines
 * NEVER: paperMode false
 * NEVER: empty disabledStrategies
 *
 * The OLD composer that copied condition-adapter over minConfidence /
 * minVelocity / stops / window / minProbEdge is FAIL-CLOSED even when
 * autoMode is true. This module does not produce those fields.
 *
 * Pure compute. No config/DB/live writes. Callers gate on autoMode.
 */

export const LEARNING_WEIGHT_MIN = 0.72;
export const LEARNING_WEIGHT_MAX = 1.18;

/** Keys the old composer used to overwrite. Adapter output must never carry them. */
export const COMPOSER_GATE_KEYS = [
  "minConfidence",
  "minVelocity",
  "minProbEdge",
  "stopLossCents",
  "profitTakeCents",
  "tradeWindowMinMin",
  "tradeWindowMaxMin",
  "maxContractsPerTrade",
  "kellyFraction",
  "useKellyFraction",
  "useKellySizing",
  "maxRiskPctPerTrade",
  "minEV",
  "paperMode",
  "disabledStrategies",
] as const;

export type TapeLieReason =
  | "LAG_STALE"
  | "LAG_AGAINST"
  | "DEAD_TAPE"
  | "CHAOS";

export type TapeLieInputs = {
  lagStale?: boolean;
  /** When set, false means Coinbase lag disagrees with the selected side. */
  lagAgreesWithSide?: boolean | null;
  volumeBucket?: string;
  chaosMode?: boolean;
};

export type AdaptationInputs = {
  autoMode: boolean;
  tape: TapeLieInputs;
  drawdownPct: number;
  /** Operator drawdownGuardPct (e.g. 20). Adapter never loosens this. */
  drawdownGuardPct?: number;
  /** Raw learner weight. Ignored unless fromBotFill is true. */
  learningWeight?: number;
  fromBotFill?: boolean;
  /** When known, CONFLUENCE_CASCADE is exempt from FRESH lag TAPE_LIE skip. */
  strategyId?: string;
};

export type AdaptationResult = {
  skip: boolean;
  skipReasons: TapeLieReason[];
  /** Position-size multiplier in (0, 1]. Never > 1. */
  sizeMult: number;
  /** Confidence/size learn multiplier in [0.72, 1.18]. 1.0 without BOT fills. */
  learningWeight: number;
  summary: string;
};

const SIZE_MULT_FLOOR = 0.5;
const DD_EXTRA_ONSET_PCT = 8;
const DD_EXTRA_FLOOR = 0.7;
const LOW_VOL_SIZE_MULT = 0.85;
const DEAD_VOL_SIZE_MULT = SIZE_MULT_FLOOR;
export const CONFLUENCE_CASCADE_ID = "CONFLUENCE_CASCADE";

export function isBotFillOutcomeKey(key: string | undefined | null): boolean {
  return typeof key === "string" && key.startsWith("bot_trades:");
}

export function clampLearningWeight(weight: number): number {
  if (!Number.isFinite(weight)) return 1;
  return Math.min(LEARNING_WEIGHT_MAX, Math.max(LEARNING_WEIGHT_MIN, weight));
}

/**
 * Learn from BOT fills only. Shadow / sim / manual / missing evidence → 1.0.
 * Never outside 0.72–1.18.
 */
export function applyBotFillLearning(
  weight: number | undefined,
  fromBotFill: boolean,
): number {
  if (!fromBotFill) return 1;
  return clampLearningWeight(weight ?? 1);
}

/**
 * Extra size haircut in drawdown. Existing drawdownGuard still binds to 0
 * at guardPct; this is a milder extra taper that never increases size.
 * 0–8% DD → 1.0; 8% → guardPct linear to 0.7; ≥guardPct → 0.7.
 */
export function drawdownSizeMult(drawdownPct: number, guardPct = 20): number {
  if (!Number.isFinite(drawdownPct) || drawdownPct <= 0) return 1;
  const guard = Number.isFinite(guardPct) && guardPct > DD_EXTRA_ONSET_PCT
    ? guardPct
    : 20;
  if (drawdownPct <= DD_EXTRA_ONSET_PCT) return 1;
  if (drawdownPct >= guard) return DD_EXTRA_FLOOR;
  const t = (drawdownPct - DD_EXTRA_ONSET_PCT) / (guard - DD_EXTRA_ONSET_PCT);
  return 1 - t * (1 - DD_EXTRA_FLOOR);
}

export function tapeLieReasons(tape: TapeLieInputs): TapeLieReason[] {
  const reasons: TapeLieReason[] = [];
  if (tape.lagStale === true) reasons.push("LAG_STALE");
  // FRESH disagree only. Stale is unknown, not a lie.
  if (tape.lagStale === false && tape.lagAgreesWithSide === false) {
    reasons.push("LAG_AGAINST");
  }
  if (tape.volumeBucket === "DEAD") reasons.push("DEAD_TAPE");
  if (tape.chaosMode === true) reasons.push("CHAOS");
  return reasons;
}

/** Only FRESH lag disagree empties a non-CC tick. DEAD sizes down; CHAOS is observed. */
export const TAPE_LIE_SIT_ON_HANDS: readonly TapeLieReason[] = ["LAG_AGAINST"];

export function tapeLieBlocksTick(reasons: readonly TapeLieReason[]): boolean {
  return reasons.includes("LAG_AGAINST");
}

/**
 * Skip more when Coinbase lag is FRESH and disagrees.
 * CONFLUENCE_CASCADE is a ≥3-factor trend book — never TAPE_LIE starved.
 */
export function freshLagDisagreeSkip(opts: {
  autoMode: boolean;
  lagStale: boolean | undefined;
  agreesWithSide: boolean | null | undefined;
  strategyId: string | undefined | null;
}): boolean {
  if (!opts.autoMode) return false;
  if (opts.strategyId === CONFLUENCE_CASCADE_ID) return false;
  if (opts.lagStale !== false) return false;
  return opts.agreesWithSide === false;
}

function volumeSizeMult(bucket: string | undefined): number {
  if (bucket === "DEAD") return DEAD_VOL_SIZE_MULT;
  if (bucket === "LOW") return LOW_VOL_SIZE_MULT;
  return 1;
}

function clampSizeMult(mult: number): number {
  if (!Number.isFinite(mult)) return 1;
  return Math.min(1, Math.max(SIZE_MULT_FLOOR, mult));
}

/**
 * Adaptation for one tick. When autoMode is false this is a no-op
 * (no extra skip, size 1, learn 1). Output never includes gate keys.
 * Without strategyId, skip stays false so CC can still evaluate.
 */
export function computeAdaptation(inputs: AdaptationInputs): AdaptationResult {
  if (!inputs.autoMode) {
    return {
      skip: false,
      skipReasons: [],
      sizeMult: 1,
      learningWeight: 1,
      summary: "autoMode off — no adaptation",
    };
  }

  const skipReasons = tapeLieReasons(inputs.tape);
  const sizeMult = clampSizeMult(
    Math.min(
      drawdownSizeMult(inputs.drawdownPct, inputs.drawdownGuardPct),
      volumeSizeMult(inputs.tape.volumeBucket),
    ),
  );
  const learningWeight = applyBotFillLearning(
    inputs.learningWeight,
    inputs.fromBotFill === true,
  );

  const skip = freshLagDisagreeSkip({
    autoMode: true,
    lagStale: inputs.tape.lagStale,
    agreesWithSide: inputs.tape.lagAgreesWithSide,
    strategyId: inputs.strategyId,
  });

  const bits: string[] = [];
  if (skip) bits.push("skip LAG_AGAINST");
  else if (skipReasons.includes("LAG_AGAINST") && inputs.strategyId === CONFLUENCE_CASCADE_ID) {
    bits.push("LAG_AGAINST observed (CC exempt)");
  }
  if (skipReasons.includes("DEAD_TAPE")) bits.push("DEAD tape size-down");
  if (skipReasons.includes("LAG_STALE")) bits.push("lag stale (unknown, not skip)");
  if (skipReasons.includes("CHAOS")) bits.push("chaos observed (not sit-on-hands)");
  if (sizeMult < 1) bits.push(`size ${sizeMult.toFixed(2)}x`);
  if (learningWeight !== 1) bits.push(`learn ${learningWeight.toFixed(2)}x (BOT fills)`);
  const summary = bits.length
    ? `adapter: ${bits.join(" · ")}`
    : "adapter: tape honest, no DD haircut, no BOT-fill learn yet";

  return {
    skip,
    skipReasons,
    sizeMult,
    learningWeight,
    summary,
  };
}

/** Runtime guard: adapter objects must not grow composer gate keys. */
export function adapterTouchesComposerGates(result: object): string[] {
  const keys = Object.keys(result);
  return COMPOSER_GATE_KEYS.filter((k) => keys.includes(k));
}

/**
 * Echo operator floors for status/UI so lastAutoSettings can never display
 * a condition-adapter cut. Spreading this onto config is a no-op.
 */
export function echoOperatorFloors<T extends Record<string, unknown>>(config: T): {
  minConfidence: unknown;
  minVelocity: unknown;
  maxContractsPerTrade: unknown;
  stopLossCents: unknown;
  profitTakeCents: unknown;
  tradeWindowMinMin: unknown;
  tradeWindowMaxMin: unknown;
  minProbEdge: unknown;
} {
  return {
    minConfidence: config.minConfidence,
    minVelocity: config.minVelocity,
    maxContractsPerTrade: config.maxContractsPerTrade,
    stopLossCents: config.stopLossCents,
    profitTakeCents: config.profitTakeCents,
    tradeWindowMinMin: config.tradeWindowMinMin,
    tradeWindowMaxMin: config.tradeWindowMaxMin,
    minProbEdge: config.minProbEdge,
  };
}
