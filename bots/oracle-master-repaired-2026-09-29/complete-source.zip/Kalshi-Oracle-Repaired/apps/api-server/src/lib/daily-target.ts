/**
 * daily-target.ts — Daily 50% Compounding Target Engine
 *
 * Gives the bot a goal-seeking layer on top of Kelly + risk-profile sizing:
 *   • Day-roll snapshot: equity at midnight ET becomes the compounding base.
 *   • Pace-aware sizing: progress vs time-of-day drives a sizing multiplier.
 *   • Protect mode after target hit: stand down (default) or trade A+ only
 *     at reduced size with a give-back cap.
 *
 * PRECEDENCE (hard rule): circuit breakers > risk profile > target engine.
 *   • The engine NEVER loosens entry quality gates. Being behind pace only
 *     increases readiness to take valid setups at fuller size.
 *   • The engine's boost multiplier is suppressed entirely when the risk
 *     profile is CONSERVATIVE or RECOVERY (account is already unhealthy).
 */

import { db, dailyEquityDays } from "@workspace/db";
import { and, desc, eq, sql } from "drizzle-orm";
import type { RiskProfile } from "./trade-path.js";

export type PaceState = "AHEAD" | "ON_PACE" | "BEHIND" | "TARGET_HIT" | "PROTECTED";

export type ProtectBehavior = "stand_down" | "reduced";

export interface DailyTargetStatus {
  /** ET date the snapshot belongs to, e.g. "2026-08-01" */
  date:              string;
  startEquityCents:  number;
  currentEquityCents: number;
  targetEquityCents: number;
  targetPct:         number;
  /** 0–100+, progress of gain toward target (100 = target hit) */
  progressPct:       number;
  paceState:         PaceState;
  /** true once equity has touched the target at any point today */
  targetHitToday:    boolean;
  /** true when protect mode is limiting or blocking new entries */
  protectActive:     boolean;
  /** sizing multiplier the engine contributes (1.0 = neutral) */
  sizeMult:          number;
  /** non-null when the engine is blocking new entries entirely */
  blockReason:       string | null;
}

/** ET calendar date string, e.g. "2026-08-01". */
export function etDateKey(d = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/New_York", year: "numeric", month: "2-digit", day: "2-digit",
  }).format(d);
  return parts; // en-CA gives YYYY-MM-DD
}

/** Fraction of the ET day elapsed, 0–1. */
function etDayFraction(d = new Date()): number {
  const et = new Date(d.toLocaleString("en-US", { timeZone: "America/New_York" }));
  return (et.getHours() * 3600 + et.getMinutes() * 60 + et.getSeconds()) / 86_400;
}

/**
 * Pure pace/sizing computation. Kept side-effect free for testability.
 *
 * Sizing schedule (applied AFTER risk-profile sizing, and only as permitted):
 *   BEHIND pace + healthy profile → 1.15× (top of aggressive readiness)
 *   ON_PACE / AHEAD               → 1.0×
 *   TARGET_HIT + stand_down       → block new entries
 *   TARGET_HIT + reduced          → 0.3×, A+ setups only (caller enforces
 *                                   quality bar; engine only shrinks size)
 *   Give-back breached in reduced → block for rest of day
 */
export function computeTargetEngine(opts: {
  startEquityCents:   number;
  currentEquityCents: number;
  /** Highest equity reached today — give-back is measured from here. */
  peakEquityCents:    number;
  targetPct:          number;          // e.g. 50
  targetHitToday:     boolean;         // latched: equity touched target earlier today
  protectBehavior:    ProtectBehavior;
  giveBackCapPct:     number;          // e.g. 10 — max % of day's PEAK gain surrendered in protect mode
  riskProfile:        RiskProfile;
  now?:               Date;
}): Omit<DailyTargetStatus, "date"> {
  const {
    startEquityCents: start, currentEquityCents: cur,
    targetPct, protectBehavior, giveBackCapPct, riskProfile,
  } = opts;
  const peak = Math.max(opts.peakEquityCents, cur, start);

  const targetEquityCents = Math.round(start * (1 + targetPct / 100));
  const gainNeeded  = targetEquityCents - start;
  const gainSoFar   = cur - start;
  const progressPct = gainNeeded > 0 ? (gainSoFar / gainNeeded) * 100 : 0;

  const hitNow         = cur >= targetEquityCents;
  const targetHitToday = opts.targetHitToday || hitNow;

  // ── Protect mode ──────────────────────────────────────────────────────────
  if (targetHitToday) {
    if (protectBehavior === "stand_down") {
      return {
        startEquityCents: start, currentEquityCents: cur, targetEquityCents,
        targetPct, progressPct, paceState: "PROTECTED", targetHitToday,
        protectActive: true, sizeMult: 0,
        blockReason: `Daily +${targetPct}% target reached — standing down to protect gains`,
      };
    }
    // reduced mode — keep trading A+ only at 0.3×, unless give-back cap breached.
    // Give-back is measured from the day's PEAK gain (high-water mark), so a
    // run-up past the target is protected too: e.g. target +50%, peak +100%,
    // 10% cap → stand down once equity falls below +90% of start.
    const peakGain    = Math.max(peak - start, gainNeeded); // target gain was reached at minimum
    const givenBack   = peakGain - gainSoFar;
    const giveBackCap = peakGain * (giveBackCapPct / 100);
    if (givenBack >= giveBackCap) {
      return {
        startEquityCents: start, currentEquityCents: cur, targetEquityCents,
        targetPct, progressPct, paceState: "PROTECTED", targetHitToday,
        protectActive: true, sizeMult: 0,
        blockReason: `Give-back cap hit (surrendered ${(givenBack / 100).toFixed(2)}$ of gains) — done for the day`,
      };
    }
    return {
      startEquityCents: start, currentEquityCents: cur, targetEquityCents,
      targetPct, progressPct, paceState: "TARGET_HIT", targetHitToday,
      protectActive: true, sizeMult: 0.3, blockReason: null,
    };
  }

  // ── Pace state — compare progress to time elapsed in the ET day ──────────
  const dayFrac  = etDayFraction(opts.now);
  const expected = dayFrac * 100;                    // linear pace expectation
  const paceState: PaceState =
    progressPct >= expected + 10 ? "AHEAD" :
    progressPct <= expected - 15 ? "BEHIND" : "ON_PACE";

  // No catch-up boost. Being "behind" a clock-based pace is not evidence of
  // edge — up-sizing after underperformance is loss chasing and compounds
  // model error exactly when it is largest (algo + risk critics, Aug 2026).
  // The engine only ever REDUCES risk: protect/stand-down after target hit.
  // riskProfile is retained in the signature for the status display.
  void riskProfile;
  const sizeMult = 1.0;

  return {
    startEquityCents: start, currentEquityCents: cur, targetEquityCents,
    targetPct, progressPct, paceState, targetHitToday,
    protectActive: false, sizeMult, blockReason: null,
  };
}

// ── Cash-flow reconciliation ─────────────────────────────────────────────────

export interface CashFlowReconciliationResult {
  /** Non-zero only when isExternalFlow is true. */
  externalFlowCents:   number;
  isExternalFlow:      boolean;
  newStartEquityCents: number;
  newPeakEquityCents:  number;
}

/**
 * Pure detector for external cash flows (deposits/withdrawals) hitting the
 * account between two balance checks. A deposit or withdrawal moves the raw
 * balance without any trade settling, which used to read as a trading
 * gain/loss and could falsely trip the daily-target latch (confirmed live
 * 2026-08-10: an $88 deposit registered as an 82% daily gain and stood the
 * bot down). Any balance movement NOT explained by realized P&L since the
 * last check is treated as an external flow and folded straight into the
 * baseline (and peak) so it never counts toward — or against — the target.
 *
 * Kept side-effect free for testability; the caller is responsible for
 * fetching `realizedSinceLastCheckCents` from settled trades and persisting
 * the returned baseline/peak.
 */
export function computeCashFlowReconciliation(opts: {
  balanceCents:                number;
  lastReconciledBalanceCents:  number;
  realizedSinceLastCheckCents: number;
  startEquityCents:            number;
  peakEquityCents:             number;
  /** Ignore moves smaller than this — fee rounding / in-flight settlement noise. Default 5¢. */
  noiseFloorCents?:            number;
}): CashFlowReconciliationResult {
  const noiseFloor    = opts.noiseFloorCents ?? 5;
  const expectedBal   = opts.lastReconciledBalanceCents + opts.realizedSinceLastCheckCents;
  const rawFlowCents  = opts.balanceCents - expectedBal;
  const isExternalFlow = Math.abs(rawFlowCents) >= noiseFloor;
  return {
    externalFlowCents:   isExternalFlow ? rawFlowCents : 0,
    isExternalFlow,
    newStartEquityCents: isExternalFlow ? opts.startEquityCents + rawFlowCents : opts.startEquityCents,
    newPeakEquityCents:  isExternalFlow ? opts.peakEquityCents + rawFlowCents : opts.peakEquityCents,
  };
}

// ── Fail-closed entry gate ───────────────────────────────────────────────────

/**
 * Single source of truth for whether the daily-target layer blocks new
 * entries. `latchDirty` = the target-hit latch could NOT be durably persisted
 * (DB outage at the transition). Trading with an unpersisted latch means a
 * restart would bypass protect mode, so we fail closed.
 *
 * `loadFailed` = the initial/day-roll snapshot load from the DB itself threw
 * (2026-08-25 audit fix). Previously a load failure just reset the cached
 * status to null with no block, so orders proceeded with zero daily-target /
 * protect-mode protection for the duration of the outage — the exact
 * "unknown state must fail closed" gap every other admission check in this
 * codebase already closes (balance staleness, position confirmation, etc.).
 */
export function dailyTargetEntryBlock(
  status: DailyTargetStatus | null,
  latchDirty: boolean,
  loadFailed = false,
): string | null {
  if (status?.blockReason) return status.blockReason;
  if (latchDirty) return "Daily target hit — latch persist pending (fail-closed)";
  if (loadFailed) return "Daily-target snapshot unknown — DB load failed (fail-closed)";
  return null;
}

/**
 * Durably persist the target-hit latch. Returns the new `latchDirty` state:
 * `false` when the write landed, `true` when it failed (caller must block
 * entries and retry on subsequent ticks).
 */
export async function persistLatchDurably(write: Promise<unknown>): Promise<boolean> {
  try { await write; return false; }
  catch { return true; }
}

// ── Persistence ──────────────────────────────────────────────────────────────

/**
 * Idempotent schema guarantee. Deployed databases that predate this feature
 * won't have the table until the next `drizzle-kit push` runs (post-merge /
 * dev-to-prod sync). Rather than erroring until then — which would silently
 * disable the engine and 500 the history endpoint — create the table and its
 * unique index on first use. Matches lib/db/src/schema/daily-equity.ts exactly.
 */
let schemaReady: Promise<void> | null = null;
export function ensureDailyEquitySchema(): Promise<void> {
  if (!schemaReady) {
    schemaReady = (async () => {
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS daily_equity_days (
          id                 serial PRIMARY KEY,
          date               text NOT NULL,
          paper_mode         boolean NOT NULL DEFAULT true,
          start_equity_cents integer NOT NULL,
          end_equity_cents   integer,
          peak_equity_cents  integer,
          pct_gain           real,
          target_hit         boolean NOT NULL DEFAULT false,
          created_at         timestamp NOT NULL DEFAULT now(),
          updated_at         timestamp NOT NULL DEFAULT now()
        )
      `);
      await db.execute(sql`
        CREATE UNIQUE INDEX IF NOT EXISTS daily_equity_days_date_mode_uq
        ON daily_equity_days (date, paper_mode)
      `);
    })().catch((err) => {
      schemaReady = null;   // allow retry on next call
      throw err;
    });
  }
  return schemaReady;
}

export async function loadOrCreateDayRow(opts: {
  date: string; paperMode: boolean; equityCents: number;
}): Promise<{ startEquityCents: number; peakEquityCents: number; targetHit: boolean }> {
  await ensureDailyEquitySchema();
  // Insert-or-ignore first (unique (date, paper_mode) index guards against a
  // concurrent process creating the row between select and insert), then read
  // back whichever row won.
  await db.insert(dailyEquityDays).values({
    date: opts.date, paperMode: opts.paperMode,
    startEquityCents: opts.equityCents, endEquityCents: opts.equityCents,
    peakEquityCents: opts.equityCents, pctGain: 0,
  }).onConflictDoNothing();
  const rows = await db.select().from(dailyEquityDays)
    .where(and(eq(dailyEquityDays.date, opts.date), eq(dailyEquityDays.paperMode, opts.paperMode)))
    .limit(1);
  const row = rows[0];
  return {
    startEquityCents: row.startEquityCents,
    peakEquityCents:  row.peakEquityCents ?? row.startEquityCents,
    targetHit:        row.targetHit,
  };
}

export async function updateDayRow(opts: {
  date: string; paperMode: boolean; endEquityCents: number;
  startEquityCents: number; peakEquityCents: number; targetHit: boolean;
}): Promise<void> {
  const pctGain = opts.startEquityCents > 0
    ? ((opts.endEquityCents - opts.startEquityCents) / opts.startEquityCents) * 100
    : 0;
  await db.update(dailyEquityDays)
    .set({
      endEquityCents: opts.endEquityCents,
      // Baseline can shift intraday when the reconciler in trading-bot.ts
      // detects an external cash flow (deposit/withdrawal) that isn't
      // explained by realized trade P&L — persist that shift so a restart
      // reloads the corrected baseline instead of the original pre-flow one.
      startEquityCents: opts.startEquityCents,
      // Monotonic writes: a stale writer (older in-memory snapshot, second
      // process) must never lower the high-water mark or clear the latch.
      peakEquityCents: sql`GREATEST(COALESCE(${dailyEquityDays.peakEquityCents}, 0), ${opts.peakEquityCents})`,
      pctGain: +pctGain.toFixed(2),
      targetHit: sql`(${dailyEquityDays.targetHit} OR ${opts.targetHit})`,
      updatedAt: new Date(),
    })
    .where(and(eq(dailyEquityDays.date, opts.date), eq(dailyEquityDays.paperMode, opts.paperMode)));
}

export async function getDailyHistory(paperMode: boolean, days = 14) {
  await ensureDailyEquitySchema();
  return db.select().from(dailyEquityDays)
    .where(eq(dailyEquityDays.paperMode, paperMode))
    .orderBy(desc(dailyEquityDays.date))
    .limit(days);
}
