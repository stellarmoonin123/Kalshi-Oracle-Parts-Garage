/**
 * liquidity-policy.test.ts — P4: LIQUIDITY POLICY (BOOK-AWARE HAIRCUTS, NOT
 * A SIGNAL ENGINE).
 *
 * Pure-function tests. No DB, no live bot, no network — mirrors
 * family-policy.test.ts's style.
 */
import test from "node:test";
import assert from "node:assert/strict";
import {
  buildBookSnap, evaluateLiquidity, computeLagNetEdgePts,
  BOOK_STALE_MS, S_MAX_CENTS, D_MIN_CONTRACTS, IMB_ADVERSE, VOL_HIGH_THRESHOLD,
  STACKED_SIZE_MULT_FLOOR, type BookSnap, type RawOrderbookSnapshot,
} from "./liquidity-policy.js";

function freshBook(overrides: Partial<BookSnap> = {}): BookSnap {
  return {
    spreadCents: 2, depthAtAsk: 10, depthNearAsk: 20, imbalance: 0.1,
    bookAgeMs: 500, bookStale: false, noQuote: false,
    ...overrides,
  };
}

// ── buildBookSnap ────────────────────────────────────────────────────────────

test("buildBookSnap: no bid/ask quote at all → noQuote=true, spreadCents=null", () => {
  const snap = buildBookSnap({
    side: 'YES', currentTicker: 'T1', quote: {}, latestOrderbook: null,
  });
  assert.equal(snap.noQuote, true);
  assert.equal(snap.spreadCents, null);
});

test("P4.1: buildBookSnap: fresh bid/ask, no L2 snapshot at all → NOT BOOK_STALE (degraded, spread-only), depth/imbalance null", () => {
  const snap = buildBookSnap({
    side: 'YES', currentTicker: 'T1',
    quote: { yesBid: 48, yesAsk: 51 }, latestOrderbook: null,
  });
  assert.equal(snap.noQuote, false);
  assert.equal(snap.spreadCents, 3);
  assert.equal(snap.bookStale, false); // P4.1: genuinely-absent snapshot degrades, does not hard-skip
  assert.equal(snap.depthAtAsk, null);
  assert.equal(snap.imbalance, null);
});

test("buildBookSnap: L2 snapshot for a different ticker is treated as stale", () => {
  const ob: RawOrderbookSnapshot = { ticker: 'OTHER', yesBids: [[48, 20]], yesAsks: [[51, 20]], ts: Date.now() };
  const snap = buildBookSnap({ side: 'YES', currentTicker: 'T1', quote: { yesBid: 48, yesAsk: 51 }, latestOrderbook: ob });
  assert.equal(snap.bookStale, true);
  assert.equal(snap.depthAtAsk, null);
});

test("buildBookSnap: L2 snapshot older than BOOK_STALE_MS is stale", () => {
  const ob: RawOrderbookSnapshot = { ticker: 'T1', yesBids: [[48, 20]], yesAsks: [[51, 20]], ts: Date.now() - (BOOK_STALE_MS + 1000) };
  const snap = buildBookSnap({ side: 'YES', currentTicker: 'T1', quote: { yesBid: 48, yesAsk: 51 }, latestOrderbook: ob });
  assert.equal(snap.bookStale, true);
});

test("buildBookSnap: fresh matching L2 snapshot fills depth + imbalance (YES side)", () => {
  const now = Date.now();
  const ob: RawOrderbookSnapshot = {
    ticker: 'T1', ts: now - 100,
    yesBids: [[48, 30], [47, 10]],
    yesAsks: [[51, 12], [52, 8]],
  };
  const snap = buildBookSnap({ side: 'YES', currentTicker: 'T1', quote: { yesBid: 48, yesAsk: 51 }, latestOrderbook: ob });
  assert.equal(snap.bookStale, false);
  assert.equal(snap.depthAtAsk, 12);
  // bidNear=40, askNear=20 → imbalance = (40-20)/60 = 0.333..
  assert.ok(snap.imbalance !== null && snap.imbalance > 0.3 && snap.imbalance < 0.34);
});

test("buildBookSnap: NO side mirrors YES bid/ask levels (NO ask depth = YES bid depth)", () => {
  const now = Date.now();
  const ob: RawOrderbookSnapshot = {
    ticker: 'T1', ts: now - 100,
    yesBids: [[48, 30]],
    yesAsks: [[51, 12]],
  };
  const snap = buildBookSnap({ side: 'NO', currentTicker: 'T1', quote: { noBid: 49, noAsk: 52 }, latestOrderbook: ob });
  // NO ask mirrors YES's best bid depth (30)
  assert.equal(snap.depthAtAsk, 30);
});

// ── evaluateLiquidity: rule 1 (stale/missing book) ──────────────────────────

test("evaluateLiquidity: missing quote → SKIP BOOK_MISSING for every family", () => {
  for (const family of ['momentum', 'lag', 'anchor', 'mean_reversion', 'confluence', 'breakout'] as const) {
    const v = evaluateLiquidity({ family, book: freshBook({ noQuote: true, spreadCents: null }) });
    assert.equal(v.action, 'SKIP');
    assert.equal(v.reason, 'BOOK_MISSING');
    assert.equal(v.sizeMult, 0);
  }
});

test("evaluateLiquidity: stale book → SKIP BOOK_STALE for every family, never invents depth", () => {
  const v = evaluateLiquidity({ family: 'lag', book: freshBook({ bookStale: true, depthAtAsk: null, imbalance: null }) });
  assert.equal(v.action, 'SKIP');
  assert.equal(v.reason, 'BOOK_STALE');
});

// ── P4.1: DEPTH_NULL degraded book (spread-only, not a stale-book skip) ─────

test("P4.1: evaluateLiquidity: DEPTH_NULL + wide spread on momentum → SKIP LIQ_SPREAD (not BOOK_STALE)", () => {
  const v = evaluateLiquidity({
    family: 'momentum',
    book: freshBook({ bookStale: false, depthAtAsk: null, imbalance: null, spreadCents: S_MAX_CENTS }),
  });
  assert.equal(v.action, 'SKIP');
  assert.equal(v.reason, 'LIQ_SPREAD');
});

test("P4.1: evaluateLiquidity: DEPTH_NULL + moderate spread on lag → HAIRCUT, spread penalty still computed for net-edge", () => {
  const v = evaluateLiquidity({
    family: 'lag',
    book: freshBook({ bookStale: false, depthAtAsk: null, imbalance: null, spreadCents: S_MAX_CENTS }),
  });
  assert.equal(v.action, 'HAIRCUT');
  assert.ok(v.sizeMult <= 0.5);
  assert.equal(v.spreadPenaltyCents, S_MAX_CENTS); // computeLagNetEdgePts still has a real penalty to net against
  assert.ok(v.reasons.includes('LIQ_DEGRADED_NO_DEPTH'));
});

test("P4.1: evaluateLiquidity: DEPTH_NULL + tight spread → ALLOW, tagged degraded but not gated", () => {
  const v = evaluateLiquidity({
    family: 'momentum',
    book: freshBook({ bookStale: false, depthAtAsk: null, imbalance: null, spreadCents: 1 }),
  });
  assert.equal(v.action, 'ALLOW');
  assert.equal(v.sizeMult, 1);
  assert.ok(v.reasons.includes('LIQ_DEGRADED_NO_DEPTH'));
});

// ── evaluateLiquidity: rule 2 (spread) ──────────────────────────────────────

test("evaluateLiquidity: wide spread hard-skips momentum/breakout/confluence", () => {
  for (const family of ['momentum', 'breakout', 'confluence'] as const) {
    const v = evaluateLiquidity({ family, book: freshBook({ spreadCents: S_MAX_CENTS }) });
    assert.equal(v.action, 'SKIP');
    assert.equal(v.reason, 'LIQ_SPREAD');
  }
});

test("evaluateLiquidity: wide spread haircuts lag/anchor/mean_reversion instead of hard-skipping", () => {
  for (const family of ['lag', 'anchor', 'mean_reversion'] as const) {
    const v = evaluateLiquidity({ family, book: freshBook({ spreadCents: S_MAX_CENTS }) });
    assert.equal(v.action, 'HAIRCUT');
    assert.ok(v.sizeMult <= 0.5);
    assert.equal(v.reason, 'LIQ_SPREAD');
  }
});

test("evaluateLiquidity: even softer families hard-skip once spread clears S_max_eff + extra", () => {
  const v = evaluateLiquidity({ family: 'lag', book: freshBook({ spreadCents: S_MAX_CENTS + 2 }) });
  assert.equal(v.action, 'SKIP');
  assert.equal(v.reason, 'LIQ_SPREAD');
});

test("evaluateLiquidity: spread below threshold does not trigger rule 2", () => {
  const v = evaluateLiquidity({ family: 'momentum', book: freshBook({ spreadCents: S_MAX_CENTS - 1 }) });
  assert.notEqual(v.reason, 'LIQ_SPREAD');
});

// ── evaluateLiquidity: rule 3 (depth) ───────────────────────────────────────

test("evaluateLiquidity: thin depth hard-skips momentum/breakout", () => {
  for (const family of ['momentum', 'breakout'] as const) {
    const v = evaluateLiquidity({ family, book: freshBook({ depthAtAsk: D_MIN_CONTRACTS - 1 }) });
    assert.equal(v.action, 'SKIP');
    assert.equal(v.reason, 'LIQ_THIN');
  }
});

test("evaluateLiquidity: thin depth haircuts lag/anchor 0.5-0.7, and mean_reversion/confluence <=0.5", () => {
  const lag = evaluateLiquidity({ family: 'lag', book: freshBook({ depthAtAsk: D_MIN_CONTRACTS - 1 }) });
  assert.equal(lag.action, 'HAIRCUT');
  assert.ok(lag.sizeMult >= 0.5 && lag.sizeMult <= 0.7);

  const mr = evaluateLiquidity({ family: 'mean_reversion', book: freshBook({ depthAtAsk: D_MIN_CONTRACTS - 1 }) });
  assert.equal(mr.action, 'HAIRCUT');
  assert.ok(mr.sizeMult <= 0.5);
});

test("evaluateLiquidity: null (unknown) depth never triggers rule 3 — never invents a value", () => {
  const v = evaluateLiquidity({ family: 'momentum', book: freshBook({ depthAtAsk: null }) });
  assert.notEqual(v.reason, 'LIQ_THIN');
});

// ── evaluateLiquidity: rule 4 (imbalance) ───────────────────────────────────

test("evaluateLiquidity: adverse imbalance hard-skips momentum/breakout", () => {
  for (const family of ['momentum', 'breakout'] as const) {
    const v = evaluateLiquidity({ family, book: freshBook({ imbalance: IMB_ADVERSE }) });
    assert.equal(v.action, 'SKIP');
    assert.equal(v.reason, 'LIQ_IMBALANCE');
  }
});

test("evaluateLiquidity: adverse imbalance haircuts every other family by 0.7x, including confluence/mean_reversion", () => {
  for (const family of ['lag', 'anchor', 'mean_reversion', 'confluence'] as const) {
    const v = evaluateLiquidity({ family, book: freshBook({ imbalance: IMB_ADVERSE }) });
    assert.equal(v.action, 'HAIRCUT');
    assert.ok(Math.abs(v.sizeMult - 0.7) < 1e-9);
  }
});

test("evaluateLiquidity: stacked haircuts never fall below STACKED_SIZE_MULT_FLOOR and never resurrect a 0", () => {
  const v = evaluateLiquidity({
    family: 'lag',
    book: freshBook({ spreadCents: S_MAX_CENTS, depthAtAsk: D_MIN_CONTRACTS - 1, imbalance: IMB_ADVERSE }),
  });
  assert.equal(v.action, 'HAIRCUT');
  assert.ok(v.sizeMult >= STACKED_SIZE_MULT_FLOOR);
  assert.ok(v.sizeMult > 0);
});

// ── evaluateLiquidity: ALLOW path ───────────────────────────────────────────

test("evaluateLiquidity: tight spread, deep book, neutral imbalance → ALLOW sizeMult=1", () => {
  const v = evaluateLiquidity({ family: 'momentum', book: freshBook() });
  assert.equal(v.action, 'ALLOW');
  assert.equal(v.sizeMult, 1);
  assert.equal(v.reason, 'OK');
});

// ── volScale adaptive bump ───────────────────────────────────────────────────

test("evaluateLiquidity: high volScale widens spread tolerance so a moderately wide spread is allowed", () => {
  const spread = S_MAX_CENTS + 1; // would trip rule 2 at the base threshold
  const lowVol = evaluateLiquidity({ family: 'momentum', book: freshBook({ spreadCents: spread }), volScale: 0.1 });
  assert.equal(lowVol.action, 'SKIP');
  const highVol = evaluateLiquidity({ family: 'momentum', book: freshBook({ spreadCents: spread }), volScale: VOL_HIGH_THRESHOLD });
  assert.equal(highVol.action, 'ALLOW');
});

// ── computeLagNetEdgePts (Part C) ───────────────────────────────────────────

test("computeLagNetEdgePts: nets the spread penalty against raw edge", () => {
  assert.equal(computeLagNetEdgePts(20, 3), 17);
  assert.equal(computeLagNetEdgePts(5, 8), -3); // can go negative — caller compares against its own floor
});
