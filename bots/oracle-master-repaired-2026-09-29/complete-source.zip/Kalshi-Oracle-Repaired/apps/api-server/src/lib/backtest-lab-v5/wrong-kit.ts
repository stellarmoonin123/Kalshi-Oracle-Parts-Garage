/**
 * backtest-lab-v5/wrong-kit.ts
 *
 * ACK LAB v5 — FAIR METRICS HARDENING ONLY (2026-08-22), Item 1.
 *
 * Fair, policy-neutral `wrong_kit` definition, replacing the earlier
 * LEAN-pack-allowlist-based measure. The old measure asked "did this trade's
 * strategy belong to LEAN's OWN pack-ideal allowlist for this regime/
 * volume?" — which structurally scores LEGACY near 100% wrong-kit whenever
 * packMode is 'off', since LEGACY never participates in LEAN's pack system
 * at all. That is an artifact of measuring conformance to one policy's own
 * config, not a fair behavioral judgment either policy can fail or pass.
 *
 * New definition (applies IDENTICALLY to both LEAN and LEGACY, and does not
 * require a pack to exist): a trade is wrong-kit when its selected
 * strategy's FAMILY (strategy-library.ts's `StrategyFamily` — already the
 * canonical per-strategy classification used elsewhere in this codebase,
 * e.g. task #281's consensus family cap) conflicts with the CAUSAL regime
 * label recorded at decision time (`SimDecision.regime`, from
 * `classifyRegimeFromBuffer` — the same regime both policies already
 * compute causally, upstream of and independent of any pack filtering).
 *
 * The map below is intentionally the SMALL, explicit set of conflicts
 * specified in the "FAIR METRICS HARDENING" directive (2026-08-22):
 *   - expansion/trend regime  -> fade/mean-reversion family        = wrong
 *   - range regime            -> breakout/expansion-only family    = wrong
 *   - fog/low-conviction regime -> pure momentum w/o lag/anchor     = wrong
 * It is NOT an attempt to encode every conceivable family/regime mismatch.
 * Any family not listed as wrong for a given regime bucket (basis-lag,
 * late-displacement, probability-model, and pattern never appear below) is
 * treated as regime-neutral — never penalized — under this map. That is a
 * documented simplification, not an oversight: widening the map is a
 * separate, explicit decision for a future step, not something to infer
 * here.
 */

import type { MarketRegimeTag, StrategyFamily } from '../strategy-library.js';

/** Coarse regime buckets the wrong-kit map is defined over. */
export type RegimeBucket = 'trend_expansion' | 'range_compression' | 'fog_lowconf';

/**
 * MarketRegimeTag -> RegimeBucket. Deliberately exhaustive (a `Record` over
 * every MarketRegimeTag literal) so that if strategy-library.ts ever adds an
 * 11th regime tag, this file fails to compile instead of silently treating
 * the new tag as "neutral" by omission.
 */
export const REGIME_TO_BUCKET: Record<MarketRegimeTag, RegimeBucket> = {
  // Strong directional/expansion moves. Fading them (mean-reversion) is the
  // "expansion/trend regime -> fade family = wrong" case.
  strong_uptrend:   'trend_expansion',
  strong_downtrend: 'trend_expansion',
  breakout_up:      'trend_expansion',
  breakdown:        'trend_expansion',
  waterfall:        'trend_expansion',
  // Tight/contained price action. Betting on a breakout that hasn't
  // happened yet is the "range regime -> breakout/expansion-only family =
  // wrong" case.
  range:            'range_compression',
  squeeze:          'range_compression',
  // Ambiguous/reversal-prone conditions. Chasing raw momentum with no
  // cross-market anchor (basis-lag) or model-based confirmation
  // (probability-model) behind it is the "fog/low_vol -> pure momentum
  // without lag/anchor = wrong" case.
  fakeout:          'fog_lowconf',
  exhaustion:       'fog_lowconf',
  unclear:          'fog_lowconf',
};

/**
 * RegimeBucket -> the StrategyFamily values considered wrong-kit in that
 * bucket. Families never listed here (basis-lag, late-displacement,
 * probability-model, pattern) are regime-neutral under this map for every
 * bucket — see module doc.
 */
export const WRONG_KIT_FAMILIES: Record<RegimeBucket, readonly StrategyFamily[]> = {
  trend_expansion:   ['mean-reversion'],
  range_compression: ['breakout'],
  fog_lowconf:       ['momentum'],
};

/**
 * True when `family` is wrong-kit for `regime` under the shared map above.
 * A `family` of `undefined` (a strategy missing family metadata — should
 * not happen for any live STRATEGIES entry, but the lookup is optional at
 * the strategy-library.ts boundary) is never wrong-kit: absence of family
 * data is not evidence of a mismatch, so it must not be penalized as one.
 */
export function isWrongKitFamily(regime: MarketRegimeTag, family: StrategyFamily | undefined): boolean {
  if (!family) return false;
  const bucket = REGIME_TO_BUCKET[regime];
  return WRONG_KIT_FAMILIES[bucket].includes(family);
}

/** Human-readable one-liner of the map, for report footers (FAIR METRICS
 *  HARDENING Item 1 requires the map to be documented in the report, not
 *  just in code comments). */
export const WRONG_KIT_FORMULA_SUMMARY =
  'wrong_kit = share of admitted trades whose strategy family conflicts with the causal regime label at decision time ' +
  '(trend/expansion regime + mean-reversion family; range/squeeze regime + breakout family; fog/low-conviction regime + pure-momentum family). ' +
  'Applied identically to both policies, independent of pack filtering — see wrong-kit.ts.';
