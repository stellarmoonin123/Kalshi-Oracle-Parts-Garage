/**
 * Test-only preload. Sets STRATEGY_LEARNING_DATA_DIR to a unique temp
 * directory BEFORE any test file imports strategy-learner (DATA_DIR is
 * captured at module load). Prevents resetLearning() / recordOutcome()
 * fixtures from writing apps/api-server/data/strategy-learning.json.
 *
 * Wired into package.json "test" via --import. Do not use from dev/start.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'strategy-learner-test-'));
process.env.STRATEGY_LEARNING_DATA_DIR = dir;
process.env.PAPER_LEDGER_DATA_DIR = dir;
process.on('exit', () => {
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* best effort */ }
});

// Many lock tests read the operator's runtime .bot-config.json (gitignored).
// On a fresh clone / CI it is absent — seed it from the committed production
// fixture (captured from the Fly desk 2026-09-24, paperMode true, $313 start)
// so tests exercise the real doctrine instead of dying with ENOENT.
{
  const here = path.dirname(new URL(import.meta.url).pathname);
  const runtime = path.join(here, '.bot-config.json');
  const fixture = path.join(here, 'test-fixtures', 'bot-config.production.json');
  if (!fs.existsSync(runtime) && fs.existsSync(fixture)) {
    try { fs.copyFileSync(fixture, runtime); } catch { /* read-only checkout: tests will report */ }
  }
}
