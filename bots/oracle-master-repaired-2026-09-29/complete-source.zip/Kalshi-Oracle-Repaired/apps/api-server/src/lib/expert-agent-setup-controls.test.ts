import test from "node:test";
import assert from "node:assert/strict";
import {
  expertAgent,
  parseSetupControls,
} from "./expert-agent.js";
import { tradingBot } from "./trading-bot.js";

// Importing the bot restores its singleton; don't allow its timer to run in this
// pure policy test.
tradingBot.stop();

test("AI setup controls clamp to safe absolute ranges", () => {
  assert.deepEqual(parseSetupControls({
    minMTFScoreForLong: 99,
    maxMTFScoreForShort: -99,
    settlementHoldSecsThreshold: -10,
    settlementHoldMinProb: 5,
    minAddConfidence: 999,
  }), {
    minMTFScoreForLong: 4,
    maxMTFScoreForShort: -4,
    settlementHoldSecsThreshold: 60,
    settlementHoldMinProb: 0.95,
    minAddConfidence: 95,
  });
});

test("invalid AI setup controls are ignored instead of changing setup policy", () => {
  assert.equal(parseSetupControls({ minMTFScoreForLong: "high", settlementHoldMinProb: null }), undefined);
  assert.equal(parseSetupControls(null), undefined);
  assert.equal(parseSetupControls(undefined), undefined);
  assert.equal(parseSetupControls({}), undefined);
});

test("AI setup controls only move every static threshold in the more-conservative direction", () => {
  const staticSetup = {
    minMTFScoreForLong: 1,
    maxMTFScoreForShort: -1,
    settlementHoldSecsThreshold: 540,
    settlementHoldMinProb: 0.58,
    addConfidenceThreshold: 80,
  };

  // A looser-than-static proposal (e.g. from a confused or adversarial
  // response) must never move the effective setting past the operator's
  // static value.
  const looser = parseSetupControls({
    minMTFScoreForLong: -2,          // lower bar for longs — must retain 1
    maxMTFScoreForShort: 3,          // higher bar for shorts — must retain -1
    settlementHoldSecsThreshold: 900, // wider hold window — must retain 540
    settlementHoldMinProb: 0.5,      // lower win-prob bar — must retain 0.58
    minAddConfidence: 50,            // lower add-to-position bar — must retain 80
  })!;
  const effectiveFromLooser = {
    minMTFScoreForLong: Math.max(staticSetup.minMTFScoreForLong, looser.minMTFScoreForLong!),
    maxMTFScoreForShort: Math.min(staticSetup.maxMTFScoreForShort, looser.maxMTFScoreForShort!),
    settlementHoldSecsThreshold: Math.min(staticSetup.settlementHoldSecsThreshold, looser.settlementHoldSecsThreshold!),
    settlementHoldMinProb: Math.max(staticSetup.settlementHoldMinProb, looser.settlementHoldMinProb!),
    addConfidenceThreshold: Math.max(staticSetup.addConfidenceThreshold, looser.minAddConfidence!),
  };
  assert.deepEqual(effectiveFromLooser, staticSetup);

  // A tighter-than-static proposal must actually take effect.
  const tighter = parseSetupControls({
    minMTFScoreForLong: 3,
    maxMTFScoreForShort: -3,
    settlementHoldSecsThreshold: 120,
    settlementHoldMinProb: 0.9,
    minAddConfidence: 92,
  })!;
  const effectiveFromTighter = {
    minMTFScoreForLong: Math.max(staticSetup.minMTFScoreForLong, tighter.minMTFScoreForLong!),
    maxMTFScoreForShort: Math.min(staticSetup.maxMTFScoreForShort, tighter.maxMTFScoreForShort!),
    settlementHoldSecsThreshold: Math.min(staticSetup.settlementHoldSecsThreshold, tighter.settlementHoldSecsThreshold!),
    settlementHoldMinProb: Math.max(staticSetup.settlementHoldMinProb, tighter.settlementHoldMinProb!),
    addConfidenceThreshold: Math.max(staticSetup.addConfidenceThreshold, tighter.minAddConfidence!),
  };
  assert.deepEqual(effectiveFromTighter, {
    minMTFScoreForLong: 3,
    maxMTFScoreForShort: -3,
    settlementHoldSecsThreshold: 120,
    settlementHoldMinProb: 0.9,
    addConfidenceThreshold: 92,
  });
});

test("stale AI assessment supplies no setup-control overrides", () => {
  const old = expertAgent.lastAssessment;
  try {
    expertAgent.lastAssessment = {
      ts: Date.now() - 301_000,
      signal: "YES",
      confidence: 90,
      reasoning: "old",
      observations: [],
      riskLevel: "LOW",
      confAdj: 10,
      setupControls: { minMTFScoreForLong: 4, settlementHoldMinProb: 0.9 },
    };
    assert.equal(expertAgent.getSetupControlOverrides(), null);
  } finally {
    expertAgent.lastAssessment = old;
  }
});

test("fresh AI assessment without setupControls leaves setup policy untouched", () => {
  const old = expertAgent.lastAssessment;
  try {
    expertAgent.lastAssessment = {
      ts: Date.now(),
      signal: "WAIT",
      confidence: 60,
      reasoning: "no setup opinion this cycle",
      observations: [],
      riskLevel: "MEDIUM",
      confAdj: 0,
    };
    assert.equal(expertAgent.getSetupControlOverrides(), null);
  } finally {
    expertAgent.lastAssessment = old;
  }
});

test("fresh AI assessment with setupControls surfaces the clamped overrides", () => {
  const old = expertAgent.lastAssessment;
  try {
    expertAgent.lastAssessment = {
      ts: Date.now(),
      signal: "WAIT",
      confidence: 60,
      reasoning: "tightening into chop",
      observations: [],
      riskLevel: "MEDIUM",
      confAdj: 0,
      setupControls: parseSetupControls({ minMTFScoreForLong: 3, minAddConfidence: 90 }),
    };
    assert.deepEqual(expertAgent.getSetupControlOverrides(), { minMTFScoreForLong: 3, minAddConfidence: 90 });
  } finally {
    expertAgent.lastAssessment = old;
  }
});
