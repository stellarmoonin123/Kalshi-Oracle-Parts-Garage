/**
 * kalshi-ws.ts
 *
 * Singleton that maintains a live WebSocket connection to Kalshi's streaming
 * API (wss://api.elections.kalshi.com/trade-api/ws/v2).
 *
 * Lifecycle:
 *  1. Fetch the active KXBTC15M ticker, floor_strike, and close_time from REST.
 *  2. Open an authenticated WS and subscribe to "ticker" + CFB BRTI
 *     (cfbenchmarks_value_5hz + cfbenchmarks_value). BRTI is separate oracle state.
 *  3. On each ticker update, broadcast to all registered SSE listeners.
 *  4. REST is a FAIL-CLOSED backstop (250 ms healthy / 200 ms when WS is down).
 *     Apply REST when WS lacks an executable 1–99¢ ask, or quoteTs >1 s —
 *     never overwrite a live executable WS book, never present REST as "live".
 *  5. At the active KXBTC15M closeTime (+1.5 s buffer): check for period
 *     rollover via REST and re-subscribe. The 60 s interval is a BACKSTOP
 *     only — without the close-timed check the countdown/book could quote
 *     the previous 15m contract for up to a minute (#384 / #385).
 *  6. Reconnect with tight exponential back-off (250 ms → 8 s) on error / close.
 *     JSON + protocol ping every 8 s; silence >12 s forces reconnect.
 */

import WebSocket from "ws";
import { normalisePem, signKalshi, kalshiAuthHeadersAsync } from "./kalshi-auth.js";
import { db, kalshiL2Snapshots, kalshiMarketTrades } from "@workspace/db";
import { incidentStore } from "./incident-store.js";
import { OrderBookSuspicionTracker } from "./orderbook-suspicion.js";
import { L2SnapshotPersistence } from "./l2-snapshot-persistence.js";
import { bookMidCents } from "./kalshi-book-mid.js";
import { isValidKalshiPrice } from "./kalshi-order-body.js";
import { freshestEntryQuote, type EntryQuoteOrigin, type ObSnap } from "./orderbook-consistency.js";

// ── Types ──────────────────────────────────────────────────────────────────────


/** CF Benchmarks BRTI oracle — separate from KalshiTick book fields. */
export interface BrtiOracleTick {
  indexId: string;
  /** Instantaneous BRTI USD from 5Hz channel (preferred) or 1Hz raw. */
  valueUsd: number;
  sourceTsMs: number;
  receivedAtMs: number;
  channel: "cfbenchmarks_value_5hz" | "cfbenchmarks_value";
  /** Trailing 60s average from 1Hz channel (settlement TWAP alignment). */
  avg60sUsd: number | null;
  /** Final-minute quarter-hour 60s window average when present. */
  last60sWindowed15mUsd: number | null;
}

export interface KalshiTick {
  ticker:       string;
  floorStrike:  number;
  /** ISO-8601 contract close time — the authoritative countdown target */
  closeTime:    string;
  yesPrice:     number;   // one-sided-safe mid bid/ask, 0-100
  yesBid:       number;
  yesAsk:       number;
  noPrice:      number;
  noBid:        number;
  noAsk:        number;
  lastPrice:    number;
  volume:       number;
  openInterest: number;
  /** Source of this tick: "ws" = WebSocket push, "rest" = REST poll */
  source:       "ws" | "rest";
  ts:           number;
  /**
   * Timestamp of the last message that contained a REAL executable quote.
   * WS heartbeats with all-zero bid/ask carry forward the previous quote for
   * UI continuity but must NOT count as fresh for trading — `ts` is the
   * message time, `quoteTs` is the quote time. Execution guards use quoteTs.
   */
  quoteTs:      number;
}

type Listener = (tick: KalshiTick) => void;

/**
 * GO EXECUTION INTEGRITY BATCH — A5 (2026-08-16). Pure predicate extracted
 * from the 24/7 heartbeat's setInterval body so the "never judge WS silence
 * off a REST-refreshed timestamp" rule is directly unit-testable. See
 * `_lastWsMessageTs`'s doc comment on KalshiWSManager for the full bug this
 * guards against. `lastWsMessageTs === null` means the WS has never
 * delivered a single message since this process started — not yet silence
 * to react to here, so this returns false (the normal connect/reconnect
 * back-off path handles a WS that never opens at all).
 */
export const WS_SILENCE_THRESHOLD_MS = 12_000;
export const WS_HEARTBEAT_INTERVAL_MS = 4_000;
export const WS_PING_INTERVAL_MS = 8_000;
export const MIN_BACKOFF_MS = 250;
export const MAX_BACKOFF_MS = 8_000;
export const NO_TICKER_RETRY_MS = 1_000;
export const NO_CREDS_RETRY_MS = 5_000;
export const PRICE_POLL_HEALTHY_MS = 250;
export const PRICE_POLL_DEGRADED_MS = 200;
export const REST_POLL_TIMEOUT_MS = 1_500;
/** R3 final — at most one by-ticker quote read per second during the open-list lag (429 safety). */
export const BY_TICKER_QUOTE_MIN_MS = 1_000;

export function nextWsReconnectBackoffMs(prevMs: number): number {
  const base = Number.isFinite(prevMs) && prevMs > 0 ? prevMs : MIN_BACKOFF_MS;
  return Math.min(Math.max(base, MIN_BACKOFF_MS) * 2, MAX_BACKOFF_MS);
}

/** Age of last-observed quote/print. Missing stamp → Infinity (skip, never invent). */
export function feedAgeMs(observedAt: number | null | undefined, nowMs: number): number {
  if (observedAt == null || !(observedAt > 0) || !Number.isFinite(observedAt)) {
    return Number.POSITIVE_INFINITY;
  }
  return nowMs - observedAt;
}

export type LastGoodFeed<T> = {
  value: T;
  observedAt: number;
  ageMs: number;
  stale: boolean;
};

/** Last-observed + age, or null to skip. Never synthesizes a mid. */
export function lastGoodOrSkip<T>(
  last: { value: T; observedAt: number } | null | undefined,
  nowMs: number,
  staleMs: number,
): LastGoodFeed<T> | null {
  if (!last || last.observedAt <= 0) return null;
  const ageMs = feedAgeMs(last.observedAt, nowMs);
  return { value: last.value, observedAt: last.observedAt, ageMs, stale: ageMs > staleMs };
}

export function shouldForceReconnectOnSilence(
  lastWsMessageTs: number | null,
  nowMs: number,
  silenceThresholdMs = WS_SILENCE_THRESHOLD_MS,
  socketOpen = true,
): boolean {
  // 2026-09-24 livelock fix: only an OPEN socket can be "silent". While the
  // socket is closed/connecting, _lastWsMessageTs stays frozen at the last
  // message of the DEAD socket, so this used to fire every 4s forever —
  // terminating every in-flight connect() (auth + REST market lookup can take
  // >4s on Fly) and resetting backoff. Desk stayed "WS degraded — entries
  // paused" for hours until a machine restart. Reconnect of a closed socket is
  // owned by scheduleReconnect()/backoff + the handshake timeout instead.
  if (!socketOpen) return false;
  if (lastWsMessageTs == null) return false;
  return nowMs - lastWsMessageTs > silenceThresholdMs;
}

/** Max time for the WS HTTP upgrade before we treat it as a failed attempt. */
export const WS_HANDSHAKE_TIMEOUT_MS = 10_000;
/** Max time for one whole connect attempt (auth headers + market lookup). */
export const WS_CONNECT_ATTEMPT_TIMEOUT_MS = 20_000;
/** An in-flight attempt younger than this is not torn down by forceReconnect(). */
export const WS_FORCE_RECONNECT_GRACE_MS = 15_000;

export type WsSocketState = "open" | "connecting" | "closed";

/**
 * Should an external forceReconnect() (watchdog / heartbeat / quote recovery)
 * tear down the current attempt? Never kill a young in-flight connect or
 * handshake — that was the other half of the livelock.
 */
export function shouldTearDownForForceReconnect(input: {
  socketState: WsSocketState;
  connectInFlightSinceMs: number | null;
  nowMs: number;
  graceMs?: number;
}): boolean {
  const grace = input.graceMs ?? WS_FORCE_RECONNECT_GRACE_MS;
  if (input.connectInFlightSinceMs != null && input.nowMs - input.connectInFlightSinceMs < grace) return false;
  return true;
}

/** Race a promise against a timeout (rejects with a labelled Error). */
export function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
    p.then(v => { clearTimeout(t); resolve(v); }, e => { clearTimeout(t); reject(e); });
  });
}

import { KALSHI_SERIES_15M, KALSHI_SERIES_1H, KALSHI_REST_BASE, KALSHI_WS_URL, KALSHI_WS_PATH, WS_DEGRADED_THRESHOLD } from "./constants.js";

// ── Constants ─────────────────────────────────────────────────────────────────

const WS_URL            = KALSHI_WS_URL;
const REST_BASE         = KALSHI_REST_BASE;
const WS_PATH           = KALSHI_WS_PATH;
/**
 * #384 / #385 — 15m KXBTC15M rollover.
 *
 * OLD: the only rollover check was this 60 s interval, so the countdown
 * and live L2 book could keep the previous contract for up to a minute.
 * NEW: a one-shot timer fires ~1.5 s after closeTime (retry every 1 s
 * until the next 15m ticker is listed). 60 s remains a backstop only.
 */
export const ROLLOVER_INTERVAL_MS = 60_000;
export const ROLLOVER_CLOSE_BUFFER_MS = 1_500;
export const ROLLOVER_MIN_DELAY_MS = 500;
export const ROLLOVER_RETRY_MS = 1_000;
const ROLLOVER_INTERVAL = ROLLOVER_INTERVAL_MS;

/**
 * Delay until we should look up the next KXBTC15M contract.
 * Returns null when closeTime is missing/invalid (caller keeps the 60 s backstop).
 * Near/after close this is ~1.5 s (min 500 ms) — never the old 60 s wait.
 */
export function rolloverCheckDelayMs(closeTimeIso: string, nowMs: number): number | null {
  if (!closeTimeIso) return null;
  const closeMs = Date.parse(closeTimeIso);
  if (!Number.isFinite(closeMs)) return null;
  return Math.max(ROLLOVER_MIN_DELAY_MS, closeMs - nowMs + ROLLOVER_CLOSE_BUFFER_MS);
}

/**
 * After a close-timed check, if Kalshi has not listed the next KXBTC15M yet
 * (null market, or the expired ticker still "active"), retry in ~1 s instead
 * of waiting for the 60 s backstop.
 */
export function shouldRetryRolloverSoon(
  fetched: { ticker: string } | null,
  activeTicker: string,
  activeCloseTimeIso: string,
  nowMs: number,
): boolean {
  if (fetched && fetched.ticker !== activeTicker) return false;
  const closeMs = Date.parse(activeCloseTimeIso);
  if (!Number.isFinite(closeMs)) return false;
  return nowMs + ROLLOVER_CLOSE_BUFFER_MS >= closeMs;
}

/**
 * D10 — deterministic next KXBTC15M ticker from the active contract's
 * close_time. Kalshi lists the next 15m in `status=open` only ~15–46 s after
 * the boundary, but the market exists (status "initialized") well before and
 * can be read by ticker. Ticker = KXBTC15M-<YY><MON><DD><HHMM>-<MM> in ET of
 * the NEXT close (close + 15 min). Null for an unparsable close.
 */
export { kxbtc15mTickerForCloseMs, nextKxbtc15mTicker } from "./kxbtc15m-ticker.js";
import { nextKxbtc15mTicker } from "./kxbtc15m-ticker.js";

/** R3 final — exact by-ticker REST read of an ACTIVE market (quotes fallback during the open-list lag). */
export async function fetchActiveMarketByTicker<T extends { ticker: string; status: string } = any>(
  ticker: string,
  fetchImpl: typeof fetch = fetch,
): Promise<T | null> {
  if (!ticker) return null;
  try {
    const r = await fetchImpl(`${REST_BASE}/markets/${encodeURIComponent(ticker)}`, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(REST_POLL_TIMEOUT_MS),
    });
    if (!r.ok) return null;
    const m = ((await r.json()) as { market?: T }).market;
    return m && m.ticker === ticker && (m.status === "active" || m.status === "open") ? m : null;
  } catch {
    return null;
  }
}

/**
 * D10 — adopt a by-ticker read of the next contract at close only when it is
 * really tradable-shaped: status active/open, a strike, and a close_time in
 * the future. An "initialized" market (strike TBD) is NOT adopted — the ~1 s
 * rollover retry keeps polling. Entry timing is unchanged: the 180 s rule and
 * frozen time window still gate entries off secsRemaining.
 */
export function adoptableNextMarket(
  m: { ticker?: string; status?: string; floor_strike?: number | null; cap_strike?: number | null; close_time?: string } | null | undefined,
  expectedTicker: string,
  nowMs: number,
): { ticker: string; floorStrike: number; closeTime: string } | null {
  if (!m || m.ticker !== expectedTicker) return null;
  if (m.status !== "active" && m.status !== "open") return null;
  const strike = m.floor_strike ?? m.cap_strike;
  if (typeof strike !== "number" || !Number.isFinite(strike) || strike <= 0) return null;
  const closeMs = Date.parse(m.close_time ?? "");
  if (!Number.isFinite(closeMs) || closeMs <= nowMs) return null;
  return { ticker: m.ticker, floorStrike: strike, closeTime: m.close_time as string };
}

/** Never serve the previous 15m book's depth as the current contract. */
export function orderbookMatchesActiveTicker(
  ob: { ticker: string } | null | undefined,
  activeTicker: string,
): boolean {
  return !!ob && !!activeTicker && ob.ticker === activeTicker;
}

/** Live YES/NO odds window. REST older than this must not render as live. */
export const WS_LIVE_QUOTE_MS = 5_000;
export const KALSHI_PERPS_TICKER = "KXBTCPERP";

export type ViewBookId = "15m" | "1h" | "perps";

export function parseViewBook(v: unknown): ViewBookId {
  if (v === "1h" || v === "perps" || v === "15m") return v;
  if (typeof v === "string") {
    const n = v.trim().toLowerCase();
    if (n === "1h" || n === "perps" || n === "15m") return n;
  }
  return "15m";
}

export type RestApplyDecision = "skip_ws_live" | "apply_fallback" | "skip_no_quotes";

/**
 * REST poll may fill a silent/empty book for the bot, but must not clobber
 * a live WS quote. UI treats REST as not-live (fail-closed).
 */
/** REST may refresh when quoteTs older than this even if WS heartbeats are live. */
export const REST_REFRESH_QUOTE_MS = 1_000;

/** True when at least one side has an executable Kalshi ask (1–99¢). */
export function hasExecutableKalshiAsk(
  q: { yesAsk?: number | null; noAsk?: number | null } | null | undefined,
): boolean {
  if (!q) return false;
  return isValidKalshiPrice(Number(q.yesAsk)) || isValidKalshiPrice(Number(q.noAsk));
}

/**
 * WS side is adoptable when its ask is executable (1–99¢). Bid may be 0 on a
 * one-sided book — requiring bid>0 falsely kept invalid 0/100 prev asks while
 * quoteTs advanced and blocked REST (sticky PRICE FEED STALLED).
 */
export function isWsSideAskFresh(ask: number | null | undefined): boolean {
  return isValidKalshiPrice(Number(ask));
}


export function shouldApplyRestQuote(opts: {
  lastWsMessageTs: number | null;
  latest: { source: "ws" | "rest"; quoteTs: number; yesBid: number; yesAsk: number; noBid: number; noAsk: number } | null;
  restHasQuotes: boolean;
  nowMs: number;
  liveThresholdMs?: number;
  /** Quote-age floor for REST refresh (default REST_REFRESH_QUOTE_MS). */
  restRefreshMs?: number;
}): RestApplyDecision {
  if (!opts.restHasQuotes) return "skip_no_quotes";
  const threshold = opts.liveThresholdMs ?? WS_LIVE_QUOTE_MS;
  const refreshMs = opts.restRefreshMs ?? REST_REFRESH_QUOTE_MS;
  const latest = opts.latest;
  if (!latest || latest.source !== "ws") return "apply_fallback";
  // Invalid-only books (0¢/100¢) must NOT block REST — they are not executable.
  if (!hasExecutableKalshiAsk(latest)) return "apply_fallback";
  const quoteAge = opts.nowMs - (latest.quoteTs || 0);
  const wsAge = opts.lastWsMessageTs == null ? Number.POSITIVE_INFINITY : opts.nowMs - opts.lastWsMessageTs;
  // Skip only when BOTH WS messages AND the executable quote are fresh.
  // Quiet books: WS heartbeats keep wsAge low while quoteTs ages — refresh via REST.
  if (quoteAge <= refreshMs && wsAge <= threshold) return "skip_ws_live";
  return "apply_fallback";
}

/**
 * Market/Trade "live odds" predicate. REST is never live. A silent WS
 * (or a quote older than 5s) is stale even if a REST poll just ran.
 */
export function isLiveWsOdds(opts: {
  source: "ws" | "rest";
  quoteTs: number;
  lastWsMessageTs: number | null;
  nowMs: number;
  liveThresholdMs?: number;
}): boolean {
  if (opts.source !== "ws") return false;
  const threshold = opts.liveThresholdMs ?? WS_LIVE_QUOTE_MS;
  if (opts.nowMs - (opts.quoteTs || 0) > threshold) return false;
  if (opts.lastWsMessageTs != null && opts.nowMs - opts.lastWsMessageTs > threshold) return false;
  if (opts.lastWsMessageTs == null) return false;
  return true;
}

/**
 * Live real-money fills require WS. Paper fake-cash uses the same evaluate
 * brain; REST is the executable book when keys/WS are missing. STALE_QUOTE
 * (5s msg / 60s quote) still refuses a frozen REST poll. UI isLiveWsOdds
 * stays false for REST.
 */
export function restQuoteBlocksFill(paperMode: boolean, source: string | undefined | null): boolean {
  if (paperMode === true) return false;
  return source !== "ws";
}

export interface HourlyMarketCandidate {
  ticker: string;
  status: string;
  close_time: string;
  floor_strike?: number;
  cap_strike?: number;
  yes_bid_dollars?: string;
  yes_ask_dollars?: string;
  yes_bid?: number;
  yes_ask?: number;
}

function hourlyYesMid(m: HourlyMarketCandidate): number {
  const bid = m.yes_bid_dollars != null ? Math.round(parseFloat(m.yes_bid_dollars) * 100)
    : (typeof m.yes_bid === "number" && Number.isFinite(m.yes_bid) ? Math.round(m.yes_bid) : 0);
  const ask = m.yes_ask_dollars != null ? Math.round(parseFloat(m.yes_ask_dollars) * 100)
    : (typeof m.yes_ask === "number" && Number.isFinite(m.yes_ask) ? Math.round(m.yes_ask) : 0);
  return bookMidCents(bid, ask);
}

/** ATM 1h contract: current hour, quoted book, YES mid closest to 50¢. */
export function pickAtmHourlyMarket(
  markets: HourlyMarketCandidate[],
  nowMs: number,
): { ticker: string; floorStrike: number; closeTime: string } | null {
  const active = markets.filter(m =>
    m.status === "active" &&
    (m.floor_strike != null || m.cap_strike != null) &&
    Date.parse(m.close_time) > nowMs,
  );
  if (active.length === 0) return null;
  const earliest = Math.min(...active.map(m => Date.parse(m.close_time)));
  const quoted = active
    .filter(m => Date.parse(m.close_time) === earliest)
    .filter(m => hourlyYesMid(m) > 0)
    .sort((a, b) => Math.abs(hourlyYesMid(a) - 50) - Math.abs(hourlyYesMid(b) - 50));
  const m = quoted[0] ?? active.find(x => Date.parse(x.close_time) === earliest);
  if (!m) return null;
  return {
    ticker: m.ticker,
    floorStrike: (m.floor_strike ?? m.cap_strike ?? 0) as number,
    closeTime: m.close_time ?? "",
  };
}
// Poll REST for fresh bid/ask on an ADAPTIVE cadence. While the WS is HEALTHY
// this poll is only a correctness backstop (the WS push is the live path).
// While the WS is DEGRADED/disconnected REST is the DOMINANT 15m price path,
// so we poll at PRICE_POLL_DEGRADED_MS. Never invent a mid — REST applies only
// when shouldApplyRestQuote says so, and last-good quoteTs stays visible.
const PRICE_POLL_MS     = PRICE_POLL_HEALTHY_MS;
const MIN_BACKOFF       = MIN_BACKOFF_MS;
const MAX_BACKOFF       = MAX_BACKOFF_MS;

// ── RSA-PSS auth ─────────────────────────────────────────────────────────────
// Signing is delegated to kalshi-auth.ts which handles PKCS#8 RSA, PKCS#8
// RSA-PSS (id-RSASSA-PSS OID rejected by OpenSSL 3.x), and PKCS#1 keys.

/**
 * Build the authenticated headers used when opening the Kalshi WebSocket.
 *
 * Keep this as the WS auth boundary rather than constructing headers inside
 * the connection lifecycle so its timestamp contract can be regression-tested
 * independently of a live socket.
 */
export function buildKalshiWsAuthHeaders(): Promise<Record<string, string>> {
  return kalshiAuthHeadersAsync("GET", WS_PATH);
}

/**
 * Normalize the two Kalshi order-book response formats to cent-priced levels.
 *
 * The API occasionally represents an empty side (or an empty level) with an
 * empty string. Keep those levels out of the derived top-of-book fields:
 * `null` is a valid value for a missing side, while `""` is not a valid
 * PostgreSQL integer and causes the entire L2 batch insert to fail.
 */
export function normalizeOrderbookLevels(
  levels: unknown,
  pricesAreDollars = false,
): [number, number][] {
  if (!Array.isArray(levels)) return [];

  return levels.flatMap((level): [number, number][] => {
    if (!Array.isArray(level) || level.length < 2) return [];

    const [rawPrice, rawQuantity] = level;
    if (
      (typeof rawPrice === "string" && rawPrice.trim() === "") ||
      (typeof rawQuantity === "string" && rawQuantity.trim() === "")
    ) {
      return [];
    }

    const price = typeof rawPrice === "number" ? rawPrice : Number(rawPrice);
    const quantity = typeof rawQuantity === "number" ? rawQuantity : Number(rawQuantity);
    if (!Number.isFinite(price) || !Number.isFinite(quantity)) return [];

    return [[pricesAreDollars ? Math.round(price * 100) : Math.round(price), quantity]];
  });
}

// ── KalshiWSManager ───────────────────────────────────────────────────────────

interface ActiveMarket {
  ticker:      string;
  floorStrike: number;
  closeTime:   string;
}

class KalshiWSManager {
  private ws:              WebSocket | null = null;
  // 2026-08-25 audit fix: a stale socket's own late "open"/"message"/"error"
  // events used to be able to fire (and mutate shared backoff/degraded state,
  // or feed handleMessage) even after a NEWER socket had already replaced
  // it — `this.ws === ws` was only checked in the "close" handler. Each
  // connect() attempt now gets its own generation number; every handler
  // below verifies it's still the current generation before touching
  // anything, closing that race for good.
  private wsGeneration     = 0;
  private listeners        = new Set<Listener>();
  private latest:          KalshiTick | null = null;
  /** Official CF Benchmarks BRTI — never mixed into KalshiTick book fields. */
  private brtiOracle:     BrtiOracleTick | null = null;
  private brti5hzSid:     number | null = null;
  private brti1hzSid:     number | null = null;
  private active:          ActiveMarket = { ticker: "", floorStrike: 0, closeTime: "" };
  private backoff          = MIN_BACKOFF;
  private reconnectTimer:  NodeJS.Timeout | null = null;
  private _pingTimer:      NodeJS.Timeout | null = null;
  private rolloverTimer:   NodeJS.Timeout | null = null;
  /** One-shot timer scheduled to fire right at (closeTime + buffer) so a new
   *  contract is picked up immediately instead of waiting up to ROLLOVER_INTERVAL. */
  private rolloverCheckTimer: NodeJS.Timeout | null = null;
  private pricePoller:     NodeJS.Timeout | null = null;
  private l2CaptureTimer:  NodeJS.Timeout | null = null;
  private _l2Capturing     = false;
  /**
   * Bounded L2 buffer. Rows stay queued until their INSERT succeeds so a
   * transient DB fault cannot silently erase market-history observations.
   */
  private _l2Persistence = new L2SnapshotPersistence({
    insert: (rows) => db.insert(kalshiL2Snapshots).values(rows).then(() => undefined),
    enterDegraded: (reason) => incidentStore.enterDegraded("orderbook", reason),
    exitDegraded: () => incidentStore.exitDegraded("orderbook"),
  });
  /** Rolling L2 history, used only to flag unstable displayed liquidity. */
  private _orderbookSuspicion = new OrderBookSuspicionTracker();
  /** Latest raw orderbook snapshot (for the /kalshi/orderbook route) */
  private _latestOrderbook: { ticker: string; yesBids: [number,number][]; yesAsks: [number,number][]; ts: number } | null = null;
  /** Recent market trades (last 50) */
  private _recentMarketTrades: Array<{ tradeId: string; count: number; yesPriceCents: number; noPriceCents: number; takerSide: string; createdAt: string }> = [];
  private seq              = 0;
  private started          = false;
  private consecutiveFailures = 0;
  /** Current REST price-poll cadence (adaptive: fast while degraded). */
  private _pricePollMs     = PRICE_POLL_HEALTHY_MS;
  /** Listeners woken only when a NEW executable quote arrives (quoteTs advances
   *  or a bid/ask side changes) — used by the bot to fire an event-driven tick
   *  instead of waiting out its idle timer. Distinct from the raw `listeners`
   *  set, which fires on every tick including zero-quote heartbeats. */
  private quoteListeners   = new Set<Listener>();
  private authErrLogged    = false;   // log auth failure once, retry silently
  private _degraded        = false;
  private degradedListeners = new Set<(degraded: boolean) => void>();
  /** Epoch ms when WS entered degraded state; null when healthy */
  private _degradedSince:  number | null = null;
  /** Rolling 10-min buffer of YES prices for contract volatility computation */
  private _priceHistory: Array<{ ts: number; yes: number }> = [];
  /** 24/7 heartbeat — forces reconnect when the feed goes silent */
  private _heartbeatTimer: NodeJS.Timeout | null = null;
  /**
   * GO EXECUTION INTEGRITY BATCH — A5 (2026-08-16): epoch ms of the last
   * message actually received ON THE WEBSOCKET SOCKET ITSELF (set only in
   * handleMessage). Deliberately separate from `this.latest.ts` /
   * `this.latest.quoteTs`, which pollRestPrices() (a REST fallback poll
   * running every 1-3s) ALSO overwrites with a fresh Date.now() and
   * source:"rest" whenever the WS is silent. Before this field existed, the
   * 24/7 heartbeat below (and any other consumer keyed on `latest.ts`) could
   * never detect a silently-hung WS connection — one that stays
   * `readyState === OPEN` with no error/close event but has simply stopped
   * delivering messages — because the healthy REST poll kept `latest.ts`
   * looking perfectly fresh underneath it. Only a real WS message may ever
   * advance this timestamp.
   */
  private _lastWsMessageTs: number | null = null;
  /** Epoch ms when the current connect() attempt started; null when idle. */
  private _connectInFlightSince: number | null = null;
  /** Monotonic id of connect() attempts; a superseded attempt aborts after its awaits. */
  private connectAttemptSeq = 0;
  /** Epoch ms of the last successful socket open. */
  private _lastOpenAt: number | null = null;
  private _reconnectSupervisor: NodeJS.Timeout | null = null;
  /**
   * Read-only view books (1h / perps). Never replace `active` / `latest`,
   * which remain the 15m execution ticker. SSE ?book= subscribes here.
   */
  private viewSlots = new Map<ViewBookId, ActiveMarket>();
  private viewLatest = new Map<string, KalshiTick>();
  private viewRefCount = new Map<ViewBookId, number>();
  private viewListeners = new Map<ViewBookId, Set<Listener>>();
  private _ensuringView = new Set<ViewBookId>();

  // ── Public API ──────────────────────────────────────────────────────────────

  /**
   * Returns the epoch-ms timestamp when WS first became degraded (null if healthy).
   * Reads from incidentStore so the value survives server restarts.
   */
  getDegradedSince(): number | null {
    return incidentStore.getDegradedSince("websocket") ?? this._degradedSince;
  }

  /** Returns count of WS degraded incidents in the rolling 24 h window (DB-backed). */
  async getIncidentCount24h(): Promise<number> {
    return incidentStore.getIncidentCount24h("websocket");
  }

  /** Returns WS incident start timestamps (epoch ms) for the rolling 24 h window (DB-backed). */
  async getIncidentTimestamps(): Promise<number[]> {
    return incidentStore.getIncidentTimestamps24h("websocket");
  }

  start() {
    if (this.started) return;
    this.started       = true;
    this.scheduleConnect();
    // Paper / no-keys: resolve the live 15m ticker immediately so REST polling
    // can feed the bot even while WS auth is missing. Previously active.ticker
    // stayed empty until PKCS#8 keys showed up, so lastSignal was "No Kalshi data".
    void this.bootstrapPublicBook().catch(err => console.error("[kalshi-ws] bootstrapPublicBook:", (err as Error).message));
    this.rolloverTimer = setInterval(() => { void this.refreshMarket(); }, ROLLOVER_INTERVAL);
    // Until the authenticated WS is actually open, REST is the live book.
    // Start at degraded cadence; WS open flips this back to PRICE_POLL_HEALTHY_MS.
    this._pricePollMs  = PRICE_POLL_DEGRADED_MS;
    this.pricePoller   = setInterval(() => {
      void this.pollRestPrices();
      void this.pollViewRestPrices();
    }, this._pricePollMs);
    // Five-second L2 capture provides enough resolution to distinguish
    // persistent depth from rapidly vanishing displayed liquidity. It is
    // still throttled to one in-flight request and only keeps 20 snapshots.
    this.l2CaptureTimer = setInterval(() => { void this.captureL2Snapshot(); }, 5_000);
    // Fetch market trade history every 2 min
    setInterval(() => { void this.fetchMarketTrades(); }, 120_000);
    // Initial fetches after 5 s (let the WS settle first)
    setTimeout(() => { void this.captureL2Snapshot(); },  5_000);
    setTimeout(() => { void this.fetchMarketTrades(); }, 10_000);

    // 24/7 heartbeat — if the feed goes silent for >12 s, force a reconnect.
    // This catches NAT timeouts, carrier-grade firewalls, and exchange-side
    // silent drops that don't trigger a close/error event on the WS.
    this._heartbeatTimer = setInterval(() => {
      // A5 fix: judge silence off the real WS socket clock (_lastWsMessageTs),
      // never off `this.latest.ts` — the REST backstop poll refreshes that
      // regardless of WS health and would mask an indefinitely hung socket.
      if (shouldForceReconnectOnSilence(this._lastWsMessageTs, Date.now(), WS_SILENCE_THRESHOLD_MS, this.getSocketState() === "open")) {
        const silentMs = Date.now() - this._lastWsMessageTs!;
        console.warn(`[kalshi-ws] WS socket silent for ${Math.round(silentMs / 1000)}s (no message received) — forcing reconnect for 24/7 uptime`);
        this.forceReconnect();
      }
    }, WS_HEARTBEAT_INTERVAL_MS);

    // Reconnect supervisor: if the socket is closed, no attempt is in flight
    // and no reconnect is scheduled (a lost timer), schedule one. Also aborts
    // a connect attempt that has hung past WS_CONNECT_ATTEMPT_TIMEOUT_MS.
    this._reconnectSupervisor = setInterval(() => {
      const now = Date.now();
      if (this._connectInFlightSince != null && now - this._connectInFlightSince > WS_CONNECT_ATTEMPT_TIMEOUT_MS + 5_000) {
        console.warn("[kalshi-ws] connect attempt hung — clearing in-flight flag");
        this._connectInFlightSince = null;
      }
      if (this.getSocketState() === "closed" && this._connectInFlightSince == null && !this.reconnectTimer) {
        console.warn("[kalshi-ws] supervisor: socket closed with no reconnect scheduled — scheduling");
        this.scheduleReconnect();
      }
    }, 15_000);
  }

  /** Real socket state (not the degraded flag). */
  getSocketState(): WsSocketState {
    const ws = this.ws;
    if (ws && ws.readyState === WebSocket.OPEN) return "open";
    if ((ws && ws.readyState === WebSocket.CONNECTING) || this._connectInFlightSince != null) return "connecting";
    return "closed";
  }

  /** Connection snapshot for /healthz, watchdog and bot status. */
  getConnectionState(): {
    socket: WsSocketState;
    degraded: boolean;
    consecutiveFailures: number;
    lastOpenAt: number | null;
    lastWsMessageTs: number | null;
    connectInFlightSince: number | null;
    backoffMs: number;
  } {
    return {
      socket: this.getSocketState(),
      degraded: this._degraded,
      consecutiveFailures: this.consecutiveFailures,
      lastOpenAt: this._lastOpenAt,
      lastWsMessageTs: this._lastWsMessageTs,
      connectInFlightSince: this._connectInFlightSince,
      backoffMs: this.backoff,
    };
  }

  getLatestOrderbook() {
    if (!orderbookMatchesActiveTicker(this._latestOrderbook, this.active.ticker)) return null;
    return this._latestOrderbook;
  }
  getL2PersistenceStatus() { return this._l2Persistence.getStatus(); }
  getOrderbookLiquidityInstability(direction: "yes" | "no") {
    return this._orderbookSuspicion.evaluate(direction);
  }
  getRecentMarketTrades() { return this._recentMarketTrades; }

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    if (this.latest) fn(this.latest);  // emit current snapshot immediately
    return () => this.listeners.delete(fn);
  }

  /**
   * Subscribe to NEW-executable-quote events only. The callback fires when a
   * tick arrives whose `quoteTs` advanced or whose bid/ask changed — i.e. a
   * real, tradeable price move — and NOT on zero-quote heartbeats that merely
   * carry forward the prior quote. The bot uses this to wake its decision tick
   * the instant a price moves, rather than waiting out its idle interval.
   * Does not emit the current snapshot on subscribe (only future changes).
   */
  onExecutableQuote(fn: Listener): () => void {
    this.quoteListeners.add(fn);
    return () => this.quoteListeners.delete(fn);
  }

  /**
   * Rebuild the REST price poller at the given cadence. Called when the WS
   * degraded state flips so the backstop poll speeds up while the WS is the
   * dominant latency path, and relaxes again once the WS recovers.
   */
  private restartPricePoller(intervalMs: number) {
    if (this._pricePollMs === intervalMs && this.pricePoller) return;
    this._pricePollMs = intervalMs;
    if (this.pricePoller) clearInterval(this.pricePoller);
    if (!this.started) return;
    this.pricePoller = setInterval(() => {
      void this.pollRestPrices();
      void this.pollViewRestPrices();
    }, intervalMs);
  }

  getLatest() { return this.latest; }

  /**
   * R4 — entry-evaluation quote: the WS tick, or (when the WS value lags a
   * newer same-ticker L2 book by >2¢) the tick with L2 top-of-book prices.
   * getLatestOrderbook() is already active-ticker guarded; freshestEntryQuote
   * re-checks tick/book ticker equality.
   */
  getLatestForEntry(now = Date.now()): KalshiTick | null {
    const r = freshestEntryQuote(this.getLatest(), this.getLatestOrderbook() as ObSnap | null, now);
    if (r.origin === "l2") this._entryQuoteFromL2Count++;
    this._lastEntryQuoteOrigin = r.origin;
    return r.tick;
  }
  private _entryQuoteFromL2Count = 0;
  private _lastEntryQuoteOrigin: EntryQuoteOrigin = "tick";
  getEntryQuoteStats() { return { fromL2Count: this._entryQuoteFromL2Count, lastOrigin: this._lastEntryQuoteOrigin }; }

  /** Latest CF Benchmarks BRTI oracle tick (5Hz preferred). Null until first frame. */
  getBrtiOracle(): BrtiOracleTick | null { return this.brtiOracle; }

  /** Fresh BRTI USD if observed within maxAgeMs; else null (never invent). */
  getFreshBrtiUsd(maxAgeMs = 2_000): number | null {
    const o = this.brtiOracle;
    if (!o || !(o.valueUsd > 0)) return null;
    const age = Date.now() - (o.receivedAtMs || o.sourceTsMs || 0);
    if (age > maxAgeMs) return null;
    return o.valueUsd;
  }

  /** Settlement-aligned 60s average when the 1Hz channel supplies it. */
  getBrtiAvg60sUsd(maxAgeMs = 5_000): number | null {
    const o = this.brtiOracle;
    if (!o || o.avg60sUsd == null || !(o.avg60sUsd > 0)) return null;
    const age = Date.now() - (o.receivedAtMs || 0);
    if (age > maxAgeMs) return null;
    return o.avg60sUsd;
  }

  /** WS socket clock — never REST. Used by SSE to fail-close live odds. */
  getLastWsMessageTs(): number | null { return this._lastWsMessageTs; }

  getViewLatest(book: ViewBookId): KalshiTick | null {
    if (book === "15m") return this.latest;
    const market = this.viewSlots.get(book);
    if (!market?.ticker) return null;
    return this.viewLatest.get(market.ticker) ?? null;
  }

  /**
   * Subscribe to the displayed book. 15m is the execution feed.
   * 1h/perps are read-only — they never write `this.latest`.
   */
  subscribeView(book: ViewBookId, fn: Listener): () => void {
    if (book === "15m") return this.subscribe(fn);
    void this.ensureViewBook(book);
    let set = this.viewListeners.get(book);
    if (!set) {
      set = new Set();
      this.viewListeners.set(book, set);
    }
    set.add(fn);
    const latest = this.getViewLatest(book);
    if (latest) fn(latest);
    return () => { set!.delete(fn); };
  }

  ensureViewBook(book: ViewBookId): void {
    const n = (this.viewRefCount.get(book) ?? 0) + 1;
    this.viewRefCount.set(book, n);
    if (book === "15m") return;
    if (this._ensuringView.has(book)) return;
    this._ensuringView.add(book);
    void this.resolveViewBook(book).finally(() => this._ensuringView.delete(book));
  }

  releaseViewBook(book: ViewBookId): void {
    const n = Math.max(0, (this.viewRefCount.get(book) ?? 0) - 1);
    this.viewRefCount.set(book, n);
  }

  /**
   * Returns the latest tick along with a staleness flag.
   * `stale: true` means the tick is older than `thresholdMs` (default 30 s) —
   * callers must not use stale prices for trade execution decisions.
   */
  getLatestWithStaleness(thresholdMs = 30_000): { tick: KalshiTick | null; stale: boolean; quoteAgeMs: number } {
    if (!this.latest) return { tick: null, stale: true, quoteAgeMs: Number.POSITIVE_INFINITY };
    const quoteAgeMs = feedAgeMs(this.latest.quoteTs, Date.now());
    return { tick: this.latest, stale: quoteAgeMs > thresholdMs, quoteAgeMs };
  }

  /**
   * Range (max − min) of the Kalshi YES mid price over the last `windowSecs`
   * seconds. High values mean the contract hasn't found its price yet — a wide
   * spread causes stop-outs on noise before the contract resolves.
   * Returns 0 when there's insufficient history (< 3 ticks).
   */
  getContractPriceVolatility(windowSecs = 120): number {
    const cutoff = Date.now() - windowSecs * 1_000;
    const prices = this._priceHistory.filter(p => p.ts >= cutoff).map(p => p.yes).filter(p => p > 0);
    if (prices.length < 3) return 0;
    return Math.max(...prices) - Math.min(...prices);
  }

  /** Recent YES price history for diagnostics. */
  getPriceHistorySample(maxPoints = 60): Array<{ ts: number; yes: number }> {
    return this._priceHistory.slice(-maxPoints);
  }

  isDegraded() { return this._degraded; }

  /**
   * Forcibly close the current WS connection and reconnect immediately.
   * Called by the watchdog when tick age exceeds the stale threshold.
   */
  forceReconnect() {
    if (!shouldTearDownForForceReconnect({
      socketState: this.getSocketState(),
      connectInFlightSinceMs: this._connectInFlightSince,
      nowMs: Date.now(),
    })) {
      console.info("[kalshi-ws] forceReconnect() skipped — a connect attempt is already in flight");
      // Still kick the REST backstop so quotes keep flowing meanwhile.
      void this.pollRestPrices();
      return;
    }
    console.info("[kalshi-ws] forceReconnect() called by watchdog");
    this.stopPing();
    if (this.ws) {
      // Bump generation first so the terminated socket's late events are ignored.
      this.wsGeneration++;
      try { this.ws.terminate(); } catch { /* ignore */ }
      this.ws = null;
    }
    this._connectInFlightSince = null;
    this.connectAttemptSeq++;     // abort any stale attempt still awaiting REST
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.backoff = MIN_BACKOFF;   // reset exponential back-off
    this.scheduleConnect();
    // WS thrash alone cannot heal rollover/quiet-book quote stalls — REST path too.
    const heldMs = this._pollingStartedAt > 0 ? Date.now() - this._pollingStartedAt : 0;
    if (this._polling && heldMs > REST_POLL_TIMEOUT_MS) {
      this._polling = false;
      this._pollingStartedAt = 0;
    }
    this.restartPricePoller(PRICE_POLL_DEGRADED_MS);
    void this.refreshMarket();
    void this.pollRestPrices();
  }

  /** Subscribe to degraded-state changes (true = WS failing, false = recovered). */
  onDegraded(fn: (degraded: boolean) => void): () => void {
    this.degradedListeners.add(fn);
    return () => this.degradedListeners.delete(fn);
  }

  /**
   * Schedules a one-shot rollover check timed to fire just after the active
   * contract's closeTime, instead of relying solely on the 60s ROLLOVER_INTERVAL
   * poll. Without this, the timer/floor-strike/orderbook could show the just-
   * expired contract's stale data for up to 60s into the new period.
   */
  private scheduleRolloverCheck() {
    if (this.rolloverCheckTimer) {
      clearTimeout(this.rolloverCheckTimer);
      this.rolloverCheckTimer = null;
    }
    const delay = rolloverCheckDelayMs(this.active.closeTime, Date.now());
    if (delay == null) return;
    this.rolloverCheckTimer = setTimeout(() => {
      void this.refreshMarket();
    }, delay);
  }

  /** #384: if the next KXBTC15M is not listed yet, retry in ~1s not 60s. */
  private scheduleRolloverRetrySoon() {
    if (this.rolloverCheckTimer) {
      clearTimeout(this.rolloverCheckTimer);
      this.rolloverCheckTimer = null;
    }
    this.rolloverCheckTimer = setTimeout(() => {
      void this.refreshMarket();
    }, ROLLOVER_RETRY_MS);
  }

  // ── REST: fetch active ticker + prices ────────────────────────────────────

  private async bootstrapPublicBook() {
    const market = await this.fetchActiveMarket();
    if (!market) {
      console.warn("[kalshi-ws] Public book: no active 15m ticker yet — REST poll will retry");
      return;
    }
    this.active = market;
    this.scheduleRolloverCheck();
    console.info(`[kalshi-ws] Public REST book armed (no WS keys needed). Market: ${market.ticker}`);
    await this.pollRestPrices();
  }

  private async fetchActiveMarket(): Promise<ActiveMarket | null> {
    try {
      const url = `${REST_BASE}/markets?series_ticker=${KALSHI_SERIES_15M}&status=open&limit=5`;
      const r   = await fetch(url, {
        headers: { Accept: "application/json" },
        signal:  AbortSignal.timeout(6_000),
      });
      if (!r.ok) return null;

      const data = (await r.json()) as {
        markets?: Array<{
          ticker:       string;
          status:       string;
          close_time:   string;
          floor_strike?: number;
          cap_strike?:  number;
        }>;
      };

      // D10 — never (re)adopt a contract past its close_time: Kalshi keeps the
      // expired 15m "active" in this list for ~10 s after the boundary, which
      // would flip a proactive rollover back to the dead ticker.
      const nowMs = Date.now();
      const m = (data.markets ?? []).find(
        m => m.status === "active" && (m.floor_strike != null || m.cap_strike != null)
          && !(Date.parse(m.close_time ?? "") <= nowMs),
      );
      if (!m) return null;

      return {
        ticker:      m.ticker,
        floorStrike: (m.floor_strike ?? m.cap_strike) as number,
        closeTime:   m.close_time ?? "",
      };
    } catch (err) {
      console.debug('[kalshi-ws] fetchActiveMarket error:', (err as Error).message);
      return null;
    }
  }

  /**
   * REST price poll — called every PRICE_POLL_MS.
   * WS is the live odds path. REST applies when WS lacks an executable ask
   * or quoteTs >1 s (shouldApplyRestQuote). Fail-closed for UI "live".
   */
  private _polling = false;
  /** Epoch ms when _polling flipped true; 0 when idle. Detects hung polls. */
  private _pollingStartedAt = 0;
  /** Rate-limit REST-miss → refreshMarket kicks (rollover gap). */
  private _rolloverMissKickAt = 0;
  private _byTickerQuoteAt = 0;

  /**
   * REST + rollover heal for quote freshness. Does not require a live WS.
   * Clears a stuck poll mutex, speeds the REST poller, and adopts the next
   * 15m when the open list has moved on. Optional WS reconnect for true
   * ticker-message silence (not quiet-book / rollover quote-only stale).
   */
  kickQuoteRecovery(opts: { reconnectWs?: boolean } = {}): void {
    const heldMs = this._pollingStartedAt > 0 ? Date.now() - this._pollingStartedAt : 0;
    if (this._polling && heldMs > REST_POLL_TIMEOUT_MS) {
      console.warn(`[kalshi-ws] kickQuoteRecovery: clearing stuck _polling after ${Math.round(heldMs / 1000)}s`);
      this._polling = false;
      this._pollingStartedAt = 0;
    }
    this.restartPricePoller(PRICE_POLL_DEGRADED_MS);
    void this.refreshMarket();
    void this.pollRestPrices();
    if (opts.reconnectWs === true) {
      this.forceReconnect();
    }
  }

  private async pollRestPrices() {
    if (!this.active.ticker) return;
    if (this._polling) {
      // Hung fetch: AbortSignal should clear within REST_POLL_TIMEOUT_MS; if not, unstick.
      const heldMs = this._pollingStartedAt > 0 ? Date.now() - this._pollingStartedAt : 0;
      if (heldMs > REST_POLL_TIMEOUT_MS * 2) {
        console.warn(`[kalshi-ws] pollRestPrices: clearing stuck _polling after ${Math.round(heldMs / 1000)}s`);
        this._polling = false;
        this._pollingStartedAt = 0;
      } else {
        return;          // don't overlap concurrent fetches
      }
    }
    this._polling = true;
    this._pollingStartedAt = Date.now();
    let kickRefreshAfter = false;

    try {
      // R4 live price lag (measured 06:24–06:25 ET Sep 25): the series
      // `status=open` LIST is served stale — it held yes 66/67¢ for 25 s+ while
      // the exact /markets/{ticker} read (and the L2 book) moved 81→93¢. This
      // poller stamped those list values with quoteTs=now, so entries were
      // judged on a lagging quote that looked fresh. Quotes now come from the
      // exact by-ticker read (≤1/s); the list is only a fallback when the
      // by-ticker read fails (exact ticker match still enforced).
      type RestMarket = {
        ticker:               string;
        status:               string;
        close_time:           string;
        floor_strike?:        number;
        cap_strike?:          number;
        yes_bid_dollars?:     string;
        yes_ask_dollars?:     string;
        no_bid_dollars?:      string;
        no_ask_dollars?:      string;
        last_price_dollars?:  string;
        yes_bid?:             number;
        yes_ask?:             number;
        no_bid?:              number;
        no_ask?:              number;
        last_price?:          number;
        volume_fp?:           string;
        open_interest_fp?:    string;
      };
      const nowMs = Date.now();
      if (nowMs - this._byTickerQuoteAt < BY_TICKER_QUOTE_MIN_MS) return;
      this._byTickerQuoteAt = nowMs;
      let m: RestMarket | undefined = (await fetchActiveMarketByTicker<RestMarket>(this.active.ticker)) ?? undefined;
      if (!m) {
        const url = `${REST_BASE}/markets?series_ticker=${KALSHI_SERIES_15M}&status=open&limit=5`;
        const r   = await fetch(url, {
          headers: { Accept: "application/json" },
          signal:  AbortSignal.timeout(REST_POLL_TIMEOUT_MS),
        });
        if (r.ok) {
          const data = (await r.json()) as { markets?: RestMarket[] };
          // Require an EXACT ticker match (never another strike's quote).
          m = (data.markets ?? []).find(x => x.status === "active" && x.ticker === this.active.ticker);
        }
      }
      if (!m) {
        // Rollover gap: active ticker left the open list (or not yet listed).
        // Defer refreshMarket until finally clears _polling so the follow-up
        // pollRestPrices inside refreshMarket is not a no-op.
        const now = Date.now();
        if (now - this._rolloverMissKickAt >= ROLLOVER_RETRY_MS) {
          this._rolloverMissKickAt = now;
          kickRefreshAfter = true;
          console.info(`[kalshi-ws] REST miss for ${this.active.ticker} — kicking refreshMarket (rollover gap)`);
        }
        return;
      }

      // Kalshi returns either *_dollars strings or integer-cent fields
      // depending on API shape — accept both, never let one format zero out quotes.
      const toCents = (d?: string, cents?: number): number =>
        d != null ? Math.round(parseFloat(d) * 100)
        : (typeof cents === "number" && Number.isFinite(cents) ? Math.round(cents) : 0);

      const yesBid  = toCents(m.yes_bid_dollars, m.yes_bid);
      const yesAsk  = toCents(m.yes_ask_dollars, m.yes_ask);
      const noBid   = toCents(m.no_bid_dollars,  m.no_bid);
      const noAsk   = toCents(m.no_ask_dollars,  m.no_ask);
      const yesPrice = bookMidCents(yesBid, yesAsk);
      const noPrice  = bookMidCents(noBid, noAsk);

      // All-zero quotes mean an unparseable response — never overwrite the
      // latest good WS tick with zeros (that feeds bot sizing and the UI).
      if (yesBid + yesAsk + noBid + noAsk === 0) return;
      // Do not replace an executable book with a 0¢/100¢ REST snapshot.
      const restExecutable = isValidKalshiPrice(yesAsk) || isValidKalshiPrice(noAsk);
      if (!restExecutable && hasExecutableKalshiAsk(this.latest)) return;

      const restDecision = shouldApplyRestQuote({
        lastWsMessageTs: this._lastWsMessageTs,
        latest: this.latest,
        restHasQuotes: true,
        nowMs: Date.now(),
      });
      if (restDecision === "skip_ws_live") return;

      // Update closeTime if we got a fresh one
      if (m.close_time && m.close_time !== this.active.closeTime) {
        this.active.closeTime = m.close_time;
        this.scheduleRolloverCheck();
      }

      const tick: KalshiTick = {
        ticker:       this.active.ticker,
        floorStrike:  this.active.floorStrike,
        closeTime:    this.active.closeTime,
        yesPrice,
        yesBid,
        yesAsk,
        noPrice,
        noBid,
        noAsk,
        lastPrice:    toCents(m.last_price_dollars, m.last_price) || yesPrice,
        volume:       m.volume_fp        ? parseFloat(m.volume_fp)        : (this.latest?.volume       ?? 0),
        openInterest: m.open_interest_fp ? parseFloat(m.open_interest_fp) : (this.latest?.openInterest ?? 0),
        source:       "rest",
        ts:           Date.now(),
        quoteTs:      Date.now(),   // REST quotes validated non-zero above
      };

      this.latest = tick;
      this.broadcast(tick);
    } catch (err) {
      console.debug('[kalshi-ws] price poll error:', (err as Error).message);
    } finally {
      this._polling = false;
      this._pollingStartedAt = 0;
      if (kickRefreshAfter) void this.refreshMarket();
    }
  }

  // ── Connect ─────────────────────────────────────────────────────────────────

  private scheduleConnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(
      () => this.connect(),
      this.backoff > MIN_BACKOFF ? this.backoff : 0,
    );
  }

  private async connect() {
    this.reconnectTimer = null;
    const now = Date.now();
    if (this._connectInFlightSince != null && now - this._connectInFlightSince < WS_CONNECT_ATTEMPT_TIMEOUT_MS) {
      return; // coalesce: one attempt at a time
    }
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return; // already connected / handshaking
    }
    this._connectInFlightSince = now;
    const attempt = ++this.connectAttemptSeq;
    try { await this._connectInner(attempt); }
    catch (err) {
      console.error("[kalshi-ws] Unhandled connect error:", (err as Error).message);
      this._connectInFlightSince = null;
      this.scheduleReconnect();
    }
  }

  private async _connectInner(attempt: number = this.connectAttemptSeq) {
    // DB-aware resolution (same priority order + PKCS#1 handling as
    // kalshiAuthHeadersAsync's other callers) — env `oracle`/`oraclekey` first,
    // then the Settings/paste-key DB row. Previously this read process.env
    // directly with no DB fallback, so a key rotated to DB-only (env secrets
    // deleted) left the WS feed permanently retrying with "No credentials"
    // even though REST auth (kalshi-auth.ts, routes/kalshi.ts) worked fine.
    let headers: Record<string, string>;
    try {
      headers = await withTimeout(buildKalshiWsAuthHeaders(), 8_000, "WS auth headers");
    } catch (err) {
      console.error("[kalshi-ws] Auth header generation failed:", (err as Error).message);
      this._connectInFlightSince = null;
      this.scheduleReconnect();
      return;
    }
    if (!headers["KALSHI-ACCESS-KEY"]) {
      console.warn(`[kalshi-ws] No usable credentials (missing, or PKCS#1 key) — REST book only, retrying WS in ${NO_CREDS_RETRY_MS / 1000}s`);
      this.restartPricePoller(PRICE_POLL_DEGRADED_MS);
      this._connectInFlightSince = null;
      if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
      this.reconnectTimer = setTimeout(() => this.connect(), NO_CREDS_RETRY_MS);
      return;
    }

    // A slow/hung REST lookup must not stall the reconnect loop; fall back to
    // the last known active market when it times out.
    const market = await withTimeout(this.fetchActiveMarket(), 8_000, "WS market lookup").catch((err) => {
      console.warn("[kalshi-ws]", (err as Error).message, "— using last known market");
      return null;
    });
    if (attempt !== this.connectAttemptSeq) return; // superseded while awaiting
    if (market) {
      this.active = market;
      this.scheduleRolloverCheck();
    }

    if (!this.active.ticker) {
      // Never resolved an active market ticker (REST lookup failed/timed out or
      // no market is "active" yet). Opening the WS now would connect but send
      // no subscription (sendSubscribe no-ops on an empty ticker), leaving the
      // feed silently idle until the watchdog's 20s staleness check eventually
      // forces a reconnect. Retry the REST lookup quickly instead.
      console.warn(`[kalshi-ws] No active market ticker yet — retrying lookup in ${NO_TICKER_RETRY_MS / 1000}s`);
      this.restartPricePoller(PRICE_POLL_DEGRADED_MS);
      this._connectInFlightSince = null;
      if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
      this.reconnectTimer = setTimeout(() => this.connect(), NO_TICKER_RETRY_MS);
      return;
    }

    this.authErrLogged = false; // key resolved — reset so next failure logs again

    try {
      const ws  = new WebSocket(WS_URL, { headers, handshakeTimeout: WS_HANDSHAKE_TIMEOUT_MS });
      const gen = ++this.wsGeneration;
      this.ws   = ws;
      // The attempt stays "in flight" through the handshake; the socket's own
      // open/error/close events clear it (handshakeTimeout guarantees one fires).

      ws.on("open", () => {
        if (gen !== this.wsGeneration) return; // superseded by a newer connect()
        console.info(`[kalshi-ws] Connected. Market: ${this.active.ticker}`);
        this._connectInFlightSince = null;
        this._lastOpenAt = Date.now();
        // Grace for the silence heartbeat: the subscribe ack is the first message.
        this._lastWsMessageTs = Date.now();
        this.backoff = MIN_BACKOFF;
        this.consecutiveFailures = 0;
        // Always close any open incident in the store, even after a restart where
        // _degraded was reset to false but an unresolved DB incident was restored.
        incidentStore.exitDegraded("websocket").catch(() => {});
        if (this._degraded) {
          this._degraded = false;
          this._degradedSince = null;
          console.info('[kalshi-ws] Recovered from degraded state — resuming normal operation');
          this.degradedListeners.forEach(fn => fn(false));
        }
        // WS is the live path — REST is a slow correctness backstop again.
        this.restartPricePoller(PRICE_POLL_HEALTHY_MS);
        this.startPing(ws);
        this.sendSubscribe(ws);
        // Immediately kick a REST poll so prices appear before first WS tick
        this.pollRestPrices();
      });

      ws.on("message", (raw) => {
        if (gen !== this.wsGeneration) return; // superseded by a newer connect()
        this.handleMessage(raw.toString());
      });

      ws.on("close", (code, reason) => {
        console.warn(`[kalshi-ws] Closed (${code}): ${reason.toString().slice(0, 80)}`);
        // Only reconnect if this is still the active socket AND still the
        // current generation (error handler may already have nulled ws,
        // bumped the generation via a fresh connect(), and scheduled its own
        // reconnect — a late close from the OLD socket must not schedule a
        // second, redundant reconnect on top of the new connection).
        if (this.ws === ws && gen === this.wsGeneration) {
          this._connectInFlightSince = null;
          this.stopPing();
          this.ws = null;
          this.scheduleReconnect();
        }
      });

      ws.on("error", (err) => {
        if (gen !== this.wsGeneration) return; // superseded by a newer connect()
        console.error("[kalshi-ws] Error:", err.message);
        this._connectInFlightSince = null;
        // Null the ref and schedule reconnect immediately.  terminate() will
        // still fire the "close" event, but the guard above prevents a
        // duplicate scheduleReconnect() call.
        this.stopPing();
        this.ws = null;
        try { ws.terminate(); } catch { /* ignore */ }
        this.scheduleReconnect();
      });
    } catch (err) {
      console.error("[kalshi-ws] Connect failed:", err);
      this._connectInFlightSince = null;
      this.scheduleReconnect();
    }
  }

  private viewMarketTickers(): string[] {
    const tickers: string[] = [];
    for (const market of this.viewSlots.values()) {
      if (market.ticker && !tickers.includes(market.ticker)) tickers.push(market.ticker);
    }
    return tickers;
  }


  private parseUsd(v: unknown): number | null {
    if (typeof v === "number" && Number.isFinite(v) && v > 0) return v;
    if (typeof v === "string") {
      const n = Number(v);
      if (Number.isFinite(n) && n > 0) return n;
    }
    return null;
  }

  /**
   * CF Benchmarks BRTI oracle ingest. Keeps book ticks (KalshiTick) untouched.
   * 5Hz supplies lean ticks; 1Hz supplies avg_60s_data for settlement TWAP.
   */
  private ingestBrtiOracle(
    channel: "cfbenchmarks_value_5hz" | "cfbenchmarks_value",
    m: {
      index_id?: string;
      value_usd?: string | number;
      source_ts_ms?: number;
      received_at?: number;
      data?: string;
      avg_60s_data?: { value?: string };
      last_60s_windowed_average_15min?: { value?: string };
    } | undefined,
  ) {
    if (!m || (m.index_id && m.index_id !== "BRTI")) return;
    let valueUsd = this.parseUsd(m.value_usd);
    let sourceTsMs = typeof m.source_ts_ms === "number" ? m.source_ts_ms : 0;
    if (valueUsd == null && typeof m.data === "string" && m.data.length > 0) {
      try {
        const raw = JSON.parse(m.data) as { value?: string; time?: number; id?: string };
        if (raw.id && raw.id !== "BRTI") return;
        valueUsd = this.parseUsd(raw.value);
        if (!sourceTsMs && typeof raw.time === "number") sourceTsMs = raw.time;
      } catch { /* ignore malformed raw frame */ }
    }
    if (valueUsd == null) return;
    const receivedAtMs = typeof m.received_at === "number" ? m.received_at : Date.now();
    const prev = this.brtiOracle;
    // Ignore duplicate / out-of-order upstream stamps (docs).
    if (prev && sourceTsMs > 0 && prev.sourceTsMs > 0 && sourceTsMs < prev.sourceTsMs) return;
    const avg60sUsd = this.parseUsd(m.avg_60s_data?.value) ?? (channel === "cfbenchmarks_value" ? null : (prev?.avg60sUsd ?? null));
    const last60 = this.parseUsd(m.last_60s_windowed_average_15min?.value)
      ?? (channel === "cfbenchmarks_value" ? null : (prev?.last60sWindowed15mUsd ?? null));
    // Prefer keeping the freshest 5Hz instant value; 1Hz may refresh averages only.
    const keep5hzValue = channel === "cfbenchmarks_value" && prev?.channel === "cfbenchmarks_value_5hz"
      && (Date.now() - (prev.receivedAtMs || 0) < 1_000);
    if (!prev) {
      console.info(`[kalshi-ws] First BRTI oracle tick via ${channel}: $${valueUsd.toFixed(2)}`);
    }
    this.brtiOracle = {
      indexId: "BRTI",
      valueUsd: keep5hzValue ? prev!.valueUsd : valueUsd,
      sourceTsMs: keep5hzValue ? prev!.sourceTsMs : (sourceTsMs || receivedAtMs),
      receivedAtMs,
      channel: keep5hzValue ? "cfbenchmarks_value_5hz" : channel,
      avg60sUsd: avg60sUsd ?? prev?.avg60sUsd ?? null,
      last60sWindowed15mUsd: last60 ?? prev?.last60sWindowed15mUsd ?? null,
    };
  }

  private sendSubscribe(ws: WebSocket) {
    const tickers = [this.active.ticker, ...this.viewMarketTickers()].filter(Boolean);
    const unique = [...new Set(tickers)];
    if (unique.length === 0) return;
    ws.send(JSON.stringify({
      id:     ++this.seq,
      cmd:    "subscribe",
      params: { channels: ["ticker"], market_tickers: unique },
    }));
    // Official free HF BRTI (~5 Hz) + 1 Hz sibling for avg_60s / settlement TWAP.
    // Separate oracle state — does NOT overwrite KalshiTick book fields.
    console.info("[kalshi-ws] Subscribing CFB BRTI 5Hz + 1Hz");
    ws.send(JSON.stringify({
      id:     ++this.seq,
      cmd:    "subscribe",
      params: { channels: ["cfbenchmarks_value_5hz"], index_ids: ["BRTI"] },
    }));
    ws.send(JSON.stringify({
      id:     ++this.seq,
      cmd:    "subscribe",
      params: { channels: ["cfbenchmarks_value"], index_ids: ["BRTI"] },
    }));
  }

  // ── Message handling ─────────────────────────────────────────────────────────

  private handleMessage(raw: string) {
    // GO EXECUTION INTEGRITY BATCH — A5 (2026-08-16): stamp on EVERY real
    // WS message, before the type/parse checks below — this is the only
    // writer of _lastWsMessageTs. See its declaration for why it must stay
    // separate from `this.latest.ts`.
    this._lastWsMessageTs = Date.now();
    try {
      const msg = JSON.parse(raw) as {
        type?: string;
        sid?: number;
        msg?: {
          market_ticker?: string;
          yes_bid?:       number;
          yes_ask?:       number;
          no_bid?:        number;
          no_ask?:        number;
          last_price?:    number;
          volume?:        number;
          open_interest?: number;
          bid?:           number;
          ask?:           number;
          index_id?:      string;
          value_usd?:     string | number;
          source_ts_ms?:  number;
          received_at?:   number;
          data?:          string;
          avg_60s_data?:  { value?: string; window_size?: number };
          last_60s_windowed_average_15min?: { value?: string; window_size?: number };
        };
      };

      if (msg.type === "error") {
        const err = (msg as { msg?: { code?: number; msg?: string } }).msg;
        console.warn(`[kalshi-ws] WS error code=${err?.code ?? "?"} ${err?.msg ?? JSON.stringify(msg).slice(0, 160)}`);
        return;
      }

      if (msg.type === "subscribed") {
        const m = msg as { sid?: number; msg?: { channel?: string } };
        console.info(`[kalshi-ws] Subscribed sid=${m.sid ?? "?"} channel=${m.msg?.channel ?? "?"}`);
        return;
      }

      if (msg.type === "cfbenchmarks_value_5hz" || msg.type === "cfbenchmarks_value") {
        this.ingestBrtiOracle(msg.type, msg.msg);
        return;
      }

      if (msg.type !== "ticker" || !msg.msg) return;
      const m    = msg.msg;
      const prev = this.latest;

      // Kalshi's WS sends volume/OI heartbeats with all-zero bid/ask when the
      // live orderbook snapshot is empty. Preserve the last known good quote
      // so the UI never flashes back to "—" during illiquid periods.
      //
      // 2026-08-05 bug fix: this used to fall back PER FIELD (yesBid, yesAsk,
      // noBid, noAsk independently), so a message where e.g. only no_bid read
      // 0 (a real, legitimate one-sided book near settlement — everyone's
      // asking, nobody's bidding on a near-certain NO) would keep the stale
      // noBid from minutes ago while noAsk updated fresh. Comparing that
      // stale/fresh mix downstream (SPREAD_GATE's bid>ask "crossed book"
      // check) produced false "corrupted quote" skips that hammered exactly
      // the highest-conviction late-contract setups (LATE_ENTRY_ANCHOR etc.)
      // — ~110 of ~451 logged skips over 4 days were this false alarm, zero
      // of them a real spread-width violation. Fix: fall back a WHOLE side's
      // pair (bid+ask together) so we never mix two different moments in time.
      // Adopt a side when its ASK is executable (1–99¢). One-sided books with
      // bid=0 + valid ask are common and must not keep a prior 0/100 stall.
      const yesPairFresh = isWsSideAskFresh(m.yes_ask);
      const noPairFresh  = isWsSideAskFresh(m.no_ask);
      const yesBid  = yesPairFresh ? (m.yes_bid ?? 0) : (prev?.yesBid ?? m.yes_bid ?? 0);
      const yesAsk  = yesPairFresh ? m.yes_ask! : (prev?.yesAsk ?? m.yes_ask ?? 0);
      const noBid   = noPairFresh  ? (m.no_bid  ?? 0) : (prev?.noBid  ?? m.no_bid  ?? 0);
      const noAsk   = noPairFresh  ? m.no_ask!  : (prev?.noAsk  ?? m.no_ask  ?? 0);

      const lastHint = (m.last_price ?? 0) > 0 ? m.last_price! : (prev?.lastPrice ?? prev?.yesPrice ?? 0);
      const yesPrice = bookMidCents(yesBid, yesAsk, lastHint);
      const noPrice = bookMidCents(noBid, noAsk, lastHint > 0 ? 100 - lastHint : (prev?.noPrice ?? 0));
      const lastPrice = (m.last_price ?? 0) > 0 ? m.last_price! : (prev?.lastPrice ?? yesPrice);

      // Other contracts (1h / perps view books) must not stamp the 15m
      // execution ticker. Route them read-only; never write this.latest.
      if (m.market_ticker && this.active.ticker && m.market_ticker !== this.active.ticker) {
        this.ingestViewTicker(m);
        return;
      }

      const msgNow = Date.now(); // single clock read: quoteTs === ts for real quotes
      const tick: KalshiTick = {
        ticker:       m.market_ticker ?? this.active.ticker,
        floorStrike:  this.active.floorStrike,
        closeTime:    this.active.closeTime,
        yesPrice,
        yesBid,
        yesAsk,
        noPrice,
        noBid,
        noAsk,
        lastPrice,
        volume:       m.volume        ?? prev?.volume       ?? 0,
        openInterest: m.open_interest ?? prev?.openInterest ?? 0,
        source:       "ws",
        ts:           msgNow,
        // Only executable 1–99¢ asks advance quote freshness. A 0¢/100¢
        // "quote" must not refresh quoteTs (that blocked REST + latched stall).
        quoteTs:      (isWsSideAskFresh(m.yes_ask) || isWsSideAskFresh(m.no_ask))
                        ? msgNow
                        : (prev?.quoteTs ?? 0),
      };

      this.latest = tick;
      this.broadcast(tick);
    } catch (err) {
      console.debug('[kalshi-ws] handleMessage parse error:', (err as Error).message);
    }
  }

  /** Signature of the last broadcast executable quote — used to detect a real
   *  price move (vs a carried-forward zero-quote heartbeat) so the event-driven
   *  wake only fires on tradeable changes. */
  private _lastQuoteSig = "";

  private broadcast(tick: KalshiTick) {
    // Maintain rolling price history — keep last 10 minutes only
    if (tick.yesPrice > 0) {
      const cutoff = tick.ts - 10 * 60_000;
      this._priceHistory.push({ ts: tick.ts, yes: tick.yesPrice });
      if (this._priceHistory.length > 600) {               // trim lazily
        this._priceHistory = this._priceHistory.filter(p => p.ts >= cutoff);
      }
    }

    // Fire executable-quote listeners ONLY on a genuinely new tradeable quote:
    // quoteTs advanced (a real bid/ask arrived) or a bid/ask level moved. This
    // skips zero-quote heartbeats, which carry forward the prior quote and must
    // not wake the decision loop with no new information.
    const sig = `${tick.quoteTs}|${tick.yesBid}|${tick.yesAsk}|${tick.noBid}|${tick.noAsk}`;
    if (sig !== this._lastQuoteSig) {
      this._lastQuoteSig = sig;
      if (this.quoteListeners.size > 0) {
        this.quoteListeners.forEach(fn => fn(tick));
      }
    }

    this.listeners.forEach(fn => fn(tick));
  }

  // ── Period rollover ──────────────────────────────────────────────────────────

  private _refreshingMarket = false;  // in-flight guard — a slow rollover must not overlap the next interval

  private async refreshMarket() {
    if (this._refreshingMarket) return;
    this._refreshingMarket = true;
    try {
      await this._refreshMarketBody();
    } catch (err) {
      console.error("[kalshi-ws] refreshMarket:", (err as Error).message);
    } finally {
      this._refreshingMarket = false;
    }
  }

  /** D10 — by-ticker read of the deterministic next 15m at/after close. */
  private async fetchNextMarketAtClose(): Promise<ActiveMarket | null> {
    const closeMs = Date.parse(this.active.closeTime);
    if (!Number.isFinite(closeMs) || Date.now() + ROLLOVER_CLOSE_BUFFER_MS < closeMs) return null;
    const next = nextKxbtc15mTicker(this.active.closeTime);
    if (!next) return null;
    try {
      const r = await fetch(`${REST_BASE}/markets/${encodeURIComponent(next)}`, {
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(4_000),
      });
      if (!r.ok) return null;
      const data = (await r.json()) as { market?: { ticker?: string; status?: string; floor_strike?: number | null; cap_strike?: number | null; close_time?: string } };
      return adoptableNextMarket(data.market, next, Date.now());
    } catch {
      return null;
    }
  }

  private async _refreshMarketBody() {
    let market = await this.fetchActiveMarket();
    // D10 — the open list lags the boundary by 15–46 s; switch at close_time
    // from a direct read of the next contract when it is already active.
    if ((!market || market.ticker === this.active.ticker) && this.active.ticker) {
      const proactive = await this.fetchNextMarketAtClose();
      if (proactive) {
        console.info(`[kalshi-ws] D10 proactive rollover at close: ${proactive.ticker} (open list still ${market?.ticker ?? "empty"})`);
        market = proactive;
      }
    }
    if (!market || market.ticker === this.active.ticker) {
      // Same period — update closeTime in case it changed
      if (market?.closeTime) {
        this.active.closeTime = market.closeTime;
      }
      // #384: after close, Kalshi may not have listed the next 15m yet.
      // Retry in ~1s instead of waiting for the 60s backstop.
      if (shouldRetryRolloverSoon(market, this.active.ticker, this.active.closeTime, Date.now())) {
        this.scheduleRolloverRetrySoon();
      } else if (market?.closeTime) {
        this.scheduleRolloverCheck();
      }
      await this.refreshViewBooks();
      return;
    }

    console.info(`[kalshi-ws] New period: ${market.ticker} (was ${this.active.ticker})`);
    this.active = market;
    this.scheduleRolloverCheck();
    this.latest = null;  // clear stale tick
    // #385: never serve the previous 15m book's depth as the new contract.
    this._latestOrderbook = null;
    // Contract-roll window: poll REST at degraded cadence until a valid ask lands.
    this.restartPricePoller(PRICE_POLL_DEGRADED_MS);

    if (this.ws?.readyState === WebSocket.OPEN) {
      this.sendSubscribe(this.ws);
    }

    // Aggressively REST-refresh through the roll — do not leave a sticky stall.
    await this.pollRestPrices();
    for (let i = 0; i < 4 && !hasExecutableKalshiAsk(this.latest); i++) {
      await new Promise(r => setTimeout(r, 120));
      await this.pollRestPrices();
    }

    // Task #385: the raw L2 order book (captureL2Snapshot) was previously
    // only refreshed by its own 5s interval timer, so on a period rollover
    // the new contract's book could sit stale for up to ~5s (labeled under
    // the OLD ticker's last-fetched depth) instead of reflecting the brand
    // new market immediately. captureL2Snapshot() already pins the ticker
    // before its async fetch and has its own in-flight guard, so calling it
    // here is safe even if the 5s timer fires concurrently.
    await this.captureL2Snapshot();
    await this.refreshViewBooks();
  }

  // ── Read-only 1h / perps view books (never 15m fills) ────────────────────────

  private async resolveViewBook(book: ViewBookId) {
    if (book === "15m") return;
    let market: ActiveMarket | null = null;
    if (book === "perps") {
      market = { ticker: KALSHI_PERPS_TICKER, floorStrike: 0, closeTime: "" };
    } else {
      market = await this.fetchActive1hMarket();
    }
    if (!market) return;
    const prev = this.viewSlots.get(book);
    this.viewSlots.set(book, market);
    if (prev?.ticker && prev.ticker !== market.ticker) {
      this.viewLatest.delete(prev.ticker);
    }
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.sendSubscribe(this.ws);
    }
    console.info(`[kalshi-ws] View book ${book} subscribed read-only: ${market.ticker}`);
  }

  private async fetchActive1hMarket(): Promise<ActiveMarket | null> {
    try {
      const url = `${REST_BASE}/markets?series_ticker=${KALSHI_SERIES_1H}&status=open&limit=1000`;
      const r = await fetch(url, {
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(8_000),
      });
      if (!r.ok) return null;
      const data = (await r.json()) as { markets?: HourlyMarketCandidate[] };
      return pickAtmHourlyMarket(data.markets ?? [], Date.now());
    } catch (err) {
      console.debug("[kalshi-ws] fetchActive1hMarket error:", (err as Error).message);
      return null;
    }
  }

  private async refreshViewBooks() {
    for (const book of this.viewRefCount.keys()) {
      if (book === "15m") continue;
      if ((this.viewRefCount.get(book) ?? 0) <= 0 && !this.viewSlots.has(book)) continue;
      await this.resolveViewBook(book);
    }
  }

  private ingestViewTicker(m: {
    market_ticker?: string;
    yes_bid?: number;
    yes_ask?: number;
    no_bid?: number;
    no_ask?: number;
    last_price?: number;
    volume?: number;
    open_interest?: number;
    bid?: number;
    ask?: number;
  }) {
    const ticker = m.market_ticker;
    if (!ticker) return;
    let slotBook: ViewBookId | null = null;
    let meta: ActiveMarket | undefined;
    for (const [book, market] of this.viewSlots) {
      if (market.ticker === ticker) {
        slotBook = book;
        meta = market;
        break;
      }
    }
    const prev = this.viewLatest.get(ticker) ?? null;
    const rawYesBid = m.yes_bid ?? m.bid ?? 0;
    const rawYesAsk = m.yes_ask ?? m.ask ?? 0;
    const rawNoBid = m.no_bid ?? 0;
    const rawNoAsk = m.no_ask ?? 0;
    const yesPairFresh = isWsSideAskFresh(rawYesAsk);
    const noPairFresh = isWsSideAskFresh(rawNoAsk);
    const yesBid = yesPairFresh ? rawYesBid : (prev?.yesBid ?? rawYesBid);
    const yesAsk = yesPairFresh ? rawYesAsk : (prev?.yesAsk ?? rawYesAsk);
    const noBid = noPairFresh ? rawNoBid : (prev?.noBid ?? rawNoBid);
    const noAsk = noPairFresh ? rawNoAsk : (prev?.noAsk ?? rawNoAsk);
    const lastHint = (m.last_price ?? 0) > 0 ? m.last_price! : (prev?.lastPrice ?? prev?.yesPrice ?? 0);
    const yesPrice = bookMidCents(yesBid, yesAsk, lastHint);
    const noPrice = bookMidCents(noBid, noAsk, lastHint > 0 ? 100 - lastHint : (prev?.noPrice ?? 0));
    const lastPrice = (m.last_price ?? 0) > 0 ? m.last_price! : (prev?.lastPrice ?? yesPrice);
    const viewNow = Date.now();
    const tick: KalshiTick = {
      ticker,
      floorStrike: meta?.floorStrike ?? prev?.floorStrike ?? 0,
      closeTime: meta?.closeTime ?? prev?.closeTime ?? "",
      yesPrice, yesBid, yesAsk, noPrice, noBid, noAsk, lastPrice,
      volume: m.volume ?? prev?.volume ?? 0,
      openInterest: m.open_interest ?? prev?.openInterest ?? 0,
      source: "ws",
      ts: viewNow,
      quoteTs: (isWsSideAskFresh(rawYesAsk) || isWsSideAskFresh(rawNoAsk))
        ? viewNow
        : (prev?.quoteTs ?? 0),
    };
    this.viewLatest.set(ticker, tick);
    if (slotBook) {
      const listeners = this.viewListeners.get(slotBook);
      if (listeners) listeners.forEach(fn => fn(tick));
    }
  }

  private _viewPolling = false;
  private async pollViewRestPrices() {
    if (this._viewPolling) return;
    const wanted: ViewBookId[] = [];
    for (const [book, n] of this.viewRefCount) {
      if (book !== "15m" && n > 0) wanted.push(book);
    }
    if (wanted.length === 0) return;
    this._viewPolling = true;
    try {
      for (const book of wanted) {
        if (!this.viewSlots.has(book)) await this.resolveViewBook(book);
        const market = this.viewSlots.get(book);
        if (!market?.ticker || book === "perps") continue;
        const prev = this.viewLatest.get(market.ticker) ?? null;
        const wsLive = shouldApplyRestQuote({
          lastWsMessageTs: this._lastWsMessageTs,
          latest: prev,
          restHasQuotes: true,
          nowMs: Date.now(),
        });
        if (wsLive === "skip_ws_live") continue;
        try {
          const url = `${REST_BASE}/markets/${encodeURIComponent(market.ticker)}`;
          const r = await fetch(url, {
            headers: { Accept: "application/json" },
            signal: AbortSignal.timeout(REST_POLL_TIMEOUT_MS),
          });
          if (!r.ok) continue;
          const data = (await r.json()) as {
            market?: {
              ticker?: string;
              close_time?: string;
              floor_strike?: number;
              cap_strike?: number;
              yes_bid_dollars?: string;
              yes_ask_dollars?: string;
              no_bid_dollars?: string;
              no_ask_dollars?: string;
              yes_bid?: number;
              yes_ask?: number;
              no_bid?: number;
              no_ask?: number;
              last_price_dollars?: string;
              last_price?: number;
            };
          };
          const m = data.market;
          if (!m || (m.ticker && m.ticker !== market.ticker)) continue;
          const toCents = (d?: string, cents?: number): number =>
            d != null ? Math.round(parseFloat(d) * 100)
            : (typeof cents === "number" && Number.isFinite(cents) ? Math.round(cents) : 0);
          const yesBid = toCents(m.yes_bid_dollars, m.yes_bid);
          const yesAsk = toCents(m.yes_ask_dollars, m.yes_ask);
          const noBid = toCents(m.no_bid_dollars, m.no_bid);
          const noAsk = toCents(m.no_ask_dollars, m.no_ask);
          if (yesBid + yesAsk + noBid + noAsk === 0) continue;
          const tick: KalshiTick = {
            ticker: market.ticker,
            floorStrike: (m.floor_strike ?? m.cap_strike ?? market.floorStrike) as number,
            closeTime: m.close_time ?? market.closeTime,
            yesPrice: bookMidCents(yesBid, yesAsk),
            yesBid, yesAsk,
            noPrice: bookMidCents(noBid, noAsk),
            noBid, noAsk,
            lastPrice: toCents(m.last_price_dollars, m.last_price) || bookMidCents(yesBid, yesAsk),
            volume: prev?.volume ?? 0,
            openInterest: prev?.openInterest ?? 0,
            source: "rest",
            ts: Date.now(),
            quoteTs: Date.now(),
          };
          this.viewLatest.set(market.ticker, tick);
          const listeners = this.viewListeners.get(book);
          if (listeners) listeners.forEach(fn => fn(tick));
        } catch (err) {
          console.debug("[kalshi-ws] view REST poll error:", (err as Error).message);
        }
      }
    } finally {
      this._viewPolling = false;
    }
  }

  // ── L2 orderbook snapshot capture ────────────────────────────────────────────

  private async captureL2Snapshot() {
    if (this._l2Capturing || !this.active.ticker) return;
    this._l2Capturing = true;
    // Pin the ticker before the async fetch — if the period rolls over while
    // the request is in flight, the old contract's depth must not be labeled
    // (or persisted) under the new ticker.
    const ticker = this.active.ticker;
    try {
      const url = `${REST_BASE}/markets/${ticker}/orderbook?depth=5`;
      const r   = await fetch(url, {
        headers: { Accept: "application/json" },
        signal:  AbortSignal.timeout(6_000),
      });
      if (!r.ok) return;

      const data = (await r.json()) as {
        orderbook?: {
          yes?: unknown;
          no?:  unknown;
        };
        // Newer API shape: dollar-string levels
        orderbook_fp?: {
          yes_dollars?: unknown;
          no_dollars?:  unknown;
        };
      };

      // Normalize both shapes to cent-integer [price, qty] levels
      const normalizeSide = (legacyLevels: unknown, fixedPointLevels: unknown): [number, number][] => {
        const normalizedLegacy = normalizeOrderbookLevels(legacyLevels);
        // Prefer the legacy shape when it contains valid levels, but fall
        // back when it only contained empty-string placeholders.
        return normalizedLegacy.length > 0
          ? normalizedLegacy
          : normalizeOrderbookLevels(fixedPointLevels, true);
      };
      const yesLevels = normalizeSide(data.orderbook?.yes, data.orderbook_fp?.yes_dollars);
      const noLevels  = normalizeSide(data.orderbook?.no,  data.orderbook_fp?.no_dollars);
      if (yesLevels.length === 0 && noLevels.length === 0) return;

      const yesBids: [number, number][] = yesLevels.slice().sort((a, b) => b[0] - a[0]).slice(0, 5);
      const yesAsks: [number, number][] = noLevels.map(([p, q]) => [100 - p, q] as [number, number]).sort((a, b) => a[0] - b[0]).slice(0, 5);

      const bestYesBid = yesBids[0]?.[0] ?? null;
      const bestYesAsk = yesAsks[0]?.[0] ?? null;
      // Enforce bid < ask: a crossed book (bid ≥ ask) indicates stale/malformed
      // data and must never produce a negative spread or misleading mid-price.
      const spreadValid = bestYesBid != null && bestYesAsk != null && bestYesBid < bestYesAsk;
      const spread     = spreadValid ? bestYesAsk! - bestYesBid! : null;
      const midPrice   = spreadValid ? Math.round((bestYesBid! + bestYesAsk!) / 2) : null;
      const bidDepth5  = yesBids.reduce((s, [, q]) => s + q, 0);
      const askDepth5  = yesAsks.reduce((s, [, q]) => s + q, 0);

      // Discard if the period rolled over while the request was in flight
      if (this.active.ticker !== ticker) return;

      this._latestOrderbook = { ticker, yesBids, yesAsks, ts: Date.now() };
      this._orderbookSuspicion.add({ ticker, yesBids, yesAsks, ts: this._latestOrderbook.ts });

      // Persist via a bounded batch buffer. Rows accumulate here and are
      // flushed as a single multi-row insert that IS awaited — the await
      // creates backpressure inside the _l2Capturing mutex, so a slow DB
      // delays the next capture instead of queuing unbounded write promises.
      this._l2Persistence.enqueue({
        ticker,
        yesBids:    JSON.stringify(yesBids),
        yesAsks:    JSON.stringify(yesAsks),
        bestYesBid, bestYesAsk, spread, midPrice, bidDepth5, askDepth5,
      });
      // Hard bound: if the DB has been failing, drop the oldest rows rather
      // than growing memory without limit. 50 rows ≈ 4 minutes of snapshots.
      await this._l2Persistence.flushIfReady();

    } catch {
      // Network error or timeout — silently skip this snapshot
    } finally {
      this._l2Capturing = false;
    }
  }

  // ── Market trade history ──────────────────────────────────────────────────────

  private _fetchingTrades = false;  // in-flight guard — a >120s response must not overlap the next fetch

  private async fetchMarketTrades() {
    if (!this.active.ticker) return;
    if (this._fetchingTrades) return;
    this._fetchingTrades = true;
    try {
      await this._fetchMarketTradesBody();
    } finally {
      this._fetchingTrades = false;
    }
  }

  private async _fetchMarketTradesBody() {
    try {
      const url = `${REST_BASE}/markets/${this.active.ticker}/trades?limit=50`;
      const r   = await fetch(url, {
        headers: { Accept: "application/json" },
        signal:  AbortSignal.timeout(8_000),
      });
      if (!r.ok) return;

      const data = (await r.json()) as {
        trades?: Array<{
          trade_id?:    string;
          count?:       number;
          yes_price?:   number;
          no_price?:    number;
          taker_side?:  string;
          created_time?: string;
        }>;
      };

      const trades = (data.trades ?? []).filter(t => t.trade_id);
      if (trades.length === 0) return;

      // Cache in memory for the live endpoint.
      // Kalshi trade prices are integer CENTS already (1–99) — do not scale.
      // Preserve the API's own no_price instead of assuming exact complements.
      this._recentMarketTrades = trades.map(t => ({
        tradeId:       t.trade_id!,
        count:         t.count ?? 1,
        yesPriceCents: Math.round(t.yes_price ?? 0),
        noPriceCents:  Math.round(t.no_price ?? (100 - (t.yes_price ?? 0))),
        takerSide:     t.taker_side ?? "unknown",
        createdAt:     t.created_time ?? new Date().toISOString(),
      }));

      // Single batched multi-row insert (ignore conflicts on trade_id PK).
      // Previously up to 50 independent fire-and-forget inserts every 2 min —
      // a slow DB queued unbounded concurrent work.
      const rows = this._recentMarketTrades.map(t => ({
        tradeId:       t.tradeId,
        ticker:        this.active.ticker,
        count:         t.count,
        yesPriceCents: t.yesPriceCents,
        noPriceCents:  t.noPriceCents,
        takerSide:     t.takerSide,
        createdAt:     new Date(t.createdAt),
      }));
      if (rows.length > 0) {
        // Await inside the fetch guard so a slow/unreachable DB provides
        // backpressure: the next 120s cycle is skipped instead of queueing
        // one more pending insert per interval.
        try {
          await db.insert(kalshiMarketTrades).values(rows).onConflictDoNothing();
        } catch { /* DB down — drop this batch; next successful cycle re-upserts */ }
      }
    } catch {
      // Silently skip on network errors
    }
  }

  // ── Back-off reconnect ───────────────────────────────────────────────────────

  private startPing(ws: WebSocket) {
    this.stopPing();
    this._pingTimer = setInterval(() => {
      if (this.ws !== ws || ws.readyState !== WebSocket.OPEN) return;
      try {
        // Kalshi Trade API WS rejects application cmd "ping" (error code 5 Unknown command).
        // Keep protocol-level ping only.
        if (typeof ws.ping === "function") ws.ping();
      } catch { /* ignore */ }
    }, WS_PING_INTERVAL_MS);
  }

  private stopPing() {
    if (this._pingTimer) {
      clearInterval(this._pingTimer);
      this._pingTimer = null;
    }
  }

  private scheduleReconnect() {
    this.consecutiveFailures++;
    this.stopPing();
    // First drop: REST becomes the 15m book immediately (do not wait for
    // WS_DEGRADED_THRESHOLD). Degraded-incident pause still waits for 5 fails.
    this.restartPricePoller(PRICE_POLL_DEGRADED_MS);
    if (this.consecutiveFailures >= WS_DEGRADED_THRESHOLD && !this._degraded) {
      this._degraded = true;
      this._degradedSince = Date.now();
      console.warn(`[kalshi-ws] ${this.consecutiveFailures} consecutive failures — entering DEGRADED state. New entries paused.`);
      incidentStore.enterDegraded("websocket").catch(() => {});
      this.degradedListeners.forEach(fn => fn(true));
    }
    this.backoff = nextWsReconnectBackoffMs(this.backoff);
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => this.connect(), this.backoff);
  }
}

// ── Export singleton ──────────────────────────────────────────────────────────

export const kalshiWS = new KalshiWSManager();
