/**
 * Leftover live Kalshi settlements API. Paper KXBTC15M never runs it.
 * Host paper SETTLEMENT stays in _detectSettlementBody. Does not ENABLE.
 */
import { paperSettlementMayStampOfficialYesNo } from "./official-settlement-archive.js";

export const LEFTOVER_LIVE_SETTLEMENT_EVALUATE_LOADED = true as const;

export const LEFTOVER_LIVE_SETTLEMENT_HOST_GUARD =
  "if (!leftoverLiveSettlementMayRun(this.config)) return;";

export const FROZEN_LIVE_SETTLEMENT_MARKERS = [
  "kalshiSettlementsPath(5)",
  'SETTLED_KALSHI", true, true, explicitYesNo',
  "extractExplicitKalshiYesNo(match)",
  "Settlement API fetch failed",
] as const;

export function leftoverLiveSettlementMayRun(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  void paperSettlementMayStampOfficialYesNo();
  if (cfg.paperMode === true || cfg.frozenCcMode === true) return false;
  return true;
}

export function leftoverLiveSettlementHostDenied(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverLiveSettlementMayRun(cfg) === false;
}

export function leftoverLiveSettlementRun(
  cfg: { paperMode?: boolean; frozenCcMode?: boolean },
  run: () => Promise<void>,
): Promise<void> {
  if (!leftoverLiveSettlementMayRun(cfg)) return Promise.resolve();
  return run();
}
