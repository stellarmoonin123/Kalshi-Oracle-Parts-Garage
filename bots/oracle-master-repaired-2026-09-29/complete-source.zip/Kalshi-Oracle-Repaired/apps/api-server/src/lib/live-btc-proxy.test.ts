/**
 * live-btc-proxy.test.ts — Live BTC Proxy hierarchy.
 *
 *   1. Fresh Kalshi-aligned observation preferred over exchanges.
 *   2. Stale exchange quotes excluded from the composite.
 *   3. Composite fallback when Kalshi is stale.
 *   4. avg60s is derived and is NEVER labeled official CF BRTI.
 *
 * Does not enable BRTI_PROBABILITY. Does not import trading-bot.ts.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { BTC_FLOOR_FALLBACK } from "./constants.js";
import {
  AVG60S_NOTE,
  createLiveBtcProxy,
  toBtcTickerJson,
  type LiveBtcProxyConstituents,
} from "./live-btc-proxy.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));

const T0 = 1_724_000_000_000;

function cons(partial: Partial<LiveBtcProxyConstituents> & { now?: number }): LiveBtcProxyConstituents {
  const now = partial.now ?? T0;
  return {
    kraken: partial.kraken === undefined ? { price: 80_100, ts: now } : partial.kraken,
    bitstamp: partial.bitstamp === undefined ? { price: 80_200, ts: now } : partial.bitstamp,
    coinbase: partial.coinbase === undefined ? { price: 80_300, ts: now } : partial.coinbase,
    binance: partial.binance === undefined ? null : partial.binance,
  };
}

test("fresh Kalshi-aligned observation is preferred over exchanges", async () => {
  const engine = createLiveBtcProxy({
    now: () => T0,
    getKalshiAligned: () => ({ price: 80_050.55, ts: T0 - 1_000 }),
    fetchConstituents: async () => cons({ now: T0 }),
  });
  const snap = await engine.snapshot();
  assert.equal(snap.source, "kalshi-aligned");
  assert.equal(snap.price, 80050.55);
  assert.equal(snap.stale, false);
  assert.equal(snap.constituents.coinbase?.price, 80_300);
  assert.notEqual(snap.price, (80_100 + 80_200 + 80_300) / 3);
});

test("stale exchange quotes are excluded from the composite", async () => {
  const engine = createLiveBtcProxy({
    now: () => T0,
    getKalshiAligned: () => null,
    fetchConstituents: async () => cons({
      now: T0,
      kraken: { price: 10, ts: T0 - 60_000 }, // stale — must be excluded
      bitstamp: { price: 80_000, ts: T0 },
      coinbase: { price: 80_200, ts: T0 },
    }),
  });
  const snap = await engine.snapshot();
  assert.equal(snap.source, "exchange-composite");
  assert.equal(snap.stale, false);
  assert.equal(snap.price, 80_100); // (80000+80200)/2, kraken 10 excluded
  assert.notEqual(snap.price, (10 + 80_000 + 80_200) / 3);
});

test("composite fallback when Kalshi observation is stale", async () => {
  const engine = createLiveBtcProxy({
    now: () => T0,
    getKalshiAligned: () => ({ price: 79_000, ts: T0 - 45_000 }), // stale vs 30s
    fetchConstituents: async () => cons({ now: T0 }),
  });
  const snap = await engine.snapshot();
  assert.equal(snap.source, "exchange-composite");
  assert.equal(snap.price, 80_200); // (80100+80200+80300)/3
  assert.equal(snap.stale, false);
});

test("last good kalshi-inferred is the explicit fallback when exchanges are also stale", async () => {
  const engine = createLiveBtcProxy({
    now: () => T0 + 40_000,
    lastGood: { price: 79_500.25, ts: T0 },
    getKalshiAligned: () => null,
    fetchConstituents: async (now) => cons({
      now,
      kraken: { price: 80_000, ts: now - 60_000 },
      bitstamp: { price: 80_000, ts: now - 60_000 },
      coinbase: { price: 80_000, ts: now - 60_000 },
    }),
  });
  const snap = await engine.snapshot();
  assert.equal(snap.source, "fallback");
  assert.equal(snap.stale, true);
  assert.equal(snap.price, 79500.25);
  assert.notEqual(snap.price, BTC_FLOOR_FALLBACK);
});

test("avg60s is derived from this proxy and is never labeled official CF BRTI", async () => {
  let t = T0;
  const engine = createLiveBtcProxy({
    now: () => t,
    getKalshiAligned: () => ({ price: 80_000, ts: t }),
    fetchConstituents: async () => cons({ now: t }),
  });
  const a = await engine.snapshot();
  t = T0 + 1_000;
  const b = await engine.snapshot();
  assert.equal(a.avg60sNote, AVG60S_NOTE);
  assert.equal(b.avg60sNote, AVG60S_NOTE);
  assert.match(AVG60S_NOTE, /not official CF BRTI/);
  assert.equal(AVG60S_NOTE.toLowerCase().includes("official cf brti") && !AVG60S_NOTE.includes("not official"), false);
  assert.equal(["CF BRTI", "official CF BRTI"].includes(a.source), false);
  assert.equal("officialCfBrti" in a, false);
  assert.equal("cfBrti" in a, false);
  assert.ok(typeof a.avg60s === "number" && a.avg60s > 0);
  assert.equal(a.avg60s, 80_000);
  assert.equal(b.avg60s, 80_000);

  const ticker = toBtcTickerJson(a, { floorStrike: 79_900, result: "yes", ticker: "KXBTC15M-X" });
  assert.equal(ticker.avg60sNote, AVG60S_NOTE);
  assert.equal(ticker.lastFloorStrike, 79_900);
  assert.equal(ticker.lastSettleResult, "yes");
  assert.equal(ticker.lastSettleTicker, "KXBTC15M-X");
  assert.equal(ticker.source, "kalshi-aligned");
  assert.ok(ticker.constituents.kraken || ticker.constituents.bitstamp || ticker.constituents.coinbase);
});

test("GET /btc/ticker JSON shape keys (proxy + legacy settlement fields)", async () => {
  const engine = createLiveBtcProxy({
    now: () => T0,
    getKalshiAligned: () => ({ price: 80_123.45, ts: T0 }),
    fetchConstituents: async () => cons({
      now: T0,
      binance: { price: 80_400, ts: T0 },
    }),
  });
  const proxy = await engine.snapshot();
  const json = toBtcTickerJson(proxy, {
    floorStrike: 80_000.12,
    result: "no",
    ticker: "KXBTC15M-26AUG271500-00",
  });
  const keys = Object.keys(json).sort();
  assert.deepEqual(keys, [
    "avg60s",
    "avg60sNote",
    "constituents",
    "lastFloorStrike",
    "lastSettleResult",
    "lastSettleTicker",
    "price",
    "quoteTs",
    "source",
    "stale",
    "ts",
  ].sort());
  assert.equal(json.quoteTs, json.ts);
  assert.equal(json.price, 80123.45);
  assert.equal(json.source, "kalshi-aligned");
  assert.equal(json.ts, T0);
  assert.equal(json.stale, false);
  assert.equal(typeof json.avg60s, "number");
  assert.equal(json.avg60sNote, AVG60S_NOTE);
  assert.equal(json.constituents.binance?.price, 80_400);
  assert.equal(json.lastFloorStrike, 80_000.12);
  assert.equal(json.lastSettleResult, "no");
  assert.equal(json.lastSettleTicker, "KXBTC15M-26AUG271500-00");
});

test("source does not import trading-bot, does not enable BRTI_PROBABILITY, names the CF negation", () => {
  const src = fs.readFileSync(path.join(HERE, "live-btc-proxy.ts"), "utf8");
  assert.equal(/from ["'].*trading-bot/.test(src), false);
  assert.equal(/placeOrder/.test(src), false);
  assert.equal(/ENABLE_STRATEGY/.test(src), true, "must name the lock");
  assert.equal(/CHANGE_EV_FLOOR/.test(src), true);
  assert.match(src, /Do not enable\s+BRTI_PROBABILITY|Do not enable\n \* BRTI_PROBABILITY/);
  assert.match(src, /not official CF BRTI/);
  assert.equal(/BRTI_PROBABILITY\s*=\s*true/.test(src), false);
  assert.equal(src.includes("evaluate("), false);
});

test("btc.ts ticker uses getLiveBtcProxy / toBtcTickerJson; evaluate untouched", () => {
  const routes = path.join(HERE, "..", "routes");
  const btc = fs.readFileSync(path.join(routes, "btc.ts"), "utf8");
  assert.match(btc, /getLiveBtcProxy/);
  assert.match(btc, /toBtcTickerJson/);
  assert.match(btc, /not official CF BRTI|NEVER official CF BRTI/);
  assert.equal(/BRTI_PROBABILITY\s*=\s*true/.test(btc), false);
  const bot = fs.readFileSync(path.join(HERE, "trading-bot.ts"), "utf8");
  assert.equal(bot.includes("live-btc-proxy"), false);
  assert.equal(bot.includes("getLiveBtcProxy"), false);
});


test("production Kalshi-aligned path ages on quoteTs (heartbeat ts is not enough)", () => {
  const src = fs.readFileSync(path.join(HERE, "live-btc-proxy.ts"), "utf8");
  assert.match(src, /kalshiTickQuoteAgeMs/);
  assert.match(src, /quoteTs/);
  assert.equal(/now - tick\.ts >= staleMs/.test(src), false);
});
