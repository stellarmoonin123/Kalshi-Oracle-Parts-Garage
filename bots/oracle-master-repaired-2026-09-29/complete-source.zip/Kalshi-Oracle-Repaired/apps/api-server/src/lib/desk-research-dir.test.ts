import { test } from "node:test";
import assert from "node:assert/strict";
import os from "node:os";
import path from "node:path";
import { researchDir, researchPath } from "./desk-data-dir.js";
import { DEFAULT_TICKS_DIR } from "./tick-replay-backtest.js";
import { DEFAULT_LAB_PATH } from "./tick-replay-lab.js";

test("research dir: env override, never the live desk folder under test", () => {
  const prev = process.env.KALSHI_RESEARCH_DIR;
  try {
    delete process.env.KALSHI_RESEARCH_DIR;
    assert.equal(researchDir(), path.join(os.tmpdir(), "kalshi-research-test"));
    process.env.KALSHI_RESEARCH_DIR = "/tmp/rx";
    assert.equal(researchPath("ticks"), "/tmp/rx/ticks");
  } finally {
    if (prev === undefined) delete process.env.KALSHI_RESEARCH_DIR; else process.env.KALSHI_RESEARCH_DIR = prev;
  }
  assert.ok(!DEFAULT_TICKS_DIR.startsWith("/workspace/kalshi-oracle"), DEFAULT_TICKS_DIR);
  assert.ok(!DEFAULT_LAB_PATH.startsWith("/workspace/kalshi-oracle"), DEFAULT_LAB_PATH);
});
