/**
 * SelfDrive — self-driving-car cognition for Oracle Mind.
 *
 * Road = 15m price/chart candle. Destination = fee-net + survive.
 * Braking (SKIP / PULL_OVER_SKIP) is success when the road is ambiguous.
 * Blind intersection (MISSING_INPUTS / no book / no index) → stop.
 * Rear-end risk = wrong-side into settle → prefer settle-side score.
 *
 * Pure functions from existing stamp/mind fields. No network. No LLM.
 * Never replaces decideFrozenCcEntry / PATH_RIDE / tick. Never cuts floors.
 *
 * Metaphor layers: ODD → Sensors → Perception → Localization → Prediction →
 * Planning → Control → Safety → Driver monitor.
 *
 * See docs/SELFDRIVE_DESK.md
 */

export const SELFDRIVE_LOADED = "SELFDRIVE_LOADED" as const;

/** Mirror floors — must stay equal to MIND_FLOOR_LOCKS (tested). */
export const SELFDRIVE_FLOOR_MIRROR = {
  evFloorCents: 3,
  kellyCap: 0.6,
  maxRiskPctPerTrade: 0.09,
  askMinCents: 20,
  askMaxCents: 55,
} as const;

/** Soft Kelly for size *proposal* only — live Kelly≤0.60 untouched. */
export const SELFDRIVE_PROPOSAL_KELLY_MULT = 0.2 as const;

export type SelfDrivePlanAction =
  | "CRUISE_TAKE_YES"
  | "CRUISE_TAKE_NO"
  | "HOLD_LANE"
  | "EXIT_RAMP"
  | "PULL_OVER_SKIP";

export type SelfDriveLane = "YES" | "NO" | "NONE";

export type SelfDriveOdd = {
  inOdd: boolean;
  series: "KXBTC15M";
  paperMode: boolean;
  frozenCc: boolean;
  reasons: string[];
};

export type SelfDriveSensors = {
  bookPresent: boolean;
  askCents: number | null;
  indexOrProxyPresent: boolean;
  clockOk: boolean;
  secsRemaining: number | null;
  velKnown: boolean;
  velocityDolPerMin: number | null;
  mtfKnown: boolean;
  mtfScore: number | null;
  feeScheduleKnown: boolean;
  stale: boolean;
  missing: string[];
};

export type SelfDriveObstacle =
  | "vel_against"
  | "thin_book"
  | "drawdown"
  | "stale"
  | "missing_book"
  | "missing_index"
  | "covers_both"
  | "floors_fail";

export type SelfDrivePerception = {
  lane: SelfDriveLane;
  obstacles: SelfDriveObstacle[];
  weather: "clear" | "haze" | "storm";
  weatherNote: string;
};

export type SelfDriveLocalization = {
  phase: "early" | "mid" | "late" | "unknown";
  position: "YES" | "NO" | "flat";
  distanceToSettleSec: number | null;
  note: string;
};

export type SelfDrivePrediction = {
  pInd: number | null;
  band80: [number | null, number | null];
  settlePick: "yes" | "no" | "skip" | null;
  ovPreferSkip: boolean;
  ovScore: number;
  foresightNext: string | null;
  note: string;
};

export type SelfDrivePlanning = {
  planAction: SelfDrivePlanAction;
  laneChangeAllowed: boolean;
  reasons: string[];
};

export type SelfDriveControl = {
  /** Proposal fraction — capped by kellyCap; soft mult for display only. */
  sizeProposalKelly: number;
  kellyCapLive: typeof SELFDRIVE_FLOOR_MIRROR.kellyCap;
  proposalMult: typeof SELFDRIVE_PROPOSAL_KELLY_MULT;
  floorsHeld: boolean;
  note: string;
};

export type SelfDriveSafety = {
  brake: boolean;
  brakeReasons: string[];
  emergencyStop: boolean;
};

export type SelfDriveDriverMonitor = {
  calibReliable: boolean | null;
  calibN: number | null;
  ece: number | null;
  scarEchoNote: string | null;
  councilCoherence: number | null;
  alert: string | null;
};

export type SelfDriveStack = {
  odd: SelfDriveOdd;
  sensors: SelfDriveSensors;
  perception: SelfDrivePerception;
  localization: SelfDriveLocalization;
  prediction: SelfDrivePrediction;
  planning: SelfDrivePlanning;
  control: SelfDriveControl;
  safety: SelfDriveSafety;
  driverMonitor: SelfDriveDriverMonitor;
  /** 6–10 short labeled lines — deterministic road narration. */
  thoughtTrace: string[];
  planAction: SelfDrivePlanAction;
  brakeReasons: string[];
  voice: "selfDrive-road";
  schema: "self_drive_v1";
};

export type BuildSelfDriveInput = {
  paperMode: boolean;
  frozenCcMode: boolean;
  decisionKind: string;
  soleDecision: string;
  side: "yes" | "no" | null;
  askCents: number | null;
  secsRemaining: number | null;
  stale: boolean;
  sizeZero: boolean;
  evCents: number | null;
  /** Index / lag proxy present (lagProven or lagDollars known). */
  indexOrProxyPresent?: boolean | null;
  /** Fresh L2 book for the live ticker (even when no side/ask was admitted this tick). */
  bookPresent?: boolean | null;
  lagProven?: boolean | null;
  lagStale?: boolean | null;
  velocityDolPerMin?: number | null;
  mtfScore?: number | null;
  ccVelocityWouldBlock?: string | null;
  thinBook?: boolean | null;
  drawdownPct?: number | null;
  /** Position held (open book). */
  positionHeld?: "yes" | "no" | "flat" | null;
  exitHold?: boolean | null;
  ruinWouldSell?: boolean | null;
  /** From phd / oracleV2 when available. */
  pInd?: number | null;
  pYes?: number | null;
  band80?: [number | null, number | null] | null;
  settlePick?: "yes" | "no" | "skip" | null;
  settleInputsPresent?: boolean | null;
  ovPreferSkip?: boolean | null;
  ovScore?: number | null;
  foresightNext?: string | null;
  calibReliable?: boolean | null;
  calibN?: number | null;
  ece?: number | null;
  coversBoth?: boolean | null;
  oracleGatesFailed?: readonly string[] | null;
  oracleMissingInputs?: readonly string[] | null;
  oracleRiskVeto?: boolean | null;
  oracleRiskVetoReasons?: readonly string[] | null;
  councilCoherence?: number | null;
  scarEchoNote?: string | null;
  feeScheduleKnown?: boolean | null;
  /** Horizon phase from brain (early/mid/late). */
  horizonPhase?: "early" | "mid" | "late" | "unknown" | null;
};

function clamp01(x: number): number {
  if (!Number.isFinite(x)) return 0;
  return Math.min(1, Math.max(0, x));
}

function phaseFromSecs(
  secs: number | null,
  horizonPhase: BuildSelfDriveInput["horizonPhase"],
): SelfDriveLocalization["phase"] {
  if (horizonPhase === "early" || horizonPhase === "mid" || horizonPhase === "late") {
    return horizonPhase;
  }
  if (typeof secs !== "number" || !Number.isFinite(secs)) return "unknown";
  if (secs >= 600) return "early";
  if (secs >= 180) return "mid";
  return "late";
}

function buildOdd(input: BuildSelfDriveInput): SelfDriveOdd {
  const reasons: string[] = [];
  if (!input.paperMode) reasons.push("paperMode false — outside ODD");
  // Desk is always KXBTC15M in this fold; frozenCc expected when frozenCcMode.
  if (input.frozenCcMode !== true && input.soleDecision === "TAKE") {
    // Advisory note only — still in series ODD; frozen preferred.
    reasons.push("frozenCcMode false — prefer frozen six-gate");
  }
  const inOdd = input.paperMode === true;
  return {
    inOdd,
    series: "KXBTC15M",
    paperMode: input.paperMode === true,
    frozenCc: input.frozenCcMode === true,
    reasons,
  };
}

function buildSensors(input: BuildSelfDriveInput): SelfDriveSensors {
  const askOk =
    typeof input.askCents === "number" &&
    Number.isFinite(input.askCents) &&
    input.askCents > 0;
  const clockOk =
    typeof input.secsRemaining === "number" &&
    Number.isFinite(input.secsRemaining);
  const velKnown =
    typeof input.velocityDolPerMin === "number" &&
    Number.isFinite(input.velocityDolPerMin);
  const mtfKnown =
    typeof input.mtfScore === "number" && Number.isFinite(input.mtfScore);
  const indexOrProxyPresent =
    input.indexOrProxyPresent === true ||
    input.lagProven === true ||
    (input.lagProven === false && input.lagStale === false) ||
    (typeof input.lagStale === "boolean" && input.lagStale === false);
  const feeScheduleKnown = input.feeScheduleKnown !== false; // desk knows default schedule
  const missing: string[] = [];
  // Book sensor = admitted ask OR a fresh live L2 book (idle ticks have no ask).
  // Only for side-less ticks: a TAKE without an ask still brakes (no loosening).
  const bookOk = askOk || (input.bookPresent === true && input.side == null);
  if (!bookOk) missing.push("book/ask");
  if (!indexOrProxyPresent) missing.push("index/proxy");
  if (!clockOk) missing.push("clock/tte");
  if (!velKnown) missing.push("vel");
  if (!mtfKnown) missing.push("mtf");
  return {
    bookPresent: bookOk,
    askCents: askOk ? input.askCents : null,
    indexOrProxyPresent,
    clockOk,
    secsRemaining: clockOk ? input.secsRemaining : null,
    velKnown,
    velocityDolPerMin: velKnown ? input.velocityDolPerMin! : null,
    mtfKnown,
    mtfScore: mtfKnown ? input.mtfScore! : null,
    feeScheduleKnown,
    stale: input.stale === true,
    missing,
  };
}

function buildPerception(
  input: BuildSelfDriveInput,
  sensors: SelfDriveSensors,
): SelfDrivePerception {
  const obstacles: SelfDriveObstacle[] = [];
  if (input.ccVelocityWouldBlock) obstacles.push("vel_against");
  if (input.thinBook !== false) obstacles.push("thin_book"); // unknown → thin
  if (
    typeof input.drawdownPct === "number" &&
    Number.isFinite(input.drawdownPct) &&
    input.drawdownPct >= 9
  ) {
    obstacles.push("drawdown");
  }
  if (sensors.stale) obstacles.push("stale");
  if (!sensors.bookPresent) obstacles.push("missing_book");
  if (!sensors.indexOrProxyPresent) obstacles.push("missing_index");
  if (input.coversBoth === true) obstacles.push("covers_both");

  const ask = sensors.askCents;
  const floorsFail =
    input.sizeZero === true ||
    (typeof input.evCents === "number" &&
      input.evCents < SELFDRIVE_FLOOR_MIRROR.evFloorCents) ||
    (ask != null &&
      (ask < SELFDRIVE_FLOOR_MIRROR.askMinCents ||
        ask > SELFDRIVE_FLOOR_MIRROR.askMaxCents));
  if (floorsFail) obstacles.push("floors_fail");

  let lane: SelfDriveLane = "NONE";
  if (input.side === "yes") lane = "YES";
  else if (input.side === "no") lane = "NO";

  let weather: SelfDrivePerception["weather"] = "clear";
  let weatherNote = "clear road";
  if (input.coversBoth === true || (input.ovPreferSkip === true && (input.ovScore ?? 0) >= 0.35)) {
    weather = "storm";
    weatherNote = "storm — coversBoth / high OV waiting ≥ taking";
  } else if (
    obstacles.includes("thin_book") ||
    obstacles.includes("stale") ||
    input.calibReliable === false ||
    (typeof input.ovScore === "number" && input.ovScore >= 0.2)
  ) {
    weather = "haze";
    weatherNote = "haze — thin/stale/calib/OV caution";
  }

  return { lane, obstacles, weather, weatherNote };
}

function buildLocalization(input: BuildSelfDriveInput): SelfDriveLocalization {
  const phase = phaseFromSecs(input.secsRemaining ?? null, input.horizonPhase);
  let position: SelfDriveLocalization["position"] = "flat";
  if (input.positionHeld === "yes") position = "YES";
  else if (input.positionHeld === "no") position = "NO";
  else if (input.decisionKind === "HOLD" || input.exitHold === true) {
    // held but side unknown → flat unless side stamped
    if (input.side === "yes") position = "YES";
    else if (input.side === "no") position = "NO";
  }
  const dist =
    typeof input.secsRemaining === "number" && Number.isFinite(input.secsRemaining)
      ? Math.max(0, Math.round(input.secsRemaining))
      : null;
  const note =
    dist != null
      ? `phase=${phase} pos=${position} TTE=${dist}s`
      : `phase=${phase} pos=${position} TTE=unknown`;
  return {
    phase,
    position,
    distanceToSettleSec: dist,
    note,
  };
}

function buildPrediction(input: BuildSelfDriveInput): SelfDrivePrediction {
  const pInd =
    typeof input.pInd === "number" && Number.isFinite(input.pInd)
      ? input.pInd
      : typeof input.pYes === "number" && Number.isFinite(input.pYes)
        ? input.pYes
        : null;
  const band80: [number | null, number | null] =
    input.band80 && Array.isArray(input.band80)
      ? [input.band80[0] ?? null, input.band80[1] ?? null]
      : [null, null];
  const settlePick =
    input.settleInputsPresent === true && input.settlePick
      ? input.settlePick
      : input.settlePick ?? null;
  const ovPreferSkip = input.ovPreferSkip === true;
  const ovScore =
    typeof input.ovScore === "number" && Number.isFinite(input.ovScore)
      ? input.ovScore
      : 0;
  const noteParts: string[] = [];
  if (pInd != null) noteParts.push(`p_ind=${Math.round(pInd * 1000) / 1000}`);
  if (settlePick) noteParts.push(`settle=${settlePick}`);
  if (ovPreferSkip) noteParts.push(`OV-SKIP=${ovScore}`);
  return {
    pInd,
    band80,
    settlePick,
    ovPreferSkip,
    ovScore,
    foresightNext: input.foresightNext ?? null,
    note: noteParts.join(" ") || "prediction thin — waiting",
  };
}

function buildSafety(
  input: BuildSelfDriveInput,
  odd: SelfDriveOdd,
  sensors: SelfDriveSensors,
  perception: SelfDrivePerception,
  prediction: SelfDrivePrediction,
): SelfDriveSafety {
  const brakeReasons: string[] = [];
  let emergencyStop = false;

  if (!odd.inOdd) {
    brakeReasons.push("ODD: paperMode false → EMERGENCY_STOP");
    emergencyStop = true;
  }
  for (const r of odd.reasons) {
    if (/paperMode false/.test(r)) {
      /* already */
    } else if (/frozenCcMode false/.test(r) && input.soleDecision === "TAKE") {
      brakeReasons.push(`ODD caution: ${r}`);
    }
  }

  // Blind intersection
  if (!sensors.bookPresent) {
    brakeReasons.push("blind intersection: missing book/ask → stop");
    emergencyStop = true;
  }
  if (!sensors.indexOrProxyPresent) {
    brakeReasons.push("blind intersection: no index/proxy → stop");
  }
  if (sensors.stale) {
    brakeReasons.push("stale feed → stop");
  }
  if (sensors.missing.includes("clock/tte") && input.soleDecision === "TAKE") {
    brakeReasons.push("MISSING_INPUTS: clock/tte");
  }

  // Floors
  if (perception.obstacles.includes("floors_fail")) {
    brakeReasons.push("floors fail (EV/ask/size) — never cut");
  }
  if (input.sizeZero) brakeReasons.push("sizeZero");
  if (
    typeof input.evCents === "number" &&
    input.evCents < SELFDRIVE_FLOOR_MIRROR.evFloorCents &&
    (input.decisionKind === "TAKE_YES" || input.decisionKind === "TAKE_NO")
  ) {
    brakeReasons.push(
      `EV ${input.evCents}¢ < floor ${SELFDRIVE_FLOOR_MIRROR.evFloorCents}¢`,
    );
  }

  // PhD / oracle RISK
  if (prediction.ovPreferSkip) {
    brakeReasons.push(`OV-SKIP score=${prediction.ovScore} — waiting ≥ taking`);
  }
  if (input.coversBoth === true) {
    brakeReasons.push("coversBoth — band/uncertainty weather");
  }
  if (input.calibReliable === false) {
    brakeReasons.push("calibration unreliable ECE");
  }
  if (input.oracleRiskVeto === true) {
    const rr = (input.oracleRiskVetoReasons ?? []).slice(0, 2).join(";");
    brakeReasons.push(rr ? `RISK veto: ${rr}` : "RISK veto");
  }
  if (input.oracleGatesFailed && input.oracleGatesFailed.length > 0) {
    brakeReasons.push(`G_* fail: ${input.oracleGatesFailed.join(",")}`);
  }
  if (input.oracleMissingInputs && input.oracleMissingInputs.length > 0) {
    const miss = input.oracleMissingInputs.slice(0, 4).join(",");
    brakeReasons.push(`MISSING_INPUTS=${miss}`);
  }

  // Obstacles that force brake on TAKE intent
  const wantTake =
    input.decisionKind === "TAKE_YES" ||
    input.decisionKind === "TAKE_NO" ||
    input.soleDecision === "TAKE";
  if (wantTake && perception.obstacles.includes("vel_against")) {
    brakeReasons.push("obstacle vel_against — rear-end / wrong-side risk");
  }
  if (wantTake && perception.obstacles.includes("thin_book")) {
    brakeReasons.push("obstacle thin_book");
  }
  if (wantTake && perception.weather === "storm") {
    brakeReasons.push("weather storm — pull over");
  }

  // Deduplicate while preserving order
  const seen = new Set<string>();
  const uniq: string[] = [];
  for (const r of brakeReasons) {
    if (!seen.has(r)) {
      seen.add(r);
      uniq.push(r);
    }
  }

  // Soft skip path (decision already SKIP) still reports brake reasons for blind/missing
  // but brake flag is true whenever any hard reason exists OR wantTake with reasons.
  const hardBlind =
    emergencyStop ||
    !sensors.bookPresent ||
    sensors.stale ||
    !odd.inOdd ||
    perception.obstacles.includes("floors_fail");
  const brake =
    hardBlind ||
    uniq.length > 0 &&
      (wantTake ||
        !sensors.bookPresent ||
        !sensors.indexOrProxyPresent ||
        prediction.ovPreferSkip ||
        input.coversBoth === true ||
        input.calibReliable === false ||
        (input.oracleGatesFailed?.length ?? 0) > 0 ||
        (input.oracleMissingInputs?.length ?? 0) > 0);

  // Always brake on blind book even when already SKIP (status clarity)
  const brakeFinal =
    brake ||
    !sensors.bookPresent ||
    !odd.inOdd ||
    sensors.stale ||
    perception.obstacles.includes("missing_book");

  return {
    brake: brakeFinal,
    brakeReasons: uniq,
    emergencyStop,
  };
}

function buildPlanning(
  input: BuildSelfDriveInput,
  perception: SelfDrivePerception,
  localization: SelfDriveLocalization,
  prediction: SelfDrivePrediction,
  safety: SelfDriveSafety,
): SelfDrivePlanning {
  const reasons: string[] = [];

  // EXIT / HOLD first when open book
  if (input.ruinWouldSell === true || input.decisionKind === "EXIT") {
    reasons.push("EXIT_RAMP — ruin/exit observe; PATH_RIDE owns sell");
    return {
      planAction: "EXIT_RAMP",
      laneChangeAllowed: false,
      reasons,
    };
  }
  if (
    input.exitHold === true ||
    input.decisionKind === "HOLD" ||
    localization.position !== "flat"
  ) {
    // If flat but HOLD decision → HOLD_LANE
    if (input.decisionKind === "HOLD" || input.exitHold === true || localization.position !== "flat") {
      reasons.push("HOLD_LANE — position/PATH_RIDE owns; no lane flip");
      return {
        planAction: "HOLD_LANE",
        laneChangeAllowed: false,
        reasons,
      };
    }
  }

  if (safety.brake || safety.emergencyStop) {
    reasons.push(...safety.brakeReasons.slice(0, 3));
    reasons.push("PULL_OVER_SKIP — braking is success when road ambiguous");
    return {
      planAction: "PULL_OVER_SKIP",
      laneChangeAllowed: false,
      reasons,
    };
  }

  // Lane change only with strong evidence
  const settleOk =
    prediction.settlePick === "yes" || prediction.settlePick === "no";
  const settleAligns =
    (prediction.settlePick === "yes" && input.side === "yes") ||
    (prediction.settlePick === "no" && input.side === "no");
  const strongEvidence =
    settleOk &&
    settleAligns &&
    !perception.obstacles.includes("vel_against") &&
    perception.weather !== "storm" &&
    typeof input.evCents === "number" &&
    input.evCents >= SELFDRIVE_FLOOR_MIRROR.evFloorCents &&
    input.calibReliable !== false;

  const laneChangeAllowed = strongEvidence;
  if (!laneChangeAllowed && (input.decisionKind === "TAKE_YES" || input.decisionKind === "TAKE_NO")) {
    reasons.push("lane_change blocked — need settle+edge+no vel_against");
    return {
      planAction: "PULL_OVER_SKIP",
      laneChangeAllowed: false,
      reasons,
    };
  }

  if (
    input.decisionKind === "TAKE_YES" &&
    perception.lane === "YES" &&
    laneChangeAllowed
  ) {
    reasons.push("CRUISE_TAKE_YES — clear YES lane, settle aligned");
    return { planAction: "CRUISE_TAKE_YES", laneChangeAllowed: true, reasons };
  }
  if (
    input.decisionKind === "TAKE_NO" &&
    perception.lane === "NO" &&
    laneChangeAllowed
  ) {
    reasons.push("CRUISE_TAKE_NO — clear NO lane, settle aligned");
    return { planAction: "CRUISE_TAKE_NO", laneChangeAllowed: true, reasons };
  }

  // Default: pull over (skip is first-class)
  reasons.push("PULL_OVER_SKIP — default; destination=fee-net+survive not frequency");
  return {
    planAction: "PULL_OVER_SKIP",
    laneChangeAllowed: false,
    reasons,
  };
}

function buildControl(
  input: BuildSelfDriveInput,
  planning: SelfDrivePlanning,
): SelfDriveControl {
  const floorsHeld = true; // doctrine: never cut — proposal only
  let sizeProposalKelly = 0;
  if (
    (planning.planAction === "CRUISE_TAKE_YES" ||
      planning.planAction === "CRUISE_TAKE_NO") &&
    typeof input.evCents === "number" &&
    input.evCents >= SELFDRIVE_FLOOR_MIRROR.evFloorCents
  ) {
    // Soft proposal: edge/100 * mult, capped
    const raw = clamp01((input.evCents / 100) * SELFDRIVE_PROPOSAL_KELLY_MULT);
    sizeProposalKelly = Math.min(SELFDRIVE_FLOOR_MIRROR.kellyCap, raw);
  }
  return {
    sizeProposalKelly: Math.round(sizeProposalKelly * 1000) / 1000,
    kellyCapLive: SELFDRIVE_FLOOR_MIRROR.kellyCap,
    proposalMult: SELFDRIVE_PROPOSAL_KELLY_MULT,
    floorsHeld,
    note: `proposalKelly=${Math.round(sizeProposalKelly * 1000) / 1000} cap=${SELFDRIVE_FLOOR_MIRROR.kellyCap} (live floors uncut)`,
  };
}

function buildDriverMonitor(input: BuildSelfDriveInput): SelfDriveDriverMonitor {
  const calibReliable =
    typeof input.calibReliable === "boolean" ? input.calibReliable : null;
  const calibN = typeof input.calibN === "number" ? input.calibN : null;
  const ece = typeof input.ece === "number" ? input.ece : null;
  const councilCoherence =
    typeof input.councilCoherence === "number" ? input.councilCoherence : null;
  let alert: string | null = null;
  if (calibReliable === false) alert = "driver drowsy — calib unreliable; lean SKIP";
  else if (councilCoherence != null && councilCoherence < 0.4) {
    alert = "council incoherent — prefer brake";
  }
  return {
    calibReliable,
    calibN,
    ece,
    scarEchoNote: input.scarEchoNote ?? null,
    councilCoherence,
    alert,
  };
}

function buildThoughtTrace(stack: {
  odd: SelfDriveOdd;
  sensors: SelfDriveSensors;
  perception: SelfDrivePerception;
  localization: SelfDriveLocalization;
  prediction: SelfDrivePrediction;
  planning: SelfDrivePlanning;
  control: SelfDriveControl;
  safety: SelfDriveSafety;
  driverMonitor: SelfDriveDriverMonitor;
}): string[] {
  // 6–10 short labeled lines — deterministic
  const lines: string[] = [
    `ODD: ${stack.odd.inOdd ? "in" : "OUT"} KXBTC15M paper=${stack.odd.paperMode} frozenCc=${stack.odd.frozenCc}`,
    `SENSORS: book=${stack.sensors.bookPresent} idx=${stack.sensors.indexOrProxyPresent} tte=${stack.sensors.secsRemaining ?? "?"} vel=${stack.sensors.velKnown} stale=${stack.sensors.stale}`,
    `PERCEPT: lane=${stack.perception.lane} weather=${stack.perception.weather} obstacles=[${stack.perception.obstacles.slice(0, 4).join(",") || "none"}]`,
    `LOCAL: ${stack.localization.note}`,
    `PRED: ${stack.prediction.note}`,
    `PLAN: ${stack.planning.planAction} laneChange=${stack.planning.laneChangeAllowed}`,
    `CTRL: ${stack.control.note}`,
    `SAFE: brake=${stack.safety.brake} [${stack.safety.brakeReasons.slice(0, 3).join(" | ") || "none"}]`,
  ];
  if (stack.driverMonitor.alert) {
    lines.push(`DRIVER: ${stack.driverMonitor.alert}`);
  } else {
    lines.push(
      `DRIVER: calibReliable=${stack.driverMonitor.calibReliable} n=${stack.driverMonitor.calibN ?? "?"} coh=${stack.driverMonitor.councilCoherence ?? "?"}`,
    );
  }
  // Metaphor closer (≤10 total)
  if (lines.length < 10) {
    lines.push(
      "RULE: braking(SKIP)=success when road ambiguous; destination=fee-net+survive",
    );
  }
  return lines.slice(0, 10);
}

/**
 * Build full SelfDrive stack from mind/stamp fields.
 * Pure. No network. No LLM.
 */
export function buildSelfDriveStack(input: BuildSelfDriveInput): SelfDriveStack {
  const odd = buildOdd(input);
  const sensors = buildSensors(input);
  const perception = buildPerception(input, sensors);
  const localization = buildLocalization(input);
  const prediction = buildPrediction(input);
  const safety = buildSafety(input, odd, sensors, perception, prediction);
  const planning = buildPlanning(
    input,
    perception,
    localization,
    prediction,
    safety,
  );
  const control = buildControl(input, planning);
  const driverMonitor = buildDriverMonitor(input);
  const thoughtTrace = buildThoughtTrace({
    odd,
    sensors,
    perception,
    localization,
    prediction,
    planning,
    control,
    safety,
    driverMonitor,
  });

  return {
    odd,
    sensors,
    perception,
    localization,
    prediction,
    planning,
    control,
    safety,
    driverMonitor,
    thoughtTrace,
    planAction: planning.planAction,
    brakeReasons: safety.brakeReasons,
    voice: "selfDrive-road",
    schema: "self_drive_v1",
  };
}

/** Lean early peek — brake + planAction without thoughtTrace/control/driverMonitor. */
export type SelfDriveBrakePeek = {
  brake: boolean;
  reasons: string[];
  planAction: SelfDrivePlanAction;
  weather: SelfDrivePerception["weather"];
  ovPreferSkip: boolean;
  emergencyStop: boolean;
};

/**
 * Cheap SelfDrive peek for council preferSkip lean.
 * Same brake + planAction as full stack; skips thoughtTrace / control / driverMonitor.
 */
export function peekSelfDriveBrake(input: BuildSelfDriveInput): SelfDriveBrakePeek {
  const odd = buildOdd(input);
  const sensors = buildSensors(input);
  const perception = buildPerception(input, sensors);
  const localization = buildLocalization(input);
  const prediction = buildPrediction(input);
  const safety = buildSafety(input, odd, sensors, perception, prediction);
  const planning = buildPlanning(
    input,
    perception,
    localization,
    prediction,
    safety,
  );
  return {
    brake: safety.brake,
    reasons: safety.brakeReasons,
    planAction: planning.planAction,
    weather: perception.weather,
    ovPreferSkip: prediction.ovPreferSkip,
    emergencyStop: safety.emergencyStop,
  };
}
