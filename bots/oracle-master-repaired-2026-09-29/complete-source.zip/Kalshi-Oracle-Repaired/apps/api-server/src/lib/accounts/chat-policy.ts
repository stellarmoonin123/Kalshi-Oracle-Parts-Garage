/**
 * accounts/chat-policy.ts — server-side role gating for Oracle chat.
 *
 * The chat role comes from the authenticated session (never the request
 * body). USER accounts get read-only desk facts only; everything that could
 * touch processes, source code, config, logs, credentials or GitHub is
 * ADMIN-only. Unknown / missing role → USER (fail closed).
 */
export type ChatRole = "ADMIN" | "USER";

/** Desk-agent tools a USER may call (all read-only, no source / logs / PRs). */
export const USER_CHAT_TOOLS: ReadonlySet<string> = new Set([
  "get_status",
  "get_entry_funnel",
  "get_positions",
  "get_recent_trades",
  "get_decision_traces",
  "get_calibration",
  "get_desk_knowledge",
  "get_healthz",
]);

/**
 * ADMIN-only chat capabilities (documented in docs/accounts/CHAT_SECURITY.md):
 *   bounce_api (restart API process), restore_default_settings ("default"
 *   command rewrites bot config), read_file / list_dir / search_code / grep
 *   (source + possible secrets), tail_log (raw logs), propose_fix (GitHub PR).
 */
export const ADMIN_ONLY_CHAT_CAPABILITIES = [
  "bounce_api",
  "restore_default_settings",
  "read_file",
  "list_dir",
  "search_code",
  "grep",
  "tail_log",
  "propose_fix",
] as const;

export function normalizeChatRole(v: unknown): ChatRole {
  return v === "ADMIN" ? "ADMIN" : "USER";
}

export function chatToolAllowed(role: ChatRole, tool: string): boolean {
  return role === "ADMIN" || USER_CHAT_TOOLS.has(tool);
}

export const USER_CHAT_REFUSAL =
  "That action is limited to the Administrator. Your account can ask about desk status, trades, " +
  "diagnostics and strategy doctrine, but cannot change settings, restart services, read source or logs, " +
  "or manage accounts.";
