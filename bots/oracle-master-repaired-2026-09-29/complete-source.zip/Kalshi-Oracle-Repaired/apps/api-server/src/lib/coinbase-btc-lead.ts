/**
 * coinbase-btc-lead.ts — public Coinbase BTC-USD lead for the lag-meter.
 *
 * DECLARED LEAD: coinbase. Public Exchange ticker + WS; no API key.
 * Binance BTCUSDT is HTTP 451 geo-blocked from this box — not the lead.
 *
 * Heartbeats / subscribe acks never stamp a print. lagProven stays false
 * until BasisTracker sees a fresh Coinbase print vs Kalshi book quoteTs.
 * Never invents lag$ or a 5–15s series. paperMode unchanged.
 */
import WebSocket from "ws";
import type { LagTick } from "./lag-meter.js";

export const DECLARED_LAG_LEAD = "coinbase" as const;
export const COINBASE_PRODUCT = "BTC-USD";
export const COINBASE_REST_TICKER_URL =
  "https://api.exchange.coinbase.com/products/BTC-USD/ticker";
export const COINBASE_WS_URL = "wss://ws-feed.exchange.coinbase.com";
export const COINBASE_LEAD_FRESH_MS = 2_000;
export const COINBASE_LEAD_STALE_MS = 45_000;
export const COINBASE_REST_POLL_MS = 1_000;
export const COINBASE_REST_TIMEOUT_MS = 2_000;
export const COINBASE_WS_MIN_BACKOFF_MS = 250;
export const COINBASE_WS_MAX_BACKOFF_MS = 8_000;

const LAG_RING_MS = 5 * 60_000;
const LAG_RING_MAX_SAMPLES = 5 * 60 + 8;
const UA = "kalshi-bot-coinbase-lead/1.0";

export type CoinbaseLeadVia = "ws" | "rest";

export type CoinbaseLeadPrint = {
  price: number;
  /** Exchange ticker/trade time. Heartbeats never write this. */
  exchangeTs: number;
  /** Local receive time — 1s ring alignment vs the Kalshi tick clock. */
  receivedAt: number;
  via: CoinbaseLeadVia;
};

export type CoinbaseLeadQuote = {
  price: number;
  source: "coinbase";
  observedAt: number;
  exchangeTs: number;
  ageMs: number;
  via: CoinbaseLeadVia;
  stale: boolean;
};

function parsePrice(raw: unknown): number | null {
  const n = typeof raw === "number" ? raw : typeof raw === "string" ? parseFloat(raw) : NaN;
  return Number.isFinite(n) && n > 0 ? n : null;
}

function parseExchangeTs(raw: unknown, fallback: number): number {
  if (typeof raw === "string" && raw.length > 0) {
    const ms = Date.parse(raw);
    if (Number.isFinite(ms) && ms > 0) return ms;
  }
  return fallback;
}

export function pushLeadRing(ring: LagTick[], tMs: number, px: number): void {
  if (!Number.isFinite(tMs) || !Number.isFinite(px) || px <= 0) return;
  const sec = Math.floor(tMs / 1000);
  const last = ring[ring.length - 1];
  if (last && Math.floor(last.tMs / 1000) === sec) {
    last.tMs = tMs;
    last.px = px;
  } else {
    ring.push({ tMs, px });
  }
  const cutoff = tMs - LAG_RING_MS;
  while (ring.length > 0 && (ring[0].tMs < cutoff || ring.length > LAG_RING_MAX_SAMPLES)) {
    ring.shift();
  }
}

/**
 * Parse a Coinbase WS/REST ticker body into a print.
 * Heartbeats, subscribe acks, errors, and ticker-less payloads → null.
 */
export function parseCoinbaseTickerBody(
  body: unknown,
  receivedAt: number,
  via: CoinbaseLeadVia,
): CoinbaseLeadPrint | null {
  if (body == null || typeof body !== "object") return null;
  const rec = body as Record<string, unknown>;
  const type = rec.type;
  if (type === "heartbeat" || type === "subscriptions" || type === "error" || type === "pong") {
    return null;
  }
  if (typeof rec.product_id === "string" && rec.product_id !== COINBASE_PRODUCT) return null;
  const price = parsePrice(rec.price);
  if (price == null) return null;
  const exchangeTs = parseExchangeTs(rec.time, receivedAt);
  return { price, exchangeTs, receivedAt, via };
}

async function fetchCoinbaseRestTicker(now: number): Promise<CoinbaseLeadPrint | null> {
  try {
    const resp = await fetch(COINBASE_REST_TICKER_URL, {
      headers: { Accept: "application/json", "User-Agent": UA },
      signal: AbortSignal.timeout(COINBASE_REST_TIMEOUT_MS),
    });
    if (!resp.ok) return null;
    const body = await resp.json();
    return parseCoinbaseTickerBody(body, now, "rest");
  } catch {
    return null;
  }
}

export class CoinbaseBtcLead {
  private last: CoinbaseLeadPrint | null = null;
  private readonly ring: LagTick[] = [];
  private ws: WebSocket | null = null;
  private restTimer: ReturnType<typeof setInterval> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private backoffMs = COINBASE_WS_MIN_BACKOFF_MS;
  private running = false;
  private lastRestAttemptAt = 0;

  getLast(): CoinbaseLeadPrint | null {
    return this.last;
  }

  getRing(): LagTick[] {
    return this.ring.slice();
  }

  getQuote(nowMs = Date.now()): CoinbaseLeadQuote | null {
    if (!this.last) return null;
    const ageMs = Math.max(0, nowMs - this.last.receivedAt);
    return {
      price: this.last.price,
      source: "coinbase",
      observedAt: this.last.receivedAt,
      exchangeTs: this.last.exchangeTs,
      ageMs,
      via: this.last.via,
      stale: ageMs > COINBASE_LEAD_STALE_MS,
    };
  }

  /** Instant Coinbase quote if the print is fresh. Null if missing/aged — never a fake mid. */
  getFreshQuote(nowMs = Date.now(), freshMs = COINBASE_LEAD_FRESH_MS): CoinbaseLeadQuote | null {
    const q = this.getQuote(nowMs);
    if (!q || q.stale || q.ageMs > freshMs) return null;
    return q;
  }

  /** Test / REST helper: record a real ticker print. Heartbeat-shaped bodies are ignored. */
  ingestPrint(print: CoinbaseLeadPrint): boolean {
    if (!Number.isFinite(print.price) || print.price <= 0) return false;
    if (!Number.isFinite(print.receivedAt) || print.receivedAt <= 0) return false;
    this.last = print;
    pushLeadRing(this.ring, print.receivedAt, print.price);
    return true;
  }

  ingestJson(raw: unknown, receivedAt: number, via: CoinbaseLeadVia = "ws"): boolean {
    const print = parseCoinbaseTickerBody(raw, receivedAt, via);
    if (!print) return false;
    return this.ingestPrint(print);
  }

  start(): void {
    if (this.running) return;
    this.running = true;
    this.backoffMs = COINBASE_WS_MIN_BACKOFF_MS;
    this.openWs();
    this.restTimer = setInterval(() => {
      void this.pollRestIfNeeded();
    }, COINBASE_REST_POLL_MS);
    void this.pollRestIfNeeded();
  }

  stop(): void {
    this.running = false;
    if (this.restTimer) {
      clearInterval(this.restTimer);
      this.restTimer = null;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.closeWs();
  }

  private openWs(): void {
    if (!this.running) return;
    this.closeWs();
    try {
      const ws = new WebSocket(COINBASE_WS_URL, { handshakeTimeout: 8_000 });
      this.ws = ws;
      ws.on("open", () => {
        this.backoffMs = COINBASE_WS_MIN_BACKOFF_MS;
        try {
          ws.send(JSON.stringify({
            type: "subscribe",
            product_ids: [COINBASE_PRODUCT],
            channels: ["ticker"],
          }));
        } catch {
          /* reconnect path handles close */
        }
      });
      ws.on("message", (data) => {
        const receivedAt = Date.now();
        let body: unknown;
        try {
          body = JSON.parse(String(data));
        } catch {
          return;
        }
        this.ingestJson(body, receivedAt, "ws");
      });
      ws.on("close", () => {
        if (this.ws === ws) this.ws = null;
        this.scheduleReconnect();
      });
      ws.on("error", () => {
        try { ws.close(); } catch { /* ignore */ }
      });
    } catch {
      this.scheduleReconnect();
    }
  }

  private closeWs(): void {
    const ws = this.ws;
    this.ws = null;
    if (!ws) return;
    try { ws.removeAllListeners(); } catch { /* ignore */ }
    try { ws.close(); } catch { /* ignore */ }
  }

  private scheduleReconnect(): void {
    if (!this.running) return;
    if (this.reconnectTimer) return;
    const wait = this.backoffMs;
    this.backoffMs = Math.min(this.backoffMs * 2, COINBASE_WS_MAX_BACKOFF_MS);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.openWs();
    }, wait);
  }

  private async pollRestIfNeeded(): Promise<void> {
    if (!this.running) return;
    const now = Date.now();
    if (this.last && now - this.last.receivedAt < COINBASE_LEAD_FRESH_MS) return;
    if (now - this.lastRestAttemptAt < COINBASE_REST_POLL_MS) return;
    this.lastRestAttemptAt = now;
    const print = await fetchCoinbaseRestTicker(Date.now());
    if (print) this.ingestPrint(print);
  }
}

export const coinbaseBtcLead = new CoinbaseBtcLead();

/** Production fetch: WS/REST lead cache if fresh, else one REST hit. Never a fake mid. */
export async function fetchCoinbaseLeadQuote(
  nowMs = Date.now(),
): Promise<{ price: number; source: "coinbase"; observedAt: number } | null> {
  const hot = coinbaseBtcLead.getFreshQuote(nowMs);
  if (hot) return { price: hot.price, source: "coinbase", observedAt: hot.observedAt };
  const print = await fetchCoinbaseRestTicker(nowMs);
  if (print) {
    coinbaseBtcLead.ingestPrint(print);
    return { price: print.price, source: "coinbase", observedAt: print.receivedAt };
  }
  return null;
}
