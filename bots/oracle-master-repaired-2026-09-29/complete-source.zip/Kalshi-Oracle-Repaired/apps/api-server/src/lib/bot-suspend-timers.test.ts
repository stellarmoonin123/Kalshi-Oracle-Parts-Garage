/**
 * bot-suspend-timers.test.ts
 *
 * Regression coverage for the daily-loss-cap suspend() timer leak: suspend()
 * previously cleared only tickTimer, leaving balanceTimer (15s) and
 * pretradeTimer (500ms) running in the background. A subsequent start()
 * (the normal "resume after suspend" flow) then registered a SECOND
 * balanceTimer and pretradeTimer on top of the still-running originals,
 * producing two concurrent balance refreshers and two concurrent pre-trade
 * sim loops racing on shared state.
 *
 * suspend() is private, so this test reaches it via a controlled cast on the
 * shared `tradingBot` singleton and only exercises the specific timer fields
 * it touches, restoring them afterward.
 *
 * Run with:
 *   node --experimental-strip-types src/lib/bot-suspend-timers.test.ts
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { tradingBot } from "./trading-bot.js";

type TimerAccess = {
  tickTimer: NodeJS.Timeout | null;
  balanceTimer: NodeJS.Timeout | null;
  pretradeTimer: NodeJS.Timeout | null;
  config: { enabled: boolean };
  state: string;
  suspend: () => void;
};

test("suspend() clears AND nulls tickTimer, balanceTimer, and pretradeTimer", () => {
  const bot = tradingBot as unknown as TimerAccess;
  const originalTick      = bot.tickTimer;
  const originalBalance   = bot.balanceTimer;
  const originalPretrade  = bot.pretradeTimer;
  const originalEnabled   = bot.config.enabled;
  const originalState     = bot.state;
  try {
    // Simulate three live intervals as if the bot had been running.
    bot.tickTimer     = setInterval(() => {}, 60_000);
    bot.balanceTimer  = setInterval(() => {}, 60_000);
    bot.pretradeTimer = setInterval(() => {}, 60_000);

    bot.suspend();

    assert.equal(bot.tickTimer,     null, "suspend() must null tickTimer, not just clear it");
    assert.equal(bot.balanceTimer,  null, "suspend() must clear AND null balanceTimer");
    assert.equal(bot.pretradeTimer, null, "suspend() must clear AND null pretradeTimer");
    assert.equal(bot.config.enabled, false, "suspend() must disable the bot config");
    assert.equal(bot.state, "SUSPENDED");
  } finally {
    // Clean up any interval this test itself created (suspend() should have
    // cleared them, but guard against a regression re-introducing the leak).
    if (bot.tickTimer)     clearInterval(bot.tickTimer);
    if (bot.balanceTimer)  clearInterval(bot.balanceTimer);
    if (bot.pretradeTimer) clearInterval(bot.pretradeTimer);
    bot.tickTimer     = originalTick;
    bot.balanceTimer  = originalBalance;
    bot.pretradeTimer = originalPretrade;
    bot.config.enabled = originalEnabled;
    bot.state = originalState;
  }
});
