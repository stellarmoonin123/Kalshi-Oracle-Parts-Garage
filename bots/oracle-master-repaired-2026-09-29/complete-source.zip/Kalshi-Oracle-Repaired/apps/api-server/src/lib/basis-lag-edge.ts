/**
 * basis-lag-edge.ts
 *
 * Extracted BASIS_LAG_EDGE signal/evaluate helpers. strategy-library.ts
 * is a caller. Proven lag book — not ENABLE_STRATEGY, not a new engine.
 * Does not bypass computeTradeEV / PATH_GATE / Kelly / 9%. Does not
 * expand SIZE_RESCUE. Does not flip paperMode / autoMode.
 *
 * LOCKS (do not loosen):
 *   - hard window 2–15m (fill-power: gold 14–15m must not hard-null evaluate;
 *     strategy-library maxTimeMins must match — evaluateAllStrategies filters
 *     metadata before this evaluate runs)
 *   - persistence streak ≥3 same-sign (not a 1-tick spike)
 *   - fully-priced ≥90¢ refused
 *   - net edge 8pt (15pt when ask ≥80¢)
 *   - preferred 3–10m unless raw edge ≥18pt
 *   - local computeTradeEV netEV > 0 (same math as PATH_GATE)
 *
 * p for Kelly/EV downstream is basisLagWinRate (winRateAtPrice), never
 * heuristic confidence. evaluate() reports evidence-strength confidence
 * (edge / streak / rolling / short) — not pWin, not a 0.55 floor bandage.
 */

import { computeTradeEV } from "./trade-path.js";
import { evaluateLiquidity, computeLagNetEdgePts, logLiquidityDecision } from "./liquidity-policy.js";
import { lagAgreesWithSide } from "./lag-meter.js";
import { paperMoneyMakerLagMinAbsDollars, isMtfAlignedCheapTake } from "./settlement-side.js";
import { haRiverConfirmSide, isStrikePinNoEnter } from "./path-ride.js";
import { projectSettlementPrice } from "./basis-tracker.js";
import { confluenceFactorBias } from "./confluence-cascade.js";
import { lagSideConfirmationAgrees } from "./lag-side-agree.js";
import type { StrategyObservation, StrategyResult, TradeSignal } from "./strategy-library.js";

export { lagSideConfirmationAgrees };

export const BASIS_LAG_MIN_TIME_MINS = 2;
export const BASIS_LAG_MAX_TIME_MINS = 15;
export const BASIS_LAG_MIN_STREAK_TICKS = 3;
export const BASIS_LAG_MIN_PROJ_DIST_PCT = 0.05;
export const BASIS_LAG_FULLY_PRICED_ASK = 90;
export const BASIS_LAG_MIN_EDGE_PTS = 8;
export const BASIS_LAG_RICH_ASK_CENTS = 80;
export const BASIS_LAG_RICH_MIN_EDGE_PTS = 15;
export const BASIS_LAG_PREFERRED_MIN = 3;
export const BASIS_LAG_PREFERRED_MAX = 10;
export const BASIS_LAG_LARGE_EDGE_PTS = 18;
export const BASIS_LAG_STRATEGY_ID = "BASIS_LAG_EDGE" as const;
export const BASIS_LAG_STRATEGY_NAME = "Basis Lag Edge";
/** LAG cheap cell — remake overlay may proceed here; do not widen fully priced. */
export const LAG_CHEAP_ASK_CENTS = 55;


/**
 * Live projector used by evaluate: fairBRTI + velocity × secs (same formula
 * as the basis-lag meter). Snapshot lastBasisState.projectedSettlementPrice
 * can lag a tick and sit on the other side of the floor (#508 77471 YES vs
 * 77024 NO). One source of truth = live. If snapshot disagrees on side,
 * fail-closed SKIP — do not fill the evaluate side.
 */
export function liveLagProjectedSettlement(obs: {
  estimatedFairBRTI?: number | null;
  velocityDolPerMin?: number | null;
  secsRemaining?: number | null;
}): number | undefined {
  const fair = obs.estimatedFairBRTI;
  const vel = obs.velocityDolPerMin;
  const secs = obs.secsRemaining;
  if (typeof fair !== "number" || !Number.isFinite(fair)) return undefined;
  if (typeof vel !== "number" || !Number.isFinite(vel)) return undefined;
  if (typeof secs !== "number" || !Number.isFinite(secs)) return undefined;
  const live = projectSettlementPrice(fair, vel, secs);
  return Number.isFinite(live) ? live : undefined;
}

export function lagProjSideOfFloor(proj: number, floor: number): "YES" | "NO" | null {
  if (!Number.isFinite(proj) || !(floor > 0) || !Number.isFinite(floor)) return null;
  const pct = ((proj - floor) / floor) * 100;
  if (Math.abs(pct) < BASIS_LAG_MIN_PROJ_DIST_PCT) return null;
  return pct > 0 ? "YES" : "NO";
}

/** Tape-computable orig-LAG persist analog. Distinct proj prints vs floor. */
export type OrigLagProjStreak = {
  sign: 1 | -1 | 0;
  count: number;
  lastDistinctProj: number | null;
};

export function emptyOrigLagProjStreak(): OrigLagProjStreak {
  return { sign: 0, count: 0, lastDistinctProj: null };
}

/**
 * Consecutive DISTINCT projectedSettlement samples on the same side of the
 * floor (displacement ≥ BASIS_LAG_MIN_PROJ_DIST_PCT). Scorer wiring only:
 * Live evaluate obs (and scorers): copy onto obs.basisStreakSign/Count so
 * evaluate can FIRE a real persist. Does not invent Coinbase lag$, HA, lead$.
 */
export function updateOrigLagProjStreak(
  prev: OrigLagProjStreak,
  tick: { projectedSettlement?: number | null; floor: number },
): OrigLagProjStreak {
  const proj = tick.projectedSettlement;
  if (typeof proj !== "number" || !Number.isFinite(proj) || !(tick.floor > 0)) {
    return { sign: 0, count: 0, lastDistinctProj: prev.lastDistinctProj };
  }
  if (prev.lastDistinctProj != null && proj === prev.lastDistinctProj) {
    return prev;
  }
  const side = lagProjSideOfFloor(proj, tick.floor);
  if (!side) {
    return { sign: 0, count: 0, lastDistinctProj: proj };
  }
  const sign: 1 | -1 = side === "YES" ? 1 : -1;
  if (sign === prev.sign) {
    return { sign, count: prev.count + 1, lastDistinctProj: proj };
  }
  return { sign, count: 1, lastDistinctProj: proj };
}

export function origLagStreakFields(s: OrigLagProjStreak): {
  basisStreakSign: 1 | -1 | 0;
  basisStreakCount: number;
} {
  return { basisStreakSign: s.sign, basisStreakCount: s.count };
}

/**
 * Live evaluate wiring. Analog persist lands on obs only when Coinbase lag$
 * is finite nonzero AND same sign. Meter missing or analog vs meter disagree
 * → 0×0 fail-closed (NOT_PERSISTENT). Does not invent lag$/HA/lead.
 */
export function liveOrigLagStreakOnObs(opts: {
  analog: OrigLagProjStreak;
  lagDollars?: number | null;
  lagStale?: boolean;
}): { basisStreakSign: 1 | -1 | 0; basisStreakCount: number; wired: boolean; reason: string } {
  const lagD = finiteNonZeroDollar(opts.lagDollars);
  if (opts.lagStale !== false || lagD == null) {
    return { basisStreakSign: 0, basisStreakCount: 0, wired: false, reason: "meter_missing" };
  }
  if (opts.analog.sign === 0 || opts.analog.count <= 0) {
    return { basisStreakSign: 0, basisStreakCount: 0, wired: false, reason: "analog_empty" };
  }
  if ((opts.analog.sign === 1 && lagD < 0) || (opts.analog.sign === -1 && lagD > 0)) {
    return { basisStreakSign: 0, basisStreakCount: 0, wired: false, reason: "analog_meter_disagree" };
  }
  return {
    basisStreakSign: opts.analog.sign,
    basisStreakCount: opts.analog.count,
    wired: true,
    reason: "wired",
  };
}

export function canonicalLagProjectedSettlement(opts: {
  liveProj?: number | null;
  snapshotProj?: number | null;
  floor: number;
}): { proj: number | undefined; splitBrain: boolean } {
  const live = typeof opts.liveProj === "number" && Number.isFinite(opts.liveProj) ? opts.liveProj : undefined;
  const snap = typeof opts.snapshotProj === "number" && Number.isFinite(opts.snapshotProj) ? opts.snapshotProj : undefined;
  if (live != null && snap != null) {
    const a = lagProjSideOfFloor(live, opts.floor);
    const b = lagProjSideOfFloor(snap, opts.floor);
    if (a && b && a !== b) return { proj: undefined, splitBrain: true };
  }
  // Live meter is the evaluate source of truth when present.
  const proj = live ?? snap;
  return { proj, splitBrain: false };
}

export type LagUnprovenGateKind = "PROVEN" | "REMAKE_OVERLAY" | "ORIGINAL_LOCK" | "PAPER_ORIG_PROJ";

export interface LagUnprovenGateResult {
  kind: LagUnprovenGateKind;
  proceed: boolean;
  reasonCode: string;
  reason: string;
}

function finiteNonZeroDollar(d: number | null | undefined): number | null {
  return typeof d === "number" && Number.isFinite(d) && d !== 0 ? d : null;
}

function dollarsAgreeWithSide(side: "yes" | "no" | undefined, d: number): boolean {
  if (side !== "yes" && side !== "no") return true;
  return side === "yes" ? d > 0 : d < 0;
}

/**
 * LAG_UNPROVEN classifier. Never invents 5–15s (tau stays null).
 * PROVEN: lagProven===true and the chosen side is not fought by the only
 *   available $. Opposite-sign catch-up lead is not PROVEN for YES.
 *   Agreeing Coinbase lag$ still proceeds (remake lead junk is ignored).
 *   LAG ≤55 only when proven. Evaluate still requires HA or CC same sign as proj.
 * UNPROVEN skip: !lagProven is ORIGINAL_LOCK in paper and live — no REMAKE_OVERLAY
 *   cheap fill, no PAPER_ORIG_PROJ. corr_junk never fills (lead$ overlay dead).
 */
export function classifyLagUnprovenGate(opts: {
  lagProven?: boolean;
  lagStale?: boolean;
  leadSeconds?: number | null;
  leadDollars?: number | null;
  proofHitRate?: number | null;
  sideAsk?: number;
  /** Traded side. When set, finite leadDollars of the opposite sign is not PROVEN. */
  side?: "yes" | "no";
  /** Coinbase tau $. May be null on corr_junk; then leadDollars is the lead. */
  lagDollars?: number | null;
  lagReason?: string | null;
  paperMode?: boolean;
}): LagUnprovenGateResult {
  const fromLead = finiteNonZeroDollar(opts.leadDollars);
  const fromCb = finiteNonZeroDollar(opts.lagDollars);
  const stale = opts.lagStale !== false;
  const leadDisagreesWithSide = fromLead != null && !dollarsAgreeWithSide(opts.side, fromLead);
  const agreeing =
    (fromLead != null && dollarsAgreeWithSide(opts.side, fromLead) ? fromLead : null)
    ?? (fromCb != null && dollarsAgreeWithSide(opts.side, fromCb) ? fromCb : null);
  const hasLead = agreeing != null;

  // corr_junk: tau is null; do not fill from catch-up lead$. Never fake 5–15s.
  if (opts.lagReason === "corr_junk") {
    return {
      kind: "ORIGINAL_LOCK",
      proceed: false,
      reasonCode: "LAG_UNPROVEN",
      reason: "corr_junk no fill — fail-closed (never fake 5–15s)",
    };
  }

  // Opposite-sign lead is never PROVEN for the chosen side. Fail-closed only
  // when no agreeing Coinbase lag$ remains — remake lead vs agreeing tau is
  // junk, not a skip. Missing $ is not disagree.
  if (leadDisagreesWithSide && !hasLead) {
    return {
      kind: "ORIGINAL_LOCK",
      proceed: false,
      reasonCode: "LAG_DISAGREES",
      reason: `lead/lag$ disagrees with ${opts.side} — fail-closed (never invent 5–15s)`,
    };
  }
  if (opts.lagProven === true) {
    return {
      kind: "PROVEN",
      proceed: true,
      reasonCode: "LAG_PROVEN",
      reason: stale
        ? "lag catch-up proven (lagStale does not ORIGINAL_LOCK when proven)"
        : "lag catch-up proven, Coinbase present",
    };
  }

  const pred = stale
    ? `ORIGINAL_LOCK unproven skip Coinbase missing/lagStale lagProven=${opts.lagProven} leadSeconds=${opts.leadSeconds} leadDollars=${opts.leadDollars} (never fake 5–15s)`
    : `ORIGINAL_LOCK unproven skip lagProven=${opts.lagProven} lagStale=${opts.lagStale} leadSeconds=${opts.leadSeconds} leadDollars=${opts.leadDollars} (never fake 5–15s)`;
  return {
    kind: "ORIGINAL_LOCK",
    proceed: false,
    reasonCode: "LAG_UNPROVEN",
    reason: pred,
  };
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

/**
 * Evidence-strength confidence for BASIS_LAG_EDGE. Independent of p
 * (basisLagWinRate). Extra edge / extra streak / rolling / short-agree.
 * Not a 0.55 floor bandage. Selector keep admits a directional fire below 0.55.
 */
export function basisLagEvidenceConfidence(opts: {
  edgePts: number;
  minEdgePts: number;
  rollingBasis?: number;
  basisShort?: number;
  isLong: boolean;
  streakCount: number;
}): number {
  const extraStreak = Math.max(0, opts.streakCount - BASIS_LAG_MIN_STREAK_TICKS);
  let conf = 0.50
    + clamp((opts.edgePts - opts.minEdgePts) / 100, 0, 0.12)
    + clamp(extraStreak * 0.02, 0, 0.06);
  if (opts.rollingBasis !== undefined && Math.abs(opts.rollingBasis) > 5) conf += 0.03;
  if (opts.basisShort !== undefined && Math.sign(opts.basisShort) === (opts.isLong ? 1 : -1)) conf += 0.02;
  return clamp(conf, 0.40, 0.80);
}


/** Signed $ for LAG agree. Tau lagDollars first; if tau is null (lagStale/corr_junk) use catch-up leadDollars. Never a fake 5–15s. */
export function lagSignedDollars(obs: {
  lagDollars?: number | null;
  leadDollars?: number | null;
  lagReason?: string | null;
}): number | null {
  const tau = finiteNonZeroDollar(obs.lagDollars);
  if (tau != null) return tau;
  return finiteNonZeroDollar(obs.leadDollars);
}

/**
 * Price- and time-conditioned win-rate estimate for Basis Lag Edge.
 *
 * Purely price+time (Kelly/EV callers only pass entryPriceCents + minutesLeft).
 * p is NOT evaluate() confidence, NOT the 0.75 prior, NOT paper 1W/9L.
 * Live BOT-only census: n=62, 26W, 41.9% WR, avg 42.55¢, 100% ≤55, 0% ≥70,
 * fee-net +$31. Raw 41.9% at 42¢ is fee-net ~0 before the 3¢ floor — using
 * that as p would starve the cheap money cell. Curve is shrunk toward the
 * tape vs the old 0.62-that-tracked-confidence, still high enough that a
 * 42¢ preferred-window ticket can clear EV 3¢ after fee+slip. Richer asks
 * fall through 0.50 so EV skips them honestly (the live book never bought ≥70).
 */
export function basisLagWinRate(entryPriceCents: number, minutesLeft: number): number {
  const BASE_WR  = 0.55;
  const FLOOR_WR = 0.40;

  let wr: number;
  if (entryPriceCents <= 40) {
    wr = BASE_WR;
  } else if (entryPriceCents <= 55) {
    const t = (entryPriceCents - 40) / 15;
    wr = BASE_WR - t * 0.05; // 0.55 → 0.50  (live 100% ≤55)
  } else {
    const t = Math.min(1, (entryPriceCents - 55) / 20);
    wr = 0.50 - t * 0.10; // 0.50 → 0.40
  }

  if (minutesLeft >= 10) {
    wr -= 0.03;
  } else if (minutesLeft <= 6) {
    wr += 0.01;
  }

  return Math.max(FLOOR_WR, Math.min(0.58, wr));
}

function logBasisLagEval(entry: {
  outcome:     "FIRED" | "BLOCKED" | "PAPER_PROCEED";
  reasonCode:  string;
  reason:      string;
  obs:         StrategyObservation;
  proj?:       number;
  projDistPct?: number;
  sideAsk?:    number;
  edgePts?:    number;
  netEV?:      number;
}): void {
  const lead        = entry.obs.basisExchangePrice;
  const proxy       = entry.obs.basisProxyPrice;
  const basis       = entry.obs.rollingBasis;
  const floorStrike = entry.obs.floorStrike;
  const streakSign  = entry.obs.basisStreakSign ?? 0;
  const streakCount = entry.obs.basisStreakCount ?? 0;
  const icon        = entry.outcome === "FIRED" ? "🎯" : entry.outcome === "PAPER_PROCEED" ? "📝" : "⏸️";

  console.log(
    `[basis-lag] ${icon} ${entry.outcome} (${entry.reasonCode}) · ` +
    `lead=${lead !== undefined ? "$" + lead.toFixed(0) : "n/a"} · ` +
    `proxy=${proxy !== undefined ? "$" + proxy.toFixed(0) : "n/a"} · ` +
    `basis=${basis !== undefined ? (basis >= 0 ? "+" : "") + basis.toFixed(2) : "n/a"} · ` +
    `floor=${floorStrike !== undefined && floorStrike > 0 ? "$" + floorStrike.toFixed(0) : "n/a"} · ` +
    `projected=${entry.proj !== undefined ? "$" + entry.proj.toFixed(0) : "n/a"} · ` +
    `dist=${entry.projDistPct !== undefined ? entry.projDistPct.toFixed(3) + "%" : "n/a"} · ` +
    `streak=${streakSign >= 0 ? "+" : ""}${streakSign}×${streakCount} · ` +
    `ask=${entry.sideAsk !== undefined ? entry.sideAsk + "c" : "n/a"} · ` +
    `edge=${entry.edgePts !== undefined ? entry.edgePts.toFixed(0) + "pt" : "n/a"} · ` +
    `estEV=${entry.netEV !== undefined ? entry.netEV.toFixed(2) + "c" : "n/a"} · ${entry.reason}`,
  );
}

/**
 * BASIS_LAG_EDGE evaluate. strategy-library.ts is a caller.
 * p for the winRateAtPrice curve is basisLagWinRate, never confidence.
 * Local EV still uses the same computeTradeEV as PATH_GATE.
 */

export function evaluateBasisLagEdge(obs: StrategyObservation): StrategyResult | null {
  const minLeft = obs.secsRemaining / 60;

  // Hard time bounds — never traded outside this window regardless of
  // edge size (matches the metadata minTimeMins/maxTimeMins consumed
  // elsewhere: Bayesian prior warm-start, consensus weighting).
  if (minLeft < BASIS_LAG_MIN_TIME_MINS || minLeft > BASIS_LAG_MAX_TIME_MINS) return null;
  if (isStrikePinNoEnter({ ohlc1m: obs.ohlc1m, ohlc5m: obs.ohlc5m, floor: obs.floorStrike })) {
    logBasisLagEval({ outcome: "BLOCKED", reasonCode: "STRIKE_PIN", reason: "STRIKE_PIN no-enter last 3m hug + HA mixed", obs });
    return null;
  }

  // Catch-up proof: paper=live via classifyLagUnprovenGate (never fake 5–15s).
  // ORIGINAL_LOCK / unproven skip both modes. LAG ≤55 only when proven.
  // corr_junk no fill. Analog HA/CC same-sign required in evaluate.
  const paperRestore = obs.paperMode === true;
  const yAsk0 = obs.yesAsk;
  const nAsk0 = obs.noAsk;
  const yOk0 = typeof yAsk0 === "number" && Number.isFinite(yAsk0);
  const nOk0 = typeof nAsk0 === "number" && Number.isFinite(nAsk0);
  const knownAsk = yOk0 && nOk0 ? Math.min(yAsk0, nAsk0) : yOk0 ? yAsk0 : nOk0 ? nAsk0 : undefined;
  const lagGate0 = classifyLagUnprovenGate({
    lagProven: obs.lagProven,
    lagStale: obs.lagStale,
    leadSeconds: obs.leadSeconds,
    leadDollars: obs.leadDollars,
    proofHitRate: obs.proofHitRate,
    sideAsk: knownAsk,
    lagDollars: obs.lagDollars,
    lagReason: obs.lagReason,
    paperMode: paperRestore,
  });
  if (lagGate0.kind === "ORIGINAL_LOCK") {
    logBasisLagEval({
      outcome: "BLOCKED",
      reasonCode: "LAG_UNPROVEN",
      reason: lagGate0.reason,
      obs,
    });
    return null;
  }

  const liveProj = liveLagProjectedSettlement(obs);
  const canon = canonicalLagProjectedSettlement({
    liveProj,
    snapshotProj: obs.projectedSettlementPrice,
    floor: obs.floorStrike,
  });
  if (canon.splitBrain) {
    logBasisLagEval({
      outcome: "BLOCKED", reasonCode: "PROJ_SPLIT_BRAIN",
      reason: `live proj ${liveProj} vs snapshot ${obs.projectedSettlementPrice} disagree vs floor ${obs.floorStrike} — fail-closed skip`,
      obs, proj: liveProj, projDistPct: 0,
    });
    return null;
  }
  const proj = canon.proj;
  if (proj === undefined || obs.floorStrike <= 0) {
    logBasisLagEval({ outcome: "BLOCKED", reasonCode: "NO_PROJECTION", reason: "no projected settlement price yet", obs });
    return null;
  }

  // Projection must sit clearly on one side of the floor — near-zero
  // distance means the contract is a coinflip and there's no basis edge.
  const projDistPct = ((proj - obs.floorStrike) / obs.floorStrike) * 100;
  if (Math.abs(projDistPct) < BASIS_LAG_MIN_PROJ_DIST_PCT) {
    logBasisLagEval({ outcome: "BLOCKED", reasonCode: "FLAT_PROJECTION", reason: `projection ${projDistPct.toFixed(3)}% from floor — coinflip, no edge`, obs, proj, projDistPct });
    return null;
  }

  let isLong = projDistPct > 0;
  let signal: TradeSignal = isLong ? "YES" : "NO";
  // MTF-aligned cheap (ENTRY 20, <=55) can flip the traded side. Analog HA/CC
  // same-sign vs that side is still required. MTF_FILTER KEEP on opposed.
  const alignedTake = isMtfAlignedCheapTake({
    mtfScore: obs.mtfScore,
    yesAsk: obs.yesAsk,
    noAsk: obs.noAsk,
    minAskCents: 20,
    maxAskCents: LAG_CHEAP_ASK_CENTS,
    spot: obs.currentPrice,
    floorStrike: obs.floorStrike,
  });
  if (obs.mtfScore != null && Number.isFinite(obs.mtfScore) && obs.mtfScore !== 0) {
    if (!alignedTake) {
      logBasisLagEval({
        outcome: "BLOCKED", reasonCode: "NO_ALIGNED_CHEAP",
        reason: "MTF directed but no aligned cheap (ENTRY 20 / ≤55) — KEEP skip",
        obs, proj, projDistPct,
      });
      return null;
    }
    isLong = alignedTake.side === "yes";
    signal = alignedTake.side === "yes" ? "YES" : "NO";
  } else if (alignedTake && ((alignedTake.side === "yes") !== isLong)) {
    isLong = alignedTake.side === "yes";
    signal = alignedTake.side === "yes" ? "YES" : "NO";
  }
  const haRiverSide = haRiverConfirmSide(obs);
  const ccFactorSide = confluenceFactorBias(obs);
  // MTF lean: when score directed, same sign as traded signal counts as confirm
  // (lag+MTF agree) — do not false LAG_SIDE_DISAGREE on HA/CC sensor lie.
  const mtfSide: "YES" | "NO" | null =
    obs.mtfScore != null && Number.isFinite(obs.mtfScore) && obs.mtfScore !== 0
      ? (obs.mtfScore > 0 ? "YES" : "NO")
      : null;
  const analogAgrees = lagSideConfirmationAgrees({
    projSide: signal, haRiverSide, ccFactorSide, mtfSide,
  });
  // Proven cheap = HA or CC or MTF same sign as proj. Unproven analog skip.
  if (!analogAgrees) {
    logBasisLagEval({
      outcome: "BLOCKED", reasonCode: "LAG_SIDE_DISAGREE",
      reason: `proj ${signal} vs HA ${haRiverSide ?? "none"} / CC ${ccFactorSide ?? "none"} / MTF ${mtfSide ?? "none"} — unproven skip (HA or CC or MTF same sign required, never fake 5–15s)`,
      obs, proj, projDistPct,
    });
    return null;
  }
  const sideAsk = isLong ? obs.yesAsk : obs.noAsk;
  if (sideAsk === undefined) {
    logBasisLagEval({ outcome: "BLOCKED", reasonCode: "NO_QUOTE", reason: "no live ask for this side", obs, proj, projDistPct });
    return null;
  }
  const lagGate = classifyLagUnprovenGate({
    lagProven: obs.lagProven,
    lagStale: obs.lagStale,
    leadSeconds: obs.leadSeconds,
    leadDollars: obs.leadDollars,
    proofHitRate: obs.proofHitRate,
    sideAsk,
    side: isLong ? "yes" : "no",
    lagDollars: obs.lagDollars,
    lagReason: obs.lagReason,
    paperMode: paperRestore,
  });
  if (!lagGate.proceed) {
    logBasisLagEval({
      outcome: "BLOCKED",
      reasonCode: lagGate.reasonCode,
      reason: lagGate.reason,
      obs, proj, projDistPct, sideAsk,
    });
    return null;
  }
  if (sideAsk >= BASIS_LAG_FULLY_PRICED_ASK) {
    logBasisLagEval({ outcome: "BLOCKED", reasonCode: "FULLY_PRICED", reason: `${sideAsk}c ask already ≥${BASIS_LAG_FULLY_PRICED_ASK}c — fully repriced, no edge left`, obs, proj, projDistPct, sideAsk });
    return null; // already repriced — no edge left
  }

  const lagSide: "yes" | "no" = signal === "YES" ? "yes" : "no";
  const lagD = lagSignedDollars(obs);
  // KEEP lag_disagrees when lagStale==false and live lag$ fights thesis (paper+live).
  if (obs.lagStale === false && lagD != null && Number.isFinite(lagD) && !lagAgreesWithSide(lagSide, lagD, {
    proven: obs.lagProven === true,
    stale: false,
  })) {
    logBasisLagEval({
      outcome: "BLOCKED", reasonCode: "LAG_DISAGREES",
      reason: `lagDollars ${lagD} disagrees with ${signal} (Coinbase tau or corr_junk catch-up $, not 1s proj)`,
      obs, proj, projDistPct, sideAsk,
    });
    return null;
  }
  // Paper≡live (2026-09-11): $16 lag floor BOTH modes — no paperRestore magnitude cheat.
  const minAbs = paperMoneyMakerLagMinAbsDollars(obs.paperMode, BASIS_LAG_STRATEGY_ID);
  if (lagD == null || !Number.isFinite(lagD) || Math.abs(lagD) < minAbs) {
    logBasisLagEval({
      outcome: "BLOCKED", reasonCode: "LAG_DOLLARS_TOO_SMALL",
      reason: `|lagDollars| ${lagD} < $${minAbs}`,
      obs, proj, projDistPct, sideAsk,
    });
    return null;
  }

  // Persistence guard: require the basis to have been on the SAME side
  // for several DISTINCT exchange samples, not a single noisy tick. Uses
  // basisTracker's basisStreakCount (advances only on a new exchange
  // price, immune to the 500ms tick / 2.5s exchange-cache mismatch).
  const streakSign  = obs.basisStreakSign ?? 0;
  const streakCount = obs.basisStreakCount ?? 0;
  const wantSign: 1 | -1 = isLong ? 1 : -1; // exchange above proxy → long lag; below → short lag
  const persistent = streakSign === wantSign && streakCount >= BASIS_LAG_MIN_STREAK_TICKS;
  if (!persistent) {
    logBasisLagEval({
      outcome: "BLOCKED", reasonCode: "NOT_PERSISTENT",
      reason: `basis streak ${streakSign >= 0 ? "+" : ""}${streakSign}×${streakCount} — need ${wantSign}×${BASIS_LAG_MIN_STREAK_TICKS}+ (not a 1-tick spike)`,
      obs, proj, projDistPct, sideAsk,
    });
    return null;
  }

  // Coarse probability read implied by the projection's distance from
  // the floor — deliberately approximate (this is a mispricing screen,
  // not a pricing model); scaled so a typical few-hundredths-of-a-percent
  // basis lag reads as a double-digit point gap.
  // P(our side settles): sign of projDistPct picks YES vs NO; magnitude is the edge.
  const impliedProb = clamp(50 + Math.abs(projDistPct) * 300, 5, 95);
  const edgePts = impliedProb - sideAsk;

  // P4 LiquidityPolicy Part C: BASIS_LAG_EDGE's edge is netted against
  // the live spread BEFORE the edge floor check below — a real edge that
  // the spread has already eaten isn't tradeable. Rule 1 (stale/missing
  // book) still fail-closes here too, ahead of the edge check, since a
  // book we can't trust means we can't trust the netting either. This is
  // ADDITIONAL to (never a replacement for) the general per-family
  // haircut applied downstream in trading-bot.ts's order-placement path
  // — that call re-evaluates the same book independently for sizeMult.
  let edgePtsForGate = edgePts;
  let spreadPenaltyCents = 0;
  const liqBook = obs.liquidityBook?.[signal];
  if (liqBook) {
    const liqVerdict = evaluateLiquidity({ family: "lag", book: liqBook, volScale: obs.volScale });
    logLiquidityDecision({
      strategyId: BASIS_LAG_STRATEGY_ID, family: "lag", side: signal,
      spreadCents: liqBook.spreadCents, depthAtAsk: liqBook.depthAtAsk, imbalance: liqBook.imbalance,
      bookAgeMs: liqBook.bookAgeMs, action: liqVerdict.action, sizeMult: liqVerdict.sizeMult, reason: liqVerdict.reason,
    });
    if (liqVerdict.action === "SKIP") {
      logBasisLagEval({
        outcome: "BLOCKED", reasonCode: liqVerdict.reason,
        reason: `liquidity policy SKIP (${liqVerdict.reason}): ${liqVerdict.detail}`,
        obs, proj, projDistPct, sideAsk, edgePts,
      });
      return null;
    }
    spreadPenaltyCents = liqVerdict.spreadPenaltyCents;
    edgePtsForGate = computeLagNetEdgePts(edgePts, spreadPenaltyCents);
  }

  // Require a meaningful, still-unpriced gap between what the
  // exchange-led projection implies and what Kalshi currently charges.
  // Graduated: once the side is already fairly expensive (≥80c), most of
  // a small edge is likely noise/already-priced — demand a bigger gap.
  const MIN_EDGE_PTS = sideAsk >= BASIS_LAG_RICH_ASK_CENTS ? BASIS_LAG_RICH_MIN_EDGE_PTS : BASIS_LAG_MIN_EDGE_PTS;
  if (edgePtsForGate < MIN_EDGE_PTS) {
    logBasisLagEval({
      outcome: "BLOCKED", reasonCode: "EDGE_TOO_SMALL",
      reason: `${edgePtsForGate.toFixed(0)}pt net edge (raw ${edgePts.toFixed(0)}pt - ${spreadPenaltyCents.toFixed(0)}pt spread) < ${MIN_EDGE_PTS}pt floor (ask ${sideAsk}c, implied ~${impliedProb.toFixed(0)}c)`,
      obs, proj, projDistPct, sideAsk, edgePts,
    });
    return null;
  }

  // Preferred window is the final 3-10 minutes; outside that (but
  // still inside the hard 2-15 min bounds above) only trade when the
  // edge is large enough to be worth the extra time for it to close
  // against us — "don't hard-lock if the edge is large" per spec.
  const outsidePreferredWindow = minLeft < BASIS_LAG_PREFERRED_MIN || minLeft > BASIS_LAG_PREFERRED_MAX;
  if (outsidePreferredWindow && edgePts < BASIS_LAG_LARGE_EDGE_PTS) {
    logBasisLagEval({
      outcome: "BLOCKED", reasonCode: "OUTSIDE_WINDOW",
      reason: `${minLeft.toFixed(1)}m left is outside preferred ${BASIS_LAG_PREFERRED_MIN}-${BASIS_LAG_PREFERRED_MAX}m window and edge ${edgePts.toFixed(0)}pt < ${BASIS_LAG_LARGE_EDGE_PTS}pt required to extend it`,
      obs, proj, projDistPct, sideAsk, edgePts,
    });
    return null;
  }

  // Heuristic confidence for StrategyResult only — never p, never local EV.
  // p = winRateAtPrice at the traded ask (basisLagWinRate). Do not boost conf into EV.
  // conf ≠ p: do not start from basisLagWinRate (18¢ ≥10m p=0.52 starved the 0.55 selector).
  // Do not floor conf to 0.55 as a bandage — selector keeps CC/LAG fires below 0.55.
  const conf = basisLagEvidenceConfidence({
    edgePts,
    minEdgePts: MIN_EDGE_PTS,
    rollingBasis: obs.rollingBasis,
    basisShort: obs.basisShort,
    isLong,
    streakCount,
  });
  const pWin = basisLagWinRate(sideAsk, minLeft);

  // Local fee+slippage-aware EV check — the SAME computeTradeEV() used
  // by PATH_GATE (trade-path.ts), so this can never diverge from or
  // loosen the shared EV math. This is an ADDITIONAL, stricter guard on
  // top of the bot's global EV floor / regime-EV filter, not a
  // replacement for either. winRate is p=winRateAtPrice, never confidence.
  const sideBid = isLong ? obs.yesBid : obs.noBid;
  const spreadCents = sideBid !== undefined ? sideAsk - sideBid : undefined;
  const evResult = computeTradeEV({
    entryPriceCents:    sideAsk,
    winRate:            pWin,
    strategyId:         BASIS_LAG_STRATEGY_ID,
    secsRemaining:      obs.secsRemaining,
    velocityDolPerMin:  obs.velocityDolPerMin,
    spreadCents,
  });
  if (evResult.netEV <= 0) {
    logBasisLagEval({
      outcome: "BLOCKED", reasonCode: "NEGATIVE_EV",
      reason: `netEV ${evResult.netEV.toFixed(2)}c ≤ 0 after ${evResult.feeCents.toFixed(1)}c fee + ${evResult.slippageCents.toFixed(1)}c slippage`,
      obs, proj, projDistPct, sideAsk, edgePts, netEV: evResult.netEV,
    });
    return null;
  }

  logBasisLagEval({
    outcome: "FIRED", reasonCode: "FIRED",
    reason: `${signal} @ ${sideAsk}c, ${edgePts.toFixed(0)}pt edge, streak ${streakSign >= 0 ? "+" : ""}${streakSign}×${streakCount}`,
    obs, proj, projDistPct, sideAsk, edgePts, netEV: evResult.netEV,
  });

  return {
    signal,
    confidence: conf,
    strategyId: BASIS_LAG_STRATEGY_ID,
    strategyName: BASIS_LAG_STRATEGY_NAME,
    edgePct: edgePts / 100,
    reason: `Basis lag: projected settlement ${proj.toFixed(0)} vs floor ${obs.floorStrike.toFixed(0)} (${projDistPct.toFixed(2)}%), ${sideAsk}c ask vs ~${impliedProb.toFixed(0)}c implied — ${edgePts.toFixed(0)}pt unpriced edge, streak ${streakSign >= 0 ? "+" : ""}${streakSign}×${streakCount}, netEV ${evResult.netEV.toFixed(1)}c`,
    earlyExitRule: "Exit if the projected settlement price crosses back to the other side of the floor, or the basis mispricing closes to under 3 points — the edge that justified this trade is gone.",
  };
}
