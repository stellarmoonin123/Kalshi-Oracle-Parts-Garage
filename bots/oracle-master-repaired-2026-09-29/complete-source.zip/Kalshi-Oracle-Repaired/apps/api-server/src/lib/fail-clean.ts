/**
 * fail-clean.ts — HTTP error bodies for Chat/UI.
 *
 * Never put err.message / err.stack / String(err) in a response.
 * Log the real error; send a generic client string.
 * paperMode / EV / Kelly / leftovers unchanged.
 */
import type { Response } from "express";
import { logger } from "./logger.js";

export function logCaught(clientError: string, err: unknown): void {
  logger.error({ err }, clientError);
}

/** Generic JSON error. extra must not include `detail` from Error.message. */
export function failClean(
  res: Response,
  status: number,
  clientError: string,
  err: unknown,
  extra: Record<string, unknown> = {},
): Response {
  logCaught(clientError, err);
  const { detail: _drop, ...rest } = extra;
  void _drop;
  return res.status(status).json({ error: clientError, ...rest });
}
