import assert from "node:assert/strict";
import test from "node:test";
import {
  BOUNCE_LOG_MAX_BYTES,
  TRACE_JSONL_MAX_BYTES,
  isProtectedLedgerPath,
  rotateDecision,
  shouldRotateBySize,
} from "./log-rotate-policy.js";

test("log-rotate-policy: bounce/trace caps are finite and positive", () => {
  assert.ok(BOUNCE_LOG_MAX_BYTES >= 8 * 1024 * 1024);
  assert.ok(TRACE_JSONL_MAX_BYTES >= 16 * 1024 * 1024);
});

test("log-rotate-policy: never rotate paper / frozen ledger", () => {
  assert.equal(isProtectedLedgerPath("/x/data/frozen-cc-ledger.jsonl"), true);
  assert.equal(isProtectedLedgerPath("paper-ledger.jsonl"), true);
  assert.equal(rotateDecision("/x/data/frozen-cc-ledger.jsonl", 9e12, 1), "refuse_protected");
  assert.equal(rotateDecision("/tmp/api-server-bounce.log", BOUNCE_LOG_MAX_BYTES + 1, BOUNCE_LOG_MAX_BYTES), "rotate");
  assert.equal(rotateDecision("/x/evaluate-decision-trace.jsonl", 100, TRACE_JSONL_MAX_BYTES), "keep");
});

test("log-rotate-policy: shouldRotateBySize edge cases", () => {
  assert.equal(shouldRotateBySize(0, 10), false);
  assert.equal(shouldRotateBySize(11, 10), true);
  assert.equal(shouldRotateBySize(NaN, 10), false);
});
