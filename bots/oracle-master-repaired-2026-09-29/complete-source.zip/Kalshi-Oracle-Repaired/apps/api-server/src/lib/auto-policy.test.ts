import { test } from "node:test";
import assert from "node:assert/strict";
import {
  DEFAULT_AUTO_POLICY_PARAMS, applyAutoPolicyOverlay, defaultBoundsFor, derivePolicy, judgeFill,
  marketStateFromRegime, normalizeBounds, normalizeMode, policySizeMult, stateIdFor, summarizeShadow,
  type EvidenceRow, type ShadowRow,
} from "./auto-policy.js";

const NOW = 1_800_000_000_000;
const baseline = { minConfidence: 55, minEntryPrice: 28, maxEntryPrice: 70 };
const bounds = defaultBoundsFor(baseline);

function row(p: Partial<EvidenceRow> & { pnlCents: number }): EvidenceRow {
  return {
    strategyId: "CONFLUENCE_CASCADE", regime: "range", volumeBucket: "NORMAL", entryPriceCents: 50,
    confidence: 62, contracts: 1, outcome: p.pnlCents > 0 ? "win" : "loss",
    settledAtMs: NOW - 3_600_000, isPaper: true, ...p,
  };
}
function many(n: number, p: Partial<EvidenceRow> & { pnlCents: number }): EvidenceRow[] {
  return Array.from({ length: n }, (_, i) => row({ settledAtMs: NOW - (i + 1) * 600_000, ...p }));
}
/** Mixed outcomes with a given win rate so the variance is realistic. */
function mixed(n: number, winRate: number, p: Partial<EvidenceRow> = {}): EvidenceRow[] {
  return Array.from({ length: n }, (_, i) =>
    row({ ...p, pnlCents: i / n < winRate ? 45 : -55, settledAtMs: NOW - (i + 1) * 600_000 }));
}

test("regime collapse: 10 regimes → 6 states, unknown → UNCLEAR", () => {
  assert.equal(marketStateFromRegime("breakout_up"), "TREND");
  assert.equal(marketStateFromRegime("fakeout"), "REVERSAL");
  assert.equal(marketStateFromRegime("squeeze"), "SQUEEZE");
  assert.equal(marketStateFromRegime(null), "UNCLEAR");
  assert.equal(stateIdFor("range", "DEAD"), "RANGE/THIN");
  assert.equal(stateIdFor("range", "HIGH"), "RANGE/OK");
});

test("no evidence → policy keeps every operator value and sizes small", () => {
  const p = derivePolicy([], baseline, bounds, DEFAULT_AUTO_POLICY_PARAMS, NOW);
  const s = p.states["RANGE/OK"];
  assert.equal(s.level, "none");
  assert.equal(s.minConfidence, null);
  assert.equal(s.minEntryPrice, null);
  assert.deepEqual(s.suppressStrategies, []);
  assert.equal(s.sizeMult, bounds.sizeMult[0]);
  // live overlay is a no-op on thresholds when nothing is known
  const eff = { minConfidence: 55, minEntryPrice: 28, maxEntryPrice: 70, disabledStrategies: [] as string[] };
  const out = applyAutoPolicyOverlay(eff, p, "RANGE/OK", "live");
  assert.deepEqual(out.applied, []);
});

test("a strategy that loses with enough evidence in a state is suppressed only there", () => {
  const rows = [
    ...mixed(30, 0.25, { strategyId: "LOSER", regime: "squeeze" }),
    ...mixed(30, 0.70, { strategyId: "LOSER", regime: "strong_uptrend" }),
    ...mixed(40, 0.65, { strategyId: "CONFLUENCE_CASCADE", regime: "squeeze" }),
  ];
  const p = derivePolicy(rows, baseline, bounds, DEFAULT_AUTO_POLICY_PARAMS, NOW);
  assert.deepEqual(p.states["SQUEEZE/OK"].suppressStrategies, ["LOSER"]);
  assert.deepEqual(p.states["TREND/OK"].suppressStrategies, []);
  const eff = { minConfidence: 55, minEntryPrice: 28, maxEntryPrice: 70, disabledStrategies: ["X"] };
  const live = applyAutoPolicyOverlay(eff, p, "SQUEEZE/OK", "live");
  assert.ok(live.eff.disabledStrategies.includes("LOSER"));
  assert.ok(live.eff.disabledStrategies.includes("X"));
  const shadow = applyAutoPolicyOverlay(eff, p, "SQUEEZE/OK", "shadow");
  assert.deepEqual(shadow.applied, [], "shadow never writes");
});

test("minConfidence rises to the lowest band whose fills clear zero, within bounds", () => {
  // Low-confidence fills lose, high-confidence fills win.
  const rows = [
    ...mixed(30, 0.30, { confidence: 57 }),
    ...mixed(30, 0.75, { confidence: 66 }),
  ];
  const p = derivePolicy(rows, baseline, bounds, DEFAULT_AUTO_POLICY_PARAMS, NOW);
  const s = p.states["RANGE/OK"];
  assert.equal(s.level, "state");
  // Floor 60 already excludes the 57-confidence losers, so 60 is the lowest band that clears zero.
  assert.equal(s.minConfidence, 60);
  assert.ok(s.sizeMult > bounds.sizeMult[0], "positive edge → size above floor");
  const eff = { minConfidence: 55, minEntryPrice: 28, maxEntryPrice: 70, disabledStrategies: [] as string[] };
  const out = applyAutoPolicyOverlay(eff, p, "RANGE/OK", "live");
  assert.equal(out.eff.minConfidence, 60);
  // bounds cap: a tight operator ceiling wins
  const tight = derivePolicy(rows, baseline, { ...bounds, minConfidence: [55, 58] }, DEFAULT_AUTO_POLICY_PARAMS, NOW);
  assert.equal(tight.states["RANGE/OK"].minConfidence, 58);
});

test("everything loses → the strategy itself is suppressed; operator window kept, smallest size", () => {
  const p = derivePolicy(mixed(60, 0.2), baseline, bounds, DEFAULT_AUTO_POLICY_PARAMS, NOW);
  const s = p.states["RANGE/OK"];
  assert.deepEqual(s.suppressStrategies, ["CONFLUENCE_CASCADE"]);
  assert.equal(s.minEntryPrice, null);
  assert.equal(s.sizeMult, bounds.sizeMult[0]);
});

test("two strategies, one mediocre: confidence goes to the most restrictive bound when nothing clears zero", () => {
  // 50/50 at 45/-55 payoffs is fee-negative but not confidently so with n=30 → not suppressed, nothing clears zero.
  const p = derivePolicy(mixed(30, 0.5), baseline, bounds, DEFAULT_AUTO_POLICY_PARAMS, NOW);
  const s = p.states["RANGE/OK"];
  assert.deepEqual(s.suppressStrategies, []);
  assert.equal(s.minConfidence, bounds.minConfidence[1]);
});

test("entry window narrows to the ask bands with positive evidence", () => {
  const rows = [
    ...mixed(20, 0.75, { entryPriceCents: 40 }),
    ...mixed(20, 0.72, { entryPriceCents: 52 }),
    ...mixed(20, 0.20, { entryPriceCents: 68 }),
  ];
  const p = derivePolicy(rows, baseline, bounds, DEFAULT_AUTO_POLICY_PARAMS, NOW);
  const s = p.states["RANGE/OK"];
  assert.equal(s.minEntryPrice, 36);
  assert.equal(s.maxEntryPrice, 55);
  // Confidence is judged on the in-window fills, which win ~73% → floor stays at the operator's 55.
  assert.equal(s.minConfidence, 55);
  const v = judgeFill(p, { strategyId: "CONFLUENCE_CASCADE", regime: "range", volumeBucket: "NORMAL", confidence: 62, entryPriceCents: 68 }, baseline);
  assert.equal(v.wouldBlock, true);
  assert.ok(v.reasons.some(r => /outside 36-55/.test(r)), v.reasons.join("|"));
  const ok = judgeFill(p, { strategyId: "CONFLUENCE_CASCADE", regime: "range", volumeBucket: "NORMAL", confidence: 62, entryPriceCents: 48 }, baseline);
  assert.equal(ok.wouldBlock, false);
});

test("thin state borrows from its market, then from global", () => {
  const rows = mixed(30, 0.7, { regime: "range", volumeBucket: "NORMAL" });
  const p = derivePolicy(rows, baseline, bounds, DEFAULT_AUTO_POLICY_PARAMS, NOW);
  assert.equal(p.states["RANGE/THIN"].level, "market");
  assert.equal(p.states["TREND/OK"].level, "global");
  assert.equal(p.states["RANGE/OK"].level, "state");
});

test("stale fills fall out of the lookback; paper can be excluded", () => {
  const old = many(40, { pnlCents: 40, settledAtMs: NOW - 100 * 86_400_000 });
  assert.equal(derivePolicy(old, baseline, bounds, DEFAULT_AUTO_POLICY_PARAMS, NOW).totalRows, 0);
  const paper = mixed(30, 0.7);
  const p = derivePolicy(paper, baseline, bounds, { ...DEFAULT_AUTO_POLICY_PARAMS, includePaper: false }, NOW);
  assert.equal(p.totalRows, 0);
});

test("size multiplier respects bounds and never exceeds 1 by default", () => {
  const p = derivePolicy(many(80, { pnlCents: 60 }), baseline, bounds, DEFAULT_AUTO_POLICY_PARAMS, NOW);
  assert.equal(policySizeMult(p, "RANGE/OK", "live"), 1);
  assert.equal(policySizeMult(p, "RANGE/OK", "shadow"), 1, "shadow never sizes");
  assert.equal(policySizeMult(null, "RANGE/OK", "live"), 1);
});

test("shadow scoreboard: blocked losers show up as uplift", () => {
  const verdictBlock = { stateId: "RANGE/OK", level: "state" as const, wouldBlock: true, reasons: ["x"], sizeMult: 0.8, policyComputedAtMs: NOW };
  const verdictAllow = { ...verdictBlock, wouldBlock: false, reasons: [] };
  const base = { kind: "CLOSE" as const, ts: NOW, mode: "shadow" as const, ticker: "T", strategyId: "CC", side: "yes" as const, askCents: 50, contracts: 1, exitReason: "SETTLEMENT", isPaper: true };
  const rows: ShadowRow[] = [
    { ...base, outcome: "loss", pnlCents: -50, verdict: verdictBlock },
    { ...base, outcome: "win", pnlCents: 100, verdict: verdictAllow },
    { ...base, outcome: "loss", pnlCents: -60, verdict: verdictBlock },
  ];
  const sb = summarizeShadow(rows);
  assert.equal(sb.closes, 3);
  assert.equal(sb.baselinePnlCents, -10);
  assert.equal(sb.blocked.pnlCents, -110);
  assert.equal(sb.policyPnlCents, 80);
  assert.equal(sb.upliftCents, 90);
  assert.equal(sb.byState["RANGE/OK"].blocked, 2);
});

test("bounds/mode normalization refuses garbage", () => {
  const b = normalizeBounds({ minConfidence: [90, 50], entryPrice: "x", sizeMult: [0, 9] }, baseline);
  assert.deepEqual(b.minConfidence, [50, 90]);
  assert.deepEqual(b.entryPrice, [28, 70]);
  assert.deepEqual(b.sizeMult, [0.1, 1.5]);
  assert.equal(normalizeMode("live"), "live");
  assert.equal(normalizeMode("bounded_write"), "off");
});
