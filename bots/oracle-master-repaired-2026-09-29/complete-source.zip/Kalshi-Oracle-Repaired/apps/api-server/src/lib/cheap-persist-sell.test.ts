import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  CHEAP_PERSIST_ASK_MAX_CENTS,
  CHEAP_PERSIST_ASK_MIN_CENTS,
  CHEAP_PERSIST_EV_FLOOR_CENTS,
  CHEAP_PERSIST_SELL_ENABLED_DEFAULT,
  LIVE_APPLY,
  LIVE_APPLY_ENABLED,
  PAPER_MODE,
  isCheapPersistSellDualGateOpen,
  shouldCheapPersistSellTake,
} from "./cheap-persist-sell.js";

const LIB = path.dirname(fileURLToPath(import.meta.url));

function base(overrides: Partial<Parameters<typeof shouldCheapPersistSellTake>[0]> = {}) {
  return {
    side: "no" as const,
    askCents: 30,
    secsRemaining: 400,
    msOnSideOfFloor: 15_000,
    evCents: 4,
    enabled: true,
    ...overrides,
  };
}

test("locks: ENABLE false, LIVE_APPLY false, paperMode true", () => {
  assert.equal(LIVE_APPLY, false);
  assert.equal(LIVE_APPLY_ENABLED, false);
  assert.equal(PAPER_MODE, true);
  assert.equal(CHEAP_PERSIST_SELL_ENABLED_DEFAULT, false);
  assert.equal(isCheapPersistSellDualGateOpen(undefined), false);
});

test("dual-gate closed", () => {
  assert.equal(shouldCheapPersistSellTake(base({ enabled: false })).reason, "dual_gate_closed");
});

test("band 22–47, EV 3, persist 15s", () => {
  assert.equal(CHEAP_PERSIST_ASK_MIN_CENTS, 20);
  assert.equal(CHEAP_PERSIST_ASK_MAX_CENTS, 47);
  assert.equal(CHEAP_PERSIST_EV_FLOOR_CENTS, 3);
  assert.equal(shouldCheapPersistSellTake(base()).take, true);
  assert.equal(shouldCheapPersistSellTake(base({ askCents: 48 })).reason, "ask_not_7_22");
  assert.equal(shouldCheapPersistSellTake(base({ evCents: 2.99 })).reason, "ev_lt_3");
  assert.equal(shouldCheapPersistSellTake(base({ msOnSideOfFloor: 1000 })).reason, "persist_lt_15s");
});

test("lottery 7–12 last 150s skip (band rejects first under desk door 20)", () => {
  // Desk door min 20 — lottery 7–12 never reaches lottery reason; band skips first.
  assert.equal(shouldCheapPersistSellTake(base({ askCents: 10, secsRemaining: 100 })).reason, "ask_not_7_22");
});

test("NOT wired into TradingBot", () => {
  const bot = fs.readFileSync(path.join(LIB, "trading-bot.ts"), "utf8");
  assert.equal(bot.includes("shouldCheapPersistSellTake"), false);
  assert.equal(bot.includes("cheap-persist-sell"), false);
});
