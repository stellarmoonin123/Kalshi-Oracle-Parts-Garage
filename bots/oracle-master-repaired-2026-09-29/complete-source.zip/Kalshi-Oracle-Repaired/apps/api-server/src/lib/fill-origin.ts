/**
 * fill-origin.ts
 *
 * Bot vs manual fill tagging. Overall P&L includes both. Bot WR / learner /
 * Kelly / winRateAtPrice scoring is BOT only — a Kalshi-app MANUAL fill
 * never increments strategy scores.
 *
 * Pure helpers. No trading-bot import.
 */

export const FILL_ORIGIN_BOT = "bot" as const;
export const FILL_ORIGIN_MANUAL = "manual" as const;
export const MANUAL_STRATEGY_ID = "MANUAL";

export type FillOrigin = typeof FILL_ORIGIN_BOT | typeof FILL_ORIGIN_MANUAL;

export function isBotFill(origin: string | null | undefined): boolean {
  if (origin == null || origin === "") return true; // legacy rows are bot
  return origin === FILL_ORIGIN_BOT;
}

export function isManualFill(origin: string | null | undefined): boolean {
  return origin === FILL_ORIGIN_MANUAL;
}

/** Learner / strategy-performance / Kelly empirical WR: bot fills only. */
export function shouldFeedLearner(origin: string | null | undefined, strategyId?: string | null): boolean {
  if (strategyId === MANUAL_STRATEGY_ID) return false;
  return isBotFill(origin);
}

/** Bot WR / winRateAtPrice empirical sample: bot fills only. */
export function includeInBotWinRate(origin: string | null | undefined, strategyId?: string | null): boolean {
  return shouldFeedLearner(origin, strategyId);
}

export const RISK_EXIT_REASONS = new Set([
  "THESIS_BREAK_EXIT",
  "THESIS_BREAK", // PATH_RIDE decideExit bare reason (exitEarly(disp.reason))
  "LAG_FLIP_EXIT",
  "LAG_FLIP", // PATH_RIDE decideExit bare reason
  "TIME_STOP",
  "TIME_STOP_WEAK",
  "TIME_STOP_SMALL_ACCT",
  "HOLD_HARD_FLOOR",
]);

export type ExitClass = "strategy" | "risk_exit";

export function classifyExitClass(exitReason: string | null | undefined): ExitClass {
  return exitReason && RISK_EXIT_REASONS.has(exitReason) ? "risk_exit" : "strategy";
}

/** Display / learner strategy WR. Risk dumps keep PnL but are not strategy losses. */
export function countsTowardStrategyWinRate(exitReason?: string | null): boolean {
  return classifyExitClass(exitReason) === "strategy";
}

export function includeInStrategyWinRate(
  origin: string | null | undefined,
  strategyId?: string | null,
  exitReason?: string | null,
): boolean {
  return includeInBotWinRate(origin, strategyId) && countsTowardStrategyWinRate(exitReason);
}

/** Overall P&L includes bot and manual. */
export function includeInOverallPnl(origin: string | null | undefined): boolean {
  void origin;
  return true;
}

/**
 * Tag a Kalshi fill. Our own order ids (including paper-*) are bot.
 * An unmatched Kalshi order id — or no order id on an unmanaged position —
 * is manual.
 */
export function classifyFillOrigin(opts: {
  kalshiOrderId?: string | null;
  botOrderIds: Iterable<string>;
}): FillOrigin {
  const id = opts.kalshiOrderId;
  if (id == null || id === "") return FILL_ORIGIN_MANUAL;
  if (id.startsWith("paper-")) return FILL_ORIGIN_BOT;
  const known = opts.botOrderIds instanceof Set ? opts.botOrderIds : new Set(opts.botOrderIds);
  return known.has(id) ? FILL_ORIGIN_BOT : FILL_ORIGIN_MANUAL;
}

export interface SettledFillRow {
  fillOrigin?: string | null;
  strategyId?: string | null;
  pnlCents: number | null;
  outcome: string | null;
  exitReason?: string | null;
}

export interface SplitPnl {
  overallPnlCents: number;
  botPnlCents: number;
  botWins: number;
  botLosses: number;
  botWinRate: number;
  manualPnlCents: number;
  manualWins: number;
  manualLosses: number;
}

export function splitSettledPnl(rows: SettledFillRow[]): SplitPnl {
  let overallPnlCents = 0;
  let botPnlCents = 0;
  let botWins = 0;
  let botLosses = 0;
  let manualPnlCents = 0;
  let manualWins = 0;
  let manualLosses = 0;
  for (const r of rows) {
    if (r.outcome !== "win" && r.outcome !== "loss") continue;
    const pnl = r.pnlCents ?? 0;
    overallPnlCents += pnl;
    if (includeInBotWinRate(r.fillOrigin, r.strategyId)) {
      botPnlCents += pnl;
      if (countsTowardStrategyWinRate(r.exitReason)) {
        if (r.outcome === "win") botWins++;
        else botLosses++;
      }
    } else {
      manualPnlCents += pnl;
      if (r.outcome === "win") manualWins++;
      else manualLosses++;
    }
  }
  const botN = botWins + botLosses;
  return {
    overallPnlCents,
    botPnlCents,
    botWins,
    botLosses,
    botWinRate: botN > 0 ? botWins / botN : 0,
    manualPnlCents,
    manualWins,
    manualLosses,
  };
}

/**
 * Paper openTrade is not a Kalshi position. Account-wide recon must compare
 * Kalshi's book to live bot exposure only, otherwise a paper fill would look
 * like a tracked-mismatch against a flat (or manual) Kalshi account.
 */
export function trackedKalshiTradeForAudit(
  trade: { ticker: string; side: "yes" | "no"; contracts: number; paper?: boolean } | null,
): { ticker: string; side: "yes" | "no"; contracts: number } | null {
  if (!trade || trade.paper) return null;
  return { ticker: trade.ticker, side: trade.side, contracts: trade.contracts };
}

export function kalshiPositionToManualIntent(p: { ticker: string; position: number }): {
  ticker: string;
  side: "yes" | "no";
  contracts: number;
  fillOrigin: typeof FILL_ORIGIN_MANUAL;
  strategyId: typeof MANUAL_STRATEGY_ID;
  signal: "LONG" | "SHORT";
} {
  const side: "yes" | "no" = p.position > 0 ? "yes" : "no";
  return {
    ticker: p.ticker,
    side,
    contracts: Math.abs(Math.round(p.position)),
    fillOrigin: FILL_ORIGIN_MANUAL,
    strategyId: MANUAL_STRATEGY_ID,
    signal: side === "yes" ? "LONG" : "SHORT",
  };
}

/**
 * Live Kalshi manuals / unmanaged / unknown must not starve a paper fill.
 * Paper virtualCents is isolated; SAFETY_GATE already ignores live recon in
 * paperMode. placeOrder's one-position helper must do the same, otherwise
 * evaluate-approve-then-skip: PATH_GATE passes, then live manuals block paper.
 * One paper position (openTrade / paper pending) still binds.
 */
export type AccountPositionStatus =
  | "never" | "unknown" | "flat" | "managed" | "tracked-mismatch" | "unmanaged";

export function accountStatusForPaperEntry(opts: {
  paperMode: boolean;
  accountStatus: AccountPositionStatus;
}): AccountPositionStatus {
  return opts.paperMode ? "never" : opts.accountStatus;
}

/**
 * Restart pending hold is book-isolated. Paper only counts isPaper rows;
 * live only counts non-paper (including legacy null). A leftover live
 * pending ticket must not freeze the paper desk.
 */
export function pendingCountsForRestartHold(opts: {
  paperMode: boolean;
  isPaper: boolean | null | undefined;
}): boolean {
  if (opts.paperMode) return opts.isPaper === true;
  return opts.isPaper !== true;
}

/** Live +$50 engines: PATH_GATE EV admits; thesis VALID/BROKEN exits. Not scalp RR. */
export function isMoneyMakerThesisHold(strategyId: string | null | undefined): boolean {
  return strategyId === "CONFLUENCE_CASCADE" || strategyId === "BASIS_LAG_EDGE"
    || strategyId === "HA_RIVER" || strategyId === "HA_FLIP" || strategyId === "TICKET_WAVE";
}

/**
 * Apply a Kalshi balance poll onto paper + live cash fields.
 * NEVER copies Kalshi cash into paper virtualCents / paper peak.
 */
export function applyKalshiBalancePoll(opts: {
  paperMode: boolean;
  paperVirtualCents: number;
  peakCents: number;
  kalshiBalanceCents: number;
}): { paperVirtualCents: number; peakCents: number; kalshiCashCents: number } {
  const kalshiCashCents = Math.round(opts.kalshiBalanceCents);
  if (opts.paperMode) {
    return {
      paperVirtualCents: opts.paperVirtualCents,
      peakCents: opts.peakCents,
      kalshiCashCents,
    };
  }
  return {
    paperVirtualCents: opts.paperVirtualCents,
    peakCents: Math.max(opts.peakCents, kalshiCashCents),
    kalshiCashCents,
  };
}
