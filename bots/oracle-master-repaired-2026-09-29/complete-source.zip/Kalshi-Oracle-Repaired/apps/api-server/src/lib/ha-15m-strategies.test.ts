/**
 * HA_RIVER / HA_FLIP / TICKET_WAVE / NO_CROSS isolated evaluates.
 * HA missing → null. EV floor. Mutual exclusion HA_RIVER > TICKET_WAVE.
 * Leftover CEE/panic/cheapSide stay off.
 */
import assert from "node:assert/strict";
import test from "node:test";
import fs from "node:fs";
import path from "path";
import { fileURLToPath } from "node:url";
import { isLivePaperLedgerCents } from "./paper-ledger.js";
import {
  evaluateHaRiver,
  evaluateHaFlip,
  evaluateTicketWave,
  evaluateNoCross,
  preferHa15mResults,
  peekHaStarveForTests,
  resetHaStarveForTests,
  ohlcSeriesStarved,
} from "./ha-15m-strategies.js";
import {
  evaluateAllStrategies,
  getStrategy,
  type StrategyObservation,
} from "./strategy-library.js";
import { evaluateCheapEarlyExit } from "./cheap-early-exit.js";
import { evaluateCheapSide15m } from "./cheap-side-15m.js";
import { evaluatePanicFade } from "./panic-fade.js";
import { EV_FLOOR } from "./admission.js";
import { loadTestPaperLedger } from "./organs/test-ledger-fixture.js";
import { effectiveDisabledStrategies, PAPER_TIER_A_STRATEGY_IDS } from "./trading-bot.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const LEDGER = loadTestPaperLedger();

function trend(n: number, start: number, step: number): { open: number; high: number; low: number; close: number }[] {
  const bars = [];
  let px = start;
  for (let i = 0; i < n; i++) {
    const open = px;
    const close = px + step;
    bars.push({
      open,
      high: Math.max(open, close) + 2,
      low: Math.min(open, close) - 2,
      close,
    });
    px = close;
  }
  return bars;
}

function base(over: Partial<StrategyObservation> = {}): StrategyObservation {
  const ohlc1m = trend(40, 64_000, 12);
  const ohlc5m = trend(30, 63_500, 40);
  return {
    currentPrice: ohlc1m[ohlc1m.length - 1]!.close,
    floorStrike: 64_000,
    velocityDolPerMin: 40,
    threeMinVelocity: 30,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.8,
    massAboveFloor: 70,
    secsRemaining: 6 * 60,
    contractDurationMins: 15,
    ticker: "KXBTC15M-26SEP020430-15",
    yesAsk: 36,
    yesBid: 34,
    noAsk: 66,
    noBid: 64,
    lagStale: false,
    lagDollars: 25,
    lagProven: true,
    paperMode: true,
    ohlc1m,
    ohlc5m,
    ...over,
  };
}

test("HA missing → null (no fake HA)", () => {
  assert.equal(evaluateHaRiver(base({ ohlc1m: undefined, ohlc5m: undefined })), null);
  assert.equal(evaluateHaFlip(base({ ohlc1m: [], ohlc5m: [] })), null);
  assert.equal(evaluateTicketWave(base({ ohlc1m: trend(5, 1, 1), ohlc5m: trend(5, 1, 1) })), null);
  assert.equal(evaluateNoCross(base({ ohlc1m: undefined })), null);
});

test("HA_RIVER fires YES on green river, ask≤55, EV≥3", () => {
  const r = evaluateHaRiver(base());
  assert.ok(r, "HA_RIVER should fire on rising HA");
  assert.equal(r!.strategyId, "HA_RIVER");
  assert.equal(r!.signal, "YES");
  assert.equal(EV_FLOOR, 3);
});

test("EV floor: rich ask does not fire HA_RIVER", () => {
  assert.equal(evaluateHaRiver(base({ yesAsk: 88, yesBid: 86, noAsk: 14, noBid: 12 })), null);
});

test("mutual exclusion prefers HA_RIVER over TICKET_WAVE", () => {
  const obs = base({ yesAsk: 28, yesBid: 26 });
  const river = evaluateHaRiver(obs);
  const wave = evaluateTicketWave(obs);
  assert.ok(river);
  assert.ok(wave);
  const kept = preferHa15mResults([wave!, river!]);
  assert.equal(kept.length, 1);
  assert.equal(kept[0]!.strategyId, "HA_RIVER");
  const { all, best } = evaluateAllStrategies(obs);
  assert.equal(all.some((x) => x.strategyId === "TICKET_WAVE"), false);
  assert.equal(all.some((x) => x.strategyId === "HA_RIVER"), true);
  assert.ok(best);
});

test("NO_CROSS only last 90s and only if flat", () => {
  const mid = base({ secsRemaining: 400 });
  assert.equal(evaluateNoCross(mid), null);
  const late = base({
    secsRemaining: 80,
    currentPrice: 66_500,
    floorStrike: 64_000,
    openStrategyId: "HA_RIVER",
  });
  assert.equal(evaluateNoCross(late), null);
});

test("library registers four new ids; CEE leftover still null", () => {
  for (const id of ["HA_RIVER", "HA_FLIP", "TICKET_WAVE", "NO_CROSS"] as const) {
    assert.ok(getStrategy(id), id);
    assert.ok(getStrategy(id)!.winRateAtPrice);
  }
  assert.equal(evaluateCheapEarlyExit(base({ cheapEarlyExitEnabled: false, yesAsk: 18 })), null);
  assert.equal(evaluateCheapSide15m(base({ cheapSide15mEnabled: false, yesAsk: 12 })), null);
  assert.equal(evaluatePanicFade(base({ panicFadeEnabled: false })), null);
});

test("paper OPT_IN: new ids evaluate; not SEV1 / not OPT_IN deny", () => {
  assert.equal(PAPER_TIER_A_STRATEGY_IDS.includes("HA_RIVER"), false, "HA_RIVER leftover — not Tier A");
  assert.equal(PAPER_TIER_A_STRATEGY_IDS.includes("HA_FLIP"), false);
  assert.equal(PAPER_TIER_A_STRATEGY_IDS.includes("TICKET_WAVE"), false);
  const gates = BOT.slice(BOT.indexOf("const STRATEGY_OPT_IN_GATES"), BOT.indexOf("const LOCKED_DISABLED_STRATEGIES"));
  const locked = BOT.slice(BOT.indexOf("const LOCKED_DISABLED_STRATEGIES"), BOT.indexOf("export const LIVE_CORE_STRATEGY_IDS"));
  for (const id of ["HA_RIVER", "HA_FLIP", "TICKET_WAVE", "NO_CROSS"]) {
    assert.equal(gates.includes(id), false, `${id} must not be OPT_IN fail-closed`);
    assert.equal(locked.includes(`'${id}'`), false, `${id} must not be SEV1 locked`);
  }
  const paper = effectiveDisabledStrategies({
    disabledStrategies: [...PAPER_TIER_A_STRATEGY_IDS],
    paperMode: true,
    cheapEarlyExitEnabled: false,
    cheapSide15mEnabled: false,
    panicFadeEnabled: false,
    streakSatFadeEnabled: false,
  });
  // HA_RIVER is leftover HARD_NO_FILL — may remain in effective disabled / not Tier A.
  assert.equal(PAPER_TIER_A_STRATEGY_IDS.includes("HA_FLIP"), false);
  assert.equal(PAPER_TIER_A_STRATEGY_IDS.includes("TICKET_WAVE"), false);
  assert.equal(PAPER_TIER_A_STRATEGY_IDS.includes("NO_CROSS"), false);
  assert.equal(paper.includes("CHEAP_EARLY_EXIT"), true);
  assert.equal(paper.includes("DEEP_OTM_SNIPER"), true);
  assert.match(BOT, /cheapEarlyExitEnabled:\s+false/);
  assert.match(BOT, /cheapSide15mEnabled:\s+false/);
  assert.match(BOT, /panicFadeEnabled:\s+false/);
  assert.equal(isLivePaperLedgerCents(LEDGER.virtualCents), true, "paper ledger not Kalshi cash");
});

test("HA missing/gapped bars log starve and never fake HA", () => {
  resetHaStarveForTests();
  assert.equal(evaluateHaRiver(base({ ohlc1m: undefined, ohlc5m: undefined })), null);
  const starve = peekHaStarveForTests();
  assert.ok(starve);
  assert.equal(starve!.reason, "ha1m_missing");
  const short = ohlcSeriesStarved([{ open: 1, high: 1, low: 1, close: 1 }], 21, 90_000);
  assert.equal(short, "ha_bars_short");
  const t0 = 1_000_000;
  const gapped = [];
  for (let i = 0; i < 22; i++) {
    const ts = i === 21 ? t0 + i * 60_000 + 5 * 60_000 : t0 + i * 60_000;
    gapped.push({ open: 64_000, high: 64_010, low: 63_990, close: 64_005, t: ts });
  }
  assert.equal(ohlcSeriesStarved(gapped, 21, 90_000), "ha_bar_gap");
  assert.equal(evaluateHaRiver(base({ ohlc1m: gapped as never, ohlc5m: gapped as never })), null);
});
