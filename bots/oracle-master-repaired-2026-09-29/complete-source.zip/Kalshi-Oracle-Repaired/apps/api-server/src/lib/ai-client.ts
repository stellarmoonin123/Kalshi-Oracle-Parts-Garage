/**
 * ai-client.ts — Rate-limit-aware AI client with automatic fallback
 * 
 * Provides a unified interface for making AI API calls across the entire
 * codebase. When one model hits a rate limit (429), it automatically falls
 * back to the next available model, ensuring requests never fail due to
 * rate limits alone.
 * 
 * Fallback chain (in order):
 *   1. Primary model (user-specified or default)
 *   2. Claude Sonnet via OpenRouter
 *   3. Claude Haiku via OpenRouter  
 *   4. Grok 3 via xAI Direct (if key configured)
 *   5. Grok 3 Mini via xAI Direct (if key configured)
 *   6. Gemini 2.0 Flash (free) via OpenRouter
 *   7. Llama 3.3 70B (free) via OpenRouter
 *   8. GPT-5.4 Mini via OpenRouter
 *   9. DeepSeek V3 (free) via OpenRouter
 */

import { logger } from "./logger.js";
import { getNextProxy, markProxyRateLimited, markProxySuccess, markProxyFailed, areAllProxiesBlocked } from "./proxy-rotator.js";
import { getConfirmedModels, labelFor } from "./model-updater.js";
import { recordSuccess, recordFailure } from "./decision-safety.js";

// ── Environment ────────────────────────────────────────────────────────────────

const OPENROUTER_BASE = process.env.AI_INTEGRATIONS_OPENROUTER_BASE_URL ?? "https://openrouter.ai/api/v1";
const OPENROUTER_KEY  = process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY  ?? "";
const XAI_BASE        = "https://api.x.ai/v1";
const XAI_KEY         = process.env.XAI_API_KEY ?? "";
// OpenAI direct — independent key & rate-limit bucket; fallback when OpenRouter is throttled
const OPENAI_BASE     = (process.env.AI_INTEGRATIONS_OPENAI_BASE_URL ?? "https://api.openai.com/v1").replace(/\/$/, "");
const OPENAI_KEY      = process.env.AI_INTEGRATIONS_OPENAI_API_KEY ?? "";
// Groq + Gemini direct (OpenAI-compatible endpoints). Both keys are already
// set on Fly for desk chat; wiring them here gives the settlement ensemble /
// ARIA a working leg when OpenRouter is out of credits (402) or slugs rot.
const GROQ_BASE       = (process.env.GROQ_BASE_URL ?? "https://api.groq.com/openai/v1").replace(/\/$/, "");
const GEMINI_OAI_BASE = (process.env.GEMINI_OPENAI_BASE_URL ?? "https://generativelanguage.googleapis.com/v1beta/openai").replace(/\/$/, "");
const envList = (v: string | undefined, def: string[]) => (v ?? "").split(",").map(x => x.trim()).filter(Boolean).length > 0
  ? (v ?? "").split(",").map(x => x.trim()).filter(Boolean) : def;
export const GROQ_DEFAULT_MODELS   = ["openai/gpt-oss-120b", "openai/gpt-oss-20b"];
export const GEMINI_DEFAULT_MODELS = ["gemini-flash-latest", "gemini-flash-lite-latest"];

/** Keys read at call time so tests / secret rotation do not need a restart. */
function groqKey(): string { return process.env.GROQ_API_KEY ?? ""; }
function geminiKey(): string { return process.env.GEMINI_API_KEY ?? ""; }

// ── Provider-wide blocks (e.g. OpenRouter 402 credits exhausted) ─────────────
const providerBlockedUntil = new Map<string, { until: number; reason: string }>();
export const PROVIDER_402_BLOCK_MS = 10 * 60_000;

function isProviderBlocked(baseUrl: string): boolean {
  const b = providerBlockedUntil.get(baseUrl);
  if (!b) return false;
  if (Date.now() >= b.until) { providerBlockedUntil.delete(baseUrl); return false; }
  return true;
}

export function providerLabelFor(baseUrl: string): string {
  if (baseUrl.includes("openrouter")) return "openrouter";
  if (baseUrl.includes("groq")) return "groq";
  if (baseUrl.includes("generativelanguage")) return "gemini";
  if (baseUrl.includes("x.ai")) return "xai";
  if (baseUrl.includes("openai")) return "openai";
  return "custom";
}

export type ProviderErrorKind = "rate_limited" | "credits_exhausted" | "dead_model" | "transient";

/**
 * Classify a non-2xx provider response. 402 = account has no credits (block
 * the whole provider for a while, not just the model); 404 "No endpoints
 * found" / "no longer available" / "does not exist" = dead slug (24h block).
 */
export function classifyProviderError(status: number, body: string): ProviderErrorKind {
  if (status === 429) return "rate_limited";
  if (status === 402 || /requires more credits|insufficient (credits|balance)|payment required/i.test(body)) return "credits_exhausted";
  if ((status === 400 || status === 403 || status === 404) &&
      /not a valid model|invalid model|model not found|no model with|no endpoints found|no longer available|does not exist/i.test(body)) {
    return "dead_model";
  }
  return "transient";
}

/** Last per-provider failure summaries for a user-visible fallback reason. */
let lastFailureNotes: string[] = [];
function noteFailure(provider: AIProvider, status: number | string, kind: string) {
  const n = `${providerLabelFor(provider.baseUrl)}:${provider.model.split("/").pop()} ${status} ${kind}`;
  lastFailureNotes.push(n);
  if (lastFailureNotes.length > 12) lastFailureNotes = lastFailureNotes.slice(-12);
}
export function getProviderBlocks(): Record<string, { until: string; reason: string }> {
  const out: Record<string, { until: string; reason: string }> = {};
  for (const [k, v] of providerBlockedUntil) if (v.until > Date.now()) out[providerLabelFor(k)] = { until: new Date(v.until).toISOString(), reason: v.reason };
  return out;
}

// ── Types ──────────────────────────────────────────────────────────────────────

export interface AIProvider {
  model:   string;
  baseUrl: string;
  apiKey:  string;
  label:   string;
}

export interface ChatMessage {
  role:    "system" | "user" | "assistant";
  content: string;
}

export interface AIRequestOptions {
  messages:         ChatMessage[];
  model?:           string;        // Override default model
  maxTokens?:       number;        // Default: 4096
  temperature?:     number;        // Default: 0.7
  stream?:          boolean;       // Default: false
  responseFormat?:  { type: "json_object" } | { type: "text" };
  timeoutMs?:       number;        // Default: 60_000
  maxRetries?:      number;        // Default: 2 retries per model
}

export interface AIResponse {
  content:      string;
  model:        string;        // Which model actually responded
  provider:     string;        // "openrouter" | "xai"
  finishReason: string | null;
  usage?: {
    promptTokens:     number;
    completionTokens: number;
    totalTokens:      number;
  };
}

export interface AIStreamChunk {
  content?: string;
  done:     boolean;
  model?:   string;
}

// ── Rate limit tracking ────────────────────────────────────────────────────────

interface RateLimitState {
  blockedUntil: number;  // Unix ms when the model becomes available again
  consecutive429s: number;
}

const rateLimitState = new Map<string, RateLimitState>();

function isModelBlocked(modelKey: string): boolean {
  const state = rateLimitState.get(modelKey);
  if (!state) return false;
  if (Date.now() >= state.blockedUntil) {
    // Cooldown expired — reset
    rateLimitState.delete(modelKey);
    return false;
  }
  return true;
}

function markRateLimited(modelKey: string, retryAfterSec: number) {
  const existing = rateLimitState.get(modelKey);
  const consecutive = (existing?.consecutive429s ?? 0) + 1;
  
  // Exponential backoff: min 5s, then 10s, 20s, 40s, max 120s
  const baseCooldown = Math.max(retryAfterSec * 1000, 5000);
  const backoffMs = Math.min(baseCooldown * Math.pow(2, consecutive - 1), 120_000);
  
  rateLimitState.set(modelKey, {
    blockedUntil: Date.now() + backoffMs,
    consecutive429s: consecutive,
  });
  
  logger.warn({ modelKey, backoffMs, consecutive }, `Rate limited — cooling off for ${backoffMs}ms`);
}

function clearRateLimit(modelKey: string) {
  rateLimitState.delete(modelKey);
}

// ── Build fallback chain ───────────────────────────────────────────────────────
// The OpenRouter portion is populated dynamically from model-updater.ts, which
// probes all candidate slugs daily at 06:00 ET and ranks them by capability.
// A hardcoded safe fallback list is used on first startup before the probe
// completes. The OpenAI direct tier is kept static (independent key/bucket).

export function buildFallbackChain(preferredModel?: string): AIProvider[] {
  const chain: AIProvider[] = [];
  const seen = new Set<string>();

  const addOR = (model: string, label: string) => {
    if (seen.has(model) || !OPENROUTER_KEY) return;
    seen.add(model);
    chain.push({ model, baseUrl: OPENROUTER_BASE, apiKey: OPENROUTER_KEY, label });
  };

  const addOAI = (model: string, label: string) => {
    if (seen.has(model) || !OPENAI_KEY) return;
    seen.add(model);
    chain.push({ model, baseUrl: OPENAI_BASE, apiKey: OPENAI_KEY, label });
  };

  const addXAI = (model: string, label: string) => {
    if (seen.has(model) || !XAI_KEY) return;
    seen.add(model);
    chain.push({ model, baseUrl: XAI_BASE, apiKey: XAI_KEY, label });
  };

  // 0. Caller-preferred model first (e.g. a specific strategy prefers one model)
  // Note: OpenRouter grok slugs are namespaced as "x-ai/grok-3", so a stray
  // guard checking for a bare "grok-" prefix here could never match real
  // input and was silently dead code — grok models go through OpenRouter
  // like any other model, there is no separate handling required.
  if (preferredModel && OPENROUTER_KEY) {
    addOR(preferredModel, `${preferredModel} [selected]`);
  }

  // Dynamic OpenRouter chain — updated daily at 06:00 ET by model-updater.
  // Returns best-first sorted list of confirmed-live models from last probe.
  for (const m of getConfirmedModels()) {
    addOR(m, labelFor(m));
  }

  // OpenAI direct — separate key + independent rate-limit bucket from OpenRouter.
  // Fires only when ALL OpenRouter models are simultaneously throttled.
  // gpt-5 > gpt-4.1; both kept for maximum resilience.
  addOAI("gpt-5",   "GPT-5 (OpenAI direct)");
  addOAI("gpt-4.1", "GPT-4.1 (OpenAI direct)");
  // mini models intentionally excluded — quality not acceptable for trading decisions

  // xAI direct — a third, fully independent provider/key/infra stack. Was
  // documented in this file's header as part of the fallback chain but never
  // actually wired into buildFallbackChain(), so an OpenRouter+OpenAI outage
  // had no third leg. Last resort: only reached if both of the above are down.
  addXAI("grok-3",      "Grok 3 (xAI direct)");
  addXAI("grok-3-mini", "Grok 3 Mini (xAI direct)");

  // Groq + Gemini direct — independent keys/buckets (OpenAI-compatible).
  const gk = groqKey();
  if (gk) for (const m of envList(process.env.GROQ_MODELS, GROQ_DEFAULT_MODELS)) {
    const key = `groq:${m}`;
    if (seen.has(key)) continue; seen.add(key);
    chain.push({ model: m, baseUrl: GROQ_BASE, apiKey: gk, label: `${m} (Groq direct)` });
  }
  const mk = geminiKey();
  if (mk) for (const m of envList(process.env.GEMINI_MODELS, GEMINI_DEFAULT_MODELS)) {
    const key = `gemini:${m}`;
    if (seen.has(key)) continue; seen.add(key);
    chain.push({ model: m, baseUrl: GEMINI_OAI_BASE, apiKey: mk, label: `${m} (Gemini direct)` });
  }

  // Skip providers that are blocked account-wide (402 credits exhausted).
  return chain.filter(p => !isProviderBlocked(p.baseUrl));
}

// ── Reasoning-model JSON handling (Task #269) ───────────────────────────────────
//
// Reasoning models (o1/o3-style, DeepSeek R1, QwQ, etc.) either reject a forced
// `response_format: json_object` outright (burning a full fallback-chain slot
// on a 400 that a normal chat model would have satisfied) or return prose/
// chain-of-thought wrapped around the JSON, which previously got treated as a
// "successful" response and handed to the caller's own JSON.parse — which then
// failed silently with no further fallback. Fix: never force response_format on
// a detected reasoning model, and when the caller wants JSON, extract the first
// balanced {...} block from the content instead of assuming the whole string
// parses.
const REASONING_MODEL_PATTERN = /(^|\/)(o1|o3|o4-mini)(\b|-)|deepseek-r1|deepseek\/deepseek-r1|qwq|-thinking\b|gemini-2\.\d+-flash-thinking/i;

function isReasoningModel(modelName: string): boolean {
  return REASONING_MODEL_PATTERN.test(modelName);
}

/** Extracts the first balanced top-level {...} JSON object from a string,
 *  tolerating leading/trailing prose (e.g. reasoning-model chain-of-thought). */
function extractJsonObject(text: string): string | null {
  const start = text.indexOf("{");
  if (start === -1) return null;
  let depth = 0;
  for (let i = start; i < text.length; i++) {
    if (text[i] === "{") depth++;
    else if (text[i] === "}") {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}

// ── Core API call with rate limit handling ─────────────────────────────────────

async function callProvider(
  provider: AIProvider,
  opts: AIRequestOptions,
  signal: AbortSignal,
): Promise<AIResponse | null> {
  const modelKey = `${provider.baseUrl}:${provider.model}`;
  
  // Skip if currently rate-limited
  if (isModelBlocked(modelKey)) {
    logger.debug({ modelKey }, "Skipping rate-limited model");
    return null;
  }
  
  const headers: Record<string, string> = {
    Authorization:  `Bearer ${provider.apiKey}`,
    "Content-Type": "application/json",
  };
  
  // OpenRouter wants referrer headers
  if (provider.baseUrl.includes("openrouter")) {
    headers["HTTP-Referer"] = "https://replit.com";
    headers["X-Title"]      = "Kalshi Oracle Trading Bot";
  }
  
  const body: Record<string, unknown> = {
    model:      provider.model,
    messages:   opts.messages,
    max_tokens: opts.maxTokens ?? 4096,
    stream:     false,
  };
  
  if (opts.temperature !== undefined) {
    body.temperature = opts.temperature;
  }
  const modelIsReasoning = isReasoningModel(provider.model);
  // Never force response_format on a reasoning model — many reject the param
  // outright (400, burning a fallback slot) or ignore it and emit
  // chain-of-thought prose around the JSON. We extract JSON from the raw
  // content below instead.
  if (opts.responseFormat && !modelIsReasoning) {
    body.response_format = opts.responseFormat;
  }
  
  try {
    // Get proxy for this request (rotates on rate limit)
    const proxyInfo = getNextProxy();
    const fetchOpts: RequestInit & { agent?: any } = {
      method:  "POST",
      headers,
      body:    JSON.stringify(body),
      signal,
    };
    
    if (proxyInfo?.agent) {
      fetchOpts.agent = proxyInfo.agent;
      logger.debug({ proxy: proxyInfo.label, model: provider.model }, "Using proxy for AI request");
    }
    
    const resp = await fetch(`${provider.baseUrl}/chat/completions`, fetchOpts);
    
    // 429 — skip this model for the current request; do NOT block it for future requests.
    // A global model block causes the entire fallback pool to go dark during brief
    // rate-limit spikes. The next request will try this model fresh.
    if (resp.status === 429) {
      logger.warn({ model: provider.model }, "AI provider: 429 (skipping for this request, no global block)");
      // Still rotate the proxy in case the limit is proxy-specific
      if (proxyInfo?.url) {
        const retryAfter = parseFloat(resp.headers.get("retry-after") ?? "5") || 5;
        markProxyRateLimited(proxyInfo.url, retryAfter * 1_000);
      }
      return null;
    }

    if (resp.status === 402 || resp.status === 404 || resp.status === 403) {
      const errText = await resp.clone().text().catch(() => "");
      const kind = classifyProviderError(resp.status, errText);
      if (kind === "credits_exhausted") {
        providerBlockedUntil.set(provider.baseUrl, { until: Date.now() + PROVIDER_402_BLOCK_MS, reason: "credits exhausted (402)" });
        logger.warn({ provider: providerLabelFor(provider.baseUrl) }, "AI provider: credits exhausted (402) — provider skipped for 10 min");
        noteFailure(provider, resp.status, "credits_exhausted");
        return null;
      }
      if (kind === "dead_model") {
        rateLimitState.set(modelKey, { blockedUntil: Date.now() + 24 * 60 * 60 * 1_000, consecutive429s: 999 });
        logger.warn({ model: provider.model, status: resp.status, error: errText.slice(0, 120) }, "AI provider: dead model (24h block)");
        noteFailure(provider, resp.status, "dead_model");
        return null;
      }
    }
    if (!resp.ok && resp.status !== 429) noteFailure(provider, resp.status, "error");

    // 400 "invalid model" — permanently block this slug for 24 h so it never
    // burns retry cycles again. Other 400s (bad params etc.) are transient.
    if (resp.status === 400) {
      const errText = await resp.text().catch(() => "");
      const isInvalidModel = errText.includes("not a valid model") || errText.includes("invalid model");
      if (isInvalidModel) {
        rateLimitState.set(modelKey, { blockedUntil: Date.now() + 24 * 60 * 60 * 1_000, consecutive429s: 999 });
        logger.warn({ model: provider.model, error: errText.slice(0, 120) }, "AI provider: invalid model (24h block)");
      } else {
        logger.warn({ model: provider.model, status: resp.status, error: errText.slice(0, 200) }, "AI provider error (non-429)");
      }
      return null;
    }

    // 403/404 — only 24h-block when the body confirms the model slug is dead.
    // Transient service errors must NOT block the model for future requests —
    // just return null so the caller skips to the next provider this request,
    // and the next request tries this model fresh.
    if (resp.status === 403 || resp.status === 404) {
      const errText = await resp.text().catch(() => "");
      const isDeadModel = errText.includes("not a valid model") || errText.includes("invalid model") ||
                          errText.includes("model not found")   || errText.includes("no model with");
      if (isDeadModel) {
        rateLimitState.set(modelKey, { blockedUntil: Date.now() + 24 * 60 * 60 * 1_000, consecutive429s: 999 });
        logger.warn({ model: provider.model, status: resp.status, error: errText.slice(0, 120) }, "AI provider: dead model (24h block)");
      } else {
        // Transient — log but do NOT block; next request tries fresh
        logger.warn({ model: provider.model, status: resp.status, error: errText.slice(0, 120) }, "AI provider: transient error (no block)");
      }
      return null;
    }
    
    // Success - mark proxy as working
    if (proxyInfo?.url) {
      markProxySuccess(proxyInfo.url);
    }
    
    // Other errors — don't mark as rate limited, just fail this provider
    if (!resp.ok) {
      const errText = await resp.text().catch(() => "");
      logger.warn({ model: provider.model, status: resp.status, error: errText.slice(0, 200) },
        "AI provider error (non-429)");
      return null;
    }
    
    // Success — clear any previous rate limit state
    clearRateLimit(modelKey);
    
    const data = await resp.json() as {
      choices?: { message?: { content?: string | null }; finish_reason?: string }[];
      usage?: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number };
    };
    
    const choice = data.choices?.[0];
    const rawContent = choice?.message?.content;
    if (typeof rawContent !== "string" || rawContent.trim().length === 0) {
      // Reasoning models can spend their whole completion budget thinking and
      // return no visible content. For JSON calls this is an expected provider
      // miss, not an outage: return null so aiChat() immediately tries the next
      // model, just like it does for a 429. Keep it quiet at normal log levels
      // because ARIA requests this path on a frequent interval.
      if (opts.responseFormat?.type === "json_object") {
        logger.debug({ model: provider.model }, "AI provider returned empty JSON content — trying next provider");
      } else {
        logger.warn({ model: provider.model }, "Empty response from AI provider");
      }
      return null;
    }
    
    let content = rawContent;
    // Task #269: when the caller wants JSON, don't hand back prose-wrapped
    // content as a "success" — a reasoning model's chain-of-thought around the
    // JSON would otherwise pass this layer and fail the caller's own
    // JSON.parse with no further fallback. Extract the JSON object; if none is
    // found, treat this provider as failed so the chain moves on.
    if (opts.responseFormat?.type === "json_object") {
      const trimmed = content.trim();
      const looksLikeJson = trimmed.startsWith("{") && trimmed.endsWith("}");
      if (!looksLikeJson) {
        const extracted = extractJsonObject(content);
        if (extracted) {
          content = extracted;
        } else {
          logger.warn({ model: provider.model, reasoning: modelIsReasoning, preview: content.slice(0, 160) },
            "AI provider: requested JSON but no JSON object found in response — treating as failed, trying next provider");
          return null;
        }
      }
    }

    return {
      content,
      model:        provider.model,
      provider:     providerLabelFor(provider.baseUrl),
      finishReason: choice?.finish_reason ?? null,
      usage: data.usage ? {
        promptTokens:     data.usage.prompt_tokens ?? 0,
        completionTokens: data.usage.completion_tokens ?? 0,
        totalTokens:      data.usage.total_tokens ?? 0,
      } : undefined,
    };
    
  } catch (err) {
    // AbortError means the caller's AbortController fired (overall timeout).
    // Re-throw so the for loop in aiChat() exits immediately instead of
    // cascading "aborted" errors through every remaining model in the chain.
    if (err instanceof Error && err.name === "AbortError") {
      throw err;
    }
    // Network error, timeout, etc.
    logger.warn({ model: provider.model, error: err instanceof Error ? err.message : String(err) },
      "AI provider fetch error");
    return null;
  }
}

// ── Public API ─────────────────────────────────────────────────────────────────

/**
 * Make an AI chat completion request with automatic rate-limit fallback.
 * INFINITE RETRY: Keeps cycling through all providers until one succeeds.
 * Will never throw due to rate limits — only throws if no providers configured.
 * 
 * @param opts - Request options
 * @param opts.maxCycles - Max times to cycle through all providers (default: Infinity)
 */
export async function aiChat(opts: AIRequestOptions & { maxCycles?: number }): Promise<AIResponse> {
  const chain = buildFallbackChain(opts.model);
  lastFailureNotes = [];
  
  if (chain.length === 0) {
    throw new Error("No AI providers configured (missing API keys)");
  }
  
  // Single-pass: try each provider once. No retry cycles — fail immediately
  // with a user-visible message rather than looping silently.
  let totalAttempts = 0;

  // If every provider is blocked, wait ≤10 s for the first one to unblock.
  const allBlocked = chain.every(p => isModelBlocked(`${p.baseUrl}:${p.model}`));
  if (allBlocked) {
    let earliest = Infinity;
    for (const [, s] of rateLimitState) { if (s.blockedUntil < earliest) earliest = s.blockedUntil; }
    const waitMs = isFinite(earliest) ? Math.max(0, earliest - Date.now()) : Infinity;
    if (waitMs <= 10_000) {
      await new Promise(r => setTimeout(r, waitMs + 200));
    } else {
      const waitSec = isFinite(waitMs) ? Math.ceil(waitMs / 1_000) : 60;
      throw new Error(
        `All AI providers are temporarily rate-limited. Please try again in ${waitSec < 60 ? `${waitSec}s` : `${Math.ceil(waitSec / 60)}m`}.`
      );
    }
  }

  const timeoutMs = opts.timeoutMs ?? 60_000;
  const controller = new AbortController();
  const timeoutId  = setTimeout(() => controller.abort(), timeoutMs);

  try {
    for (const provider of chain) {
      const modelKey = `${provider.baseUrl}:${provider.model}`;
      if (isModelBlocked(modelKey) || isProviderBlocked(provider.baseUrl)) continue;

      totalAttempts++;
      const result = await callProvider(provider, opts, controller.signal);
      if (result) {
        recordSuccess("ai-provider");
        if (totalAttempts > 1) {
          logger.info({ model: result.model, provider: result.provider, totalAttempts },
            "🔄 AI request succeeded on fallback provider");
        }
        return result;
      }
      // If the proxy itself is now blocked, stop trying more models immediately —
      // they'll all wait 5 s each for the same blocked connection.
      if (areAllProxiesBlocked()) {
        logger.warn({ totalAttempts }, "All proxies blocked — aborting model chain early");
        break;
      }
    }
  } finally {
    clearTimeout(timeoutId);
  }

  // Systemic outage signal — every configured provider failed this call.
  // Per-model 429/400/403/404 blocking already happens inside callProvider;
  // this circuit breaker is a coarser "the whole AI subsystem is down" flag
  // for isDecisionSafe() to consult, not a replacement for that per-model logic.
  recordFailure("ai-provider");
  const notes = lastFailureNotes.slice(-4).join("; ");
  lastFailureNotes = [];
  throw new Error(`All AI providers failed (${totalAttempts} tried)${notes ? `: ${notes}` : ""} — try again in a moment.`);
}

/**
 * Streaming version of aiChat with automatic rate-limit fallback.
 * INFINITE RETRY: Keeps cycling through all providers until one succeeds.
 * Returns an async generator that yields content chunks.
 * 
 * @param opts - Request options
 * @param opts.maxCycles - Max times to cycle through all providers (default: Infinity)
 */
export async function* aiChatStream(opts: AIRequestOptions & { maxCycles?: number }): AsyncGenerator<AIStreamChunk> {
  const chain = buildFallbackChain(opts.model);
  
  if (chain.length === 0) {
    throw new Error("No AI providers configured (missing API keys)");
  }
  
  // Single-pass: try each provider once. No retry cycles.
  let totalAttempts = 0;
  let lastError: Error | null = null;

  // If every provider is blocked, wait ≤10 s for the first to unblock.
  const allBlocked = chain.every(p => isModelBlocked(`${p.baseUrl}:${p.model}`));
  if (allBlocked) {
    let earliest = Infinity;
    for (const [, s] of rateLimitState) { if (s.blockedUntil < earliest) earliest = s.blockedUntil; }
    const waitMs = isFinite(earliest) ? Math.max(0, earliest - Date.now()) : Infinity;
    if (waitMs <= 10_000) {
      await new Promise(r => setTimeout(r, waitMs + 200));
    } else {
      const waitSec = isFinite(waitMs) ? Math.ceil(waitMs / 1_000) : 60;
      throw new Error(
        `All AI providers are temporarily rate-limited. Please try again in ${waitSec < 60 ? `${waitSec}s` : `${Math.ceil(waitSec / 60)}m`}.`
      );
    }
  }

  const timeoutMs = opts.timeoutMs ?? 90_000;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  // Content already yielded to the caller across all attempts. When a model is
  // interrupted mid-stream (rate limit / stream error), this is passed to the
  // next model so it continues rather than restarts from scratch.
  let accumulatedContent = "";

  try {
    for (const provider of chain) {
      const modelKey = `${provider.baseUrl}:${provider.model}`;

      if (isModelBlocked(modelKey) || isProviderBlocked(provider.baseUrl)) {
        continue;
      }
        
        totalAttempts++;
        
        const headers: Record<string, string> = {
          Authorization:  `Bearer ${provider.apiKey}`,
          "Content-Type": "application/json",
        };
        
        if (provider.baseUrl.includes("openrouter")) {
          headers["HTTP-Referer"] = "https://replit.com";
          headers["X-Title"]      = "Kalshi Oracle Trading Bot";
        }

        // If a previous provider was interrupted mid-response, pass what it
        // already said so this provider continues rather than restarts.
        const messagesForAttempt = accumulatedContent
          ? [
              ...opts.messages,
              { role: "assistant" as const, content: accumulatedContent },
              { role: "user"      as const, content: "(Your previous response was interrupted by a rate limit. Continue exactly where you left off — do not repeat anything already said.)" },
            ]
          : opts.messages;
        
        const body: Record<string, unknown> = {
          model:      provider.model,
          messages:   messagesForAttempt,
          max_tokens: opts.maxTokens ?? 4096,
          stream:     true,
        };
        
        if (opts.temperature !== undefined) {
          body.temperature = opts.temperature;
        }

        // Rotate proxies for streaming attempts too, so 429s can mark the
        // active proxy rate-limited (same behavior as the non-stream path).
        const proxyInfo = getNextProxy();

        try {
          const resp = await fetch(`${provider.baseUrl}/chat/completions`, {
            method:  "POST",
            headers,
            body:    JSON.stringify(body),
            signal:  controller.signal,
          });
          
          if (resp.status === 429) {
            // Skip this model for this request only — no global block.
            logger.warn({ model: provider.model }, "AI stream: 429 (skipping, no global block)");
            if (proxyInfo?.url) {
              const retryAfter = parseFloat(resp.headers.get("retry-after") ?? "5") || 5;
              markProxyRateLimited(proxyInfo.url, retryAfter * 1_000);
            }
            lastError = new Error(`429 on ${provider.model}`);
            // If the proxy itself is now blocked, stop trying more models immediately
            if (areAllProxiesBlocked()) {
              logger.warn({ totalAttempts }, "All proxies blocked — aborting stream chain early");
              break;
            }
            continue;
          }

          // 400 invalid model — 24h permanent block
          if (resp.status === 400) {
            const errText = await resp.text().catch(() => "");
            const isInvalidModel = errText.includes("not a valid model") || errText.includes("invalid model");
            if (isInvalidModel) {
              rateLimitState.set(modelKey, { blockedUntil: Date.now() + 24 * 60 * 60 * 1_000, consecutive429s: 999 });
              logger.warn({ model: provider.model, error: errText.slice(0, 120) }, "AI stream: invalid model (24h block)");
            } else {
              lastError = new Error(`${provider.label} HTTP 400: ${errText.slice(0, 200)}`);
            }
            continue;
          }

          // 403/404 — only 24h-block on confirmed dead model slug; transient errors get no block
          if (resp.status === 402) {
            providerBlockedUntil.set(provider.baseUrl, { until: Date.now() + PROVIDER_402_BLOCK_MS, reason: "credits exhausted (402)" });
            logger.warn({ provider: providerLabelFor(provider.baseUrl) }, "AI stream: credits exhausted (402) — provider skipped for 10 min");
            lastError = new Error(`${provider.label} HTTP 402: credits exhausted`);
            continue;
          }
          if (resp.status === 403 || resp.status === 404) {
            const errText = await resp.text().catch(() => "");
            const isDeadModel = errText.includes("not a valid model") || errText.includes("invalid model") ||
                                errText.includes("model not found")   || errText.includes("no model with");
            if (isDeadModel) {
              rateLimitState.set(modelKey, { blockedUntil: Date.now() + 24 * 60 * 60 * 1_000, consecutive429s: 999 });
              logger.warn({ model: provider.model, status: resp.status, error: errText.slice(0, 120) }, "AI stream: dead model (24h block)");
            } else {
              // Transient — do NOT block; next request tries fresh
              logger.warn({ model: provider.model, status: resp.status, error: errText.slice(0, 120) }, "AI stream: transient error (no block)");
              lastError = new Error(`${provider.label} HTTP ${resp.status}: ${errText.slice(0, 200)}`);
            }
            continue;
          }

          if (!resp.ok || !resp.body) {
            const errText = await resp.text().catch(() => "");
            lastError = new Error(`${provider.label} HTTP ${resp.status}: ${errText.slice(0, 200)}`);
            continue;
          }
          
          // Success — stream the response
          clearRateLimit(modelKey);
          
          if (totalAttempts > 1) {
            logger.info({ model: provider.model, totalAttempts }, 
              "🔄 AI stream using fallback provider after retries");
          }
          
          const reader = resp.body.getReader();
          const decoder = new TextDecoder();
          let buffer = "";
          let streamError = false;
          let chunkContent = "";
          
          try {
            outer: while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              
              buffer += decoder.decode(value, { stream: true });
              const lines = buffer.split("\n");
              buffer = lines.pop() ?? "";
              
              for (const line of lines) {
                if (!line.startsWith("data: ")) continue;
                const raw = line.slice(6).trim();
                if (raw === "[DONE]") {
                  yield { done: true, model: provider.model };
                  return;
                }
                
                try {
                  const chunk = JSON.parse(raw) as {
                    error?: { code?: number; message?: string };
                    choices?: { delta?: { content?: string } }[];
                  };

                  // Rate-limit or error embedded inside the stream
                  if (chunk.error) {
                    const isRateLimit = chunk.error.code === 429 ||
                      String(chunk.error.message).toLowerCase().includes("rate limit") ||
                      String(chunk.error.message).toLowerCase().includes("rate_limit") ||
                      String(chunk.error.message).toLowerCase().includes("too many request");
                    logger.warn({ model: provider.model, code: chunk.error.code, msg: chunk.error.message },
                      `AI stream: in-stream ${isRateLimit ? "rate-limit" : "error"} — switching to next model`);
                    lastError = new Error(`Stream error from ${provider.label}: ${chunk.error.message}`);
                    streamError = true;
                    reader.cancel().catch(() => {});
                    break outer;
                  }

                  const content = chunk.choices?.[0]?.delta?.content;
                  if (content) {
                    chunkContent += content;
                    yield { content, done: false, model: provider.model };
                  }
                } catch {
                  // Skip malformed JSON chunks
                }
              }
            }

            if (streamError) {
              // Accumulate what was already sent so the next model can continue
              if (chunkContent) {
                accumulatedContent += chunkContent;
                yield { content: "\n\n*[⚡ Rate limit hit — switching to next AI model and continuing...]*\n\n", done: false, model: provider.model };
              }
              continue;
            }
            
            yield { done: true, model: provider.model };
            return;
            
          } finally {
            reader.releaseLock();
          }
          
        } catch (err) {
          lastError = err instanceof Error ? err : new Error(String(err));
          continue;
        }
      }
  } finally {
    clearTimeout(timeoutId);
  }

  throw lastError ?? new Error(`All AI providers failed (${totalAttempts} tried) — try again in a moment.`);
}

/**
 * Simple helper for single-turn completions (most common use case)
 */
export async function aiComplete(
  systemPrompt: string,
  userPrompt:   string,
  opts?: Partial<AIRequestOptions>,
): Promise<string> {
  const response = await aiChat({
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user",   content: userPrompt },
    ],
    ...opts,
  });
  return response.content;
}

/**
 * JSON completion helper — parses response as JSON
 */
export async function aiCompleteJSON<T = unknown>(
  systemPrompt: string,
  userPrompt:   string,
  opts?: Partial<AIRequestOptions>,
): Promise<T> {
  const response = await aiChat({
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user",   content: userPrompt },
    ],
    responseFormat: { type: "json_object" },
    ...opts,
  });
  
  // Some models wrap JSON in a markdown code fence even when json_object mode
  // is requested — strip it before parsing rather than failing outright.
  const fenced = response.content.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
  const candidate = fenced ? fenced[1]! : response.content;

  try {
    return JSON.parse(candidate) as T;
  } catch {
    throw new Error(`Failed to parse AI response as JSON: ${response.content.slice(0, 200)}`);
  }
}

/**
 * Get current rate limit status for debugging
 */
export function getRateLimitStatus(): Record<string, { blockedUntil: Date; consecutive429s: number }> {
  const status: Record<string, { blockedUntil: Date; consecutive429s: number }> = {};
  for (const [key, state] of rateLimitState) {
    status[key] = {
      blockedUntil: new Date(state.blockedUntil),
      consecutive429s: state.consecutive429s,
    };
  }
  return status;
}

/**
 * Clear all rate-limit state — call this to immediately unblock every provider
 * without needing a server restart.
 */
export function clearAllRateLimits(): number {
  const count = rateLimitState.size;
  rateLimitState.clear();
  return count;
}
