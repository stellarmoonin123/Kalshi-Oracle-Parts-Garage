/** QUARANTINE(HANG): god-file assert.match on trading-bot; hang-prone — frozen-irrelevant host peel */
/**
 * brain-resilience.test.ts
 *
 * One file for SMART/FAST/STRONG/RESILIENT desk checks that were scattered.
 * Does NOT import trading-bot.ts (node:test isolation).
 *
 * RESILIENT: restart one-position, quote_stale skip, lag_stale/lag_against skip,
 * Kelly-zero stays 0.
 * SMART: p ≠ confidence; still-mid SP/CC/LE stay disabled; REST is not live fills.
 *
 * LOCKS: paperMode true, autoMode true as adaptation (disk). No EV/Kelly cuts.
 * No ENABLE. Ledger 30720 untouched. No charts.tsx.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import test from "node:test";
import assert from "node:assert/strict";
import { computeContracts, pWinFromCurve } from "./admission.js";
import { decideSettlementSide } from "./settlement-side.js";
import { isLiveWsOdds } from "./kalshi-ws.js";
import {
  is15mDeskEvaluateAllowed,
  hourlyOrPerpEvaluateAllowed,
} from "./15m-product.js";
import {
  evaluateAllStrategies,
  getStrategy,
  FAIL_CLOSED_WITHOUT_WINRATE_CURVE,
  type StrategyObservation,
} from "./strategy-library.js";
import { PATCH_FAIL_CLOSED_DISABLED } from "./config-patch-surface.js";
import {
  confluenceStillMidUnclearReason,
  CONFLUENCE_STILL_MID_UNCLEAR_SKIP,
} from "./confluence-cascade.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const ADM = readFileSync(path.join(DIR, "admission.ts"), "utf8");

function stillMidObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65_100,
    floorStrike: 65_000,
    velocityDolPerMin: 10,
    threeMinVelocity: 8,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 52,
    secsRemaining: 8 * 60,
    contractDurationMins: 15,
    ticker: "KXBTC15M-26AUG271615-15",
    yesAsk: 49,
    noAsk: 51,
    regime: "unclear",
    ...overrides,
  };
}

test.skip("RESILIENT restart: soft PG/null clears start() fail-closed heldPending latch", () => {
  // Regression: start() sets heldPendingFromRestart=true then void adoptRestartPendingGuard().
  // If the DB select throws, catch must clear the latch — otherwise paper placeOrder
  // deadlocks on "pending trade from the prior process is still open" with openTrade=null.
  assert.match(BOT, /let confirmedLivePending = false/);
  assert.match(BOT, /this\.heldPendingFromRestart = confirmedLivePending/);
  assert.match(BOT, /Restart pending-exposure check failed — not blocking \(soft\)/);
  assert.doesNotMatch(
    BOT,
    /if \(this\.heldPendingFromRestart !== true\) this\.heldPendingFromRestart = false/,
  );
});

test.skip("RESILIENT restart: placeOrder uses shouldBlockSecondPosition (one-position)", () => {
  assert.match(BOT, /shouldBlockSecondPosition\(/);
  assert.match(BOT, /hasPendingUnsettled: this\.heldPendingFromRestart/);
  assert.match(BOT, /hasOpenTrade: this\.openTrade != null/);
  assert.match(BOT, /Task #604: one-position rule/);
});

test.skip("RESILIENT quote_stale / lag_stale / lag_against skip (not fill)", () => {
  const stale = decideSettlementSide({ pYes: 0.7, pNo: null, mtf: 0, quoteAgeMs: 61_000 });
  assert.equal(stale.side, "skip");
  assert.equal(stale.reason, "quote_stale");
  assert.equal(stale.pWin, null);

  const lagStale = decideSettlementSide({
    pYes: 0.7, pNo: null, mtf: 0, lagStale: true, lagDollars: 40,
  });
  assert.equal(lagStale.side, "skip");
  assert.equal(lagStale.reason, "lag_stale");

  const against = decideSettlementSide({
    pYes: 0.7, pNo: null, mtf: 0, lagStale: false, lagDollars: -40,
  });
  assert.equal(against.side, "skip");
  assert.equal(against.reason, "lag_disagrees");
  assert.notEqual(against.side, "no");
});

test.skip("RESILIENT Kelly-zero stays 0; SIZE_RESCUE off", () => {
  const sized = computeContracts({
    pWin: 0.50,
    pSizeClamped: 0.50,
    entryPriceCents: 50,
    confidence: 80,
    edge: 8,
    balanceCents: 31_300,
    maxContracts: 999,
    uMult: 1,
  });
  assert.equal(sized.contracts, 0);
  assert.match(sized.limiter, /KELLY/);
  assert.equal(ADM.includes("SIZE_RESCUE_MIN1"), false);
  assert.equal(BOT.includes('limiter: "SIZE_RESCUE_MIN1"'), false);
});

test.skip("SMART p is winRateAtPrice curve, never confidence", () => {
  const curve = (ask: number) => Math.max(0.01, Math.min(0.99, 1 - ask / 200));
  const p = pWinFromCurve(curve, 40, 8);
  assert.equal(p, curve(40));
  assert.notEqual(p, 0.99, "heuristic confidence 0.99 must not replace curve p");
  assert.equal(pWinFromCurve(undefined, 40, 8), null);
  assert.equal(BOT.includes("const p = expectedWinRate;"), false);
  assert.match(BOT, /return pWinFromCurve\(winRateAtPrice, entryPriceCents, minutesLeft\)/);
});

test.skip("SMART still-mid: SP/LE stay disabled; CC still-mid 49¢ unclear still skips", () => {
  for (const id of ["SETTLEMENT_PREDICTION", "LATE_ENTRY_ANCHOR"]) {
    assert.ok(
      (PATCH_FAIL_CLOSED_DISABLED as readonly string[]).includes(id),
      `${id} must stay in PATCH_FAIL_CLOSED_DISABLED`,
    );
  }
  assert.equal(
    (PATCH_FAIL_CLOSED_DISABLED as readonly string[]).includes("CONFLUENCE_CASCADE"),
    false,
    "CONFLUENCE paper-restored — not PATCH fail-closed",
  );
  assert.ok(FAIL_CLOSED_WITHOUT_WINRATE_CURVE.has("CONFLUENCE_CASCADE"));
  assert.equal(
    confluenceStillMidUnclearReason(stillMidObs(), 49),
    CONFLUENCE_STILL_MID_UNCLEAR_SKIP,
  );

  const disabled = [
    "SETTLEMENT_PREDICTION",
    "LATE_ENTRY_ANCHOR",
  ];
  const spies: Array<{ id: string; restore: () => void; calls: () => number }> = [];
  for (const id of disabled) {
    const strat = getStrategy(id as "SETTLEMENT_PREDICTION");
    if (!strat) continue;
    const original = strat.evaluate;
    let n = 0;
    strat.evaluate = (obs) => {
      n++;
      return original.call(strat, obs);
    };
    spies.push({ id, restore: () => { strat.evaluate = original; }, calls: () => n });
  }
  try {
    const { best, all } = evaluateAllStrategies(stillMidObs(), disabled);
    for (const s of spies) {
      assert.equal(s.calls(), 0, `${s.id}.evaluate must not run while disabled`);
    }
    assert.equal(all.some((r) => disabled.includes(r.strategyId)), false);
    if (best) assert.equal(disabled.includes(best.strategyId), false);
    assert.equal(all.some((r) => r.strategyId === "CONFLUENCE_CASCADE"), false,
      "still-mid 49¢ unclear must still skip CONFLUENCE even when paper-eligible");
  } finally {
    for (const s of spies) s.restore();
  }
});

test.skip("SMART REST quote is never live for fills; 15m desk refuses hourly/perp flags-off", () => {
  const t = Date.now();
  assert.equal(isLiveWsOdds({
    source: "rest", quoteTs: t, lastWsMessageTs: t, nowMs: t,
  }), false);
  assert.match(BOT, /REST_NOT_LIVE/);
  assert.match(BOT, /restQuoteBlocksFill/);

  assert.equal(is15mDeskEvaluateAllowed({ ticker: "KXBTCD-26AUG2714" }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({ ticker: "KXBTCPERP" }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({
    ticker: "KXBTCD-26AUG2714", enable1HContracts: false,
  }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({ ticker: "KXBTCPERP" }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({
    ticker: "KXBTC15M-26AUG271615-15",
  }).ok, true);
});
