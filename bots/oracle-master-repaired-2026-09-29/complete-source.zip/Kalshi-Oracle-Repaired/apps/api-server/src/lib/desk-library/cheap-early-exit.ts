/**
 * cheap-early-exit.ts — early-exit book, shadow.
 *
 * Stellar doctrine: money CAN be made if the WRONG settlement side is
 * picked. Buy a cheap ask → ticket turns green → SELL EARLY. Hold-to-settle
 * is a different book. persist-cheap LIVE 60s hold-to-settle is dead
 * (0 fills). This cell reuses still-cheap's 15s fair persist + intra-scalp
 * exits, on the cheap 7–22¢ band, without a settlement-EV gate.
 *
 * paperMode true. autoMode false. LIVE_APPLY false.
 * CHEAP_EARLY_EXIT_PAPER false (fail-closed). Never ENABLE_STRATEGY.
 * Never CHANGE_EV_FLOOR. Never re-enable PAPER_SCALP.
 */
import { isCheapSideMidWindow } from "../cheap-side-15m.js";
import { PERSIST_LAG_MIN_HOLD_MS } from "../tick-replay-backtest.js";
import { mtfFightsSide } from "../intra-scalp-replay.js";
import { LOTTERY_ASK_MAX_CENTS, LOTTERY_ASK_MIN_CENTS, LOTTERY_LAST_SECS } from "./skip.js";
import { decideHoldOrSell, type HoldSellAction, type HoldSellInput } from "../hold-sell.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;
/** Fail-closed. Bot does not fill. Env cannot sneak a take. */
export const CHEAP_EARLY_EXIT_PAPER = false as const;

/** Research cell band 7–22 (fail-closed; never live fill). Not desk door 20–55. */
export const CHEAP_EARLY_ASK_MIN_CENTS = 7;
export const CHEAP_EARLY_ASK_MAX_CENTS = 22;
/** Fair-now persist. 15s still-cheap clock, not the killed 60s hold-to-settle. */
export const CHEAP_EARLY_PERSIST_MS = PERSIST_LAG_MIN_HOLD_MS;
/** Sell when executable bid is this many cents above entry. Tape: 8¢ > 20¢ on 7–22. */
export const CHEAP_EARLY_GREEN_CENTS = 8;
export const CHEAP_EARLY_TIME_STOP_SECS = 90;
export const CHEAP_EARLY_HOLD_DEFAULT: HoldSellAction = "SELL";

export type CheapEarlyHa = {
  color: "green" | "red";
  consecutive?: number;
};

export type CheapEarlyOpts = {
  side: "yes" | "no";
  askCents: number;
  secsRemaining: number;
  /** Consecutive ms projectedSettlement has agreed with this side of the floor. */
  msFairAgree: number;
  mtf?: number;
  ha?: CheapEarlyHa | null;
  floor?: number | null;
  projectedSettlement?: number | null;
};

export type CheapEarlyDecision = {
  take: boolean;
  reason: string;
  holdDefault: HoldSellAction;
};

function skip(reason: string): CheapEarlyDecision {
  return { take: false, reason, holdDefault: CHEAP_EARLY_HOLD_DEFAULT };
}

export function isCheapEarlyAsk(ask: number): boolean {
  return Number.isFinite(ask)
    && ask >= CHEAP_EARLY_ASK_MIN_CENTS
    && ask <= CHEAP_EARLY_ASK_MAX_CENTS;
}

export function isCheapEarlyLottery(ask: number, secsRemaining: number): boolean {
  return Number.isFinite(ask)
    && Number.isFinite(secsRemaining)
    && ask >= LOTTERY_ASK_MIN_CENTS
    && ask <= LOTTERY_ASK_MAX_CENTS
    && secsRemaining <= LOTTERY_LAST_SECS;
}

/** YES + red HA, or NO + green HA. Missing HA is not fighting. */
export function haFightsSide(side: "yes" | "no", ha?: CheapEarlyHa | null): boolean {
  if (!ha) return false;
  if (side === "yes" && ha.color === "red") return true;
  if (side === "no" && ha.color === "green") return true;
  return false;
}

function fairAgrees(side: "yes" | "no", floor?: number | null, proj?: number | null): boolean | null {
  if (!(typeof floor === "number" && floor > 0)) return null;
  if (!(typeof proj === "number" && proj > 0)) return null;
  return side === "yes" ? proj > floor : proj < floor;
}

/**
 * Never HOLD_SETTLE. Reuses decideHoldOrSell with CHEAP_EARLY_EXIT id
 * (green 8¢ / 2× / 90s). Does not tag CHEAP_SIDE_15M.
 */
export function cheapEarlyHold(
  input: Omit<HoldSellInput, "strategyId"> & { strategyId?: string },
) {
  return decideHoldOrSell({
    ...input,
    strategyId: input.strategyId ?? "CHEAP_EARLY_EXIT",
  });
}

/**
 * Shadow predicate. Caller passes already-measured persist ms.
 * Does not size, place, or mutate BotConfig. Does NOT require settlement EV
 * or the correct settle side (fair-now ≠ settle).
 */
export function shouldCheapEarlyExitTake(opts: CheapEarlyOpts): CheapEarlyDecision {
  if (LIVE_APPLY || LIVE_APPLY_ENABLED) {
    return skip("live_apply_refused");
  }
  if (!isCheapEarlyAsk(opts.askCents)) {
    return skip("ask_not_7_22");
  }
  if (isCheapEarlyLottery(opts.askCents, opts.secsRemaining)) {
    return skip("lottery_7_12_last_150s");
  }
  const minLeft = opts.secsRemaining / 60;
  if (!isCheapSideMidWindow(minLeft)) {
    return skip("window");
  }
  if (!(opts.msFairAgree >= CHEAP_EARLY_PERSIST_MS)) {
    return skip("persist_lt_15s");
  }
  const agreed = fairAgrees(opts.side, opts.floor, opts.projectedSettlement);
  if (agreed === false) {
    return skip("fair_disagree");
  }
  if (haFightsSide(opts.side, opts.ha)) {
    return skip("ha_fighting");
  }
  if (mtfFightsSide(opts.side, opts.mtf ?? 0)) {
    return skip("mtf_fights");
  }
  return { take: true, reason: "cheap_early_exit", holdDefault: CHEAP_EARLY_HOLD_DEFAULT };
}

export function cheapEarlyExitPaperMayFill(): boolean {
  if (LIVE_APPLY || LIVE_APPLY_ENABLED) return false;
  if (CHEAP_EARLY_EXIT_PAPER) return false;
  const env = process.env.CHEAP_EARLY_EXIT_PAPER;
  if (env === "true" || env === "1") return false;
  return false;
}
