/**
 * Read/propose-only chat inspection. Prompts and proposal lint never authorize
 * filesystem mutations, tests or process control on the running host.
 */
import fs from "node:fs";
import path from "node:path";
import type { SpawnSyncReturns } from "node:child_process";
import { fileURLToPath } from "node:url";

export const LIVE_REAL_MONEY_PHRASE = "LIVE REAL MONEY";
export const WRITE_SOURCE_EXTS = [".ts", ".tsx", ".md", ".json"] as const;
export const CHAT_CODE_EDIT_TOOLS = [
  "read_file",
  "list_dir",
  "list_files",
  "grep",
  "search",
  "get_paper_ledger",
  "get_bot_config",
  "tail_tape",
] as const;
export type ChatCodeEditToolName = (typeof CHAT_CODE_EDIT_TOOLS)[number];

export type ChatSpawnFn = (
  command: string,
  args: readonly string[],
  options: { cwd?: string; encoding?: BufferEncoding; timeout?: number; maxBuffer?: number; env?: NodeJS.ProcessEnv },
) => SpawnSyncReturns<string>;

const HERE = path.dirname(fileURLToPath(import.meta.url));

export function defaultDeskRoot(): string {
  return resolveDeskRoot();
}

/**
 * R2 — desk root = nearest ancestor with pnpm-workspace.yaml. The old fixed
 * `HERE/../../../../` was right for src/lib but on Fly the server runs from
 * the esbuild bundle (apps/api-server/dist/index.mjs), where it resolved to
 * "/" — chat code tools then listed the host root ("I'm not seeing the desk
 * source files"). CHAT_DESK_ROOT still wins.
 */
export function resolveDeskRoot(env: NodeJS.ProcessEnv = process.env, starts: string[] = [HERE, process.cwd()]): string {
  const forced = (env.CHAT_DESK_ROOT ?? "").trim();
  if (forced) return path.resolve(forced);
  for (const start of starts) {
    let dir = path.resolve(start);
    for (let i = 0; i < 8; i++) {
      if (fs.existsSync(path.join(dir, "pnpm-workspace.yaml"))) return dir;
      const up = path.dirname(dir);
      if (up === dir) break;
      dir = up;
    }
  }
  return path.resolve(HERE, "../../../../");
}

export type ChatCodeReject = { ok: false; refused: true; reason: string; path?: string };
export type ChatCodeAccept<T extends Record<string, unknown> = Record<string, unknown>> = {
  ok: true;
  refused: false;
  summary: string;
} & T;
export type ChatCodeOutcome = ChatCodeReject | ChatCodeAccept;

export function hasLiveRealMoneyInUserMessage(userMessage: string): boolean {
  return userMessage.includes(LIVE_REAL_MONEY_PHRASE);
}

const SECRET_BASENAME = /^(?:\.env(?:\..*)?|.*(?:private_key|oraclekey).*\.pem|id_rsa|id_ed25519)$/i;
const SECRET_PATH_HINT = /(?:^|\/)(?:\.env(?:\..*)?|secrets?(?:\/|$)|credentials?(?:\/|$)|oraclekey(?:\.[a-z]+)?$)/i;

export function isSecretPath(rel: string): boolean {
  const n = rel.replace(/\\/g, "/").replace(/^\/+/, "");
  // Metadata/config files are private even when not named .env. Block hidden
  // components, credential stores and common backup variants at every depth.
  return n.split("/").some(component =>
    (component.startsWith(".") && component !== ".")
    || /(?:credential|secret|private[_-]?key|token|password)/i.test(component)
    || SECRET_BASENAME.test(component)
    || SECRET_PATH_HINT.test(component)
    || /\.(?:pem|key)(?:\..*)?$/i.test(component));
}

export function isWritableSourcePath(rel: string): boolean {
  if (isSecretPath(rel)) return false;
  const n = rel.replace(/\\/g, "/").replace(/^\/+/, "");
  if (n.split("/").some((p) => p === "node_modules" || p === ".git")) return false;
  const ext = path.posix.extname(n).toLowerCase();
  return (WRITE_SOURCE_EXTS as readonly string[]).includes(ext);
}

function countRe(src: string, re: RegExp): number {
  return [...src.matchAll(new RegExp(re.source, "g"))].length;
}

function introducedPaperModeFalse(before: string, after: string): boolean {
  const falseRe = /\bpaperMode\s*[:=]\s*false\b|\bPAPER_MODE\s*=\s*false\b/;
  const trueRe = /\bpaperMode\s*[:=]\s*true\b|\bPAPER_MODE\s*=\s*true\b/g;
  if (countRe(after, /\bpaperMode\s*[:=]\s*false\b/g) > countRe(before, /\bpaperMode\s*[:=]\s*false\b/g)) {
    return true;
  }
  if (countRe(after, /\bPAPER_MODE\s*=\s*false\b/g) > countRe(before, /\bPAPER_MODE\s*=\s*false\b/g)) {
    return true;
  }
  if (countRe(after, trueRe) < countRe(before, trueRe) && falseRe.test(after)) {
    return true;
  }
  const beforeLines = new Set(before.replace(/\r\n/g, "\n").split("\n").map((l) => l.trim()));
  for (const line of after.replace(/\r\n/g, "\n").split("\n")) {
    if (falseRe.test(line) && !beforeLines.has(line.trim())) return true;
  }
  return false;
}

type DeskPath = { ok: true; abs: string; rel: string; identity?: { dev: number; ino: number }; kind?: 'file' | 'directory' };

function resolveInspectionPath(relRaw: string, deskRoot: string, configOnly = false): DeskPath | ChatCodeReject {
  const refuse = (reason: string): ChatCodeReject => ({ ok: false, refused: true, reason });
  try {
    const rel = String(relRaw ?? "").trim().replace(/\\/g, "/");
    const root = path.resolve(deskRoot);
    if (!rel || rel.includes("\0") || path.isAbsolute(rel) || rel.split("/").includes("..")) {
      return refuse("Path escape refused");
    }
    if (root === path.parse(root).root || fs.realpathSync(root) !== root || !fs.statSync(root).isDirectory()) {
      return refuse("Unsafe desk root refused");
    }
    const abs = path.resolve(root, rel);
    const canonicalRel = path.relative(root, abs).replace(/\\/g, "/") || ".";
    const configException = configOnly && (canonicalRel === "apps/api-server/.bot-config.json" || canonicalRel === "apps/api-server/data/.bot-config.json");
    if (!configException && (isSecretPath(rel) || isSecretPath(canonicalRel))) {
      return refuse("Private metadata / .env / keys source read refused");
    }
    let cursor = root;
    const rootStat = fs.lstatSync(root);
    if (!rootStat.isDirectory()) return refuse("Desk root changed during inspection");
    let identity: DeskPath['identity'] = abs === root ? { dev: rootStat.dev, ino: rootStat.ino } : undefined;
    let kind: DeskPath['kind'] = abs === root ? 'directory' : undefined;
    for (const component of canonicalRel.split("/").filter(p => p !== ".")) {
      cursor = path.join(cursor, component);
      let stat: fs.Stats;
      try { stat = fs.lstatSync(cursor); } catch (e) {
        // Missing files remain a clean result for optional telemetry getters.
        if ((e as NodeJS.ErrnoException).code === "ENOENT") break;
        throw e;
      }
      if (stat.isSymbolicLink() || (!stat.isDirectory() && (!stat.isFile() || stat.nlink !== 1))) {
        return refuse("Symlink, hardlink or special-file inspection refused");
      }
      if (cursor === abs) {
        identity = { dev: stat.dev, ino: stat.ino };
        kind = stat.isDirectory() ? 'directory' : 'file';
      }
    }
    return { ok: true, abs, rel: canonicalRel, identity, kind };
  } catch {
    return refuse("Path inspection failed closed");
  }
}

export function resolveDeskFile(relRaw: string, deskRoot = defaultDeskRoot()): DeskPath | ChatCodeReject {
  return resolveInspectionPath(relRaw, deskRoot);
}

// Use an open descriptor and verify the checked identity before reading. Reads
// never follow a final symlink, block on a FIFO, or consume unbounded source.
const MAX_SOURCE_BYTES = 1_048_576;
function openInspectionHandle({ abs, identity: expected }: DeskPath, directory = false): { fd: number; size: number } {
  if (!expected) throw new Error("Not an inspected filesystem object");
  const flags = fs.constants.O_RDONLY | fs.constants.O_NOFOLLOW | fs.constants.O_NONBLOCK
    | (directory ? fs.constants.O_DIRECTORY : 0);
  const fd = fs.openSync(abs, flags);
  try {
    const actual = fs.fstatSync(fd);
    const validType = directory ? actual.isDirectory() : actual.isFile() && actual.nlink === 1;
    if (!validType || actual.dev !== expected.dev || actual.ino !== expected.ino) {
      throw new Error("File changed during inspection");
    }
    // The walk itself can race: a parent may become a symlink before its child
    // is inspected, making both recorded and opened identities external. Check
    // the actual descriptor, not a second pathname lookup. Our Linux host must
    // expose procfs; unsupported/unavailable descriptor verification denies.
    if (fs.realpathSync(`/proc/self/fd/${fd}`) !== abs) {
      throw new Error("Opened descriptor is outside its authorized path");
    }
    return { fd, size: actual.size };
  } catch (e) { fs.closeSync(fd); throw e; }
}
function readInspectionText(resolved: DeskPath): string {
  const { fd, size } = openInspectionHandle(resolved);
  try {
    if (size > MAX_SOURCE_BYTES) throw new Error("Inspection byte limit exceeded");
    const bytes = Buffer.alloc(size);
    const read = fs.readSync(fd, bytes, 0, size, 0);
    return bytes.subarray(0, read).toString("utf8");
  } finally { fs.closeSync(fd); }
}

function readInspectionDirectory(resolved: DeskPath): fs.Dirent[] {
  const { fd } = openInspectionHandle(resolved, true);
  try {
    // Enumerate the verified directory itself, never a mutable pathname. A
    // temporary symlink swap during readdir cannot redirect this descriptor.
    return fs.readdirSync(`/proc/self/fd/${fd}`, { withFileTypes: true });
  } finally { fs.closeSync(fd); }
}

function numAssign(src: string, name: string): number | null {
  const re = new RegExp(
    `(?:export\\s+)?(?:const|let|var)\\s+${name}\\s*=\\s*([0-9]*\\.?[0-9]+)`,
  );
  const m = src.match(re);
  if (m) return Number(m[1]);
  const re2 = new RegExp(`${name}\\s*[:=]\\s*([0-9]*\\.?[0-9]+)`);
  const m2 = src.match(re2);
  return m2 ? Number(m2[1]) : null;
}

function hasPaperModeFalse(src: string): boolean {
  return /\bpaperMode\s*[:=]\s*false\b/.test(src) || /\bPAPER_MODE\s*=\s*false\b/.test(src);
}

function hasPaperModeTrue(src: string): boolean {
  return /\bpaperMode\s*[:=]\s*true\b/.test(src) || /\bPAPER_MODE\s*=\s*true\b/.test(src);
}

function kellyTopCap(src: string): number | null {
  const fn = src.match(/function\s+kellyFraction[\s\S]{0,500}?\)\s*:\s*number\s*\{([\s\S]{0,400})\}/);
  const body = fn?.[1] ?? src;
  const m = body.match(/\?\s*(0\.\d+)/);
  return m ? Number(m[1]) : null;
}

const ENABLE_TRUE_RES: { re: RegExp; label: string }[] = [
  { re: /\bLIVE_APPLY(?:_ENABLED)?\s*=\s*true\b/, label: "LIVE_APPLY" },
  { re: /\bPAPER_SCALP_FEE_NET_BEATS_SKIP\s*=\s*true\b/, label: "PAPER_SCALP" },
  { re: /\bSETTLEMENT_LAG_ENABLED_DEFAULT\s*=\s*true\b/, label: "SETTLEMENT_LAG" },
  { re: /\bPERSIST_MID_LAGFLIP_ENABLED_DEFAULT\s*=\s*true\b/, label: "persist-mid" },
  { re: /\bCHEAP_PERSIST_SELL_ENABLED_DEFAULT\s*=\s*true\b/, label: "cheap-persist" },
  { re: /\bPANIC_FADE_ENABLED_DEFAULT\s*=\s*true\b/, label: "panic fade" },
  { re: /\bpanicFadeEnabled\s*[:=]\s*true\b/, label: "panic fade" },
  { re: /\benable1H(?:Contracts|Live)\s*[:=]\s*true\b/, label: "hourly" },
  { re: /\bPERPS_LIVE_TRADING_DISABLED\s*=\s*false\b/, label: "perps" },
  { re: /\bperpsLive\s*[:=]\s*true\b/, label: "perps" },
  { re: /\buseExpertAgent\s*[:=]\s*true\b/, label: "ARIA" },
  { re: /\bsettlementConsensusVoteEnabled\s*[:=]\s*true\b/, label: "SP" },
  { re: /\bcheapEarlyExitEnabled\s*[:=]\s*true\b/, label: "cheap-persist" },
  { re: /\botm(?:Asymmetry|Breakout)?Enabled\s*[:=]\s*true\b/i, label: "OTM" },
  { re: /\bENABLE_(?:SEV1|OTM|SP|PAPER_SCALP|HOURLY|PERPS|SETTLEMENT_LAG)\s*=\s*true\b/i, label: "ENABLE" },
];

const SEV1_IDS = [
  "BRTI_PROBABILITY",
  "MTF_ALIGNED",
  "SAKATA_CANDLE_PATTERN",
  "DEEP_OTM_SNIPER",
  "OTM_ASYMMETRY",
  "OTM_BREAKOUT_EXPANSION",
  "SETTLEMENT_PREDICTION",
] as const;

const KEY_ASSIGN = /(?:^|\n)\s*(?:export\s+)?(?:GEMINI_API_KEY|GOOGLE_GENERATIVE_AI_API_KEY|GROQ_API_KEY|OPENROUTER_API_KEY|AI_INTEGRATIONS_OPENROUTER_API_KEY|XAI_API_KEY|KALSHI_(?:PRIVATE_KEY|API_KEY)|BOT_API_KEY|SESSION_SECRET|DATABASE_URL)\s*=\s*["']?[^\s"']+/;
const PRIVATE_KEY_BLOCK = /-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----/;
const PRINT_ENV = /console\.(?:log|info|debug|error|warn)\s*\(\s*(?:process\.env|['"`]\.env)/;

export function scanProposedEdit(opts: {
  relPath: string;
  before: string;
  after: string;
  userMessage: string;
}): ChatCodeReject | { ok: true } {
  const { relPath, before, after, userMessage } = opts;
  if (isSecretPath(relPath)) {
    return { ok: false, refused: true, reason: ".env / keys print-or-rewrite refused", path: relPath };
  }
  if (
    (PRIVATE_KEY_BLOCK.test(after) && !PRIVATE_KEY_BLOCK.test(before))
    || (KEY_ASSIGN.test(after) && !KEY_ASSIGN.test(before))
    || (PRINT_ENV.test(after) && !PRINT_ENV.test(before))
  ) {
    return { ok: false, refused: true, reason: ".env / keys print-or-rewrite refused", path: relPath };
  }
  if (introducedPaperModeFalse(before, after)) {
    return {
      ok: false,
      refused: true,
      reason: "paperMode false refused (LIVE REAL MONEY required; Chat never writes it)",
      path: relPath,
    };
  }
  if (hasPaperModeTrue(before) && !hasPaperModeTrue(after) && !hasLiveRealMoneyInUserMessage(userMessage)) {
    return {
      ok: false,
      refused: true,
      reason: "removing paperMode true refused without LIVE REAL MONEY in the same user message",
      path: relPath,
    };
  }

  const evAfter = numAssign(after, "EV_FLOOR");
  if (evAfter != null && evAfter < 3) {
    return { ok: false, refused: true, reason: "EV floor below 3¢ refused", path: relPath };
  }
  const kelly = kellyTopCap(after);
  const kellyBefore = kellyTopCap(before);
  if (kelly != null && kelly < 0.60 && (kellyBefore == null || kelly < kellyBefore || kellyBefore >= 0.60)) {
    return { ok: false, refused: true, reason: "Kelly cap below 0.60 refused", path: relPath };
  }
  const risk = numAssign(after, "maxRiskPctPerTrade");
  const riskBefore = numAssign(before, "maxRiskPctPerTrade");
  if (risk != null && risk < 0.09 && (riskBefore == null || risk < riskBefore || riskBefore >= 0.09)) {
    return { ok: false, refused: true, reason: "9% cap lower refused", path: relPath };
  }
  const reserve = numAssign(after, "reservePct");
  if (reserve != null && reserve < 15) {
    return { ok: false, refused: true, reason: "15% reserve lower refused", path: relPath };
  }
  const haltPct = numAssign(after, "DAILY_HALT_PCT");
  const haltBefore = numAssign(before, "DAILY_HALT_PCT");
  if (haltPct != null && haltPct < 0.10 && (haltBefore == null || haltPct < haltBefore || haltBefore >= 0.10)) {
    return { ok: false, refused: true, reason: "daily halt lower refused", path: relPath };
  }
  const haltFloor = numAssign(after, "DAILY_HALT_FLOOR_CENTS");
  if (haltFloor != null && haltFloor < 3000 && numAssign(before, "DAILY_HALT_FLOOR_CENTS") === 3000) {
    return { ok: false, refused: true, reason: "daily halt lower refused", path: relPath };
  }
  if (
    /function\s+dailyHaltTrips[\s\S]{0,200}return\s+false/.test(after)
    && !/function\s+dailyHaltTrips[\s\S]{0,200}return\s+false/.test(before)
  ) {
    return { ok: false, refused: true, reason: "daily halt disable refused", path: relPath };
  }

  for (const { re, label } of ENABLE_TRUE_RES) {
    if (re.test(after) && !re.test(before)) {
      return { ok: false, refused: true, reason: `ENABLE ${label} refused`, path: relPath };
    }
  }

  if (/disabledStrategies/.test(before) || /disabledStrategies/.test(after)) {
    for (const id of SEV1_IDS) {
      if (before.includes(id) && !after.includes(id)) {
        return { ok: false, refused: true, reason: `ENABLE ${id} (SEV1/OTM/SP) refused`, path: relPath };
      }
    }
  }

  // Textual numeric matching is not a JavaScript evaluator. Fail closed for
  // any changed source that contains a protected risk identifier, including
  // signed/computed values, bracket properties, compound writes and multiline
  // expressions. Even unrelated edits in risk-bearing files need review.
  // This remains advisory lint: every host mutation is independently denied.
  const protectedRisk = /\b(?:EV_FLOOR|reservePct|maxRiskPctPerTrade|DAILY_HALT_PCT|DAILY_HALT_FLOOR_CENTS|dailyHaltTrips|kellyFraction)\b/;
  if (before !== after && (protectedRisk.test(before) || protectedRisk.test(after))) {
    return { ok: false, refused: true, reason: "Protected risk source edit refused; separate human review required", path: relPath };
  }
  return { ok: true };
}

function uniqueReplace(content: string, oldStr: string, newStr: string): ChatCodeReject | { ok: true; next: string } {
  if (!oldStr) return { ok: false, refused: true, reason: "apply_patch old_string required" };
  const parts = content.split(oldStr);
  const count = parts.length - 1;
  if (count === 0) {
    return { ok: false, refused: true, reason: "apply_patch: old_string not found (copy verbatim from read_file)" };
  }
  if (count > 1) {
    return { ok: false, refused: true, reason: `apply_patch: old_string appears ${count} times — add surrounding context` };
  }
  return { ok: true, next: parts.join(newStr) };
}

/**
 * Minimal unified-diff apply for a single file (context / +/- lines).
 * Fail-closed on mismatch — never writes a half patch.
 */
export function applyUnifiedPatch(original: string, patch: string): ChatCodeReject | { ok: true; next: string } {
  let body = patch.replace(/\r\n/g, "\n");
  const begin = body.indexOf("*** Begin Patch");
  if (begin >= 0) {
    const end = body.indexOf("*** End Patch");
    body = body.slice(begin, end >= 0 ? end : undefined);
    body = body.replace(/^\*\*\* (?:Begin|End) Patch.*$/gm, "").replace(/^\*\*\* (?:Update|Add) File:.*$/gm, "");
  }
  const lines = body.split("\n");
  const origLines = original.replace(/\r\n/g, "\n").split("\n");
  const out: string[] = [];
  let oi = 0;
  let i = 0;
  let sawHunk = false;
  while (i < lines.length) {
    const line = lines[i] ?? "";
    if (line.startsWith("---") || line.startsWith("+++") || line.startsWith("diff ") || line.startsWith("index ")) {
      i += 1;
      continue;
    }
    if (line.startsWith("@@")) {
      sawHunk = true;
      const m = line.match(/@@\s*-(\d+)(?:,\d+)?\s+\+(\d+)(?:,\d+)?\s*@@/);
      const oldStart = m ? Number(m[1]) - 1 : oi;
      if (oldStart < 0 || oldStart > origLines.length) {
        return { ok: false, refused: true, reason: "apply_patch: hunk out of range" };
      }
      while (oi < oldStart) {
        out.push(origLines[oi] ?? "");
        oi += 1;
      }
      i += 1;
      continue;
    }
    if (!sawHunk) {
      i += 1;
      continue;
    }
    if (line.startsWith(" ")) {
      const expect = line.slice(1);
      if ((origLines[oi] ?? "") !== expect) {
        return { ok: false, refused: true, reason: "apply_patch: context mismatch" };
      }
      out.push(expect);
      oi += 1;
      i += 1;
      continue;
    }
    if (line.startsWith("-")) {
      const expect = line.slice(1);
      if ((origLines[oi] ?? "") !== expect) {
        return { ok: false, refused: true, reason: "apply_patch: delete mismatch" };
      }
      oi += 1;
      i += 1;
      continue;
    }
    if (line.startsWith("+")) {
      out.push(line.slice(1));
      i += 1;
      continue;
    }
    if (line === "\\ No newline at end of file" || line.trim() === "") {
      i += 1;
      continue;
    }
    return { ok: false, refused: true, reason: "apply_patch: unreadable patch line" };
  }
  if (!sawHunk) {
    return { ok: false, refused: true, reason: "apply_patch: no hunks" };
  }
  while (oi < origLines.length) {
    out.push(origLines[oi] ?? "");
    oi += 1;
  }
  return { ok: true, next: out.join("\n") };
}

export function readDeskFile(
  relPath: string,
  deskRoot = defaultDeskRoot(),
  opts?: { startLine?: number; endLine?: number },
): ChatCodeOutcome {
  try {
    const resolved = resolveDeskFile(relPath, deskRoot);
    if (!resolved.ok) return resolved;
    if (!fs.existsSync(resolved.abs) || !fs.statSync(resolved.abs).isFile()) {
      return { ok: false, refused: true, reason: `File not found: ${resolved.rel}`, path: resolved.rel };
    }
    const raw = readInspectionText(resolved);
    const lines = raw.split("\n");
    const start = opts?.startLine != null && Number.isFinite(opts.startLine)
      ? Math.max(1, Math.floor(opts.startLine))
      : 1;
    const end = opts?.endLine != null && Number.isFinite(opts.endLine)
      ? Math.min(lines.length, Math.floor(opts.endLine))
      : lines.length;
    const slice = lines.slice(start - 1, Math.max(start - 1, end));
    const numbered = slice.map((l, i) => `${start + i}|${l}`).join("\n");
    const truncated = numbered.length > 80_000 ? numbered.slice(0, 80_000) + "\n…[truncated — pass start_line/end_line]" : numbered;
    return {
      ok: true,
      refused: false,
      summary: `${resolved.rel} lines ${start}–${start + slice.length - 1} of ${lines.length}`,
      path: resolved.rel,
      content: truncated,
      totalBytes: raw.length,
      totalLines: lines.length,
    };
  } catch {
    return { ok: false, refused: true, reason: "read_file failed (desk hiccup, no write)" };
  }
}

export function listDeskFiles(relPath: string, deskRoot = defaultDeskRoot(), recursive = false): ChatCodeOutcome {
  try {
    const rel = (relPath || ".").trim() || ".";
    const resolved = resolveDeskFile(rel, deskRoot);
    if (!resolved.ok) return resolved;
    if (!fs.existsSync(resolved.abs)) {
      return { ok: false, refused: true, reason: `Path not found: ${resolved.rel}`, path: resolved.rel };
    }
    const skip = new Set(["node_modules", ".git", "dist", ".cache", "__pycache__"]);
    const lines: string[] = [];
    const walk = (inspected: DeskPath, depth: number) => {
      if (depth > 4) return;
      const dir = inspected.abs;
      let entries: fs.Dirent[] = [];
      try { entries = readInspectionDirectory(inspected); } catch { return; }
      for (const e of entries) {
        if (skip.has(e.name)) continue;
        const checked = resolveDeskFile(path.relative(path.resolve(deskRoot), path.join(dir, e.name)), deskRoot);
        if (e.isSymbolicLink() || !checked.ok || !checked.identity) continue;
        const indent = "  ".repeat(depth);
        if (e.isDirectory()) {
          lines.push(`${indent}${e.name}/`);
          if (recursive) walk(checked, depth + 1);
        } else {
          lines.push(`${indent}${e.name}`);
        }
      }
    };
    if (resolved.kind === 'directory') walk(resolved, 0);
    else {
      const { fd } = openInspectionHandle(resolved);
      fs.closeSync(fd);
      lines.push(resolved.rel);
    }
    return {
      ok: true,
      refused: false,
      summary: `${resolved.rel}: ${lines.length} entries`,
      path: resolved.rel,
      tree: lines.slice(0, 400),
    };
  } catch {
    return { ok: false, refused: true, reason: "list_files failed (desk hiccup, no write)" };
  }
}

function refuseMutation(): ChatCodeReject {
  return { ok: false, refused: true, reason: "Chat is read/propose-only; writes and process execution require a separate approved worker" };
}

export function writeDeskFile(_opts: { relPath: string; content: string; userMessage: string; deskRoot?: string }): ChatCodeOutcome {
  return refuseMutation();
}
export function applyDeskPatch(_opts: {
  relPath: string; userMessage: string; oldString?: string; newString?: string; patch?: string; deskRoot?: string;
}): ChatCodeOutcome {
  return refuseMutation();
}

export function grepDeskFiles(opts: {
  pattern: string;
  relPath?: string;
  deskRoot?: string;
  glob?: string;
}): ChatCodeOutcome {
  try {
    const deskRoot = opts.deskRoot ?? defaultDeskRoot();
    const pattern = String(opts.pattern ?? "").trim();
    if (!pattern || pattern.length > 200) {
      return { ok: false, refused: true, reason: "grep: pattern required (max 200 chars)" };
    }
    // This is a source-inspection boundary, so model/user input is search text,
    // not executable regex. Escaping keeps the existing case-insensitive search
    // while preventing nested quantifiers (for example `(a+)+$`) from blocking
    // the server through catastrophic backtracking.
    const re = new RegExp(pattern.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
    const rel = (opts.relPath || ".").trim() || ".";
    const resolved = resolveDeskFile(rel, deskRoot);
    if (!resolved.ok) return resolved;
    if (!fs.existsSync(resolved.abs)) {
      return { ok: false, refused: true, reason: `Path not found: ${resolved.rel}`, path: resolved.rel };
    }
    const skip = new Set(["node_modules", ".git", "dist", ".cache", "__pycache__"]);
    const extOk = new Set([".ts", ".tsx", ".md", ".json", ".mjs", ".js", ".css", ".yml", ".yaml"]);
    const glob = (opts.glob ?? "").trim().toLowerCase();
    const hits: string[] = [];
    const walk = (inspected: DeskPath, depth: number) => {
      if (depth > 6 || hits.length >= 200) return;
      const dir = inspected.abs;
      let entries: fs.Dirent[] = [];
      try { entries = readInspectionDirectory(inspected); } catch { return; }
      for (const e of entries) {
        if (hits.length >= 200) return;
        if (skip.has(e.name) || isSecretPath(e.name)) continue;
        const abs = path.join(dir, e.name);
        const relFile = path.relative(path.resolve(deskRoot), abs).replace(/\\/g, "/");
        const checked = resolveDeskFile(relFile, deskRoot);
        if (!checked.ok || !checked.identity) continue;
        if (e.isDirectory()) {
          walk(checked, depth + 1);
          continue;
        }
        if (!e.isFile()) continue;
        const ext = path.posix.extname(e.name).toLowerCase();
        if (!extOk.has(ext)) continue;
        if (glob && !e.name.toLowerCase().includes(glob.replace("*", ""))) continue;
        let raw = "";
        try { raw = readInspectionText(checked); } catch { continue; }
        const lines = raw.split("\n");
        for (let i = 0; i < lines.length && hits.length < 200; i++) {
          if (re.test(lines[i] ?? "")) {
            const line = (lines[i] ?? "").slice(0, 240);
            hits.push(`${relFile}:${i + 1}:${line}`);
          }
        }
      }
    };
    if (resolved.kind === 'directory') walk(resolved, 0);
    else {
      const raw = readInspectionText(resolved);
      raw.split("\n").forEach((line, i) => {
        if (hits.length < 200 && re.test(line)) hits.push(`${resolved.rel}:${i + 1}:${line.slice(0, 240)}`);
      });
    }
    return {
      ok: true,
      refused: false,
      summary: `${hits.length} match(es) for ${JSON.stringify(pattern)}`,
      path: resolved.rel,
      matches: hits,
    };
  } catch {
    return { ok: false, refused: true, reason: "grep failed (desk hiccup, no write)" };
  }
}

const API_SERVER_TEST = /^(?:apps\/api-server\/)?src\/(?:[A-Za-z0-9._-]+\/)*[A-Za-z0-9._-]+\.test\.ts$/;

export function normalizeApiServerTestPath(relRaw: string): ChatCodeReject | { ok: true; rel: string } {
  let rel = String(relRaw ?? "").trim().replace(/\\/g, "/").replace(/^\/+/, "");
  if (!rel) {
    return { ok: false, refused: true, reason: "run_tests: path to one apps/api-server **/*.test.ts required" };
  }
  if (rel.split("/").some((p) => p === ".." || p === "node_modules")) {
    return { ok: false, refused: true, reason: "run_tests: path escape refused", path: rel };
  }
  if (isSecretPath(rel)) {
    return { ok: false, refused: true, reason: ".env / keys print-or-rewrite refused", path: rel };
  }
  if (rel.startsWith("src/")) rel = `apps/api-server/${rel}`;
  if (!API_SERVER_TEST.test(rel) && !API_SERVER_TEST.test(rel.replace(/^apps\/api-server\//, ""))) {
    return {
      ok: false,
      refused: true,
      reason: "run_tests: only a single apps/api-server/src/**/*.test.ts file (no general spawn)",
      path: rel,
    };
  }
  if (!rel.startsWith("apps/api-server/")) rel = `apps/api-server/${rel.replace(/^apps\/api-server\//, "")}`;
  if (!rel.endsWith(".test.ts") || !rel.startsWith("apps/api-server/src/")) {
    return {
      ok: false,
      refused: true,
      reason: "run_tests: only a single apps/api-server/src/**/*.test.ts file (no general spawn)",
      path: rel,
    };
  }
  return { ok: true, rel };
}

export function runApiServerTests(_opts: { relPath: string; deskRoot?: string; spawn?: ChatSpawnFn }): ChatCodeOutcome {
  return refuseMutation();
}

function redactConfig(raw: unknown): unknown {
  if (raw == null || typeof raw !== "object") return raw;
  if (Array.isArray(raw)) return raw.map(redactConfig);
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (/key|secret|token|password|pem|private/i.test(k)) {
      out[k] = "[redacted]";
    } else {
      out[k] = redactConfig(v);
    }
  }
  return out;
}

function getPaperLedgerTool(deskRoot: string): ChatCodeOutcome {
  const rel = "apps/api-server/data/paper-ledger.json";
  const resolved = resolveDeskFile(rel, deskRoot);
  if (!resolved.ok) return resolved;
  try {
    const text = readInspectionText(resolved);
    return {
      ok: true,
      refused: false,
      summary: "paper ledger (virtualCents, not Kalshi cash)",
      path: rel,
      json: JSON.parse(text) as unknown,
    };
  } catch {
    return { ok: false, refused: true, reason: "paper ledger unreadable" };
  }
}

function getBotConfigTool(deskRoot: string): ChatCodeOutcome {
  // PR #11 moved the running config onto the volume (data/); legacy cwd file as fallback.
  const volumeRel = "apps/api-server/data/.bot-config.json";
  const rel = fs.existsSync(path.resolve(deskRoot, volumeRel)) ? volumeRel : "apps/api-server/.bot-config.json";
  const resolved = resolveInspectionPath(rel, deskRoot, true);
  if (!resolved.ok) return resolved;
  try {
    const parsed = JSON.parse(readInspectionText(resolved)) as unknown;
    return {
      ok: true,
      refused: false,
      summary: "bot config (secrets redacted; paperMode must stay true)",
      path: rel,
      json: redactConfig(parsed),
    };
  } catch {
    return { ok: false, refused: true, reason: "bot config unreadable" };
  }
}

function tailTapeTool(deskRoot: string, nRaw: unknown): ChatCodeOutcome {
  const rel = "apps/api-server/data/paper-bar-tape.jsonl";
  const resolved = resolveDeskFile(rel, deskRoot);
  if (!resolved.ok) return resolved;
  const requested = Number(nRaw);
  const n = Number.isFinite(requested) ? Math.min(40, Math.max(1, Math.floor(requested || 20))) : 20;
  try {
    if (!fs.existsSync(resolved.abs)) {
      return { ok: true, refused: false, summary: "paper-bar-tape.jsonl missing (no bars logged yet)", lines: [] };
    }
    const { fd, size } = openInspectionHandle(resolved);
    let text: string;
    const start = Math.max(0, size - 65_536);
    try {
      const bytes = Buffer.alloc(Math.min(size, 65_536));
      const read = fs.readSync(fd, bytes, 0, bytes.length, start);
      text = bytes.subarray(0, read).toString("utf8");
    } finally { fs.closeSync(fd); }
    // Drop a potentially partial first record and any uncommitted final record.
    if (start > 0) text = text.includes("\n") ? text.slice(text.indexOf("\n") + 1) : "";
    text = text.slice(0, text.lastIndexOf("\n") + 1);
    const lines = text.split("\n").map(line => line.replace(/\r$/, "")).filter(Boolean);
    const slice = lines.slice(-n);
    return {
      ok: true,
      refused: false,
      summary: `last ${slice.length} paper-bar-tape lines`,
      path: rel,
      lines: slice,
    };
  } catch {
    return { ok: false, refused: true, reason: "tape unreadable" };
  }
}

export const BOUNCE_DESK_API_SCRIPT = "/workspace/bin/bounce-desk-api.sh";

/** Exact word `bounce` after trim; case-insensitive. */
export function isBounceChatCommand(text: string): boolean {
  return String(text ?? "").trim().toLowerCase() === "bounce";
}

/** Process control is never authorized by a chat command or model output. */
export function scheduleDeskApiBounce(_opts: { spawn?: ChatSpawnFn; scriptPath?: string } = {}): ChatCodeOutcome {
  return refuseMutation();
}

export function runChatCodeTool(
  name: string,
  args: Record<string, unknown>,
  opts: { userMessage: string; deskRoot?: string; spawn?: ChatSpawnFn },
): ChatCodeOutcome {
  const deskRoot = opts.deskRoot ?? defaultDeskRoot();
  const userMessage = opts.userMessage ?? "";
  try {
    switch (name) {
      case "read_file":
        return readDeskFile(String(args.path ?? ""), deskRoot, {
          startLine: args.start_line != null ? Number(args.start_line) : undefined,
          endLine: args.end_line != null ? Number(args.end_line) : undefined,
        });
      case "list_dir":
      case "list_files":
        return listDeskFiles(String(args.path ?? "."), deskRoot, Boolean(args.recursive));
      case "grep":
      case "search":
      case "search_code":
        return grepDeskFiles({
          pattern: String(args.pattern ?? args.query ?? ""),
          relPath: args.path != null ? String(args.path) : ".",
          deskRoot,
          glob: args.glob != null ? String(args.glob) : undefined,
        });
      case "write_file":
      case "apply_patch":
      case "run_tests":
      case "bounce_api":
        return refuseMutation();
      case "get_paper_ledger":
        return getPaperLedgerTool(deskRoot);
      case "get_bot_config":
        return getBotConfigTool(deskRoot);
      case "tail_tape":
        return tailTapeTool(deskRoot, args.n ?? args.lines);
      case "run_shell":
        return { ok: false, refused: true, reason: "run_shell refused (no general spawn)" };
      case "update_config":
      case "toggle_strategy":
      case "force_exit_trade":
      case "control_bot":
      case "reset_paper_sim":
      case "run_backtest":
        return { ok: false, refused: true, reason: `${name} refused (locks: paper, no force_exit from Chat, no ENABLE)` };
      default:
        return { ok: false, refused: true, reason: `Unknown chat code tool: ${name}` };
    }
  } catch {
    return { ok: false, refused: true, reason: "tool failed clean (no write)" };
  }
}

export const GEMINI_CODE_EDIT_DECLARATIONS = [
  {
    name: "read_file",
    description: "Read a UTF-8 source file under the desk. Use start_line/end_line for large files (e.g. trading-bot.ts). .env/keys refused.",
    parameters: {
      type: "OBJECT",
      properties: {
        path: { type: "STRING", description: "Relative path from desk root" },
        start_line: { type: "NUMBER", description: "1-based start line" },
        end_line: { type: "NUMBER", description: "1-based end line inclusive" },
      },
      required: ["path"],
    },
  },
  {
    name: "list_dir",
    description: "List files under a desk directory (skips node_modules, .git, .env).",
    parameters: {
      type: "OBJECT",
      properties: {
        path: { type: "STRING", description: "Directory relative to desk root" },
        recursive: { type: "BOOLEAN" },
      },
    },
  },
  {
    name: "grep",
    description: "Search desk source for case-insensitive literal text (skips node_modules, .env/keys). Alias: search.",
    parameters: {
      type: "OBJECT",
      properties: {
        pattern: { type: "STRING", description: "Literal text" },
        path: { type: "STRING", description: "Directory or file relative to desk root" },
        glob: { type: "STRING", description: "Optional filename substring filter" },
      },
      required: ["pattern"],
    },
  },
  {
    name: "get_paper_ledger",
    description: "Read paper virtualCents ledger JSON. This is NOT Kalshi cash. Never mix them.",
    parameters: { type: "OBJECT", properties: {} },
  },
  {
    name: "get_bot_config",
    description: "Read running .bot-config.json with secrets redacted. paperMode must stay true.",
    parameters: { type: "OBJECT", properties: {} },
  },
  {
    name: "tail_tape",
    description: "Last N lines of paper-bar-tape.jsonl (skip reasons / evaluate). Default 20, max 40.",
    parameters: {
      type: "OBJECT",
      properties: { n: { type: "NUMBER", description: "How many trailing bars (1-40)" } },
    },
  },
] as const;
