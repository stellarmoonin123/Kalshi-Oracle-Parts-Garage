/**
 * Scar-Echo Learning (SEL) — signature Oracle / Kalshi-15m learning.
 *
 * Not generic RL. Scars bind Oracle Mind state at entry to fee-net vs skip
 * at close/settle. Echoes surface similar scars on later ticks.
 *
 * Bounded updates only — NEVER cut EV/Kelly/ask/floors; NEVER ENABLE leftovers;
 * NEVER LLM on tick. Skip is a valid teacher.
 */
import { existsSync, mkdirSync, appendFileSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";
import { deskDataPath } from "../desk-data-dir.js";

export const SCAR_ECHO_LOADED = "SCAR_ECHO_LOADED" as const;
export const SCAR_ECHO_N_SOFT = 20 as const;
export const SCAR_ECHO_N_PROMOTE = 40 as const;
export const SCAR_ECHO_LEARNING_STARVED_N = 10 as const;

/** Floors SEL never proposes to cut. */
export const SEL_FLOOR_LOCKS = {
  evFloorCents: 3,
  kellyCap: 0.6,
  maxRiskPctPerTrade: 0.09,
  reservePctFloor: 15,
  askMinCents: 20,
  askMaxCents: 55,
} as const;

export type AskBand = "low" | "mid" | "high" | "out";

export type ScarEntryBind = {
  conflicts: string[];
  councilResolved: string | null;
  horizonPhase: string | null;
  diagnosis: string | null;
  /**
   * Fill-side decision (TAKE_YES/TAKE_NO on fill scars; SKIP on skip-teacher).
   * Not the mind council vote — see councilResolved + scarAdvisoryOnly.
   */
  decisionKind: string;
  /**
   * True when mind council resolved SKIP/HEAVE but fill still took.
   * Claim honesty: council was advisory; did not block the fill.
   */
  scarAdvisoryOnly?: boolean;
  /** Explicit mismatch flag: council SKIP-like ∧ decisionKind TAKE_*. */
  councilFillMismatch?: boolean;
  frozenCc: boolean;
  strategyId: string | null;
  side: "yes" | "no";
  askBand: AskBand;
  askCents: number | null;
};

/** Council resolved looks like SKIP/HEAVE (advisory, not fill authority under frozen). */
export function councilResolvedIsSkipLike(resolved: string | null | undefined): boolean {
  if (resolved == null) return false;
  const r = String(resolved).trim().toUpperCase();
  if (!r) return false;
  return (
    r === "SKIP"
    || r === "ABSTAIN"
    || r === "HEAVE_TO"
    || r.includes("SKIP")
    || r.includes("HEAVE")
  );
}

/** Stamp advisory/mismatch honesty onto a fill bind. */
export function stampScarFillHonesty(
  bind: ScarEntryBind,
): Pick<ScarEntryBind, "scarAdvisoryOnly" | "councilFillMismatch"> {
  const take =
    bind.decisionKind === "TAKE_YES"
    || bind.decisionKind === "TAKE_NO"
    || /^TAKE_/i.test(bind.decisionKind);
  const skipLike = councilResolvedIsSkipLike(bind.councilResolved);
  const mismatch = take && skipLike;
  return {
    scarAdvisoryOnly: mismatch,
    councilFillMismatch: mismatch,
  };
}

export type Scar = {
  id: string;
  openedAtMs: number;
  closedAtMs: number | null;
  bind: ScarEntryBind;
  /** fee-net cents vs skip≈0; negative = take hurt vs sitting. */
  feeNetVsSkipCents: number | null;
  outcome: "win" | "loss" | "skip_teacher" | "flat" | null;
  status: "open" | "closed";
  /** Causal settle attribution (PhD layer). */
  sideCorrect?: boolean | null;
  exitSavedWrongSide?: boolean | null;
  settledSide?: "yes" | "no" | null;
  exitReason?: string | null;
  /** Side-picker learning weight from causal attribution. */
  sidePickerWeight?: number | null;
};

export type ScarEcho = {
  n: number;
  meanFeeNetVsSkip: number;
  wr: number;
  salience: number;
  advice: string;
  matchKey: string;
  conflictCodes: string[];
  side: "yes" | "no" | null;
  horizonPhase: string | null;
};

export type WeightDelta = {
  conflictCode: string;
  /** Additive council skip weight bump (clamped). Soft when n≥20. */
  councilSkipWeightDelta: number;
  /** Tactical veto confidence bump 0..1 (clamped). Soft when n≥20. */
  tacticalVetoConfidenceDelta: number;
  /** Advisory promote when n≥40 and mean clearly worse when ignored. */
  promoteHint: boolean;
  n: number;
  meanFeeNetVsSkip: number;
  reason: string;
};

export type ScarRingState = {
  scars: Scar[];
};

const RING_MAX = 256;
const ECHO_TOP = 3;
const WEIGHT_SKIP_SOFT = 0.05;
const WEIGHT_SKIP_PROMOTE = 0.12;
const WEIGHT_VETO_SOFT = 0.05;
const WEIGHT_VETO_PROMOTE = 0.1;
const WEIGHT_DELTA_CLAMP = 0.15;

/** Empirical-Bayes prior strength (shrinkage toward 0 until n grows). */
export const EB_PRIOR_STRENGTH = 12 as const;
/** Max |councilSkipWeightDelta| from EB nudge. */
export const EB_WEIGHT_CLAMP = 0.12 as const;

let scarRing: Scar[] = [];

export function resetScarEchoForTests(): void {
  scarRing = [];
}

export function getScarRing(): readonly Scar[] {
  return scarRing;
}

export function askBandFromCents(ask: number | null | undefined): AskBand {
  if (!(typeof ask === "number" && Number.isFinite(ask))) return "out";
  if (ask < 20 || ask > 55) return "out";
  if (ask <= 32) return "low";
  if (ask <= 44) return "mid";
  return "high";
}

/** Match key: top conflict codes (sorted) + side + horizon phase. */
export function scarMatchKey(bind: Pick<ScarEntryBind, "conflicts" | "side" | "horizonPhase">): string {
  const codes = [...(bind.conflicts ?? [])]
    .filter(Boolean)
    .map(String)
    .sort();
  const top = codes.slice(0, 3).join("|") || "NONE";
  const side = bind.side === "no" ? "no" : "yes";
  const hz = bind.horizonPhase && String(bind.horizonPhase).trim()
    ? String(bind.horizonPhase)
    : "unknown";
  return `${top}::${side}::${hz}`;
}

export function recordScar(
  bind: ScarEntryBind,
  opts?: { id?: string; openedAtMs?: number; ring?: Scar[] },
): Scar {
  const scar: Scar = {
    id: opts?.id ?? randomUUID(),
    openedAtMs: opts?.openedAtMs ?? Date.now(),
    closedAtMs: null,
    bind: {
      conflicts: [...(bind.conflicts ?? [])],
      councilResolved: bind.councilResolved ?? null,
      horizonPhase: bind.horizonPhase ?? null,
      diagnosis: bind.diagnosis ?? null,
      decisionKind: bind.decisionKind,
      scarAdvisoryOnly: bind.scarAdvisoryOnly === true,
      councilFillMismatch: bind.councilFillMismatch === true,
      frozenCc: bind.frozenCc === true,
      strategyId: bind.strategyId ?? null,
      side: bind.side === "no" ? "no" : "yes",
      askBand: bind.askBand ?? askBandFromCents(bind.askCents),
      askCents: typeof bind.askCents === "number" ? bind.askCents : null,
    },
    feeNetVsSkipCents: null,
    outcome: null,
    status: "open",
  };
  if (opts?.ring) {
    opts.ring.push(scar);
    if (opts.ring.length > RING_MAX) opts.ring.splice(0, opts.ring.length - RING_MAX);
  } else {
    scarRing = updateScarRing(scarRing, scar);
  }
  return scar;
}

/** Pure ring append. */
export function updateScarRing(ring: readonly Scar[], scar: Scar, max = RING_MAX): Scar[] {
  const next = [...ring, scar];
  if (next.length > max) return next.slice(next.length - max);
  return next;
}

/**
 * Tattoo fee-net vs skip on close/settle.
 * skip_teacher: skipped proposal that would have lost → positive scar for SKIP
 * (feeNetVsSkipCents > 0 means sitting beat taking).
 */
export function closeScar(
  scarId: string,
  tattoo: {
    feeNetVsSkipCents: number;
    outcome?: "win" | "loss" | "skip_teacher" | "flat" | null;
    closedAtMs?: number;
    sideCorrect?: boolean | null;
    exitSavedWrongSide?: boolean | null;
    settledSide?: "yes" | "no" | null;
    exitReason?: string | null;
    sidePickerWeight?: number | null;
  },
  ring?: Scar[],
): Scar | null {
  const target = ring ?? scarRing;
  const idx = target.findIndex((s) => s.id === scarId);
  if (idx < 0) return null;
  const prev = target[idx]!;
  const closed: Scar = {
    ...prev,
    closedAtMs: tattoo.closedAtMs ?? Date.now(),
    feeNetVsSkipCents: Math.round(tattoo.feeNetVsSkipCents),
    outcome: tattoo.outcome ?? classifyOutcome(tattoo.feeNetVsSkipCents),
    status: "closed",
    sideCorrect: tattoo.sideCorrect ?? prev.sideCorrect ?? null,
    exitSavedWrongSide: tattoo.exitSavedWrongSide ?? prev.exitSavedWrongSide ?? null,
    settledSide: tattoo.settledSide ?? prev.settledSide ?? null,
    exitReason: tattoo.exitReason ?? prev.exitReason ?? null,
    sidePickerWeight: tattoo.sidePickerWeight ?? prev.sidePickerWeight ?? null,
  };
  target[idx] = closed;
  if (!ring) scarRing = [...target];
  return closed;
}

function classifyOutcome(feeNetVsSkip: number): "win" | "loss" | "flat" {
  if (feeNetVsSkip > 0) return "win";
  if (feeNetVsSkip < 0) return "loss";
  return "flat";
}

/**
 * Record a skip-teacher scar: proposal was skipped; counterfactual take would
 * have lost → feeNetVsSkip positive (sitting won).
 */
export function recordSkipTeacherScar(
  bind: ScarEntryBind,
  wouldHaveLostCents: number,
  opts?: { openedAtMs?: number; ring?: Scar[] },
): Scar {
  const scar = recordScar(
    { ...bind, decisionKind: bind.decisionKind || "SKIP" },
    opts,
  );
  const saved = Math.abs(wouldHaveLostCents);
  return (
    closeScar(
      scar.id,
      {
        feeNetVsSkipCents: saved,
        outcome: "skip_teacher",
        closedAtMs: opts?.openedAtMs ?? Date.now(),
      },
      opts?.ring,
    ) ?? scar
  );
}

/** Closed scars only for echo matching. */
export function closedScars(ring: readonly Scar[] = scarRing): Scar[] {
  return ring.filter(
    (s) =>
      s.status === "closed" &&
      typeof s.feeNetVsSkipCents === "number" &&
      Number.isFinite(s.feeNetVsSkipCents),
  );
}

/**
 * Match echoes for current mind bind — similar conflict codes + side + horizon.
 * Returns top echoes by salience (n * |mean|).
 */
export function matchEchoes(
  query: Pick<ScarEntryBind, "conflicts" | "side" | "horizonPhase">,
  ring: readonly Scar[] = scarRing,
  topN = ECHO_TOP,
): ScarEcho[] {
  const closed = closedScars(ring);
  if (closed.length === 0) return [];

  const qKey = scarMatchKey(query);
  const qCodes = new Set((query.conflicts ?? []).map(String));
  const qSide = query.side === "no" ? "no" : "yes";
  const qHz = query.horizonPhase ?? "unknown";

  // Bucket by match key; also soft-match on overlapping conflict + side
  const buckets = new Map<string, Scar[]>();
  for (const s of closed) {
    const key = scarMatchKey(s.bind);
    const exact = key === qKey;
    const overlap =
      s.bind.side === qSide &&
      (s.bind.horizonPhase ?? "unknown") === qHz &&
      (s.bind.conflicts ?? []).some((c) => qCodes.has(c));
    const noneQuery = qCodes.size === 0 && (s.bind.conflicts?.length ?? 0) === 0 && s.bind.side === qSide;
    if (!exact && !overlap && !noneQuery) continue;
    const bucketKey = exact ? key : `soft::${key}`;
    const arr = buckets.get(bucketKey) ?? [];
    arr.push(s);
    buckets.set(bucketKey, arr);
  }

  const echoes: ScarEcho[] = [];
  for (const [matchKey, scars] of buckets) {
    const n = scars.length;
    const sum = scars.reduce((a, s) => a + (s.feeNetVsSkipCents ?? 0), 0);
    const mean = n > 0 ? Math.round((sum / n) * 10) / 10 : 0;
    const wins = scars.filter((s) => (s.feeNetVsSkipCents ?? 0) > 0 || s.outcome === "skip_teacher").length;
    const wr = n > 0 ? Math.round((wins / n) * 100) / 100 : 0;
    const salience = Math.min(1, Math.round((n * Math.min(1, Math.abs(mean) / 200) + (exactBoost(matchKey, qKey) ? 0.2 : 0)) * 100) / 100);
    const codes = [...new Set(scars.flatMap((s) => s.bind.conflicts ?? []))].slice(0, 5);
    echoes.push({
      n,
      meanFeeNetVsSkip: mean,
      wr,
      salience,
      advice: echoAdvice(mean, n, wr),
      matchKey: matchKey.replace(/^soft::/, ""),
      conflictCodes: codes,
      side: qSide,
      horizonPhase: qHz === "unknown" ? null : qHz,
    });
  }

  echoes.sort((a, b) => b.salience - a.salience || b.n - a.n);
  return echoes.slice(0, topN);
}

function exactBoost(bucketKey: string, qKey: string): boolean {
  return bucketKey === qKey || bucketKey.replace(/^soft::/, "") === qKey;
}

function echoAdvice(mean: number, n: number, wr: number): string {
  if (n < SCAR_ECHO_N_SOFT) {
    return `INSUFFICIENT_DATA n=${n}<${SCAR_ECHO_N_SOFT} — echo advisory only`;
  }
  if (mean < -50) {
    return n >= SCAR_ECHO_N_PROMOTE
      ? `PROMOTE_SKIP — mean fee-net vs skip ${mean}¢ (n=${n}); prefer veto`
      : `SOFT_SKIP_LEAN — mean ${mean}¢ (n=${n}); raise skip weight`;
  }
  if (mean > 50 && wr >= 0.55) {
    return `ECHO_SUPPORTIVE — similar scars mean +${mean}¢ (n=${n}); take not proven bad`;
  }
  return `ECHO_NEUTRAL — mean ${mean}¢ wr=${wr} n=${n}`;
}

/**
 * Bounded weight deltas from closed scars grouped by conflict code.
 * Clamped; never touches floors / ENABLE / paperMode.
 */
export function suggestWeightDeltas(
  ring: readonly Scar[] = scarRing,
): WeightDelta[] {
  const closed = closedScars(ring);
  const byCode = new Map<string, number[]>();
  for (const s of closed) {
    const codes = s.bind.conflicts?.length ? s.bind.conflicts : ["NONE"];
    for (const c of codes) {
      const arr = byCode.get(c) ?? [];
      arr.push(s.feeNetVsSkipCents ?? 0);
      byCode.set(c, arr);
    }
  }
  const out: WeightDelta[] = [];
  for (const [conflictCode, vals] of byCode) {
    const n = vals.length;
    if (n < SCAR_ECHO_N_SOFT) continue;
    const mean = vals.reduce((a, b) => a + b, 0) / n;
    const meanR = Math.round(mean * 10) / 10;
    // Clearly worse when conflict present and taken (negative fee-net vs skip)
    const worse = meanR < -40;
    if (!worse) continue;
    const soft = n >= SCAR_ECHO_N_SOFT && n < SCAR_ECHO_N_PROMOTE;
    const promote = n >= SCAR_ECHO_N_PROMOTE;
    const skipD = clamp(
      promote ? WEIGHT_SKIP_PROMOTE : WEIGHT_SKIP_SOFT,
      0,
      WEIGHT_DELTA_CLAMP,
    );
    const vetoD = clamp(
      promote ? WEIGHT_VETO_PROMOTE : WEIGHT_VETO_SOFT,
      0,
      WEIGHT_DELTA_CLAMP,
    );
    out.push({
      conflictCode,
      councilSkipWeightDelta: skipD,
      tacticalVetoConfidenceDelta: vetoD,
      promoteHint: promote,
      n,
      meanFeeNetVsSkip: meanR,
      reason: promote
        ? `n≥${SCAR_ECHO_N_PROMOTE} meanFeeNetVsSkip=${meanR}¢ — promoteHint skip/veto`
        : `n≥${SCAR_ECHO_N_SOFT} meanFeeNetVsSkip=${meanR}¢ — soft skip lean`,
    });
  }
  return out.sort((a, b) => a.meanFeeNetVsSkip - b.meanFeeNetVsSkip);
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

function defaultScarPath(): string {
  return deskDataPath("scar-echo.jsonl");
}


/**
 * Empirical-Bayes posterior lean on a conflict code's fee-net sample.
 * Shrinkage toward 0: μ_post = (κ·0 + n·μ̂) / (κ + n), κ = EB_PRIOR_STRENGTH.
 * Weight deltas clamped to ±EB_WEIGHT_CLAMP. Never touches floors / ENABLE.
 *
 * When causal sidePickerWeight provided per obs, use weighted mean (settle
 * mistakes count more than TP-saved wrong sides).
 */
export type EmpiricalBayesNudge = {
  conflictCode: string;
  n: number;
  rawMean: number;
  posteriorMean: number;
  shrinkage: number;
  councilSkipWeightDelta: number;
  reason: string;
};

export function empiricalBayesScarNudge(
  conflictCode: string,
  feeNets: readonly number[],
  opts?: {
    priorStrength?: number;
    weightClamp?: number;
    /** Optional per-obs weights (same length as feeNets). */
    weights?: readonly number[] | null;
  },
): EmpiricalBayesNudge {
  const kappa = opts?.priorStrength ?? EB_PRIOR_STRENGTH;
  const wClamp = opts?.weightClamp ?? EB_WEIGHT_CLAMP;
  const n = feeNets.length;
  if (n === 0) {
    return {
      conflictCode,
      n: 0,
      rawMean: 0,
      posteriorMean: 0,
      shrinkage: 1,
      councilSkipWeightDelta: 0,
      reason: "n=0 — full shrink to 0",
    };
  }
  let sum = 0;
  let wSum = 0;
  for (let i = 0; i < n; i++) {
    const w = opts?.weights?.[i] ?? 1;
    sum += feeNets[i]! * w;
    wSum += w;
  }
  const rawMean = wSum > 0 ? sum / wSum : 0;
  const posteriorMean = (kappa * 0 + n * rawMean) / (kappa + n);
  const shrinkage = kappa / (kappa + n);
  // Negative posterior (take hurt vs skip) → positive skip lean
  let delta = 0;
  if (posteriorMean < -20) {
    delta = Math.min(wClamp, ((-posteriorMean) / 400) * (1 - shrinkage));
  } else if (posteriorMean > 40) {
    // Supportive scars — tiny negative skip lean (do not force take)
    delta = -Math.min(wClamp * 0.35, (posteriorMean / 800) * (1 - shrinkage));
  }
  delta = Math.max(-wClamp, Math.min(wClamp, Math.round(delta * 1000) / 1000));
  return {
    conflictCode,
    n,
    rawMean: Math.round(rawMean * 10) / 10,
    posteriorMean: Math.round(posteriorMean * 10) / 10,
    shrinkage: Math.round(shrinkage * 1000) / 1000,
    councilSkipWeightDelta: delta,
    reason: `EB κ=${kappa} n=${n} μ̂=${Math.round(rawMean * 10) / 10} μ_post=${Math.round(posteriorMean * 10) / 10} shrink=${Math.round(shrinkage * 1000) / 1000}`,
  };
}

/** EB nudges for all conflict codes present in closed scars (incl. n&lt;20). */
export function empiricalBayesWeightNudges(
  ring: readonly Scar[] = scarRing,
): EmpiricalBayesNudge[] {
  const closed = closedScars(ring);
  const byCode = new Map<string, { fees: number[]; weights: number[] }>();
  for (const s of closed) {
    const codes = s.bind.conflicts?.length ? s.bind.conflicts : ["NONE"];
    const w = typeof s.sidePickerWeight === "number" ? s.sidePickerWeight : 1;
    for (const c of codes) {
      const bucket = byCode.get(c) ?? { fees: [], weights: [] };
      bucket.fees.push(s.feeNetVsSkipCents ?? 0);
      bucket.weights.push(w);
      byCode.set(c, bucket);
    }
  }
  const out: EmpiricalBayesNudge[] = [];
  for (const [conflictCode, { fees, weights }] of byCode) {
    out.push(empiricalBayesScarNudge(conflictCode, fees, { weights }));
  }
  return out.sort((a, b) => a.posteriorMean - b.posteriorMean);
}

/** Persist one scar line (best-effort). */
export function persistScar(scar: Scar, filePath?: string): void {
  try {
    const file = filePath ?? defaultScarPath();
    const dir = path.dirname(file);
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    appendFileSync(file, `${JSON.stringify(scar)}\n`, "utf8");
  } catch {
    /* never block settle */
  }
}

/** Load JSONL into ring (startup / tests). */
export function loadScarsFromDisk(filePath?: string): number {
  try {
    const file = filePath ?? defaultScarPath();
    if (!existsSync(file)) return 0;
    const lines = readFileSync(file, "utf8").split("\n").filter(Boolean);
    let n = 0;
    for (const line of lines) {
      try {
        const s = JSON.parse(line) as Scar;
        if (s && typeof s.openedAtMs === "number" && s.bind) {
          scarRing = updateScarRing(scarRing, s);
          n += 1;
        }
      } catch {
        /* skip */
      }
    }
    return n;
  } catch {
    return 0;
  }
}

/** Snapshot for brainMind.learning.scarEcho */
export function scarEchoLearningSnapshot(ring: readonly Scar[] = scarRing): {
  scarCount: number;
  closedCount: number;
  openCount: number;
  starved: boolean;
  weightDeltas: WeightDelta[];
  empiricalBayes: EmpiricalBayesNudge[];
  doctrine: {
    nSoft: number;
    nPromote: number;
    starvedBelow: number;
    floorsUncut: true;
    noLlmOnTick: true;
  };
} {
  const closed = closedScars(ring);
  const open = ring.filter((s) => s.status === "open");
  return {
    scarCount: ring.length,
    closedCount: closed.length,
    openCount: open.length,
    starved: closed.length < SCAR_ECHO_LEARNING_STARVED_N,
    weightDeltas: suggestWeightDeltas(ring),
    empiricalBayes: empiricalBayesWeightNudges(ring),
    doctrine: {
      nSoft: SCAR_ECHO_N_SOFT,
      nPromote: SCAR_ECHO_N_PROMOTE,
      starvedBelow: SCAR_ECHO_LEARNING_STARVED_N,
      floorsUncut: true,
      noLlmOnTick: true,
    },
  };
}
