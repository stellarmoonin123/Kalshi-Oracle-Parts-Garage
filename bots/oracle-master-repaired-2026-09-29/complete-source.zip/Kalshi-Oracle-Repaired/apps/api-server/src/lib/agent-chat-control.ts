/**
 * In-app Chat (`/api/agent/chat`) ↔ agent control plane.
 * Deterministic wrappers — same semantics as `/api/bot/agent/*`.
 * No LLM on the fill hot path; tools call tradingBot + agent-control helpers.
 */
import { tradingBot, type BotConfig } from "./trading-bot.js";
import {
  AGENT_FLOORS,
  FORCE_EXIT_CONFIRM_PHRASE,
  filterAgentConfigPatch,
  parseDirective,
  refuseAgentAuthorityWhenNotPaper,
} from "./agent-control.js";

export const AGENT_CHAT_TOOL_NAMES = [
  "agent_status",
  "agent_directive",
  "agent_config",
  "agent_entry_approve",
  "agent_entry_reject",
  "agent_exit",
] as const;

export type AgentChatToolName = (typeof AGENT_CHAT_TOOL_NAMES)[number];

export function isAgentChatTool(name: string): name is AgentChatToolName {
  return (AGENT_CHAT_TOOL_NAMES as readonly string[]).includes(name);
}

/** OpenAI-style tool schemas for Oracle Agent TOOLS array. */
export const AGENT_CHAT_TOOL_DEFS = [
  {
    type: "function",
    function: {
      name: "agent_status",
      description:
        "Operator snapshot from the agent control plane: config flags " +
        "(agentControlMode, requireAgentEntryApproval, brainCenterAuthority, paperMode), " +
        "bot state, openTrade, brainCenter, pendingAgentEntry, directives (halt/sit/skip), floors. " +
        "Call this FIRST before any halt/approve/exit/config mutation.",
      parameters: { type: "object", properties: {} },
    },
  },
  {
    type: "function",
    function: {
      name: "agent_directive",
      description:
        "Sticky paper-only entry directive: HALT_ENTRIES | RESUME_ENTRIES | SKIP_NEXT | SIT_UNTIL_SECS. " +
        "Requires agentControlMode + paperMode. Prefer agent_status after applying.",
      parameters: {
        type: "object",
        properties: {
          type: {
            type: "string",
            enum: ["HALT_ENTRIES", "RESUME_ENTRIES", "SKIP_NEXT", "SIT_UNTIL_SECS"],
          },
          secs: {
            type: "number",
            description: "Required for SIT_UNTIL_SECS — seconds in (0, 3600]",
          },
          note: { type: "string", description: "Optional operator note" },
        },
        required: ["type"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "agent_config",
      description:
        "Allowlisted agent-plane config patch (always forces paperMode true). " +
        "Primary keys: agentControlMode, requireAgentEntryApproval, brainCenterAuthority, autopilotMode. " +
        "Also allowlisted: frozenCcMode, frozenCcAndSit, enabled, holdToSettlement, useStopLoss, " +
        "useProfitTake, strategyOverride. NEVER cuts EV/Kelly/9%/reserve floors. Never live.",
      parameters: {
        type: "object",
        properties: {
          changes: {
            type: "object",
            description:
              'e.g. {"agentControlMode":true,"brainCenterAuthority":true,"requireAgentEntryApproval":false}',
          },
        },
        required: ["changes"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "agent_entry_approve",
      description:
        "Approve a parked pendingAgentEntry (when requireAgentEntryApproval) → placeOrder if still fresh. " +
        "Pass id from agent_status.pendingAgentEntry.id. Paper + agentControlMode required.",
      parameters: {
        type: "object",
        properties: {
          id: { type: "string", description: "pendingAgentEntry id" },
        },
        required: ["id"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "agent_entry_reject",
      description:
        "Reject a parked pendingAgentEntry. Pass id from agent_status. Optional reason. Paper + agentControlMode required.",
      parameters: {
        type: "object",
        properties: {
          id: { type: "string" },
          reason: { type: "string" },
        },
        required: ["id"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "agent_exit",
      description:
        "Paper force-close open trade via agent control plane. " +
        'HARD CONFIRM: pass confirm="FORCE EXIT" (exact). Same gate as /api/bot/agent/exit.',
      parameters: {
        type: "object",
        properties: {
          confirm: {
            type: "string",
            description: 'Exact phrase "FORCE EXIT" required or the tool refuses.',
          },
        },
        required: ["confirm"],
      },
    },
  },
] as const;

export const AGENT_CHAT_TOOL_LABELS: Record<AgentChatToolName, string> = {
  agent_status: "Reading agent control status…",
  agent_directive: "Applying agent directive…",
  agent_config: "Updating agent control config…",
  agent_entry_approve: "Approving pending entry…",
  agent_entry_reject: "Rejecting pending entry…",
  agent_exit: "Force-exiting via agent plane…",
};

type ToolResult = { result: unknown; summary: string };

function refuseAgentControlOff(): ToolResult {
  return {
    result: {
      ok: false,
      refused: true,
      reason: "agentControlMode is false — enable via agent_config {agentControlMode:true} on paper first",
    },
    summary: "refused — agentControlMode false",
  };
}

function refuseNotPaper(action: string): ToolResult {
  return {
    result: {
      ok: false,
      refused: true,
      reason: `mutating agent command ${action} requires paperMode true`,
    },
    summary: `refused — ${action} needs paperMode`,
  };
}

function requireAgentControl(): ToolResult | null {
  if (tradingBot.config.agentControlMode !== true) return refuseAgentControlOff();
  return null;
}

function requirePaperMutate(action: string): ToolResult | null {
  if (tradingBot.config.paperMode !== true) return refuseNotPaper(action);
  return null;
}

export async function runAgentChatTool(
  name: AgentChatToolName,
  args: Record<string, unknown>,
): Promise<ToolResult> {
  switch (name) {
    case "agent_status": {
      const snap = tradingBot.getAgentControlSnapshot();
      const cfg = (snap.config ?? {}) as Record<string, unknown>;
      const dirs = (snap.directives ?? {}) as Record<string, unknown>;
      const pending = snap.pendingAgentEntry as { id?: string } | null | undefined;
      const summary = [
        `state=${String(snap.state ?? "?")}`,
        `paper=${cfg.paperMode === true}`,
        `agentControl=${cfg.agentControlMode === true}`,
        `brainAuth=${cfg.brainCenterAuthority === true}`,
        `requireApprove=${cfg.requireAgentEntryApproval === true}`,
        `halt=${dirs.haltEntries === true}`,
        `pending=${pending?.id ? pending.id.slice(0, 8) : "none"}`,
        `open=${snap.openTrade ? "yes" : "no"}`,
      ].join(" · ");
      return {
        result: { ok: true, ...snap, floors: AGENT_FLOORS },
        summary,
      };
    }

    case "agent_directive": {
      const gate = requireAgentControl() ?? requirePaperMutate("agent_directive");
      if (gate) return gate;
      const body: Record<string, unknown> = {
        type: args.type,
        note: args.note,
        secs: args.secs,
        sitSecs: args.sitSecs,
      };
      const parsed = parseDirective(body);
      if (!parsed.ok) {
        return { result: { ok: false, reason: parsed.reason }, summary: parsed.reason };
      }
      const state = tradingBot.applyAgentDirective(parsed.directive);
      return {
        result: { ok: true, directive: parsed.directive, directives: state },
        summary: `directive ${parsed.directive.type} applied · halt=${state.haltEntries} skip=${state.skipNextRemaining} sitUntil=${state.sitUntilMs ?? "none"}`,
      };
    }

    case "agent_config": {
      const changes = (args.changes ?? args) as Record<string, unknown>;
      const paper = tradingBot.config.paperMode === true;
      if (!paper) {
        return {
          result: { ok: false, refused: true, reason: "agent config requires paperMode true" },
          summary: "refused — agent_config needs paperMode",
        };
      }
      if (
        tradingBot.config.agentControlMode !== true &&
        changes.agentControlMode !== true
      ) {
        return {
          result: {
            ok: false,
            refused: true,
            reason:
              'agentControlMode is false — pass changes.agentControlMode=true once to arm the control plane',
          },
          summary: "refused — pass agentControlMode:true to arm",
        };
      }
      const { accepted, refused } = filterAgentConfigPatch(changes);
      const authorityGate = refuseAgentAuthorityWhenNotPaper(
        accepted as {
          agentControlMode?: boolean;
          requireAgentEntryApproval?: boolean;
          brainCenterAuthority?: boolean;
          paperMode?: boolean;
        },
        true,
      );
      if (!authorityGate.ok) {
        return {
          result: { ok: false, refused: true, reason: authorityGate.reason },
          summary: authorityGate.reason,
        };
      }
      if (Object.keys(accepted).length === 0) {
        return {
          result: { ok: false, refused, reason: "no allowlisted keys" },
          summary: "no allowlisted keys in agent_config",
        };
      }
      tradingBot.updateConfig({ ...accepted, paperMode: true } as Partial<BotConfig>);
      const config = {
        agentControlMode: tradingBot.config.agentControlMode === true,
        requireAgentEntryApproval: tradingBot.config.requireAgentEntryApproval === true,
        brainCenterAuthority: tradingBot.config.brainCenterAuthority === true,
        frozenCcMode: tradingBot.config.frozenCcMode === true,
        frozenCcAndSit: tradingBot.config.frozenCcAndSit === true,
        enabled: tradingBot.config.enabled === true,
        paperMode: tradingBot.config.paperMode === true,
      };
      return {
        result: { ok: true, config, refused, floors: AGENT_FLOORS },
        summary: `agent_config applied · agentControl=${config.agentControlMode} brainAuth=${config.brainCenterAuthority} requireApprove=${config.requireAgentEntryApproval}`,
      };
    }

    case "agent_entry_approve": {
      const gate = requireAgentControl() ?? requirePaperMutate("agent_entry_approve");
      if (gate) return gate;
      const id = typeof args.id === "string" ? args.id : "";
      if (!id) {
        return { result: { ok: false, reason: "id required" }, summary: "id required" };
      }
      const result = await tradingBot.approveAgentEntry(id);
      return {
        result,
        summary: result.ok
          ? `approved pending ${id.slice(0, 8)} · stamp=${result.stamp ?? "ok"}`
          : `approve failed: ${result.error ?? "unknown"}`,
      };
    }

    case "agent_entry_reject": {
      const gate = requireAgentControl() ?? requirePaperMutate("agent_entry_reject");
      if (gate) return gate;
      const id = typeof args.id === "string" ? args.id : "";
      if (!id) {
        return { result: { ok: false, reason: "id required" }, summary: "id required" };
      }
      const reason = typeof args.reason === "string" ? args.reason : undefined;
      const result = tradingBot.rejectAgentEntry(id, reason);
      return {
        result,
        summary: result.ok
          ? `rejected pending ${id.slice(0, 8)} · stamp=${result.stamp ?? "AGENT_REJECTED"}`
          : `reject failed: ${result.error ?? "unknown"}`,
      };
    }

    case "agent_exit": {
      const gate = requireAgentControl() ?? requirePaperMutate("agent_exit");
      if (gate) return gate;
      const confirm = args.confirm ?? args.confirmForceExit;
      if (confirm !== FORCE_EXIT_CONFIRM_PHRASE) {
        return {
          result: {
            ok: false,
            refused: true,
            needConfirm: FORCE_EXIT_CONFIRM_PHRASE,
            reason: `confirm must be exact phrase "${FORCE_EXIT_CONFIRM_PHRASE}"`,
          },
          summary: `agent_exit refused — confirm must be "${FORCE_EXIT_CONFIRM_PHRASE}"`,
        };
      }
      const result = await tradingBot.forceExitOpenTrade("MANUAL_FORCE_EXIT");
      return {
        result: {
          ok: result.ok,
          exitPriceCents: result.exitPriceCents,
          error: result.error,
          stamp: result.ok ? "AGENT_FORCE_EXIT" : undefined,
        },
        summary: result.ok
          ? `FORCE EXIT ok @ ${result.exitPriceCents}¢`
          : `FORCE EXIT failed: ${result.error ?? "unknown"}`,
      };
    }

    default: {
      const _exhaustive: never = name;
      return {
        result: { ok: false, reason: `unknown agent chat tool: ${String(_exhaustive)}` },
        summary: "unknown agent chat tool",
      };
    }
  }
}
