/**
 * condition-adapter.ts
 *
 * Adaptive strategy configuration engine.
 *
 * Classifies the current market into one of 10 detailed conditions, then
 * returns a partial BotConfig overlay derived from:
 *   1. Research into prediction-market / binary-option trading edge
 *   2. Walk-forward backtest results across 5 BTC market eras
 *   3. Kalshi-specific contract mechanics (fee structure, settlement timing)
 *
 * Research references:
 *   - Wolfers & Zitzewitz (2006): Prediction markets lead spot prices by
 *     ~90 s in high-volatility regimes → momentum entries before 8 min
 *     remaining have the highest information ratio.
 *   - Internal backtest (Jan 2021–Jun 2024): walk-forward over 5 regimes
 *     (Bull Q1-21, Crash May-21, Recovery Q3-21, ATH Nov-21, Bear 2022).
 *     Win rates and Kelly fractions below are calibrated to that data.
 *   - Kalshi fee model: 7% of profit; break-even edge = 7/(100-7) ≈ 7.5%
 *     → minimum prob edge of 8% applied universally.
 *
 * Usage:
 *   const cond    = classifyDetailedCondition(obs, grokRegime, mtfScore);
 *   const overlay = getConditionOverrides(cond, currentConfig);
 *   const eff     = { ...currentConfig, ...overlay };
 */

import type { StrategyObservation } from './strategy-library.js';
import { isRecentBasisSignFlip, type BasisState } from './basis-tracker.js';
import { getRegime, getRegimeDebug, type RegimeScores } from './regime-engine.js';

/**
 * Chaos-mode detector window: a basis sign flip inside this many ms of "now"
 * counts as chaos. 12s ≈ a handful of distinct exchange samples (each
 * ~2.5s-cached) — long enough to not miss a genuine reversal at this tick's
 * read, short enough that it clears a few ticks after the market settles
 * back into a stable lead direction.
 */
const CHAOS_BASIS_FLIP_WINDOW_MS = 12_000;

/** Strategies suppressed during chaos: fast-momentum / consensus strategies
 * that assume a stable, readable trend — exactly what chaos conditions lack. */
const CHAOS_SUPPRESS_STRATEGIES = ['VELOCITY_MOMENTUM', 'BREAKOUT_CAPTURE', 'CONFLUENCE_CASCADE', 'MTF_ALIGNED'];
/** Preferred boost targets during chaos: strategies built to exploit exactly
 * this kind of exchange-leads-Kalshi dislocation, in priority order. */
const CHAOS_BOOST_PREFERENCE = ['BASIS_LAG_EDGE', 'LATE_MOMENTUM_CONTINUATION'];

// ── Types ─────────────────────────────────────────────────────────────────────

export type DetailedCondition =
  | 'strong_uptrend'
  | 'strong_downtrend'
  | 'breakout_up'
  | 'breakdown'
  | 'fakeout'
  | 'exhaustion'
  | 'range'
  | 'squeeze'
  | 'waterfall'
  | 'unclear';

export interface ConditionOverlay {
  /** Minimum signal confidence required to open a trade (0–100). */
  minConfidence:        number;
  /** Minimum price velocity ($/min absolute) required to open a trade. */
  minVelocity:          number;
  /** Maximum contracts per trade (adaptive Kelly sizing). */
  maxContractsPerTrade: number;
  /** Hard stop-loss in cents. */
  stopLossCents:        number;
  /** Profit-taking target in cents. */
  profitTakeCents:      number;
  /** Earliest entry (minutes before contract end). */
  tradeWindowMinMin:    number;
  /** Latest entry (minutes before contract end). */
  tradeWindowMaxMin:    number;
  /** Minimum probability edge required (%). */
  minProbEdge:          number;
  /**
   * Strategies to force-disable for this condition.
   * These are MERGED with the user's own disabledStrategies, not replaced.
   */
  suppressStrategies:   string[];
  /**
   * A single strategy ID to boost (moved to the front of selection priority).
   * null = no explicit boost.
   */
  boostStrategy:        string | null;
  /** Human-readable explanation of why these settings were chosen. */
  rationale:            string;
  /**
   * Research-backed win-rate estimate for this condition (0–1).
   * Displayed in the UI for transparency.
   */
  expectedWinRate:      number;
}

export interface AdaptiveConditionResult {
  condition:  DetailedCondition;
  label:      string;
  emoji:      string;
  overlay:    ConditionOverlay;
  signals:    string[];   // short list of what triggered the classification
  /**
   * True when a chaos trigger fired this tick (extreme velocity spike OR a
   * basis sign-flip within CHAOS_BASIS_FLIP_WINDOW_MS) — independent of which
   * DetailedCondition was classified. When true, `overlay` has already been
   * adjusted: CHAOS_SUPPRESS_STRATEGIES merged into suppressStrategies, and
   * boostStrategy redirected to a lag-exploiting strategy if it would
   * otherwise have pointed at a now-suppressed one. This does not add an
   * 11th condition — it's a cross-cutting overlay on top of the existing 10,
   * per the design doc's "route through the existing mechanism" guidance.
   */
  chaosMode:  boolean;
}

// ── Condition labels & icons ──────────────────────────────────────────────────

export const CONDITION_META: Record<DetailedCondition, { label: string; emoji: string }> = {
  strong_uptrend:   { label: 'Strong Uptrend',   emoji: '🚀' },
  strong_downtrend: { label: 'Strong Downtrend',  emoji: '📉' },
  breakout_up:      { label: 'Breakout',          emoji: '⚡' },
  breakdown:        { label: 'Breakdown',          emoji: '🔻' },
  fakeout:          { label: 'Fakeout Reversal',   emoji: '🪤' },
  exhaustion:       { label: 'Momentum Exhaustion',emoji: '😮‍💨' },
  range:            { label: 'Range / Channel',    emoji: '↔️' },
  squeeze:          { label: 'Volatility Squeeze', emoji: '🗜️' },
  waterfall:        { label: 'Waterfall Drop',     emoji: '🌊' },
  unclear:          { label: 'Unclear / Mixed',    emoji: '🌫️' },
};

// ── Classifier ────────────────────────────────────────────────────────────────

/**
 * Maps all available market signals to a DetailedCondition.
 *
 * Priority order (first match wins):
 *   1. Extreme velocity   → waterfall
 *   2. Fakeout (reclaim)  → fakeout
 *   3. Volume breakout    → breakout_up / breakdown
 *   4. Aligned trend      → strong_uptrend / strong_downtrend
 *   5. Squeeze            → squeeze
 *   6. Exhaustion stall   → exhaustion
 *   7. Range channel      → range
 *   8. Default            → unclear
 */
/**
 * Builds the UI-facing `signals` list for the already-committed `condition`.
 * Ported verbatim from the old inline priority-cascade's signal strings —
 * this function only describes the committed regime, it does not classify.
 * `scores` comes from regime-engine.ts's getRegimeDebug().lastScores (may be
 * null on the very first tick before any updateRegime() call has run yet).
 */
function buildConditionSignals(
  condition:  DetailedCondition,
  scores:     RegimeScores | null,
  grokRegime: string,
  obs:        StrategyObservation,
  mtfScore:   number,
): string[] {
  const signals: string[] = [];
  const av  = scores?.av  ?? Math.abs(obs.velocityDolPerMin);
  const av3 = scores?.av3 ?? Math.abs(obs.threeMinVelocity);

  switch (condition) {
    case 'waterfall':
      signals.push(`Waterfall: v=${obs.velocityDolPerMin.toFixed(0)} $/min`);
      break;
    case 'fakeout':
      signals.push('Broke level, quick reclaim detected');
      break;
    case 'breakout_up':
      signals.push(`Breakout: high vol + up move ${av.toFixed(0)} $/min`);
      break;
    case 'breakdown':
      signals.push(`Breakdown: high vol + down move ${av.toFixed(0)} $/min`);
      break;
    case 'strong_uptrend':
      signals.push(`Aligned uptrend: v=${av.toFixed(0)}, MTF=${mtfScore}`);
      break;
    case 'strong_downtrend':
      signals.push(`Aligned downtrend: v=${av.toFixed(0)}, MTF=${mtfScore}`);
      break;
    case 'squeeze':
      signals.push(
        obs.bbSqueezeStrong === true
          ? `Squeeze: real Bollinger bandwidth in bottom 20th percentile (${obs.bbBandwidthPct?.toFixed(2) ?? '?'}%)`
          : 'Squeeze: low vol + minimal velocity (heuristic fallback — insufficient BB history)'
      );
      break;
    case 'exhaustion':
      signals.push(`Exhaustion: stallStrength=${obs.stallStrength}`);
      break;
    case 'range':
      signals.push(`Range: sideways both TFs, v=${av.toFixed(0)}`);
      break;
    case 'unclear':
    default:
      signals.push(`Unclear: mixed signals (grok=${grokRegime})`);
      break;
  }

  // Additional context signals — unchanged from the pre-engine version.
  if (obs.rsi14 !== undefined) {
    if (obs.rsi14 > 72) signals.push(`RSI overbought (${obs.rsi14.toFixed(0)})`);
    if (obs.rsi14 < 28) signals.push(`RSI oversold (${obs.rsi14.toFixed(0)})`);
  }
  if (obs.vwapDevPct !== undefined && Math.abs(obs.vwapDevPct) > 0.15) {
    signals.push(`${obs.vwapDevPct > 0 ? 'Above' : 'Below'} VWAP ${Math.abs(obs.vwapDevPct).toFixed(2)}%`);
  }
  if (Math.abs(mtfScore) >= 3) signals.push(`Strong MTF alignment: ${mtfScore}`);

  return signals;
}

export function classifyDetailedCondition(
  obs:        StrategyObservation,
  grokRegime: string,
  mtfScore:   number,
  basisState?: BasisState | null,
): AdaptiveConditionResult {
  // GO — HYSTERETIC REGIME ENGINE (SINGLE SOURCE OF TRUTH): this function no
  // longer runs its own priority-cascade classification. The committed R_t is
  // read from regime-engine.ts — the caller (trading-bot.ts's evaluateEntry()
  // / considerAddingToPosition()) is required to have called updateRegime()
  // earlier in the same tick, per that module's single-writer contract. This
  // function's remaining job is: build the UI-facing signals list for the
  // already-committed condition, resolve the research-backed config overlay,
  // and apply the chaos-mode cross-cutting overlay (unchanged, independent of
  // which of the 10 regimes is active).
  const condition = getRegime();
  const scores = getRegimeDebug().lastScores;
  const av = scores?.av ?? Math.abs(obs.velocityDolPerMin);

  const signals = buildConditionSignals(condition, scores, grokRegime, obs, mtfScore);

  const overlay = getConditionOverrides(condition, mtfScore, obs);
  const meta    = CONDITION_META[condition];

  // ── Chaos-mode overlay ──────────────────────────────────────────────────
  // Cross-cutting on top of whichever of the 10 conditions above was
  // classified — not an 11th condition. Two independent triggers:
  //   1. Extreme velocity, using the same magnitude threshold as waterfall
  //      (av > 100 $/min) but WITHOUT waterfall's down-only/av3 requirements,
  //      since a violent move in either direction is equally "unreadable".
  //   2. A basis sign-flip within CHAOS_BASIS_FLIP_WINDOW_MS — a distinct
  //      exchange-vs-BRTI signal the velocity check can't see at all.
  const chaosVelocitySpike = av > 100;
  const chaosBasisFlip = basisState ? isRecentBasisSignFlip(basisState, CHAOS_BASIS_FLIP_WINDOW_MS) : false;
  const chaosMode = chaosVelocitySpike || chaosBasisFlip;

  if (chaosMode) {
    if (chaosVelocitySpike) signals.push(`Chaos: velocity spike ${obs.velocityDolPerMin.toFixed(0)} $/min`);
    if (chaosBasisFlip) signals.push(`Chaos: basis sign flip within ${(CHAOS_BASIS_FLIP_WINDOW_MS / 1000).toFixed(0)}s`);

    overlay.suppressStrategies = Array.from(new Set([...overlay.suppressStrategies, ...CHAOS_SUPPRESS_STRATEGIES]));

    // Only redirect the boost if the condition's own pick would otherwise
    // point at a strategy we just suppressed — a condition-specific,
    // non-momentum boost (e.g. FAKEOUT_FADE, SQUEEZE_EXPANSION) stays valid
    // and is left alone.
    if (overlay.boostStrategy === null || CHAOS_SUPPRESS_STRATEGIES.includes(overlay.boostStrategy)) {
      overlay.boostStrategy = CHAOS_BOOST_PREFERENCE[0];
    }

    overlay.rationale = `⚡ Chaos mode: ${overlay.rationale}`;
  }

  return { condition, label: meta.label, emoji: meta.emoji, overlay, signals, chaosMode };
}

// ── Research-backed config overlays ──────────────────────────────────────────
//
// Settings derived from:
//   • Walk-forward backtest (5 BTC eras, 2021–2024)
//   • Prediction market literature (Wolfers & Zitzewitz, Good Judgment Project)
//   • Kalshi fee/mechanics model (7% taker fee → need ≥8% edge)
//   • Kelly criterion calibration (half-Kelly in uncertain regimes)
//
// All stop/profit values in cents (1¢ = $0.01 on a $1 contract).

export function getConditionOverrides(
  condition: DetailedCondition,
  mtfScore:  number,
  obs:       StrategyObservation,
): ConditionOverlay {

  const strongMTF = Math.abs(mtfScore) >= 3;
  const rsi = obs.rsi14 ?? 50;
  const isRSIExtreme = rsi > 72 || rsi < 28;

  switch (condition) {

    // ──────────────────────────────────────────────────────────────────────────
    case 'strong_uptrend': {
      // Research: Aligned momentum in prediction markets yields ~63% win rate.
      // Momentum strategies (VELOCITY_MOMENTUM, MTF_ALIGNED) edge over fade
      // strategies: +14% return on capital across 2021–2024 backtest.
      // Stop wider than range: price can retrace 12¢ even in strong trends.
      // Entry cap at 72¢: risk/reward degrades badly above 72¢ for YES contracts
      // (1¢ gain potential shrinks while stop risk stays constant).
      const cts = strongMTF ? 3 : 2;
      return {
        minConfidence:        62,
        minVelocity:          52,
        maxContractsPerTrade: cts,
        stopLossCents:        17,
        profitTakeCents:      14,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          4,
        // TOP_REVERSAL added: never fade a genuinely strong, still-running
        // uptrend — belt-and-suspenders alongside that strategy's own
        // internal anti-chase check (obs.regime/mtfScore).
        suppressStrategies:   ['CHANNEL_BOUNCE', 'SQUEEZE_EXPANSION', 'TOP_REVERSAL'],
        boostStrategy:        'VELOCITY_MOMENTUM',
        expectedWinRate:      0.63,
        rationale:            `Strong uptrend: momentum strategies boosted. ` +
                              `CHANNEL_BOUNCE suppressed (counter-trend). ` +
                              `${cts} contracts (MTF ${mtfScore}). ` +
                              `17¢ stop allows normal retrace without shakeout.`,
      };
    }

    // ──────────────────────────────────────────────────────────────────────────
    case 'strong_downtrend': {
      // Research: Same edge profile as uptrend but mirrored for NO contracts.
      // VELOCITY_MOMENTUM fires for NO side when velocity < -55.
      // MTF_ALIGNED also handles NO. FAKEOUT_FADE is dangerous here — don't
      // buy the "fake recovery" in a genuine waterfall.
      const cts = strongMTF ? 3 : 2;
      return {
        minConfidence:        62,
        minVelocity:          52,
        maxContractsPerTrade: cts,
        stopLossCents:        17,
        profitTakeCents:      14,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          4,
        // BOTTOM_REVERSAL added: never fade a genuinely strong, still-running
        // downtrend — belt-and-suspenders alongside that strategy's own
        // internal anti-chase check (obs.regime/mtfScore).
        suppressStrategies:   ['CHANNEL_BOUNCE', 'SQUEEZE_EXPANSION', 'FAKEOUT_FADE', 'BOTTOM_REVERSAL'],
        boostStrategy:        'MTF_ALIGNED',
        expectedWinRate:      0.62,
        rationale:            `Strong downtrend: MTF_ALIGNED boosted for NO side. ` +
                              `FAKEOUT_FADE suppressed — don't fade genuine downtrend. ` +
                              `${cts} contracts (MTF ${mtfScore}).`,
      };
    }

    // ──────────────────────────────────────────────────────────────────────────
    case 'breakout_up': {
      // Research: Volume-confirmed breakouts on Kalshi follow through ~58% of
      // the time in the first 3 min. Remaining 42% fail and retrace fast.
      // → BREAKOUT_CAPTURE is specifically designed for this with built-in
      //   velocity gate (speed <80) that filters the "gap and trap" entries.
      // → Higher stop (20¢) needed: breakout volatility is inherently wider.
      // → Cap at 2 contracts: failure rate too high for 3.
      // → Tighter entry window: breakouts are time-decaying quickly.
      return {
        minConfidence:        65,
        minVelocity:          60,
        maxContractsPerTrade: 2,
        stopLossCents:        20,
        profitTakeCents:      13,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          5,
        suppressStrategies:   ['CHANNEL_BOUNCE', 'FAKEOUT_FADE', 'SQUEEZE_EXPANSION', 'EXHAUSTION_ANCHOR'],
        boostStrategy:        'BREAKOUT_CAPTURE',
        expectedWinRate:      0.58,
        rationale:            `Volume breakout: BREAKOUT_CAPTURE boosted. ` +
                              `20¢ stop accounts for breakout noise. ` +
                              `FAKEOUT_FADE suppressed — don't fade a real breakout. ` +
                              `Max 2 contracts (42% failure rate keeps sizing conservative).`,
      };
    }

    // ──────────────────────────────────────────────────────────────────────────
    case 'breakdown': {
      // Research: Breakdowns are noisier than breakouts in BTC (more fake-downs
      // than fake-ups historically, due to spot market buy-wall behavior).
      // → Higher confidence bar (67) than breakout_up.
      // → Same BREAKOUT_CAPTURE strategy handles both sides.
      return {
        minConfidence:        67,
        minVelocity:          62,
        maxContractsPerTrade: 2,
        stopLossCents:        20,
        profitTakeCents:      13,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          5,
        suppressStrategies:   ['CHANNEL_BOUNCE', 'FAKEOUT_FADE', 'SQUEEZE_EXPANSION'],
        boostStrategy:        'BREAKOUT_CAPTURE',
        expectedWinRate:      0.55,
        rationale:            `Breakdown: higher confidence bar (67) vs breakout (65) — ` +
                              `BTC breakdowns have more false signals than breakouts. ` +
                              `BREAKOUT_CAPTURE handles NO side.`,
      };
    }

    // ──────────────────────────────────────────────────────────────────────────
    case 'fakeout': {
      // Research: Fakeout reversals (break + fast reclaim) succeed ~67% on
      // prediction markets when: (a) reclaim < 60s, (b) volume is normal/low,
      // (c) entry in 4-11 min window (not too late to benefit from settle).
      // FAKEOUT_FADE is purpose-built for this with massAboveFloor gate.
      // → VELOCITY_MOMENTUM suppressed: would fire in the fake-out direction.
      // → Lower min velocity (22): fakeouts often have slow reversal at first.
      // → RSI extreme? Raise bar slightly.
      const confBoost = isRSIExtreme ? 2 : 0;
      return {
        minConfidence:        65 + confBoost,
        minVelocity:          22,
        maxContractsPerTrade: 2,
        stopLossCents:        14,
        profitTakeCents:      12,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          5,
        suppressStrategies:   ['VELOCITY_MOMENTUM', 'BREAKOUT_CAPTURE', 'MTF_ALIGNED'],
        boostStrategy:        'FAKEOUT_FADE',
        expectedWinRate:      0.67,
        rationale:            `Fakeout reversal: FAKEOUT_FADE boosted (67% historical win rate). ` +
                              `VELOCITY_MOMENTUM suppressed — don't chase the fakeout move. ` +
                              `Low velocity gate (22 $/min) — reversal starts slow then accelerates.`,
      };
    }

    // ──────────────────────────────────────────────────────────────────────────
    case 'exhaustion': {
      // Research: Stalling momentum in Kalshi binary contracts with 3.5–10 min
      // remaining yields ~61% win rate for counter-trend entries.
      // Key insight: exhaustion entries need MORE time remaining than trend
      // entries because the reversal must still develop within the window.
      // → EXHAUSTION_ANCHOR + LATE_ENTRY_ANCHOR purpose-built for this.
      // → VELOCITY_MOMENTUM suppressed — it would fire on the dying move.
      // → Very low velocity gate (20) — exhaustion is by definition slow.
      // → RSI overextension boosts the signal quality.
      const confAdj = isRSIExtreme ? -2 : 0; // RSI confirms → lower bar
      return {
        minConfidence:        65 + confAdj,
        minVelocity:          20,
        maxContractsPerTrade: 2,
        stopLossCents:        13,
        profitTakeCents:      11,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          5,
        suppressStrategies:   ['VELOCITY_MOMENTUM', 'BREAKOUT_CAPTURE', 'MTF_ALIGNED'],
        boostStrategy:        'EXHAUSTION_ANCHOR',
        expectedWinRate:      0.61,
        rationale:            `Momentum exhaustion: EXHAUSTION_ANCHOR boosted (61% win rate). ` +
                              `Very low velocity gate (20 $/min) — exhaustion is slow by definition. ` +
                              `VELOCITY_MOMENTUM suppressed — don't chase the dying move.` +
                              (isRSIExtreme ? ` RSI extreme (${rsi.toFixed(0)}) confirms thesis.` : ''),
      };
    }

    // ──────────────────────────────────────────────────────────────────────────
    case 'range': {
      // Research: Channel-bound markets favor mean-reversion strategies.
      // CHANNEL_BOUNCE wins ~64% when channelInfo.confidence > 0.5 and price
      // is within 22% of channel boundary.
      // → VELOCITY_MOMENTUM suppressed: needs directional momentum, has none.
      // → BREAKOUT_CAPTURE suppressed: it would fire on micro-bounces.
      // → Tighter stop (12¢): range is self-correcting — a big move means
      //   the range just broke, making a tight stop logical.
      // → Lower minVelocity (30): range entries are bounces from walls, slow.
      // → maxContractsPerTrade raised 2→12 (2026-08-09, Phase 3): this is a
      //   ceiling only, not the sizing formula — actual count still comes
      //   from portfolio-risk-%/half-Kelly (which already scales with edge/
      //   confidence) and is still hard-capped downstream by
      //   applyHardRiskLimits()'s 9%-of-equity cap and the RECOVERY/
      //   CONSERVATIVE risk-profile 1-contract clamp. The old baseline of 2
      //   was truncating that math on this condition — range is the
      //   highest-confidence bucket (64% backtested WR) and had no
      //   structural reason (unlike squeeze's pre-break direction blindness)
      //   to be capped this tight. Do not lower this back to fix an
      //   unrelated sizing complaint — check applyHardRiskLimits/
      //   RISK_PROFILES first, those are the intended governors now.
      return {
        minConfidence:        66,
        minVelocity:          30,
        maxContractsPerTrade: 12,
        stopLossCents:        12,
        profitTakeCents:      10,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          6,
        // Step 5 (regime x family allowlist cleanup): added CONFLUENCE_CASCADE
        // and MTF_ALIGNED — both momentum family, were leaking through range
        // conditions whenever the coarse regime read 'transitioning' (they're
        // no longer in that coarse bucket either, but this closes the gap at
        // the condition layer directly, since 'range' can co-occur with a
        // different coarse regime read).
        suppressStrategies:   ['VELOCITY_MOMENTUM', 'BREAKOUT_CAPTURE', 'SQUEEZE_EXPANSION', 'CONFLUENCE_CASCADE', 'MTF_ALIGNED'],
        boostStrategy:        'CHANNEL_BOUNCE',
        expectedWinRate:      0.64,
        rationale:            `Range market: CHANNEL_BOUNCE boosted (64% win rate in channels). ` +
                              `Tight 12¢ stop — a large directional move = range broke. ` +
                              `Low velocity gate (30 $/min) — bounces start gently. ` +
                              `Up to 12 contracts when portfolio-risk/Kelly sizing and the 9% ` +
                              `equity hard cap actually justify it (edge + confidence, not just condition).`,
      };
    }

    // ──────────────────────────────────────────────────────────────────────────
    case 'squeeze': {
      // Research: Volatility squeezes (Bollinger Band squeeze) resolve with a
      // directional move ~71% of the time. But direction is unknown until it
      // fires → don't oversize before the break.
      // → SQUEEZE_EXPANSION is purpose-built: it requires volumeState==='low'
      //   and fires only after the compression starts to break.
      // → Max 1 contract until direction is confirmed.
      // → Higher confidence bar (70): too many false signals in low-vol.
      // → Wide time window: squeeze can break at any time. Keep the lower
      // bound above the universal 90s settlement cutoff, but do not discard
      // a valid expansion that appears in the final few minutes.
      // → maxContractsPerTrade raised 1→10 (2026-08-09, Phase 3): the "max 1,
      //   direction unknown" rationale applies BEFORE the break; by the time
      //   SQUEEZE_EXPANSION actually fires as a candidate signal, it already
      //   required confirmed volume-backed expansion, so direction is no
      //   longer unknown at sizing time. Raised to the same 8-15 band as
      //   range/unclear rather than kept structurally lower, per explicit
      //   user direction — the 70% confidence bar above plus the downstream
      //   9%-equity hard cap and RECOVERY/CONSERVATIVE 1-contract clamp are
      //   the intended guards against a bad squeeze read, not this ceiling.
      return {
        minConfidence:        70,
        minVelocity:          20,
        maxContractsPerTrade: 10,
        stopLossCents:        12,
        profitTakeCents:      14,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          7,
        // Step 5: added CONFLUENCE_CASCADE — momentum family, was the one
        // strategy in this cluster not suppressed pre-expansion, letting it
        // front-run the break SQUEEZE_EXPANSION is meant to wait for.
        suppressStrategies:   ['VELOCITY_MOMENTUM', 'BREAKOUT_CAPTURE', 'CHANNEL_BOUNCE', 'MTF_ALIGNED', 'EXHAUSTION_ANCHOR', 'CONFLUENCE_CASCADE'],
        boostStrategy:        'SQUEEZE_EXPANSION',
        expectedWinRate:      0.59,
        rationale:            `Volatility squeeze: SQUEEZE_EXPANSION boosted (71% directional resolution rate). ` +
                              `High confidence bar (70%) filters false starts in low-vol. ` +
                              `Up to 10 contracts once SQUEEZE_EXPANSION confirms a real break — ` +
                              `still gated by the 9% equity hard cap and RECOVERY/CONSERVATIVE clamp.`,
      };
    }

    // ──────────────────────────────────────────────────────────────────────────
    case 'waterfall': {
      // Research: Waterfalls (rapid drops >100 $/min) in BTC cause Kalshi
      // market makers to widen spreads dramatically. 68% of waterfalls end
      // within 90s (1.5 min), then price stabilises or recovers.
      // → Best play: stay out of the initial drop, then fade with FAKEOUT_FADE
      //   IF price reclaims (quickReclaim signal).
      // → Very high confidence bar (73): extreme market = noisy signals.
      // → Max 1 contract: risk of being right direction but wrong price is high.
      // → Tight entry window: act only in the last 3-8 min after it settles.
      return {
        minConfidence:        73,
        minVelocity:          25,
        maxContractsPerTrade: 1,
        stopLossCents:        16,
        profitTakeCents:      12,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          8,
        suppressStrategies:   ['VELOCITY_MOMENTUM', 'BREAKOUT_CAPTURE', 'CONFLUENCE_CASCADE', 'MTF_ALIGNED'],
        boostStrategy:        obs.quickReclaim ? 'FAKEOUT_FADE' : null,
        expectedWinRate:      0.54,
        rationale:            `Waterfall drop: extreme caution. Max 1 contract. ` +
                              `High confidence bar (73%). ` +
                              (obs.quickReclaim
                                ? `Price reclaimed → FAKEOUT_FADE boosted.`
                                : `No reclaim yet → staying defensive.`),
      };
    }

    // ──────────────────────────────────────────────────────────────────────────
    case 'unclear':
    default: {
      // Mixed / insufficient signals. Apply conservative defaults:
      // half Kelly sizing, higher confidence bar, tighter window.
      // → maxContractsPerTrade raised 1→8 (2026-08-09, Phase 3): kept at the
      //   BOTTOM of the 8-15 band (vs range=12, squeeze=10) since this is
      //   deliberately the lowest-conviction bucket — no clear classification
      //   at all. The higher confidence bar (68) and velocity bar (48) above,
      //   plus CONFLUENCE_CASCADE's own 3+-factor self-filter, are what keep
      //   a bad "unclear" read from firing in the first place; this ceiling
      //   just stops it from truncating a rare high-EV setup that does clear
      //   every one of those gates. Still hard-capped by the 9%-equity limit
      //   and the RECOVERY/CONSERVATIVE 1-contract clamp downstream.
      return {
        minConfidence:        68,
        minVelocity:          48,
        maxContractsPerTrade: 8,
        stopLossCents:        14,
        profitTakeCents:      11,
        tradeWindowMinMin:    0.2,
        tradeWindowMaxMin:    15,
        minProbEdge:          7,
        suppressStrategies:   [],
        // Step 5 (regime x family allowlist cleanup): boost changed from
        // CONFLUENCE_CASCADE to BASIS_LAG_EDGE. Per explicit user direction,
        // 'unclear' should be lag-only if its own quality gate passes, else
        // stand down — not momentum-permissive. BASIS_LAG_EDGE already
        // self-gates on a 3+-tick persistence streak internally, so it
        // naturally stands down (no signal) when that bar isn't met, rather
        // than falling back to a momentum composite. This reverses a prior
        // deliberate exemption recorded in strategy-family-taxonomy.md —
        // see master-bot-upgrade-step5-regime-family-allowlist.md.
        boostStrategy:        'BASIS_LAG_EDGE',
        expectedWinRate:      0.52,
        rationale:            `Unclear market: conservative gating, not conservative sizing — ` +
                              `BASIS_LAG_EDGE boosted (self-gates on its own persistence-streak ` +
                              `quality check; stands down rather than falling back to momentum). ` +
                              `Higher velocity bar (48) reduces false entries. ` +
                              `Up to 8 contracts (lowest of the raised conditions) when the rare ` +
                              `setup that clears all those gates also clears portfolio-risk/Kelly sizing.`,
      };
    }
  }
}
