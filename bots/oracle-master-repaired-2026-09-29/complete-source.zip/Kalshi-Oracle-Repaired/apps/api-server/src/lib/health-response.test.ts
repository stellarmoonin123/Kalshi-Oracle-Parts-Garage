import { test } from "node:test";
import assert from "node:assert/strict";
import { healthResponse } from "./health-response.js";

test("anonymous health probes omit money, positions, errors, and build internals", () => {
  const report = { healthy: false, timestamp: "2026-09-29T22:00:00Z", balance: 100, position: "private", error: "private", build: { gitSha: "private" } };
  assert.deepEqual(healthResponse(report, false), { healthy: false, timestamp: report.timestamp });
  assert.equal(healthResponse(report, true), report);
});
