/** QUARANTINE(P2): ARIA guardian DEAD_ENGINE; never ENABLE */
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  parseAriaDecision,
  clampTighten,
  computeAriaEvidence,
  isAriaExitAllowed,
  shouldEvaluateAriaGuardian,
  evaluateAriaGuardianPolicy,
  resolveExitPriority,
  ariaConfidenceIsNotWinRate,
  ariaLagFlipPersistenceMet,
  ARIA_EXIT_MIN_CONF,
  ARIA_GRACE_SECS,
  ARIA_EXIT_MIN_SECS,
  ARIA_RATE_LIMIT_SECS,
  LAG_FLIP_MIN_HOLD_MS,
  LAG_FLIP_MIN_SAMPLES,
  type AriaContext,
  type AriaDecision,
} from "./aria-guardian.js";

function baseCtx(overrides: Partial<AriaContext> = {}): AriaContext {
  return {
    trade: { side: "yes", strategyId: "TEST_STRAT", family: "momentum", entryAsk: 40, contracts: 10, floorStrike: 100000, secsRemaining: 300, entryThesis: "test thesis" },
    market: { velScale: 50, zVel: 0, rangeScale: 1, volScale: 0.5, regime: "trending", session: "us", tau: 0.5, stale: false },
    book: { spreadCents: 2, depthAtAsk: 20, imbalance: 0, liqAction: "ALLOW", bookClass: "FULL" },
    lag: { projectedSettlement: 100050, rollingBasis: 5, projAgreesWithSide: true },
    position: { unrealizedCents: 5, distanceToHardStopCents: 20, thesisBreakTicksRising: false, lagFlipTicks: 0 },
    gates: { netEVAtEntry: 3, primaryBlocker: null },
    secsSinceEntry: 60,
    ...overrides,
  };
}

// ── parseAriaDecision: fail-safe HOLD ───────────────────────────────────────

test.skip("parseAriaDecision: valid HOLD passes through", () => {
  const d = parseAriaDecision({ action: "HOLD", confidence: 0.4, reasons: ["OK"] });
  assert.equal(d.action, "HOLD");
  assert.equal(d.confidence, 0.4);
});

test.skip("parseAriaDecision: valid EXIT with exitCode passes through", () => {
  const d = parseAriaDecision({ action: "EXIT", confidence: 0.8, reasons: ["LAG"], exitCode: "ARIA_LAG_FLIP" });
  assert.equal(d.action, "EXIT");
  assert.equal(d.exitCode, "ARIA_LAG_FLIP");
});

test.skip("parseAriaDecision: null/non-object -> fail-safe HOLD", () => {
  assert.deepEqual(parseAriaDecision(null), { action: "HOLD", confidence: 0, reasons: ["PARSE_FAIL"] });
  assert.deepEqual(parseAriaDecision("EXIT"), { action: "HOLD", confidence: 0, reasons: ["PARSE_FAIL"] });
  assert.deepEqual(parseAriaDecision(undefined), { action: "HOLD", confidence: 0, reasons: ["PARSE_FAIL"] });
});

test.skip("parseAriaDecision: invalid action string -> fail-safe HOLD, never EXIT", () => {
  const d = parseAriaDecision({ action: "FORCE_EXIT", confidence: 0.9, reasons: [] });
  assert.equal(d.action, "HOLD");
});

test.skip("parseAriaDecision: missing confidence -> fail-safe HOLD", () => {
  const d = parseAriaDecision({ action: "EXIT", reasons: ["x"] });
  assert.equal(d.action, "HOLD");
});

test.skip("parseAriaDecision: reasons not an array of strings -> fail-safe HOLD", () => {
  const d = parseAriaDecision({ action: "EXIT", confidence: 0.9, reasons: [1, 2] });
  assert.equal(d.action, "HOLD");
});

test.skip("parseAriaDecision: invalid exitCode -> fail-safe HOLD", () => {
  const d = parseAriaDecision({ action: "EXIT", confidence: 0.9, reasons: [], exitCode: "MADE_UP" });
  assert.equal(d.action, "HOLD");
});

test.skip("parseAriaDecision: confidence clamped to [0,1]", () => {
  const d = parseAriaDecision({ action: "HOLD", confidence: 5, reasons: [] });
  assert.equal(d.confidence, 1);
  const d2 = parseAriaDecision({ action: "HOLD", confidence: -2, reasons: [] });
  assert.equal(d2.confidence, 0);
});

test.skip("parseAriaDecision: reasons truncated to 3", () => {
  const d = parseAriaDecision({ action: "HOLD", confidence: 0.5, reasons: ["a", "b", "c", "d", "e"] });
  assert.equal(d.reasons.length, 3);
});

test.skip("parseAriaDecision: tighten with mult > 1 is dropped (never widen)", () => {
  const d = parseAriaDecision({ action: "TIGHTEN", confidence: 0.5, reasons: [], tighten: { stopMult: 1.5, trailMult: 0.8 } });
  assert.equal(d.tighten?.stopMult, undefined);
  assert.equal(d.tighten?.trailMult, 0.8);
});

// ── clampTighten: mult bounds ────────────────────────────────────────────────

test.skip("clampTighten: valid (0,1] values pass through", () => {
  assert.deepEqual(clampTighten({ stopMult: 0.5, trailMult: 1 }), { stopMult: 0.5, trailMult: 1 });
});

test.skip("clampTighten: 0 or negative or >1 dropped entirely", () => {
  assert.equal(clampTighten({ stopMult: 0 }), undefined);
  assert.equal(clampTighten({ stopMult: -0.5 }), undefined);
  assert.equal(clampTighten({ stopMult: 1.01 }), undefined);
});

test.skip("clampTighten: undefined/null -> undefined", () => {
  assert.equal(clampTighten(undefined), undefined);
  assert.equal(clampTighten(null), undefined);
});

// ── computeAriaEvidence ──────────────────────────────────────────────────────

test.skip("computeAriaEvidence: projAgreesWithSide=null (unknown/stale) is never treated as disagreement", () => {
  const ctx = baseCtx({ lag: { projectedSettlement: null, rollingBasis: null, projAgreesWithSide: null } });
  assert.equal(computeAriaEvidence(ctx).lagDisagrees, false);
});

test.skip("computeAriaEvidence: projAgreesWithSide=false is disagreement", () => {
  const ctx = baseCtx({ lag: { projectedSettlement: 99000, rollingBasis: 5, projAgreesWithSide: false } });
  assert.equal(computeAriaEvidence(ctx).lagDisagrees, true);
});

test.skip("computeAriaEvidence: zVel strongly against side is side-aware (yes vs no)", () => {
  const yesCtx = baseCtx({ trade: { ...baseCtx().trade, side: "yes" }, market: { ...baseCtx().market, zVel: -2 } });
  assert.equal(computeAriaEvidence(yesCtx).zVelStronglyAgainst, true);
  const noCtx = baseCtx({ trade: { ...baseCtx().trade, side: "no" }, market: { ...baseCtx().market, zVel: -2 } });
  assert.equal(computeAriaEvidence(noCtx).zVelStronglyAgainst, false);
  const noCtxAgainst = baseCtx({ trade: { ...baseCtx().trade, side: "no" }, market: { ...baseCtx().market, zVel: 2 } });
  assert.equal(computeAriaEvidence(noCtxAgainst).zVelStronglyAgainst, true);
});

test.skip("computeAriaEvidence: stale market never contributes zVel evidence", () => {
  const ctx = baseCtx({ market: { ...baseCtx().market, zVel: -5, stale: true } });
  assert.equal(computeAriaEvidence(ctx).zVelStronglyAgainst, false);
});

test.skip("computeAriaEvidence: liqAction SKIP or HAIRCUT both count as adverse", () => {
  const skip = baseCtx({ book: { ...baseCtx().book, liqAction: "SKIP" } });
  const haircut = baseCtx({ book: { ...baseCtx().book, liqAction: "HAIRCUT" } });
  const allow = baseCtx({ book: { ...baseCtx().book, liqAction: "ALLOW" } });
  assert.equal(computeAriaEvidence(skip).liqAdverse, true);
  assert.equal(computeAriaEvidence(haircut).liqAdverse, true);
  assert.equal(computeAriaEvidence(allow).liqAdverse, false);
});

// ── isAriaExitAllowed: Part C rule 2 gating ─────────────────────────────────

test.skip("isAriaExitAllowed: non-EXIT action is never allowed to exit", () => {
  const ctx = baseCtx();
  const decision: AriaDecision = { action: "HOLD", confidence: 0.99, reasons: [] };
  assert.equal(isAriaExitAllowed(ctx, decision).allowed, false);
});

test.skip("isAriaExitAllowed: confidence below ARIA_EXIT_MIN_CONF blocks EXIT", () => {
  const ctx = baseCtx({ lag: { projectedSettlement: 99000, rollingBasis: 5, projAgreesWithSide: false }, secsSinceEntry: 60 });
  const decision: AriaDecision = { action: "EXIT", confidence: ARIA_EXIT_MIN_CONF - 0.01, reasons: [], exitCode: "ARIA_LAG_FLIP" };
  const result = isAriaExitAllowed(ctx, decision);
  assert.equal(result.allowed, false);
  assert.equal(result.reason, "CONF_BELOW_MIN");
});

test.skip("isAriaExitAllowed: no evidence at all blocks EXIT even at high confidence", () => {
  const ctx = baseCtx({ secsSinceEntry: 60 }); // all evidence-neutral defaults
  const decision: AriaDecision = { action: "EXIT", confidence: 0.95, reasons: [], exitCode: "ARIA_OTHER" };
  const result = isAriaExitAllowed(ctx, decision);
  assert.equal(result.allowed, false);
  assert.equal(result.reason, "NO_EVIDENCE");
});

test.skip("isAriaExitAllowed: within grace period blocks EXIT even with evidence + high confidence", () => {
  const ctx = baseCtx({
    lag: { projectedSettlement: 99000, rollingBasis: 5, projAgreesWithSide: false },
    secsSinceEntry: ARIA_GRACE_SECS - 1,
  });
  const decision: AriaDecision = { action: "EXIT", confidence: 0.9, reasons: ["LAG"], exitCode: "ARIA_LAG_FLIP" };
  const result = isAriaExitAllowed(ctx, decision);
  assert.equal(result.allowed, false);
  assert.equal(result.reason, "WITHIN_GRACE");
});

test.skip("isAriaExitAllowed: too close to expiry blocks EXIT unless hard-stop imminent", () => {
  const ctx = baseCtx({
    lag: { projectedSettlement: 99000, rollingBasis: 5, projAgreesWithSide: false },
    position: { unrealizedCents: 5, distanceToHardStopCents: 20, thesisBreakTicksRising: false, lagFlipTicks: LAG_FLIP_MIN_SAMPLES },
    secsSinceEntry: 60,
    trade: { ...baseCtx().trade, secsRemaining: ARIA_EXIT_MIN_SECS - 1 },
  });
  const decision: AriaDecision = { action: "EXIT", confidence: 0.9, reasons: ["LAG"], exitCode: "ARIA_LAG_FLIP" };
  const blocked = isAriaExitAllowed(ctx, decision);
  assert.equal(blocked.allowed, false);
  assert.equal(blocked.reason, "TOO_CLOSE_TO_EXPIRY");
  const allowedViaHardStop = isAriaExitAllowed(ctx, decision, { hardStopImminent: true });
  assert.equal(allowedViaHardStop.allowed, true);
});

test.skip("isAriaExitAllowed: fully-qualified EXIT (confidence + evidence + grace + time) is allowed", () => {
  const ctx = baseCtx({
    lag: { projectedSettlement: 99000, rollingBasis: 5, projAgreesWithSide: false },
    position: { unrealizedCents: 5, distanceToHardStopCents: 20, thesisBreakTicksRising: false, lagFlipTicks: LAG_FLIP_MIN_SAMPLES },
    secsSinceEntry: ARIA_GRACE_SECS + 5,
    trade: { ...baseCtx().trade, secsRemaining: ARIA_EXIT_MIN_SECS + 30 },
  });
  const decision: AriaDecision = { action: "EXIT", confidence: ARIA_EXIT_MIN_CONF, reasons: ["LAG"], exitCode: "ARIA_LAG_FLIP" };
  const result = isAriaExitAllowed(ctx, decision);
  assert.equal(result.allowed, true);
});

// ── shouldEvaluateAriaGuardian: rate limiting ───────────────────────────────

test.skip("shouldEvaluateAriaGuardian: first evaluation (lastEvalTs null) always runs", () => {
  assert.equal(shouldEvaluateAriaGuardian(null, Date.now(), 20), true);
});

test.skip("shouldEvaluateAriaGuardian: within rate-limit window without hard-stop proximity is skipped", () => {
  const now = 1_000_000;
  const last = now - (ARIA_RATE_LIMIT_SECS * 1000 - 1);
  assert.equal(shouldEvaluateAriaGuardian(last, now, 20), false);
});

test.skip("shouldEvaluateAriaGuardian: window elapsed runs again", () => {
  const now = 1_000_000;
  const last = now - ARIA_RATE_LIMIT_SECS * 1000;
  assert.equal(shouldEvaluateAriaGuardian(last, now, 20), true);
});

test.skip("shouldEvaluateAriaGuardian: hard-stop proximity bypasses the rate limit", () => {
  const now = 1_000_000;
  const last = now - 1; // just evaluated 1ms ago
  assert.equal(shouldEvaluateAriaGuardian(last, now, 2), true); // within ARIA_HARD_STOP_PROXIMITY_CENTS
});

// ── evaluateAriaGuardianPolicy: deterministic scored policy ─────────────────

test.skip("evaluateAriaGuardianPolicy: stale market -> HOLD, confidence 0", () => {
  const ctx = baseCtx({ market: { ...baseCtx().market, stale: true } });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.equal(d.action, "HOLD");
  assert.equal(d.confidence, 0);
});

test.skip("evaluateAriaGuardianPolicy: clean position, no evidence -> HOLD", () => {
  const d = evaluateAriaGuardianPolicy(baseCtx());
  assert.equal(d.action, "HOLD");
});

test.skip("evaluateAriaGuardianPolicy: strong multi-signal evidence -> EXIT with a valid exitCode", () => {
  const ctx = baseCtx({
    lag: { projectedSettlement: 99000, rollingBasis: 5, projAgreesWithSide: false },
    position: { unrealizedCents: -5, distanceToHardStopCents: 20, thesisBreakTicksRising: true, lagFlipTicks: LAG_FLIP_MIN_SAMPLES },
    book: { ...baseCtx().book, liqAction: "SKIP" },
  });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.equal(d.action, "EXIT");
  assert.ok(d.confidence >= ARIA_EXIT_MIN_CONF);
  assert.ok(d.exitCode);
  assert.ok(d.reasons.length > 0 && d.reasons.length <= 3);
});

test.skip("evaluateAriaGuardianPolicy: single moderate signal -> TIGHTEN with mult <= 1, never widens", () => {
  const ctx = baseCtx({ position: { unrealizedCents: -3, distanceToHardStopCents: 20, thesisBreakTicksRising: true, lagFlipTicks: 0 } });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.equal(d.action, "TIGHTEN");
  assert.ok(d.tighten);
  assert.ok((d.tighten!.stopMult ?? 1) <= 1);
  assert.ok((d.tighten!.stopMult ?? 1) > 0);
  assert.ok((d.tighten!.trailMult ?? 1) <= 1);
});

test.skip("evaluateAriaGuardianPolicy: low tau alone is not SETTLE_HOLD (LOCKED_ITM required)", () => {
  const ctx = baseCtx({ market: { ...baseCtx().market, tau: 0.05 } });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.notEqual(d.action, "SETTLE_HOLD");
  assert.equal(d.action, "HOLD");
});

test.skip("evaluateAriaGuardianPolicy: EXIT decisions always pass through parseAriaDecision unchanged (schema-valid)", () => {
  const ctx = baseCtx({
    lag: { projectedSettlement: 99000, rollingBasis: 5, projAgreesWithSide: false },
    position: { unrealizedCents: -5, distanceToHardStopCents: 20, thesisBreakTicksRising: true, lagFlipTicks: LAG_FLIP_MIN_SAMPLES },
    book: { ...baseCtx().book, liqAction: "SKIP" },
  });
  const raw = evaluateAriaGuardianPolicy(ctx);
  const reparsed = parseAriaDecision(raw);
  assert.deepEqual(reparsed, raw);
});

// ── resolveExitPriority: money-law order (Part C rule 1) ────────────────────

test.skip("resolveExitPriority: THESIS_BREAK outranks hard % stop, lag-flip, ARIA, settlement-hold", () => {
  assert.equal(resolveExitPriority({ hardStop: true, thesisBreak: true, lagFlip: true, ariaExit: true, settlementHoldActive: true }), "THESIS_BREAK");
});

test.skip("resolveExitPriority: LAG_FLIP outranks hard % stop, ARIA, settlement-hold", () => {
  assert.equal(resolveExitPriority({ hardStop: true, thesisBreak: false, lagFlip: true, ariaExit: true, settlementHoldActive: true }), "LAG_FLIP");
});

test.skip("resolveExitPriority: hard stop still beats ARIA and settlement-hold when TB/lag are off", () => {
  assert.equal(resolveExitPriority({ hardStop: true, thesisBreak: false, lagFlip: false, ariaExit: true, settlementHoldActive: true }), "HARD_STOP");
});

test.skip("resolveExitPriority: thesis-break beats lag-flip, ARIA exit, and settlement-hold", () => {
  assert.equal(resolveExitPriority({ hardStop: false, thesisBreak: true, lagFlip: true, ariaExit: true, settlementHoldActive: true }), "THESIS_BREAK");
});

test.skip("resolveExitPriority: lag-flip beats ARIA exit and settlement-hold", () => {
  assert.equal(resolveExitPriority({ hardStop: false, thesisBreak: false, lagFlip: true, ariaExit: true, settlementHoldActive: true }), "LAG_FLIP");
});

test.skip("resolveExitPriority: ARIA exit beats settlement-hold", () => {
  assert.equal(resolveExitPriority({ hardStop: false, thesisBreak: false, lagFlip: false, ariaExit: true, settlementHoldActive: true }), "ARIA_EXIT");
});

test.skip("resolveExitPriority: settlement-hold wins when nothing above it fires", () => {
  assert.equal(resolveExitPriority({ hardStop: false, thesisBreak: false, lagFlip: false, ariaExit: false, settlementHoldActive: true }), "SETTLEMENT_HOLD");
});

test.skip("resolveExitPriority: NONE when nothing fires (falls through to soft/time/trailing)", () => {
  assert.equal(resolveExitPriority({ hardStop: false, thesisBreak: false, lagFlip: false, ariaExit: false, settlementHoldActive: false }), "NONE");
});

// ── CHEAP_SIDE_15M: never SETTLE_HOLD (sell-before-expiry) ───────────────────

test.skip("evaluateAriaGuardianPolicy: CHEAP_SIDE_15M + low tau never returns SETTLE_HOLD (HOLD instead)", () => {
  const ctx = baseCtx({
    trade: { ...baseCtx().trade, strategyId: "CHEAP_SIDE_15M" },
    market: { ...baseCtx().market, tau: 0.05 },
  });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.notEqual(d.action, "SETTLE_HOLD");
  assert.equal(d.action, "HOLD");
});

test.skip("evaluateAriaGuardianPolicy: non-cheap-side locked ITM (90¢+, $400 through, 60s) → SETTLE_HOLD LOCKED_ITM", () => {
  const b = baseCtx();
  const ctx = baseCtx({
    trade: { ...b.trade, strategyId: "LATE_ENTRY", entryAsk: 50, floorStrike: 100000, secsRemaining: 60 },
    lag: { projectedSettlement: 100400, rollingBasis: 5, projAgreesWithSide: true },
    position: {
      unrealizedCents: 42,
      distanceToHardStopCents: 20,
      thesisBreakTicksRising: false,
      lagFlipTicks: 0,
      peakUnrealizedCents: 42,
      markCents: 92,
    },
    secsSinceEntry: 60,
  });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.equal(d.action, "SETTLE_HOLD");
  assert.ok(d.reasons.includes("LOCKED_ITM"));
  assert.ok(!d.reasons.includes("LOW_TAU_LAG_OK"));
  assert.equal("pWin" in d, false);
});

test.skip("evaluateAriaGuardianPolicy: CHEAP_SIDE_15M can still TIGHTEN (SETTLE_HOLD refuse is not a blanket HOLD)", () => {
  const ctx = baseCtx({
    trade: { ...baseCtx().trade, strategyId: "CHEAP_SIDE_15M" },
    market: { ...baseCtx().market, tau: 0.05 },
    position: { unrealizedCents: -3, distanceToHardStopCents: 20, thesisBreakTicksRising: true, lagFlipTicks: 0 },
  });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.equal(d.action, "TIGHTEN");
  assert.notEqual(d.action, "SETTLE_HOLD");
});

// ── ARIA_LAG_FLIP EXIT requires lag-flip persistence (15s AND 16 samples) ───

test.skip("ariaLagFlipPersistenceMet: needs lagFlipTicks >= 16 AND secsSinceEntry >= 15", () => {
  assert.equal(LAG_FLIP_MIN_HOLD_MS, 15_000);
  assert.equal(LAG_FLIP_MIN_SAMPLES, 16);
  const enough = baseCtx({
    position: { unrealizedCents: 0, distanceToHardStopCents: 20, thesisBreakTicksRising: false, lagFlipTicks: 16 },
    secsSinceEntry: 15,
  });
  assert.equal(ariaLagFlipPersistenceMet(enough), true);
  const shortTime = baseCtx({
    position: { unrealizedCents: 0, distanceToHardStopCents: 20, thesisBreakTicksRising: false, lagFlipTicks: 16 },
    secsSinceEntry: 14.9,
  });
  assert.equal(ariaLagFlipPersistenceMet(shortTime), false);
  const fewTicks = baseCtx({
    position: { unrealizedCents: 0, distanceToHardStopCents: 20, thesisBreakTicksRising: false, lagFlipTicks: 15 },
    secsSinceEntry: 60,
  });
  assert.equal(ariaLagFlipPersistenceMet(fewTicks), false);
});

function lagExitCtx(overrides: Partial<AriaContext> = {}): AriaContext {
  const b = baseCtx();
  return baseCtx({
    lag: { projectedSettlement: 99000, rollingBasis: 5, projAgreesWithSide: false },
    position: { unrealizedCents: -5, distanceToHardStopCents: 20, thesisBreakTicksRising: true, lagFlipTicks: LAG_FLIP_MIN_SAMPLES },
    book: { ...b.book, liqAction: "SKIP" },
    secsSinceEntry: 60,
    ...overrides,
  });
}

test.skip("evaluateAriaGuardianPolicy: lag disagrees after 20s grace but lagFlipTicks < 16 → TIGHTEN not EXIT", () => {
  const ctx = lagExitCtx({
    position: { unrealizedCents: -5, distanceToHardStopCents: 20, thesisBreakTicksRising: true, lagFlipTicks: LAG_FLIP_MIN_SAMPLES - 1 },
    secsSinceEntry: ARIA_GRACE_SECS + 5,
  });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.equal(d.action, "TIGHTEN");
  assert.notEqual(d.action, "EXIT");
  assert.ok((d.tighten!.stopMult ?? 1) <= 1 && (d.tighten!.stopMult ?? 1) > 0);
});

test.skip("evaluateAriaGuardianPolicy: lag disagrees with 16 ticks but secsSinceEntry < 15 → TIGHTEN not EXIT", () => {
  const ctx = lagExitCtx({ secsSinceEntry: 14 });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.equal(d.action, "TIGHTEN");
  assert.notEqual(d.action, "EXIT");
});

test.skip("evaluateAriaGuardianPolicy: ARIA_LAG_FLIP EXIT only when lagFlipTicks >= 16 AND secsSinceEntry >= 15", () => {
  const ctx = lagExitCtx({ secsSinceEntry: 15 });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.equal(d.action, "EXIT");
  assert.equal(d.exitCode, "ARIA_LAG_FLIP");
  assert.ok(d.confidence >= ARIA_EXIT_MIN_CONF);
});

test.skip("isAriaExitAllowed: ARIA_LAG_FLIP blocked until lag-flip persistence even after grace", () => {
  const ctx = baseCtx({
    lag: { projectedSettlement: 99000, rollingBasis: 5, projAgreesWithSide: false },
    position: { unrealizedCents: 5, distanceToHardStopCents: 20, thesisBreakTicksRising: false, lagFlipTicks: 3 },
    secsSinceEntry: ARIA_GRACE_SECS + 5,
    trade: { ...baseCtx().trade, secsRemaining: 60 },
  });
  const decision: AriaDecision = { action: "EXIT", confidence: 0.9, reasons: ["LAG"], exitCode: "ARIA_LAG_FLIP" };
  const result = isAriaExitAllowed(ctx, decision);
  assert.equal(result.allowed, false);
  assert.equal(result.reason, "LAG_FLIP_PERSISTENCE");
});

// ── confidence is evidence-strength, NEVER pWin / Kelly p ───────────────────

test.skip("parseAriaDecision: confidence 0.9 is not used as winRate; pWin on raw is dropped", () => {
  const d = parseAriaDecision({
    action: "HOLD",
    confidence: 0.9,
    reasons: ["x"],
    pWin: 0.9,
    winRate: 0.9,
    kellyP: 0.9,
  });
  assert.equal(d.confidence, 0.9);
  assert.equal("pWin" in d, false);
  assert.equal("winRate" in d, false);
  assert.equal("kellyP" in d, false);
  assert.equal(ariaConfidenceIsNotWinRate(d), true);
});

test.skip("evaluateAriaGuardianPolicy never writes a field named pWin (confidence is not Kelly p)", () => {
  const d = evaluateAriaGuardianPolicy(lagExitCtx({ secsSinceEntry: 60 }));
  assert.ok(d.confidence >= 0.7);
  assert.equal("pWin" in d, false);
  assert.equal("winRate" in d, false);
  assert.equal("kellyP" in d, false);
  assert.equal(ariaConfidenceIsNotWinRate(d), true);
  // A 0.9-ish evidence score must not be treatable as P(win): no pWin field exists to feed EV.
  const highConf: AriaDecision = { action: "HOLD", confidence: 0.9, reasons: ["EVIDENCE"] };
  assert.equal(ariaConfidenceIsNotWinRate(highConf), true);
  assert.notEqual(highConf.confidence, undefined);
  assert.equal((highConf as { pWin?: number }).pWin, undefined);
});


// ── hold-sell interaction: LOCKED_ITM SETTLE_HOLD + trail EXIT without LLM ──

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const botSource = fs.readFileSync(path.join(__dirname, "trading-bot.ts"), "utf8");
const guardianSource = fs.readFileSync(path.join(__dirname, "aria-guardian.ts"), "utf8");
const holdSellSource = fs.readFileSync(path.join(__dirname, "hold-sell.ts"), "utf8");

test.skip("evaluateAriaGuardianPolicy: cheap-side 92¢ never SETTLE_HOLD", () => {
  const b = baseCtx();
  const ctx = baseCtx({
    trade: { ...b.trade, strategyId: "CHEAP_SIDE_15M", entryAsk: 50, floorStrike: 100000, secsRemaining: 200 },
    lag: { projectedSettlement: 100400, rollingBasis: 5, projAgreesWithSide: true },
    position: {
      unrealizedCents: 42,
      distanceToHardStopCents: 20,
      thesisBreakTicksRising: false,
      lagFlipTicks: 0,
      peakUnrealizedCents: 42,
      markCents: 92,
    },
    secsSinceEntry: 60,
  });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.notEqual(d.action, "SETTLE_HOLD");
  assert.notEqual(d.action, "EXIT");
});

test.skip("evaluateAriaGuardianPolicy: green peak +20 now +5 trail 12 → EXIT ARIA_TRAIL with 0 lag/thesis evidence", () => {
  const b = baseCtx();
  const ctx = baseCtx({
    trade: { ...b.trade, strategyId: "LATE_ENTRY", entryAsk: 50, secsRemaining: 400 },
    lag: { projectedSettlement: 100050, rollingBasis: 5, projAgreesWithSide: true },
    position: {
      unrealizedCents: 5,
      distanceToHardStopCents: 20,
      thesisBreakTicksRising: false,
      lagFlipTicks: 0,
      peakUnrealizedCents: 20,
      markCents: 55,
    },
    secsSinceEntry: ARIA_GRACE_SECS + 10,
  });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.equal(d.action, "EXIT");
  assert.equal(d.exitCode, "ARIA_TRAIL");
  assert.ok(d.reasons.includes("TRAIL_GIVEBACK"));
  assert.ok(d.confidence >= ARIA_EXIT_MIN_CONF);
  assert.equal("pWin" in d, false);
  const gate = isAriaExitAllowed(ctx, d);
  assert.equal(gate.allowed, true, gate.reason);
});

test.skip("isAriaExitAllowed: ARIA_TRAIL / TRAIL_GIVEBACK EXIT allowed with 0 evidence after grace", () => {
  const ctx = baseCtx({ secsSinceEntry: ARIA_GRACE_SECS + 5, trade: { ...baseCtx().trade, secsRemaining: 60 } });
  const decision: AriaDecision = { action: "EXIT", confidence: ARIA_EXIT_MIN_CONF, reasons: ["TRAIL_GIVEBACK"], exitCode: "ARIA_TRAIL" };
  const result = isAriaExitAllowed(ctx, decision);
  assert.equal(result.allowed, true);
});

test.skip("isAriaExitAllowed: ARIA_TRAIL still blocked within 20s grace", () => {
  const ctx = baseCtx({ secsSinceEntry: ARIA_GRACE_SECS - 1, trade: { ...baseCtx().trade, secsRemaining: 60 } });
  const decision: AriaDecision = { action: "EXIT", confidence: 0.9, reasons: ["TRAIL_GIVEBACK"], exitCode: "ARIA_TRAIL" };
  const result = isAriaExitAllowed(ctx, decision);
  assert.equal(result.allowed, false);
  assert.equal(result.reason, "WITHIN_GRACE");
});

test.skip("evaluateAriaGuardianPolicy: DEAD_RED is not Guardian EXIT (lag-flip/thesis own that)", () => {
  const b = baseCtx();
  const ctx = baseCtx({
    trade: { ...b.trade, entryAsk: 50, secsRemaining: 120 },
    position: {
      unrealizedCents: -5,
      distanceToHardStopCents: 20,
      thesisBreakTicksRising: false,
      lagFlipTicks: 0,
      peakUnrealizedCents: 0,
      markCents: 45,
    },
    secsSinceEntry: 60,
  });
  const d = evaluateAriaGuardianPolicy(ctx);
  assert.notEqual(d.action, "EXIT");
});

test.skip("parseAriaDecision: ARIA_TRAIL is a valid exitCode", () => {
  const d = parseAriaDecision({ action: "EXIT", confidence: 0.8, reasons: ["TRAIL_GIVEBACK"], exitCode: "ARIA_TRAIL" });
  assert.equal(d.action, "EXIT");
  assert.equal(d.exitCode, "ARIA_TRAIL");
});

test.skip("parseAriaDecision: junk / unparseable still HOLD (never EXIT)", () => {
  assert.equal(parseAriaDecision("not json").action, "HOLD");
  assert.equal(parseAriaDecision({ action: "EXIT" }).action, "HOLD");
  assert.equal(parseAriaDecision({ foo: 1 }).action, "HOLD");
  assert.deepEqual(parseAriaDecision("{really junk"), { action: "HOLD", confidence: 0, reasons: ["PARSE_FAIL"] });
});

test.skip("hold-sell.ts must not import aria-guardian (no cycle)", () => {
  assert.equal(holdSellSource.includes("aria-guardian"), false);
  assert.ok(guardianSource.includes('from "./hold-sell.js"'));
});

test.skip("checkAriaGuardian is not gated on useExpertAgent (source-text)", () => {
  const fnStart = botSource.indexOf("private async checkAriaGuardian");
  const fnEnd = botSource.indexOf("private async monitorOpenTrade");
  assert.ok(fnStart >= 0 && fnEnd > fnStart);
  const fn = botSource.slice(fnStart, fnEnd);
  assert.equal(fn.includes("useExpertAgent"), false);
  const call = botSource.indexOf("if (await this.checkAriaGuardian");
  assert.ok(call > fnEnd);
  // DANGER LLM path is gated; Guardian call is the next statement, not inside that if.
  const danger = botSource.lastIndexOf("this.config.useExpertAgent && expertAgent.isSustainedDanger", call);
  assert.ok(danger >= 0 && danger < call);
  const dangerBlockEnd = botSource.indexOf("}", botSource.indexOf("await this.exitEarly(\"ARIA_GATED_EXIT\"", danger));
  assert.ok(dangerBlockEnd < call);
});

test.skip("checkAriaGuardian SETTLE_HOLD is applied (settlementHoldActive), not log-only", () => {
  const fnStart = botSource.indexOf("private async checkAriaGuardian");
  const fnEnd = botSource.indexOf("private async monitorOpenTrade");
  const fn = botSource.slice(fnStart, fnEnd);
  assert.ok(fn.includes("this.settlementHoldActive = true"));
  assert.ok(fn.includes("applied: true"));
  assert.ok(fn.includes("SETTLE_HOLD_LOCKED_ITM") || fn.includes("SETTLE_HOLD"));
  assert.ok(!fn.includes("log-only this phase"));
  assert.ok(fn.includes("peakUnrealizedCents: this.openTradeMaxGain"));
  assert.ok(fn.includes("markCents: currentSidePrice"));
});

test.skip("monitorOpenTrade: thesis-break and lag-flip stay above hard stop and Guardian", () => {
  const hard = botSource.indexOf("if (await this.checkHardStop");
  const thesis = botSource.indexOf("if (await this.checkThesisBreak");
  const lag = botSource.indexOf("if (await this.checkLagFlip");
  const guardian = botSource.indexOf("if (await this.checkAriaGuardian");
  const settle = botSource.indexOf("const settlementHoldEligible");
  assert.ok(hard >= 0 && thesis >= 0 && lag >= 0 && guardian >= 0 && settle >= 0);
  assert.ok(thesis < lag && lag < hard && hard < guardian && guardian < settle);
});
