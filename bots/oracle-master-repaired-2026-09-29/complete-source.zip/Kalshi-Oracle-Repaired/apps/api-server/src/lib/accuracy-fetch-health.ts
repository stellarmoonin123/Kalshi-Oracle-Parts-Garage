/**
 * Pure state and retry helpers for the scheduled fresh model-accuracy monitor.
 *
 * Kept independent of routes, the database, and the bot singleton so outage
 * behavior can be tested without starting any live service timers.
 */

/** Sentinel used when a transient fetch or calculation error prevents measurement. */
export const ACCURACY_UNAVAILABLE = -1;

/** Number of consecutive unavailable fresh measurements before health warns. */
export const ACCURACY_FAILURE_STREAK_THRESHOLD = 2;

/**
 * Process-local state for the scheduled fresh accuracy monitor.
 *
 * It intentionally receives only final outcomes from scheduled fresh-fetch
 * cycles. Cached snapshots, manual runs, and historical backfills must not
 * hide an ongoing fresh-feed outage by resetting this streak.
 */
export class AccuracyFetchFailureTracker {
  private consecutiveFailures = 0;

  recordScheduledFreshResult(accuracy: number): void {
    if (accuracy === ACCURACY_UNAVAILABLE) {
      this.consecutiveFailures++;
    } else {
      this.consecutiveFailures = 0;
    }
  }

  getHealth(): { consecutiveFailures: number; accuracyFetchFailing: boolean } {
    return {
      consecutiveFailures: this.consecutiveFailures,
      accuracyFetchFailing: this.consecutiveFailures >= ACCURACY_FAILURE_STREAK_THRESHOLD,
    };
  }
}

/**
 * Execute a fresh accuracy measurement with one retry. The caller decides
 * whether the final result participates in the operational health monitor.
 * That separation prevents non-scheduled callers from masking a feed outage.
 */
export async function runFreshAccuracyWithRetry(
  attemptFreshAccuracy: () => Promise<number>,
  waitBeforeRetry: () => Promise<void>,
): Promise<number> {
  let accuracy = await attemptFreshAccuracy();
  if (accuracy === ACCURACY_UNAVAILABLE) {
    await waitBeforeRetry();
    accuracy = await attemptFreshAccuracy();
  }
  return accuracy;
}