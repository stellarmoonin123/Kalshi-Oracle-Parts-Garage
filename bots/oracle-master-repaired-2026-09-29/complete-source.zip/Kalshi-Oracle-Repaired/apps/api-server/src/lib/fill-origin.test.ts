/**
 * fill-origin.test.ts
 *
 * Bot vs manual fill tagging. Overall P&L includes both. Bot WR / learner /
 * Kelly / winRateAtPrice: BOT only. Paper virtualCents is never Kalshi cash.
 *
 * Does NOT import trading-bot.ts.
 *
 * LOCKS: paper stays paper. Never ENABLE_STRATEGY. Do not edit charts.tsx.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import test from "node:test";
import assert from "node:assert/strict";
import {
  FILL_ORIGIN_BOT,
  FILL_ORIGIN_MANUAL,
  MANUAL_STRATEGY_ID,
  isBotFill,
  isManualFill,
  shouldFeedLearner,
  includeInBotWinRate,
  includeInOverallPnl,
  classifyFillOrigin,
  splitSettledPnl,
  countsTowardStrategyWinRate,
  classifyExitClass,
  trackedKalshiTradeForAudit,
  kalshiPositionToManualIntent,
  applyKalshiBalancePoll,
  accountStatusForPaperEntry,
  pendingCountsForRestartHold,
  isMoneyMakerThesisHold,
} from "./fill-origin.js";
import { classifyAccountPositionState, shouldBlockSecondPosition } from "./trading-bot.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const SETTLEMENT = readFileSync(path.join(DIR, "settlement-helpers.ts"), "utf8");
const PERF = readFileSync(path.join(DIR, "strategy-performance.ts"), "utf8");
const BOT_TSX = readFileSync(
  path.resolve(DIR, "../../../kalshi-trader/src/pages/bot.tsx"),
  "utf8",
);

test("legacy / bot origin is a bot fill; manual is not", () => {
  assert.equal(isBotFill(undefined), true);
  assert.equal(isBotFill(null), true);
  assert.equal(isBotFill(FILL_ORIGIN_BOT), true);
  assert.equal(isBotFill(FILL_ORIGIN_MANUAL), false);
  assert.equal(isManualFill(FILL_ORIGIN_MANUAL), true);
  assert.equal(isManualFill(FILL_ORIGIN_BOT), false);
});

test("learner / bot WR skip MANUAL; overall P&L includes both", () => {
  assert.equal(shouldFeedLearner(FILL_ORIGIN_BOT, "BASIS_LAG_EDGE"), true);
  assert.equal(shouldFeedLearner(FILL_ORIGIN_MANUAL, "BASIS_LAG_EDGE"), false);
  assert.equal(shouldFeedLearner(FILL_ORIGIN_BOT, MANUAL_STRATEGY_ID), false);
  assert.equal(includeInBotWinRate(FILL_ORIGIN_MANUAL), false);
  assert.equal(includeInBotWinRate(FILL_ORIGIN_BOT), true);
  assert.equal(includeInOverallPnl(FILL_ORIGIN_MANUAL), true);
  assert.equal(includeInOverallPnl(FILL_ORIGIN_BOT), true);
});

test("classifyFillOrigin: paper/bot order ids are bot; unmatched Kalshi id is manual", () => {
  const botIds = new Set(["abc-live-order"]);
  assert.equal(classifyFillOrigin({ kalshiOrderId: "paper-1", botOrderIds: botIds }), FILL_ORIGIN_BOT);
  assert.equal(classifyFillOrigin({ kalshiOrderId: "abc-live-order", botOrderIds: botIds }), FILL_ORIGIN_BOT);
  assert.equal(classifyFillOrigin({ kalshiOrderId: "someone-else", botOrderIds: botIds }), FILL_ORIGIN_MANUAL);
  assert.equal(classifyFillOrigin({ kalshiOrderId: null, botOrderIds: botIds }), FILL_ORIGIN_MANUAL);
});

test("splitSettledPnl: overall includes manual; bot WR ignores it", () => {
  const botOnly = splitSettledPnl([
    { fillOrigin: "bot", strategyId: "BASIS_LAG_EDGE", pnlCents: 40, outcome: "win" },
    { fillOrigin: "bot", strategyId: "BASIS_LAG_EDGE", pnlCents: -20, outcome: "loss" },
  ]);
  const withManual = splitSettledPnl([
    { fillOrigin: "bot", strategyId: "BASIS_LAG_EDGE", pnlCents: 40, outcome: "win" },
    { fillOrigin: "bot", strategyId: "BASIS_LAG_EDGE", pnlCents: -20, outcome: "loss" },
    { fillOrigin: "manual", strategyId: MANUAL_STRATEGY_ID, pnlCents: -500, outcome: "loss" },
  ]);
  assert.equal(withManual.overallPnlCents, 40 - 20 - 500);
  assert.notEqual(withManual.overallPnlCents, botOnly.overallPnlCents, "MANUAL settled row must change overall P&L");
  assert.equal(withManual.botPnlCents, botOnly.botPnlCents);
  assert.equal(withManual.botWins, botOnly.botWins);
  assert.equal(withManual.botLosses, botOnly.botLosses);
  assert.equal(withManual.botWinRate, botOnly.botWinRate, "MANUAL must not change bot WR");
  assert.equal(withManual.botWinRate, 0.5);
  assert.equal(withManual.manualPnlCents, -500);
  assert.equal(withManual.manualLosses, 1);
});

test("applyKalshiBalancePoll never overwrites paper 30720 with Kalshi cash", () => {
  const paper = applyKalshiBalancePoll({
    paperMode: true,
    paperVirtualCents: 30720,
    peakCents: 31300,
    kalshiBalanceCents: 99_000,
  });
  assert.equal(paper.paperVirtualCents, 30720);
  assert.equal(paper.peakCents, 31300, "paper peak must not jump to Kalshi cash");
  assert.equal(paper.kalshiCashCents, 99_000);

  const live = applyKalshiBalancePoll({
    paperMode: false,
    paperVirtualCents: 30720,
    peakCents: 31300,
    kalshiBalanceCents: 50_000,
  });
  assert.equal(live.kalshiCashCents, 50_000);
  assert.equal(live.peakCents, 50_000);
  assert.equal(live.paperVirtualCents, 30720);
});

test("trackedKalshiTradeForAudit: paper openTrade is not Kalshi-tracked", () => {
  assert.equal(
    trackedKalshiTradeForAudit({ ticker: "KXBTC15M-PAPER", side: "yes", contracts: 3, paper: true }),
    null,
  );
  assert.deepEqual(
    trackedKalshiTradeForAudit({ ticker: "KXBTC15M-LIVE", side: "no", contracts: 4, paper: false }),
    { ticker: "KXBTC15M-LIVE", side: "no", contracts: 4 },
  );
});

test("MANUAL Kalshi position + paper openTrade is unmanaged (blocks second bot position)", () => {
  const tracked = trackedKalshiTradeForAudit({
    ticker: "KXBTC15M-PAPER", side: "yes", contracts: 2, paper: true,
  });
  const result = classifyAccountPositionState(
    [{ ticker: "KXBTC15M-MANUAL", position: 5 }],
    tracked,
  );
  assert.equal(result.status, "unmanaged");
  assert.deepEqual(result.unmanaged, [{ ticker: "KXBTC15M-MANUAL", position: 5 }]);
});

test("kalshiPositionToManualIntent tags yes/no from signed position", () => {
  const yes = kalshiPositionToManualIntent({ ticker: "T-YES", position: 3 });
  assert.equal(yes.side, "yes");
  assert.equal(yes.contracts, 3);
  assert.equal(yes.fillOrigin, FILL_ORIGIN_MANUAL);
  assert.equal(yes.strategyId, MANUAL_STRATEGY_ID);
  const no = kalshiPositionToManualIntent({ ticker: "T-NO", position: -2 });
  assert.equal(no.side, "no");
  assert.equal(no.contracts, 2);
  assert.equal(no.signal, "SHORT");
});

test("refreshBalance polls Kalshi in paper; never assigns paperVirtual from Kalshi cash", () => {
  const refreshIdx = BOT.indexOf("private async refreshBalance()");
  assert.ok(refreshIdx >= 0);
  const refresh = BOT.slice(refreshIdx, refreshIdx + 400);
  assert.ok(
    !refresh.includes("if (this.config.paperMode) return"),
    "paper mode must still poll Kalshi cash",
  );
  assert.ok(BOT.includes("applyKalshiBalancePoll("));
  const bodyIdx = BOT.indexOf("private async _refreshBalanceBody()");
  assert.ok(bodyIdx >= 0);
  const body = BOT.slice(bodyIdx, bodyIdx + 2500);
  assert.ok(body.includes("applyKalshiBalancePoll"));
  assert.ok(
    !/this\.paperVirtualBalanceCents\s*=\s*data\.balance/.test(body),
    "Kalshi cash must not overwrite paperVirtualBalanceCents",
  );
  assert.ok(
    !/this\.paperVirtualBalanceCents\s*=\s*next\./.test(body),
    "paper virtual is not assigned from the Kalshi poll result",
  );
});

test("probeAuth uses applyKalshiBalancePoll so paper peak cannot snap to Kalshi cash", () => {
  const idx = BOT.indexOf("private async probeAuth()");
  assert.ok(idx >= 0);
  const body = BOT.slice(idx, idx + 2800);
  assert.ok(body.includes("applyKalshiBalancePoll"));
  assert.ok(!/this\.paperVirtualBalanceCents\s*=/.test(body), "probeAuth must not write paper virtual from Kalshi");
  assert.ok(!/this\.peakBalanceCents\s*=\s*data\.balance/.test(body), "probeAuth must not snap peak to Kalshi cash");
});

test("account recon runs in paper (manual Kalshi fill blocks a second bot position)", () => {
  const startIdx = BOT.indexOf("this.balanceTimer");
  const startBlock = BOT.slice(startIdx, startIdx + 1800);
  assert.ok(startBlock.includes("reconcileAccountPositionsWithKalshi"));
  assert.ok(
    !startBlock.includes("if (!this.config.paperMode) {\n      // This audit"),
    "recon timer must not be live-only",
  );
  const reconIdx = BOT.indexOf("private async reconcileAccountPositionsWithKalshi()");
  assert.ok(reconIdx >= 0);
  const recon = BOT.slice(reconIdx, reconIdx + 2200);
  assert.ok(
    !recon.includes("if (this.config.paperMode || this.accountPositionReconcileInFlight) return"),
    "recon must run in paper mode",
  );
  assert.ok(recon.includes("trackedKalshiTradeForAudit"));
  assert.ok(recon.includes("ingestManualKalshiPositions") || recon.includes("kalshiPositionToManualIntent"));
});

test("placeOrder tags bot fills; feedLearningPipelines skips manual", () => {
  assert.ok(BOT.includes("fillOrigin: \"bot\"") || BOT.includes("fillOrigin: FILL_ORIGIN_BOT"));
  assert.ok(SETTLEMENT.includes("shouldFeedLearner"));
  assert.ok(PERF.includes("includeInBotWinRate") || PERF.includes("fillOrigin") || PERF.includes("FILL_ORIGIN"));
});

test("dashboard shows Kalshi cash separately from paper virtual; charts.tsx untouched contract", () => {
  assert.ok(BOT_TSX.includes("Kalshi cash") || BOT_TSX.includes("kalshi cash") || BOT_TSX.includes("Kalshi Cash"));
  assert.ok(BOT_TSX.includes("paperVirtualBalanceCents"));
  assert.ok(BOT_TSX.includes("accountBalance"));
  const charts = readFileSync(
    path.resolve(DIR, "../../../kalshi-trader/src/pages/charts.tsx"),
    "utf8",
  );
  void charts; // existence only — this test file must not be the editor of charts.tsx
});

test("Bot page all-time WR is bot fills only; overall P&L still includes MANUAL", () => {
  assert.ok(BOT_TSX.includes("isBotSettledFill"), "WR fallback must filter fill_origin");
  assert.ok(BOT_TSX.includes("botTrades") && BOT_TSX.includes("botWins"));
  // Honesty: paperMode scopes all-time WR to paper book (never blend live zeros).
  assert.ok(
    BOT_TSX.includes("scopedReport.botTrades")
    || BOT_TSX.includes("allTimeReport.live.botTrades + allTimeReport.paper.botTrades"),
    "all-time WR must use botTrades (scoped or summed)",
  );
  assert.ok(
    BOT_TSX.includes("scopedReport.botWins")
    || BOT_TSX.includes("allTimeReport.live.botWins + allTimeReport.paper.botWins"),
    "all-time WR must use botWins (scoped or summed)",
  );
  assert.ok(
    BOT_TSX.includes("isPaper ? allTimeReport.paper : allTimeReport.live")
    || BOT_TSX.includes("All-time WR is BOT fills only"),
    "paper desk must not mislabel live all-time as session/paper WR",
  );
  assert.ok(BOT_TSX.includes("bot fills"), "WR card must be labeled bot fills");
  assert.ok(BOT_TSX.includes("Overall · bot + MANUAL"), "P&L card must stay overall and labeled");
  assert.ok(
    BOT_TSX.includes("Kalshi cash") && (BOT_TSX.includes("not paper") || BOT_TSX.includes("(not paper)")),
    "Kalshi cash must be labeled not-paper",
  );
  assert.ok(BOT_TSX.includes("Session P&L") || BOT_TSX.includes("Session WR"), "session cards distinct from all-time");
});

test("bot.ts report WR / Kelly / strategy-stats use splitSettledPnl and exclude MANUAL", () => {
  const routes = readFileSync(path.resolve(DIR, "../routes/bot.ts"), "utf8");
  assert.ok(routes.includes("splitSettledPnl"));
  assert.ok(routes.includes("includeInBotWinRate"));
  assert.ok(routes.includes("const split = splitSettledPnl(rows)"));
  assert.ok(routes.includes("const botRows = rows.filter(r => includeInBotWinRate"));
  assert.ok(routes.includes(".filter(t => includeInBotWinRate(t.fillOrigin, t.strategyId))"), "Kelly sim must skip MANUAL");
  assert.ok(routes.includes("or(eq(botTrades.fillOrigin, FILL_ORIGIN_BOT), isNull(botTrades.fillOrigin))"));
  assert.ok(routes.includes("sql`${botTrades.strategyId} is distinct from ${MANUAL_STRATEGY_ID}`"));
});

test("paper one-position: live unmanaged/manual does not starve a paper fill", () => {
  assert.equal(accountStatusForPaperEntry({ paperMode: true, accountStatus: "unmanaged" }), "never");
  assert.equal(accountStatusForPaperEntry({ paperMode: true, accountStatus: "unknown" }), "never");
  assert.equal(accountStatusForPaperEntry({ paperMode: true, accountStatus: "tracked-mismatch" }), "never");
  assert.equal(accountStatusForPaperEntry({ paperMode: false, accountStatus: "unmanaged" }), "unmanaged");
  assert.equal(shouldBlockSecondPosition({
    hasOpenTrade: false, hasPendingUnsettled: false,
    accountStatus: accountStatusForPaperEntry({ paperMode: true, accountStatus: "unmanaged" }),
  }), false, "live manuals must not evaluate-approve-then-skip paper");
  assert.equal(shouldBlockSecondPosition({
    hasOpenTrade: true, hasPendingUnsettled: false,
    accountStatus: accountStatusForPaperEntry({ paperMode: true, accountStatus: "unmanaged" }),
  }), true, "one paper position still binds");
  assert.equal(shouldBlockSecondPosition({
    hasOpenTrade: false, hasPendingUnsettled: false, accountStatus: "unmanaged",
  }), true, "live still fail-closes on unmanaged");
});

test("restart pending hold is paper/live isolated", () => {
  assert.equal(pendingCountsForRestartHold({ paperMode: true, isPaper: true }), true);
  assert.equal(pendingCountsForRestartHold({ paperMode: true, isPaper: false }), false);
  assert.equal(pendingCountsForRestartHold({ paperMode: true, isPaper: null }), false);
  assert.equal(pendingCountsForRestartHold({ paperMode: false, isPaper: false }), true);
  assert.equal(pendingCountsForRestartHold({ paperMode: false, isPaper: null }), true);
  assert.equal(pendingCountsForRestartHold({ paperMode: false, isPaper: true }), false);
});

test("CONFLUENCE and BASIS_LAG are thesis-hold money makers", () => {
  assert.equal(isMoneyMakerThesisHold("CONFLUENCE_CASCADE"), true);
  assert.equal(isMoneyMakerThesisHold("BASIS_LAG_EDGE"), true);
  assert.equal(isMoneyMakerThesisHold("PAPER_SCALP"), false);
  assert.equal(isMoneyMakerThesisHold("LATE_ENTRY_ANCHOR"), false);
});

test("THESIS_BREAK / LAG_FLIP risk_exit keep PnL out of strategy WR", () => {
  assert.equal(classifyExitClass("THESIS_BREAK_EXIT"), "risk_exit");
  assert.equal(classifyExitClass("LAG_FLIP_EXIT"), "risk_exit");
  assert.equal(countsTowardStrategyWinRate("THESIS_BREAK_EXIT"), false);
  assert.equal(countsTowardStrategyWinRate("SETTLEMENT"), true);
  const split = splitSettledPnl([
    { fillOrigin: "bot", strategyId: "BASIS_LAG_EDGE", pnlCents: 40, outcome: "win", exitReason: "SETTLEMENT" },
    { fillOrigin: "bot", strategyId: "BASIS_LAG_EDGE", pnlCents: -80, outcome: "loss", exitReason: "LAG_FLIP_EXIT" },
    { fillOrigin: "bot", strategyId: "CONFLUENCE_CASCADE", pnlCents: -50, outcome: "loss", exitReason: "THESIS_BREAK_EXIT" },
  ]);
  assert.equal(split.overallPnlCents, 40 - 80 - 50, "PnL still books risk dumps");
  assert.equal(split.botPnlCents, 40 - 80 - 50);
  assert.equal(split.botWins, 1);
  assert.equal(split.botLosses, 0, "risk_exit must not count as strategy losses");
  assert.equal(split.botWinRate, 1);
});


test("PATH_RIDE bare THESIS_BREAK / LAG_FLIP / TIME_STOP_SMALL_ACCT are risk_exit", () => {
  assert.equal(classifyExitClass("THESIS_BREAK"), "risk_exit");
  assert.equal(classifyExitClass("LAG_FLIP"), "risk_exit");
  assert.equal(classifyExitClass("TIME_STOP_SMALL_ACCT"), "risk_exit");
  assert.equal(countsTowardStrategyWinRate("THESIS_BREAK"), false);
  assert.equal(countsTowardStrategyWinRate("LAG_FLIP"), false);
  const split = splitSettledPnl([
    { fillOrigin: "bot", strategyId: "CONFLUENCE_CASCADE", pnlCents: -90, outcome: "loss", exitReason: "THESIS_BREAK" },
    { fillOrigin: "bot", strategyId: "BASIS_LAG_EDGE", pnlCents: -40, outcome: "loss", exitReason: "LAG_FLIP" },
    { fillOrigin: "bot", strategyId: "CONFLUENCE_CASCADE", pnlCents: 50, outcome: "win", exitReason: "PATH_RIDE_TP" },
  ]);
  assert.equal(split.overallPnlCents, -90 - 40 + 50, "fee-net / PnL still on row");
  assert.equal(split.botWins, 1);
  assert.equal(split.botLosses, 0, "risk_exit settle must not bump learner strategy W/L");
});
