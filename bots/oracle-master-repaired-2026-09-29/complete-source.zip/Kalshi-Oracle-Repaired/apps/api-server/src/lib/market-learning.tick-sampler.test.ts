/**
 * market-learning.tick-sampler.test.ts — 1s shadow sampler helpers.
 *
 * Pure-function coverage only. Does not start the sampler, flip LIVE_APPLY,
 * or touch trading-bot / EV / autoMode / paperMode.
 */
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
  CHEAP_ASK_MAX_CENTS,
  CHEAP_ASK_MIN_CENTS,
  cheapSettledITM,
  isCheapAsk,
  LIVE_APPLY_ENABLED,
  pickCheapAsk,
  tickJsonlFilename,
} from "./market-learning.js";

test("LIVE_APPLY_ENABLED stays false (shadow only)", () => {
  assert.equal(LIVE_APPLY_ENABLED, false);
});

test("cheap-side band is 7–22¢ inclusive", () => {
  assert.equal(CHEAP_ASK_MIN_CENTS, 7);
  assert.equal(CHEAP_ASK_MAX_CENTS, 22);
  assert.equal(isCheapAsk(6), false);
  assert.equal(isCheapAsk(7), true);
  assert.equal(isCheapAsk(22), true);
  assert.equal(isCheapAsk(23), false);
  assert.equal(isCheapAsk(null), false);
  assert.equal(isCheapAsk(undefined), false);
});

test("pickCheapAsk prefers the cheaper in-band side", () => {
  assert.equal(pickCheapAsk(50, 50), null);
  assert.deepEqual(pickCheapAsk(11, 90), { side: "YES", price: 11 });
  assert.deepEqual(pickCheapAsk(90, 8), { side: "NO", price: 8 });
  assert.deepEqual(pickCheapAsk(10, 9), { side: "NO", price: 9 });
  assert.deepEqual(pickCheapAsk(9, 9), { side: "YES", price: 9 });
});

test("cheapSettledITM is yes-side vs settlement", () => {
  assert.equal(cheapSettledITM("YES", "YES"), true);
  assert.equal(cheapSettledITM("YES", "NO"), false);
  assert.equal(cheapSettledITM("NO", "NO"), true);
  assert.equal(cheapSettledITM("NO", "YES"), false);
  assert.equal(cheapSettledITM(null, "YES"), null);
  assert.equal(cheapSettledITM("YES", null), null);
});

test("tick jsonl filename is YYYYMMDD-ticker.jsonl", () => {
  const name = tickJsonlFilename(Date.parse("2026-08-27T03:55:00Z"), "KXBTC15M-26AUG270000-00");
  assert.equal(name, "20260827-KXBTC15M-26AUG270000-00.jsonl");
});

test("1s sampler stamps lagSeconds/lagDollars via stampTickLag; no ENABLE / bounce / EV cut", () => {
  const src = fs.readFileSync(new URL("./market-learning.ts", import.meta.url), "utf8");
  assert.match(src, /stampTickLag/);
  assert.match(src, /lagSeconds: lagStamp\.lagSeconds/);
  assert.match(src, /lagDollars: lagStamp\.lagDollars/);
  assert.match(src, /coinbasePx/);
  assert.match(src, /kalshiImpliedPx/);
  assert.equal(src.includes("ENABLE_STRATEGY"), false);
  assert.equal(src.includes("paperMode = false") || src.includes("paperMode: false"), false);
  assert.equal(LIVE_APPLY_ENABLED, false);
});

test("1s sampler feeds chart tape ingest; no ENABLE", () => {
  const src = fs.readFileSync(new URL("./market-learning.ts", import.meta.url), "utf8");
  assert.match(src, /ingestChart1sTick\(s\)/);
  assert.equal(src.includes("ENABLE_STRATEGY"), false);
  assert.equal(LIVE_APPLY_ENABLED, false);
});
