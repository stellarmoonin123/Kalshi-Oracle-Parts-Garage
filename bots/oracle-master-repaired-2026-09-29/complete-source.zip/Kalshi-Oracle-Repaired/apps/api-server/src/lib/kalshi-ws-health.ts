/**
 * Single source of truth for "is the Kalshi WS healthy?" (2026-09-24).
 *
 * Before: /healthz websocket.connected = !degraded (true for the first 4
 * failures while the socket was actually closed), and the watchdog judged
 * kalshi-ws by tick age — which the REST backstop keeps fresh — so it read
 * "ok" while /healthz said degraded and entries were paused. Both now derive
 * from the same pure verdict over the real socket state.
 */
import type { WsSocketState } from "./kalshi-ws.js";

export interface WsHealthInput {
  socket: WsSocketState;
  degraded: boolean;
  lastWsMessageTs: number | null;
  lastOpenAt: number | null;
  nowMs: number;
  /** A socket with no message for this long is "stale" even if open. */
  staleMs?: number;
}

export type WsHealthStatus = "ok" | "healing" | "degraded";

export interface WsHealthVerdict {
  connected: boolean;
  status: WsHealthStatus;
  reason: string;
  messageAgeMs: number | null;
}

export const WS_MESSAGE_STALE_MS = 30_000;

export function wsHealthVerdict(i: WsHealthInput): WsHealthVerdict {
  const staleMs = i.staleMs ?? WS_MESSAGE_STALE_MS;
  const messageAgeMs = i.lastWsMessageTs == null ? null : Math.max(0, i.nowMs - i.lastWsMessageTs);
  const open = i.socket === "open";
  const fresh = messageAgeMs != null && messageAgeMs <= staleMs;
  if (open && fresh && !i.degraded) return { connected: true, status: "ok", reason: "socket open, messages flowing", messageAgeMs };
  if (i.degraded) return { connected: false, status: "degraded", reason: `WS degraded (socket ${i.socket}) — entries paused`, messageAgeMs };
  if (open && !fresh) return { connected: false, status: "healing", reason: "socket open but silent", messageAgeMs };
  return { connected: false, status: "healing", reason: `socket ${i.socket} — reconnecting`, messageAgeMs };
}
