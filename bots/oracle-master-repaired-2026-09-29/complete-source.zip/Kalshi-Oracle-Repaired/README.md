# Kalshi Oracle (clean remake)

Single trading product: Express API + in-process bot + Vite dashboard. Paper mode by default. No Replit, no mobile, no perps frontend, no live trading enabled.

Run commands from the root of your checkout. Record the source commit used for each release.

## Layout

apps/api-server              trading brain, Kalshi client, strategies, risk, Express
apps/kalshi-trader           dashboard (AuthGate + Vite)
packages/db                  Drizzle schema
packages/api-zod             generated Zod types
packages/api-spec            OpenAPI + orval codegen
packages/api-client-react    generated React Query client

## Setup

Use Node 22, pnpm 10.14.0 (pinned in package.json), and PostgreSQL.

Dashboard dev server is port 5173 and proxies /api to the API on 8080.

```bash
cd Kalshi-oracle
cp .env.example .env
# fill DATABASE_URL and ORACLE_ADMIN_USERNAME / EMAIL / PASSWORD
pnpm install --frozen-lockfile
pnpm db:push
```

## Run

Terminal 1: pnpm run dev:api
Terminal 2: pnpm run dev:dashboard

Open http://localhost:5173 and sign in with your Oracle account (bootstrap the first ADMIN with `ORACLE_ADMIN_USERNAME` / `ORACLE_ADMIN_EMAIL` / `ORACLE_ADMIN_PASSWORD` or `pnpm --filter @workspace/api-server accounts:bootstrap-admin`; see docs/accounts/ACCOUNTS.md).

Production-shaped single process (API serves the built dashboard):
pnpm run build && NODE_ENV=production pnpm start

## Tests

pnpm run test:api          # node:test under apps/api-server
pnpm run test:dashboard    # vitest
pnpm run test              # both

API tests share DATABASE_URL. Use a disposable DB.

## Auth

- Sign in with an Oracle account. BOT_API_KEY is not an account login credential.
- Login sets the opaque HttpOnly oracle_session cookie; sessions are stored server-side.
- Public: GET /api/healthz, GET /api/public/status, POST /api/auth/login|logout, GET /api/auth/me.
- Protected routes default to 401 without an active account session; write/control routes additionally enforce ADMIN permissions. See docs/accounts/ACCOUNTS.md.
- Anonymous health probes contain only healthy and timestamp. Authenticated clients retain the detailed subsystem report.

## What is not wired yet

- Postgres + pnpm db:push against a live database (not run in this pass).
- Docker / Fly deploy (omitted on purpose).
- Hourly diagnostic sweep that spawned the full test suite (dropped). Manual /api/diagnostics/run-now is runtime-health only.
- kalshi-mobile, kalshi-perps UI, solodev-researcher, mockup-sandbox (dropped). API still has a read-only perps market-data poller from the original brain.
- Replit CORS, Replit Vite plugins, .replit workflows.

## Landmines

See docs/LANDMINES.md. Copied trading-bot.ts is the product; do not rewrite it.
