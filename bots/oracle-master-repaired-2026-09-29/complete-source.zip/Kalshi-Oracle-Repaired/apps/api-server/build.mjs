import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build as esbuild } from "esbuild";
import esbuildPluginPino from "esbuild-plugin-pino";
import { rm } from "node:fs/promises";
import { execFileSync } from "node:child_process";

// Plugins (e.g. 'esbuild-plugin-pino') may use `require` to resolve dependencies
globalThis.require = createRequire(import.meta.url);

const artifactDir = path.dirname(fileURLToPath(import.meta.url));

/** Run unit tests before bundling. Exits non-zero on failure. */
function runTests() {
  if (process.env.SKIP_BUILD_TESTS === "1") {
    console.log("[build] SKIP_BUILD_TESTS=1 — skipping unit tests");
    return;
  }
  const tsxBin = path.resolve(artifactDir, "node_modules/.bin/tsx");
  const testFiles = [
    path.resolve(artifactDir, "src/lib/kalshi-auth.test.ts"),
    path.resolve(artifactDir, "src/lib/perps/position-manager.test.ts"),
    path.resolve(artifactDir, "src/lib/perps/paper-engine.test.ts"),
    path.resolve(artifactDir, "src/lib/perps/trend-follow-perps.test.ts"),
    path.resolve(artifactDir, "src/lib/perps/perps-risk-guard.test.ts"),
    path.resolve(artifactDir, "src/lib/price-band-gate.test.ts"),
    path.resolve(artifactDir, "src/lib/session-mode.test.ts"),
    path.resolve(artifactDir, "src/lib/stack-size-tier.test.ts"),
  ];
  console.log("[build] Running unit tests…");
  try {
    // BOT_CONFIG_PATH must be overridden here — these tests run in the same
    // working directory as the live bot, and some of them instantiate
    // TradingBot and trigger savePersistedConfig(). Without this override,
    // every `pnpm run dev` (build+start, i.e. every workflow restart)
    // silently rewrote the real .bot-config.json back to in-code defaults
    // (paperMode, autoMode, maxContractsPerTrade, usePortfolioRisk all
    // reverted) right before the server loaded it. `pnpm test`'s script
    // already isolates itself this way; this build-triggered run did not.
    execFileSync(tsxBin, ["--test", ...testFiles], {
      stdio: "inherit",
      env: { ...process.env, BOT_CONFIG_PATH: "/tmp/api-server-build-test-bot-config.json" },
    });
    console.log("[build] Tests passed ✓");
  } catch {
    console.error("[build] Tests FAILED — aborting bundle.");
    process.exit(1);
  }
}

// The `check-api-drift` workflow runs orval codegen, which *cleans then
// rewrites* lib/api-zod/src/generated (and lib/api-client-react/src/generated)
// on disk. If that happens to run at the same moment as this build (e.g. a
// full-workspace restart launches every workflow at once), esbuild can catch
// the brief window where those files are deleted but not yet rewritten and
// fail with "Cannot read file" / "Could not resolve" for perfectly real,
// committed files. Retry a few times before giving up — the files reappear
// within well under a second once codegen finishes writing them.
const MAX_BUILD_ATTEMPTS = 5;
const RETRY_DELAY_MS = 750;

function isGeneratedFileRace(err) {
  const errors = err?.errors ?? [];
  return errors.some((e) => {
    const text = e.text ?? "";
    const file = e.location?.file ?? "";
    // For an unresolved-import error, esbuild's `location.file` is the file
    // DOING the importing (e.g. lib/api-zod/src/index.ts), not the missing
    // generated target it references (e.g. "./generated/api") — that target
    // only appears inside `text`. The original check compared `file` against
    // "*/generated" and therefore never matched this exact shape, so the race
    // it was written to catch went undetected and hard-failed the build
    // (2026-08-07 outage). Match on either: the importer living inside the
    // codegen'd packages, or the unresolved specifier itself pointing at
    // "./generated/...".
    const importerInCodegenPkg = file.includes("api-zod/src") || file.includes("api-client-react/src");
    const targetIsGenerated = /generated\//.test(text) || /generated\//.test(file);
    return (
      (text.includes("Cannot read file") || text.includes("Could not resolve")) &&
      (importerInCodegenPkg || targetIsGenerated)
    );
  });
}

async function buildAll() {
  runTests();
  const distDir = path.resolve(artifactDir, "dist");
  await rm(distDir, { recursive: true, force: true });

  for (let attempt = 1; attempt <= MAX_BUILD_ATTEMPTS; attempt++) {
    try {
      await runEsbuild(distDir);
      return;
    } catch (err) {
      const canRetry = attempt < MAX_BUILD_ATTEMPTS && isGeneratedFileRace(err);
      if (!canRetry) throw err;
      console.warn(
        `[build] esbuild hit a generated-file race with check-api-drift codegen ` +
        `(attempt ${attempt}/${MAX_BUILD_ATTEMPTS}) — retrying in ${RETRY_DELAY_MS}ms…`
      );
      await new Promise((r) => setTimeout(r, RETRY_DELAY_MS));
    }
  }
}

async function runEsbuild(distDir) {
  await esbuild({
    entryPoints: [path.resolve(artifactDir, "src/index.ts")],
    platform: "node",
    bundle: true,
    format: "esm",
    outdir: distDir,
    outExtension: { ".js": ".mjs" },
    logLevel: "info",
    // Some packages may not be bundleable, so we externalize them, we can add more here as needed.
    // Some of the packages below may not be imported or installed, but we're adding them in case they are in the future.
    // Examples of unbundleable packages:
    // - uses native modules and loads them dynamically (e.g. sharp)
    // - use path traversal to read files (e.g. @google-cloud/secret-manager loads sibling .proto files)
    external: [
      "*.node",
      "sharp",
      "better-sqlite3",
      "sqlite3",
      "canvas",
      "bcrypt",
      "argon2",
      "@node-rs/*", // @node-rs/argon2 (accounts): loads a per-platform native binding at runtime
      "fsevents",
      "re2",
      "farmhash",
      "xxhash-addon",
      "bufferutil",
      "utf-8-validate",
      "ssh2",
      "cpu-features",
      "dtrace-provider",
      "isolated-vm",
      "lightningcss",
      "pg-native",
      "oracledb",
      "mongodb-client-encryption",
      "nodemailer",
      "handlebars",
      "knex",
      "typeorm",
      "protobufjs",
      "onnxruntime-node",
      "@tensorflow/*",
      "@prisma/client",
      "@mikro-orm/*",
      "@grpc/*",
      "@swc/*",
      "@aws-sdk/*",
      "@azure/*",
      "@opentelemetry/*",
      "@google-cloud/*",
      "@google/*",
      "googleapis",
      "firebase-admin",
      "@parcel/watcher",
      "@sentry/profiling-node",
      "@tree-sitter/*",
      "aws-sdk",
      "classic-level",
      "dd-trace",
      "ffi-napi",
      "grpc",
      "hiredis",
      "kerberos",
      "leveldown",
      "miniflare",
      "mysql2",
      "newrelic",
      "odbc",
      "piscina",
      "realm",
      "ref-napi",
      "rocksdb",
      "sass-embedded",
      "sequelize",
      "serialport",
      "snappy",
      "tinypool",
      "usb",
      "workerd",
      "wrangler",
      "zeromq",
      "zeromq-prebuilt",
      "cron-parser",
      "playwright",
      "puppeteer",
      "puppeteer-core",
      "electron",
    ],
    sourcemap: "linked",
    plugins: [
      // pino relies on workers to handle logging, instead of externalizing it we use a plugin to handle it
      esbuildPluginPino({ transports: ["pino-pretty"] })
    ],
    // Make sure packages that are cjs only (e.g. express) but are bundled continue to work in our esm output file
    banner: {
      js: `import { createRequire as __bannerCrReq } from 'node:module';
import __bannerPath from 'node:path';
import __bannerUrl from 'node:url';

globalThis.require = __bannerCrReq(import.meta.url);
globalThis.__filename = __bannerUrl.fileURLToPath(import.meta.url);
globalThis.__dirname = __bannerPath.dirname(globalThis.__filename);
    `,
    },
  });
}

buildAll().catch((err) => {
  console.error(err);
  process.exit(1);
});
