/**
 * 15m purity (2026-08-27 score lift).
 *
 * Hourly KXBTCD and perps must not enter the 15m evaluate path while flags
 * are off. Does NOT import trading-bot.ts (locked by another executor).
 *
 * Covers:
 *   - durationBucket: PERP / hourly strings are never 15M
 *   - isStrategyAllowedForDuration: 1H-only / 15M-only vs string labels
 *   - 1H-only strategy evaluate() is never invoked on a 15m observation
 *   - enable1HContracts true in a test fixture does not leak into production
 *     .bot-config.json
 *   - evaluateHourlyTick source-text no-op when !enable1HContracts
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  durationBucket,
  isStrategyAllowedForDuration,
  evaluateAllStrategies,
  getStrategy,
  type StrategyObservation,
} from "./strategy-library.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const PRODUCTION_CONFIG = path.resolve(DIR, "../../.bot-config.json");
const BOT_SRC = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");

function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65_100,
    floorStrike: 65_000,
    velocityDolPerMin: 80,
    threeMinVelocity: 70,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.2,
    massAboveFloor: 55,
    secsRemaining: 20 * 60,
    contractDurationMins: 15,
    ...overrides,
  };
}

test("durationBucket: minutes — null/15 → 15M, 0 → PERP, ≥45 → 1H", () => {
  assert.equal(durationBucket(null), "15M");
  assert.equal(durationBucket(undefined), "15M");
  assert.equal(durationBucket(15), "15M");
  assert.equal(durationBucket(14), "15M");
  assert.equal(durationBucket(0), "PERP");
  assert.equal(durationBucket(45), "1H");
  assert.equal(durationBucket(60), "1H");
});

test("durationBucket: PERP / hourly strings are never treated as 15M", () => {
  assert.equal(durationBucket("PERP"), "PERP");
  assert.equal(durationBucket("perp"), "PERP");
  assert.equal(durationBucket("PERPETUAL"), "PERP");
  assert.equal(durationBucket("0"), "PERP");
  assert.equal(durationBucket("1H"), "1H");
  assert.equal(durationBucket("1h"), "1H");
  assert.equal(durationBucket("HOURLY"), "1H");
  assert.equal(durationBucket("60"), "1H");
  assert.equal(durationBucket("60M"), "1H");
  assert.equal(durationBucket("15M"), "15M");
  assert.equal(durationBucket("15"), "15M");
  assert.equal(durationBucket(""), "15M");
});

test("isStrategyAllowedForDuration: 1H-only OTM_BREAKOUT is not 15m or PERP", () => {
  assert.equal(isStrategyAllowedForDuration("OTM_BREAKOUT_EXPANSION", 15), false);
  assert.equal(isStrategyAllowedForDuration("OTM_BREAKOUT_EXPANSION", null), false);
  assert.equal(isStrategyAllowedForDuration("OTM_BREAKOUT_EXPANSION", "PERP"), false);
  assert.equal(isStrategyAllowedForDuration("OTM_BREAKOUT_EXPANSION", "1H"), true);
  assert.equal(isStrategyAllowedForDuration("OTM_BREAKOUT_EXPANSION", 60), true);
});

test("isStrategyAllowedForDuration: 15M-only CHEAP_SIDE is not hourly/PERP", () => {
  assert.equal(isStrategyAllowedForDuration("CHEAP_SIDE_15M", 15), true);
  assert.equal(isStrategyAllowedForDuration("CHEAP_SIDE_15M", "15M"), true);
  assert.equal(isStrategyAllowedForDuration("CHEAP_SIDE_15M", "1H"), false);
  assert.equal(isStrategyAllowedForDuration("CHEAP_SIDE_15M", 60), false);
  assert.equal(isStrategyAllowedForDuration("CHEAP_SIDE_15M", "PERP"), false);
  assert.equal(isStrategyAllowedForDuration("CHEAP_SIDE_15M", 0), false);
});

test("1H-only strategy evaluate() is never invoked on a 15m observation", () => {
  const otm1h = getStrategy("OTM_BREAKOUT_EXPANSION");
  assert.ok(otm1h);
  let calls = 0;
  const original = otm1h!.evaluate;
  otm1h!.evaluate = (obs) => { calls++; return original.call(otm1h, obs); };
  try {
    evaluateAllStrategies(baseObs({ contractDurationMins: 15 }));
    assert.equal(calls, 0, "1H-only evaluate() must not run on 15m obs");
    evaluateAllStrategies(baseObs({ contractDurationMins: undefined }));
    assert.equal(calls, 0, "missing duration defaults to 15M — 1H-only still skipped");
  } finally {
    otm1h!.evaluate = original;
  }
});

test("1H-only evaluate() is never invoked when duration label is PERP", () => {
  const otm1h = getStrategy("OTM_BREAKOUT_EXPANSION");
  assert.ok(otm1h);
  let calls = 0;
  const original = otm1h!.evaluate;
  otm1h!.evaluate = (obs) => { calls++; return original.call(otm1h, obs); };
  try {
    evaluateAllStrategies(baseObs({ contractDurationMins: "PERP" as unknown as number }));
    assert.equal(calls, 0, "PERP string must not enter 1H-only evaluate, and must not be treated as 15M");
  } finally {
    otm1h!.evaluate = original;
  }
});

test("evaluateHourlyTick source-text no-ops when !enable1HContracts", () => {
  assert.match(
    BOT_SRC,
    /if \(!this\.config\.enable1HContracts\) return;/,
    "evaluateHourlyTick must no-op at the wrapper top when the 1H flag is off",
  );
  assert.match(
    BOT_SRC,
    /hourlyOrPerpEvaluateAllowed/,
    "evaluateHourlyTick must also consult hourlyOrPerpEvaluateAllowed so flags-off cannot bypass",
  );
  assert.ok(BOT_SRC.includes("enable1HLive"), "1H live flag still exists");
});

test("enable1HContracts true in a test fixture does not leak into production .bot-config.json", { skip: !fs.existsSync(PRODUCTION_CONFIG) && "runtime .bot-config.json absent (gitignored; fresh clone/CI) — paper lock covered by hard-locks.unify.test.ts" }, () => {
  assert.ok(fs.existsSync(PRODUCTION_CONFIG), `missing production config at ${PRODUCTION_CONFIG}`);
  const before = JSON.parse(fs.readFileSync(PRODUCTION_CONFIG, "utf8")) as Record<string, unknown>;
  assert.equal(before.enable1HContracts, false);
  assert.equal(before.enable1HLive, false);
  assert.equal(before.paperMode, true);
  assert.equal(before.autoMode, false, "disk doctrine: autoMode false");
  assert.equal(before.paperStartingBalanceCents, 31300);

  const envPath = process.env.BOT_CONFIG_PATH;
  assert.ok(envPath, "BOT_CONFIG_PATH must be set so tests never write the production file");
  assert.notEqual(path.resolve(envPath), path.resolve(PRODUCTION_CONFIG));

  const fixture = path.join(os.tmpdir(), `1h-leak-fixture-${process.pid}-${Date.now()}.json`);
  try {
    fs.writeFileSync(fixture, JSON.stringify({
      enable1HContracts: true,
      enable1HLive: true,
      paperMode: false,
      autoMode: false,
    }, null, 2));
    const after = JSON.parse(fs.readFileSync(PRODUCTION_CONFIG, "utf8")) as Record<string, unknown>;
    assert.equal(after.enable1HContracts, false, "production enable1HContracts must stay false");
    assert.equal(after.enable1HLive, false);
    assert.equal(after.paperMode, true);
    assert.equal(after.autoMode, false, "disk doctrine: autoMode false");
    assert.deepEqual(after, before, "hostile test fixture must not mutate production .bot-config.json");
  } finally {
    fs.rmSync(fixture, { force: true });
  }
});
