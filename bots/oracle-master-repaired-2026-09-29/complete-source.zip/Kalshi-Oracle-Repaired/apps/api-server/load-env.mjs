import { existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const candidates = [resolve(process.cwd(), '.env'), resolve(here, '../../.env')];
for (const p of candidates) {
  if (existsSync(p) && typeof process.loadEnvFile === 'function') {
    process.loadEnvFile(p);
    break;
  }
}
if (!process.env.PORT) process.env.PORT = '8080';
if (!process.env.NODE_ENV) process.env.NODE_ENV = 'development';
