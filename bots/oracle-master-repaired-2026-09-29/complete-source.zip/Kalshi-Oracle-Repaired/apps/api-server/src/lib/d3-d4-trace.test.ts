import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { finiteAskOrNull } from "./decision-trace.js";
import { appendEntryShadowVeto } from "./frozen-cc-entry-shadow.js";

test("D4: 0/100 no-book sentinels become null, real asks pass", () => {
  assert.equal(finiteAskOrNull(0), null);
  assert.equal(finiteAskOrNull(100), null);
  assert.equal(finiteAskOrNull(undefined), null);
  assert.equal(finiteAskOrNull(Number.NaN), null);
  assert.equal(finiteAskOrNull(34), 34);
});

test("D3(c): veto outcome row is appended for the shadow decision", () => {
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), "veto-")), "l.jsonl");
  appendEntryShadowVeto({ decisionId: "d1", ticker: "KXBTC15M-X", side: "no", realDecision: "VETO:MIND_HEAVE_BIND", reason: "edge" }, f);
  const row = JSON.parse(fs.readFileSync(f, "utf8").trim());
  assert.equal(row.kind, "VETO");
  assert.equal(row.decisionId, "d1");
  assert.equal(row.realDecision, "VETO:MIND_HEAVE_BIND");
});
