/**
 * Fast tape + fail-closed fallbacks (2026-09-02).
 * No live socket. EV/Kelly/9%/15%/daily halt untouched.
 */
import assert from "node:assert/strict";
import test from "node:test";
import {
  feedAgeMs,
  lastGoodOrSkip,
  nextWsReconnectBackoffMs,
  shouldForceReconnectOnSilence,
  shouldApplyRestQuote,
  isLiveWsOdds,
  restQuoteBlocksFill,
  MIN_BACKOFF_MS,
  MAX_BACKOFF_MS,
  PRICE_POLL_HEALTHY_MS,
  PRICE_POLL_DEGRADED_MS,
  WS_SILENCE_THRESHOLD_MS,
  WS_LIVE_QUOTE_MS,
} from "./kalshi-ws.js";
import { isFeedStaleForEntry } from "./trading-bot.js";
import {
  paperMoneyMakerIgnoresSettlementSideSkip,
  decideSettlementSide,
} from "./settlement-side.js";

test("reconnect backoff tightens 250ms → 8s, never 30s", () => {
  assert.equal(MIN_BACKOFF_MS, 250);
  assert.equal(MAX_BACKOFF_MS, 8_000);
  let b = MIN_BACKOFF_MS;
  const seen: number[] = [];
  for (let i = 0; i < 8; i++) {
    b = nextWsReconnectBackoffMs(b);
    seen.push(b);
  }
  assert.equal(seen[0], 500);
  assert.equal(seen[seen.length - 1], 8_000);
  assert.ok(seen.every((x) => x <= 8_000));
  assert.ok(PRICE_POLL_DEGRADED_MS < PRICE_POLL_HEALTHY_MS);
  assert.ok(PRICE_POLL_DEGRADED_MS <= 500);
  assert.ok(PRICE_POLL_HEALTHY_MS <= 500);
  assert.equal(PRICE_POLL_HEALTHY_MS, 250);
  assert.equal(PRICE_POLL_DEGRADED_MS, 200);
});

test("silence reconnect is 12s (15m tape), not 90s", () => {
  const now = 2_000_000_000;
  assert.equal(WS_SILENCE_THRESHOLD_MS, 12_000);
  assert.equal(shouldForceReconnectOnSilence(now - 12_000, now), false);
  assert.equal(shouldForceReconnectOnSilence(now - 12_001, now), true);
});

test("last-good + age: skip when never observed; stale when old; never invents a mid", () => {
  const now = 1_000_000;
  assert.equal(lastGoodOrSkip(null, now, 5_000), null);
  assert.equal(feedAgeMs(null, now), Number.POSITIVE_INFINITY);
  const fresh = lastGoodOrSkip({ value: 42, observedAt: now - 200 }, now, 5_000);
  assert.ok(fresh);
  assert.equal(fresh.value, 42);
  assert.equal(fresh.stale, false);
  assert.equal(fresh.ageMs, 200);
  const old = lastGoodOrSkip({ value: 42, observedAt: now - 8_000 }, now, 5_000);
  assert.ok(old);
  assert.equal(old.value, 42);
  assert.equal(old.stale, true);
  assert.equal(old.ageMs, 8_000);
});

test("Kalshi WS die → REST apply_fallback with age; REST is never live odds", () => {
  const now = 3_000_000_000;
  const deadWs = {
    source: "ws" as const,
    quoteTs: now - 8_000,
    yesBid: 41,
    yesAsk: 43,
    noBid: 57,
    noAsk: 59,
  };
  assert.equal(shouldApplyRestQuote({
    lastWsMessageTs: now - 8_000,
    latest: deadWs,
    restHasQuotes: true,
    nowMs: now,
  }), "apply_fallback");
  assert.equal(isLiveWsOdds({
    source: "rest", quoteTs: now, lastWsMessageTs: now - 8_000, nowMs: now,
  }), false);
  assert.equal(shouldApplyRestQuote({
    lastWsMessageTs: now - 8_000,
    latest: deadWs,
    restHasQuotes: false,
    nowMs: now,
  }), "skip_no_quotes");
  assert.ok(WS_LIVE_QUOTE_MS <= 5_000);
});

test("LIVE REST still blocks fill; paper REST ignores REST_NOT_LIVE", () => {
  assert.equal(restQuoteBlocksFill(false, "rest"), true);
  assert.equal(restQuoteBlocksFill(false, "ws"), false);
  assert.equal(restQuoteBlocksFill(true, "rest"), false);
  assert.equal(restQuoteBlocksFill(true, "ws"), false);
});

test("quote_stale 5s msg / 60s quote is identical paper vs live", () => {
  assert.equal(isFeedStaleForEntry(4_000, 14_000, true), false);
  assert.equal(isFeedStaleForEntry(4_000, 14_000, false), false);
  assert.equal(isFeedStaleForEntry(5_001, 1_000, true), true);
  assert.equal(isFeedStaleForEntry(5_001, 1_000, false), true);
  // Quiet book: quote >15s but <60s with fresh msgs — not frozen.
  assert.equal(isFeedStaleForEntry(1_000, 15_001, true), false);
  assert.equal(isFeedStaleForEntry(1_000, 15_001, false), false);
  assert.equal(isFeedStaleForEntry(1_000, 60_001, true), true);
  assert.equal(isFeedStaleForEntry(1_000, 60_001, false), true);
});

test("paper=live remake-ignore lag_stale; quote_stale KEEP both", () => {
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(false, "BASIS_LAG_EDGE", "lag_stale"), true);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "BASIS_LAG_EDGE", "lag_stale"), true);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "lag_stale"), true);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(false, "CONFLUENCE_CASCADE", "lag_stale"), true);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "BASIS_LAG_EDGE", "quote_stale"), false);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(false, "BASIS_LAG_EDGE", "quote_stale"), false);

  const liveBlind = decideSettlementSide({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: true, lagDollars: null, quoteAgeMs: 200,
  });
  assert.equal(liveBlind.side, "skip");
  assert.equal(liveBlind.reason, "lag_stale");

  const liveMissingDollars = decideSettlementSide({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: null, quoteAgeMs: 200,
  });
  assert.equal(liveMissingDollars.side, "skip");
  assert.ok(liveMissingDollars.reason === "lag_disagrees" || liveMissingDollars.reason === "lag_dollars_too_small");

  const quoteStale = decideSettlementSide({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: 40, quoteAgeMs: 61_000,
  });
  assert.equal(quoteStale.reason, "quote_stale");
});
