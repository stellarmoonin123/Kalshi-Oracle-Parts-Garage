/**
 * alignedTakeGate — isolate-rewrite organ (select/side path).
 * TAKE {CC|LAG, side, ask, p, ev} or SKIP {reason}.
 * CC does not inherit LAG_UNPROVEN. LAG requires lagProven.
 * p = P(filled side) = winRateAtPrice(side, ask). Constructing NO uses P(NO).
 * leftover SETTLEMENT_SIDE / leftover best cannot beat a TAKE.
 * MTF_FILTER veto of unaligned cheap is KEEP (opposed SKIP unless cheap aligned NO).
 * TAKE side is cheap aligned vs MTF/river AND Kalshi strike (spot vs floor).
 * Fail-closed if strike unknown. Constructed aligned cheap NO when MTF short stays.
 * Last-60s BRTI is EXIT only — new entries SKIP LAST_60S_BRTI_AVG.
 * Still-mid 48–52 is HARD SKIP for ALL (including lagProven LAG) — fill-power lock.
 * Ask band YES 20–55 / NO 20–55 (PAPER DESK v2 door for CC|LAG). No sub-20 lottery.
 * Never take 87–95 YES or 5–14 NO. Gold-cell tags may log 56–62 / LAG 48–52 but
 * those must NOT TAKE under this lock. EV≥3 KEEP. paperMode / floors KEEP.
 */
import { computeTradeEV } from "./trade-path.js";
import { EV_FLOOR } from "./admission.js";
import { confluenceWinRate } from "./confluence-cascade.js";
import { basisLagWinRate } from "./basis-lag-edge.js";
import { kalshiStrikeContractSide, SETTLEMENT_SIDE_QUOTE_STALE_MS } from "./settlement-side.js";
import { matchGoldCell, preferGoldStrategyId } from "./gold-trade-copy.js";
import { inDeskAskBand } from "./paper-desk-v2.js";

export const ALIGNED_ASK_MIN_CENTS = 20;
/** PAPER DESK v2: NO ask band floor (same 20 as YES). */
export const ALIGNED_NO_ASK_MIN_CENTS = 20;
/** Fill-power lock: aligned max 55 (not 62). Gold 56–62 may still TAG but must not TAKE. */
export const ALIGNED_ASK_MAX_CENTS = 55;
/**
 * LAG tryTake ask floor = desk door 20 (same as CC / PAPER DESK v2). No sub-20 lottery.
 */
export const LAG_ALIGNED_ASK_MIN_CENTS = 20;
export const LAG_ASK_BELOW_MIN_SKIP = "lag_ask_below_20";
/** Coin-flip unfinished BRTI minute. New entries only. Does not flatten an open ride. */
export const LAST_60S_BRTI_SECS = 60;
export const LAST_60S_BRTI_AVG_SKIP = "LAST_60S_BRTI_AVG";
/** Still-mid ~50¢. Inclusive. HARD skip for CC and LAG (no lagProven exemption). */
export const STILL_MID_MIN_CENTS = 48;
export const STILL_MID_MAX_CENTS = 52;
export const STILL_MID_UNCLEAR_SKIP = "still_mid_unclear";
export const MONEY_MAKER_IDS = ["CONFLUENCE_CASCADE", "BASIS_LAG_EDGE"] as const;
/** PAPER DESK v2 placeable — not leftover HARD_NO_FILL. */
export const PAPER_DESK_PLACEABLE_IDS = [
  "CONFLUENCE_CASCADE", "BASIS_LAG_EDGE", "VELOCITY_MOMENTUM",
  "BRTI_PROBABILITY", "PANIC_FADE", "CHEAP_SIDE_15M",
] as const;


export type AlignedMtfSign = number | "long" | "short" | "yes" | "no" | null | undefined;

export type AlignedTakeInput = {
  mtfSign?: AlignedMtfSign;
  yesAsk?: number | null;
  noAsk?: number | null;
  lagProven?: boolean;
  strategyId?: string | null;
  winRateAtPrice?: (side: "yes" | "no", ask: number, strategyId?: string) => number | null | undefined;
  p?: number | null;
  ev?: number | null;
  quoteStale?: boolean;
  quoteFresh?: boolean;
  quoteAgeMs?: number | null;
  secsRemaining?: number;
  /** BTC spot for Kalshi strike. Fail-closed if missing/invalid. */
  spot?: number | null;
  currentPrice?: number | null;
  /** Contract floor/strike. YES iff spot >= floor. */
  floorStrike?: number | null;
};

export type AlignedTake =
  | {
      kind: "TAKE";
      strategyId: "CONFLUENCE_CASCADE" | "BASIS_LAG_EDGE";
      side: "yes" | "no";
      ask: number;
      p: number;
      ev: number;
      /** Heavy R1#2: true when MTF short constructed cheap NO. */
      constructedNo?: boolean;
      /** Replit gold-trade-copy: same winning cell shape as settled live book. */
      goldCopy?: boolean;
      /** Cell id from replit-gold-cells.json (e.g. LAG_YES_42_50). */
      replitCell?: string;
    }
  | { kind: "SKIP"; reason: string };

export function mtfSignToSide(mtfSign: AlignedMtfSign): "yes" | "no" | null {
  if (mtfSign === "long" || mtfSign === "yes") return "yes";
  if (mtfSign === "short" || mtfSign === "no") return "no";
  if (typeof mtfSign === "number" && Number.isFinite(mtfSign)) {
    if (mtfSign > 0) return "yes";
    if (mtfSign < 0) return "no";
  }
  return null;
}

export function isLeftoverStrategyId(id: string | null | undefined): boolean {
  if (!id) return false;
  // PAPER DESK v2 six are placeable — not leftover.
  if ((PAPER_DESK_PLACEABLE_IDS as readonly string[]).includes(id)) return false;
  return true;
}


/** YES [28,55]; NO [22,55]. Still-mid checked separately. */
export function inSideAskBand(
  side: "yes" | "no",
  ask: number | null | undefined,
): ask is number {
  if (typeof ask !== "number" || !Number.isFinite(ask)) return false;
  if (ask > ALIGNED_ASK_MAX_CENTS) return false;
  const min = side === "no" ? ALIGNED_NO_ASK_MIN_CENTS : ALIGNED_ASK_MIN_CENTS;
  return ask >= min;
}

function inAlignedBand(ask: number | null | undefined): ask is number {
  return typeof ask === "number" && Number.isFinite(ask)
    && ask >= ALIGNED_ASK_MIN_CENTS && ask <= ALIGNED_ASK_MAX_CENTS;
}

/** CC|LAG money path: desk door YES 20–55 / NO 20–55 (paper desk v2). */
export function inStrategyAskBand(
  ask: number | null | undefined,
  strategyId: "CONFLUENCE_CASCADE" | "BASIS_LAG_EDGE" | null | undefined,
  side?: "yes" | "no" | null,
): ask is number {
  void strategyId;
  if (typeof ask !== "number" || !Number.isFinite(ask)) return false;
  if (side === "yes" || side === "no") return inDeskAskBand(side, ask);
  // Side omitted: fail closed to YES door (28–55). Never OR the NO wing — that
  // let YES@22–27 pass W2 as if they were NO asks (operator false trust).
  return inDeskAskBand("yes", ask);
}

function anyMoneyMakerAskInBand(
  input: AlignedTakeInput,
  ask: number | null | undefined,
  side?: "yes" | "no",
): boolean {
  // PAPER DESK v2 door: YES 20–55 / NO 20–55 (still-mid excluded inside inDeskAskBand).
  // Do not admit YES 10–27 via old LAG floor — that fought the desk door and lottery takes.
  void input;
  if (side === "yes" || side === "no") {
    return typeof ask === "number" && inDeskAskBand(side, ask);
  }
  // Side unknown: YES door only (fail closed). Callers must pass side for NO.
  return typeof ask === "number" && inDeskAskBand("yes", ask);
}

/** secsRemaining known and ≤60. Missing secs is not last-minute (tests / mid-window). */
export function inLast60sBrti(secsRemaining: number | undefined): boolean {
  return typeof secsRemaining === "number" && Number.isFinite(secsRemaining)
    && secsRemaining <= LAST_60S_BRTI_SECS;
}


/** Inclusive 48–52 coin-flip. Do not add 50¢ takes. */
export function inStillMidCoinFlip(ask: number | null | undefined): boolean {
  return typeof ask === "number" && Number.isFinite(ask)
    && ask >= STILL_MID_MIN_CENTS && ask <= STILL_MID_MAX_CENTS;
}

/**
 * Still-mid entry block — HARD for every strategy (fill-power lock).
 * lagProven LAG exemption removed: 48–52 always blocks new takes.
 * Gold-cell tags may still log LAG 48–52 shapes but must not TAKE.
 */
export function stillMidUnclearBlocksEntry(opts: {
  ask: number | null | undefined;
  lagProven?: boolean | null;
  strategyId?: string | null;
}): boolean {
  void opts.lagProven;
  void opts.strategyId;
  return inStillMidCoinFlip(opts.ask);
}

/**
 * True when executable fill (raw ask + sweep) lands in still-mid 48–52.
 * Aligned/W2 gate the raw ask; evaluateEntry must also refuse swept fills
 * that cross into the coin-flip band (e.g. raw 47 + 1¢ sweep → 48).
 */
export function sweptFillHitsStillMid(
  rawAsk: number | null | undefined,
  sweepCents: number,
): boolean {
  if (typeof rawAsk !== "number" || !Number.isFinite(rawAsk)) return false;
  if (typeof sweepCents !== "number" || !Number.isFinite(sweepCents) || sweepCents < 0) {
    return inStillMidCoinFlip(rawAsk);
  }
  return inStillMidCoinFlip(rawAsk + sweepCents);
}

/**
 * Heavy R1#2 constructed-NO sign check.
 * NO ticket must use noAsk and P(NO) — never yesAsk / P(YES) for green/EV.
 */
export function constructedNoSignCheck(opts: {
  side: "yes" | "no";
  ask: number;
  yesAsk?: number | null;
  noAsk?: number | null;
  p: number;
  pYes?: number | null;
  pNo?: number | null;
}): { ok: true } | { ok: false; reason: string } {
  if (opts.side !== "no") return { ok: true };
  const noAsk = opts.noAsk;
  if (typeof noAsk !== "number" || !Number.isFinite(noAsk)) {
    return { ok: false, reason: "noAsk_missing" };
  }
  if (opts.ask !== noAsk) return { ok: false, reason: "ask_not_noAsk" };
  const yesAsk = opts.yesAsk;
  if (
    typeof yesAsk === "number"
    && Number.isFinite(yesAsk)
    && yesAsk !== noAsk
    && opts.ask === yesAsk
  ) {
    return { ok: false, reason: "ask_is_yesAsk" };
  }
  if (
    typeof opts.pYes === "number"
    && Number.isFinite(opts.pYes)
    && typeof opts.pNo === "number"
    && Number.isFinite(opts.pNo)
    && opts.pYes !== opts.pNo
    && opts.p === opts.pYes
  ) {
    return { ok: false, reason: "p_is_P_YES" };
  }
  if (
    typeof opts.pNo === "number"
    && Number.isFinite(opts.pNo)
    && opts.p !== opts.pNo
  ) {
    return { ok: false, reason: "p_not_P_NO" };
  }
  return { ok: true };
}

/** Durable log line when taking constructed NO: side=no, p=P(NO), ask=noAsk. */
export function formatConstructedNoLog(opts: { p: number; ask: number }): string {
  return `[CONSTRUCTED_NO] side=no p=${opts.p} ask=${opts.ask}`;
}

function quoteIsStale(input: AlignedTakeInput): boolean {
  if (input.quoteStale === true) return true;
  if (input.quoteFresh === false) return true;
  if (input.quoteAgeMs != null) {
    if (!Number.isFinite(input.quoteAgeMs) || input.quoteAgeMs > SETTLEMENT_SIDE_QUOTE_STALE_MS) return true;
  }
  return false;
}

function minutesLeft(input: AlignedTakeInput): number {
  const secs = input.secsRemaining;
  if (typeof secs === "number" && Number.isFinite(secs) && secs > 0) return secs / 60;
  return 7;
}

function pFor(input: AlignedTakeInput, side: "yes" | "no", ask: number, strategyId: string): number | null {
  // Heavy R1#2: side-bound curve first. Never let a leaked P(YES) ride a NO ticket
  // when winRateAtPrice(side, ask) is available.
  if (input.winRateAtPrice) {
    const p = input.winRateAtPrice(side, ask, strategyId);
    if (typeof p === "number" && Number.isFinite(p) && p > 0 && p <= 1) return p;
    return null;
  }
  if (typeof input.p === "number" && Number.isFinite(input.p) && input.p > 0 && input.p <= 1) {
    return input.p;
  }
  const mins = minutesLeft(input);
  const wr = strategyId === "BASIS_LAG_EDGE"
    ? basisLagWinRate(ask, mins)
    : confluenceWinRate(ask, mins);
  if (typeof wr === "number" && Number.isFinite(wr) && wr > 0 && wr <= 1) return wr;
  return null;
}

function evFor(input: AlignedTakeInput, strategyId: string, ask: number, p: number): number | null {
  // SIGN-SAFE: when winRateAtPrice bound side p, always derive EV from that p+ask.
  // Leaked input.ev must not green a wrong-side ticket (YES EV on a NO fill).
  if (input.winRateAtPrice) {
    const net = computeTradeEV({
      entryPriceCents: ask,
      winRate: p,
      strategyId,
      secsRemaining: input.secsRemaining,
    }).netEV;
    return Number.isFinite(net) ? net : null;
  }
  if (typeof input.ev === "number" && Number.isFinite(input.ev)) return input.ev;
  const net = computeTradeEV({
    entryPriceCents: ask,
    winRate: p,
    strategyId,
    secsRemaining: input.secsRemaining,
  }).netEV;
  return Number.isFinite(net) ? net : null;
}

function tagGoldCopy(
  take: Extract<AlignedTake, { kind: "TAKE" }>,
): Extract<AlignedTake, { kind: "TAKE" }> {
  // LAG TAKE only fires when lagProven; treat as proven for cell match.
  const g = matchGoldCell({
    strategyId: take.strategyId,
    side: take.side,
    ask: take.ask,
    lagProven: take.strategyId === "BASIS_LAG_EDGE" ? true : undefined,
  });
  if (g.match && g.cellId) {
    return { ...take, goldCopy: true, replitCell: g.cellId };
  }
  return take;
}

function tryTake(
  input: AlignedTakeInput,
  strategyId: "CONFLUENCE_CASCADE" | "BASIS_LAG_EDGE",
  side: "yes" | "no",
  ask: number,
  constructedNo = false,
): AlignedTake {
  // LAG + CC desk door YES 20 / NO 20; both max 55 (PAPER DESK v2).
  if (ask > ALIGNED_ASK_MAX_CENTS) {
    return { kind: "SKIP", reason: "ask_out_of_band" };
  }
  // Desk door 20 for both CC and LAG (LAG_ALIGNED_ASK_MIN_CENTS === ALIGNED_ASK_MIN_CENTS).
  const deskMin = side === "no" ? ALIGNED_NO_ASK_MIN_CENTS : ALIGNED_ASK_MIN_CENTS;
  if (ask < deskMin) {
    if (strategyId === "BASIS_LAG_EDGE") {
      return { kind: "SKIP", reason: LAG_ASK_BELOW_MIN_SKIP };
    }
    return { kind: "SKIP", reason: "ask_out_of_band" };
  }
  // Heavy R1#2: NO green/EV must use noAsk, never yesAsk.
  if (side === "no") {
    const noAsk = input.noAsk;
    if (typeof noAsk !== "number" || !Number.isFinite(noAsk) || ask !== noAsk) {
      return { kind: "SKIP", reason: "constructed_no_ask_mismatch" };
    }
  }
  const p = pFor(input, side, ask, strategyId);
  if (p == null) return { kind: "SKIP", reason: "p_null" };
  if (side === "no" && input.winRateAtPrice) {
    const pYes = typeof input.yesAsk === "number"
      ? input.winRateAtPrice("yes", input.yesAsk, strategyId)
      : null;
    const check = constructedNoSignCheck({
      side, ask, yesAsk: input.yesAsk, noAsk: input.noAsk, p,
      pYes: typeof pYes === "number" ? pYes : null,
      pNo: p,
    });
    if (!check.ok) return { kind: "SKIP", reason: check.reason };
  }
  const ev = evFor(input, strategyId, ask, p);
  if (ev == null) return { kind: "SKIP", reason: "p_null" };
  if (ev < EV_FLOOR) return { kind: "SKIP", reason: "ev_below_3" };
  let take: Extract<AlignedTake, { kind: "TAKE" }> = {
    kind: "TAKE", strategyId, side, ask, p, ev,
  };
  if (constructedNo && side === "no") {
    take = { ...take, constructedNo: true };
  }
  return tagGoldCopy(take);
}

function takeCheap(
  input: AlignedTakeInput,
  considerCc: boolean,
  considerLag: boolean,
  side: "yes" | "no",
  ask: number,
  constructedNo = false,
): AlignedTake {
  // Still-mid 48–52 HARD for all (fill-power lock). No lagProven LAG exemption.
  if (stillMidUnclearBlocksEntry({
    ask,
    lagProven: input.lagProven,
    strategyId: input.strategyId,
  })) {
    return { kind: "SKIP", reason: STILL_MID_UNCLEAR_SKIP };
  }

  // Gold-copy: prefer winning strategy shape when cell matches AND in TAKE band.
  // Example: LAG YES @44¢ → BASIS_LAG_EDGE over CC when lagProven + EV≥3.
  const prefer = preferGoldStrategyId({
    side,
    ask,
    lagProven: input.lagProven,
    strategyId: input.strategyId,
  });
  if (prefer === "BASIS_LAG_EDGE" && considerLag && input.lagProven === true) {
    const take = tryTake(input, "BASIS_LAG_EDGE", side, ask, constructedNo);
    if (take.kind === "TAKE") return take;
  }
  if (prefer === "CONFLUENCE_CASCADE" && considerCc) {
    const take = tryTake(input, "CONFLUENCE_CASCADE", side, ask, constructedNo);
    if (take.kind === "TAKE") return take;
  }

  if (considerCc) {
    const take = tryTake(input, "CONFLUENCE_CASCADE", side, ask, constructedNo);
    if (take.kind === "TAKE") return take;
    // Desk door: no LAG fallthrough below 20 (same 20/20 band as CC).
    const allowLagFallthrough = false;
    if (!allowLagFallthrough && (take.reason === "p_null" || take.reason === "ev_below_3" || take.reason.startsWith("p_") || take.reason.startsWith("ask_") || take.reason.startsWith("constructed_") || take.reason === LAG_ASK_BELOW_MIN_SKIP)) {
      return take;
    }
  }
  if (considerLag) {
    if (input.lagProven !== true) return { kind: "SKIP", reason: "LAG_UNPROVEN" };
    return tryTake(input, "BASIS_LAG_EDGE", side, ask, constructedNo);
  }
  return { kind: "SKIP", reason: "no_cc_lag" };
}

/**
 * Rewrite winner. Fail-closed. CC TAKE does not require lagProven.
 * Kalshi 15m side is strike (spot vs floor), not analog last-close-vs-next-close.
 */
export function alignedTakeGate(input: AlignedTakeInput): AlignedTake {
  if (quoteIsStale(input)) return { kind: "SKIP", reason: "quote_stale" };
  // Last-60s BRTI is EXIT only. Coin-flip unfinished BRTI minute. Not SETTLEMENT_LAG entry.
  // Existing open PATH_RIDE is not flattened by this skip (exit organ).
  if (inLast60sBrti(input.secsRemaining)) {
    return { kind: "SKIP", reason: LAST_60S_BRTI_AVG_SKIP };
  }
  if (isLeftoverStrategyId(input.strategyId)) {
    return { kind: "SKIP", reason: "leftover_id" };
  }

  const mtfSide = mtfSignToSide(input.mtfSign);
  if (!mtfSide) return { kind: "SKIP", reason: "mtf_sign_null" };

  const strike = kalshiStrikeContractSide(
    input.spot ?? input.currentPrice,
    input.floorStrike,
  );
  if (!strike) return { kind: "SKIP", reason: "strike_unknown" };

  const considerCc = input.strategyId == null || input.strategyId === "CONFLUENCE_CASCADE";
  const considerLag = input.strategyId == null || input.strategyId === "BASIS_LAG_EDGE";

  if (considerLag && input.lagProven !== true && input.strategyId === "BASIS_LAG_EDGE") {
    return { kind: "SKIP", reason: "LAG_UNPROVEN" };
  }

  // Construct aligned cheap NO when MTF short (MTF_FILTER KEEP opposed YES).
  // W2 strike_disagree carve is ENTRY-gated: lagProven + feeds fresh only;
  // through-floor ≥$20 against wing + lag unproven → W2 SKIP (GG #721).
  // Heavy R1#2: p = P(NO).
  if (mtfSide === "no") {
    if (anyMoneyMakerAskInBand(input, input.noAsk, "no")) {
      return takeCheap(input, considerCc, considerLag, "no", input.noAsk!, true);
    }
    // MTF_FILTER KEEP: opposed in-band YES stays SKIP (do not flip short→YES).
    if (anyMoneyMakerAskInBand(input, input.yesAsk, "yes")) return { kind: "SKIP", reason: "opposed_side" };
    if (inStillMidCoinFlip(input.noAsk)) {
      return { kind: "SKIP", reason: STILL_MID_UNCLEAR_SKIP };
    }
    return { kind: "SKIP", reason: "ask_out_of_band" };
  }

  // MTF long: TAKE aligned cheap YES in band (FLOOR_CROSS — spot wick below floor
  // is not an entry veto). #518 YES 31 + strike YES stays YES.
  // Prefer in-band cheap NO wing over opposed rich YES lean (YES @68–69 out of
  // band + NO @33 in [22,55] → evaluate/TAKE NO when door/EV passes). Do not
  // SKIP-only on the rich lean; HA/MTF must not force rich YES when cheap NO is legal.
  if (anyMoneyMakerAskInBand(input, input.yesAsk, "yes")) {
    return takeCheap(input, considerCc, considerLag, "yes", input.yesAsk!);
  }
  if (anyMoneyMakerAskInBand(input, input.noAsk, "no")) {
    return takeCheap(input, considerCc, considerLag, "no", input.noAsk!, true);
  }
  // Prefer honest still-mid reason when the lean wing is 48–52 (not generic ask_out).
  if (mtfSide === "yes" && inStillMidCoinFlip(input.yesAsk)) {
    return { kind: "SKIP", reason: STILL_MID_UNCLEAR_SKIP };
  }
  return { kind: "SKIP", reason: "ask_out_of_band" };
}

export function overlayAlignedTake<T extends { strategyId: string; signal: string }>(
  selected: T | null,
  pool: T[],
  gate: AlignedTake,
): T | null {
  if (gate.kind !== "TAKE") {
    // Last-60s / still-mid skips veto NEW entries. Opposed/leftover SKIP keeps selected
    // (MTF opposed veto KEEP). Does not flatten an already-open ride.
    if (gate.reason === LAST_60S_BRTI_AVG_SKIP || gate.reason === STILL_MID_UNCLEAR_SKIP) {
      return null;
    }
    return selected;
  }
  const wantSig = gate.side === "yes" ? "YES" : "NO";
  const match = pool.find(r => r.strategyId === gate.strategyId && r.signal === wantSig)
    ?? pool.find(r => r.strategyId === gate.strategyId)
    ?? pool.find(r => !isLeftoverStrategyId(r.strategyId) && r.signal === wantSig)
    ?? pool.find(r => !isLeftoverStrategyId(r.strategyId));
  if (match) {
    return { ...match, strategyId: gate.strategyId, signal: wantSig };
  }
  if (selected && isLeftoverStrategyId(selected.strategyId)) return null;
  if (selected && !isLeftoverStrategyId(selected.strategyId)) {
    return { ...selected, strategyId: gate.strategyId, signal: wantSig };
  }
  return selected;
}
