/**
 * QUARANTINE — cheap-side-15m.ts
 * DEAD_REMOVE candidate / leftover deny. OFF money-path placeOrder wire.
 * Shadow/replay imports may remain; HARD_NO_FILL + paper-release still block fills.
 * DO NOT ENABLE. DO NOT WIRE as a second entry law beside frozen six-gate / CC|LAG.
 *
 * --- original header follows ---
 */
/**
 * cheap-side-15m.ts
 *
 * Extracted CHEAP_SIDE_15M signal/evaluate helpers. Paper/research signal
 * only — not a live engine, does not flip cheapSide15mEnabled, does not
 * bypass computeTradeEV / PATH_GATE / Kelly / 9%.
 *
 * PAPER DESK v2 bands:
 *   - Down(NO) 22–47¢ / Up(YES) 28–47¢
 *   - dual-gate = cheapSide15mEnabled === true only (no paperMode OR-unlock; paper≡live)
 *   - mid-window 2–12m
 *   - MTF veto via decideSettlementSide (mtf <= -3 no YES, mtf >= +3 no NO)
 *
 * p for side selection is cheapSideWinRate (winRateAtPrice), never confidence.
 */

import fs from "node:fs";
import { computeTradeEV } from "./trade-path.js";
import { evaluateLiquidity, logLiquidityDecision } from "./liquidity-policy.js";
import { decideSettlementSideLogged } from "./settlement-side.js";
import { classifyBarWindow } from "./timing-clock.js";
import type { StrategyObservation, StrategyResult, TradeSignal } from "./strategy-library.js";
import { researchDir, researchPath } from "./desk-data-dir.js";

export const CHEAP_SIDE_ASK_MIN_CENTS = 20;
export const CHEAP_SIDE_ASK_MAX_CENTS = 47;
export const CHEAP_SIDE_MIN_MINS = 2;
export const CHEAP_SIDE_MAX_MINS = 12;
export const CHEAP_SIDE_MIN_PROJ_DIST_PCT = 0.05;
export const CHEAP_SIDE_MIN_STREAK = 2;
export const CHEAP_SIDE_MIN_EDGE_PTS = 8;

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

/** Dual-gate: ENABLE flag only (obs.cheapSide15mEnabled must be true; no paperMode force). */
export function isCheapSideDualGateOpen(enabled: boolean | undefined): boolean {
  return enabled === true;
}

/** Desk cheap band 22–47 (NO). YES uses 28–47 via isCheapAskForSide. */
export function isCheapAsk(ask: number | undefined | null): boolean {
  return typeof ask === "number" && ask >= CHEAP_SIDE_ASK_MIN_CENTS && ask <= CHEAP_SIDE_ASK_MAX_CENTS;
}

export function isCheapAskForSide(side: "yes" | "no", ask: number | undefined | null): boolean {
  if (typeof ask !== "number" || !Number.isFinite(ask)) return false;
  if (side === "yes") return ask >= 28 && ask <= CHEAP_SIDE_ASK_MAX_CENTS;
  return ask >= CHEAP_SIDE_ASK_MIN_CENTS && ask <= CHEAP_SIDE_ASK_MAX_CENTS;
}

/**
 * Mid-window 2–12m. Same numbers as classifyBarWindow OK_MID (120–720s inclusive).
 * Caller of the TIMING clock — not a second window.
 */
export function isCheapSideMidWindow(minLeft: number): boolean {
  return classifyBarWindow(minLeft * 60) === "OK_MID";
}

/**
 * Conservative asymmetric-payout prior for CHEAP_SIDE_15M (~0.45).
 * Buying 7–20¢+ with a book that's wrong vs the floor is a high-payout /
 * sub-50% hit-rate shape — Kelly/EV must not inherit BASIS_LAG's 0.62 curve.
 * Slightly better at the cheapest asks, a small haircut near 22¢ and at the
 * edges of the 2–12m window. Does not change the downstream 3¢/5¢ EV floors.
 */
export function cheapSideWinRate(entryPriceCents: number, minutesLeft: number): number {
  let wr = 0.48 - Math.max(0, Math.min(15, entryPriceCents - 7)) * (0.06 / 15);
  if (minutesLeft >= 10) wr -= 0.02;
  else if (minutesLeft <= 3) wr -= 0.02;
  return Math.max(0.40, Math.min(0.52, wr));
}

const CHEAP_SIDE_SHADOW_LOG = researchPath("cheap-side-15m.log");
function logCheapSideFire(payload: Record<string, unknown>): void {
  try {
    fs.appendFileSync(CHEAP_SIDE_SHADOW_LOG, JSON.stringify(payload) + "\n");
  } catch {
    // Best-effort observational log — never throw into evaluate().
  }
}

/**
 * CHEAP_SIDE_15M evaluate. strategy-library.ts is a caller.
 * Side pick goes through decideSettlementSideLogged (p = winRateAtPrice, MTF veto;
 * named pWin vs signalConfidence on the shadow log). Evaluate gates are unchanged.
 * EV still gated after that via computeTradeEV. Not a live engine.
 */
export function evaluateCheapSide15m(obs: StrategyObservation): StrategyResult | null {
  if (!isCheapSideDualGateOpen(obs.cheapSide15mEnabled)) return null;
  if ((obs.contractDurationMins ?? 15) !== 15) return null;

  const minLeft = obs.secsRemaining / 60;
  if (!isCheapSideMidWindow(minLeft)) return null;

  const floor = obs.floorStrike;
  if (!(floor > 0)) return null;

  const fair = obs.projectedSettlementPrice ?? obs.currentPrice;
  if (!(fair > 0)) return null;

  const projDistPct = ((fair - floor) / floor) * 100;
  if (Math.abs(projDistPct) < CHEAP_SIDE_MIN_PROJ_DIST_PCT) return null;

  const fairLong = projDistPct > 0;
  const yesAsk = obs.yesAsk;
  const noAsk = obs.noAsk;
  const yesCheap = isCheapAskForSide("yes", yesAsk);
  const noCheap = isCheapAskForSide("no", noAsk);

  let signal: TradeSignal | null = null;
  let cheapAsk: number | undefined;
  if (fairLong && yesCheap) {
    signal = "YES";
    cheapAsk = yesAsk;
  } else if (!fairLong && noCheap) {
    signal = "NO";
    cheapAsk = noAsk;
  }
  if (!signal || cheapAsk === undefined) return null;

  const streakSign = obs.basisStreakSign ?? 0;
  const streakCount = obs.basisStreakCount;
  if (streakCount === undefined) return null;
  const wantSign: 1 | -1 = signal === "YES" ? 1 : -1;
  if (streakSign !== wantSign || streakCount < CHEAP_SIDE_MIN_STREAK) return null;

  const impliedProb = clamp(50 + Math.abs(projDistPct) * 300, 5, 95);
  const edgePts = impliedProb - cheapAsk;
  if (edgePts < CHEAP_SIDE_MIN_EDGE_PTS) return null;

  const liqBook = obs.liquidityBook?.[signal];
  if (liqBook) {
    const liqVerdict = evaluateLiquidity({ family: "lag", book: liqBook, volScale: obs.volScale });
    logLiquidityDecision({
      strategyId: "CHEAP_SIDE_15M", family: "lag", side: signal,
      spreadCents: liqBook.spreadCents, depthAtAsk: liqBook.depthAtAsk, imbalance: liqBook.imbalance,
      bookAgeMs: liqBook.bookAgeMs, action: liqVerdict.action, sizeMult: liqVerdict.sizeMult, reason: liqVerdict.reason,
    });
    if (liqVerdict.action === "SKIP") return null;
  }

  let conf = 0.56 + clamp((edgePts - CHEAP_SIDE_MIN_EDGE_PTS) / 80, 0, 0.12);
  conf = clamp(conf, 0.55, 0.70);

  const wr = cheapSideWinRate(cheapAsk, minLeft);
  const { decision: sideDecision, log: sideLog } = decideSettlementSideLogged({
    pYes: signal === "YES" ? wr : null,
    pNo: signal === "NO" ? wr : null,
    mtf: obs.mtfScore ?? 0,
    ...(obs.lagStale !== undefined
      ? { lagStale: obs.lagStale, lagDollars: obs.lagDollars ?? null }
      : {}),
  }, { signalConfidence: conf });
  if (sideDecision.side === "skip") {
    logCheapSideFire({
      ts: new Date().toISOString(),
      ticker: obs.ticker ?? null,
      ask: cheapAsk,
      proj: fair,
      skipped: true,
      event: sideLog.event,
      side: sideLog.side,
      pWin: sideLog.pWin,
      sideReason: sideLog.reason,
      signalConfidence: sideLog.signalConfidence,
    });
    return null;
  }

  const sideBid = signal === "YES" ? obs.yesBid : obs.noBid;
  const spreadCents = sideBid !== undefined ? cheapAsk - sideBid : undefined;
  const evResult = computeTradeEV({
    entryPriceCents:   cheapAsk,
    winRate:           wr,
    strategyId:        "CHEAP_SIDE_15M",
    secsRemaining:     obs.secsRemaining,
    velocityDolPerMin: obs.velocityDolPerMin,
    spreadCents,
  });
  if (evResult.netEV < 3) return null;  // PAPER DESK v2: netEV>=3

  const reason =
    `Cheap side 15m: ${signal} @ ${cheapAsk}c vs fair ${fair.toFixed(0)} / floor ${floor.toFixed(0)} ` +
    `(${projDistPct >= 0 ? "+" : ""}${projDistPct.toFixed(3)}%, implied ~${impliedProb.toFixed(0)}c, ` +
    `${edgePts.toFixed(0)}pt edge, streak ${streakSign >= 0 ? "+" : ""}${streakSign}x${streakCount})`;

  logCheapSideFire({
    ts: new Date().toISOString(),
    ticker: obs.ticker ?? null,
    side: signal,
    ask: cheapAsk,
    proj: fair,
    reason,
    event: sideLog.event,
    pWin: sideLog.pWin,
    sideReason: sideLog.reason,
    signalConfidence: sideLog.signalConfidence,
  });

  return {
    signal,
    confidence: conf,
    strategyId: "CHEAP_SIDE_15M",
    strategyName: "Cheap Side 15M",
    edgePct: edgePts / 100,
    reason,
    earlyExitRule: "Do not hold-to-settlement as the default. Sell via existing profit-take / time-decay exits if the cheap-side thesis is gone (fair crosses back through the floor, or the ask is no longer cheap). Exit immediately if the last ~90s lottery window opens.",
  };
}
