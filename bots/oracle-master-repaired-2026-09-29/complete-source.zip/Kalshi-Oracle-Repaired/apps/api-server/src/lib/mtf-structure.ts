/**
 * mtf-structure.ts — HTF channel + S/R CONTEXT for the 15m YES/NO/skip call.
 *
 * Price typically lives between channel lines. Know support/resistance on
 * 1h / 4h / daily (weekly if enough bars already in cache). Breaks above or
 * below change the 15m side. Heikin Ashi is the default candle for channel
 * and break tests (desk default). Psych S/R reuses strike-levels.nearestPsych.
 *
 * Channel method: LINEAR REGRESSION envelope (OLS close ~ bar index, ±2σ).
 * Honest: this is a statistical band around HA closes, not a drawn pitchfork
 * and not Donchian (Donchian "break" is just a new N-bar high). We picked
 * linreg because it names a mid, a slope, and a break that is not tautological.
 *
 * CONTEXT only. Not a strategy ENABLE. Does not bypass EV / Kelly 0.60 / 9% /
 * 15% reserve / daily halt. Does not flip paperMode. Does not ENABLE
 * CONFLUENCE / SP / OTM / hourly. persist-cheap stays OBSERVE. 15m is the
 * only armed book — this module never places, never sets enable1HContracts.
 *
 * Fail-closed: stale or missing HTF → freshness missing/stale, sideBias
 * UNKNOWN. Do not invent a 15m side from HTF. 15m PATH / lag still apply.
 *
 * Hierarchy: MTF-confirmed HTF structure > naked 15m velocity.
 * Side call is YES vs NO vs skip. Skip is valid. p = winRateAtPrice lives
 * elsewhere (admission / PATH_GATE).
 */

import { nearestPsych } from "./strike-levels.js";
import { getMtfOhlcBars } from "./mtf-analyzer.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
/** This module never composes. autoMode = adaptation only lives on the bot. */
export const AUTO_MODE = false as const;

/** Same window as MTF_STALE_MS. Older HTF is fail-closed UNKNOWN. */
export const HTF_STALE_MS = 10 * 60 * 1_000;
export const CHANNEL_METHOD = "linreg" as const;
export const CHANNEL_SIGMA = 2;
/** Outer 15% of the band = hugging the channel line. */
export const HUG_OUTER = 0.15;
/** Middle ±20% of the band (40% total) + flat slope = mid-channel chop. */
export const MID_BAND = 0.20;
/** Window rise / band-width below this → slope is flat. */
export const SLOPE_FLAT_RATIO = 0.35;
/** Two consecutive HA closes beyond the level = accepted break (not a wick). */
export const ACCEPT_BREAK_BARS = 2;
export const PIVOT_LEFT = 2;
export const PIVOT_RIGHT = 2;
export const MIN_CHANNEL_BARS = 12;
/** |$/min| below this is not a 15m velocity chase. */
export const VELOCITY_FLAT_DOLLARS_PER_MIN = 20;
export const PSYCH_STEPS_HTF = [100, 500, 1000] as const;

export type OhlcBar = { open: number; high: number; low: number; close: number };
export type HtfFreshness = "fresh" | "stale" | "missing";
export type HtfChannelState =
  | "in"
  | "hug_high"
  | "hug_low"
  | "break_above"
  | "break_below"
  | "mid_chop";
export type HtfBreak = "none" | "accepted_above" | "accepted_below" | "unaccepted";
export type HtfSideBias = "YES" | "NO" | "skip" | "UNKNOWN";
export type HtfTf = "1h" | "4h" | "1d" | "1w";
export type HaColor = "green" | "red";

export type HtfLevel = {
  tf: HtfTf;
  price: number;
  distDollars: number;
  distSigma15m: number | null;
  source: "swing" | "psych" | "channel";
};

export type HtfChannel = {
  method: typeof CHANNEL_METHOD;
  state: HtfChannelState;
  upper: number;
  mid: number;
  lower: number;
  slope: number;
  /** 0 = at lower, 1 = at upper. */
  pos: number;
};

export type HtfTfView = {
  tf: HtfTf;
  freshness: HtfFreshness;
  ageMs: number;
  channel: HtfChannel | null;
  support: HtfLevel | null;
  resistance: HtfLevel | null;
  break: HtfBreak;
  haColor: HaColor | null;
};

export type HtfStructureSnapshot = {
  freshness: HtfFreshness;
  sideBias: HtfSideBias;
  break: HtfBreak;
  primaryTf: HtfTf | null;
  displayLine: string;
  reason: string;
  haColor: HaColor | null;
  h1: HtfTfView | null;
  h4: HtfTfView | null;
  d1: HtfTfView | null;
  w1: HtfTfView | null;
  support: HtfLevel | null;
  resistance: HtfLevel | null;
};

export type HtfCandleLeg = { bars: OhlcBar[]; ts: number; formingLast?: boolean } | null | undefined;

export type HtfCandleSet = {
  now?: number;
  spot: number;
  h1?: HtfCandleLeg;
  h4?: HtfCandleLeg;
  d1?: HtfCandleLeg;
  w1?: HtfCandleLeg;
  m15?: HtfCandleLeg;
};

export type HtfContextDecision = {
  action: "pass" | "skip";
  sideBias: HtfSideBias;
  reason: string;
};

function finite(n: unknown): n is number {
  return typeof n === "number" && Number.isFinite(n);
}

export function haTransform(bars: OhlcBar[]): OhlcBar[] {
  if (bars.length === 0) return [];
  const out: OhlcBar[] = new Array(bars.length);
  let prevOpen = (bars[0]!.open + bars[0]!.close) / 2;
  let prevClose = bars[0]!.close;
  for (let i = 0; i < bars.length; i++) {
    const c = bars[i]!;
    const haClose = (c.open + c.high + c.low + c.close) / 4;
    const haOpen = i === 0 ? (c.open + c.close) / 2 : (prevOpen + prevClose) / 2;
    out[i] = {
      open: haOpen,
      high: Math.max(c.high, haOpen, haClose),
      low: Math.min(c.low, haOpen, haClose),
      close: haClose,
    };
    prevOpen = haOpen;
    prevClose = haClose;
  }
  return out;
}

function linreg(ys: number[]): { slope: number; intercept: number; stdev: number } {
  const n = ys.length;
  if (n < 2) return { slope: 0, intercept: ys[0] ?? 0, stdev: 0 };
  let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  for (let i = 0; i < n; i++) {
    const y = ys[i]!;
    sumX += i;
    sumY += y;
    sumXY += i * y;
    sumXX += i * i;
  }
  const den = n * sumXX - sumX * sumX;
  const slope = den === 0 ? 0 : (n * sumXY - sumX * sumY) / den;
  const intercept = (sumY - slope * sumX) / n;
  let ss = 0;
  for (let i = 0; i < n; i++) {
    const r = ys[i]! - (intercept + slope * i);
    ss += r * r;
  }
  const stdev = Math.sqrt(ss / Math.max(1, n - 2));
  return { slope, intercept, stdev };
}

function atr(bars: OhlcBar[], period = 14): number {
  if (bars.length < 2) return 0;
  const trs: number[] = [];
  for (let i = 1; i < bars.length; i++) {
    const h = bars[i]!.high;
    const l = bars[i]!.low;
    const pc = bars[i - 1]!.close;
    trs.push(Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc)));
  }
  const last = trs.slice(-period);
  return last.reduce((a, b) => a + b, 0) / last.length;
}

function swingPivots(bars: OhlcBar[]): { highs: number[]; lows: number[] } {
  const highs: number[] = [];
  const lows: number[] = [];
  const left = PIVOT_LEFT;
  const right = PIVOT_RIGHT;
  for (let i = left; i < bars.length - right; i++) {
    let isH = true;
    let isL = true;
    for (let k = i - left; k <= i + right; k++) {
      if (k === i) continue;
      if (bars[k]!.high >= bars[i]!.high) isH = false;
      if (bars[k]!.low <= bars[i]!.low) isL = false;
    }
    if (isH) highs.push(bars[i]!.high);
    if (isL) lows.push(bars[i]!.low);
  }
  return { highs, lows };
}

export function synthesizeHigherTf(bars: OhlcBar[], group: number): OhlcBar[] {
  if (group < 2 || bars.length < group) return [];
  const out: OhlcBar[] = [];
  const start = bars.length % group;
  for (let i = start; i + group <= bars.length; i += group) {
    const slice = bars.slice(i, i + group);
    out.push({
      open: slice[0]!.open,
      high: Math.max(...slice.map(b => b.high)),
      low: Math.min(...slice.map(b => b.low)),
      close: slice[slice.length - 1]!.close,
    });
  }
  return out;
}

export function formatBtcLevel(px: number): string {
  if (!finite(px)) return "n/a";
  if (Math.abs(px) >= 1_000) return `${(px / 1_000).toFixed(1)}k`;
  return px.toFixed(0);
}

function freshnessOf(ts: number | undefined, now: number): { freshness: HtfFreshness; ageMs: number } {
  if (!finite(ts) || ts <= 0) return { freshness: "missing", ageMs: Number.POSITIVE_INFINITY };
  const ageMs = Math.max(0, now - ts);
  if (ageMs > HTF_STALE_MS) return { freshness: "stale", ageMs };
  return { freshness: "fresh", ageMs };
}

function makeLevel(
  tf: HtfTf,
  price: number,
  spot: number,
  sigma: number,
  source: HtfLevel["source"],
): HtfLevel {
  const distDollars = spot - price;
  return {
    tf,
    price,
    distDollars,
    distSigma15m: sigma > 0 ? distDollars / sigma : null,
    source,
  };
}

function classifyTf(
  tf: HtfTf,
  leg: HtfCandleLeg,
  spot: number,
  now: number,
  sigma15m: number,
): HtfTfView | null {
  if (!leg || !Array.isArray(leg.bars) || leg.bars.length === 0) {
    return {
      tf,
      freshness: "missing",
      ageMs: Number.POSITIVE_INFINITY,
      channel: null,
      support: null,
      resistance: null,
      break: "none",
      haColor: null,
    };
  }
  const { freshness, ageMs } = freshnessOf(leg.ts, now);
  const haAll = haTransform(leg.bars);
  // Live exchange/Kalshi series include the forming bar. Counting its HA
  // close as an accepted break is look-ahead. Channel + color + break use
  // closed HA; pos uses live spot vs the closed envelope.
  const ha = leg.formingLast === true && haAll.length > 1 ? haAll.slice(0, -1) : haAll;
  const lastHa = ha[ha.length - 1];
  const haColor: HaColor | null = lastHa
    ? (lastHa.close >= lastHa.open ? "green" : "red")
    : null;
  const closes = ha.map(b => b.close);
  const lastClose = (leg.formingLast === true && spot > 0) ? spot : (closes[closes.length - 1] ?? spot);

  let channel: HtfChannel | null = null;
  if (closes.length >= MIN_CHANNEL_BARS) {
    const { slope, intercept, stdev } = linreg(closes);
    const x = closes.length - 1;
    const mid = intercept + slope * x;
    const band = CHANNEL_SIGMA * stdev;
    const upper = mid + band;
    const lower = mid - band;
    const width = upper - lower;
    const pos = width > 0 ? (lastClose - lower) / width : 0.5;
    const rise = Math.abs(slope) * Math.max(1, x);
    const flat = width <= 0 || rise / width < SLOPE_FLAT_RATIO;
    let state: HtfChannelState;
    if (lastClose > upper) state = "break_above";
    else if (lastClose < lower) state = "break_below";
    else if (flat && Math.abs(pos - 0.5) <= MID_BAND) state = "mid_chop";
    else if (pos >= 1 - HUG_OUTER) state = "hug_high";
    else if (pos <= HUG_OUTER) state = "hug_low";
    else state = "in";
    channel = { method: CHANNEL_METHOD, state, upper, mid, lower, slope, pos };
  }

  const piv = swingPivots(ha);
  const swingHigh = piv.highs.length > 0 ? piv.highs[piv.highs.length - 1]! : null;
  const swingLow = piv.lows.length > 0 ? piv.lows[piv.lows.length - 1]! : null;
  const psych = nearestPsych(spot, PSYCH_STEPS_HTF);

  let resistance: HtfLevel | null = null;
  let support: HtfLevel | null = null;
  if (swingHigh != null && swingHigh >= spot) {
    resistance = makeLevel(tf, swingHigh, spot, sigma15m, "swing");
  }
  if (swingLow != null && swingLow <= spot) {
    support = makeLevel(tf, swingLow, spot, sigma15m, "swing");
  }
  if (finite(psych.level)) {
    const psychLvl = makeLevel(tf, psych.level, spot, sigma15m, "psych");
    if (psych.level >= spot) {
      if (!resistance || Math.abs(psychLvl.distDollars) < Math.abs(resistance.distDollars)) {
        resistance = psychLvl;
      }
    } else {
      if (!support || Math.abs(psychLvl.distDollars) < Math.abs(support.distDollars)) {
        support = psychLvl;
      }
    }
  }
  if (!resistance && channel) {
    resistance = makeLevel(tf, channel.upper, spot, sigma15m, "channel");
  }
  if (!support && channel) {
    support = makeLevel(tf, channel.lower, spot, sigma15m, "channel");
  }

  const resPx = resistance?.price ?? channel?.upper ?? null;
  const supPx = support?.price ?? channel?.lower ?? null;
  const lastN = ha.slice(-ACCEPT_BREAK_BARS);
  const heldAbove = lastN.length === ACCEPT_BREAK_BARS
    && resPx != null
    && lastN.every(b => b.close > resPx);
  const heldBelow = lastN.length === ACCEPT_BREAK_BARS
    && supPx != null
    && lastN.every(b => b.close < supPx);
  const lastBeyondAbove = resPx != null && lastHa != null && lastHa.close > resPx;
  const lastBeyondBelow = supPx != null && lastHa != null && lastHa.close < supPx;

  let brk: HtfBreak = "none";
  if (heldAbove && haColor === "green") brk = "accepted_above";
  else if (heldBelow && haColor === "red") brk = "accepted_below";
  else if (lastBeyondAbove || lastBeyondBelow) brk = "unaccepted";
  else if (channel?.state === "break_above" && haColor === "green" && heldAbove) brk = "accepted_above";
  else if (channel?.state === "break_below" && haColor === "red" && heldBelow) brk = "accepted_below";

  return {
    tf,
    freshness,
    ageMs,
    channel,
    support,
    resistance,
    break: brk,
    haColor,
  };
}

function rollBias(views: Array<HtfTfView | null>): {
  sideBias: HtfSideBias;
  break: HtfBreak;
  primaryTf: HtfTf | null;
  reason: string;
} {
  const fresh = views.filter((v): v is HtfTfView => !!v && v.freshness === "fresh");
  if (fresh.length === 0) {
    return { sideBias: "UNKNOWN", break: "none", primaryTf: null, reason: "htf_stale_or_missing" };
  }
  const above = fresh.filter(v => v.break === "accepted_above");
  const below = fresh.filter(v => v.break === "accepted_below");
  if (above.length > 0 && below.length > 0) {
    return { sideBias: "skip", break: "none", primaryTf: fresh[0]!.tf, reason: "htf_break_conflict" };
  }
  if (above.length > 0) {
    const tf = above[0]!.tf;
    return { sideBias: "YES", break: "accepted_above", primaryTf: tf, reason: `accepted_break_above_${tf}` };
  }
  if (below.length > 0) {
    const tf = below[0]!.tf;
    return { sideBias: "NO", break: "accepted_below", primaryTf: tf, reason: `accepted_break_below_${tf}` };
  }
  const primary = fresh.find(v => v.tf === "4h") ?? fresh.find(v => v.tf === "1d") ?? fresh[0]!;
  const st = primary.channel?.state ?? null;
  if (st === "mid_chop") {
    return { sideBias: "skip", break: "none", primaryTf: primary.tf, reason: "mid_channel_chop" };
  }
  if (st === "hug_high" || st === "hug_low") {
    return { sideBias: "skip", break: "none", primaryTf: primary.tf, reason: `hug_${st}` };
  }
  if (st === "break_above") {
    return { sideBias: "YES", break: "unaccepted", primaryTf: primary.tf, reason: "channel_break_above_unaccepted" };
  }
  if (st === "break_below") {
    return { sideBias: "NO", break: "unaccepted", primaryTf: primary.tf, reason: "channel_break_below_unaccepted" };
  }
  if (st === "in" && primary.channel) {
    const slope = primary.channel.slope;
    if (slope > 0) {
      return { sideBias: "YES", break: "none", primaryTf: primary.tf, reason: `${primary.tf}_in_channel_up` };
    }
    if (slope < 0) {
      return { sideBias: "NO", break: "none", primaryTf: primary.tf, reason: `${primary.tf}_in_channel_down` };
    }
  }
  return { sideBias: "skip", break: "none", primaryTf: primary.tf, reason: "htf_no_clear_structure" };
}

function displayLineOf(opts: {
  freshness: HtfFreshness;
  primary: HtfTfView | null;
  d1: HtfTfView | null;
  sideBias: HtfSideBias;
  brk: HtfBreak;
}): string {
  if (opts.freshness !== "fresh" || !opts.primary) {
    return "HTF structure UNKNOWN (stale/missing) — 15m PATH/lag still apply";
  }
  const p = opts.primary;
  const ch = p.channel;
  const chBit = ch
    ? `${p.tf} ${ch.state.replace(/_/g, "-")}`
    : `${p.tf} no-channel`;
  const dailySup = opts.d1?.support;
  const dailyRes = opts.d1?.resistance;
  let srBit = "";
  if (dailySup && (dailyRes == null || Math.abs(dailySup.distDollars) <= Math.abs(dailyRes.distDollars))) {
    srBit = `, daily support ${formatBtcLevel(dailySup.price)}`;
  } else if (dailyRes) {
    srBit = `, daily resistance ${formatBtcLevel(dailyRes.price)}`;
  } else if (p.support && (p.resistance == null || Math.abs(p.support.distDollars) <= Math.abs(p.resistance.distDollars))) {
    srBit = `, ${p.tf} support ${formatBtcLevel(p.support.price)}`;
  } else if (p.resistance) {
    srBit = `, ${p.tf} resistance ${formatBtcLevel(p.resistance.price)}`;
  }
  let breakBit = "";
  if (opts.brk === "accepted_above") breakBit = ", accepted break favors YES";
  else if (opts.brk === "accepted_below") breakBit = ", accepted break favors NO";
  else if (opts.sideBias === "YES") breakBit = ", break would favor YES";
  else if (opts.sideBias === "NO") breakBit = ", break would favor NO";
  else if (opts.sideBias === "skip") breakBit = ", skip 15m chase";
  return `${chBit}${srBit}${breakBit}`;
}

const UNKNOWN_SNAP: HtfStructureSnapshot = {
  freshness: "missing",
  sideBias: "UNKNOWN",
  break: "none",
  primaryTf: null,
  displayLine: "HTF structure UNKNOWN (stale/missing) — 15m PATH/lag still apply",
  reason: "htf_stale_or_missing",
  haColor: null,
  h1: null,
  h4: null,
  d1: null,
  w1: null,
  support: null,
  resistance: null,
};

/**
 * Pure. Candles in, snapshot out. No fetch. No orders.
 */
export function computeHtfStructure(input: HtfCandleSet): HtfStructureSnapshot {
  if (!finite(input.spot) || input.spot <= 0) return { ...UNKNOWN_SNAP };
  const now = finite(input.now) ? input.now : Date.now();
  const sigma15m = input.m15?.bars && input.m15.bars.length >= 5
    ? atr(haTransform(input.m15.bars))
    : input.h4?.bars && input.h4.bars.length >= 5
      ? atr(haTransform(input.h4.bars)) / 4
      : 0;

  const h1 = classifyTf("1h", input.h1, input.spot, now, sigma15m);
  const h4 = classifyTf("4h", input.h4, input.spot, now, sigma15m);
  const d1 = classifyTf("1d", input.d1, input.spot, now, sigma15m);
  const w1 = input.w1 && input.w1.bars.length >= MIN_CHANNEL_BARS
    ? classifyTf("1w", input.w1, input.spot, now, sigma15m)
    : null;

  const rolled = rollBias([d1, h4, h1, w1]);
  const anyFresh = [h1, h4, d1, w1].some(v => v && v.freshness === "fresh");
  const anyPresent = [h1, h4, d1].some(v => v && v.freshness !== "missing");
  const freshness: HtfFreshness = anyFresh ? "fresh" : anyPresent ? "stale" : "missing";
  const primary = (rolled.primaryTf === "4h" ? h4
    : rolled.primaryTf === "1d" ? d1
    : rolled.primaryTf === "1h" ? h1
    : rolled.primaryTf === "1w" ? w1
    : h4 ?? d1 ?? h1) ?? null;
  const sideBias: HtfSideBias = freshness === "fresh" ? rolled.sideBias : "UNKNOWN";
  const reason = freshness === "fresh" ? rolled.reason : "htf_stale_or_missing";
  const brk: HtfBreak = freshness === "fresh" ? rolled.break : "none";

  return {
    freshness,
    sideBias,
    break: brk,
    primaryTf: freshness === "fresh" ? rolled.primaryTf : null,
    displayLine: displayLineOf({ freshness, primary, d1, sideBias, brk }),
    reason,
    haColor: primary?.haColor ?? h4?.haColor ?? h1?.haColor ?? null,
    h1, h4, d1, w1,
    support: d1?.support ?? h4?.support ?? h1?.support ?? null,
    resistance: d1?.resistance ?? h4?.resistance ?? h1?.resistance ?? null,
  };
}

/**
 * Live snapshot from already-fetched mtf-analyzer caches. No extra API.
 * Daily is synthesized from 4h (6 bars). Weekly only if enough daily bars.
 */
export function computeLiveHtfStructure(spot: number, now = Date.now()): HtfStructureSnapshot {
  if (!finite(spot) || spot <= 0) return { ...UNKNOWN_SNAP };
  const h1raw = getMtfOhlcBars(60);
  const h4raw = getMtfOhlcBars(240);
  const m15raw = getMtfOhlcBars(15);
  const markForming = (leg: { bars: OhlcBar[]; ts: number } | null) =>
    leg ? { ...leg, formingLast: true as const } : null;
  const h1 = markForming(h1raw);
  const h4 = markForming(h4raw);
  const m15 = markForming(m15raw);
  const dBars = h4 ? synthesizeHigherTf(h4.bars, 6) : [];
  const d1 = dBars.length > 0 && h4 ? { bars: dBars, ts: h4.ts, formingLast: true as const } : null;
  const wBars = d1 ? synthesizeHigherTf(d1.bars, 5) : [];
  const w1 = wBars.length >= MIN_CHANNEL_BARS && d1 ? { bars: wBars, ts: d1.ts, formingLast: true as const } : null;
  return computeHtfStructure({ now, spot, h1, h4, d1, w1, m15 });
}

function proposedConflicts(bias: HtfSideBias, proposed: "yes" | "no"): boolean {
  return (bias === "YES" && proposed === "no") || (bias === "NO" && proposed === "yes");
}

/**
 * CONTEXT for evaluateEntry's side/skip call.
 * Returns skip or pass. Never a fill. Never flips paperMode. Never ENABLE.
 * Stale/UNKNOWN → pass (do not invent a side; 15m PATH/lag still apply).
 */
export function applyHtfStructureToSide(opts: {
  structure: HtfStructureSnapshot;
  proposedSide: "yes" | "no" | null;
  velocitySide: "yes" | "no" | "flat";
  haRejection: boolean;
  lagAgainst: boolean;
  /** Mid-channel exception: cheap ask whose EV_PRE_CHECK already cleared. */
  cheapSideEvClears?: boolean;
}): HtfContextDecision {
  const s = opts.structure;
  if (s.freshness !== "fresh" || s.sideBias === "UNKNOWN") {
    return { action: "pass", sideBias: "UNKNOWN", reason: "htf_stale_or_missing" };
  }

  const primaryView = s.primaryTf === "1d" ? s.d1
    : s.primaryTf === "1h" ? s.h1
    : s.primaryTf === "1w" ? s.w1
    : s.h4;
  const chop = s.reason === "mid_channel_chop" || primaryView?.channel?.state === "mid_chop";

  if (s.sideBias === "skip" || chop) {
    if (opts.cheapSideEvClears === true) {
      return { action: "pass", sideBias: "skip", reason: "mid_channel_chop_cheap_ev_clears" };
    }
    if (opts.velocitySide !== "flat") {
      return { action: "skip", sideBias: "skip", reason: "mid_channel_velocity_chase" };
    }
    return { action: "skip", sideBias: "skip", reason: s.reason || "mid_channel_chop" };
  }

  if (s.sideBias === "YES" || s.sideBias === "NO") {
    const proposed = opts.proposedSide;
    if (proposed && proposedConflicts(s.sideBias, proposed)) {
      const fadeOk = opts.haRejection === true && opts.lagAgainst === true
        && (s.break === "accepted_above" || s.break === "accepted_below");
      if (fadeOk) {
        return { action: "pass", sideBias: s.sideBias, reason: "fade_ha_reject_lag_against" };
      }
      if (opts.velocitySide === proposed) {
        return { action: "skip", sideBias: s.sideBias, reason: "htf_against_15m_velocity" };
      }
      return { action: "skip", sideBias: s.sideBias, reason: "htf_against_proposed_side" };
    }
    if (opts.velocitySide !== "flat" && proposedConflicts(s.sideBias, opts.velocitySide)) {
      return { action: "skip", sideBias: s.sideBias, reason: "htf_against_15m_velocity" };
    }
    return { action: "pass", sideBias: s.sideBias, reason: s.reason };
  }

  return { action: "pass", sideBias: s.sideBias, reason: s.reason };
}

export function velocitySideFromDollarsPerMin(vel: number): "yes" | "no" | "flat" {
  if (!finite(vel) || Math.abs(vel) < VELOCITY_FLAT_DOLLARS_PER_MIN) return "flat";
  return vel > 0 ? "yes" : "no";
}
