import { test } from "node:test";
import assert from "node:assert/strict";
import { resolveReadableConfigPath, resolveConfigPath } from "./config-persist.js";

test("resolveReadableConfigPath honours BOT_CONFIG_PATH (same file the bot reads)", () => {
  assert.ok(process.env.BOT_CONFIG_PATH, "test runner sets BOT_CONFIG_PATH");
  assert.equal(resolveReadableConfigPath(), resolveConfigPath());
});
