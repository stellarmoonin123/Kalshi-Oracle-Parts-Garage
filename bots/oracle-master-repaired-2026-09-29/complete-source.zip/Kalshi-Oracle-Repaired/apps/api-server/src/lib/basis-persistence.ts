/**
 * basis-persistence.ts — durable history for basis-tracker samples.
 *
 * basis-tracker.ts stays a pure, DB-free module (see its own header); this
 * module owns the one-way write from a `BasisState` snapshot into the
 * `basis_samples` table so lag/basis behavior can be measured over hours or
 * days instead of only via a live poll. Writes are fire-and-forget and never
 * throw — a DB hiccup here must never affect the live trading tick.
 */
import { db, basisSamples } from "@workspace/db";
import type { BasisState } from "./basis-tracker.js";

let lastLoggedWriteFailureAt = 0;
const FAILURE_LOG_THROTTLE_MS = 60_000;

export async function persistBasisSample(input: {
  ticker: string | null;
  floorStrike: number | null;
  secsRemaining: number;
  state: BasisState;
}): Promise<void> {
  const { state } = input;
  try {
    await db.insert(basisSamples).values({
      ticker:                   input.ticker,
      floorStrike:              input.floorStrike,
      exchangeSource:           state.exchangeSource,
      exchangePrice:            state.exchangePrice,
      brtiProxy:                state.brtiProxy,
      rollingBasis:             state.rollingBasis,
      shortBasis:               state.shortBasis,
      basisStreakSign:          state.basisStreakSign,
      basisStreakCount:         state.basisStreakCount,
      basisStreakMs:            Math.round(state.basisStreakMs),
      estimatedFairBrti:        state.estimatedFairBRTI,
      projectedSettlementPrice: state.projectedSettlementPrice,
      secsRemaining:            input.secsRemaining,
    });
  } catch (err) {
    // Never let persistence failures affect the live tick. Throttled so a
    // sustained DB outage doesn't spam the log at the same cadence as writes.
    const now = Date.now();
    if (now - lastLoggedWriteFailureAt >= FAILURE_LOG_THROTTLE_MS) {
      lastLoggedWriteFailureAt = now;
      console.error("[basis-persistence] failed to write basis sample:", (err as Error).message);
    }
  }
}
