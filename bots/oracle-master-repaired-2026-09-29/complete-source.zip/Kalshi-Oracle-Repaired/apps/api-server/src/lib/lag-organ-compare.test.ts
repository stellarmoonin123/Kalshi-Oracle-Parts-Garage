/** QUARANTINE(P2): lag-organ compare research */
/**
 * Isolate-rewrite-compare LAG organ (classifier + analog + corr_junk).
 * Does not rewrite TradingBot. Does not bounce. paperMode true. EV 3¢. No ENABLE.
 */
import "./strategy-learner-test-isolation.js";
import assert from "node:assert/strict";
import test from "node:test";
import { classifyLagUnprovenGateIsolate } from "./basis-lag-edge.isolate.js";
import { classifyLagUnprovenGate, evaluateBasisLagEdge, LAG_CHEAP_ASK_CENTS } from "./basis-lag-edge.js";
import { lagSideConfirmationAgrees as isolateLag } from "./lag-side-agree.isolate.js";
import { lagSideConfirmationAgrees as liveLag } from "./lag-side-agree.js";
import { freshLagDisagreeSkip, CONFLUENCE_CASCADE_ID } from "./automode-adapter.js";
import { EV_FLOOR } from "./admission.js";
import type { StrategyObservation } from "./strategy-library.js";

type Cell = { proceed: boolean; kind: string };
type Row = { fixture: string; isolate: Cell; rewrite: Cell; want: "TAKE" | "SKIP"; isolatePass: boolean; rewritePass: boolean };

const rows: Row[] = [];

function rec(fixture: string, iso: Cell, rew: Cell, want: "TAKE" | "SKIP"): void {
  const isoPass = want === "TAKE" ? iso.proceed : !iso.proceed;
  const rewPass = want === "TAKE" ? rew.proceed : !rew.proceed;
  rows.push({ fixture, isolate: iso, rewrite: rew, want, isolatePass: isoPass, rewritePass: rewPass });
}

function obs(over: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60,
    projectedSettlementPrice: 65130,
    rollingBasis: 8,
    basisShort: 8,
    basisStreakCount: 4,
    basisStreakSign: 1,
    lagStale: false,
    lagProven: true,
    lagDollars: 40,
    leadSeconds: 8,
    leadDollars: 40,
    proofHitRate: 0.8,
    yesAsk: 30,
    yesBid: 28,
    noAsk: 68,
    noBid: 66,
    paperMode: true,
    ...over,
  };
}

test.skip("isolate-rewrite-compare LAG: proven take vs unproven skip; corr_junk no fill", () => {
  assert.equal(EV_FLOOR, 3);
  assert.equal(LAG_CHEAP_ASK_CENTS, 55);

  const provenGate = {
    lagProven: true, lagStale: false, leadSeconds: 8, leadDollars: 40, sideAsk: 30, side: "yes" as const,
  };
  rec(
    "proven cheap YES → TAKE",
    { proceed: classifyLagUnprovenGateIsolate(provenGate).proceed, kind: classifyLagUnprovenGateIsolate(provenGate).kind },
    { proceed: classifyLagUnprovenGate(provenGate).proceed, kind: classifyLagUnprovenGate(provenGate).kind },
    "TAKE",
  );
  const provenEval = evaluateBasisLagEdge(obs({ lagProven: true, lagStale: false, paperMode: true, yesAsk: 30 }));
  assert.ok(provenEval, "rewrite proven take");
  assert.equal(provenEval!.signal, "YES");

  const unprovenGate = {
    lagProven: false, lagStale: false, leadSeconds: 5, leadDollars: 15, lagDollars: 40, sideAsk: 30, side: "yes" as const,
    paperMode: true,
  };
  rec(
    "unproven cheap remake/paper orig → SKIP",
    { proceed: classifyLagUnprovenGateIsolate(unprovenGate).proceed, kind: classifyLagUnprovenGateIsolate(unprovenGate).kind },
    { proceed: classifyLagUnprovenGate(unprovenGate).proceed, kind: classifyLagUnprovenGate(unprovenGate).kind },
    "SKIP",
  );
  assert.equal(evaluateBasisLagEdge(obs({
    lagProven: false, lagStale: false, leadSeconds: 5, leadDollars: 15, lagDollars: 40, paperMode: true, yesAsk: 30,
  })), null, "rewrite unproven skip");

  const junkGate = {
    lagProven: false, lagStale: true, leadSeconds: null as null, leadDollars: 40,
    lagDollars: null as null, lagReason: "corr_junk", sideAsk: 36, side: "yes" as const, paperMode: true,
  };
  rec(
    "corr_junk + same-sign lead$ → SKIP (no fill)",
    { proceed: classifyLagUnprovenGateIsolate(junkGate).proceed, kind: classifyLagUnprovenGateIsolate(junkGate).kind },
    { proceed: classifyLagUnprovenGate(junkGate).proceed, kind: classifyLagUnprovenGate(junkGate).kind },
    "SKIP",
  );
  assert.equal(evaluateBasisLagEdge(obs({
    lagProven: false, lagStale: true, lagReason: "corr_junk",
    lagDollars: null, lagSeconds: null, leadSeconds: null, leadDollars: 40,
    yesAsk: 36, yesBid: 34, noAsk: 64, noBid: 62, paperMode: true,
  })), null, "corr_junk no fill");

  rec(
    "analog HA/CC missing → SKIP",
    { proceed: isolateLag({ projSide: "YES", haRiverSide: null, ccFactorSide: null }), kind: "AGREE" },
    { proceed: liveLag({ projSide: "YES", haRiverSide: null, ccFactorSide: null }), kind: "AGREE" },
    "SKIP",
  );
  rec(
    "analog CC YES same sign → TAKE (side-agree)",
    { proceed: isolateLag({ projSide: "YES", haRiverSide: null, ccFactorSide: "YES" }), kind: "AGREE" },
    { proceed: liveLag({ projSide: "YES", haRiverSide: null, ccFactorSide: "YES" }), kind: "AGREE" },
    "TAKE",
  );

  console.log("\nLAG COMPARE (fixture × isolate × rewrite)");
  console.log("fixture | want | isolate | rewrite | isoOK | rewOK");
  for (const r of rows) {
    console.log(`${r.fixture} | ${r.want} | ${r.isolate.kind}/${r.isolate.proceed} | ${r.rewrite.kind}/${r.rewrite.proceed} | ${r.isolatePass} | ${r.rewritePass}`);
  }
  for (const r of rows) {
    assert.equal(r.rewritePass, true, `rewrite failed: ${r.fixture}`);
  }
  const isoWins = rows.filter((r) => r.isolatePass).length;
  const rewWins = rows.filter((r) => r.rewritePass).length;
  assert.ok(rewWins >= isoWins, `keep winner rewrite (${rewWins} vs isolate ${isoWins})`);
});

test.skip("CC exempt from Adapt TAPE_LIE; LAG still skip FRESH disagree", () => {
  assert.equal(freshLagDisagreeSkip({
    autoMode: true, lagStale: false, agreesWithSide: false, strategyId: CONFLUENCE_CASCADE_ID,
  }), false);
  assert.equal(freshLagDisagreeSkip({
    autoMode: true, lagStale: false, agreesWithSide: false, strategyId: "BASIS_LAG_EDGE",
  }), true);
});

test.skip("locks: EV 3, cheap 55, no fake 5–15s in classifier", () => {
  assert.equal(EV_FLOOR, 3);
  const g = classifyLagUnprovenGate({ lagProven: false, lagStale: true, lagReason: "corr_junk", sideAsk: 30 });
  assert.equal(g.proceed, false);
  assert.equal(/\b5-15s\b|invented 5/.test(g.reason), false);
  assert.match(g.reason, /never fake 5–15s|corr_junk/);
});
