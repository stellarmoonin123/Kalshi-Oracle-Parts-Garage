/**
 * Persistent desk data directory.
 *
 * Bug (Fly v11/v12): several organs resolved their data files relative to
 * `import.meta.url`. In source that is `src/lib[/organs]/` → `apps/api-server/data`
 * (the Fly volume). Under the esbuild bundle `import.meta.url` is
 * `apps/api-server/dist/index.mjs`, so `../../../data` became `/app/data` and
 * `../../data` became `/app/apps/data` — OFF the volume. Mind calibration,
 * brain episodes, scar-echo and lag proofs were wiped on every deploy/restart
 * (mind calibration n=0 forever → captain HEAVE_TO "unreliable ECE").
 *
 * The server always runs with cwd = apps/api-server (Dockerfile WORKDIR,
 * `pnpm start`, tests), matching bounce-level-tracker's `cwd/data`.
 */
import os from "node:os";
import path from "node:path";

export function deskDataDir(): string {
  const override = process.env.DESK_DATA_DIR;
  return override && override.trim()
    ? path.resolve(override.trim())
    : path.resolve(process.cwd(), "data");
}

export function deskDataPath(file: string): string {
  return path.join(deskDataDir(), file);
}

/**
 * Research data root (tick tapes, labels, replay summaries, shadow logs).
 * Was hard-coded to /workspace/kalshi-oracle/research in ~15 modules, which
 * does not exist on Fly (writes hit the ephemeral root FS) and made the API
 * test suite write into the live local desk folder.
 *
 *   KALSHI_RESEARCH_DIR set  → that directory
 *   test process             → <tmpdir>/kalshi-research-test (never the desk)
 *   otherwise                → <desk data dir>/research (Fly volume)
 */
export function researchDir(): string {
  const override = process.env.KALSHI_RESEARCH_DIR;
  if (override && override.trim()) return path.resolve(override.trim());
  const inTest = process.env.NODE_TEST_CONTEXT != null
    || process.env.VITEST != null
    || (typeof process.env.BOT_CONFIG_PATH === "string" && process.env.BOT_CONFIG_PATH.includes("/tmp"));
  if (inTest) return path.join(os.tmpdir(), "kalshi-research-test");
  return path.join(deskDataDir(), "research");
}

export function researchPath(file: string): string {
  return path.join(researchDir(), file);
}
