/** R3 — chat tool rounds: no more "ran out of tool rounds" dead ends. */
import { test } from "node:test";
import assert from "node:assert/strict";
import { runDeskAgent, compactOldToolResults, budgetWithPinnedQuestion, MAX_AGENT_TOOL_ROUNDS_EXTENDED, FINAL_ANSWER_INSTRUCTION } from "./chat-agent.js";
import { CooldownBook, type Msg } from "./chat-router.js";

const status = { state: "WATCHING", config: { paperMode: true }, paperVirtualBalanceCents: 30604, entryFunnel: { counts: { TAKE_SIGNAL: 3 } } };
const deps: any = { getStatus: () => status, getRecentTrades: async () => [], getRecentLogs: () => [{ level: "info", message: "x".repeat(3000) }] };

async function drain(gen: AsyncGenerator<any, any>) {
  const events: any[] = []; let step = await gen.next();
  while (!step.done) { events.push(step.value); step = await gen.next(); }
  return { events, result: step.value };
}
const toolReply = (id: string, name: string, args = "{}") => new Response(JSON.stringify({ choices: [{ message: { content: "", tool_calls: [{ id, function: { name, arguments: args } }] } }] }), { status: 200 });

test("model that always calls tools gets a forced no-tools final round and its text is used", async () => {
  let n = 0; let finalBody: any = null;
  const fetchImpl = (async (_u: string, init: any) => {
    const body = JSON.parse(init.body); n++;
    if (!body.tools || body.tools.length === 0) {
      finalBody = body;
      // Model still tries to emit a tool call alongside text — must be ignored.
      return new Response(JSON.stringify({ choices: [{ message: { content: "Funnel shows 3 TAKE signals.", tool_calls: [{ id: "zz", function: { name: "tail_log", arguments: "{}" } }] } }] }), { status: 200 });
    }
    return toolReply(`c${n}`, "tail_log", JSON.stringify({ n: n }));
  }) as unknown as typeof fetch;
  const { result, events } = await drain(runDeskAgent({ question: "why no trades?", history: [], deps, env: { GROQ_API_KEY: "g" }, fetchImpl, cooldowns: new CooldownBook() }));
  assert.equal(result.failed, false);
  assert.match(result.text, /3 TAKE/);
  assert.ok(finalBody.messages.some((m: any) => m.role === "user" && m.content === FINAL_ANSWER_INSTRUCTION));
  assert.ok(finalBody.messages.some((m: any) => m.role === "user" && m.content === "why no trades?"), "question pinned in final round");
  const toolStarts = events.filter((e) => e.type === "tool_start").length;
  assert.ok(toolStarts >= 5 && toolStarts <= MAX_AGENT_TOOL_ROUNDS_EXTENDED, `tool rounds ${toolStarts}`);
  assert.ok(!/ran out of tool rounds/.test(result.text));
});

test("empty final answer → digest of tool results instead of a bare failure", async () => {
  const fetchImpl = (async (_u: string, init: any) => {
    const body = JSON.parse(init.body);
    if (!body.tools || body.tools.length === 0) return new Response(JSON.stringify({ choices: [{ message: { content: "" } }] }), { status: 200 });
    return toolReply("c", "get_entry_funnel", JSON.stringify({ k: Math.random() }));
  }) as unknown as typeof fetch;
  const { result } = await drain(runDeskAgent({ question: "funnel?", history: [], deps, env: { GROQ_API_KEY: "g" }, fetchImpl, cooldowns: new CooldownBook() }));
  assert.match(result.text, /TAKE_SIGNAL/);
});

test("repeated identical tool call is not re-run", async () => {
  let calls = 0;
  const d = { ...deps, getStatus: () => { calls++; return status; } };
  let n = 0;
  const fetchImpl = (async () => { n++; return n <= 3 ? toolReply(`c${n}`, "get_status") : new Response(JSON.stringify({ choices: [{ message: { content: "done" } }] }), { status: 200 }); }) as unknown as typeof fetch;
  const before = calls;
  await drain(runDeskAgent({ question: "status?", history: [], deps: d, env: { GROQ_API_KEY: "g" }, fetchImpl, cooldowns: new CooldownBook() }));
  // 1 call for the system-prompt snapshot + 1 real tool run; repeats served from cache.
  assert.equal(calls - before, 2);
});

test("compaction shrinks older tool results, keeps newest round full; question stays pinned", () => {
  const big = "y".repeat(3000);
  const turns: Msg[] = [
    { role: "user", content: "Q?" },
    { role: "assistant", content: "", toolCalls: [{ id: "a", name: "t", args: {} }] },
    { role: "tool", content: big, toolCallId: "a", toolName: "t" },
    { role: "assistant", content: "", toolCalls: [{ id: "b", name: "t", args: {} }] },
    { role: "tool", content: big, toolCallId: "b", toolName: "t" },
  ];
  const c = compactOldToolResults(turns, 3);
  assert.ok(c[2]!.content.length < 500);
  assert.equal(c[4]!.content.length, 3000);
  const many: Msg[] = [{ role: "user", content: "Q?" }];
  for (let i = 0; i < 12; i++) many.push({ role: "assistant", content: "", toolCalls: [{ id: `x${i}`, name: "t", args: {} }] }, { role: "tool", content: big, toolCallId: `x${i}`, toolName: "t" });
  const kept = budgetWithPinnedQuestion("sys", many, 0);
  assert.equal(kept[0]!.content, "Q?");
  assert.notEqual(kept[1]!.role, "tool");
});
