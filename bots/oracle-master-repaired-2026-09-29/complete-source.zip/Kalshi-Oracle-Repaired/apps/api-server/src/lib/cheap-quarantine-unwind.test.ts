/**
 * Phase A: cheap-* quarantine unwind — money-path import graph clean.
 * Banners + dual-gate / disabledStrategies; never ENABLE. CHEAP_SIDE stays
 * PAPER_TIER_A (not HARD_NO_FILL) but cannot fill under paper+frozen mayRun.
 * Shadow/replay imports OK. trading-bot must never import cheap-*.
 */
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { leftover15mEvaluateMayRun } from "./leftover-15m-evaluate.js";
import { isHardNoFillStrategy } from "./hard-no-fill.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const CHEAP_FILES = [
  "cheap-side-15m.ts",
  "cheap-early-exit.ts",
  "cheap-persist-sell.ts",
] as const;

test("cheap-* QUARANTINE banners present on all engines", () => {
  for (const f of CHEAP_FILES) {
    const src = fs.readFileSync(path.join(HERE, f), "utf8");
    assert.match(src, /QUARANTINE/, `${f} missing QUARANTINE banner`);
    assert.match(src, /DO NOT ENABLE|DO NOT WIRE/, `${f} missing DO NOT ENABLE/WIRE`);
  }
});

test("trading-bot money-path never imports cheap-* modules", () => {
  const BOT = fs.readFileSync(path.join(HERE, "trading-bot.ts"), "utf8");
  assert.doesNotMatch(BOT, /from ["']\.\/cheap-[^"']+["']/);
  assert.doesNotMatch(BOT, /from ["']\.\/desk-library\/cheap-/);
  // Dual-gates stay fail-closed defaults on host config.
  assert.match(BOT, /cheapSide15mEnabled:\s*false/);
  assert.match(BOT, /cheapEarlyExitEnabled:\s*false/);
});

test("money-path organs do not import cheap-*", () => {
  const organsDir = path.join(HERE, "organs");
  for (const f of fs.readdirSync(organsDir).filter((n) => n.endsWith(".ts") && !n.endsWith(".test.ts"))) {
    const src = fs.readFileSync(path.join(organsDir, f), "utf8");
    assert.doesNotMatch(src, /from ["']\.\.\/cheap-[^"']+["']/, `organs/${f}`);
  }
  // Frozen six-gate evaluate host file (if separate) / admission keep out.
  for (const f of ["frozen-six-gate-evaluate.ts", "admission.ts", "path-ride.ts"]) {
    const p = path.join(HERE, f);
    if (!fs.existsSync(p)) continue;
    const src = fs.readFileSync(p, "utf8");
    assert.doesNotMatch(src, /from ["']\.\/cheap-[^"']+["']/, f);
  }
});

test("CHEAP_EARLY_EXIT is HARD_NO_FILL; CHEAP_SIDE remains dual-gate (not HARD_NO_FILL)", () => {
  assert.equal(isHardNoFillStrategy("CHEAP_EARLY_EXIT"), true);
  assert.equal(isHardNoFillStrategy("CHEAP_SIDE_15M"), false,
    "CHEAP_SIDE stays PAPER_TIER_A — dual-gate + disabled + leftover mayRun deny fills");
  assert.equal(isHardNoFillStrategy("CONFLUENCE_CASCADE"), false);
});

test("live .bot-config: cheap dual-gates false + CHEAP_* disabled; leftover15m mayRun deny on paper+frozen", () => {
  const cfgPath = path.join(HERE, "../../.bot-config.json");
  const cfg = JSON.parse(fs.readFileSync(cfgPath, "utf8")) as {
    paperMode: boolean;
    frozenCcMode: boolean;
    cheapSide15mEnabled: boolean;
    cheapEarlyExitEnabled: boolean;
    disabledStrategies: string[];
  };
  assert.equal(cfg.paperMode, true);
  // Dual-gates are the hard off-switch; do not require rewriting live disabledStrategies.
  assert.equal(cfg.cheapSide15mEnabled, false);
  assert.equal(cfg.cheapEarlyExitEnabled, false);
  // When frozen-cc is on, CHEAP_* must also sit on the denylist. Current desk may run
  // frozenCcMode=false (paper Tier A) — dual-gates false still quarantine money path.
  if (cfg.frozenCcMode === true) {
    assert.ok(cfg.disabledStrategies.includes("CHEAP_SIDE_15M"));
    assert.ok(cfg.disabledStrategies.includes("CHEAP_EARLY_EXIT"));
  }
  assert.equal(
    leftover15mEvaluateMayRun({ paperMode: true, frozenCcMode: true }),
    false,
  );
});

test("README quarantine notes cheap-* off TradingBot placeOrder wire", () => {
  const readme = fs.readFileSync(path.join(HERE, "_research_quarantine/README.md"), "utf8");
  assert.match(readme, /cheap-\*/);
  assert.match(readme, /Do not import quarantine modules from `trading-bot\.ts`/);
});
