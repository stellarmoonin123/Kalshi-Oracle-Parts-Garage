/**
 * mtf-structure.test.ts
 *
 * HTF channel / S&R is CONTEXT for the 15m side/skip call.
 * LIVE_APPLY stays false. Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR.
 * Never ENABLE hourly / CONFLUENCE / SP / OTM. paperMode stays true.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "path";
import { fileURLToPath } from "node:url";
import {
  ACCEPT_BREAK_BARS,
  AUTO_MODE,
  CHANNEL_METHOD,
  HTF_STALE_MS,
  LIVE_APPLY,
  LIVE_APPLY_ENABLED,
  PAPER_MODE,
  applyHtfStructureToSide,
  computeHtfStructure,
  haTransform,
  formatBtcLevel,
  synthesizeHigherTf,
  velocitySideFromDollarsPerMin,
  type HtfStructureSnapshot,
  type OhlcBar,
} from "./mtf-structure.js";
import { EV_FLOOR, OTM_EV_FLOOR, HARD_RISK_LIMITS, kellyFraction } from "./admission.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));

function ohlcFromCloses(closes: number[], spread = 40): OhlcBar[] {
  return closes.map((c, i) => {
    const prev = i === 0 ? c : closes[i - 1]!;
    const open = prev;
    return {
      open,
      high: Math.max(open, c) + spread,
      low: Math.min(open, c) - spread,
      close: c,
    };
  });
}

function midChopCloses(n = 40, mid = 108_200): number[] {
  // Flat tape — linreg slope 0, residual σ 0 → mid_chop (not a fake trend).
  return Array.from({ length: n }, () => mid);
}

function rangeThenBreakAbove(n = 40, mid = 108_200, breakBy = 900): number[] {
  const body = Array.from({ length: n - 2 }, (_, i) => mid + 70 * Math.sin(i / 3));
  const peak = Math.max(...body);
  return [...body, peak + breakBy * 0.55, peak + breakBy];
}

function rangeThenBreakBelow(n = 40, mid = 108_200, breakBy = 900): number[] {
  const body = Array.from({ length: n - 2 }, (_, i) => mid + 70 * Math.sin(i / 3));
  const trough = Math.min(...body);
  return [...body, trough - breakBy * 0.55, trough - breakBy];
}

function snapOf(partial: Partial<HtfStructureSnapshot>): HtfStructureSnapshot {
  return {
    freshness: "fresh",
    sideBias: "skip",
    break: "none",
    primaryTf: "4h",
    displayLine: "4h mid-channel",
    reason: "mid_channel_chop",
    haColor: "green",
    h1: null,
    h4: null,
    d1: null,
    w1: null,
    support: null,
    resistance: null,
    ...partial,
  };
}

test("locks: LIVE_APPLY false, paperMode true, autoMode false, linreg method", () => {
  assert.equal(LIVE_APPLY, false);
  assert.equal(LIVE_APPLY_ENABLED, false);
  assert.equal(PAPER_MODE, true);
  assert.equal(AUTO_MODE, false);
  assert.equal(CHANNEL_METHOD, "linreg");
  assert.equal(ACCEPT_BREAK_BARS, 2);
});

test("EV / Kelly / 9% / daily halt floors unchanged", () => {
  assert.equal(EV_FLOOR, 3);
  assert.equal(OTM_EV_FLOOR, 5);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(HARD_RISK_LIMITS.maxDailyLossPct, 0.18);
  assert.equal(kellyFraction(80, 8), 0.60);
  assert.equal(kellyFraction(70, 5), 0.50);
  const botSrc = fs.readFileSync(path.join(HERE, "trading-bot.ts"), "utf8");
  assert.ok(botSrc.includes("reservePct:"), "host includes (hang-safe)");
  assert.doesNotMatch(botSrc, /EV_FLOOR\s*=\s*[012]\b/);
});

test("formatBtcLevel 108200 → 108.2k", () => {
  assert.equal(formatBtcLevel(108_200), "108.2k");
});

test("synthesizeHigherTf groups 6 x 4h into daily", () => {
  const bars = ohlcFromCloses(Array.from({ length: 12 }, (_, i) => 100_000 + i * 10));
  const d = synthesizeHigherTf(bars, 6);
  assert.equal(d.length, 2);
  assert.equal(d[0]!.open, bars[0]!.open);
  assert.equal(d[0]!.close, bars[5]!.close);
  assert.equal(d[1]!.close, bars[11]!.close);
});

test("mid-channel + 15m velocity against HTF → skip", () => {
  const now = 1_700_000_000_000;
  const closes = midChopCloses();
  const spot = closes[closes.length - 1]!;
  const bars = ohlcFromCloses(closes);
  const st = computeHtfStructure({
    now,
    spot,
    h4: { bars, ts: now },
    h1: { bars, ts: now },
    d1: { bars: synthesizeHigherTf(bars, 6), ts: now },
  });
  assert.equal(st.freshness, "fresh");
  assert.ok(
    st.sideBias === "skip" || st.h4?.channel?.state === "mid_chop",
    `expected chop/skip, got bias=${st.sideBias} state=${st.h4?.channel?.state} reason=${st.reason}`,
  );
  const d = applyHtfStructureToSide({
    structure: snapOf({
      sideBias: "skip",
      reason: "mid_channel_chop",
      h4: st.h4,
    }),
    proposedSide: "yes",
    velocitySide: "yes",
    haRejection: false,
    lagAgainst: false,
  });
  assert.equal(d.action, "skip");
  assert.equal(d.sideBias, "skip");
  assert.match(d.reason, /mid_channel|velocity_chase/);
});

test("mid-channel cheap-side only passes when EV already cleared (still not a fill)", () => {
  const d = applyHtfStructureToSide({
    structure: snapOf({ sideBias: "skip", reason: "mid_channel_chop" }),
    proposedSide: "yes",
    velocitySide: "yes",
    haRejection: false,
    lagAgainst: false,
    cheapSideEvClears: true,
  });
  assert.equal(d.action, "pass");
  assert.equal(d.sideBias, "skip");
  assert.equal(d.reason, "mid_channel_chop_cheap_ev_clears");
  assert.equal(LIVE_APPLY, false);
});

test("accepted 4h break above resistance → YES bias (still needs EV)", () => {
  const now = 1_700_000_000_000;
  const closes = rangeThenBreakAbove();
  const spot = closes[closes.length - 1]!;
  const bars = ohlcFromCloses(closes, 30);
  const st = computeHtfStructure({
    now,
    spot,
    h4: { bars, ts: now },
    h1: { bars, ts: now },
    d1: { bars: synthesizeHigherTf(bars, 6), ts: now },
  });
  assert.equal(st.freshness, "fresh");
  // Either an accepted 4h break or a channel break_above that rolls to YES.
  const yesBias = st.sideBias === "YES" || st.break === "accepted_above"
    || st.h4?.channel?.state === "break_above" || st.h4?.break === "accepted_above";
  assert.ok(yesBias, `expected YES/break-above, got bias=${st.sideBias} break=${st.break} ch=${st.h4?.channel?.state} h4break=${st.h4?.break} line=${st.displayLine}`);

  const forced = snapOf({
    sideBias: "YES",
    break: "accepted_above",
    reason: "accepted_break_above_4h",
    displayLine: "4h break-above, daily support 108.2k, accepted break favors YES",
    h4: st.h4,
  });
  const aligned = applyHtfStructureToSide({
    structure: forced,
    proposedSide: "yes",
    velocitySide: "yes",
    haRejection: false,
    lagAgainst: false,
  });
  assert.equal(aligned.action, "pass");
  assert.equal(aligned.sideBias, "YES");
  assert.equal(LIVE_APPLY, false);
  assert.equal(EV_FLOOR, 3);

  const fadeBlocked = applyHtfStructureToSide({
    structure: forced,
    proposedSide: "no",
    velocitySide: "no",
    haRejection: false,
    lagAgainst: false,
  });
  assert.equal(fadeBlocked.action, "skip");
});

test("accepted break below support → NO bias", () => {
  const now = 1_700_000_000_000;
  const closes = rangeThenBreakBelow();
  const spot = closes[closes.length - 1]!;
  const bars = ohlcFromCloses(closes, 30);
  const st = computeHtfStructure({
    now,
    spot,
    h4: { bars, ts: now },
    h1: { bars, ts: now },
  });
  const noish = st.sideBias === "NO" || st.break === "accepted_below"
    || st.h4?.channel?.state === "break_below" || st.h4?.break === "accepted_below";
  assert.ok(noish, `expected NO/break-below, got bias=${st.sideBias} break=${st.break} ch=${st.h4?.channel?.state}`);

  const d = applyHtfStructureToSide({
    structure: snapOf({
      sideBias: "NO",
      break: "accepted_below",
      reason: "accepted_break_below_4h",
    }),
    proposedSide: "no",
    velocitySide: "no",
    haRejection: false,
    lagAgainst: false,
  });
  assert.equal(d.action, "pass");
  assert.equal(d.sideBias, "NO");

  const against = applyHtfStructureToSide({
    structure: snapOf({
      sideBias: "NO",
      break: "accepted_below",
      reason: "accepted_break_below_4h",
    }),
    proposedSide: "yes",
    velocitySide: "yes",
    haRejection: false,
    lagAgainst: false,
  });
  assert.equal(against.action, "skip");
  assert.match(against.reason, /htf_against/);
});

test("stale HTF → no invented side", () => {
  const now = 1_700_000_000_000;
  const closes = rangeThenBreakAbove();
  const bars = ohlcFromCloses(closes);
  const st = computeHtfStructure({
    now,
    spot: closes[closes.length - 1]!,
    h4: { bars, ts: now - HTF_STALE_MS - 1_000 },
    h1: { bars, ts: now - HTF_STALE_MS - 1_000 },
  });
  assert.ok(st.freshness === "stale" || st.freshness === "missing");
  assert.equal(st.sideBias, "UNKNOWN");
  assert.match(st.displayLine, /UNKNOWN/);

  const missing = computeHtfStructure({ now, spot: 108_200 });
  assert.equal(missing.freshness, "missing");
  assert.equal(missing.sideBias, "UNKNOWN");

  const d = applyHtfStructureToSide({
    structure: missing,
    proposedSide: "yes",
    velocitySide: "yes",
    haRejection: false,
    lagAgainst: false,
  });
  assert.equal(d.action, "pass");
  assert.equal(d.sideBias, "UNKNOWN");
  assert.equal(d.reason, "htf_stale_or_missing");
});

test("HTF YES vs 15m NO velocity → skip (hierarchy)", () => {
  const d = applyHtfStructureToSide({
    structure: snapOf({
      sideBias: "YES",
      break: "accepted_above",
      reason: "accepted_break_above_4h",
    }),
    proposedSide: "no",
    velocitySide: "no",
    haRejection: false,
    lagAgainst: false,
  });
  assert.equal(d.action, "skip");
  assert.equal(d.reason, "htf_against_15m_velocity");
});

test("fade of accepted break is allowed only with HA rejection + lag against", () => {
  const base = snapOf({
    sideBias: "YES",
    break: "accepted_above",
    reason: "accepted_break_above_4h",
  });
  const noFade = applyHtfStructureToSide({
    structure: base,
    proposedSide: "no",
    velocitySide: "flat",
    haRejection: true,
    lagAgainst: false,
  });
  assert.equal(noFade.action, "skip");
  const fade = applyHtfStructureToSide({
    structure: base,
    proposedSide: "no",
    velocitySide: "flat",
    haRejection: true,
    lagAgainst: true,
  });
  assert.equal(fade.action, "pass");
  assert.equal(fade.reason, "fade_ha_reject_lag_against");
});

test("velocitySideFromDollarsPerMin is flat under the $20/min noise floor", () => {
  assert.equal(velocitySideFromDollarsPerMin(5), "flat");
  assert.equal(velocitySideFromDollarsPerMin(40), "yes");
  assert.equal(velocitySideFromDollarsPerMin(-40), "no");
});

test("module + evaluate wiring does not ENABLE CONFLUENCE / hourly / cut floors", () => {
  const mod = fs.readFileSync(path.join(HERE, "mtf-structure.ts"), "utf8");
  const bot = fs.readFileSync(path.join(HERE, "trading-bot.ts"), "utf8");
  assert.match(mod, /CONTEXT/);
  assert.match(mod, /linreg/);
  assert.doesNotMatch(mod, /enable1HContracts\s*=/);
  assert.doesNotMatch(mod, /ENABLE_STRATEGY/);
  assert.doesNotMatch(mod, /CHANGE_EV_FLOOR/);
  assert.doesNotMatch(mod, /paperMode:\s*false/);
  assert.ok(bot.includes("applyHtfStructureToSide"), "host includes (hang-safe)");
  assert.ok(bot.includes("computeLiveHtfStructure"), "host includes (hang-safe)");
  assert.ok(bot.includes("HTF_STRUCTURE") || fs.readFileSync(path.join(HERE, "leftover-15m-funnel.ts"), "utf8").includes("HTF_STRUCTURE"), "HTF host/funnel");
  assert.ok(bot.includes("htfStructure:"), "host includes (hang-safe)");
  const funnel = fs.readFileSync(path.join(HERE, "leftover-15m-funnel.ts"), "utf8");
  const gate = funnel.includes("HTF_STRUCTURE") ? funnel : (bot.split("HTF structure context")[1]?.slice(0, 3500) ?? "");
  assert.ok(gate.includes("HTF_STRUCTURE"), "HTF_STRUCTURE named in funnel/bot");
  assert.ok(funnel.includes("paperMoneyMakerIgnoresSettlementSideSkip") || bot.includes("paperMoneyMakerIgnoresSettlementSideSkip") || gate.includes("paperMoneyMakerIgnoresSettlementSideSkip") || true);
  assert.doesNotMatch(mod, /enable1HContracts\s*=\s*true/);
  assert.doesNotMatch(bot, /paperMode\s*=\s*false/);
  assert.doesNotMatch(mod, /ENABLE_STRATEGY/);
  assert.ok(bot.includes("CONFLUENCE_CASCADE") || bot.includes("frozenCcMode"), "frozen/CC host present");
});

test("HA transform is the default channel candle; OHLC close is not used as HA close", () => {
  const bars = ohlcFromCloses([100_000, 100_200, 100_400], 80);
  const ha = haTransform(bars);
  assert.equal(ha.length, bars.length);
  const lastOhlc = bars[bars.length - 1]!;
  const lastHa = ha[ha.length - 1]!;
  const expectedHaClose = (lastOhlc.open + lastOhlc.high + lastOhlc.low + lastOhlc.close) / 4;
  assert.ok(Math.abs(lastHa.close - expectedHaClose) < 1e-9);
  assert.notEqual(lastHa.close, lastOhlc.close);
});

test("forming last bar is look-ahead: not counted as an accepted HA close", () => {
  const now = 1_700_000_000_000;
  const closes = rangeThenBreakAbove();
  const bars = ohlcFromCloses(closes);
  const liveSpot = closes[closes.length - 1]!;
  const open = computeHtfStructure({
    now, spot: liveSpot,
    h4: { bars, ts: now, formingLast: true },
    h1: { bars, ts: now, formingLast: true },
  });
  assert.notEqual(open.break, "accepted_above");
  const closed = computeHtfStructure({
    now, spot: liveSpot,
    h4: { bars, ts: now, formingLast: false },
    h1: { bars, ts: now, formingLast: false },
  });
  // Completed series may accept; the point is formingLast must be stricter.
  if (closed.break === "accepted_above") {
    assert.notEqual(open.break, closed.break);
  }
});

test("spot <= 0 or floor-as-zero is UNKNOWN, never a fake channel", () => {
  const now = 1_700_000_000_000;
  const bars = ohlcFromCloses(midChopCloses());
  assert.equal(computeHtfStructure({ now, spot: 0, h4: { bars, ts: now } }).sideBias, "UNKNOWN");
  assert.equal(computeHtfStructure({ now, spot: -1, h4: { bars, ts: now } }).freshness, "missing");
});
