import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { deskDataDir, deskDataPath } from "./desk-data-dir.js";
import { defaultLagProofDir } from "./lag-meter.js";

test("desk data dir is cwd/data (the Fly volume mount), not bundle-relative", () => {
  const prev = process.env.DESK_DATA_DIR;
  delete process.env.DESK_DATA_DIR;
  try {
    assert.equal(deskDataDir(), path.resolve(process.cwd(), "data"));
    assert.equal(deskDataPath("mind-calibration.jsonl"), path.resolve(process.cwd(), "data", "mind-calibration.jsonl"));
    assert.equal(defaultLagProofDir(), path.resolve(process.cwd(), "data"));
  } finally {
    if (prev !== undefined) process.env.DESK_DATA_DIR = prev;
  }
});

test("DESK_DATA_DIR override", () => {
  const prev = process.env.DESK_DATA_DIR;
  process.env.DESK_DATA_DIR = "/tmp/desk-x";
  try {
    assert.equal(deskDataPath("a.jsonl"), "/tmp/desk-x/a.jsonl");
  } finally {
    if (prev === undefined) delete process.env.DESK_DATA_DIR; else process.env.DESK_DATA_DIR = prev;
  }
});

test("persistent organ files never resolve data via import.meta.url (bundle puts it off the volume)", () => {
  const here = path.dirname(new URL(import.meta.url).pathname);
  for (const rel of [
    "organs/mind-calibration.ts",
    "organs/brain-center.ts",
    "organs/scar-echo-learning.ts",
    "lag-meter.ts",
    "organ-debug/runner.ts",
  ]) {
    const src = fs.readFileSync(path.join(here, rel), "utf8");
    assert.ok(!/\.\.\/\.\.\/(\.\.\/)?data/.test(src), `${rel} still resolves ../../data relative to the module`);
  }
});
