/**
 * confidence-floor.ts — CONFIDENCE_FLOOR / minConfidence admission.
 *
 * Default: skip when conf < minConfidence (pack-adjusted floor).
 * CONFLUENCE_CASCADE / BASIS_LAG_EDGE only: if ticket EV ≥ 3¢ (p =
 * winRateAtPrice, never confidence) AND side agrees, do not skip the
 * floor. Other strategies still use the floor. minConfidence is not
 * set to 0. p is not written into confidence.
 *
 * LAG side: lagAgreesWithSide AND lagSideConfirmationAgrees.
 * CC side: proposed side is the CC take (yes/no). Do not require a
 * second confluenceFactorBias vote (mixed/null factors still agree).
 * Genuine CC vs LAG opposite is settlement-side (selector null), not a
 * floor bypass.
 */
import { EV_FLOOR, evaluateEntryEVGate } from "./admission.js";
import { lagAgreesWithSide } from "./lag-meter.js";
import {
  lagSignedDollars,
  lagSideConfirmationAgrees,
} from "./basis-lag-edge.js";
import { confluenceFactorBias } from "./confluence-cascade.js";
import { haRiverConfirmSide } from "./path-ride.js";

export const MONEY_MAKER_CONF_FLOOR_IDS = new Set([
  "CONFLUENCE_CASCADE",
  "BASIS_LAG_EDGE",
]);

export function isMoneyMakerConfFloorId(strategyId: string): boolean {
  return MONEY_MAKER_CONF_FLOOR_IDS.has(strategyId);
}

/** Ticket EV in cents from p=winRateAtPrice. Never uses confidence as p. */
export function ticketEVCentsFromP(opts: {
  entryPriceCents: number;
  pWin: number;
  strategyId: string;
  secsRemaining?: number;
  velocityDolPerMin?: number;
  spreadCents?: number;
}): number | null {
  if (!(opts.pWin > 0) || !Number.isFinite(opts.pWin)) return null;
  const g = evaluateEntryEVGate({
    entryPriceCents: opts.entryPriceCents,
    strategyWinRate: opts.pWin,
    strategyId: opts.strategyId,
    secsRemaining: opts.secsRemaining,
    velocityDolPerMin: opts.velocityDolPerMin,
    spreadCents: opts.spreadCents,
  });
  return g.netEV;
}

export function moneyMakerConfFloorSideAgrees(opts: {
  strategyId: string;
  side: "yes" | "no";
  lagAgreesWithSide?: boolean | null;
  lagSideConfirmationAgrees?: boolean | null;
  /** Ignored for CC. Kept so callers that still pass it do not change LAG. */
  ccFactorsSameSide?: boolean | null;
}): boolean {
  if (opts.strategyId === "BASIS_LAG_EDGE") {
    return opts.lagAgreesWithSide === true && opts.lagSideConfirmationAgrees === true;
  }
  if (opts.strategyId === "CONFLUENCE_CASCADE") {
    // The proposed side *is* the CC take. No second factor-bias vote.
    return opts.side === "yes" || opts.side === "no";
  }
  return false;
}

/** Resolve LAG/CC side-agree from obs. Fail-closed missing → false. */
export function resolveMoneyMakerConfFloorSideAgree(opts: {
  strategyId: string;
  side: "yes" | "no";
  obs: {
    lagDollars?: number | null;
    leadDollars?: number | null;
    lagReason?: string | null;
    lagProven?: boolean;
    lagStale?: boolean;
    ohlc1m?: unknown;
    ohlc5m?: unknown;
    velocityDolPerMin?: number;
    threeMinVelocity?: number;
    distFromFloorPct?: number;
    fairDistFromFloorPct?: number;
    massAboveFloor?: number;
    recentUpPct?: number;
    channelInfo?: { confidence: number; nearLower?: boolean; nearUpper?: boolean } | null;
    [k: string]: unknown;
  };
}): boolean {
  const proposed = opts.side === "yes" ? "YES" : "NO";
  if (opts.strategyId === "CONFLUENCE_CASCADE") {
    return moneyMakerConfFloorSideAgrees({
      strategyId: opts.strategyId,
      side: opts.side,
    });
  }
  if (opts.strategyId === "BASIS_LAG_EDGE") {
    const ccFactorSide = confluenceFactorBias(opts.obs as never);
    const dollars = lagSignedDollars(opts.obs);
    const lagAgree = lagAgreesWithSide(opts.side, dollars, {
      proven: opts.obs.lagProven === true,
      stale: opts.obs.lagStale === true,
    });
    const lagConfirm = lagSideConfirmationAgrees({
      projSide: proposed,
      haRiverSide: haRiverConfirmSide(opts.obs as never),
      ccFactorSide,
    });
    return moneyMakerConfFloorSideAgrees({
      strategyId: opts.strategyId,
      side: opts.side,
      lagAgreesWithSide: lagAgree,
      lagSideConfirmationAgrees: lagConfirm,
    });
  }
  return false;
}

export function shouldSkipConfidenceFloor(opts: {
  strategyId: string;
  /** 0–100 evaluateEntry scale. Not p. */
  confidence: number;
  minConfidence: number;
  /** netEV ¢ from evaluateEntryEVGate / computeTradeEV with p=winRateAtPrice. */
  ticketEVCents: number | null;
  sideAgrees: boolean;
}): boolean {
  if (!(opts.confidence < opts.minConfidence)) return false;
  if (!isMoneyMakerConfFloorId(opts.strategyId)) return true;
  if (opts.ticketEVCents == null || !Number.isFinite(opts.ticketEVCents)) return true;
  if (opts.ticketEVCents >= EV_FLOOR && opts.sideAgrees) return false;
  return true;
}
