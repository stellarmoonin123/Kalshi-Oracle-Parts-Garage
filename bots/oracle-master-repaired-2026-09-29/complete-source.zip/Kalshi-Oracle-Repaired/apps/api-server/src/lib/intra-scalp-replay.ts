/**
 * intra-scalp-replay.ts
 *
 * SHADOW fee-net replay of INTRA-CONTRACT scalps on real Kalshi 15m quotes.
 * Not a live engine. Does not import or patch trading-bot.ts.
 *
 * LOCKS
 *   LIVE_APPLY_ENABLED = false. paperMode true. autoMode false.
 *   Never ENABLE_STRATEGY. Never enable VELOCITY_MOMENTUM live.
 *   Never cut EV 3¢ / Kelly / 9% / 18%. Never cut minVelocity.
 *   Never remove the lag-family minVelocity exemption on the SETTLEMENT
 *   book (CHEAP_SIDE_15M / BASIS_LAG_EDGE still buy a still misprice —
 *   that is a different book).
 *   Forbidden fill strategyIds: SETTLEMENT_PREDICTION, LATE_ENTRY,
 *   LATE_ENTRY_ANCHOR, TOP_REVERSAL, BOTTOM_REVERSAL, BOLLINGER,
 *   BOLLINGER_BAND, VELOCITY_MOMENTUM.
 *
 * SPEC (velocity-gated intra-scalp)
 *   Ticket velocity = dAsk/dt or dMid/dt on the Kalshi contract side we
 *   would buy, NOT BTC $/min. A still 11¢ or still 48¢ print is skip.
 *   Entry (velocity book B): cheap-or-mid ask 7–55¢ AND ticket velocity
 *   in the buy direction AND fair (projectedSettlement vs floor) agrees
 *   now AND MTF not fighting AND fee-net EV ≥ 3¢ (paperFillCostCents
 *   / kalshiFeeCents) AND secsRemaining 180–720 AND size 1 AND remaining
 *   9% bar budget covers notional+fee AND not already in a trade.
 *   Ticket velocity (dAsk/dt, dMid/dt) is the confirmation — a still 11¢
 *   or still 48¢ print is skip. Still-cheap cell A keeps persist 15s and
 *   does NOT require ticket velocity (lag-book analog, separate cell).
 *   One 9% risk budget per bar (of bankroll at bar open), not 9% per scalp.
 *   Never both sides open (positions).
 *   Exit, first of: (a) mark−entry ≥ 20¢ green, (b) mark ≥ min(99, 2×entry),
 *   (c) shouldLagFlipExit 15s+3 consecutiveBothAgainst + lagProven, (d) 90s left → sell, (e) settlement.
 *   Opposite-side flip is a SEPARATE shadow cell (not mixed into B).
 *
 * Cells
 *   (A) stillCheap         — same gates as B minus ticket velocity (counterfactual)
 *   (B) velocityIntra      — velocity-confirmed scalps (the intra book)
 *   settlementOnly         — same entry as B, hold to official 0/100, no scalp, no flip
 *   flipShadow             — after B goes flat, at most one opposite-side take
 *   alwaysSkip             — 0 fills, 0 pnl
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
// Do NOT import admission.js here — admission → trade-path → strategy-library →
// cheap-early-exit → this file, so a live EV_FLOOR import creates a TDZ cycle.
import { kalshiFeeCents } from "./constants.js";
import { shouldLagFlipExit } from "./lag-flip.js";
import {
  paperEarlyExitCreditCents,
  paperFillCostCents,
  paperSettlementCreditCents,
} from "./settlement-helpers.js";
import {
  DEFAULT_LABELS_PATH,
  DEFAULT_OVERNIGHT_LOG,
  DEFAULT_TICKS_DIR,
  PATH_MIN_DISP_FRAC,
  loadJsonlLabels,
  loadJsonlTicks,
  parseTickLine,
  pathPWinFromDistance,
  pathSideFromTick,
  persistHeldMs,
  sortTicksCausal,
  updatePersistState,
  type PersistState,
  type TickQuote,
} from "./tick-replay-backtest.js";
import { researchDir, researchPath } from "./desk-data-dir.js";

export type { TickQuote };

export const LIVE_APPLY_ENABLED = false as const;
export const INTRA_SCALP_BANKROLL_START_CENTS = 31_300;
export const INTRA_SCALP_CONTRACTS = 1;
export const INTRA_ASK_MIN_CENTS = 7;
export const INTRA_ASK_MAX_CENTS = 55;
export const INTRA_WINDOW_SECS_MIN = 180;
export const INTRA_WINDOW_SECS_MAX = 720;
export const INTRA_GREEN_CENTS = 20;
export const INTRA_TIME_STOP_SECS = 90;
export const TICKET_VEL_LOOKBACK_MS = 8_000;
export const TICKET_VEL_MIN_MOVE_CENTS = 2;
export const INTRA_PERSIST_MS = 15_000; // keep in sync with PERSIST_LAG_MIN_HOLD_MS
/** Must stay === admission.EV_FLOOR (3). Literal breaks admission↔intra TDZ cycle. */
export const INTRA_MIN_EV_CENTS = 3;
/** Must stay === HARD_RISK_LIMITS.maxRiskPctPerTrade (0.09). */
export const INTRA_BAR_RISK_PCT = 0.09;

const FORBIDDEN_TAKE_STRATEGY_IDS = new Set([
  "SETTLEMENT_PREDICTION",
  "LATE_ENTRY",
  "LATE_ENTRY_ANCHOR",
  "TOP_REVERSAL",
  "BOTTOM_REVERSAL",
  "BOLLINGER",
  "BOLLINGER_BAND",
  "VELOCITY_MOMENTUM",
]);

export type IntraPolicyId =
  | "velocityIntra"
  | "stillCheap"
  | "settlementOnly"
  | "flipShadow"
  | "alwaysSkip";

export type IntraStrategyId =
  | "INTRA_SCALP"
  | "STILL_CHEAP"
  | "INTRA_SCALP_FLIP"
  | "SETTLEMENT_ONLY";

export type IntraExit =
  | "sell_green"
  | "two_x"
  | "lag_flip"
  | "time_stop"
  | "settlement";

export interface IntraFill {
  ticker: string;
  policyId: IntraPolicyId;
  strategyId: IntraStrategyId;
  side: "yes" | "no";
  fillPriceCents: number;
  fillTs: number;
  pWin: number | null;
  exit: IntraExit;
  exitTs: number;
  exitBidCents: number | null;
  won: boolean;
  feeNetPnlCents: number;
  fillCostCents: number;
  isFlip: boolean;
  ticketVelocity: { dAskCents: number; dMidCents: number; dtMs: number } | null;
}

export interface IntraBarResult {
  ticker: string;
  policyId: IntraPolicyId;
  fills: IntraFill[];
  nFlips: number;
  feeNetPnlCents: number;
  maxOpen: number;
  barBudgetCents: number;
  spentBudgetCents: number;
  blockedThirdByBudget: boolean;
}

export interface IntraPolicySummary {
  policyId: IntraPolicyId;
  nBars: number;
  nFills: number;
  nFlips: number;
  nWins: number;
  nLosses: number;
  feeNetPnlCents: number;
  startBankrollCents: number;
  endBankrollCents: number;
  strategyIds: IntraStrategyId[];
}

export interface IntraScalpSummary {
  generatedAt: string;
  paperMode: true;
  autoMode: false;
  liveApplyEnabled: false;
  bankrollStartCents: number;
  nBars: number;
  nTickFiles: number;
  observeOnly: boolean;
  observeReason: string | null;
  alwaysSkipFeeNetPnlCents: 0;
  intraFills: number;
  flips: number;
  feeNetPnlCents: number;
  stillCheapFeeNetPnlCents: number;
  velocityConfirmedFeeNetPnlCents: number;
  settlementHoldTo100FeeNetPnlCents: number;
  alwaysSkip: 0;
  intraBeatHoldToSettlement: boolean;
  policies: Record<IntraPolicyId, IntraPolicySummary>;
  limitations: string[];
  fills: IntraFill[];
}

export const INTRA_SCALP_LIMITATIONS: string[] = [
  "SHADOW only. LIVE_APPLY false. Not a live engine. Does not ENABLE_STRATEGY or VELOCITY_MOMENTUM.",
  "Ticket velocity is dAsk/dt or dMid/dt on the Kalshi side we would buy, not BTC $/min. Still 11¢ / still 48¢ is skip on book B.",
  "Lag-family minVelocity exemption on the SETTLEMENT book (cheap-side / basis-lag) is untouched.",
  "MTF: tick files have no MTF series; mtf=0 always. Veto at ±3 is implemented and idle on this tape.",
  "9% is one bar budget of bankroll-at-open, not 9% per scalp. Size is 1. Budget is spent at entry (not restored on exit).",
  "Opposite-side flip is a separate shadow cell. Never both sides open (one position).",
  "Tiny n → OBSERVE. Does not cut EV 3¢ / Kelly / 9% / 18%.",
];

function assertAllowedStrategyId(id: string): asserts id is IntraStrategyId {
  if (FORBIDDEN_TAKE_STRATEGY_IDS.has(id)) {
    throw new Error(`intra-scalp replay must never take ${id}`);
  }
}

export function isIntraAskBand(ask: number): boolean {
  return Number.isFinite(ask) && ask >= INTRA_ASK_MIN_CENTS && ask <= INTRA_ASK_MAX_CENTS;
}

export function inIntraWindow(secsRemaining: number): boolean {
  return Number.isFinite(secsRemaining)
    && secsRemaining >= INTRA_WINDOW_SECS_MIN
    && secsRemaining <= INTRA_WINDOW_SECS_MAX;
}

export function mtfFightsSide(side: "yes" | "no", mtf: number): boolean {
  const m = Number.isFinite(mtf) ? mtf : 0;
  if (m <= -3 && side === "yes") return true;
  if (m >= 3 && side === "no") return true;
  return false;
}

function askOf(side: "yes" | "no", tick: TickQuote): number {
  return side === "yes" ? tick.yesAsk : tick.noAsk;
}

function bidOf(side: "yes" | "no", tick: TickQuote): number {
  return side === "yes" ? tick.yesBid : tick.noBid;
}

export function ticketMidCents(side: "yes" | "no", tick: TickQuote): number {
  return (askOf(side, tick) + bidOf(side, tick)) / 2;
}

export function bothAsksInBand(tick: TickQuote): boolean {
  return isIntraAskBand(tick.yesAsk) && isIntraAskBand(tick.noAsk);
}

export function isLagAgainst(side: "yes" | "no", tick: TickQuote): boolean {
  if (tick.projectedSettlement == null || !(tick.floor > 0)) return false;
  const disp = Math.abs(tick.projectedSettlement - tick.floor) / tick.floor;
  if (disp < PATH_MIN_DISP_FRAC) return false;
  return side === "yes" ? tick.projectedSettlement < tick.floor : tick.projectedSettlement > tick.floor;
}

export interface TicketVelocity {
  dAskCents: number;
  dMidCents: number;
  dtMs: number;
  inBuyDirection: boolean;
}

/**
 * Ticket velocity on the Kalshi side we would buy.
 * Fail-closed with null when there is not enough lookback (not "still", not "moving").
 * inBuyDirection requires the ask OR mid to have risen by ≥ TICKET_VEL_MIN_MOVE_CENTS
 * over ~TICKET_VEL_LOOKBACK_MS. A still print is false, not null.
 */
export function ticketVelocity(opts: {
  side: "yes" | "no";
  now: TickQuote;
  history: TickQuote[];
}): TicketVelocity | null {
  const target = opts.now.ts - TICKET_VEL_LOOKBACK_MS;
  let then: TickQuote | null = null;
  for (let i = opts.history.length - 1; i >= 0; i--) {
    const t = opts.history[i]!;
    if (t.ts <= target) {
      then = t;
      break;
    }
  }
  if (!then) return null;
  const dtMs = opts.now.ts - then.ts;
  if (dtMs < TICKET_VEL_LOOKBACK_MS * 0.75) return null;
  const dAskCents = askOf(opts.side, opts.now) - askOf(opts.side, then);
  const dMidCents = ticketMidCents(opts.side, opts.now) - ticketMidCents(opts.side, then);
  const inBuyDirection =
    dAskCents >= TICKET_VEL_MIN_MOVE_CENTS || dMidCents >= TICKET_VEL_MIN_MOVE_CENTS;
  return { dAskCents, dMidCents, dtMs, inBuyDirection };
}

export function ticketDeltasFromHistory(now: TickQuote, history: TickQuote[]): {
  yesAskDeltaCents: number | null;
  noAskDeltaCents: number | null;
  yesMidDeltaCents: number | null;
  noMidDeltaCents: number | null;
} {
  const yv = ticketVelocity({ side: "yes", now, history });
  const nv = ticketVelocity({ side: "no", now, history });
  return {
    yesAskDeltaCents: yv ? yv.dAskCents : null,
    noAskDeltaCents: nv ? nv.dAskCents : null,
    yesMidDeltaCents: yv ? yv.dMidCents : null,
    noMidDeltaCents: nv ? nv.dMidCents : null,
  };
}

export function feeNetSettlementEVCents(askCents: number, pWin: number): number {
  const fillCost = paperFillCostCents(INTRA_SCALP_CONTRACTS, askCents);
  return pWin * 100 - fillCost;
}

function strategyFor(policy: IntraPolicyId, isFlip: boolean): IntraStrategyId {
  if (policy === "stillCheap") return "STILL_CHEAP";
  if (policy === "settlementOnly") return "SETTLEMENT_ONLY";
  if (policy === "flipShadow" && isFlip) return "INTRA_SCALP_FLIP";
  return "INTRA_SCALP";
}

interface OpenPos {
  side: "yes" | "no";
  entryCents: number;
  fillTs: number;
  pWin: number | null;
  vel: TicketVelocity | null;
  isFlip: boolean;
}

function closeFill(opts: {
  ticker: string;
  policyId: IntraPolicyId;
  open: OpenPos;
  exit: IntraExit;
  exitTs: number;
  exitBidCents: number | null;
  settled: "YES" | "NO";
}): IntraFill {
  const strategyId = strategyFor(opts.policyId, opts.open.isFlip);
  assertAllowedStrategyId(strategyId);
  const fillCostCents = paperFillCostCents(INTRA_SCALP_CONTRACTS, opts.open.entryCents);
  let credit: number;
  let won: boolean;
  if (opts.exit === "settlement") {
    const settledWon = opts.open.side.toUpperCase() === opts.settled;
    credit = paperSettlementCreditCents(INTRA_SCALP_CONTRACTS, settledWon);
    won = settledWon;
  } else {
    const exitBid = opts.exitBidCents ?? 0;
    credit = paperEarlyExitCreditCents(INTRA_SCALP_CONTRACTS, exitBid);
    won = credit > fillCostCents;
  }
  return {
    ticker: opts.ticker,
    policyId: opts.policyId,
    strategyId,
    side: opts.open.side,
    fillPriceCents: opts.open.entryCents,
    fillTs: opts.open.fillTs,
    pWin: opts.open.pWin,
    exit: opts.exit,
    exitTs: opts.exitTs,
    exitBidCents: opts.exitBidCents,
    won,
    feeNetPnlCents: credit - fillCostCents,
    fillCostCents,
    isFlip: opts.open.isFlip,
    ticketVelocity: opts.open.vel
      ? { dAskCents: opts.open.vel.dAskCents, dMidCents: opts.open.vel.dMidCents, dtMs: opts.open.vel.dtMs }
      : null,
  };
}

function pickExit(opts: {
  policy: IntraPolicyId;
  open: OpenPos;
  tick: TickQuote;
  samplesAgainst: number;
}): IntraExit | null {
  if (opts.policy === "settlementOnly") return null;
  const mark = bidOf(opts.open.side, opts.tick);
  if (Number.isFinite(mark)) {
    if (mark - opts.open.entryCents >= INTRA_GREEN_CENTS) return "sell_green";
    const twoX = Math.min(99, 2 * opts.open.entryCents);
    if (mark >= twoX) return "two_x";
  }
  const msSinceFill = opts.tick.ts - opts.open.fillTs;
  if (shouldLagFlipExit({ consecutiveBothAgainst: opts.samplesAgainst, lagProven: true, msSinceFill })) return "lag_flip";
  if (opts.tick.secsRemaining <= INTRA_TIME_STOP_SECS) return "time_stop";
  return null;
}

export interface IntraEntryIntent {
  side: "yes" | "no";
  ask: number;
  pWin: number;
  vel: TicketVelocity | null;
  reason: string;
}

/**
 * Pure per-tick entry decision. MUST NOT accept a settlement label.
 */
export function decideIntraEntry(opts: {
  policy: IntraPolicyId;
  tick: TickQuote;
  persist: PersistState;
  history: TickQuote[];
  open: boolean;
  fillsThisBar: number;
  firstSide: "yes" | "no" | null;
  remainingBudgetCents: number;
  mtf?: number;
}): IntraEntryIntent | null {
  const { policy, tick, persist } = opts;
  if (policy === "alwaysSkip") return null;
  if (opts.open) return null; // never both sides open (positions, not both-asks-in-band)
  if (!inIntraWindow(tick.secsRemaining)) return null;

  const requireVel = policy === "velocityIntra" || policy === "settlementOnly" || policy === "flipShadow";
  let side: "yes" | "no" | null;
  if (requireVel) {
    // Velocity book: fair agrees now. Ticket motion is the confirmation
    // (a still 11¢/48¢ after 15s persist is exactly what we skip).
    side = pathSideFromTick(tick);
  } else {
    if (persist.side == null) return null;
    if (persistHeldMs(persist, tick) < INTRA_PERSIST_MS) return null;
    side = persist.side;
  }
  if (side == null) return null;
  if (mtfFightsSide(side, opts.mtf ?? 0)) return null;

  if (policy === "flipShadow") {
    if (opts.firstSide == null) {
      // first (non-flip) take is simulated so we can arm the opposite cell
    } else if (side === opts.firstSide) {
      return null;
    } else if (opts.fillsThisBar >= 1) {
      return null; // one opposite fill per bar
    }
  }

  const ask = askOf(side, tick);
  if (!isIntraAskBand(ask)) return null;

  const pWin = pathPWinFromDistance(tick);
  if (pWin == null) return null;
  const ev = feeNetSettlementEVCents(ask, pWin);
  if (!(ev >= INTRA_MIN_EV_CENTS)) return null;

  const fillCost = paperFillCostCents(INTRA_SCALP_CONTRACTS, ask);
  if (!(opts.remainingBudgetCents >= fillCost)) return null;
  // pin kalshiFeeCents so a missing helper would fail to compile / be unused
  if (!(kalshiFeeCents(ask) >= 0)) return null;

  const vel = ticketVelocity({ side, now: tick, history: opts.history });
  if (requireVel) {
    if (!vel || !vel.inBuyDirection) return null;
  }

  return {
    side,
    ask,
    pWin,
    vel,
    reason: requireVel ? "velocity_confirmed" : "still_cheap",
  };
}

export function replayBar(opts: {
  ticks: TickQuote[];
  settled: "YES" | "NO";
  policy: IntraPolicyId;
  startBankrollCents?: number;
  mtf?: number;
}): IntraBarResult {
  const ticks = sortTicksCausal(opts.ticks);
  const ticker = ticks[0]?.ticker ?? "";
  const policy = opts.policy;
  const bankrollOpen = opts.startBankrollCents ?? INTRA_SCALP_BANKROLL_START_CENTS;
  const barBudgetCents = Math.floor(bankrollOpen * INTRA_BAR_RISK_PCT);

  if (policy === "alwaysSkip") {
    return {
      ticker,
      policyId: policy,
      fills: [],
      nFlips: 0,
      feeNetPnlCents: 0,
      maxOpen: 0,
      barBudgetCents,
      spentBudgetCents: 0,
      blockedThirdByBudget: false,
    };
  }

  let persist: PersistState = { side: null, sinceTs: 0 };
  const pos: { open: OpenPos | null } = { open: null };
  let samplesAgainst = 0;
  let spentBudgetCents = 0;
  let maxOpen = 0;
  let firstSide: "yes" | "no" | null = null;
  let closedNonFlip = 0;
  let attemptedEntries = 0;
  let blockedThirdByBudget = false;
  const fills: IntraFill[] = [];
  const history: TickQuote[] = [];

  const remaining = () => barBudgetCents - spentBudgetCents;

  const tryEnter = (tick: TickQuote) => {
    const intent = decideIntraEntry({
      policy,
      tick,
      persist,
      history,
      open: pos.open != null,
      fillsThisBar: fills.filter(f => f.isFlip).length,
      firstSide,
      remainingBudgetCents: remaining(),
      mtf: opts.mtf,
    });
    if (!intent) {
      // Detect a third same-side attempt blocked only by budget (for the test).
      if (policy === "velocityIntra" && pos.open == null && inIntraWindow(tick.secsRemaining)) {
        const sideNow = pathSideFromTick(tick);
        if (sideNow && isIntraAskBand(askOf(sideNow, tick))) {
          const ask = askOf(sideNow, tick);
          const cost = paperFillCostCents(INTRA_SCALP_CONTRACTS, ask);
          if (attemptedEntries >= 2 && remaining() < cost) blockedThirdByBudget = true;
        }
      }
      return;
    }

    if (policy === "flipShadow") {
      if (firstSide == null) {
        // Simulate the first velocity take so we can go flat and arm the flip,
        // but do not count it as a flip-cell fill.
        const cost = paperFillCostCents(INTRA_SCALP_CONTRACTS, intent.ask);
        spentBudgetCents += cost;
        attemptedEntries += 1;
        pos.open = {
          side: intent.side,
          entryCents: intent.ask,
          fillTs: tick.ts,
          pWin: intent.pWin,
          vel: intent.vel,
          isFlip: false,
        };
        firstSide = intent.side;
        samplesAgainst = 0;
        maxOpen = Math.max(maxOpen, 1);
        return;
      }
      if (intent.side === firstSide) return;
      if (fills.some(f => f.isFlip)) return;
    }

    if (policy === "settlementOnly" && (fills.length > 0 || closedNonFlip > 0 || firstSide != null)) {
      return;
    }
    if (policy === "velocityIntra" || policy === "stillCheap") {
      // never open the other side on the main book (flip is a separate cell)
      if (firstSide != null && intent.side !== firstSide) return;
    }

    const cost = paperFillCostCents(INTRA_SCALP_CONTRACTS, intent.ask);
    if (remaining() < cost) {
      if (attemptedEntries >= 2) blockedThirdByBudget = true;
      return;
    }
    spentBudgetCents += cost;
    attemptedEntries += 1;
    const isFlip = policy === "flipShadow" && firstSide != null && intent.side !== firstSide;
    pos.open = {
      side: intent.side,
      entryCents: intent.ask,
      fillTs: tick.ts,
      pWin: intent.pWin,
      vel: intent.vel,
      isFlip,
    };
    if (firstSide == null) firstSide = intent.side;
    samplesAgainst = 0;
    maxOpen = Math.max(maxOpen, 1);
  };

  const settleOpen = (tick: TickQuote, exit: IntraExit) => {
    if (!pos.open) return;
    const fill = closeFill({
      ticker,
      policyId: policy,
      open: pos.open,
      exit,
      exitTs: tick.ts,
      exitBidCents: exit === "settlement" ? null : bidOf(pos.open.side, tick),
      settled: opts.settled,
    });
    if (policy === "flipShadow") {
      if (fill.isFlip) fills.push(fill);
      else closedNonFlip += 1;
    } else {
      fills.push(fill);
    }
    pos.open = null;
    samplesAgainst = 0;
  };

  for (const tick of ticks) {
    persist = updatePersistState(persist, tick);
    history.push(tick);

    if (pos.open) {
      maxOpen = Math.max(maxOpen, 1);
      samplesAgainst = isLagAgainst(pos.open.side, tick) ? samplesAgainst + 1 : 0;
      const exit = pickExit({ policy, open: pos.open, tick, samplesAgainst });
      if (exit) {
        settleOpen(tick, exit);
        // after flat, may enter on a later tick (or this tick only if we were
        // not already in a trade at the start of the tick). Same-tick reentry
        // is forbidden: we just exited.
        continue;
      }
      continue;
    }

    tryEnter(tick);
  }

  if (pos.open) {
    const last = ticks[ticks.length - 1]!;
    settleOpen(last, "settlement");
  }

  const published = policy === "flipShadow" ? fills.filter(f => f.isFlip) : fills;
  return {
    ticker,
    policyId: policy,
    fills: published,
    nFlips: published.filter(f => f.isFlip).length,
    feeNetPnlCents: published.reduce((s, f) => s + f.feeNetPnlCents, 0),
    maxOpen,
    barBudgetCents,
    spentBudgetCents,
    blockedThirdByBudget,
  };
}

const ALL_POLICIES: IntraPolicyId[] = [
  "velocityIntra",
  "stillCheap",
  "settlementOnly",
  "flipShadow",
  "alwaysSkip",
];

function emptyPolicySummary(policyId: IntraPolicyId): IntraPolicySummary {
  return {
    policyId,
    nBars: 0,
    nFills: 0,
    nFlips: 0,
    nWins: 0,
    nLosses: 0,
    feeNetPnlCents: 0,
    startBankrollCents: INTRA_SCALP_BANKROLL_START_CENTS,
    endBankrollCents: INTRA_SCALP_BANKROLL_START_CENTS,
    strategyIds: [],
  };
}

export function summarizeIntra(results: IntraBarResult[], extra?: { nTickFiles?: number }): IntraScalpSummary {
  const byPolicy = new Map<IntraPolicyId, IntraPolicySummary>();
  for (const p of ALL_POLICIES) byPolicy.set(p, emptyPolicySummary(p));
  const fills: IntraFill[] = [];
  const tickers = new Set<string>();

  for (const r of results) {
    tickers.add(r.ticker);
    const s = byPolicy.get(r.policyId)!;
    s.nBars += 1;
    s.nFills += r.fills.length;
    s.nFlips += r.nFlips;
    s.feeNetPnlCents += r.feeNetPnlCents;
    s.endBankrollCents += r.feeNetPnlCents;
    for (const f of r.fills) {
      if (f.won) s.nWins += 1;
      else s.nLosses += 1;
      if (!s.strategyIds.includes(f.strategyId)) s.strategyIds.push(f.strategyId);
      fills.push(f);
    }
  }

  const nBars = tickers.size;
  const observeOnly = nBars < 80;
  const policies = {} as Record<IntraPolicyId, IntraPolicySummary>;
  for (const p of ALL_POLICIES) policies[p] = byPolicy.get(p)!;

  const intra = policies.velocityIntra;
  const still = policies.stillCheap;
  const hold = policies.settlementOnly;
  const flip = policies.flipShadow;

  return {
    generatedAt: new Date().toISOString(),
    paperMode: true,
    autoMode: false,
    liveApplyEnabled: LIVE_APPLY_ENABLED,
    bankrollStartCents: INTRA_SCALP_BANKROLL_START_CENTS,
    nBars,
    nTickFiles: extra?.nTickFiles ?? nBars,
    observeOnly,
    observeReason: observeOnly
      ? `OBSERVE not a live engine — nBars=${nBars} is tiny (need a much larger labeled tape).`
      : null,
    alwaysSkipFeeNetPnlCents: 0,
    intraFills: intra.nFills,
    flips: flip.nFills,
    feeNetPnlCents: intra.feeNetPnlCents,
    stillCheapFeeNetPnlCents: still.feeNetPnlCents,
    velocityConfirmedFeeNetPnlCents: intra.feeNetPnlCents,
    settlementHoldTo100FeeNetPnlCents: hold.feeNetPnlCents,
    alwaysSkip: 0,
    intraBeatHoldToSettlement: intra.feeNetPnlCents > hold.feeNetPnlCents,
    policies,
    limitations: INTRA_SCALP_LIMITATIONS,
    fills,
  };
}

export const DEFAULT_INTRA_SUMMARY_PATH = researchPath("intra-scalp-replay-summary.json");

function tickFileForTicker(ticksDir: string, ticker: string, files: string[]): string | null {
  const suffix = `-${ticker}.jsonl`;
  const hit = files.find(f => f.endsWith(suffix) || f === `${ticker}.jsonl`);
  return hit ? path.join(ticksDir, hit) : null;
}

export function runIntraScalpReplayFromDisk(opts?: {
  ticksDir?: string;
  labelsPath?: string;
  summaryPath?: string;
  overnightLogPath?: string;
  writeOutputs?: boolean;
}): IntraScalpSummary {
  const ticksDir = opts?.ticksDir ?? DEFAULT_TICKS_DIR;
  const labelsPath = opts?.labelsPath ?? DEFAULT_LABELS_PATH;
  const labels = loadJsonlLabels(labelsPath);
  const files = fs.existsSync(ticksDir)
    ? fs.readdirSync(ticksDir).filter(f => f.endsWith(".jsonl"))
    : [];

  const results: IntraBarResult[] = [];
  let nTickFilesUsed = 0;
  const runningBankroll: Record<IntraPolicyId, number> = {
    velocityIntra: INTRA_SCALP_BANKROLL_START_CENTS,
    stillCheap: INTRA_SCALP_BANKROLL_START_CENTS,
    settlementOnly: INTRA_SCALP_BANKROLL_START_CENTS,
    flipShadow: INTRA_SCALP_BANKROLL_START_CENTS,
    alwaysSkip: INTRA_SCALP_BANKROLL_START_CENTS,
  };
  for (const label of labels) {
    const file = tickFileForTicker(ticksDir, label.ticker, files);
    if (!file || !fs.existsSync(file)) continue;
    const ticks = loadJsonlTicks(file);
    if (ticks.length === 0) continue;
    nTickFilesUsed += 1;
    for (const policy of ALL_POLICIES) {
      const bar = replayBar({
        ticks,
        settled: label.settled,
        policy,
        startBankrollCents: runningBankroll[policy],
      });
      runningBankroll[policy] += bar.feeNetPnlCents;
      results.push(bar);
    }
  }

  const summary = summarizeIntra(results, { nTickFiles: nTickFilesUsed });

  if (opts?.writeOutputs !== false) {
    const summaryPath = opts?.summaryPath ?? DEFAULT_INTRA_SUMMARY_PATH;
    fs.mkdirSync(path.dirname(summaryPath), { recursive: true });
    fs.writeFileSync(summaryPath, JSON.stringify(summary, null, 2) + "\n");
    const overnightLogPath = opts?.overnightLogPath ?? DEFAULT_OVERNIGHT_LOG;
    appendOvernightLog(overnightLogPath, summary);
  }

  return summary;
}

function appendOvernightLog(filePath: string, summary: IntraScalpSummary): void {
  const beat = summary.intraBeatHoldToSettlement ? "YES — intra beat hold-to-settlement" : "NO — intra did not beat hold-to-settlement";
  const block = `

## Intra-scalp replay (2026-08-27 ~4:15pm ET)

Paper stays paper. autoMode false. LIVE_APPLY false. No ENABLE_STRATEGY. Did not enable VELOCITY_MOMENTUM. Did not cut minVelocity. Did not remove the lag-family minVelocity exemption on the SETTLEMENT book. Did not edit trading-bot.ts. Intra-scalp is a shadow book that buys WITH TICKET VELOCITY (dAsk/dt or dMid/dt on the Kalshi side, not BTC $/min): a still 11¢ or still 48¢ print is skip. Cheap-or-mid 7–55¢, ticket velocity in the buy direction (still 11¢/48¢ skip; persist 15s is still-cheap cell A only), fee-net EV≥3¢, one 9% bar budget, never both-open, sell +20¢ / 2x / lag-flip 15s+16 / 90s. Opposite-side flip is a separate cell. nBars=${summary.nBars}. Intra (velocity) fills=${summary.intraFills} feeNet=${summary.velocityConfirmedFeeNetPnlCents}¢. Still-cheap (A, no velocity) feeNet=${summary.stillCheapFeeNetPnlCents}¢. Settlement-hold-to-100 feeNet=${summary.settlementHoldTo100FeeNetPnlCents}¢. Flips=${summary.flips}. alwaysSkip=0. ${beat}. ${summary.observeOnly ? summary.observeReason : ""} Spec: \`apps/api-server/src/lib/intra-scalp-replay.ts\`. Summary: \`research/intra-scalp-replay-summary.json\`.
`;
  try {
    fs.appendFileSync(filePath, block);
  } catch (err) {
    console.warn("[intra-scalp] overnight-score-lift.md append failed:", (err as Error).message);
  }
}

export { parseTickLine };

const thisFile = fileURLToPath(import.meta.url);
const invoked = process.argv[1] ? path.resolve(process.argv[1]) : "";
// Under esbuild bundle, import.meta.url resolves to dist/index.mjs and equals argv[1] —
// do not treat the production server entry as a CLI main (Fly crash: missing research JSONL).
if (
  invoked &&
  thisFile === invoked &&
  path.basename(thisFile) !== "index.mjs" &&
  path.basename(thisFile) !== "index.js" &&
  !process.env.KALSHI_ORACLE_FLY
) {
  const summary = runIntraScalpReplayFromDisk({ writeOutputs: true });
  console.log(JSON.stringify({
    nBars: summary.nBars,
    observeOnly: summary.observeOnly,
    intraFills: summary.intraFills,
    flips: summary.flips,
    velocityConfirmedFeeNetPnlCents: summary.velocityConfirmedFeeNetPnlCents,
    stillCheapFeeNetPnlCents: summary.stillCheapFeeNetPnlCents,
    settlementHoldTo100FeeNetPnlCents: summary.settlementHoldTo100FeeNetPnlCents,
    alwaysSkip: summary.alwaysSkip,
    intraBeatHoldToSettlement: summary.intraBeatHoldToSettlement,
    liveApplyEnabled: summary.liveApplyEnabled,
  }, null, 2));
}
