/**
 * liquidity-policy.ts — P4: LIQUIDITY POLICY (BOOK-AWARE HAIRCUTS, NOT A
 * SIGNAL ENGINE).
 *
 * Pure, consume-only module. Reads L2 order-book state (spread/depth/
 * imbalance) already captured elsewhere (kalshi-ws.ts's 5s orderbook poll)
 * and turns it into an ALLOW / HAIRCUT / SKIP verdict plus a size multiplier.
 * It NEVER creates a trade thesis, NEVER touches EV/PATH_GATE/RICH_ASK/9%/
 * SEV1/size-0 admission, NEVER rewrites MarketState (market-state.ts, P3 —
 * consume only), and NEVER expands specialist-pack membership. This mirrors
 * family-policy.ts's architecture: a pure helper module with no owned
 * polling loop, fed by whatever trading-bot.ts/kalshi-ws.ts already track.
 *
 * ── Data source & degraded-mode semantics (revised P4.1) ────────────────────
 * Two independent freshness signals feed a BookSnap:
 *   1. Top-of-book quote (yesBid/yesAsk/noBid/noAsk) — the same live WS
 *      ticker feed that already drives entryPrice/order placement elsewhere
 *      in trading-bot.ts. If the side's bid/ask isn't available at all,
 *      spreadCents=null and `noQuote=true` → BOOK_MISSING, hard SKIP for
 *      every family (unchanged from P4 — distinct from a merely-wide spread).
 *   2. The L2 order-book snapshot (kalshi-ws.ts's captureL2Snapshot(), a
 *      REST poll every 5s, refreshed immediately on contract switch — see
 *      Task #385's comment in kalshi-ws.ts) — supplies depthAtAsk/imbalance.
 *
 * P4.1 HOTFIX: P4 originally collapsed three distinct L2 conditions into one
 * `bookStale` fail-closed SKIP. They are now classified separately:
 *   - BOOK_STALE (hard SKIP, every family, no fallthrough to spread/depth
 *     rules): a snapshot EXISTS but is unusable for this decision — either
 *     it's for the wrong ticker (stale market data, not "no data") or its
 *     age exceeds BOOK_STALE_MS. Both mean something is actively wrong with
 *     the feed for the market we're about to trade, not merely "depth isn't
 *     captured yet" — hence still fail-closed, stricter than the spec's
 *     general spread-only allowance, exactly as P4 reasoned.
 *   - DEPTH_NULL / degraded (NOT stale, NOT a skip on its own): no L2
 *     snapshot has been captured for ANY ticker yet (e.g. moments after a
 *     fresh contract switch, before the first L2 poll completes) while the
 *     top-of-book quote itself is present and fresh. `bookStale` stays
 *     false and `depthAtAsk`/`imbalance` stay null (never invented) — this
 *     degrades to a spread-only policy (rule 2 only; rules 3/4 simply don't
 *     fire on a null value) instead of a hard skip, per P4.1.
 *   - FULL: snapshot exists, matches the current ticker, and is fresh →
 *     full rule 2/3/4 table runs unchanged from P4.
 * This distinction already falls out of `evaluateLiquidity`'s existing rule
 * order (rule 1 only checks `noQuote`/`bookStale`; rules 3/4 already no-op
 * on a null depth/imbalance) — the P4.1 fix lives entirely in
 * `buildBookSnap`'s classification of *when* `bookStale` is set.
 *
 * ── Family-differentiated actions (Part B) ──────────────────────────────────
 * Spec explicitly assigns: rule 2 (spread) hard-skips {momentum, breakout,
 * confluence}; rules 3 (depth) and 4 (imbalance) hard-skip only {momentum,
 * breakout}. mean_reversion and confluence are not named for rules 3/4 —
 * reasoned (not spec-given, documented here per the same pattern P3 used for
 * undocumented family assignments): rule 3 gives mean_reversion/confluence
 * the same soft ≤0.5 haircut ceiling the spec offers momentum/breakout as an
 * alternative to a hard skip; rule 4 gives them the same ×0.7 stacking
 * haircut explicitly specified for "everyone else" in that rule.
 *
 * ── Locks (unchanged — verified against this file) ──────────────────────────
 * EV floors, PATH_GATE minima, RICH_ASK, 9% hard risk cap, daily halt,
 * size-0 abort, SEV1, specialist pack membership, MarketState formulas
 * (consume only), winRateAtPrice, hourly sweep — none of these are read,
 * written, or gated by this module. `sizeMult` returned here is a pure
 * multiplicative haircut applied to an ALREADY-approved contract count
 * (after uMult/volSizeMult), and a SKIP here never resurrects a protective
 * 0 — SKIP is a distinct action the caller must honor by not placing the
 * order at all, not by forcing sizeMult through the size spine.
 */

import { logger } from './logger.js';
import type { Family } from './family-policy.js';

// ── Starter constants (documented per spec's Definition of Done) ───────────

/** L2 snapshot max age before it's considered untrustworthy. Set to the top
 *  of the spec's 2000-5000ms suggested range, matching kalshi-ws.ts's own
 *  5s L2 capture cadence — a healthy feed's age stays comfortably under this
 *  except on a genuine capture failure or REST hang. */
export const BOOK_STALE_MS = 5000;

/** Base wide-spread threshold (¢). Mid of the spec's 3-5¢ suggested range. */
export const S_MAX_CENTS = 4;

/** Base thin-book threshold (contracts). Mid of the spec's 2-5 suggested range. */
export const D_MIN_CONTRACTS = 3;

/** Adverse order-book imbalance threshold. Mid of the spec's -0.25 to -0.40
 *  suggested range. Imbalance is (bidDepth-askDepth)/(bidDepth+askDepth) on
 *  the side being bought — negative means the ask side is heavier. */
export const IMB_ADVERSE = -0.30;

/** Optional adaptive bonus (Part A): on a high-volScale tick (violent tape),
 *  widen the spread tolerance and raise the depth floor slightly, since a
 *  fast tape naturally produces wider quoted spreads that aren't necessarily
 *  a liquidity problem. Reuses MarketState.volScale (P3's 0-1 volume-risk
 *  score) verbatim, per the spec's explicit field name — not a new signal. */
export const VOL_HIGH_THRESHOLD = 0.7;
export const S_MAX_HIGH_VOL_BONUS_CENTS = 2;
export const D_MIN_HIGH_VOL_BONUS_CONTRACTS = 1;

/** Rule 2 (spread) haircut ceiling for softer families (lag/anchor/mean_reversion). */
export const SPREAD_HAIRCUT_MAX_MULT = 0.5;
/** Rule 2: softer families still hard-SKIP once spread clears S_max_eff + this many extra cents. */
export const SPREAD_SKIP_EXTRA_CENTS = 2;

/** Rule 3 (depth) haircut for lag/anchor — mid of the spec's 0.5-0.7 range. */
export const DEPTH_HAIRCUT_LAGANCHOR_MULT = 0.6;
/** Rule 3 (depth) haircut for mean_reversion/confluence — reasoned extension, see file doc comment. */
export const DEPTH_HAIRCUT_SOFT_MULT = 0.5;

/** Rule 4 (imbalance) stacking haircut for every non-hard-skip family. */
export const IMBALANCE_HAIRCUT_MULT = 0.7;

/** Final stacked sizeMult never goes below this floor (never resurrects a protective 0, but also never fully zeroes a HAIRCUT — that's what SKIP is for). */
export const STACKED_SIZE_MULT_FLOOR = 0.25;

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

// ── Part A: BookSnap ─────────────────────────────────────────────────────────

export interface BookSnap {
  /** Ask - bid on the side being bought, in cents. Null when no usable top-of-book quote exists (see `noQuote`). */
  spreadCents: number | null;
  /** Visible size at the best price level on the side being bought. Null when depth is unavailable (degraded/stale — see `bookStale`), never a fabricated 0. */
  depthAtAsk: number | null;
  /** Sum of the top 2-3 levels on the ask side, when depth is available. */
  depthNearAsk?: number;
  /** (bidDepth-askDepth)/(bidDepth+askDepth) over the near-ask window. Null when depth is unavailable. Negative = ask-heavy = adverse for a buyer. */
  imbalance: number | null;
  /** Age of the L2 snapshot in ms. Null when no snapshot exists for the current ticker at all. */
  bookAgeMs: number | null;
  /** P4.1: true ONLY when a snapshot exists but is unusable for this decision — wrong ticker or age > BOOK_STALE_MS. This is a hard fail-closed SKIP for every family, no fallthrough. When NO snapshot has been captured for any ticker yet (genuinely absent, not corrupt), this stays false — that is the DEPTH_NULL degraded case (spread-only policy), not a stale book. Depth/imbalance are null whenever this is true. */
  bookStale: boolean;
  /** True when there's no usable top-of-book bid/ask for this side at all — distinct from bookStale (NO_BOOK vs a merely-stale/thin book). */
  noQuote: boolean;
}

/** Minimal shape of kalshi-ws.ts's `getLatestOrderbook()` return value — avoids importing the whole module into this pure file. */
export interface RawOrderbookSnapshot {
  ticker: string;
  yesBids: [number, number][]; // [priceCents, qty], best (highest) bid first
  yesAsks: [number, number][]; // [priceCents, qty], best (lowest) ask first
  ts: number;
}

const NEAR_ASK_LEVELS = 3;

/**
 * Builds a BookSnap for one side of one ticker. Pure — takes the live quote
 * and the already-captured L2 snapshot, does not fetch anything itself.
 * `yesBids`/`yesAsks` are always expressed in YES terms in the raw snapshot
 * (kalshi-ws.ts derives yesAsks by mirroring the NO side's bids); for a NO
 * evaluation, the ask/bid role of the two arrays swaps: NO's ask mirrors
 * YES's best bid depth, and NO's bid mirrors YES's best ask depth.
 */
export function buildBookSnap(params: {
  side: 'YES' | 'NO';
  currentTicker: string;
  quote: { yesBid?: number; yesAsk?: number; noBid?: number; noAsk?: number };
  latestOrderbook: RawOrderbookSnapshot | null;
  now?: number;
}): BookSnap {
  const { side, quote, latestOrderbook, currentTicker } = params;
  const now = params.now ?? Date.now();

  const bestBid = side === 'YES' ? quote.yesBid : quote.noBid;
  const bestAsk = side === 'YES' ? quote.yesAsk : quote.noAsk;
  const noQuote = bestBid === undefined || bestAsk === undefined || bestAsk <= 0 || bestBid < 0;
  const spreadCents = noQuote ? null : Math.max(0, bestAsk! - bestBid!);

  // P4.1: classify the L2 snapshot into STALE (hard skip) vs. genuinely
  // absent (degraded, spread-only — NOT stale). A snapshot that exists for
  // the WRONG ticker or has aged past BOOK_STALE_MS is "corrupt/unusable
  // for this decision" and stays a hard fail-closed SKIP. A snapshot that
  // simply hasn't been captured yet for ANY ticker (hasSnapshot=false) is
  // not corrupt — it's structurally not-yet-available, which the P4.1 spec
  // requires to degrade to a spread-only policy instead of a hard skip.
  const hasSnapshot = !!latestOrderbook;
  const tickerMatches = hasSnapshot && latestOrderbook!.ticker === currentTicker;
  const bookAgeMs = tickerMatches ? now - latestOrderbook!.ts : null;
  const wrongTicker = hasSnapshot && !tickerMatches;
  const tooOld = tickerMatches && bookAgeMs !== null && bookAgeMs > BOOK_STALE_MS;
  const bookStale = wrongTicker || tooOld;

  let depthAtAsk: number | null = null;
  let depthNearAsk: number | undefined;
  let imbalance: number | null = null;

  if (tickerMatches && !tooOld && latestOrderbook) {
    // YES ask levels are yesAsks; NO ask levels mirror yesBids (NO ask price = 100 - YES bid price, same underlying liquidity).
    const askLevels = side === 'YES' ? latestOrderbook.yesAsks : latestOrderbook.yesBids;
    const bidLevels = side === 'YES' ? latestOrderbook.yesBids : latestOrderbook.yesAsks;
    depthAtAsk = askLevels[0]?.[1] ?? 0;
    const askNear = askLevels.slice(0, NEAR_ASK_LEVELS).reduce((s, [, q]) => s + q, 0);
    const bidNear = bidLevels.slice(0, NEAR_ASK_LEVELS).reduce((s, [, q]) => s + q, 0);
    depthNearAsk = askNear;
    const totalNear = askNear + bidNear;
    imbalance = totalNear > 1e-9 ? (bidNear - askNear) / totalNear : 0;
  }

  return { spreadCents, depthAtAsk, depthNearAsk, imbalance, bookAgeMs, bookStale, noQuote };
}

// ── Part B: evaluateLiquidity ────────────────────────────────────────────────

export type LiquidityAction = 'ALLOW' | 'HAIRCUT' | 'SKIP';
export type LiquidityReason = 'OK' | 'BOOK_STALE' | 'BOOK_MISSING' | 'LIQ_SPREAD' | 'LIQ_THIN' | 'LIQ_IMBALANCE';

export interface LiquidityVerdict {
  action: LiquidityAction;
  /** Multiplicative size haircut in (0,1]. Only meaningful when action !== 'SKIP' — a SKIP means don't place the order at all, not "place it at sizeMult". */
  sizeMult: number;
  /** Raw spread charged against BASIS_LAG_EDGE's edge (Part C). 0 when spread never exceeded S_max_eff. Always the raw spread, independent of whether the action taken was HAIRCUT or SKIP. */
  spreadPenaltyCents: number;
  /** Primary machine-readable reason — the first rule that fired, or 'OK'. */
  reason: LiquidityReason;
  /** Every rule that fired, in evaluation order (rules can stack on a HAIRCUT). */
  reasons: string[];
  detail: string;
}

const SPREAD_HARD_SKIP_FAMILIES = new Set<Family>(['momentum', 'breakout', 'confluence']);
const DEPTH_IMBALANCE_HARD_SKIP_FAMILIES = new Set<Family>(['momentum', 'breakout']);

/**
 * Pure book-aware haircut/skip evaluator. Never touches EV/PATH_GATE/9%/
 * SEV1/size-0 — this is strictly a liquidity-quality layer applied to an
 * already-qualified candidate order.
 */
export function evaluateLiquidity(params: {
  family: Family;
  book: BookSnap;
  /** MarketState.volScale (0-1) — optional adaptive S_max/D_min bump on a violent tape. Omit to use the base constants unmodified. */
  volScale?: number;
}): LiquidityVerdict {
  const { family, book } = params;
  const volScale = params.volScale ?? 0;
  const volHigh = volScale >= VOL_HIGH_THRESHOLD;
  const sMaxEff = S_MAX_CENTS + (volHigh ? S_MAX_HIGH_VOL_BONUS_CENTS : 0);
  const dMinEff = D_MIN_CONTRACTS + (volHigh ? D_MIN_HIGH_VOL_BONUS_CONTRACTS : 0);

  // ── Rule 1: stale/missing book → fail-closed SKIP, unconditional on family.
  if (book.noQuote) {
    return {
      action: 'SKIP', sizeMult: 0, spreadPenaltyCents: 0, reason: 'BOOK_MISSING', reasons: ['BOOK_MISSING'],
      detail: 'no usable top-of-book quote for this side — never invent a spread',
    };
  }
  if (book.bookStale) {
    return {
      action: 'SKIP', sizeMult: 0, spreadPenaltyCents: 0, reason: 'BOOK_STALE', reasons: ['BOOK_STALE'],
      detail: `L2 book missing/stale (age=${book.bookAgeMs ?? 'n/a'}ms, threshold=${BOOK_STALE_MS}ms) — never invent depth`,
    };
  }

  const spread = book.spreadCents as number; // non-null: noQuote already handled above
  let sizeMult = 1;
  let spreadPenaltyCents = 0;
  const firedReasons: string[] = [];
  // P4.1: depth genuinely unavailable this tick (no L2 snapshot yet, but the
  // book is NOT stale — rule 1 already returned for that case). Tagged into
  // the log/detail so a "degraded, spread-only" decision is distinguishable
  // from a normal FULL-book decision, without becoming the primary `reason`
  // or gating anything on its own (rules 3/4 already no-op on null values).
  const degradedNoDepth = book.depthAtAsk === null;

  // ── Rule 2: wide spread.
  if (spread >= sMaxEff) {
    spreadPenaltyCents = spread;
    if (SPREAD_HARD_SKIP_FAMILIES.has(family)) {
      return {
        action: 'SKIP', sizeMult: 0, spreadPenaltyCents, reason: 'LIQ_SPREAD', reasons: ['LIQ_SPREAD'],
        detail: `spread ${spread}c >= ${sMaxEff}c hard-skip for family=${family}${degradedNoDepth ? ' [LIQ_DEGRADED_NO_DEPTH]' : ''}`,
      };
    }
    if (spread >= sMaxEff + SPREAD_SKIP_EXTRA_CENTS) {
      return {
        action: 'SKIP', sizeMult: 0, spreadPenaltyCents, reason: 'LIQ_SPREAD', reasons: ['LIQ_SPREAD'],
        detail: `spread ${spread}c >= ${sMaxEff + SPREAD_SKIP_EXTRA_CENTS}c — too wide even for family=${family}${degradedNoDepth ? ' [LIQ_DEGRADED_NO_DEPTH]' : ''}`,
      };
    }
    sizeMult = Math.min(sizeMult, SPREAD_HAIRCUT_MAX_MULT);
    firedReasons.push('LIQ_SPREAD');
  }

  // ── Rule 3: thin depth (only evaluated when depth is known — a
  // structurally- or momentarily-unavailable depth stays spread-only, never
  // a hard skip on its own here since rule 1 already fail-closed a truly
  // stale/missing book).
  if (book.depthAtAsk !== null && book.depthAtAsk < dMinEff) {
    if (DEPTH_IMBALANCE_HARD_SKIP_FAMILIES.has(family)) {
      return {
        action: 'SKIP', sizeMult: 0, spreadPenaltyCents, reason: 'LIQ_THIN', reasons: [...firedReasons, 'LIQ_THIN'],
        detail: `depthAtAsk=${book.depthAtAsk} < ${dMinEff} hard-skip for family=${family}`,
      };
    }
    const thinMult = family === 'lag' || family === 'anchor' ? DEPTH_HAIRCUT_LAGANCHOR_MULT : DEPTH_HAIRCUT_SOFT_MULT;
    sizeMult = Math.min(sizeMult, thinMult);
    firedReasons.push('LIQ_THIN');
  }

  // ── Rule 4: adverse imbalance.
  if (book.imbalance !== null && book.imbalance <= IMB_ADVERSE) {
    if (DEPTH_IMBALANCE_HARD_SKIP_FAMILIES.has(family)) {
      return {
        action: 'SKIP', sizeMult: 0, spreadPenaltyCents, reason: 'LIQ_IMBALANCE', reasons: [...firedReasons, 'LIQ_IMBALANCE'],
        detail: `imbalance=${book.imbalance.toFixed(2)} <= ${IMB_ADVERSE} hard-skip for family=${family}`,
      };
    }
    sizeMult = Math.max(STACKED_SIZE_MULT_FLOOR, sizeMult * IMBALANCE_HAIRCUT_MULT);
    firedReasons.push('LIQ_IMBALANCE');
  }

  sizeMult = clamp(sizeMult, STACKED_SIZE_MULT_FLOOR, 1);
  const action: LiquidityAction = sizeMult < 1 ? 'HAIRCUT' : 'ALLOW';
  // Log-only tag list: real rule reasons first (unchanged `reason` derivation
  // below), with the degraded-no-depth flag appended for visibility — it
  // never becomes the primary `reason` and never gates by itself.
  const loggedReasons = degradedNoDepth ? [...firedReasons, 'LIQ_DEGRADED_NO_DEPTH'] : firedReasons;
  const reason = (firedReasons[0] as LiquidityReason | undefined) ?? 'OK';
  const tagSuffix = degradedNoDepth ? ' [LIQ_DEGRADED_NO_DEPTH]' : '';
  const detail = firedReasons.length
    ? `sizeMult=${sizeMult.toFixed(2)} via [${firedReasons.join(',')}] spread=${spread}c depthAtAsk=${book.depthAtAsk ?? 'n/a'} imbalance=${book.imbalance !== null ? book.imbalance.toFixed(2) : 'n/a'}${tagSuffix}`
    : `ALLOW spread=${spread}c depthAtAsk=${book.depthAtAsk ?? 'n/a'} imbalance=${book.imbalance !== null ? book.imbalance.toFixed(2) : 'n/a'}${tagSuffix}`;

  return { action, sizeMult, spreadPenaltyCents, reason, reasons: loggedReasons, detail };
}

// ── Part C: lag net-edge adjustment (BASIS_LAG_EDGE only) ───────────────────

/**
 * `edgePts_net = edgePts - spreadPenaltyCents`, per spec Part C. Applies
 * strictly inside BASIS_LAG_EDGE's own evaluate() against its own minimum
 * edge threshold — never as a second global EV floor. PATH_GATE/
 * computeTradeEV still run on the real ask + fees, completely unchanged.
 */
export function computeLagNetEdgePts(edgePts: number, spreadPenaltyCents: number): number {
  return edgePts - spreadPenaltyCents;
}

// ── Part D: structured logging ───────────────────────────────────────────────

export interface LiquidityLogEntry {
  strategyId: string;
  family: Family;
  side: 'YES' | 'NO';
  spreadCents: number | null;
  depthAtAsk: number | null;
  imbalance: number | null;
  bookAgeMs: number | null;
  action: LiquidityAction;
  sizeMult: number;
  reason: LiquidityReason;
}

/** One structured log line per liquidity decision, per spec Part D. */
export function logLiquidityDecision(entry: LiquidityLogEntry): void {
  const { strategyId, family, side, spreadCents, depthAtAsk, imbalance, bookAgeMs, action, sizeMult, reason } = entry;
  logger.info(
    `[liquidity-policy] ${strategyId} family=${family} side=${side} spread=${spreadCents ?? 'n/a'}c ` +
    `depthAtAsk=${depthAtAsk ?? 'n/a'} imbalance=${imbalance !== null ? imbalance.toFixed(2) : 'n/a'} ` +
    `bookAge=${bookAgeMs ?? 'n/a'}ms → ${action}${action !== 'SKIP' ? ` sizeMult=${sizeMult.toFixed(2)}` : ''} reason=${reason}`,
  );
}
