/**
 * config-guard.ts
 *
 * Detects config that changed WITHOUT going through updateConfig().
 * autoMode true is Adapt (allowed) — false→true is NOT drift.
 * paperMode cannot silently go false: true→false (or unspecified→false)
 * IS drift and restore always pins paperMode true (until LIVE REAL MONEY).
 * Silent minConfidence jumps still restore. Floor-cutting composer is never
 * persisted: restore patches omit autoMode and never write lastAutoSettings.
 */
export interface ManualFloorSnapshot {
  autoMode: boolean;
  paperMode?: boolean;
  enabled?: boolean;
  minConfidence: number;
  minVelocity: number;
  // GO — ARIA MANUAL CEILING EXTENSION (2026-08-15): carried alongside
  // minConfidence/minVelocity so a CONFIG_DRIFT restore puts back the same
  // manual ceiling capToManualBoundary() enforces for these fields (see
  // tighten-only.ts). Intentionally NOT added to detectConfigDrift()'s own
  // drift checks below — the spec for this change is "extend the ceiling
  // fields carried by the restore snapshot", not "add new drift-alert
  // triggers" (no new alert spam).
  minEntryPrice: number;
  maxEntryPrice: number;
  minProbEdge: number;
}

export interface ConfigDriftResult {
  drifted: boolean;
  reasons: string[];
}

/** Restore patch: floors + paperMode. NEVER autoMode (Adapt may stay ON). */
export type ConfigGuardRestorePatch = {
  paperMode: true;
  enabled?: boolean;
  minConfidence: number;
  minVelocity: number;
  minEntryPrice: number;
  maxEntryPrice: number;
  minProbEdge: number;
};

/** minConfidence jumps of at least this many points without an intervening
 *  updateConfig() call are treated as drift, not normal operator tuning. */
export const MIN_CONFIDENCE_DRIFT_THRESHOLD = 5;

/** last-good paper lock: undefined counts as paper (fail-closed). */
export function isPaperLocked(last: ManualFloorSnapshot | null | undefined): boolean {
  return !last || last.paperMode !== false;
}

export function snapshotManualFloors(cfg: ManualFloorSnapshot): ManualFloorSnapshot {
  return {
    autoMode: cfg.autoMode,
    paperMode: cfg.paperMode,
    enabled: cfg.enabled,
    minConfidence: cfg.minConfidence,
    minVelocity: cfg.minVelocity,
    minEntryPrice: cfg.minEntryPrice,
    maxEntryPrice: cfg.maxEntryPrice,
    minProbEdge: cfg.minProbEdge,
  };
}

/**
 * Restore last known-good floors / paperMode. Omits autoMode so Adapt
 * true is not snapped false. paperMode ALWAYS restored true — drift
 * restore is never a LIVE REAL MONEY path (fail-closed).
 */
export function configGuardRestorePatch(last: ManualFloorSnapshot): ConfigGuardRestorePatch {
  const patch: ConfigGuardRestorePatch = {
    paperMode: true,
    minConfidence: last.minConfidence,
    minVelocity: last.minVelocity,
    minEntryPrice: last.minEntryPrice,
    maxEntryPrice: last.maxEntryPrice,
    minProbEdge: last.minProbEdge,
  };
  if (last.enabled !== undefined) patch.enabled = last.enabled;
  return patch;
}

/**
 * Detects config drift that did not go through updateConfig().
 *
 * Drift shapes:
 *  - paperMode silently flipping to false while last-good was paper/unspecified
 *  - enabled dropping true → false
 *  - minConfidence jumping up by MIN_CONFIDENCE_DRIFT_THRESHOLD or more
 *
 * autoMode false→true is Adapt ON — not drift.
 * autoMode true→false is operator turning Adapt off — not drift.
 */
export function detectConfigDrift(
  current: ManualFloorSnapshot,
  lastGoodManual: ManualFloorSnapshot | null,
): ConfigDriftResult {
  if (!lastGoodManual) return { drifted: false, reasons: [] };

  const reasons: string[] = [];

  // Fail-closed: paperMode false is ALWAYS drift here. Drift restore is never
  // a LIVE REAL MONEY path — updateConfig(+phrase) is the only live arm.
  if (current.paperMode === false) {
    const lastLabel =
      lastGoodManual.paperMode === false
        ? "false (still refuse silent live)"
        : lastGoodManual.paperMode === undefined
          ? "unspecified→paper"
          : "true";
    reasons.push(`paperMode flipped true→false (last known-good: ${lastLabel})`);
  }

  if (lastGoodManual.enabled && !current.enabled) {
    reasons.push(`enabled dropped true→false (last known-good: true)`);
  }

  const confidenceJump = current.minConfidence - lastGoodManual.minConfidence;
  if (confidenceJump >= MIN_CONFIDENCE_DRIFT_THRESHOLD) {
    reasons.push(
      `minConfidence jumped ${lastGoodManual.minConfidence}→${current.minConfidence} (+${confidenceJump}, ` +
      `threshold ${MIN_CONFIDENCE_DRIFT_THRESHOLD})`
    );
  }

  return { drifted: reasons.length > 0, reasons };
}
