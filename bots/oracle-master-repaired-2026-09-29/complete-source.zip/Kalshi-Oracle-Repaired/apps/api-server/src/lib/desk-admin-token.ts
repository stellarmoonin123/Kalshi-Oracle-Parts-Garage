/**
 * desk-admin-token.ts — OPT-IN admin token for state-changing API routes.
 *
 * Active ONLY when env DESK_ADMIN_TOKEN is set (non-empty). With it unset the
 * middleware is a no-op, so behaviour is exactly as before (the phone desk
 * stays open per Stellar 2026-09-11). When set, every non-GET/HEAD/OPTIONS
 * request under /api must carry header `X-Desk-Admin-Token: <token>`;
 * otherwise 401 { adminTokenRequired: true } (the dashboard prompts once and
 * stores the token in localStorage). /api/auth/* is exempt (login flow).
 * Token compared in constant time; never logged.
 */
import { timingSafeEqual, createHash } from "node:crypto";
import type { Request, Response, NextFunction } from "express";

export const ADMIN_TOKEN_HEADER = "x-desk-admin-token";
const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

export function configuredAdminToken(env: NodeJS.ProcessEnv = process.env): string | null {
  const t = (env.DESK_ADMIN_TOKEN ?? "").trim();
  return t.length > 0 ? t : null;
}

function digest(s: string): Buffer { return createHash("sha256").update(s, "utf8").digest(); }

export function tokenMatches(provided: string | undefined | null, expected: string): boolean {
  if (typeof provided !== "string" || provided.length === 0) return false;
  return timingSafeEqual(digest(provided), digest(expected));
}

export function isAdminExemptPath(path: string): boolean {
  return path === "/auth" || path.startsWith("/auth/");
}

export function requireDeskAdminToken(req: Request, res: Response, next: NextFunction): void {
  const expected = configuredAdminToken();
  if (!expected) { next(); return; }               // opt-in: unset = today's behaviour
  if (SAFE_METHODS.has(req.method.toUpperCase())) { next(); return; }
  if (isAdminExemptPath(req.path)) { next(); return; }
  const provided = req.get(ADMIN_TOKEN_HEADER);
  if (tokenMatches(provided, expected)) { next(); return; }
  res.status(401).json({
    error: "Admin token required for this action",
    adminTokenRequired: true,
    header: "X-Desk-Admin-Token",
  });
}
