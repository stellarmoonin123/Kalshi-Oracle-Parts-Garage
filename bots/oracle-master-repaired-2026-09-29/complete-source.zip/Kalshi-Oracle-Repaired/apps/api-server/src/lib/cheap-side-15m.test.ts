/**
 * cheap-side-15m.test.ts
 *
 * Focused unit tests for CHEAP_SIDE_15M evaluate() gates.
 * Run with: tsx --test src/lib/cheap-side-15m.test.ts
 */
import assert from "node:assert/strict";
import test from "node:test";
import { getStrategy, evaluateCheapSide15m, type StrategyObservation } from "./strategy-library.js";

const strategy = getStrategy("CHEAP_SIDE_15M");
if (!strategy) throw new Error("CHEAP_SIDE_15M strategy not found");

function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60,
    contractDurationMins: 15,
    projectedSettlementPrice: 65200, // +0.307% from floor -> fair YES
    basisStreakCount: 2,
    basisStreakSign: 1,
    yesAsk: 32,
    yesBid: 30,
    noAsk: 88,
    noBid: 86,
    cheapSide15mEnabled: true,
    ...overrides,
  };
}

test("fires YES when yesAsk is 32 and projection is clearly above floor with edge", () => {
  const result = strategy.evaluate(baseObs());
  assert.ok(result, "expected the strategy to fire YES");
  assert.equal(result!.signal, "YES");
  assert.equal(result!.strategyId, "CHEAP_SIDE_15M");
});

test("fires NO when noAsk is 28 and projection is clearly below floor", () => {
  const result = strategy.evaluate(baseObs({
    currentPrice: 64800,
    distFromFloorPct: -0.31,
    projectedSettlementPrice: 64800, // -0.307%
    basisStreakSign: -1,
    basisStreakCount: 2,
    yesAsk: 72,
    yesBid: 70,
    noAsk: 28,
    noBid: 26,
  }));
  assert.ok(result, "expected the strategy to fire NO");
  assert.equal(result!.signal, "NO");
  assert.equal(result!.strategyId, "CHEAP_SIDE_15M");
});

test("does not fire when cheap side is 12 but projection AGREES it should be cheap (book is right)", () => {
  const result = strategy.evaluate(baseObs({
    projectedSettlementPrice: 64800, // below floor — YES at 12c is correctly a long shot
    basisStreakSign: -1,
    yesAsk: 32,
    noAsk: 88,
  }));
  assert.equal(result, null, "book is right that YES is cheap — must not buy it");
});

test("does not fire at yesAsk 50 (above cheap max 47)", () => {
  const result = strategy.evaluate(baseObs({ yesAsk: 50, noAsk: 50 }));
  assert.equal(result, null);
});

test("does not fire at yesAsk 3 (lottery)", () => {
  const result = strategy.evaluate(baseObs({ yesAsk: 3, noAsk: 97 }));
  assert.equal(result, null);
});

test("does not fire with 1 minute left", () => {
  const result = strategy.evaluate(baseObs({ secsRemaining: 60 }));
  assert.equal(result, null);
});

test("does not fire when cheapSide15mEnabled is false", () => {
  const result = strategy.evaluate(baseObs({ cheapSide15mEnabled: false }));
  assert.equal(result, null);
});

test("does not fire when cheapSide15mEnabled is missing (fail closed)", () => {
  const result = strategy.evaluate(baseObs({ cheapSide15mEnabled: undefined }));
  assert.equal(result, null);
});

test("evaluateCheapSide15m is the implementation the library calls", () => {
  const viaLib = strategy.evaluate(baseObs());
  const viaMod = evaluateCheapSide15m(baseObs());
  assert.ok(viaLib);
  assert.ok(viaMod);
  assert.equal(viaLib!.signal, viaMod!.signal);
  assert.equal(viaLib!.strategyId, "CHEAP_SIDE_15M");
});

test("does not fire YES when mtfScore is -4 (settlement-side veto)", () => {
  const result = strategy.evaluate(baseObs({ mtfScore: -4 }));
  assert.equal(result, null);
});
