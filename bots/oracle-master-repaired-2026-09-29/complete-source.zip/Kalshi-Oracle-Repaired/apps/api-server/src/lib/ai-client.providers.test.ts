import { test } from "node:test";
import assert from "node:assert/strict";

process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY = "test-or";
process.env.AI_INTEGRATIONS_OPENROUTER_BASE_URL = "https://openrouter.test/api/v1";
process.env.GROQ_API_KEY = "test-groq";
process.env.GEMINI_API_KEY = "test-gemini";
delete process.env.XAI_API_KEY;

const ai = await import("./ai-client.js");
const mu = await import("./model-updater.js");

test("classifyProviderError: 402 credits, 404 no endpoints = dead, 503 transient", () => {
  assert.equal(ai.classifyProviderError(402, '{"error":{"message":"This request requires more credits, or fewer max_tokens"}}'), "credits_exhausted");
  assert.equal(ai.classifyProviderError(404, '{"error":{"message":"No endpoints found for anthropic/claude-haiku-4-5."}}'), "dead_model");
  assert.equal(ai.classifyProviderError(404, "models/gemini-2.5-flash is no longer available to new users"), "dead_model");
  assert.equal(ai.classifyProviderError(503, "high demand"), "transient");
  assert.equal(ai.classifyProviderError(429, ""), "rate_limited");
});

test("fallback chain includes Groq and Gemini direct legs after OpenRouter", () => {
  const chain = ai.buildFallbackChain();
  const labels = chain.map(p => ai.providerLabelFor(p.baseUrl));
  assert.ok(labels.includes("openrouter"));
  assert.ok(labels.includes("groq"));
  assert.ok(labels.includes("gemini"));
  assert.ok(labels.indexOf("groq") > labels.indexOf("openrouter"));
  assert.ok(chain.some(p => p.model === "openai/gpt-oss-20b"));
});

test("OpenRouter 402 blocks the provider and the call succeeds on Groq with a labelled provider", async () => {
  const calls: string[] = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = (async (url: string) => {
    calls.push(String(url));
    if (String(url).includes("openrouter.test")) {
      return new Response('{"error":{"message":"requires more credits"}}', { status: 402 });
    }
    if (String(url).includes("groq")) {
      return new Response(JSON.stringify({ choices: [{ message: { content: '{"ok":true}' }, finish_reason: "stop" }] }), { status: 200 });
    }
    return new Response("no", { status: 503 });
  }) as typeof fetch;
  try {
    const r = await ai.aiChat({ messages: [{ role: "user", content: "hi" }], maxTokens: 20, responseFormat: { type: "json_object" } } as any);
    assert.equal(r.provider, "groq");
    const orCalls = calls.filter(c => c.includes("openrouter.test")).length;
    assert.equal(orCalls, 1, "only one OpenRouter attempt before the provider-wide 402 block");
    assert.ok(ai.getProviderBlocks().openrouter, "openrouter blocked");
    // Next chain skips OpenRouter entirely
    assert.ok(!ai.buildFallbackChain().some(p => ai.providerLabelFor(p.baseUrl) === "openrouter"));
  } finally {
    globalThis.fetch = realFetch;
  }
});

test("when everything fails the error names the per-provider reasons", async () => {
  const realFetch = globalThis.fetch;
  globalThis.fetch = (async () => new Response("high demand", { status: 503 })) as typeof fetch;
  try {
    await assert.rejects(ai.aiChat({ messages: [{ role: "user", content: "hi" }], maxTokens: 5 } as any), /All AI providers failed \(\d+ tried\): .*503/);
  } finally { globalThis.fetch = realFetch; }
});

test("model-updater: dead Anthropic slugs out of SAFE_FALLBACK; listing filter; replace threshold 2", () => {
  assert.ok(!mu.SAFE_FALLBACK.some(m => m.startsWith("anthropic/")));
  assert.equal(mu.SAFE_FALLBACK[0], "openai/gpt-4o-mini");
  assert.deepEqual(mu.filterListedModels(["a", "b", "c"], new Set(["b", "c"])), ["b", "c"]);
  assert.equal(mu.shouldReplaceConfirmed(1), false);
  assert.equal(mu.shouldReplaceConfirmed(2), true);
});
