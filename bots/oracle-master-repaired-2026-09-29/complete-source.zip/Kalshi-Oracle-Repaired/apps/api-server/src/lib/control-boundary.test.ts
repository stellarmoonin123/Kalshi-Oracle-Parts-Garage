import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createManualExchangeWriteBoundary, parseBearerToken, publicLiveness } from './control-boundary.js';
import { resolveDeskFile, runChatCodeTool, GEMINI_CODE_EDIT_DECLARATIONS, CHAT_CODE_EDIT_TOOLS, scanProposedEdit, writeDeskFile, applyDeskPatch, runApiServerTests, scheduleDeskApiBounce } from './chat-code-edit.js';

test('Bearer parser agrees for mobile tokens and rejects raw/ambiguous schemes', () => {
  assert.equal(parseBearerToken('Bearer abc.def'), 'abc.def');
  assert.equal(parseBearerToken('bearer\tabc.def'), 'abc.def');
  for (const header of [undefined, '', 'abc.def', 'Basic abc.def', 'Bearer a b', 'Bearer\\sabc']) {
    assert.equal(parseBearerToken(header), undefined);
  }
});

for (const mode of [true, false, undefined, null, 'false']) {
  for (const method of ['POST', 'DELETE']) {
    test(`manual ${method} mode=${String(mode)} cannot reach exchange continuation`, () => {
      let nextCalls = 0;
      let code = 0;
      let payload: unknown;
      const handler = createManualExchangeWriteBoundary(() => mode);
      handler({ method }, { status(n) { code = n; return { json(v) { payload = v; } }; } }, () => { nextCalls++; });
      assert.equal(nextCalls, 0);
      assert.equal(code, mode === false ? 503 : 409);
      assert.equal((payload as { success: boolean }).success, false);
    });
  }
}

test('mode lookup exception denies writes; reads remain available', () => {
  let status = 0;
  let reads = 0;
  const handler = createManualExchangeWriteBoundary(() => { throw new Error('unknown'); });
  const res = { status(n: number) { status = n; return { json() {} }; } };
  handler({ method: 'POST' }, res, () => { throw new Error('write escaped'); });
  assert.equal(status, 409);
  handler({ method: 'GET' }, res, () => { reads++; });
  assert.equal(reads, 1);
});

test('public liveness has no financial, mode or credential telemetry', () => {
  assert.deepEqual(publicLiveness(), { status: 'ok' });
});

test('read-only tool declarations and dispatcher reject writes and processes', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-boundary-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  let spawned = 0;
  for (const name of ['write_file', 'apply_patch', 'run_tests']) {
    assert.equal(GEMINI_CODE_EDIT_DECLARATIONS.some(tool => tool.name === name), false);
    const result = runChatCodeTool(name, { path: 'src/a.test.ts', content: 'arbitrary executable code' }, {
      deskRoot: root, userMessage: 'LIVE REAL MONEY', spawn: () => { spawned++; throw new Error('must not run'); },
    });
    assert.equal(result.ok, false);
  }
  assert.equal(spawned, 0);
  assert.deepEqual(fs.readdirSync(root), []);
});

test('read inspection refuses external symlinks, secret aliases and filesystem root', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-symlink-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.writeFileSync(path.join(root, '.env'), 'TEST_FIXTURE=never_print');
  fs.symlinkSync(path.join(root, '.env'), path.join(root, 'notes.md'));
  fs.symlinkSync('/etc', path.join(root, 'outside'));
  assert.equal(resolveDeskFile('notes.md', root).ok, false);
  assert.equal(resolveDeskFile('outside/hosts', root).ok, false);
  assert.equal(resolveDeskFile('etc/hosts', '/').ok, false);
  assert.equal(runChatCodeTool('list_dir', { path: '.' }, { deskRoot: '/', userMessage: 'inspect' }).ok, false);
});

test('proposal lint rejects increases in risk maxima as well as prior floor changes', () => {
  for (const [name, before, after] of [['maxRiskPctPerTrade', '.09', '.20'], ['DAILY_HALT_PCT', '.10', '.50']]) {
    const result = scanProposedEdit({ relPath: 'src/risk.ts', before: `const ${name} = ${before}`, after: `const ${name} = ${after}`, userMessage: 'increase' });
    assert.equal(result.ok, false);
  }
});

test('search treats pathological regex text literally', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-search-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.writeFileSync(path.join(root, 'notes.md'), 'a'.repeat(10000) + '!');
  for (const pattern of ['(a+)+$', '(a|aa)+$', '([a-zA-Z]+)*$']) {
    const result = runChatCodeTool('grep', { path: '.', pattern }, { deskRoot: root, userMessage: 'search' });
    assert.equal(result.ok, true);
    if (result.ok) assert.deepEqual(result.matches, []);
  }
});

test('search still finds literal regex metacharacters and ignores case', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-search-literal-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.writeFileSync(path.join(root, 'notes.md'), 'Needle: (A+)+$\nInvalid regex text: [unclosed\n');
  const nested = runChatCodeTool('grep', { path: '.', pattern: '(a+)+$' }, { deskRoot: root, userMessage: 'search' });
  assert.equal(nested.ok, true);
  if (nested.ok) assert.deepEqual(nested.matches, ['notes.md:1:Needle: (A+)+$']);
  const unclosed = runChatCodeTool('grep', { path: '.', pattern: '[unclosed' }, { deskRoot: root, userMessage: 'search' });
  assert.equal(unclosed.ok, true);
  if (unclosed.ok) assert.deepEqual(unclosed.matches, ['notes.md:2:Invalid regex text: [unclosed']);
});


test('source tools cannot bypass the redacted configuration getter or read credential metadata', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-private-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.mkdirSync(path.join(root, 'apps/api-server'), { recursive: true });
  fs.mkdirSync(path.join(root, '.git'));
  fs.writeFileSync(path.join(root, '.git/config'), 'url=credential-bearing-fixture');
  fs.writeFileSync(path.join(root, '.npmrc'), 'fixture=secret');
  fs.writeFileSync(path.join(root, 'apps/api-server/.bot-config.json'), JSON.stringify({paperMode:true, apiKey:'fixture-secret', nested:{sessionToken:'secret'}}));
  for (const rel of ['.git/config', '.npmrc', 'apps/api-server/.bot-config.json']) {
    assert.equal(runChatCodeTool('read_file', {path:rel}, {deskRoot:root, userMessage:'inspect'}).ok, false);
    assert.equal(runChatCodeTool('grep', {path:rel, pattern:'secret'}, {deskRoot:root, userMessage:'inspect'}).ok, false);
  }
  const config = runChatCodeTool('get_bot_config', {}, {deskRoot:root, userMessage:'inspect'});
  assert.equal(config.ok, true);
  if (config.ok) assert.deepEqual(config.json, {paperMode:true, apiKey:'[redacted]', nested:{sessionToken:'[redacted]'}});
});

test('tape tail uses a bounded read and returns complete final lines', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-tail-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.mkdirSync(path.join(root, 'apps/api-server/data'), { recursive: true });
  const tape = path.join(root, 'apps/api-server/data/paper-bar-tape.jsonl');
  fs.writeFileSync(tape, 'x'.repeat(250000) + '\n{"id":1}\n{"id":2}\n');
  const result = runChatCodeTool('tail_tape', {n:2}, {deskRoot:root, userMessage:'inspect'});
  assert.equal(result.ok, true);
  if (result.ok) assert.deepEqual(result.lines, ['{"id":1}', '{"id":2}']);
  fs.writeFileSync(tape, 'x'.repeat(250000));
  const oversized = runChatCodeTool('tail_tape', {n:2}, {deskRoot:root, userMessage:'inspect'});
  assert.equal(oversized.ok, true);
  if (oversized.ok) assert.deepEqual(oversized.lines, []);
});

test('all mutation entrypoints deny before filesystem or process side effects', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-no-effects-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.writeFileSync(path.join(root, 'safe.ts'), 'original');
  const spawn = () => { throw new Error('process boundary escaped'); };
  for (const name of ['write_file', 'apply_patch', 'run_tests', 'bounce_api']) {
    assert.equal(GEMINI_CODE_EDIT_DECLARATIONS.some(tool => String(tool.name) === name), false);
    assert.equal(CHAT_CODE_EDIT_TOOLS.some(tool => String(tool) === name), false);
    assert.equal(runChatCodeTool(name, { path: 'safe.ts', content: 'overwrite' }, { deskRoot: root, userMessage: 'LIVE REAL MONEY', spawn }).ok, false);
  }
  assert.equal(writeDeskFile({relPath:'safe.ts', content:'overwrite', userMessage:'approved', deskRoot:root}).ok, false);
  assert.equal(applyDeskPatch({relPath:'safe.ts', oldString:'original', newString:'overwrite', userMessage:'approved', deskRoot:root}).ok, false);
  assert.equal(runApiServerTests({relPath:'safe.ts', deskRoot:root, spawn}).ok, false);
  assert.equal(scheduleDeskApiBounce({scriptPath:path.join(root, 'safe.ts'), spawn}).ok, false);
  assert.equal(fs.readFileSync(path.join(root, 'safe.ts'), 'utf8'), 'original');
  assert.deepEqual(fs.readdirSync(root), ['safe.ts']);
});

test('every inspection alias rejects unsafe roots, traversal and private metadata', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-private-aliases-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  for (const file of ['.npmrc', '.netrc', '.git/config', '.aws/credentials', 'nested/.env.local', 'nested/session-token.json']) {
    fs.mkdirSync(path.dirname(path.join(root,file)), {recursive:true});
    fs.writeFileSync(path.join(root,file), 'fixture-private');
    for (const name of ['read_file', 'grep', 'search', 'search_code', 'list_dir', 'list_files']) {
      assert.equal(runChatCodeTool(name, {path:file, pattern:'fixture-private'}, {deskRoot:root,userMessage:'inspect'}).ok, false, `${name}: ${file}`);
    }
  }
  for (const name of ['read_file', 'grep', 'search', 'search_code', 'list_dir', 'list_files']) {
    assert.equal(runChatCodeTool(name, {path:'.', pattern:'fixture'}, {deskRoot:'/',userMessage:'inspect'}).ok, false, name);
  }
  for (const file of ['/etc/hosts', '../outside', 'nested/../../outside', 'nested/..\\..\\outside']) {
    assert.equal(resolveDeskFile(file,root).ok,false,file);
  }
  const tree = runChatCodeTool('list_files',{path:'.',recursive:true},{deskRoot:root,userMessage:'inspect'});
  assert.equal(tree.ok,true);
  if (tree.ok) assert.deepEqual(tree.tree,['nested/']);
});

test('source and fixed telemetry getters reject symlink and hardlink aliases', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-link-aliases-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.mkdirSync(path.join(root,'apps/api-server/data'),{recursive:true});
  fs.writeFileSync(path.join(root,'.env'),'fixture-private');
  fs.symlinkSync(path.join(root,'.env'),path.join(root,'notes.md'));
  fs.linkSync(path.join(root,'.env'),path.join(root,'hardlink.md'));
  for(const alias of ['notes.md','hardlink.md']) {
    for(const name of ['read_file','grep','list_dir']) {
      assert.equal(runChatCodeTool(name,{path:alias,pattern:'fixture'},{deskRoot:root,userMessage:'inspect'}).ok,false);
    }
  }
  for(const [tool,rel] of [['get_bot_config','apps/api-server/.bot-config.json'],['get_paper_ledger','apps/api-server/data/paper-ledger.json'],['tail_tape','apps/api-server/data/paper-bar-tape.jsonl']]) {
    fs.symlinkSync(path.join(root,'.env'),path.join(root,rel));
    assert.equal(runChatCodeTool(tool,{}, {deskRoot:root,userMessage:'inspect'}).ok,false,tool);
  }
  const search = runChatCodeTool('grep',{path:'.',pattern:'fixture-private'},{deskRoot:root,userMessage:'inspect'});
  assert.equal(search.ok,true);
  if(search.ok) assert.deepEqual(search.matches,[]);
});

test('risk maximum removal, quoted JSON and computed replacements fail lint', () => {
  for(const name of ['maxRiskPctPerTrade','DAILY_HALT_PCT']) {
    for(const after of ['', `const ${name} = 1 / 2`, `const ${name} = Number('0.5')`, `{"${name}": 0.5}`]) {
      assert.equal(scanProposedEdit({relPath:'src/risk.ts',before:`const ${name} = .09`,after,userMessage:'LIVE REAL MONEY'}).ok,false);
    }
  }
  assert.equal(scanProposedEdit({relPath:'src/helper.ts',before:'const helper = 1;',after:'const helper = 2;',userMessage:'propose'}).ok,true);
});

test('directory replacement between inspection and open cannot redirect reads', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-race-root-'));
  const outside = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-race-outside-'));
  t.after(() => { fs.rmSync(root,{recursive:true,force:true}); fs.rmSync(outside,{recursive:true,force:true}); });
  fs.mkdirSync(path.join(root,'safe'));
  fs.writeFileSync(path.join(root,'safe/notes.md'),'public fixture');
  fs.writeFileSync(path.join(outside,'notes.md'),'private fixture');
  const originalOpen = fs.openSync;
  let replaced = false;
  t.mock.method(fs,'openSync', (...args: Parameters<typeof fs.openSync>) => {
    if (!replaced && args[0] === path.join(root,'safe/notes.md')) {
      replaced = true;
      fs.renameSync(path.join(root,'safe'),path.join(root,'original'));
      fs.symlinkSync(outside,path.join(root,'safe'));
    }
    return Reflect.apply(originalOpen,fs,args);
  });
  assert.equal(runChatCodeTool('read_file',{path:'safe/notes.md'},{deskRoot:root,userMessage:'inspect'}).ok,false);
  assert.equal(replaced,true);
});

test('parent replacement between parent and child lstat cannot authorize an external file', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-walk-race-root-'));
  const outside = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-walk-race-outside-'));
  t.after(() => { fs.rmSync(root,{recursive:true,force:true}); fs.rmSync(outside,{recursive:true,force:true}); });
  fs.mkdirSync(path.join(root,'safe'));
  fs.writeFileSync(path.join(root,'safe/notes.md'),'public fixture');
  fs.writeFileSync(path.join(outside,'notes.md'),'private fixture');
  const originalLstat = fs.lstatSync;
  let replaced = false;
  t.mock.method(fs,'lstatSync', (...args: Parameters<typeof fs.lstatSync>) => {
    const result = Reflect.apply(originalLstat,fs,args);
    if (!replaced && args[0] === path.join(root,'safe')) {
      replaced = true;
      fs.renameSync(path.join(root,'safe'),path.join(root,'original'));
      fs.symlinkSync(outside,path.join(root,'safe'));
    }
    return result;
  });
  assert.equal(runChatCodeTool('read_file',{path:'safe/notes.md'},{deskRoot:root,userMessage:'inspect'}).ok,false);
  assert.equal(replaced,true);
});

test('unavailable descriptor path verification denies without reading bytes', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-no-procfs-'));
  t.after(() => fs.rmSync(root,{recursive:true,force:true}));
  fs.writeFileSync(path.join(root,'notes.md'),'public fixture');
  const originalRealpath = fs.realpathSync;
  t.mock.method(fs,'realpathSync', (...args: Parameters<typeof fs.realpathSync>) => {
    if (String(args[0]).startsWith('/proc/self/fd/')) throw new Error('procfs unavailable');
    return Reflect.apply(originalRealpath,fs,args);
  });
  let reads = 0;
  t.mock.method(fs,'readSync', () => { reads++; throw new Error('must not read'); });
  assert.equal(runChatCodeTool('read_file',{path:'notes.md'},{deskRoot:root,userMessage:'inspect'}).ok,false);
  assert.equal(reads,0);
});

for (const [name,before,after] of [
  ['negative EV floor','const EV_FLOOR = 3;','const EV_FLOOR = -1;'],
  ['negative reserve floor','const cfg = {reservePct: 15};','const cfg = {reservePct: -1};'],
  ['bracket maximum override','const cfg = {maxRiskPctPerTrade: .09};','const cfg = {maxRiskPctPerTrade: .09};\nconfig["maxRiskPctPerTrade"] = .5;'],
  ['compound daily halt override','let DAILY_HALT_PCT = .10;','let DAILY_HALT_PCT = .10;\nDAILY_HALT_PCT *= 5;'],
  ['multiline risk expression','const maxRiskPctPerTrade =\n .09;','const maxRiskPctPerTrade =\n .50;'],
]) {
  test(`proposal lint refuses ${name}`, () => {
    assert.equal(scanProposedEdit({relPath:'src/risk.ts',before,after,userMessage:'LIVE REAL MONEY'}).ok,false);
  });
}

test('private-component policy applies to ancestors for direct and recursive reads', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-private-ancestors-'));
  t.after(() => fs.rmSync(root,{recursive:true,force:true}));
  for (const directory of ['credential-backups','nested/session-token-backup','private-key-archive']) {
    fs.mkdirSync(path.join(root,directory),{recursive:true});
    fs.writeFileSync(path.join(root,directory,'prod.json'),'"fixture-private"');
    for(const tool of ['read_file','grep','search','list_dir','list_files']) {
      assert.equal(runChatCodeTool(tool,{path:`${directory}/prod.json`,pattern:'fixture-private'},{deskRoot:root,userMessage:'inspect'}).ok,false,`${tool}: ${directory}`);
    }
  }
  const search = runChatCodeTool('grep',{path:'.',pattern:'fixture-private'},{deskRoot:root,userMessage:'inspect'});
  assert.equal(search.ok,true);
  if(search.ok) assert.deepEqual(search.matches,[]);
});

test('directory enumeration cannot expose external filenames during a temporary path swap', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-enumeration-race-root-'));
  const outside = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-enumeration-race-outside-'));
  t.after(() => { fs.rmSync(root,{recursive:true,force:true}); fs.rmSync(outside,{recursive:true,force:true}); });
  const safe = path.join(root,'safe');
  fs.mkdirSync(safe);
  fs.writeFileSync(path.join(safe,'allowed.md'),'public fixture');
  fs.writeFileSync(path.join(outside,'external-filename.md'),'private fixture');
  const originalReaddir = fs.readdirSync;
  let swapped = false;
  t.mock.method(fs,'readdirSync', (...args: Parameters<typeof fs.readdirSync>) => {
    if (!swapped && (String(args[0]) === safe || String(args[0]).startsWith('/proc/self/fd/'))) {
      swapped = true;
      fs.renameSync(safe,path.join(root,'original'));
      fs.symlinkSync(outside,safe);
      try { return Reflect.apply(originalReaddir,fs,args); }
      finally { fs.unlinkSync(safe); fs.renameSync(path.join(root,'original'),safe); }
    }
    return Reflect.apply(originalReaddir,fs,args);
  });
  const result = runChatCodeTool('list_dir',{path:'safe'},{deskRoot:root,userMessage:'inspect'});
  assert.equal(swapped,true);
  assert.equal(result.ok,true);
  if(result.ok) assert.deepEqual(result.tree,['allowed.md']);
});

test('all legacy sensitive basenames are denied as ancestor components', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-private-legacy-ancestors-'));
  t.after(() => fs.rmSync(root,{recursive:true,force:true}));
  for (const directory of ['id_rsa','id_ed25519','signing.pem','signing.key','nested/oraclekey','nested/ID_RSA','nested/signing.KEY']) {
    fs.mkdirSync(path.join(root,directory),{recursive:true});
    fs.writeFileSync(path.join(root,directory,'prod.json'),'"fixture-private"');
    for(const tool of ['read_file','grep','search','list_dir','list_files']) {
      assert.equal(runChatCodeTool(tool,{path:`${directory}/prod.json`,pattern:'fixture-private'},{deskRoot:root,userMessage:'inspect'}).ok,false,`${tool}: ${directory}`);
    }
  }
  const search = runChatCodeTool('grep',{path:'.',pattern:'fixture-private'},{deskRoot:root,userMessage:'inspect'});
  assert.equal(search.ok,true);
  if(search.ok) assert.deepEqual(search.matches,[]);
});

test('source byte ceiling fails closed and recursive search skips oversized content', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-source-limit-'));
  t.after(() => fs.rmSync(root, {recursive:true,force:true}));
  fs.writeFileSync(path.join(root,'huge.md'),'x'.repeat(1_048_577));
  for(const name of ['read_file','grep']) {
    assert.equal(runChatCodeTool(name,{path:'huge.md',pattern:'x'},{deskRoot:root,userMessage:'inspect'}).ok,false);
  }
  const search = runChatCodeTool('grep',{path:'.',pattern:'x'},{deskRoot:root,userMessage:'inspect'});
  assert.equal(search.ok,true);
  if(search.ok) assert.deepEqual(search.matches,[]);
});

test('tape tail never reads whole file and drops uncommitted final records', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-tail-byte-limit-'));
  t.after(() => fs.rmSync(root, {recursive:true,force:true}));
  fs.mkdirSync(path.join(root,'apps/api-server/data'),{recursive:true});
  const tape = path.join(root,'apps/api-server/data/paper-bar-tape.jsonl');
  fs.writeFileSync(tape,'x'.repeat(250000)+'\n{"id":1}\r\n{"id":2}\n{"unfinished":');
  const originalRead = fs.readSync;
  let totalBytes = 0;
  t.mock.method(fs,'readFileSync', () => { throw new Error('unbounded whole-file read'); });
  t.mock.method(fs,'readSync', (...args: Parameters<typeof fs.readSync>) => {
    const count = Reflect.apply(originalRead,fs,args);
    totalBytes += count;
    return count;
  });
  const result = runChatCodeTool('tail_tape',{n:Infinity},{deskRoot:root,userMessage:'inspect'});
  assert.equal(result.ok,true);
  if(result.ok) assert.deepEqual(result.lines,['{"id":1}','{"id":2}']);
  assert.ok(totalBytes > 0 && totalBytes <= 65_536);
});
