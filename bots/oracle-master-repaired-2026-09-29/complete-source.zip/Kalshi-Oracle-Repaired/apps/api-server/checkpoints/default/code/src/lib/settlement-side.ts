/**
 * settlement-side.ts
 *
 * Tiny pure module: pick at most one settlement SIDE (yes / no / skip).
 * This is the first-principle decision. Sizing, EV floors, Kelly, and
 * recordOutcome live elsewhere (admission / learner). This file never
 * calls them.
 *
 * pYes / pNo are winRateAtPrice. NEVER confidence. There is no confidence
 * field on this API — callers that only have a heuristic must pass null.
 * Coinbase→Kalshi lag (BasisState.lagStale / lagDollars) is a skip/veto
 * with the same shape as MTF. Lag never becomes pWin.
 *
 * LIVE_APPLY_ENABLED is not read. Not a live engine.
 */

import { lagAgreesWithSide } from "./lag-meter.js";
import { DESK_YES_ASK_MIN, DESK_YES_ASK_MAX } from "./paper-desk-v2.js";
import { HARVEST_ALLOWED_FAMILIES } from "./constants.js";
import { getStrategyFamily, type StrategyId } from "./strategy-library.js";

export type SettlementSide = "yes" | "no" | "skip";

/**
 * Same $16 floor as desk-library/metered-lag (shadow, LIVE_APPLY false).
 * NOT original to live +$31 BASIS_LAG_EDGE. Original evaluate had no Coinbase
 * |lag$| floor — it used proj-vs-floor + streak >=3 + 8pt edge + netEV>0.
 * Default stays $16 (fail-closed). Paper CONFLUENCE+LAG restore uses 0 via
 * paperMoneyMakerLagMinAbsDollars. Do not cut EV 3c / Kelly 0.60 / 9%.
 */
export const SETTLEMENT_SIDE_LAG_MIN_ABS_DOLLARS = 16;

/** Live +$50 engines. Only these may drop the $16 magnitude on paper. */
export const MONEY_MAKER_STRATEGY_IDS = ["CONFLUENCE_CASCADE", "BASIS_LAG_EDGE"] as const;

export function isMoneyMakerStrategyId(id: string | null | undefined): boolean {
  return id === "CONFLUENCE_CASCADE" || id === "BASIS_LAG_EDGE";
}

/** Goose/Stellar next-bar SIDE. Strong MTF SHORT → NO; LONG → YES. Not a filter skip. */
export const MTF_ALIGNED_CHEAP_MAX_CENTS = 55;

export function mtfStrongNextBarSide(mtfScore: number | null | undefined): "yes" | "no" | null {
  if (typeof mtfScore !== "number" || !Number.isFinite(mtfScore)) return null;
  // Same composite lock as evaluateEntry MTF_FILTER (minLong=0, maxShort=0).
  if (mtfScore < 0) return "no";
  if (mtfScore > 0) return "yes";
  return null;
}

/**
 * Kalshi 15m contract side: YES iff spot >= floor/strike.
 * Fail-closed if strike unknown. Not analog last-close-vs-next-close.
 */
export function kalshiStrikeContractSide(
  spot: number | null | undefined,
  floor: number | null | undefined,
): "yes" | "no" | null {
  if (typeof spot !== "number" || !Number.isFinite(spot) || !(spot > 0)) return null;
  if (typeof floor !== "number" || !Number.isFinite(floor) || !(floor > 0)) return null;
  return spot >= floor ? "yes" : "no";
}

/**
 * Time-aware |BRTI-path − strike| deadband ($). Settlement ground truth is the
 * ~60s BRTI mean in the final minute vs THIS window's strike — early path near
 * strike is coin-flip; widen early, tighten near expiry. Not a pWin. Not an
 * admission veto for CC/LAG (those keep remake-ignore). Call-quality / timing only.
 */
export const BRTI_PATH_FINAL_MINUTE_SECS = 60;
export const BRTI_PATH_LATE_CONFIRM_SECS = 180;

export function brtiPathDeadbandDollars(secsRemaining: number): number {
  if (!Number.isFinite(secsRemaining) || secsRemaining < 0) return 50;
  if (secsRemaining > 10 * 60) return 120; // early: do not lock hard side near strike
  if (secsRemaining > 6 * 60) return 80;
  if (secsRemaining > 3 * 60) return 50;
  if (secsRemaining > BRTI_PATH_FINAL_MINUTE_SECS) return 30;
  return 15; // final minute — 60s mean should clear strike
}

/**
 * Pick the BRTI-path price for the call. Final minute prefers mean60s (close TWAP
 * proxy). Else projected/fair path. Never invents a price.
 */
export function pickBrtiPathPrice(opts: {
  secsRemaining: number;
  /** Projected / fair BRTI path (basis+lag). */
  brtiPath?: number | null;
  /** Final-minute ~60s mean. Preferred when secsRemaining <= 60. */
  mean60s?: number | null;
}): number | null {
  const fin = (n: unknown): n is number =>
    typeof n === "number" && Number.isFinite(n) && n > 0;
  const inFinal = Number.isFinite(opts.secsRemaining)
    && opts.secsRemaining >= 0
    && opts.secsRemaining <= BRTI_PATH_FINAL_MINUTE_SECS;
  if (inFinal && fin(opts.mean60s)) return opts.mean60s;
  if (fin(opts.brtiPath)) return opts.brtiPath;
  if (fin(opts.mean60s)) return opts.mean60s;
  return null;
}

export interface BrtiPathSettlementInput {
  /** Projected / fair BRTI path vs strike. */
  brtiPath?: number | null;
  /** Final-minute 60s mean (preferred when secsRemaining <= 60). */
  mean60s?: number | null;
  strike: number | null | undefined;
  secsRemaining: number;
  /**
   * Late confirmation: when lag is proven and path distance clears the
   * (already-tight) late deadband, trust the call. Never flips side. Never pWin.
   * Omitted / false does not invent a call inside the deadband.
   */
  lagProven?: boolean;
}

export interface BrtiPathSettlementDecision {
  side: SettlementSide;
  reason: string;
  gapDollars: number | null;
  deadband: number;
  pathUsed: number | null;
}

/**
 * Plain settlement call from BRTI-path vs THIS window's strike.
 * YES if path clearly above, NO clearly below, SKIP when unclear / near strike.
 * Not Bullish/Bearish. Not Coinbase/HA wick as settle oracle.
 * Does not size, place, or rewrite decideSettlementSide admission.
 */
export function decideBrtiPathSettlementSide(
  input: BrtiPathSettlementInput,
): BrtiPathSettlementDecision {
  const deadband = brtiPathDeadbandDollars(input.secsRemaining);
  const pathUsed = pickBrtiPathPrice({
    secsRemaining: input.secsRemaining,
    brtiPath: input.brtiPath,
    mean60s: input.mean60s,
  });
  const strike = input.strike;
  if (pathUsed == null) {
    return { side: "skip", reason: "path_missing", gapDollars: null, deadband, pathUsed: null };
  }
  if (typeof strike !== "number" || !Number.isFinite(strike) || !(strike > 0)) {
    return { side: "skip", reason: "strike_missing", gapDollars: null, deadband, pathUsed };
  }
  const gap = pathUsed - strike;
  const abs = Math.abs(gap);
  const late = Number.isFinite(input.secsRemaining)
    && input.secsRemaining >= 0
    && input.secsRemaining <= BRTI_PATH_LATE_CONFIRM_SECS;
  const clear = abs >= deadband;
  // Late + lagProven: allow call at 70% of deadband (distance still required).
  const lateConfirm = late
    && input.lagProven === true
    && abs >= deadband * 0.7
    && abs > 0;
  if (!clear && !lateConfirm) {
    return {
      side: "skip",
      reason: late ? "path_near_strike" : "path_unclear_early",
      gapDollars: gap,
      deadband,
      pathUsed,
    };
  }
  if (gap >= 0) {
    return {
      side: "yes",
      reason: lateConfirm && !clear ? "yes_path_late_confirm" : "yes_path_clear",
      gapDollars: gap,
      deadband,
      pathUsed,
    };
  }
  return {
    side: "no",
    reason: lateConfirm && !clear ? "no_path_late_confirm" : "no_path_clear",
    gapDollars: gap,
    deadband,
    pathUsed,
  };
}


function askInCheapBand(
  ask: number | null | undefined,
  minAskCents: number,
  maxAskCents: number,
): ask is number {
  return typeof ask === "number" && Number.isFinite(ask)
    && ask >= minAskCents && ask <= maxAskCents;
}

/**
 * MTF-aligned cheap take (≤55). Opposed cheap still hits MTF_FILTER skip-return.
 * minAskCents is ENTRY (20 LAG / 28 CC) — do not loosen.
 * When spot/floorStrike passed: Kalshi strike maps the ticket, not analog
 * close-vs-close. Analog long + strike cheap NO → NO. MTF short construct NO stays.
 * Strike unknown (passed but invalid) fail-closed.
 */
export function isMtfAlignedCheapTake(opts: {
  mtfScore?: number | null;
  yesAsk?: number;
  noAsk?: number;
  minAskCents: number;
  maxAskCents?: number;
  spot?: number | null;
  floorStrike?: number | null;
}): { side: "yes" | "no"; ask: number } | null {
  const analog = mtfStrongNextBarSide(opts.mtfScore);
  if (!analog) return null;
  const max = opts.maxAskCents ?? MTF_ALIGNED_CHEAP_MAX_CENTS;
  const inBand = (ask: number | null | undefined): ask is number =>
    askInCheapBand(ask, opts.minAskCents, max);

  const strikePassed = opts.spot !== undefined || opts.floorStrike !== undefined;
  if (strikePassed) {
    const strike = kalshiStrikeContractSide(opts.spot, opts.floorStrike);
    if (!strike) return null;
    // Constructed aligned cheap NO when MTF short must stay.
    if (analog === "no") {
      if (inBand(opts.noAsk)) return { side: "no", ask: opts.noAsk };
      return null;
    }
    // MTF long: prefer aligned cheap YES in band (FLOOR_CROSS — spot wick below
    // floor is not an entry veto). Strike cheap NO only when YES not in band.
    if (inBand(opts.yesAsk)) return { side: "yes", ask: opts.yesAsk };
    if (strike === "no" && inBand(opts.noAsk)) return { side: "no", ask: opts.noAsk };
    return null;
  }

  const ask = analog === "yes" ? opts.yesAsk : opts.noAsk;
  if (!inBand(ask)) return null;
  return { side: analog, ask };
}

/** CC ENTRY 28 / LAG ENTRY 20. Null = aligned ask not in band (skip, do not take opposed). */
export function mtfAlignedCheapWantSignal(opts: {
  strategyId: string;
  mtfScore?: number | null;
  yesAsk?: number;
  noAsk?: number;
  spot?: number | null;
  floorStrike?: number | null;
}): "YES" | "NO" | null {
  if (!isMoneyMakerStrategyId(opts.strategyId)) return null;
  const take = isMtfAlignedCheapTake({
    mtfScore: opts.mtfScore,
    yesAsk: opts.yesAsk,
    noAsk: opts.noAsk,
    minAskCents: opts.strategyId === "BASIS_LAG_EDGE" ? 20 : 28,
    spot: opts.spot,
    floorStrike: opts.floorStrike,
  });
  if (!take) return null;
  return take.side === "yes" ? "YES" : "NO";
}

/**
 * Leftover 1¢ YES poison: leftover YES at 1¢ must not feed pYes / MIXED / yesR.
 * CC/LAG/HA_RIVER are never poison. Do not ENABLE leftovers.
 */
export function leftoverYesAskIsPoison(strategyId: string | null | undefined, yesAsk: number | null | undefined): boolean {
  if (!strategyId) return false;
  if (strategyId === "CONFLUENCE_CASCADE" || strategyId === "BASIS_LAG_EDGE" || strategyId === "HA_RIVER") return false;
  return typeof yesAsk === "number" && Number.isFinite(yesAsk) && yesAsk <= 1;
}

/**
 * Keep CC/LAG rows that match MTF-aligned cheap (ENTRY 28 CC / 10 LAG).
 * 37¢ YES / 8¢ NO with MTF short: no aligned cheap → KEEP opposed CC for MTF_FILTER
 * (not NO_ELIGIBLE); LAG stays locked (drop). Other ids unchanged. Do not cut ENTRY.
 *
 * When an aligned cheap wing EXISTS but the pool only holds the opposed CC
 * or opposed LAG row (e.g. LONG book YES@66 / NO@35 with strike-NO take wanting
 * NO, while evaluate still emitted YES), KEEP that sole opposed money-maker so
 * direction-lock can remap / MTF_FILTER skip-return — never empty the money
 * pool into a false NO_ELIGIBLE_STRATEGY / SELECT_MISS on LAG-only fire.
 */
export function filterPoolToMtfAlignedCheap<T extends { strategyId: string; signal: string }>(
  pool: T[],
  opts: {
    mtfScore?: number | null;
    yesAsk?: number;
    noAsk?: number;
    spot?: number | null;
    floorStrike?: number | null;
  },
): T[] {
  if (!mtfStrongNextBarSide(opts.mtfScore)) return pool;
  const ccTake = isMtfAlignedCheapTake({ ...opts, minAskCents: 28 });
  const lagTake = isMtfAlignedCheapTake({ ...opts, minAskCents: 20 });
  const ccWant = ccTake ? (ccTake.side === "yes" ? "YES" : "NO") : null;
  const lagWant = lagTake ? (lagTake.side === "yes" ? "YES" : "NO") : null;
  const hasAlignedCc = ccWant != null
    && pool.some(r => r.strategyId === "CONFLUENCE_CASCADE" && r.signal === ccWant);
  const hasAlignedLag = lagWant != null
    && pool.some(r => r.strategyId === "BASIS_LAG_EDGE" && r.signal === lagWant);
  return pool.filter(r => {
    if (r.strategyId === "CONFLUENCE_CASCADE") {
      // No aligned cheap in band: KEEP opposed CC so MTF_FILTER skip-returns
      // (do not invent NO_ELIGIBLE when evaluate() already fired).
      if (!ccWant) return true;
      if (r.signal === ccWant) return true;
      // Sole opposed CC: KEEP for remap / MTF_FILTER (not false NO_ELIGIBLE).
      // Drop opposed only when an aligned CC row is already present.
      return !hasAlignedCc;
    }
    if (r.strategyId === "BASIS_LAG_EDGE") {
      // LAG stays locked when no aligned cheap (do not keep opposed LAG).
      if (!lagWant) return false;
      if (r.signal === lagWant) return true;
      // Sole opposed LAG: KEEP for remap (mirror CC) — LAG-only evaluate fire
      // must not empty the money pool before overlayAlignedTake.
      return !hasAlignedLag;
    }
    return true;
  });
}

/** PATH_RIDE Kelly remake-ignore book. CC/LAG + HA_RIVER (Goose P0) only.
 * HA_FLIP / TICKET_WAVE / NO_CROSS do not inherit remake-ignore. Not ENABLE. */
export const PATH_RIDE_KELLY_STRATEGY_IDS = [
  "CONFLUENCE_CASCADE",
  "BASIS_LAG_EDGE",
  "HA_RIVER",
] as const;

export function isPathRideKellyStrategyId(id: string | null | undefined): boolean {
  return id === "CONFLUENCE_CASCADE" || id === "BASIS_LAG_EDGE" || id === "HA_RIVER";
}

/**
 * Paper≡live lag floor (2026-09-11 parity kill): LIVE doctrine $16 for BOTH.
 * paperMode arg retained for call-site stability; never grants paper a $0 cheat.
 * Under FROZEN_CC metered lag is disabled anyway — same value stops paper≠live.
 */
export function paperMoneyMakerLagMinAbsDollars(
  paperMode: boolean | undefined,
  strategyId?: string | null,
): number {
  void paperMode;
  void strategyId;
  return SETTLEMENT_SIDE_LAG_MIN_ABS_DOLLARS;
}

/**
 * Paper≡live HARVEST (2026-09-11 parity kill): no paper-only LAG exempt.
 * Both modes use HARVEST_ALLOWED_FAMILIES only via isHarvestSessionFamilyAllowed.
 * Args retained for call-site stability.
 */
export function paperMoneyMakerHarvestExempt(
  paperMode: boolean | undefined,
  strategyId: string | null | undefined,
): boolean {
  void paperMode;
  void strategyId;
  return false;
}

/**
 * HARVEST session family allow — single organ for 15m + 1h (was duplicated
 * inline in trading-bot evaluateEntry / _evaluateHourlyTickBody).
 * paperMoneyMakerHarvestExempt is always false (paper≡live); family set only.
 */
export function isHarvestSessionFamilyAllowed(
  paperMode: boolean | undefined,
  strategyId: string,
): boolean {
  if (paperMoneyMakerHarvestExempt(paperMode, strategyId)) return true;
  const fam = getStrategyFamily(strategyId as StrategyId);
  return fam != null && HARVEST_ALLOWED_FAMILIES.has(fam);
}

/**
 * Remake skip ignore for CONFLUENCE + LAG.
 * Original +$50 was evaluate → PATH/EV/Kelly. Money-makers must not be
 * emptied by remake starve: SETTLEMENT_SIDE lag_stale / $16 / mtf_veto /
 * both_sides (paper PATH_RIDE), and evaluateEntry HTF_STRUCTURE (Aug 28
 * linreg — same starve class as mtf_veto). HTF_STRUCTURE is paper=live
 * CC/LAG. quote_stale uses SETTLEMENT_SIDE_QUOTE_STALE_MS (60s) — still blocks when over floor. Do not cut EV 3c.
 */
export function paperMoneyMakerIgnoresSettlementSideSkip(
  paperMode: boolean | undefined,
  strategyId: string | null | undefined,
  reason: string,
): boolean {
  return paperPathRidePreservesThroughSettlementSkip(paperMode, [strategyId], reason);
}

/**
 * Paper≡live CC/LAG/HA_RIVER PATH_RIDE: ignore remake SETTLEMENT_SIDE (lag_stale,
 * both_sides, mtf_veto, $16) when ANY fired id is PATH_RIDE Kelly (CC/LAG/HA_RIVER).
 * HA_FLIP/TICKET_WAVE/NO_CROSS do not inherit. HTF_STRUCTURE paper=live CC/LAG only.
 * quote_stale / p_null KEEP. lag_disagrees demoted (book-lead). quote_stale still blocks.
 * Do not cut EV 3c. Remake ignore is NOT paper-only (2026-09-11 parity kill).
 */
/** Remake overlay starve. PATH_RIDE ignore paper≡live; HTF_STRUCTURE CC/LAG. */
export const REMAKE_SETTLEMENT_SIDE_REASONS = [
  "lag_stale",
  "both_sides_look_good",
  "mtf_veto_yes",
  "mtf_veto_no",
  "lag_dollars_too_small",
  "HTF_STRUCTURE",
  "lag_disagrees",
] as const;

/** BSM OVERPAY money-cell bypass for CC/LAG. Inclusive desk door 20–55.
 * Cheap-to-mid restores (+$50 path). Expensive/favorite outside door KEEP OVERPAY.
 * Still-mid 48–52 is a separate SIT (not this gate). */
export const MONEY_CELL_OVERPAY_ASK_MIN_CENTS = DESK_YES_ASK_MIN;
export const MONEY_CELL_OVERPAY_ASK_MAX_CENTS = DESK_YES_ASK_MAX;

export function moneyMakerIgnoresOverpayGate(
  strategyId: string | null | undefined,
  entryPriceCents: number,
): boolean {
  if (!isMoneyMakerStrategyId(strategyId)) return false;
  if (!Number.isFinite(entryPriceCents)) return false;
  return entryPriceCents >= MONEY_CELL_OVERPAY_ASK_MIN_CENTS
    && entryPriceCents <= MONEY_CELL_OVERPAY_ASK_MAX_CENTS;
}

/** Original side-accuracy locks. KEEP — do not unstarve. quote_stale uses 60s quiet-book floor (aligned with FEED_STALE_QUOTE_MS). */
export const ORIGINAL_SETTLEMENT_SIDE_LOCK_REASONS = [
  "quote_stale",
  "p_null_or_invalid",
] as const;

export function isRemakeSettlementSideSkip(reason: string): boolean {
  return (REMAKE_SETTLEMENT_SIDE_REASONS as readonly string[]).includes(reason);
}

export function isOriginalSettlementSideLock(reason: string): boolean {
  return (ORIGINAL_SETTLEMENT_SIDE_LOCK_REASONS as readonly string[]).includes(reason);
}

export function paperPathRidePreservesThroughSettlementSkip(
  paperMode: boolean | undefined,
  strategyIds: readonly (string | null | undefined)[],
  reason: string,
): boolean {
  void paperMode; // paper≡live — remake ignore is not paper-only (2026-09-11)
  if (reason === "quote_stale") return false;
  // Original side-accuracy lock KEEP. Do not blindly unstarve all SETTLEMENT_SIDE.
  if (!isRemakeSettlementSideSkip(reason)) return false;
  const money = strategyIds.some(id => isMoneyMakerStrategyId(id));
  // paper=live CC/LAG: HTF_STRUCTURE skip-return must not fire (evaluateEntry).
  if (reason === "HTF_STRUCTURE") return money;
  return money || strategyIds.some(id => isPathRideKellyStrategyId(id));
}

/** CC 28–55 / LAG 20–55 (desk door). Census cheap money cell. No sub-20 LAG lottery. */
export function isCheapMoneyCellAsk(strategyId: string | null | undefined, askCents: number): boolean {
  if (!Number.isFinite(askCents)) return false;
  if (strategyId === "CONFLUENCE_CASCADE") return askCents >= 28 && askCents <= MTF_ALIGNED_CHEAP_MAX_CENTS;
  if (strategyId === "BASIS_LAG_EDGE") return askCents >= 20 && askCents <= MTF_ALIGNED_CHEAP_MAX_CENTS;
  return false;
}

/**
 * Census: SETTLEMENT_SIDE on paper CC/LAG EV≥3 cheap cell is a remake leak
 * iff ignoreLater should fire (lag_stale / mtf_veto / both_sides / HTF) but does not.
 * quote_stale / lag_disagrees / p_null KEEP — not leaks. MTF_FILTER KEEP original.
 */
export function settlementSideSkipIsRemakeLeak(opts: {
  paperMode: boolean | undefined;
  strategyId?: string | null;
  strategyIds?: readonly (string | null | undefined)[];
  reason: string;
  evCents: number | null | undefined;
  askCents: number;
}): boolean {
  const ids = [opts.strategyId, ...(opts.strategyIds ?? [])];
  const moneyId = ids.find(id => isMoneyMakerStrategyId(id)) ?? opts.strategyId;
  if (!isCheapMoneyCellAsk(moneyId, opts.askCents)) return false;
  if (typeof opts.evCents !== "number" || !Number.isFinite(opts.evCents) || opts.evCents < 3) return false;
  if (isOriginalSettlementSideLock(opts.reason)) return false;
  if (opts.reason === "MTF_FILTER") return false;
  if (!isRemakeSettlementSideSkip(opts.reason)) return false;
  return !paperPathRidePreservesThroughSettlementSkip(opts.paperMode, ids, opts.reason);
}

/** Leftover pack. STRATEGY_REGIME_BLOCK on these must not empty CC/LAG money cells. */
export const LEFTOVER_PACK_STRATEGY_IDS = [
  "TICKET_WAVE",
  "NO_CROSS",
  "LATE_ENTRY_ANCHOR",
  "HA_FLIP",
] as const;

export function leftoverPackRegimeBlockWouldSkipMoneyCell(
  blockedStrategyId: string | null | undefined,
  moneyMakerFired: boolean,
): boolean {
  if (!moneyMakerFired) return false;
  return (LEFTOVER_PACK_STRATEGY_IDS as readonly string[]).includes(blockedStrategyId ?? "");
}

/** KEEP: leftover STRATEGY_REGIME_BLOCK does not empty a fired CC/LAG money cell. */
export function leftoverRegimeBlockPlacesMoneyMaker(
  blockedStrategyId: string | null | undefined,
  moneyMakerFired: boolean,
): boolean;
export function leftoverRegimeBlockPlacesMoneyMaker(opts: {
  strategyId: string | null | undefined;
  paperMode?: boolean;
  evCents?: number | null;
  askCents?: number;
}): boolean;
export function leftoverRegimeBlockPlacesMoneyMaker(
  blockedStrategyIdOrOpts: string | null | undefined | {
    strategyId: string | null | undefined;
    paperMode?: boolean;
    evCents?: number | null;
    askCents?: number;
  },
  moneyMakerFired?: boolean,
): boolean {
  if (blockedStrategyIdOrOpts !== null && typeof blockedStrategyIdOrOpts === "object") {
    const opts = blockedStrategyIdOrOpts;
    // paper≡live — same law both modes (2026-09-11 R3 money); paperMode retained for call-site stability
    void opts.paperMode;
    if (!isMoneyMakerStrategyId(opts.strategyId)) return false;
    if (typeof opts.evCents !== "number" || !Number.isFinite(opts.evCents) || opts.evCents < 3) return false;
    if (typeof opts.askCents !== "number" || !Number.isFinite(opts.askCents)) return false;
    if (opts.askCents < 28 || opts.askCents > 55) return false;
    return true;
  }
  return leftoverPackRegimeBlockWouldSkipMoneyCell(blockedStrategyIdOrOpts, moneyMakerFired === true);
}

/** Same 60s bar as FEED_STALE_QUOTE_MS / MAX_QUOTE_AGE_MS (quiet-book floor; not 15s). */
export const SETTLEMENT_SIDE_QUOTE_STALE_MS = 60_000;

export interface SettlementSideInput {
  /** winRateAtPrice for YES. Never confidence. null = this side is not a candidate. */
  pYes: number | null;
  /** winRateAtPrice for NO. Never confidence. null = this side is not a candidate. */
  pNo: number | null;
  /** MTF score, typically -4..+4. <= -3 vetoes YES; >= +3 vetoes NO. */
  mtf: number;
  /**
   * BasisState.lagStale. Omit = no lag gate (p/mtf unit tests).
   * Live callers always pass it. true → skip lag_stale (blind).
   * false → apply dollar-agree / too-small vetoes on the chosen side.
   */
  lagStale?: boolean;
  /**
   * BasisState.lagDollars — Coinbase $ move over metered tau.
   * NOT 1s proj-vs-floor flicker (that's projAgreesWithSide).
   */
  lagDollars?: number | null;
  /** Optional quote age. >60s or non-finite → skip quote_stale. */
  quoteAgeMs?: number | null;
  /**
   * Override |lag$| floor. Default $16. Paper money-maker restore passes 0
   * (sign-only). Never a pWin. Never a disagree exemption.
   */
  lagMinAbsDollars?: number;
}

export interface SettlementSideDecision {
  side: SettlementSide;
  /** winRateAtPrice of the chosen side; null on skip. Never confidence. Never lag. */
  pWin: number | null;
  reason: string;
}

function isValidP(p: number | null): p is number {
  return typeof p === "number" && Number.isFinite(p) && p > 0 && p <= 1;
}

function skip(reason: string): SettlementSideDecision {
  return { side: "skip", pWin: null, reason };
}

export type LiveLagSkipReason = "lag_disagrees" | "lag_dollars_too_small";

/**
 * Shared Coinbase→Kalshi live-lag veto for a chosen side.
 * Callers that already know lagStale===false use this instead of copying $16.
 * Disagree and too-small are skips, never a flip, never pWin.
 */
export function liveLagSkipReason(
  side: "yes" | "no",
  lagDollars: number | null | undefined,
  minAbsDollars: number = SETTLEMENT_SIDE_LAG_MIN_ABS_DOLLARS,
): LiveLagSkipReason | null {
  if (!lagAgreesWithSide(side, lagDollars ?? null)) {
    return "lag_disagrees";
  }
  const floor = Number.isFinite(minAbsDollars) ? Math.max(0, minAbsDollars) : SETTLEMENT_SIDE_LAG_MIN_ABS_DOLLARS;
  const d = lagDollars;
  if (d == null || !Number.isFinite(d) || Math.abs(d) < floor) {
    return "lag_dollars_too_small";
  }
  return null;
}

function lagVeto(
  side: "yes" | "no",
  pWin: number,
  lagDollars: number | null | undefined,
  minAbsDollars: number,
): SettlementSideDecision {
  const veto = liveLagSkipReason(side, lagDollars, minAbsDollars);
  if (veto) return skip(veto);
  return { side, pWin, reason: side === "yes" ? "yes_pwin" : "no_pwin" };
}

/**
 * Pick at most one settlement side. If both pYes and pNo are valid, skip
 * (never both sides of the same bar). Invalid/null p → skip. Strong MTF
 * against a side vetoes it (cheap YES with MTF -4 settled NO).
 *
 * Lag (when lagStale is passed) is the same shape as MTF: a veto, not p.
 * Blind (stale / bad quote) → skip. Material Coinbase move against the
 * chosen side → skip. Never flip. Never boost pWin.
 */
export function decideSettlementSide(input: SettlementSideInput): SettlementSideDecision {
  if (input.quoteAgeMs != null) {
    if (!Number.isFinite(input.quoteAgeMs) || input.quoteAgeMs > SETTLEMENT_SIDE_QUOTE_STALE_MS) {
      return skip("quote_stale");
    }
  }
  if (input.lagStale === true) {
    return skip("lag_stale");
  }

  const pYesOk = isValidP(input.pYes);
  const pNoOk = isValidP(input.pNo);
  const mtf = Number.isFinite(input.mtf) ? input.mtf : 0;
  const applyLag = input.lagStale === false;
  const minAbs = typeof input.lagMinAbsDollars === "number" && Number.isFinite(input.lagMinAbsDollars)
    ? Math.max(0, input.lagMinAbsDollars)
    : SETTLEMENT_SIDE_LAG_MIN_ABS_DOLLARS;

  if (pYesOk && pNoOk) {
    return skip("both_sides_look_good");
  }
  if (!pYesOk && !pNoOk) {
    return skip("p_null_or_invalid");
  }

  if (isValidP(input.pYes)) {
    if (mtf <= -3) return skip("mtf_veto_yes");
    if (applyLag) return lagVeto("yes", input.pYes, input.lagDollars, minAbs);
    return { side: "yes", pWin: input.pYes, reason: "yes_pwin" };
  }

  if (!isValidP(input.pNo)) return skip("p_null_or_invalid");
  if (mtf >= 3) return skip("mtf_veto_no");
  if (applyLag) return lagVeto("no", input.pNo, input.lagDollars, minAbs);
  return { side: "no", pWin: input.pNo, reason: "no_pwin" };
}

export interface SettlementSideLog {
  event: "settlement_side";
  side: SettlementSide;
  /** winRateAtPrice of the chosen side; null on skip. Never confidence. Never lag. */
  pWin: number | null;
  reason: string;
  /** Heuristic only. Never copied into pWin. */
  signalConfidence: number | null;
  /** Meter reading. Observability only — never pWin. */
  lagStale: boolean | null;
  /** Meter reading. Observability only — never pWin. */
  lagDollars: number | null;
}

export type SettlementSideLogExtra = {
  signalConfidence?: number | null;
  lagStale?: boolean;
  lagDollars?: number | null;
};

/**
 * Named log fields for a side decision. pWin is winRateAtPrice.
 * signalConfidence is a separate heuristic — a 0.99 conf cannot become pWin.
 * lagStale / lagDollars are meter readings — they cannot become pWin.
 * Callers that have no heuristic omit it (stays null).
 */
export function namedSettlementSideLog(
  decision: SettlementSideDecision,
  extra?: SettlementSideLogExtra,
): SettlementSideLog {
  const conf = extra?.signalConfidence;
  const lagStale = extra?.lagStale;
  const lagDollars = extra?.lagDollars;
  return {
    event: "settlement_side",
    side: decision.side,
    pWin: decision.pWin,
    reason: decision.reason,
    signalConfidence: typeof conf === "number" && Number.isFinite(conf) ? conf : null,
    lagStale: typeof lagStale === "boolean" ? lagStale : null,
    lagDollars: typeof lagDollars === "number" && Number.isFinite(lagDollars) ? lagDollars : null,
  };
}

/**
 * Thin caller helper: decideSettlementSide + named log fields.
 * Does not size, does not place, does not rewrite evaluate, does not
 * call recordOutcome / PATH_GATE / Kelly.
 */
export function decideSettlementSideLogged(
  input: SettlementSideInput,
  extra?: { signalConfidence?: number | null },
): { decision: SettlementSideDecision; log: SettlementSideLog } {
  const decision = decideSettlementSide(input);
  return {
    decision,
    log: namedSettlementSideLog(decision, {
      signalConfidence: extra?.signalConfidence,
      lagStale: input.lagStale,
      lagDollars: input.lagDollars,
    }),
  };
}
