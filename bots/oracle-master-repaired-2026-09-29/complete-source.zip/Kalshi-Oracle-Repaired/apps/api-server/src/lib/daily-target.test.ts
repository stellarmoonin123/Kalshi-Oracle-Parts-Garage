import test from "node:test";
import assert from "node:assert/strict";
import { computeTargetEngine, dailyTargetEntryBlock, persistLatchDurably, computeCashFlowReconciliation, etDateKey } from "./daily-target.js";

const base = {
  startEquityCents: 10_000,        // $100 base
  targetPct:        50,            // target = $150
  protectBehavior:  "stand_down" as const,
  giveBackCapPct:   10,
  riskProfile:      "BALANCED" as const,
};

test("target not hit: progress and target equity computed from start", () => {
  const r = computeTargetEngine({ ...base, currentEquityCents: 12_500, peakEquityCents: 12_500, targetHitToday: false });
  assert.equal(r.targetEquityCents, 15_000);
  assert.equal(r.progressPct, 50);
  assert.equal(r.protectActive, false);
  assert.equal(r.blockReason, null);
});

test("target hit + stand_down: blocks entries with sizeMult 0", () => {
  const r = computeTargetEngine({ ...base, currentEquityCents: 15_100, peakEquityCents: 15_100, targetHitToday: false });
  assert.equal(r.targetHitToday, true);
  assert.equal(r.paceState, "PROTECTED");
  assert.equal(r.sizeMult, 0);
  assert.ok(r.blockReason);
});

test("targetHitToday latch persists even after equity falls back below target", () => {
  const r = computeTargetEngine({ ...base, currentEquityCents: 14_000, peakEquityCents: 15_200, targetHitToday: true });
  assert.equal(r.targetHitToday, true);
  assert.equal(r.protectActive, true);
});

test("reduced mode: keeps trading at 0.3x while inside give-back cap", () => {
  // peak +60% ($160), now +55% ($155): given back $5 of $60 peak gain = 8.3% < 10% cap
  const r = computeTargetEngine({
    ...base, protectBehavior: "reduced",
    currentEquityCents: 15_500, peakEquityCents: 16_000, targetHitToday: true,
  });
  assert.equal(r.paceState, "TARGET_HIT");
  assert.equal(r.sizeMult, 0.3);
  assert.equal(r.blockReason, null);
});

test("reduced mode: give-back measured from PEAK gain, not target gain", () => {
  // peak +100% ($200), now +55% ($155): given back $45 of $100 peak gain = 45% >> 10% cap.
  // (Under the old target-based formula, +55% > +50% target would NOT have tripped.)
  const r = computeTargetEngine({
    ...base, protectBehavior: "reduced",
    currentEquityCents: 15_500, peakEquityCents: 20_000, targetHitToday: true,
  });
  assert.equal(r.sizeMult, 0);
  assert.match(r.blockReason ?? "", /Give-back cap/);
});

test("fail-closed: latch persist rejection blocks entries until a retry succeeds", async () => {
  // Simulate updateDayRow rejecting at the target-hit transition.
  const latchDirty = await persistLatchDurably(Promise.reject(new Error("db down")));
  assert.equal(latchDirty, true, "failed durable write must leave the latch dirty");

  // With a dirty latch, the entry gate must block — even if the engine status
  // itself has no blockReason (e.g. status lost after a crash/reload).
  const block = dailyTargetEntryBlock(null, latchDirty);
  assert.ok(block, "no entry may proceed while the latch is unpersisted");
  assert.match(block!, /fail-closed/);

  // Once a retry write succeeds, the gate reopens.
  const cleared = await persistLatchDurably(Promise.resolve());
  assert.equal(cleared, false);
  assert.equal(dailyTargetEntryBlock(null, cleared), null);
});

test("entry gate: engine blockReason takes precedence and is surfaced verbatim", () => {
  const status = computeTargetEngine({ ...base, currentEquityCents: 15_100, peakEquityCents: 15_100, targetHitToday: false });
  const block = dailyTargetEntryBlock({ date: "2099-01-01", ...status }, false);
  assert.equal(block, status.blockReason);
});

// 2026-08-25 audit fix: a DB failure while loading/rolling the daily-target
// snapshot used to reset status to null with no block at all — orders then
// proceeded with zero daily-target/protect-mode protection for the outage.
test("fail-closed: a snapshot load failure blocks entries even with no status and a clean latch", () => {
  assert.equal(dailyTargetEntryBlock(null, false, true), "Daily-target snapshot unknown — DB load failed (fail-closed)");
});

test("entry gate: defaults to open when nothing is blocked (status null, latch clean, load ok)", () => {
  assert.equal(dailyTargetEntryBlock(null, false), null);
  assert.equal(dailyTargetEntryBlock(null, false, false), null);
});

// ── computeCashFlowReconciliation ────────────────────────────────────────────
// Regression coverage for the 2026-08-10 incident: an $88 deposit read as an
// 82% daily trading gain and falsely tripped the target latch, standing the
// bot down on live money it hadn't actually earned.

test("cash-flow reconciliation: balance move fully explained by realized P&L is NOT a flow", () => {
  // Bot won 500¢ since the last check; balance moved by exactly that much.
  const r = computeCashFlowReconciliation({
    balanceCents: 10_500, lastReconciledBalanceCents: 10_000,
    realizedSinceLastCheckCents: 500,
    startEquityCents: 10_000, peakEquityCents: 10_500,
  });
  assert.equal(r.isExternalFlow, false);
  assert.equal(r.externalFlowCents, 0);
  assert.equal(r.newStartEquityCents, 10_000, "no re-baseline on a trade-explained move");
  assert.equal(r.newPeakEquityCents, 10_500);
});

test("cash-flow reconciliation: an $88 deposit is detected and folded into baseline + peak", () => {
  // Reproduces the live incident: no trades settled (realized = 0), but the
  // balance jumped by $88 — must be recognized as a deposit, not a gain.
  const r = computeCashFlowReconciliation({
    balanceCents: 18_800, lastReconciledBalanceCents: 10_000,
    realizedSinceLastCheckCents: 0,
    startEquityCents: 10_000, peakEquityCents: 10_000,
  });
  assert.equal(r.isExternalFlow, true);
  assert.equal(r.externalFlowCents, 8_800);
  assert.equal(r.newStartEquityCents, 18_800, "deposit must be folded into the baseline");
  assert.equal(r.newPeakEquityCents, 18_800, "and into the peak, so it can't fake a give-back gain either");
});

test("cash-flow reconciliation: a withdrawal is detected as a negative flow", () => {
  const r = computeCashFlowReconciliation({
    balanceCents: 7_000, lastReconciledBalanceCents: 10_000,
    realizedSinceLastCheckCents: 0,
    startEquityCents: 10_000, peakEquityCents: 12_000,
  });
  assert.equal(r.isExternalFlow, true);
  assert.equal(r.externalFlowCents, -3_000);
  assert.equal(r.newStartEquityCents, 7_000);
  assert.equal(r.newPeakEquityCents, 9_000, "peak shifts down with the withdrawal, not just the start");
});

test("cash-flow reconciliation: a deposit landing alongside a real trade loss isn't double-counted or dropped", () => {
  // A trade lost $30 (realized = -3,000¢) in this window, yet the balance
  // rose by $15 net ($100 → $115) — only explainable by a $45 deposit
  // arriving alongside the loss. The reconciler must isolate exactly the
  // $45 deposit and still let the $30 loss count against the target.
  const r = computeCashFlowReconciliation({
    balanceCents: 11_500, lastReconciledBalanceCents: 10_000,
    realizedSinceLastCheckCents: -3_000,
    startEquityCents: 10_000, peakEquityCents: 10_000,
  });
  assert.equal(r.isExternalFlow, true);
  assert.equal(r.externalFlowCents, 4_500, "must isolate the $45 deposit, not the $15 net balance change");
  assert.equal(r.newStartEquityCents, 14_500, "baseline absorbs only the deposit — the $30 loss still counts against the target");
});

test("cash-flow reconciliation: sub-5¢ noise (fee rounding) is never treated as a flow", () => {
  const r = computeCashFlowReconciliation({
    balanceCents: 10_004, lastReconciledBalanceCents: 10_000,
    realizedSinceLastCheckCents: 0,
    startEquityCents: 10_000, peakEquityCents: 10_000,
  });
  assert.equal(r.isExternalFlow, false, "4¢ of drift must not re-baseline the whole day");
  assert.equal(r.newStartEquityCents, 10_000);
});

test("BEHIND pace never boosts size — the engine only reduces risk", () => {
  // 0% progress guarantees BEHIND late in the ET day.
  const evening = new Date("2026-08-01T23:00:00-04:00");
  for (const riskProfile of ["BALANCED", "AGGRESSIVE", "CONSERVATIVE", "RECOVERY"] as const) {
    const r = computeTargetEngine({
      ...base, riskProfile,
      currentEquityCents: 10_000, peakEquityCents: 10_000, targetHitToday: false, now: evening,
    });
    assert.equal(r.paceState, "BEHIND");
    assert.equal(r.sizeMult, 1.0, `no catch-up boost on ${riskProfile} — up-sizing after underperformance is loss chasing`);
  }
});

test("ET date key rolls at midnight Eastern, not midnight UTC", () => {
  // August is EDT: 23:59:59 ET is still the prior date, while 00:00:00 ET
  // is the new date even though both instants are on the same UTC date.
  assert.equal(etDateKey(new Date("2026-08-02T03:59:59.999Z")), "2026-08-01");
  assert.equal(etDateKey(new Date("2026-08-02T04:00:00.000Z")), "2026-08-02");
});
