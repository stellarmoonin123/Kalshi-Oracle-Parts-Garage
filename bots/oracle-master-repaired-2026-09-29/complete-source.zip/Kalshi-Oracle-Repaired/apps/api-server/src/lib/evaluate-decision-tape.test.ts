/**
 * Skip/take jsonl schema. Observational. No ENABLE. No EV cut.
 */
process.env.EVALUATE_DECISION_TRACE_DISABLE = "1";

import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  appendEvaluateDecision,
  honestPWin,
  honestEvCents,
  isEvaluateDecisionRow,
  sanitizeEvaluatePricing,
  EVALUATE_DECISION_KIND,
  LIVE_APPLY,
  type EvaluateDecisionRow,
} from "./evaluate-decision-tape.js";

test("locks: liveApply false, no paperMode false", () => {
  assert.equal(LIVE_APPLY, false);
  assert.equal(EVALUATE_DECISION_KIND, "evaluate_decision");
});

test("junk p=1 / ev=50 / yesAsk 91 on skip is stripped", () => {
  assert.equal(honestPWin(1), null);
  assert.equal(honestPWin(0.60), 0.60);
  assert.equal(honestEvCents(50, null), null);
  assert.equal(honestEvCents(4.2, 0.60), 4.2);
  const s = sanitizeEvaluatePricing({
    pWin: 1,
    evCents: 50,
    yesAsk: 91,
    noAsk: 10,
    side: "skip",
  });
  assert.equal(s.pWin, null);
  assert.equal(s.evCents, null);
  assert.equal(s.fillAsk, null);
  assert.equal(s.yesAsk, 91);
  assert.equal(s.noAsk, 10);
});

test("skip jsonl schema writes R_t packId sideOrSkip p EV asks", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "eval-dec-"));
  const file = path.join(dir, "evaluate-decision-trace.jsonl");
  process.env.EVALUATE_DECISION_TRACE_PATH = file;
  delete process.env.EVALUATE_DECISION_TRACE_DISABLE;
  const row: EvaluateDecisionRow = {
    kind: "evaluate_decision",
    ts: 1,
    ticker: "KXBTC15M-TEST",
    R_t: {
      vol: "NORMAL",
      shape: "CHOP",
      cycleMicro: "MICRO_RANGE",
      cycleHtf: "HTF_RANGE",
      confidence: 0.4,
      lagUsed: false,
    },
    packId: "RANGE",
    sideOrSkip: "skip",
    outcome: "SKIP",
    pWin: 0.60,
    evCents: 4,
    yesAsk: 49,
    noAsk: 52,
    fillAsk: null,
    strategyId: "CONFLUENCE_CASCADE",
    skipReason: "still_mid",
    rawCode: "NO_ELIGIBLE_STRATEGY",
    liveApply: false,
  };
  appendEvaluateDecision(row);
  const parsed = JSON.parse(fs.readFileSync(file, "utf8").trim()) as unknown;
  assert.equal(isEvaluateDecisionRow(parsed), true);
  const r = parsed as EvaluateDecisionRow;
  assert.equal(r.kind, "evaluate_decision");
  assert.equal(r.liveApply, false);
  assert.ok(r.R_t);
  assert.equal(r.packId, "RANGE");
  assert.equal(r.sideOrSkip, "skip");
  assert.equal(r.pWin, 0.60);
  assert.equal(r.yesAsk, 49);
  assert.equal(r.noAsk, 52);
  assert.equal(r.fillAsk, null);
  fs.rmSync(dir, { recursive: true, force: true });
  process.env.EVALUATE_DECISION_TRACE_DISABLE = "1";
  delete process.env.EVALUATE_DECISION_TRACE_PATH;
});
