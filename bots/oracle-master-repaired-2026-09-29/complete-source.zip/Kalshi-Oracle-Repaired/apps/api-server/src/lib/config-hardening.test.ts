import { test } from "node:test";
import assert from "node:assert/strict";
import { sanitizeConfigPatch } from "./config-patch-surface.js";
import { applyComposerLocks } from "./composer-lock.js";
import { applyFrozenCcLocks, restoreFrozenCcSaved } from "./frozen-cc.js";
import { signKalshi } from "./kalshi-auth.js";
import { shouldRestoreCodeCheckpoint } from "./default-settings.js";
import crypto from "node:crypto";

const ref: Record<string, unknown> = {
  paperMode: true, enabled: false, minConfidence: 55, disabledStrategies: ["X"],
  frozenCcFixedContracts: null, frozenCcMode: false, strategyOverride: null,
};

test("paperMode: only a boolean is accepted; falsy non-booleans are refused", () => {
  for (const v of [0, null, "", "false"]) {
    const r = sanitizeConfigPatch({ paperMode: v });
    assert.equal(r.accepted.paperMode, undefined, `paperMode=${JSON.stringify(v)} must not be accepted`);
    assert.equal(r.refused.length, 1);
  }
  const ok = sanitizeConfigPatch({ paperMode: true });
  assert.equal(ok.accepted.paperMode, true);
});

test("composer lock coerces a non-boolean paperMode back to paper", () => {
  const base = { autoMode: false, autoModeV2Mode: "off", useExpertAgent: false, ariaModel: "", enable1HLive: false,
    disabledStrategies: [] as string[], paperMode: 0 as unknown as boolean };
  const r = applyComposerLocks(base as never, {});
  assert.equal((r.config as { paperMode: unknown }).paperMode, true);
});

test("enabled is ignored on patch (runtime state), unknown keys and type mismatches are refused", () => {
  const r = sanitizeConfigPatch({ enabled: true, bogusKey: 1, minConfidence: "60", disabledStrategies: "X" }, ref);
  assert.equal(r.accepted.enabled, undefined);
  assert.ok(r.notes.some(n => n.startsWith("enabled ignored")));
  assert.deepEqual(r.refused.map(x => x.key).sort(), ["bogusKey", "disabledStrategies", "minConfidence"]);
});

test("null-default keys accept a value and numeric keys accept null", () => {
  const r = sanitizeConfigPatch({ frozenCcFixedContracts: 3, strategyOverride: "CONFLUENCE_CASCADE" }, ref);
  assert.equal(r.refused.length, 0);
  assert.equal(r.accepted.frozenCcFixedContracts, 3);
});

test("manual risk profile can be selected and returned to automatic mode", () => {
  for (const current of [null, "BALANCED"]) {
    const reference = { manualRiskProfile: current };
    for (const value of [null, "CONSERVATIVE", "BALANCED", "AGGRESSIVE", "RECOVERY"]) {
      const result = sanitizeConfigPatch({ manualRiskProfile: value }, reference);
      assert.deepEqual(result.refused, []);
      assert.equal(result.accepted.manualRiskProfile, value);
    }
    for (const value of ["UNKNOWN", 1, {}, []]) {
      const result = sanitizeConfigPatch({ manualRiskProfile: value }, reference);
      assert.equal(result.refused.length, 1);
    }
  }
});

test("FROZEN_CC snapshots pre-freeze values and restores them when the mode turns off", () => {
  const before = {
    frozenCcMode: true, autoMode: false, autoModeV2Mode: "off" as const, useExpertAgent: false,
    specialistPacksMode: "on", useDailyTarget: true, enable1HContracts: true, enable1HLive: false,
    holdToSettlement: false, strategyOverride: null, disabledStrategies: ["A", "B"],
    settlementVetoEnabled: true, settlementConsensusVoteEnabled: false,
    frozenCcSaved: null as Record<string, unknown> | null,
    frozenCcCatastrophicCents: 8,
  };
  const frozen = applyFrozenCcLocks(before).config;
  assert.equal(frozen.holdToSettlement, false, "PATH_RIDE must permit sell-green exits");
  assert.ok(frozen.disabledStrategies!.length > 20);
  assert.deepEqual(frozen.frozenCcSaved?.disabledStrategies, ["A", "B"]);
  assert.equal(frozen.frozenCcSaved?.holdToSettlement, false);

  // Turning it off restores the operator's pre-freeze values.
  const off = restoreFrozenCcSaved({ ...frozen, frozenCcMode: false }).config;
  assert.equal(off.holdToSettlement, false);
  assert.equal(off.specialistPacksMode, "on");
  assert.equal(off.useDailyTarget, true);
  assert.deepEqual(off.disabledStrategies, ["A", "B"]);
  assert.equal(off.frozenCcSaved, null);

  // A second freeze does not overwrite the snapshot while still frozen.
  const again = applyFrozenCcLocks({ ...frozen, holdToSettlement: false }).config;
  assert.equal(again.frozenCcSaved?.holdToSettlement, false);
});

test("FROZEN_CC downgrades autoPolicyMode live → shadow and restores it when unfrozen", () => {
  const frozen = applyFrozenCcLocks({ frozenCcMode: true, autoPolicyMode: "live", frozenCcSaved: null }).config;
  assert.equal(frozen.autoPolicyMode, "shadow");
  const savedPolicy = (frozen.frozenCcSaved as Record<string, unknown> | null)?.autoPolicyMode;
  assert.equal(savedPolicy, "live");
  const shadowStays = applyFrozenCcLocks({ frozenCcMode: true, autoPolicyMode: "shadow", frozenCcSaved: null }).config;
  assert.equal(shadowStays.autoPolicyMode, "shadow");
  const off = restoreFrozenCcSaved({ ...frozen, frozenCcMode: false }).config;
  assert.equal(off.autoPolicyMode, "live");
});

test("composer lock coerces an unknown autoPolicyMode to off", () => {
  const base = { autoMode: false, autoModeV2Mode: "off" as const, useExpertAgent: false, ariaModel: "", enable1HLive: false,
    disabledStrategies: [] as string[], paperMode: true, autoPolicyMode: "bounded_write" };
  const r = applyComposerLocks(base as never, {});
  assert.equal((r.config as { autoPolicyMode: unknown }).autoPolicyMode, "off");
  const ok = applyComposerLocks({ ...base, autoPolicyMode: "live" } as never, {});
  assert.equal((ok.config as { autoPolicyMode: unknown }).autoPolicyMode, "live");
});

test("Kalshi signature covers the path without its query string", () => {
  const { privateKey } = crypto.generateKeyPairSync("rsa", { modulusLength: 2048 });
  const pem = privateKey.export({ type: "pkcs8", format: "pem" }).toString();
  const pub = crypto.createPublicKey(privateKey);
  const sig = signKalshi(pem, "1700000000000", "get", "/trade-api/v2/markets?series_ticker=KXBTC&limit=1");
  const verify = (msg: string) => crypto.verify("sha256", Buffer.from(msg), {
    key: pub, padding: crypto.constants.RSA_PKCS1_PSS_PADDING, saltLength: 32,
  }, Buffer.from(sig, "base64"));
  assert.equal(verify("1700000000000GET/trade-api/v2/markets"), true);
  assert.equal(verify("1700000000000GET/trade-api/v2/markets?series_ticker=KXBTC&limit=1"), false);
});

test("restoring the code checkpoint is opt-in only", () => {
  assert.equal(shouldRestoreCodeCheckpoint({}), false);
  assert.equal(shouldRestoreCodeCheckpoint({ snapshotPath: "/x", checkpointDir: "/y" }), false);
  assert.equal(shouldRestoreCodeCheckpoint({ restoreCode: true }), true);
});
