/** Committed `default` checkpoint matches master src and restores cleanly (2026-09-25). */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import {
  DEFAULT_CODE_CHECKPOINT_FILES,
  DEFAULT_SETTINGS_FROZEN_AT,
  restoreDefaultSettings,
} from "./default-settings.js";
import { oracleDeskChatEvents } from "./oracle-desk-chat.js";

const API = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const CK = path.join(API, "checkpoints/default");
const sha = (b: Buffer) => crypto.createHash("sha256").update(b).digest("hex");
const manifest = JSON.parse(fs.readFileSync(path.join(CK, "MANIFEST.json"), "utf8"));

test("checkpoint files are byte-identical to src and the manifest hash is current", () => {
  assert.equal(manifest.frozenAt, DEFAULT_SETTINGS_FROZEN_AT);
  assert.equal(manifest.fileCount, DEFAULT_CODE_CHECKPOINT_FILES.length);
  for (const rel of DEFAULT_CODE_CHECKPOINT_FILES) {
    const live = fs.readFileSync(path.join(API, rel));
    const ck = fs.readFileSync(path.join(CK, "code", rel));
    assert.ok(live.equals(ck), `checkpoint stale for ${rel} — run: node scripts/refresh-default-checkpoint.mjs`);
    assert.equal(manifest.files[rel], sha(live));
  }
  const snapSha = sha(fs.readFileSync(path.join(CK, "default-settings-snapshot.json")));
  assert.equal(manifest.snapshotSha256, snapSha);
  const lines = Object.keys(manifest.files).sort().map((k) => `${k}\0${manifest.files[k]}\n`).join("");
  assert.equal(manifest.hash, crypto.createHash("sha256").update(lines + snapSha).digest("hex"));
});

test("snapshot is paper, approved band, no secrets, no ledger", () => {
  const snap = JSON.parse(fs.readFileSync(path.join(CK, "default-settings-snapshot.json"), "utf8"));
  assert.equal(snap.paperMode, true);
  assert.equal(snap.minEntryPrice, 20);
  assert.equal(snap.maxEntryPrice, 55);
  assert.equal(snap.reservePct, 15);
  for (const k of Object.keys(snap)) assert.ok(!/(secret|token|password|apikey|privatekey|pem|passcode)/i.test(k), `secret-like key ${k}`);
  assert.equal("trades" in snap || "virtualCents" in snap, false, "ledger fields must not be in the snapshot");
});

test("typing `default` in chat restores the committed checkpoint (temp config + temp src)", async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "default-ck-"));
  const configPath = path.join(dir, ".bot-config.json");
  fs.writeFileSync(configPath, JSON.stringify({ paperMode: true, minEntryPrice: 28 }));
  let applied: Record<string, unknown> | null = null;
  const events: any[] = [];
  for await (const ev of oracleDeskChatEvents({
    question: "default",
    snapshot: {} as any,
    chatRole: "ADMIN", // accounts: `default` is an ADMIN-only chat command
    restoreDefault: () => restoreDefaultSettings({
      snapshotPath: path.join(CK, "default-settings-snapshot.json"),
      checkpointDir: path.join(CK, "code"),
      srcRoot: dir,
      configPath,
      restoreCode: true,
      applyConfig: (cfg) => { applied = cfg; },
    }),
  })) events.push(ev);
  const text = events.filter((e) => e.type === "delta").map((e) => e.content).join("");
  assert.match(text, new RegExp(`Restored SETTINGS frozen at ${DEFAULT_SETTINGS_FROZEN_AT.replace(/[()+]/g, "\\$&")}`));
  assert.match(text, new RegExp(`${DEFAULT_CODE_CHECKPOINT_FILES.length} files`));
  assert.equal((applied as any)?.paperMode, true);
  const written = JSON.parse(fs.readFileSync(configPath, "utf8"));
  assert.equal(written.paperMode, true);
  assert.equal(written.minEntryPrice, 20);
  for (const rel of DEFAULT_CODE_CHECKPOINT_FILES) {
    assert.ok(fs.readFileSync(path.join(dir, rel)).equals(fs.readFileSync(path.join(API, rel))), rel);
  }
  assert.equal(fs.existsSync(path.join(dir, "data/paper-ledger.json")), false);
});
