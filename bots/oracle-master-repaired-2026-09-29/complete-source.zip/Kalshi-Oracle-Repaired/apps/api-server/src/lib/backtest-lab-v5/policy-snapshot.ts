/**
 * backtest-lab-v5/policy-snapshot.ts
 *
 * GO — BACKTEST LAB v5 + CONTINUOUS POLICY REGRESSION (2026-08-22), PART II-A.
 *
 * A lab-only registry of `SimPolicy` snapshots + their OOS metrics, keyed by
 * an id and a git sha/timestamp. This is a RESEARCH ARTIFACT STORE, never a
 * live-config source — nothing in this file or its callers writes to
 * `.bot-config.json` or any live BotConfig field. Regression comparisons
 * read the most recent prior snapshot as a baseline; they never write one
 * back into live trading behavior (see regression-runner.ts's explicit
 * "never auto-modifies live config" contract).
 *
 * Follows this codebase's established raw-SQL `CREATE TABLE IF NOT EXISTS`
 * bootstrap pattern (daily-target.ts / prediction-learner.ts / cash-flow.ts)
 * rather than a Drizzle schema addition — this repo's `drizzle-kit push`
 * needs an interactive TTY this environment doesn't have, so ad-hoc lab
 * tables are bootstrapped at runtime instead (documented precedent, not a
 * new workaround invented here).
 */

import { db } from '@workspace/db';
import { sql } from 'drizzle-orm';
import type { SimPolicy } from './sim-policy.js';
import type { PolicyMetrics } from './validation.js';
import type { Verdict } from './validation.js';

export interface PolicySnapshot {
  id:        number;
  snapshotId: string;   // human label, e.g. "LEAN@2026-08-22T19:00:00Z" or a git sha
  gitSha:    string | null;
  createdAt: string;
  policyId:  string;    // SimPolicy.id ('LEAN' | 'LEGACY' | future custom ids)
  policyBlob: SimPolicy;
  oosMetrics: PolicyMetrics | null;
  verdict:   Verdict | null;
  note:      string | null;
}

const MAX_SNAPSHOTS_KEPT = 20;

let schemaReady: Promise<void> | null = null;
export function ensurePolicySnapshotSchema(): Promise<void> {
  if (!schemaReady) {
    schemaReady = (async () => {
      await db.execute(sql`
        CREATE TABLE IF NOT EXISTS policy_snapshots (
          id           serial PRIMARY KEY,
          snapshot_id  text NOT NULL,
          git_sha      text,
          created_at   timestamp NOT NULL DEFAULT now(),
          policy_id    text NOT NULL,
          policy_blob  jsonb NOT NULL,
          oos_metrics  jsonb,
          verdict      text,
          note         text
        )
      `);
      await db.execute(sql`
        CREATE INDEX IF NOT EXISTS policy_snapshots_created_at_idx
        ON policy_snapshots (created_at DESC)
      `);
    })().catch((err) => {
      schemaReady = null; // allow retry on next call
      throw err;
    });
  }
  return schemaReady;
}

function rowToSnapshot(row: any): PolicySnapshot {
  return {
    id:        row.id,
    snapshotId: row.snapshot_id,
    gitSha:    row.git_sha,
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString() : String(row.created_at),
    policyId:  row.policy_id,
    policyBlob: typeof row.policy_blob === 'string' ? JSON.parse(row.policy_blob) : row.policy_blob,
    oosMetrics: row.oos_metrics == null ? null : (typeof row.oos_metrics === 'string' ? JSON.parse(row.oos_metrics) : row.oos_metrics),
    verdict:   row.verdict ?? null,
    note:      row.note ?? null,
  };
}

export async function saveSnapshot(args: {
  snapshotId: string;
  gitSha:     string | null;
  policy:     SimPolicy;
  oosMetrics: PolicyMetrics | null;
  verdict:    Verdict | null;
  note:       string | null;
}): Promise<PolicySnapshot> {
  await ensurePolicySnapshotSchema();
  const result = await db.execute(sql`
    INSERT INTO policy_snapshots (snapshot_id, git_sha, policy_id, policy_blob, oos_metrics, verdict, note)
    VALUES (
      ${args.snapshotId}, ${args.gitSha}, ${args.policy.id},
      ${JSON.stringify(args.policy)}::jsonb,
      ${args.oosMetrics ? JSON.stringify(args.oosMetrics) : null}::jsonb,
      ${args.verdict}, ${args.note}
    )
    RETURNING *
  `);
  const rows = (result as any).rows ?? result;
  await pruneOldSnapshots();
  return rowToSnapshot(rows[0]);
}

export async function listSnapshots(policyId?: string, limit = MAX_SNAPSHOTS_KEPT): Promise<PolicySnapshot[]> {
  await ensurePolicySnapshotSchema();
  const result = policyId
    ? await db.execute(sql`
        SELECT * FROM policy_snapshots WHERE policy_id = ${policyId}
        ORDER BY created_at DESC LIMIT ${limit}
      `)
    : await db.execute(sql`
        SELECT * FROM policy_snapshots ORDER BY created_at DESC LIMIT ${limit}
      `);
  const rows = (result as any).rows ?? result;
  return rows.map(rowToSnapshot);
}

/** Most recent snapshot for a given policyId, used as the regression
 *  baseline. Returns null when no prior snapshot exists (first-ever run —
 *  the regression gate treats this as "nothing to compare against yet",
 *  never as a failure). */
export async function getLatestSnapshot(policyId: string): Promise<PolicySnapshot | null> {
  const rows = await listSnapshots(policyId, 1);
  return rows[0] ?? null;
}

async function pruneOldSnapshots(): Promise<void> {
  await db.execute(sql`
    DELETE FROM policy_snapshots
    WHERE id NOT IN (
      SELECT id FROM policy_snapshots ORDER BY created_at DESC LIMIT ${MAX_SNAPSHOTS_KEPT}
    )
  `);
}
