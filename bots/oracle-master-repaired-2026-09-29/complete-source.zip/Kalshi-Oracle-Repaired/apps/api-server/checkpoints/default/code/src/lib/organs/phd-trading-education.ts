/**
 * phd-trading-education — deterministic PhD trading education + street common sense.
 *
 * Pure. No network. No LLM. Never placeOrder. Never cuts floors
 * (EV≥3¢ / Kelly≤0.60 / ask 20–55 / 9% / reserve 15%).
 * Never hard-gates six-gate CC_VEL until n≥40 (observe / soft heave only).
 *
 * Curriculum: microstructure · probability/calibration · settlement/BTC 15m ·
 * decision theory · causal/scar · common-sense boolean checks.
 */
export const PHD_TRADING_EDUCATION_LOADED = "PHD_TRADING_EDUCATION_LOADED" as const;

/** Default slip when depth unknown — blotter evidence (+2¢). */
export const PHD_DEFAULT_SLIP_CENTS = 2 as const;

/** Ordinary thin min edge (¢) — soft refuse; hard floor still EV≥3¢. */
export const PHD_MIN_EDGE_NET_THIN_CENTS = 7 as const;

/** Hard EV floor mirror — never cut. */
export const PHD_EV_FLOOR_CENTS = 3 as const;

/** pWin at/below this with high confidence → overconfidence / refuse sail. */
export const PHD_CONFIDENCE_OUTRUNS_P_MAX = 0.55 as const;

/** Mid-ask band where fee peaks and thin edges hurt most. */
export const PHD_MID_ASK_MIN = 30 as const;
export const PHD_MID_ASK_MAX = 50 as const;

export const PHD_FLOOR_NOTE =
  "floors intact: EV≥3¢ Kelly≤0.60 ask20–55 9% reserve15% — never cut; CC_VEL observe-only until n≥40" as const;

/** Short doctrine citations (inspectable). */
export const PHD_DOCTRINES = {
  microstructure:
    "MICRO: default slip 2¢ when depth unknown; fee peaks near 50¢; net=p−(ask/100+fee+slip); rounding punishes tiny clips",
  probability:
    "PROB: confidence≫pWin → overconfidence tax toward 0.5; good=62% hits~6/10; bad=85% sized like 85% hits 6/10; p−cost<min_edge→REFUSE",
  settlement:
    "SETTLE: named-index avg not last tick; hold-wrong-side primary scar; PATH_RIDE_TP can mask wrong entry; settle≠side→HEAVE soft",
  decision:
    "DECISION: default ABSTAIN; skip@0 first-class; option value of waiting when band covers both; never add to loser without Class A/B",
  causal:
    "CAUSAL: tag sold_early_correct_settle vs held_wrong_settle; train side-pick from settle; don't upweight entry from lucky TP on wrong side",
  commonSense:
    "STREET: thinEdgeAfterSlip · velAgainst · mtfBullIntoRedVel · settleSideDisagrees · confidenceOutrunsP · holdYesIntoSettleNoRisk · slippageEatingEV",
} as const;

export type PhdCheckSeverity = "heave" | "warn";

export type PhdCommonSenseCheckId =
  | "thinEdgeAfterSlip"
  | "velAgainstProposedSide"
  | "mtfBullIntoRedVel"
  | "settleSideDisagrees"
  | "confidenceOutrunsP"
  | "holdYesIntoSettleNoRisk"
  | "slippageEatingEV";

export type PhdCommonSenseCheck = {
  id: PhdCommonSenseCheckId;
  fired: boolean;
  severity: PhdCheckSeverity;
  detail: string;
};

export type PhdEducationInput = {
  /** P(proposed side wins) 0..1 — not raw confidence. */
  pWin?: number | null;
  /** Ask for the proposed side (¢). */
  askCents?: number | null;
  side?: "yes" | "no" | null;
  /** CC_VEL_AGAINST_YES / CC_VEL_AGAINST_NO / null */
  ccVel?: string | null;
  /** True when YES + mtf bull + red 1m vel. */
  mtfBullRed?: boolean | null;
  settleSide?: "yes" | "no" | "skip" | null;
  /** Stated / sole EV before slip (¢). */
  evCents?: number | null;
  soleDecision?: string | null;
  confidenceBand?: "low" | "mid" | "high" | null;
  /** Override; default 2¢. */
  slipDefaultCents?: number | null;
  /** Optional fee override (¢/contract); else quadratic taker ceil at ask. */
  feeCents?: number | null;
  /** Open position side when holding (abandon lean). */
  openSide?: "yes" | "no" | null;
  /** Soft min edge; default 7¢ thin. Hard floor still 3¢. */
  minEdgeNetCents?: number | null;
};

export type PhdEducationResult = {
  schema: "phd_trading_education_v1";
  educationLoaded: true;
  doctrines: string[];
  checks: PhdCommonSenseCheck[];
  heaveTo: boolean;
  heaveReasons: string[];
  abandonLean: boolean;
  /** 0..1 pull of p toward p0=0.5 */
  overconfidenceTax: number;
  assumedSlipCents: number;
  edgeNetAfterSlip: number | null;
  commonSenseSummary: string;
  floorNote: typeof PHD_FLOOR_NOTE;
};

function finite(n: number | null | undefined): n is number {
  return typeof n === "number" && Number.isFinite(n);
}

function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * Taker fee ¢/contract at ask — 0.07·P·(1−P)·100 ceil (fee peaks near 50¢).
 * Mirrors oracle-v2 / kalshi-fee SoT without importing (cycle-safe).
 */
export function phdTakerFeeCentsPerContract(askCents: number): number {
  const P = askCents / 100;
  if (!(P > 0) || !(P < 1)) return 0;
  return Math.ceil(0.07 * P * (1 - P) * 100 - 1e-9);
}

/** Parse CC_VEL_AGAINST_* → side it fights. */
export function parsePhdVelAgainst(
  ccVel: string | null | undefined,
): "yes" | "no" | null {
  if (!ccVel) return null;
  if (ccVel === "CC_VEL_AGAINST_YES" || /AGAINST_YES/i.test(ccVel)) return "yes";
  if (ccVel === "CC_VEL_AGAINST_NO" || /AGAINST_NO/i.test(ccVel)) return "no";
  return null;
}

/**
 * Net edge after ask + fee + slip (¢).
 * pWin = P(proposed side wins); askCents = ask for that side.
 * Formula: pWin·100 − ask − fee − slip
 */
export function phdEdgeNetAfterSlip(input: {
  pWin: number;
  askCents: number;
  side?: "yes" | "no" | null;
  slipCents?: number;
  feeCents?: number | null;
}): number {
  const slip =
    typeof input.slipCents === "number" && Number.isFinite(input.slipCents)
      ? input.slipCents
      : PHD_DEFAULT_SLIP_CENTS;
  const fee = finite(input.feeCents)
    ? input.feeCents
    : phdTakerFeeCentsPerContract(input.askCents);
  return round2(input.pWin * 100 - input.askCents - fee - slip);
}

/**
 * Overconfidence tax 0..1 — pull toward p0 when confidenceBand high but pWin mid.
 */
export function phdOverconfidenceTax(input: {
  pWin?: number | null;
  confidenceBand?: "low" | "mid" | "high" | null;
  askCents?: number | null;
}): number {
  let tax = 0;
  const p = finite(input.pWin) ? clamp01(input.pWin) : null;
  const band = input.confidenceBand ?? null;
  const ask = finite(input.askCents) ? input.askCents : null;
  const midAsk =
    ask != null && ask >= PHD_MID_ASK_MIN && ask <= PHD_MID_ASK_MAX;

  if (band === "high" && p != null && p <= PHD_CONFIDENCE_OUTRUNS_P_MAX) {
    tax += 0.35;
  } else if (band === "high" && p != null && p < 0.62) {
    tax += 0.2;
  } else if (band === "mid" && p != null && p <= 0.52) {
    tax += 0.1;
  }
  if (midAsk && p != null && Math.abs(p - 0.5) < 0.08) {
    tax += 0.1;
  }
  return round2(Math.min(1, tax));
}

function isTakeSole(sole: string | null | undefined): boolean {
  if (!sole) return false;
  const u = String(sole).toUpperCase();
  return (
    u === "TAKE" ||
    u.startsWith("TAKE_") ||
    u === "BUY_YES" ||
    u === "BUY_NO" ||
    u === "SAIL_YES" ||
    u === "SAIL_NO"
  );
}

/**
 * Evaluate PhD common-sense gates. Soft heave / abandon lean only —
 * never hard six-gate CC_VEL; never cut floors.
 */
export function evaluatePhdCommonSense(
  input: PhdEducationInput,
): PhdEducationResult {
  const slip =
    finite(input.slipDefaultCents) && input.slipDefaultCents >= 0
      ? input.slipDefaultCents
      : PHD_DEFAULT_SLIP_CENTS;
  const minEdge =
    finite(input.minEdgeNetCents) &&
    input.minEdgeNetCents >= PHD_EV_FLOOR_CENTS
      ? input.minEdgeNetCents
      : PHD_MIN_EDGE_NET_THIN_CENTS;

  const pWin = finite(input.pWin) ? clamp01(input.pWin) : null;
  const ask = finite(input.askCents) ? input.askCents : null;
  const side = input.side === "yes" || input.side === "no" ? input.side : null;
  const settle =
    input.settleSide === "yes" ||
    input.settleSide === "no" ||
    input.settleSide === "skip"
      ? input.settleSide
      : null;
  const openSide =
    input.openSide === "yes" || input.openSide === "no" ? input.openSide : null;
  const band = input.confidenceBand ?? null;
  const sole = input.soleDecision ?? null;
  const taking = isTakeSole(sole) || side != null;

  let edgeNet: number | null = null;
  if (pWin != null && ask != null) {
    edgeNet = phdEdgeNetAfterSlip({
      pWin,
      askCents: ask,
      side: side ?? "yes",
      slipCents: slip,
      feeCents: input.feeCents,
    });
  }

  const tax = phdOverconfidenceTax({
    pWin,
    confidenceBand: band,
    askCents: ask,
  });

  const against = parsePhdVelAgainst(input.ccVel ?? null);
  const checks: PhdCommonSenseCheck[] = [];

  // 1. thinEdgeAfterSlip — blotter 52%@40¢+2¢ slip class heaves via cushion
  {
    let fired = false;
    let detail = "edge after slip not thin / inputs missing";
    if (edgeNet != null && taking) {
      const cushion =
        pWin != null && pWin <= PHD_CONFIDENCE_OUTRUNS_P_MAX
          ? minEdge + slip
          : minEdge;
      if (edgeNet < cushion) {
        fired = true;
        detail = `edgeNetAfterSlip=${edgeNet}¢ < cushion ${cushion}¢ (min ${minEdge}¢ + slip context) ask=${ask} pWin=${pWin} slip=${slip}¢`;
      } else {
        detail = `edgeNetAfterSlip=${edgeNet}¢ ≥ cushion ${cushion}¢`;
      }
    }
    checks.push({
      id: "thinEdgeAfterSlip",
      fired,
      severity: "heave",
      detail,
    });
  }

  // 2. velAgainstProposedSide
  {
    const fired =
      taking && against != null && side != null && against === side;
    checks.push({
      id: "velAgainstProposedSide",
      fired,
      severity: "heave",
      detail: fired
        ? `CC_VEL against ${side} (${input.ccVel}) — WR~20% class; soft heave (n≪40 observe)`
        : against
          ? `vel against ${against} but side=${side ?? "none"}`
          : "no CC_VEL_AGAINST on proposed side",
    });
  }

  // 3. mtfBullIntoRedVel
  {
    const fired = taking && input.mtfBullRed === true && side === "yes";
    checks.push({
      id: "mtfBullIntoRedVel",
      fired,
      severity: "heave",
      detail: fired
        ? "YES + MTF bull into red 1m vel — refuse sail"
        : "no mtfBullIntoRedVel on YES",
    });
  }

  // 4. settleSideDisagrees
  {
    const fired =
      taking &&
      side != null &&
      settle != null &&
      settle !== "skip" &&
      settle !== side;
    checks.push({
      id: "settleSideDisagrees",
      fired,
      severity: "heave",
      detail: fired
        ? `settle pick=${settle} ≠ side=${side} — soft HEAVE_TO`
        : `settle=${settle ?? "n/a"} side=${side ?? "n/a"}`,
    });
  }

  // 5. confidenceOutrunsP
  {
    const midAsk =
      ask != null && ask >= PHD_MID_ASK_MIN && ask <= PHD_MID_ASK_MAX;
    const fired =
      taking &&
      band === "high" &&
      pWin != null &&
      pWin <= PHD_CONFIDENCE_OUTRUNS_P_MAX &&
      (midAsk || ask == null);
    checks.push({
      id: "confidenceOutrunsP",
      fired,
      severity: "heave",
      detail: fired
        ? `confidenceBand=high but pWin=${pWin}≲${PHD_CONFIDENCE_OUTRUNS_P_MAX} at ask=${ask ?? "?"} — overconfidence tax=${tax}`
        : `confidenceBand=${band ?? "n/a"} pWin=${pWin ?? "n/a"} tax=${tax}`,
    });
  }

  // 6. holdYesIntoSettleNoRisk → abandonLean
  {
    const fired =
      (openSide === "yes" ||
        (side === "yes" && /HOLD|EXIT/i.test(String(sole ?? "")))) &&
      settle === "no";
    checks.push({
      id: "holdYesIntoSettleNoRisk",
      fired,
      severity: "warn",
      detail: fired
        ? "open YES + settle lean NO — ABANDON lean (hold-wrong-side scar)"
        : "no hold-YES-into-settle-NO risk",
    });
  }

  // 7. slippageEatingEV
  {
    const ev = finite(input.evCents) ? input.evCents : null;
    const fired = taking && ev != null && slip >= ev && ev >= 0;
    checks.push({
      id: "slippageEatingEV",
      fired,
      severity: "heave",
      detail: fired
        ? `slip ${slip}¢ ≥ stated EV ${ev}¢ — refuse sail`
        : `slip=${slip}¢ ev=${ev ?? "n/a"}¢`,
    });
  }

  if (edgeNet != null && taking && edgeNet < PHD_EV_FLOOR_CENTS) {
    const thin = checks.find((c) => c.id === "thinEdgeAfterSlip");
    if (thin && !thin.fired) {
      thin.fired = true;
      thin.detail = `edgeNetAfterSlip=${edgeNet}¢ < hard EV floor ${PHD_EV_FLOOR_CENTS}¢`;
    }
  }

  const heaveReasons: string[] = [];
  for (const c of checks) {
    if (c.fired && c.severity === "heave") {
      heaveReasons.push(`${c.id}: ${c.detail}`);
    }
  }
  const abandonLean = checks.some(
    (c) => c.id === "holdYesIntoSettleNoRisk" && c.fired,
  );
  const heaveTo = heaveReasons.length > 0;
  const firedIds = checks.filter((c) => c.fired).map((c) => c.id);
  const commonSenseSummary = heaveTo
    ? `HEAVE_TO — ${firedIds.slice(0, 3).join(", ") || "common-sense"}${abandonLean ? " (+abandonLean)" : ""}`
    : abandonLean
      ? "ABANDON lean — holdYesIntoSettleNoRisk; sail ok if flat"
      : firedIds.length
        ? `warn — ${firedIds.join(", ")}`
        : "clear — common sense allows sail (floors still bind)";

  return {
    schema: "phd_trading_education_v1",
    educationLoaded: true,
    doctrines: [
      PHD_DOCTRINES.microstructure,
      PHD_DOCTRINES.probability,
      PHD_DOCTRINES.settlement,
      PHD_DOCTRINES.decision,
      PHD_DOCTRINES.causal,
      PHD_DOCTRINES.commonSense,
    ],
    checks,
    heaveTo,
    heaveReasons: heaveReasons.slice(0, 8),
    abandonLean,
    overconfidenceTax: tax,
    assumedSlipCents: slip,
    edgeNetAfterSlip: edgeNet,
    commonSenseSummary,
    floorNote: PHD_FLOOR_NOTE,
  };
}
