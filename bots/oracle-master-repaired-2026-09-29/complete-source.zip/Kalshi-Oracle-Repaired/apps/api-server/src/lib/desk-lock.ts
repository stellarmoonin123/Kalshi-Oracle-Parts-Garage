/**
 * desk-lock.ts — passcode lock for the whole desk API (opt-in via env
 * DESK_ADMIN_TOKEN). With the env unset every export is a no-op (unchanged
 * behaviour for local dev / tests).
 *
 * When set, every /api request needs ONE of:
 *   - cookie `desk_session` (httpOnly, issued by POST /api/auth/login), or
 *   - `Authorization: Bearer <session token | passcode>`, or
 *   - legacy header `X-Desk-Admin-Token: <passcode>`.
 * Open: /api/healthz, /api/public/status, /api/auth/* (login/logout/me),
 * and CORS preflight. There is NO loopback/IP bypass (D8): the agent's
 * in-process SELF fetches carry `X-Desk-Internal: <per-process random token>`
 * (deskInternalHeaders()); the token lives only in this process's memory.
 * The tick/fill path is in-process and never goes through HTTP.
 *
 * Passcode comparison is constant-time (sha256 digests + timingSafeEqual).
 * Session tokens are `<expMs>.<hmac>` signed with a key derived from
 * SESSION_SECRET (if set) + the passcode, so rotating the passcode revokes
 * every session. The passcode is never logged or returned.
 */
import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import type { Request, Response, NextFunction } from "express";

export const DESK_SESSION_COOKIE = "desk_session";
export const DESK_SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const LEGACY_HEADER = "x-desk-admin-token";

export function deskPasscode(env: NodeJS.ProcessEnv = process.env): string | null {
  const t = (env.DESK_ADMIN_TOKEN ?? "").trim();
  return t.length > 0 ? t : null;
}

export function deskLockEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return deskPasscode(env) != null;
}

const sha = (s: string): Buffer => createHash("sha256").update(s, "utf8").digest();

/** Constant-time string compare (length-independent via fixed-size digests). */
export function constantTimeEqual(provided: unknown, expected: string): boolean {
  if (typeof provided !== "string" || provided.length === 0 || expected.length === 0) return false;
  return timingSafeEqual(sha(provided), sha(expected));
}

function signingKey(passcode: string): Buffer {
  return sha(`desk-session-v1|${process.env.SESSION_SECRET ?? ""}|${passcode}`);
}

export function createDeskSession(passcode: string, nowMs = Date.now()): string {
  const payload = String(nowMs + DESK_SESSION_TTL_MS);
  const sig = createHmac("sha256", signingKey(passcode)).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}

export function verifyDeskSession(token: unknown, passcode: string, nowMs = Date.now()): boolean {
  if (typeof token !== "string") return false;
  const dot = token.indexOf(".");
  if (dot <= 0) return false;
  const payload = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  const expected = createHmac("sha256", signingKey(passcode)).update(payload).digest("base64url");
  if (!constantTimeEqual(sig, expected)) return false;
  const exp = Number(payload);
  return Number.isFinite(exp) && nowMs < exp;
}

/** True when the request carries a valid session or the passcode itself. */
export function isDeskAuthorized(req: Request, passcode: string): boolean {
  const cookies = (req as Request & { cookies?: Record<string, string> }).cookies;
  if (verifyDeskSession(cookies?.[DESK_SESSION_COOKIE], passcode)) return true;
  const auth = req.get("authorization") ?? "";
  const bearer = /^Bearer\s+(.+)$/i.exec(auth)?.[1]?.trim();
  if (bearer && (verifyDeskSession(bearer, passcode) || constantTimeEqual(bearer, passcode))) return true;
  const legacy = req.get(LEGACY_HEADER);
  if (legacy && constantTimeEqual(legacy, passcode)) return true;
  return false;
}

const PUBLIC_PATHS = new Set(["/healthz", "/public/status"]);

export function isDeskPublicPath(p: string): boolean {
  return PUBLIC_PATHS.has(p) || p === "/auth" || p.startsWith("/auth/");
}

// D8 — per-process internal token for in-process SELF HTTP calls. Random at
// boot, never persisted, logged, or returned; replaces the loopback bypass
// (any same-host process or proxy misconfig could reach the API unauthenticated).
const INTERNAL_HEADER = "x-desk-internal";
const INTERNAL_TOKEN = randomBytes(32).toString("base64url");

/** Headers for the server's own in-process fetches to /api (agent SELF). */
export function deskInternalHeaders(): Record<string, string> {
  return { [INTERNAL_HEADER]: INTERNAL_TOKEN };
}

function isInternalCall(req: Request): boolean {
  const h = req.get(INTERNAL_HEADER);
  return typeof h === "string" && constantTimeEqual(h, INTERNAL_TOKEN);
}

/** Exported for the accounts gate (accounts/middleware.ts): same check, no bypass added. */
export function isDeskInternalRequest(req: Request): boolean {
  return isInternalCall(req);
}

/** Mount on /api BEFORE the router. */
export function requireDeskLock(req: Request, res: Response, next: NextFunction): void {
  const passcode = deskPasscode();
  if (!passcode) { next(); return; }
  if (req.method.toUpperCase() === "OPTIONS") { next(); return; }
  if (isDeskPublicPath(req.path)) { next(); return; }
  if (isInternalCall(req)) { next(); return; }
  if (isDeskAuthorized(req, passcode)) { next(); return; }
  res.status(401).json({ error: "Desk is locked — passcode required", deskLocked: true, adminTokenRequired: true });
}

// ── Login rate limit (fixed window per IP) ──────────────────────────────────

export function createLoginRateLimiter(opts: { max?: number; windowMs?: number } = {}) {
  const max = opts.max ?? 5;
  const windowMs = opts.windowMs ?? 60_000;
  const hits = new Map<string, { start: number; n: number }>();
  return {
    /** Returns {ok:false, retryAfterSec} when over the limit; counts the attempt. */
    hit(key: string, nowMs = Date.now()): { ok: true } | { ok: false; retryAfterSec: number } {
      if (hits.size > 5_000) {
        for (const [k, v] of hits) if (nowMs - v.start >= windowMs) hits.delete(k);
      }
      const cur = hits.get(key);
      if (!cur || nowMs - cur.start >= windowMs) {
        hits.set(key, { start: nowMs, n: 1 });
        return { ok: true };
      }
      cur.n += 1;
      if (cur.n > max) return { ok: false, retryAfterSec: Math.max(1, Math.ceil((cur.start + windowMs - nowMs) / 1000)) };
      return { ok: true };
    },
    reset(key: string) { hits.delete(key); },
  };
}

export const deskLoginLimiter = createLoginRateLimiter();

export function deskCookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict" as const,
    path: "/",
    maxAge: DESK_SESSION_TTL_MS,
  };
}
