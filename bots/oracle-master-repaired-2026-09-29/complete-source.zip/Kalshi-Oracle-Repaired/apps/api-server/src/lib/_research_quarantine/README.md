# `_research_quarantine/` — off money path

Modules here are **not** on the TradingBot evaluateEntry / placeOrder wire.

| Module | Why quarantined |
|--------|-----------------|
| `scalp-paper-fill.ts` | Separate scalp book paper fill; HARD_NO_FILL / PAPER_SCALP denylist; never ENABLE |

Stable re-exports may remain under `lib/` for research routes (`/api/scalp`) only.

`cheap-*` engines stay under `lib/` with QUARANTINE banners because strategy-library /
desk-library still import them for shadow/replay:
- `CHEAP_EARLY_EXIT` → HARD_NO_FILL (cannot placeOrder)
- `CHEAP_SIDE_15M` → dual-gate default false + disabledStrategies + leftover mayRun deny on paper+frozen (not HARD_NO_FILL; PAPER_TIER_A list retained)
- trading-bot never imports `cheap-*`

Rules:
- Do not import quarantine modules from `trading-bot.ts` or money-path organs.
- Do not ENABLE leftover cheap engines.
- paperMode stays true; EV≥3¢ / Kelly 0.60 floors intact.
