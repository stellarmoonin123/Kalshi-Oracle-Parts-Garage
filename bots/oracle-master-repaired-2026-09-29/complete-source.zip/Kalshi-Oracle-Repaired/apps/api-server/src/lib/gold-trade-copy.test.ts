/**
 * Gold-trade-copy: match Replit winning cells; LAG YES @44 → LAG_YES_42_50.
 * Does not cut EV/floors. Toxic LAG&lt;42 is not a gold match.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  matchGoldCell,
  preferGoldStrategyId,
  loadGoldCells,
  resetGoldCellsCache,
} from "./gold-trade-copy.js";
import { alignedTakeGate, LAG_ASK_BELOW_MIN_SKIP } from "./aligned-take-gate.js";
import { basisLagWinRate, BASIS_LAG_MAX_TIME_MINS } from "./basis-lag-edge.js";
import { confluenceWinRate, CONFLUENCE_MAX_TIME_MINS } from "./confluence-cascade.js";
import { getStrategy } from "./strategy-library.js";
import { EV_FLOOR } from "./admission.js";

const STRIKE_YES = { spot: 65_100, floorStrike: 65_000 } as const;
const STRIKE_NO = { spot: 64_900, floorStrike: 65_000 } as const;

const lagWr = (_side: "yes" | "no", ask: number) => basisLagWinRate(ask, 7);
const ccWr = (_side: "yes" | "no", ask: number) => confluenceWinRate(ask, 7);

test("locks: EV_FLOOR 3; gold cells load; toxic LAG&lt;42 present", () => {
  assert.equal(EV_FLOOR, 3);
  resetGoldCellsCache();
  const cells = loadGoldCells();
  assert.ok(cells.some((c) => c.cellId === "LAG_YES_42_50"));
  assert.ok(cells.some((c) => c.cellId === "CC_NO_50_62"));
  assert.ok(cells.some((c) => c.toxic === true && c.cellId === "LAG_CHEAP_LT42_TOXIC"));
});

test("LAG YES @44¢ matches LAG_YES_42_50 (sample CSV winners 1423/1677/1788)", () => {
  const m = matchGoldCell({
    strategyId: "BASIS_LAG_EDGE",
    side: "yes",
    ask: 44,
    lagProven: true,
  });
  assert.equal(m.match, true);
  assert.equal(m.cellId, "LAG_YES_42_50");
  assert.match(m.reason, /LAG_YES_42_50/);
  assert.equal(preferGoldStrategyId({
    side: "yes",
    ask: 44,
    lagProven: true,
  }), "BASIS_LAG_EDGE");
});

test("LAG YES @44 without lagProven is not gold", () => {
  const m = matchGoldCell({
    side: "yes",
    ask: 44,
    lagProven: false,
  });
  assert.equal(m.match, false);
});

test("LAG YES @38 toxic anti-cell — no gold match", () => {
  const m = matchGoldCell({
    strategyId: "BASIS_LAG_EDGE",
    side: "yes",
    ask: 38,
    lagProven: true,
  });
  assert.equal(m.match, false);
  assert.equal(m.reason, "toxic_anti_cell");
  assert.equal(m.cellId, "LAG_CHEAP_LT42_TOXIC");
});

test("CC YES @53 and CC NO @56 match gold cells (CSV HIGH_ODDS winners)", () => {
  const yes = matchGoldCell({
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    ask: 53,
  });
  assert.equal(yes.match, true);
  assert.equal(yes.cellId, "CC_YES_50_62");
  const no = matchGoldCell({
    strategyId: "CONFLUENCE_CASCADE",
    side: "no",
    ask: 56,
  });
  assert.equal(no.match, true);
  assert.equal(no.cellId, "CC_NO_50_62");
});

test("alignedTakeGate LAG YES @44 lagProven → TAKE goldCopy replitCell LAG_YES_42_50", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 44,
    noAsk: 56,
    lagProven: true,
    winRateAtPrice: lagWr,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "TAKE");
  if (g.kind !== "TAKE") return;
  assert.equal(g.strategyId, "BASIS_LAG_EDGE");
  assert.equal(g.side, "yes");
  assert.equal(g.ask, 44);
  assert.ok(g.ev >= EV_FLOOR);
  assert.equal(g.goldCopy, true);
  assert.equal(g.replitCell, "LAG_YES_42_50");
});

test("alignedTakeGate LAG ask 38 → TAKE under fill-power LAG floor 10 (toxic was <10)", () => {
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 38,
    noAsk: 62,
    lagProven: true,
    strategyId: "BASIS_LAG_EDGE",
    p: 0.62,
    ev: 8,
    secsRemaining: 180,
    spot: 65_100,
    floorStrike: 65_000,
  });
  assert.equal(g.kind, "TAKE");
  if (g.kind === "TAKE") {
    assert.equal(g.strategyId, "BASIS_LAG_EDGE");
    assert.equal(g.ask, 38);
  }
});

test("alignedTakeGate CC YES @53 → TAKE goldCopy CC_YES_50_62 (EV≥3 required)", () => {
  // Default confluenceWinRate(53) is EV&lt;3 — gold-copy never bypasses EV floor.
  // Pass a live-like p that clears EV≥3 so the Replit cell can be copied.
  const wrEv = (_side: "yes" | "no", _ask: number) => 0.72;
  const g = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 53,
    noAsk: 47,
    lagProven: false,
    strategyId: "CONFLUENCE_CASCADE",
    winRateAtPrice: wrEv,
    ...STRIKE_YES,
  });
  assert.equal(g.kind, "TAKE");
  if (g.kind !== "TAKE") return;
  assert.equal(g.strategyId, "CONFLUENCE_CASCADE");
  assert.equal(g.goldCopy, true);
  assert.equal(g.replitCell, "CC_YES_50_62");
  assert.ok(g.ev >= EV_FLOOR);
  const skipEv = alignedTakeGate({
    mtfSign: "long",
    yesAsk: 53,
    noAsk: 47,
    strategyId: "CONFLUENCE_CASCADE",
    winRateAtPrice: ccWr,
    ...STRIKE_YES,
  });
  assert.equal(skipEv.kind, "SKIP", "gold cell without EV≥3 must not fill");
});

test("alignedTakeGate CC NO @56 strike NO → SKIP ask_out_of_band (max 55); gold cell may still match for tag", () => {
  const g = alignedTakeGate({
    mtfSign: "short",
    yesAsk: 70,
    noAsk: 56,
    lagProven: false,
    strategyId: "CONFLUENCE_CASCADE",
    p: 0.72,
    ev: 8,
    secsRemaining: 180,
    spot: 64_900,
    floorStrike: 65_000,
  });
  assert.equal(g.kind, "SKIP");
  if (g.kind === "SKIP") assert.equal(g.reason, "ask_out_of_band");
  // Gold matcher may still recognize the cell shape for logging/tags.
  const m = matchGoldCell({
    strategyId: "CONFLUENCE_CASCADE",
    side: "no",
    ask: 56,
  });
  assert.equal(m.match, true);
  assert.equal(m.cellId, "CC_NO_50_62");
});

test("fill-power: CC/LAG library maxTimeMins match module hard max (evaluateAllStrategies)", () => {
  // Gold 14–15m tags are useless if evaluateAllStrategies skips meta max 11/13.
  assert.equal(CONFLUENCE_MAX_TIME_MINS, 15);
  assert.equal(BASIS_LAG_MAX_TIME_MINS, 15);
  assert.equal(getStrategy("CONFLUENCE_CASCADE")!.maxTimeMins, CONFLUENCE_MAX_TIME_MINS);
  assert.equal(getStrategy("BASIS_LAG_EDGE")!.maxTimeMins, BASIS_LAG_MAX_TIME_MINS);
});
