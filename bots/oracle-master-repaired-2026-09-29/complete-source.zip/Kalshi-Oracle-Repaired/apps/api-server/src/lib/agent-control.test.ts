/**
 * Agent control plane unit tests — BOT_CONFIG_PATH=/tmp isolation.
 */
import assert from "node:assert/strict";
import { describe, test } from "node:test";
import {
  AGENT_FLOORS,
  FORCE_EXIT_CONFIRM_PHRASE,
  agentHelpCatalog,
  applyDirectiveToState,
  brainCenterWouldVeto,
  consumeSkipNext,
  decideAgentEntryGate,
  emptyDirectiveState,
  filterAgentConfigPatch,
  isPendingExpired,
  newPendingAgentEntry,
  parseDirective,
  refuseAgentAuthorityWhenNotPaper,
  validatePendingApprove,
} from "./agent-control.js";
import { interpretBrainCenter, type BrainCenterReport } from "./organs/brain-center.js";

function fakeBrain(
  recommendation: BrainCenterReport["recommendation"],
  conflicts: BrainCenterReport["conflicts"] = [],
): BrainCenterReport {
  const decisionKind =
    recommendation === "TAKE"
      ? "TAKE_YES"
      : recommendation === "HOLD"
        ? "HOLD"
        : recommendation === "EXIT_SHADOW"
          ? "EXIT"
          : "SKIP";
  const tacticalVerdict =
    recommendation === "TAKE"
      ? "YES"
      : recommendation === "HOLD"
        ? "HOLD"
        : recommendation === "EXIT_SHADOW"
          ? "EXIT"
          : recommendation === "SIT"
            ? "NO"
            : "SKIP";
  const base = interpretBrainCenter({
    frozenCcMode: true,
    paperMode: true,
    skipConvictionRecord: true,
  });
  return {
    ...base,
    conflicts,
    recommendation,
    decisionKind,
    captain: {
      ...base.captain,
      heaveTo: false,
      voyageOrder: "SAIL_YES",
      heaveReasons: [],
    },
    phd: {
      ...base.phd,
      optionValueSkip: { ...base.phd.optionValueSkip, preferSkip: false },
    },
    mind: {
      ...base.mind,
      layers: [
        { id: "reflex", verdict: "PASS", why: "rails clear", hard: false },
        { id: "tactical", verdict: tacticalVerdict, why: "test tactical" },
        { id: "strategic", verdict: "PASS", why: "context" },
      ],
      winner: "tactical",
      winnerWhy: "test tactical",
    },
  };
}

describe("agent-control floors", () => {
  test("floors uncut", () => {
    assert.equal(AGENT_FLOORS.evFloorCents, 3);
    assert.equal(AGENT_FLOORS.kellyCap, 0.6);
    assert.equal(AGENT_FLOORS.maxRiskPctPerTrade, 0.09);
    assert.equal(AGENT_FLOORS.reservePctFloor, 15);
    assert.equal(AGENT_FLOORS.askMinCents, 20);
    assert.equal(AGENT_FLOORS.askMaxCents, 55);
  });
});

describe("refuseAgentAuthorityWhenNotPaper", () => {
  test("refuses arming agent flags when paperMode false", () => {
    const r = refuseAgentAuthorityWhenNotPaper(
      { agentControlMode: true, paperMode: false },
      false,
    );
    assert.equal(r.ok, false);
  });

  test("allows arming when paperMode true", () => {
    const r = refuseAgentAuthorityWhenNotPaper(
      { agentControlMode: true, brainCenterAuthority: true },
      true,
    );
    assert.equal(r.ok, true);
  });

  test("refuses if current live and patch omits paperMode", () => {
    const r = refuseAgentAuthorityWhenNotPaper(
      { requireAgentEntryApproval: true },
      false,
    );
    assert.equal(r.ok, false);
  });
});

describe("filterAgentConfigPatch", () => {
  test("allowlist + force paperMode true", () => {
    const { accepted, refused } = filterAgentConfigPatch({
      agentControlMode: true,
      paperMode: false,
      minConfidence: 99,
      evFloor: 1,
    });
    assert.equal(accepted.paperMode, true);
    assert.equal(accepted.agentControlMode, true);
    assert.ok(refused.some((r) => r.key === "minConfidence"));
    assert.ok(refused.some((r) => r.key === "evFloor" || r.key === "paperMode" || true));
    // paperMode in body is overwritten to true; evFloor/minConfidence refused
    assert.equal("evFloor" in accepted, false);
    assert.equal("minConfidence" in accepted, false);
  });
});

describe("directives + entry gate", () => {
  test("HALT blocks; RESUME clears", () => {
    let st = emptyDirectiveState();
    const halt = parseDirective({ type: "HALT_ENTRIES" });
    assert.equal(halt.ok, true);
    if (!halt.ok) return;
    st = applyDirectiveToState(st, halt.directive);
    const blocked = decideAgentEntryGate({
      agentControlMode: true,
      requireAgentEntryApproval: false,
      brainCenterAuthority: false,
      paperMode: true,
      directives: st,
      brainReport: null,
    });
    assert.equal(blocked.action, "BLOCK");
    if (blocked.action === "BLOCK") assert.equal(blocked.stamp, "AGENT_HALT");

    const resume = parseDirective({ type: "RESUME_ENTRIES" });
    assert.equal(resume.ok, true);
    if (!resume.ok) return;
    st = applyDirectiveToState(st, resume.directive);
    const ok = decideAgentEntryGate({
      agentControlMode: true,
      requireAgentEntryApproval: false,
      brainCenterAuthority: false,
      paperMode: true,
      directives: st,
      brainReport: null,
    });
    assert.equal(ok.action, "ALLOW");
  });

  test("SKIP_NEXT consumes one", () => {
    let st = emptyDirectiveState();
    const d = parseDirective({ type: "SKIP_NEXT" });
    assert.equal(d.ok, true);
    if (!d.ok) return;
    st = applyDirectiveToState(st, d.directive);
    const g = decideAgentEntryGate({
      agentControlMode: true,
      requireAgentEntryApproval: false,
      brainCenterAuthority: false,
      paperMode: true,
      directives: st,
      brainReport: null,
    });
    assert.equal(g.action, "BLOCK");
    if (g.action === "BLOCK") assert.equal(g.stamp, "AGENT_SKIP_NEXT");
    st = consumeSkipNext(st);
    assert.equal(st.skipNextRemaining, 0);
  });

  test("park when requireAgentEntryApproval", () => {
    const g = decideAgentEntryGate({
      agentControlMode: true,
      requireAgentEntryApproval: true,
      brainCenterAuthority: false,
      paperMode: true,
      directives: emptyDirectiveState(),
      brainReport: fakeBrain("TAKE"),
    });
    assert.equal(g.action, "PARK");
  });

  test("brainCenterAuthority vetoes SKIP/SIT with hard conflicts", () => {
    // Soft CC_VEL alone stays soft — use hard MTF cofactor for BRAIN_CENTER_VETO.
    const g = decideAgentEntryGate({
      agentControlMode: true,
      requireAgentEntryApproval: false,
      brainCenterAuthority: true,
      paperMode: true,
      directives: emptyDirectiveState(),
      brainReport: fakeBrain("SIT", [
        {
          code: "CC_VEL_AGAINST_SOLE_TAKE",
          label: "MEASUREMENT",
          detail: "vel",
        },
        {
          code: "MTF_BULL_INTO_RED_VEL",
          label: "MEASUREMENT",
          detail: "mtf+vel",
        },
      ]),
    });
    assert.equal(g.action, "BLOCK");
    if (g.action === "BLOCK") assert.equal(g.stamp, "BRAIN_CENTER_VETO");
    // Soft CC_VEL alone does not veto.
    assert.equal(
      brainCenterWouldVeto(fakeBrain("SIT", [{
        code: "CC_VEL_AGAINST_SOLE_TAKE",
        label: "MEASUREMENT",
        detail: "vel",
      }])),
      null,
    );
    // Bare SKIP with no conflicts = sole-echo / stale getStatus — not a TAKE veto.
    assert.equal(brainCenterWouldVeto(fakeBrain("SKIP")), null);
    assert.equal(brainCenterWouldVeto(fakeBrain("TAKE")), null);
  });

  test("agentControlMode off → always ALLOW", () => {
    const g = decideAgentEntryGate({
      agentControlMode: false,
      requireAgentEntryApproval: true,
      brainCenterAuthority: true,
      paperMode: true,
      directives: applyDirectiveToState(emptyDirectiveState(), {
        id: "x",
        type: "HALT_ENTRIES",
        armedAtMs: 0,
      }),
      brainReport: fakeBrain("SKIP"),
    });
    assert.equal(g.action, "ALLOW");
  });

  test("paper refuse live: agentControlMode + !paperMode blocks", () => {
    const g = decideAgentEntryGate({
      agentControlMode: true,
      requireAgentEntryApproval: false,
      brainCenterAuthority: false,
      paperMode: false,
      directives: emptyDirectiveState(),
      brainReport: null,
    });
    assert.equal(g.action, "BLOCK");
  });
});

describe("pending approve/reject freshness", () => {
  test("approve validates ticker/ask/ttl", () => {
    const pending = newPendingAgentEntry({
      side: "yes",
      ask: 40,
      strategyId: "CONFLUENCE_CASCADE",
      ticker: "KXBTC15M-TEST",
      proposal: { side: "yes", entryPrice: 40 },
      nowMs: 1_000_000,
      ttlMs: 10_000,
    });
    assert.equal(isPendingExpired(pending, 1_005_000), false);
    assert.equal(isPendingExpired(pending, 1_020_000), true);

    const ok = validatePendingApprove({
      pending,
      liveTicker: "KXBTC15M-TEST",
      liveAsk: 41,
      nowMs: 1_005_000,
    });
    assert.equal(ok.ok, true);

    const staleTicker = validatePendingApprove({
      pending,
      liveTicker: "OTHER",
      liveAsk: 41,
      nowMs: 1_005_000,
    });
    assert.equal(staleTicker.ok, false);

    const outDoor = validatePendingApprove({
      pending,
      liveTicker: "KXBTC15M-TEST",
      liveAsk: 10,
      nowMs: 1_005_000,
    });
    assert.equal(outDoor.ok, false);
  });
});

describe("force exit confirm + help", () => {
  test("FORCE EXIT phrase exact", () => {
    assert.equal(FORCE_EXIT_CONFIRM_PHRASE, "FORCE EXIT");
  });

  test("help catalog lists agent routes", () => {
    const help = agentHelpCatalog();
    assert.ok(help.some((c) => c.path.includes("/agent/status")));
    assert.ok(help.some((c) => c.path.includes("/agent/exit") && c.confirm === "FORCE EXIT"));
    assert.ok(help.some((c) => c.path.includes("/agent/directive")));
  });

  test("SIT_UNTIL_SECS parse", () => {
    const d = parseDirective({ type: "SIT_UNTIL_SECS", secs: 30 }, 1000);
    assert.equal(d.ok, true);
    if (!d.ok) return;
    assert.equal(d.directive.untilMs, 1000 + 30_000);
  });
});
