import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { evaluate15mAdmissionEnvelope } from "./decision-envelope.js";

test("paper admission envelope admits CC in the 20–55 door excluding 48–52", () => {
  const env = evaluate15mAdmissionEnvelope({
    paperMode: true,
    ticker: "KXBTC15M-26SEP151200-00",
    strategyId: "CONFLUENCE_CASCADE",
    askCents: 40,
    frozenCc: true,
    nowMs: 1,
  });
  assert.equal(env.admit, true);
  assert.equal(env.blockReason, null);
  assert.equal(env.llmMayVetoEntry, false);
  assert.equal(env.llmMayVetoExit, false);
});

test("LLM cannot be wired as a veto: envelope flags are literal false", () => {
  const env = evaluate15mAdmissionEnvelope({
    paperMode: true, ticker: "KXBTC15M-x", strategyId: "OTHER", askCents: 40, frozenCc: true,
  });
  assert.equal(env.admit, false);
  assert.equal(env.llmMayVetoEntry, false);
});

test("trading-bot uses the envelope at placeOrder", () => {
  const src = fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), "trading-bot.ts"), "utf8");
  assert.match(src, /evaluate15mAdmissionEnvelope/);
  assert.match(src, /organAction: this\.lastOrganReport\?\.action/);
  assert.doesNotMatch(src, /llmMayVetoEntry:\s*true/);
  assert.doesNotMatch(src, /admission envelope drifted from paper release/);
});

test("envelope is the sole admit: director skip-abort denies; frozen six-gate still admits", () => {
  const skip = evaluate15mAdmissionEnvelope({
    paperMode: true,
    ticker: "KXBTC15M-26SEP151200-00",
    strategyId: "CONFLUENCE_CASCADE",
    askCents: 40,
    frozenCc: true,
    side: "yes",
    organAction: "skip",
    organReason: "ev_below_floor",
    frozenSixGateFill: false,
  });
  assert.equal(skip.admit, false);
  assert.equal(skip.blockReason, "DIRECTOR_SKIP:ev_below_floor");
  assert.equal(skip.llmMayVetoEntry, false);

  const frozen = evaluate15mAdmissionEnvelope({
    paperMode: true,
    ticker: "KXBTC15M-26SEP151200-00",
    strategyId: "CONFLUENCE_CASCADE",
    askCents: 40,
    frozenCc: true,
    side: "yes",
    organAction: "skip",
    organReason: "ev_below_floor",
    frozenSixGateFill: true,
    organP: 0.62,
    organEv: 4,
    organSize: 17,
  });
  assert.equal(frozen.admit, true);
  assert.equal(frozen.p, 0.62);
  assert.equal(frozen.ev, 4);
  assert.equal(frozen.size, 17);
});
