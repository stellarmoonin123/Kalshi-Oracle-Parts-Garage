/**
 * entry-price-band.test.ts
 *
 * Regression test for Task #368 code review round 4: the historical
 * backtester's entry-price band gate (getEntryPriceBand) produced
 * `tradesPlaced: 0` across a multi-thousand-scenario run because
 * simulateKalshiTrade priced every entry as (true win probability ± a
 * few cents), making the ask tautologically track the strategy's own
 * probability read. Any strategy whose signal criteria only fires on
 * already-lopsided setups (e.g. FLOOR_DISTANCE, LATE_ENTRY_ANCHOR) could
 * then never produce an entryPrice inside its band, so the newly added
 * gate rejected every single trade.
 *
 * This test proves, independently of whatever buildSimObs happens to
 * generate from real candle data, that simulateKalshiTrade's pricing
 * model CAN still land inside every strategy's own entry-price band
 * (standard, each named OTM band, and the hourly-generic band) — i.e.
 * the band gate is satisfiable, not structurally empty.
 *
 * It also proves the OTM sizing gate in trading-bot.ts now judges EV
 * with the bot's real per-side fee model (kalshiNetWinCents /
 * kalshiNetCostCents), not a flat (1 - KALSHI_TAKER_FEE) haircut on the
 * gross payout, which understated the fee drag near less-extreme OTM
 * entries and could let a boundary-probability trade slip through as
 * "profitable" when it was actually break-even or negative once the
 * real min(entry, 100-entry) × 7% fee is applied.
 *
 * Run with:  tsx --test src/lib/entry-price-band.test.ts
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { simulateKalshiTrade } from "./historical-backtester.js";
import {
  getEntryPriceBand,
  kalshiNetWinCents,
  kalshiNetCostCents,
} from "./constants.js";
import type { StrategyObservation } from "./strategy-library.js";

// ── Helpers ─────────────────────────────────────────────────────────────────

function makeObs(massAboveFloor: number): StrategyObservation {
  return {
    currentPrice: 65_000,
    floorStrike: 65_000,
    velocityDolPerMin: 0,
    threeMinVelocity: 0,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0,
    massAboveFloor,
    secsRemaining: 600,
  };
}

/** Fraction of `trials` simulated entries that land inside [min, max]. */
function inBandRate(
  strategyId: string,
  massAboveFloor: number,
  band: { min: number; max: number },
  trials = 400,
): number {
  let hits = 0;
  for (let i = 0; i < trials; i++) {
    const obs = makeObs(massAboveFloor);
    const result = simulateKalshiTrade("YES", strategyId, strategyId, 0.7, obs, 65_500);
    if (result.entryPrice >= band.min && result.entryPrice <= band.max) hits++;
  }
  return hits / trials;
}

// ── Each strategy band must be reachable ─────────────────────────────────────

test("standard 20-55¢ band is reachable for a generic (non-OTM) strategy", () => {
  const band = getEntryPriceBand("VELOCITY_MOMENTUM");
  assert.deepEqual(band, { min: 20, max: 55 });
  // massAboveFloor at the band midpoint — most quotes should land in-band.
  const rate = inBandRate("VELOCITY_MOMENTUM", 45, band);
  assert.ok(rate > 0.5, `expected >50% of quotes in-band, got ${(rate * 100).toFixed(0)}%`);
});

test("OTM_ASYMMETRY's 5-25¢ band is reachable", () => {
  const band = getEntryPriceBand("OTM_ASYMMETRY");
  assert.deepEqual(band, { min: 5, max: 25 });
  const rate = inBandRate("OTM_ASYMMETRY", 15, band);
  assert.ok(rate > 0.5, `expected >50% of quotes in-band, got ${(rate * 100).toFixed(0)}%`);
});

test("DEEP_OTM_SNIPER's 5-14¢ band is reachable", () => {
  const band = getEntryPriceBand("DEEP_OTM_SNIPER");
  assert.deepEqual(band, { min: 5, max: 14 });
  const rate = inBandRate("DEEP_OTM_SNIPER", 9, band);
  assert.ok(rate > 0.5, `expected >50% of quotes in-band, got ${(rate * 100).toFixed(0)}%`);
});

test("OTM_BREAKOUT_EXPANSION's 11-38¢ band is reachable", () => {
  const band = getEntryPriceBand("OTM_BREAKOUT_EXPANSION");
  assert.deepEqual(band, { min: 11, max: 38 });
  const rate = inBandRate("OTM_BREAKOUT_EXPANSION", 24, band);
  assert.ok(rate > 0.5, `expected >50% of quotes in-band, got ${(rate * 100).toFixed(0)}%`);
});

test("hourly-generic 15-85¢ band is reachable for a non-breakout strategy on a 60-min contract", () => {
  const band = getEntryPriceBand("VELOCITY_MOMENTUM", { contractDurationMins: 60 });
  assert.deepEqual(band, { min: 15, max: 85 });
  const rate = inBandRate("VELOCITY_MOMENTUM", 50, band);
  assert.ok(rate > 0.5, `expected >50% of quotes in-band, got ${(rate * 100).toFixed(0)}%`);
});

test("a strategy that only fires on already-lopsided setups (~85% true prob) can still occasionally clear the standard band", () => {
  // This is the exact FLOOR_DISTANCE / LATE_ENTRY_ANCHOR shape the review
  // flagged: trueProb is high because the signal only fires once price is
  // clearly displaced from the floor. The old tautological pricing model
  // made this structurally impossible; the lagged-quote model must allow a
  // non-zero (even if minority) rate of in-band fills.
  const band = getEntryPriceBand("FLOOR_DISTANCE");
  // Seeded RNG: the pricing model is stochastic and an unseeded 2000-trial
  // run occasionally produced 0 in-band hits (flaky). Deterministic now.
  const realRandom = Math.random;
  let seed = 0x9e3779b9;
  Math.random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2 ** 32; };
  let rate: number;
  try { rate = inBandRate("FLOOR_DISTANCE", 85, band, 2000); } finally { Math.random = realRandom; }
  assert.ok(rate > 0, "expected at least some quotes to land in the standard band");
  assert.ok(rate < 0.5, "a lopsided setup should still be in-band the MINORITY of the time (mostly correctly rejected)");
});

test("PAPER_SCALP uses its own 7–55¢ band (not the 20–55 standard band)", () => {
  const band = getEntryPriceBand("PAPER_SCALP");
  assert.deepEqual(band, { min: 7, max: 55 });
  const standard = getEntryPriceBand("VELOCITY_MOMENTUM");
  assert.deepEqual(standard, { min: 20, max: 55 });
  const rate = inBandRate("PAPER_SCALP", 30, band);
  assert.ok(rate > 0.5, `expected >50% of quotes in-band, got ${(rate * 100).toFixed(0)}%`);
});

test("PAPER_SCALP band is independent of hourly generic 15–85 overlay", () => {
  const band = getEntryPriceBand("PAPER_SCALP", { contractDurationMins: 60 });
  assert.deepEqual(band, { min: 7, max: 55 }, "fixed PAPER_SCALP band wins over hourly generic");
});

// ── OTM sizing gate uses the real per-side fee model ─────────────────────────

test("net payout ratio at a boundary OTM price matches kalshiNetWinCents/kalshiNetCostCents, not a flat payout haircut", () => {
  const entryPrice = 35; // near OTM_BREAKOUT_EXPANSION's 38¢ upper bound
  const netWin  = kalshiNetWinCents(entryPrice);
  const netCost = kalshiNetCostCents(entryPrice);
  const netPayoutRatio = netWin / netCost;

  const grossPayoutMultiple = (100 - entryPrice) / entryPrice;
  const flatHaircutApprox = grossPayoutMultiple * 0.93; // the old, rejected approximation

  // The real net ratio must differ meaningfully from the flat-haircut
  // approximation at a mid-range OTM price — if they matched, the review's
  // "wrong fee model" finding would not reproduce.
  assert.ok(
    Math.abs(netPayoutRatio - flatHaircutApprox) > 0.02,
    `expected the real net ratio (${netPayoutRatio.toFixed(3)}) to diverge from the flat-haircut ` +
    `approximation (${flatHaircutApprox.toFixed(3)}) at a mid-range OTM price`
  );
});

test("OTM EV gate rejects a strategy win-rate that is only profitable under the flat-haircut approximation, not the real fee model", () => {
  // Construct a win rate that clears `otmEdge > 0` under the old flat
  // 7%-of-gross-payout approximation but is actually negative EV once
  // judged by the real min(entry,100-entry)×7% fee on cost.
  const entryPrice = 35;
  const netWin  = kalshiNetWinCents(entryPrice);
  const netCost = kalshiNetCostCents(entryPrice);

  const grossPayoutMultiple = (100 - entryPrice) / entryPrice;
  const flatHaircutPayout = grossPayoutMultiple * 0.93;

  // Breakeven win rate under each model. The old flat-haircut approximation
  // overstates the payout ratio at this price, so its breakeven WR is lower
  // than the real one — any WR strictly between the two looks profitable
  // under the old model but is actually negative EV under the real fee model.
  const oldBreakevenWR  = 1 / (1 + flatHaircutPayout);
  const realBreakevenWR = netCost / (netWin + netCost);
  assert.ok(oldBreakevenWR < realBreakevenWR, "sanity check: flat-haircut approximation should be more optimistic (lower breakeven WR)");

  const testWR = (oldBreakevenWR + realBreakevenWR) / 2;

  // Under the OLD flat-haircut approximation this win rate looks profitable...
  const oldEdge = testWR * flatHaircutPayout - (1 - testWR);
  assert.ok(oldEdge > 0, "sanity check: old approximation should look profitable at this win rate");

  // ...but under the CORRECT real-fee model (what the gate now uses) it is
  // negative EV and must be rejected (`otmEdge <= 0` → skip the trade).
  const realEdge = testWR * netWin - (1 - testWR) * netCost;
  assert.ok(realEdge < 0, "the real-fee model must show this win rate as negative EV, catching what the old approximation missed");
});
