/**
 * chat-free-llm.ts
 *
 * Chat-tab completions only. Groq qwen/qwen3.8-27b first when GROQ_API_KEY
 * is set (preferred free Chat); else Gemini generateContent (AI Studio).
 * Never OpenRouter. Never used by trading evaluate.
 *
 * Gemini may call desk read_file, list_dir, grep/search (read-only). Write,
 * test and bounce tools are refused at runtime; proposals are text only.
 * The executor HARD REJECTS lock-breaking writes. Groq is text-only fallback.
 */
import { DESK_KNOWLEDGE_SUMMARY } from "./desk-knowledge.js";
import type { DeskSnapshot } from "./oracle-desk-chat.js";
import { GEMINI_CODE_EDIT_DECLARATIONS } from "./chat-code-edit.js";
import { oracleV2ChatDoctrineCondensed } from "./organs/oracle-v2-doctrine.js";

export const GEMINI_FLASH_API_MODEL = "gemini-3.6-flash";
export const GEMINI_FLASH_API_FALLBACKS = ["gemini-3.6-flash", "gemini-flash-latest", "gemini-3.5-flash"] as const;
export const GROQ_LLAMA_MODEL = "openai/gpt-oss-120b"; // best free on Groq (2026-09-05)
export const GROQ_CHAT_MODEL_FALLBACKS = [
  "openai/gpt-oss-120b",
  "openai/gpt-oss-20b",
  "qwen/qwen3.8-27b",
] as const;

export type EnvLike = NodeJS.Dict<string>;

export function geminiApiKey(env: EnvLike = process.env): string {
  const a = (env.GEMINI_API_KEY ?? "").trim();
  if (a) return a;
  return (env.GOOGLE_GENERATIVE_AI_API_KEY ?? "").trim();
}

export function groqApiKey(env: EnvLike = process.env): string {
  return (env.GROQ_API_KEY ?? "").trim();
}

export function geminiKeyPresent(env: EnvLike = process.env): boolean {
  return geminiApiKey(env).length > 0;
}

export function groqKeyPresent(env: EnvLike = process.env): boolean {
  return groqApiKey(env).length > 0;
}

function dollars(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

export type ChatTurn = { role: string; content: string };

export function chatSystemPrompt(snapshot: DeskSnapshot): string {
  const cash = snapshot.paperLedgerCents ?? snapshot.paperVirtualCents;
  return [
    "You are Oracle Chat — the full desk AGENT for this Kalshi 15m paper box.",
    "Talk like a sharp trading friend. Answer the user's actual question. Use conversation history.",
    "You HAVE read-only tools. Use them: read_file, list_dir, grep, get_paper_ledger, get_bot_config, tail_tape. You cannot write files, run tests or restart anything — propose changes as a unified diff in your reply.",
    "Tools run SERVER-SIDE only. NEVER print <tool_call>, <function=, </function>, or any tool XML/markup in your reply to the user — only clean prose.",
    "Do not guess file contents. Read first. Then propose a patch as text; a human applies it through the reviewed release workflow.",
    "The live snapshot below is CONTEXT, not a script. Do not paste a canned diagnosis unless they ask why idle / status / skip.",
    "You may NOT edit desk source at runtime. Inspect and propose only.",
    "CODE TOOLS: read_file (use start_line/end_line on large files), list_dir, grep/search. Read/propose-only.",
    "Nothing is writable from chat. Proposals are reviewed and shipped through the release workflow.",
    "Proposals must never (and the release lint rejects any that):",
    "- sets paperMode false or removes paperMode true without LIVE REAL MONEY in the SAME user message (always refuse paperMode false)",
    "- lowers EV floor below 3¢, Kelly cap below 0.60, 9% cap, 15% reserve, or daily halt",
    "- ENABLE's SEV1, OTM, SP, PAPER_SCALP, hourly, perps, SETTLEMENT_LAG, persist-mid, cheap-persist, panic fade",
    "- prints or rewrites .env / keys",
    "ARIA / ExpertAgent stays OFF. Never recommend turning it on.",
        "You cannot run: update_config, toggle_strategy, force_exit_trade, apply-backtest-config,",
    "spawn_subagent, control_bot, reset_paper_sim, run_backtest, run_shell.",
    "If asked to loosen locks, refuse. If a tool comes back refused, tell the operator the lock held — do not retry a weaker version of the same write.",
    "p = winRateAtPrice, not confidence. Skip is valid.",
    "Never invent fills, balances, or live books not in this snapshot. Tick/autopilot stay LLM-free.",
    "",
    oracleV2ChatDoctrineCondensed(),
    "",
    DESK_KNOWLEDGE_SUMMARY.replace("call get_desk_knowledge", "see the desk-agent tool get_desk_knowledge / src/lib/desk-knowledge.ts"),
    "",
    `LIVE SNAPSHOT: ${snapshot.paperMode ? "PAPER" : "LIVE"} ${dollars(cash)} · state=${snapshot.state}`,
    `ARIA=${snapshot.useExpertAgent ? "ON" : "OFF"} composer=${snapshot.autoMode ? "ON" : "OFF"} 1h=${snapshot.enable1HContracts ? "ON" : "OFF"}`,
    `Classification: ${snapshot.classification}`,
    snapshot.headline,
    `Recommendation: ${snapshot.recommendation}`,
    `Last signal: ${snapshot.lastSignal || "(none)"}`,
    `Regime: ${snapshot.detectedRegime ?? "unclassified"} · strategy: ${snapshot.activeStrategy ?? "none"}`,
    snapshot.regimeRtLine ? snapshot.regimeRtLine : "R_t n/a",
    `Pack ${snapshot.packId ?? "n/a"} (log-only)${snapshot.packSkipReason ? ` · pack skip ${snapshot.packSkipReason}` : ""}`,
    `Today ${snapshot.todayWins}W/${snapshot.todayLosses}L P&L ${snapshot.todayPnlCents}¢ consecLosses=${snapshot.consecutiveLosses}`,
    `Blockers: ${snapshot.activeBlockers.length ? snapshot.activeBlockers.join("; ") : "none (wait, not a bug)"}`,
    snapshot.projLine,
  ].join("\n");
}

export type ChatToolEvent =
  | { type: "tool_start"; name: string; label: string }
  | { type: "tool_done"; name: string; summary: string };

export interface ChatLlmResult {
  text: string;
  provider: "gemini" | "groq";
  model: string;
  toolEvents?: ChatToolEvent[];
}

export type ChatToolHandler = (
  name: string,
  args: Record<string, unknown>,
) => Record<string, unknown>;

const TOOL_LABELS: Record<string, string> = {
  read_file: "Reading file…",
  list_dir: "Listing directory…",
  list_files: "Listing directory…",
  grep: "Searching code…",
  search: "Searching code…",
  search_code: "Searching code…",
  apply_patch: "Applying patch…",
  write_file: "Writing file…",
  run_tests: "Running api-server tests…",
  bounce_api: "Bouncing API (:8080 only)…",
  get_paper_ledger: "Reading paper ledger…",
  get_bot_config: "Reading bot config…",
  tail_tape: "Tailing paper tape…",
};

/** True when assistant text leaked raw tool-call markup (must never reach Chat UI). */
export function containsRawToolCallMarkup(text: string): boolean {
  if (!text) return false;
  return /<\/?tool_call\b|<function\s*=|<\/function\s*>|<invoke\b|<\/invoke>/i.test(text);
}

export type ParsedTextToolCall = { name: string; args: Record<string, unknown> };

/**
 * Parse pseudo tool calls some models emit as text, e.g.
 * `<tool_call> <function=get_paper_ledger> </function> </tool_call>`
 * or `<function=read_file>{"path":"x"}</function>`.
 */
export function parseTextToolCalls(text: string): ParsedTextToolCall[] {
  if (!text) return [];
  const calls: ParsedTextToolCall[] = [];
  const re = /<function\s*=\s*([A-Za-z0-9_]+)\s*>([\s\S]*?)<\/function>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    const name = m[1];
    const body = (m[2] ?? "").trim();
    let args: Record<string, unknown> = {};
    if (body) {
      try {
        const parsed = JSON.parse(body) as unknown;
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          args = parsed as Record<string, unknown>;
        }
      } catch {
        const paramRe = /<parameter\s+name=["']([^"']+)["']\s*>([\s\S]*?)<\/parameter>/gi;
        let pm: RegExpExecArray | null;
        while ((pm = paramRe.exec(body)) !== null) {
          args[pm[1]] = pm[2].trim();
        }
      }
    }
    calls.push({ name, args });
  }
  return calls;
}

/** Strip tool XML so Chat never shows raw tool-call markup. */
export function stripRawToolCallMarkup(text: string): string {
  if (!text) return "";
  let out = text;
  out = out.replace(/<tool_call\b[\s\S]*?<\/tool_call>/gi, "");
  out = out.replace(/<function\s*=[\s\S]*?<\/function>/gi, "");
  out = out.replace(/<invoke\b[\s\S]*?<\/invoke>/gi, "");
  out = out.replace(/<\/?tool_call\b[^>]*>/gi, "");
  out = out.replace(/<\/?function\b[^>]*>/gi, "");
  out = out.replace(/<\/?invoke\b[^>]*>/gi, "");
  out = out.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  return out;
}

function finalizeAssistantText(text: string): string {
  const cleaned = stripRawToolCallMarkup(text);
  if (cleaned) return cleaned;
  if (containsRawToolCallMarkup(text)) {
    return "Desk tools ran server-side. Ask again if you need the prose summary — locks still hold (paper, EV floors, ARIA off).";
  }
  return text.trim();
}

function runNamedTool(
  runTool: ChatToolHandler,
  name: string,
  args: Record<string, unknown>,
  toolEvents: ChatToolEvent[],
): Record<string, unknown> {
  toolEvents.push({
    type: "tool_start",
    name,
    label: TOOL_LABELS[name] ?? name,
  });
  let result: Record<string, unknown>;
  try {
    result = runTool(name, args);
  } catch {
    result = { ok: false, refused: true, reason: "tool failed clean (no write)" };
  }
  const summary = String(
    result.summary ?? result.reason ?? (result.ok ? `${name} ok` : `${name} refused`),
  );
  toolEvents.push({ type: "tool_done", name, summary });
  return result;
}

type GeminiPart = {
  text?: string;
  functionCall?: { name?: string; args?: Record<string, unknown> };
  functionResponse?: { name: string; response: Record<string, unknown> };
};

type GeminiContent = { role: string; parts: GeminiPart[] };

async function geminiGenerateOnce(
  system: string,
  contents: GeminiContent[],
  env: EnvLike,
  fetchImpl: typeof fetch,
  withTools: boolean,
): Promise<{ parts: GeminiPart[]; text: string; modelId: string } | null> {
  const key = geminiApiKey(env);
  if (!key) return null;
  const payload: Record<string, unknown> = {
    systemInstruction: { parts: [{ text: system }] },
    contents,
    generationConfig: { temperature: 0.7, maxOutputTokens: 8192 },
  };
  if (withTools) {
    payload.tools = [{ functionDeclarations: GEMINI_CODE_EDIT_DECLARATIONS }];
    payload.toolConfig = { functionCallingConfig: { mode: "AUTO" } };
  }
  let lastParts: GeminiPart[] | null = null;
  let lastText = "";
  for (const modelId of GEMINI_FLASH_API_FALLBACKS) {
    const url =
      `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent`;
    const resp = await fetchImpl(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": key,
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(45_000),
    });
    if (!resp.ok) continue;
    const data = (await resp.json()) as {
      candidates?: { content?: { parts?: GeminiPart[] } }[];
    };
    const parts = data.candidates?.[0]?.content?.parts ?? [];
    const text = parts.map((p) => p.text ?? "").join("").trim();
    lastParts = parts;
    lastText = text;
    if (parts.length > 0) return { parts, text, modelId };
  }
  if (lastParts) return { parts: lastParts, text: lastText, modelId: GEMINI_FLASH_API_MODEL };
  return null;
}

function toLlmTurns(opts: { question: string; messages?: ChatTurn[] }): ChatTurn[] {
  const raw = (opts.messages ?? []).filter((m) => m && typeof m.content === "string");
  const turns: ChatTurn[] = [];
  for (const m of raw) {
    const role = m.role === "assistant" || m.role === "model" ? "assistant" : "user";
    const content = m.content.trim();
    if (!content) continue;
    turns.push({ role, content });
  }
  if (turns.length === 0) {
    turns.push({ role: "user", content: opts.question.trim() || "(empty)" });
  } else if (turns[turns.length - 1].role !== "user") {
    const q = opts.question.trim();
    if (q) turns.push({ role: "user", content: q });
  }
  return turns.slice(-24);
}

function toGeminiContents(turns: ChatTurn[]): GeminiContent[] {
  return turns.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));
}

async function groqChatCompletions(
  system: string,
  turns: ChatTurn[],
  env: EnvLike,
  fetchImpl: typeof fetch,
): Promise<{ text: string; model: string } | null> {
  const key = groqApiKey(env);
  if (!key) return null;
  const models = typeof GROQ_CHAT_MODEL_FALLBACKS !== "undefined"
    ? GROQ_CHAT_MODEL_FALLBACKS
    : [GROQ_LLAMA_MODEL];
  for (const modelId of models) {
    try {
      const resp = await fetchImpl("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: modelId,
          messages: [
            { role: "system", content: system },
            ...turns.map((m) => ({ role: m.role, content: m.content })),
          ],
          temperature: 0.7,
          max_tokens: 4096,
        }),
        signal: AbortSignal.timeout(45_000),
      });
      if (!resp.ok) continue;
      const data = (await resp.json()) as {
        choices?: { message?: { content?: string | null } }[];
      };
      const text = data.choices?.[0]?.message?.content;
      if (typeof text === "string" && text.trim()) {
        return { text: text.trim(), model: modelId };
      }
    } catch {
      continue;
    }
  }
  return null;
}

const MAX_TOOL_ROUNDS = 8;

const TOOL_FOLLOWUP =
  "Tool results above are from the server. Answer the operator in clean prose only. "
  + "Never print <tool_call>, <function=, or any tool XML/markup.";

/**
 * Groq often emits XML tool calls as text (no native tool loop). Parse+execute
 * server-side, retry with results, and always strip markup before returning.
 */
async function groqCompleteWithTextTools(opts: {
  system: string;
  turns: ChatTurn[];
  env: EnvLike;
  fetchImpl: typeof fetch;
  toolsEnabled: boolean;
  runTool?: ChatToolHandler;
  toolEvents: ChatToolEvent[];
}): Promise<ChatLlmResult | null> {
  const working = opts.turns.map((t) => ({ ...t }));
  for (let round = 0; round < MAX_TOOL_ROUNDS; round += 1) {
    const groq = await groqChatCompletions(opts.system, working, opts.env, opts.fetchImpl);
    if (!groq) return null;
    const calls = opts.toolsEnabled && opts.runTool ? parseTextToolCalls(groq.text) : [];
    if (calls.length === 0 || !opts.runTool) {
      return {
        text: finalizeAssistantText(groq.text),
        provider: "groq",
        model: groq.model,
        toolEvents: opts.toolEvents,
      };
    }
    working.push({ role: "assistant", content: groq.text });
    const blocks: string[] = [];
    for (const call of calls) {
      const result = runNamedTool(opts.runTool, call.name, call.args, opts.toolEvents);
      blocks.push(`Tool ${call.name} result:\n${JSON.stringify(result)}`);
    }
    working.push({ role: "user", content: `${blocks.join("\n\n")}\n\n${TOOL_FOLLOWUP}` });
  }
  const lastDone = [...opts.toolEvents].reverse().find((e) => e.type === "tool_done");
  return {
    text: finalizeAssistantText(
      lastDone?.summary
        ? `Chat tool: ${lastDone.summary}. Locks still hold (paper, EV floors, ARIA off).`
        : "Chat tools finished. Locks still hold (paper, EV floors, ARIA off).",
    ),
    provider: "groq",
    model: GROQ_LLAMA_MODEL,
    toolEvents: opts.toolEvents,
  };
}

/**
 * Groq first when GROQ_API_KEY is set; else Gemini Flash;
 * null → Oracle desk snapshot. No OpenRouter.
 * Raw <tool_call>/<function= markup is never returned to Chat UI.
 */
export async function completeChatFreeLlm(opts: {
  question: string;
  snapshot: DeskSnapshot;
  env?: EnvLike;
  fetchImpl?: typeof fetch;
  toolsEnabled?: boolean;
  runTool?: ChatToolHandler;
  messages?: ChatTurn[];
  /** Prefer groq even if Gemini keyed (Chat default). */
  preferGroq?: boolean;
}): Promise<ChatLlmResult | null> {
  const env = opts.env ?? process.env;
  const fetchImpl = opts.fetchImpl ?? globalThis.fetch;
  const system = chatSystemPrompt(opts.snapshot);
  const q = opts.question.trim() || "(empty)";
  const turns = toLlmTurns({ question: q, messages: opts.messages });
  const toolsEnabled = Boolean(opts.toolsEnabled && opts.runTool);
  const toolEvents: ChatToolEvent[] = [];
  const preferGroq = opts.preferGroq !== false; // default true

  if (preferGroq && groqApiKey(env)) {
    try {
      const groq = await groqCompleteWithTextTools({
        system,
        turns,
        env,
        fetchImpl,
        toolsEnabled,
        runTool: opts.runTool,
        toolEvents,
      });
      if (groq) return groq;
    } catch {
      /* fall through to Gemini */
    }
  }

  try {
    const contents: GeminiContent[] = toGeminiContents(turns);
    for (let round = 0; round < MAX_TOOL_ROUNDS; round += 1) {
      const got = await geminiGenerateOnce(system, contents, env, fetchImpl, toolsEnabled);
      if (!got) break;
      const nativeCalls = got.parts.filter((p) => p.functionCall?.name);
      const textCalls = (!nativeCalls.length && toolsEnabled && opts.runTool)
        ? parseTextToolCalls(got.text)
        : [];
      if (nativeCalls.length === 0 && textCalls.length === 0) {
        if (got.text) {
          return {
            text: finalizeAssistantText(got.text),
            provider: "gemini",
            model: got.modelId ?? GEMINI_FLASH_API_MODEL,
            toolEvents,
          };
        }
        break;
      }
      if (!opts.runTool) {
        if (got.text) {
          return {
            text: finalizeAssistantText(got.text),
            provider: "gemini",
            model: got.modelId ?? GEMINI_FLASH_API_MODEL,
            toolEvents,
          };
        }
        break;
      }
      if (nativeCalls.length > 0) {
        contents.push({ role: "model", parts: got.parts });
        const responseParts: GeminiPart[] = [];
        for (const part of nativeCalls) {
          const name = String(part.functionCall?.name ?? "");
          const rawArgs = part.functionCall?.args as unknown;
          let args: Record<string, unknown> = {};
          if (rawArgs && typeof rawArgs === "object" && !Array.isArray(rawArgs)) {
            args = rawArgs as Record<string, unknown>;
          } else if (typeof rawArgs === "string") {
            try {
              const parsed = JSON.parse(rawArgs) as unknown;
              if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
                args = parsed as Record<string, unknown>;
              }
            } catch { /* empty args */ }
          }
          const result = runNamedTool(opts.runTool, name, args, toolEvents);
          responseParts.push({
            functionResponse: {
              name,
              response: result,
            },
          });
        }
        contents.push({ role: "user", parts: responseParts });
        continue;
      }
      // Text-emitted tool calls (defense when native tools are off or ignored)
      contents.push({ role: "model", parts: [{ text: got.text }] });
      const blocks: string[] = [];
      for (const call of textCalls) {
        const result = runNamedTool(opts.runTool, call.name, call.args, toolEvents);
        blocks.push(`Tool ${call.name} result:\n${JSON.stringify(result)}`);
      }
      contents.push({
        role: "user",
        parts: [{ text: `${blocks.join("\n\n")}\n\n${TOOL_FOLLOWUP}` }],
      });
    }
  } catch {
    /* try Groq */
  }
  try {
    const groq = await groqCompleteWithTextTools({
      system,
      turns,
      env,
      fetchImpl,
      toolsEnabled,
      runTool: opts.runTool,
      toolEvents,
    });
    if (groq) return groq;
  } catch {
    /* snapshot fallback */
  }
  if (toolEvents.length > 0) {
    const last = [...toolEvents].reverse().find((e) => e.type === "tool_done");
    return {
      text: finalizeAssistantText(
        last?.summary
          ? `Chat tool: ${last.summary}. Locks still hold (paper, EV floors, ARIA off).`
          : "Chat tools finished. Locks still hold (paper, EV floors, ARIA off).",
      ),
      provider: "gemini",
      model: GEMINI_FLASH_API_MODEL,
      toolEvents,
    };
  }
  return null;
}
