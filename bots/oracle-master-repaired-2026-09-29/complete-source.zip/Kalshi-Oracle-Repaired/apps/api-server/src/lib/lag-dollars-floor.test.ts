/**
 * $16 lag-$ floor: later metered-lag preserver, not original +$50.
 * 2026-09-11 paper=live: CONFLUENCE+LAG also keep $16 (no paper $0 cheat).
 * EV 3c / Kelly 0.60 / 9% untouched. paperMode stays true.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  liveLagSkipReason,
  paperMoneyMakerLagMinAbsDollars,
  SETTLEMENT_SIDE_LAG_MIN_ABS_DOLLARS,
  decideSettlementSide,
} from "./settlement-side.js";
import { METERED_LAG_MIN_ABS_DOLLARS } from "./desk-library/metered-lag.js";
import { evaluateBasisLagEdge } from "./basis-lag-edge.js";
import { evaluateConfluenceCascade } from "./confluence-cascade.js";
import { apply15mSettlementSideBeforeSize, tradingBot } from "./trading-bot.js";
import { EV_FLOOR, HARD_RISK_LIMITS, kellyFraction } from "./admission.js";
import type { StrategyObservation } from "./strategy-library.js";

tradingBot.stop();

const DIR = path.dirname(fileURLToPath(import.meta.url));
const PERSISTED = JSON.parse(
  fs.readFileSync(path.resolve(DIR, "../../.bot-config.json"), "utf8"),
) as { paperMode: boolean; disabledStrategies: string[] };

const LAG_851 = 8.51; // live skip that starved BASIS_LAG this session

function lagObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60,
    projectedSettlementPrice: 65130,
    rollingBasis: 8,
    basisShort: 8,
    basisStreakCount: 4,
    basisStreakSign: 1,
    lagStale: false,
    lagDollars: LAG_851,
    lagProven: true,
    leadSeconds: 19,
    leadDollars: -17,
    yesAsk: 42,
    yesBid: 40,
    noAsk: 58,
    noBid: 56,
    regime: "unclear",
    contractDurationMins: 15,
    ticker: "KXBTC15M-26AUG281945-45",
    ...overrides,
  };
}

function confluenceObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 63500,
    floorStrike: 63000,
    velocityDolPerMin: 90,
    threeMinVelocity: 85,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 1.2,
    massAboveFloor: 80,
    secsRemaining: 5 * 60,
    recentUpPct: 0.60,
    regime: "strong_uptrend",
    yesAsk: 49,
    noAsk: 51,
    contractDurationMins: 15,
    ticker: "KXBTC15M-26AUG281945-45",
    lagStale: false,
    lagDollars: LAG_851,
    paperMode: true,
    ...overrides,
  };
}

test("locks: paperMode true, EV 3c, Kelly 0.60, 9%, $16 default matches metered-lag shadow", () => {
  assert.equal(PERSISTED.paperMode, true);
  assert.equal(tradingBot.config.paperMode, true);
  assert.equal(EV_FLOOR, 3);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(kellyFraction(80, 8), 0.60);
  assert.ok(kellyFraction(90, 20) <= 0.60);
  assert.equal(SETTLEMENT_SIDE_LAG_MIN_ABS_DOLLARS, 16);
  assert.equal(SETTLEMENT_SIDE_LAG_MIN_ABS_DOLLARS, METERED_LAG_MIN_ABS_DOLLARS);
  assert.equal(PERSISTED.disabledStrategies.includes("CONFLUENCE_CASCADE"), false);
  // FROZEN_CC desk keeps LAG disabled; paper Tier A (frozenCcMode false) may leave LAG enabled.
  // Do not rewrite live .bot-config.json from tests — assert the invariant conditionally.
  const frozenCc = (PERSISTED as { frozenCcMode?: boolean }).frozenCcMode === true;
  if (frozenCc) {
    assert.equal(PERSISTED.disabledStrategies.includes("BASIS_LAG_EDGE"), true, "FROZEN_CC disables LAG");
  }
  // Money-maker law still paper=live in helpers either way.
});

test("helper: paper=live $16 for all ids (no paper money-maker $0)", () => {
  assert.equal(paperMoneyMakerLagMinAbsDollars(true, "BASIS_LAG_EDGE"), 16);
  assert.equal(paperMoneyMakerLagMinAbsDollars(true, "CONFLUENCE_CASCADE"), 16);
  assert.equal(paperMoneyMakerLagMinAbsDollars(true, "CHEAP_SIDE_15M"), 16);
  assert.equal(paperMoneyMakerLagMinAbsDollars(true, "PAPER_SCALP"), 16);
  assert.equal(paperMoneyMakerLagMinAbsDollars(false, "BASIS_LAG_EDGE"), 16);
  assert.equal(paperMoneyMakerLagMinAbsDollars(undefined, "BASIS_LAG_EDGE"), 16);
  assert.equal(paperMoneyMakerLagMinAbsDollars(true, null), 16);
});

test("liveLagSkipReason default: |8.51| too small; explicit floor 0 agrees YES", () => {
  assert.equal(liveLagSkipReason("yes", LAG_851), "lag_dollars_too_small");
  assert.equal(liveLagSkipReason("yes", LAG_851, 0), null);
  assert.equal(liveLagSkipReason("yes", -LAG_851, 0), "lag_disagrees");
  assert.equal(liveLagSkipReason("no", -LAG_851, 0), null);
});

test("BASIS_LAG: missing paperMode + $8.51 still skips (fail-closed live path)", () => {
  assert.equal(evaluateBasisLagEdge(lagObs()), null);
});

test("BASIS_LAG paper=live: $8.51 skips; $20 fires both modes", () => {
  assert.equal(evaluateBasisLagEdge(lagObs({ paperMode: true })), null, "paper $8.51 under $16");
  assert.equal(evaluateBasisLagEdge(lagObs({ paperMode: false })), null, "live $8.51 under $16");
  const fired = evaluateBasisLagEdge(lagObs({ paperMode: true, lagDollars: 20 }));
  assert.ok(fired, "paper |lag$|>=16 fires");
  assert.equal(fired!.strategyId, "BASIS_LAG_EDGE");
  assert.equal(fired!.signal, "YES");
  assert.ok(evaluateBasisLagEdge(lagObs({ paperMode: false, lagDollars: 20 })), "live |lag$|>=16 fires");
});

test("BASIS_LAG paper=live: disagree still null; $8.51 both modes off; $20 same-sign fires", () => {
  const disagree = evaluateBasisLagEdge(lagObs({ paperMode: true, lagDollars: -LAG_851, leadDollars: -40 }));
  assert.equal(disagree, null, "opposite-sign Coinbase/lead$ vs YES is not proven and must not fire");
  assert.equal(evaluateBasisLagEdge(lagObs({ paperMode: true, lagDollars: LAG_851, leadDollars: 40 })), null);
  assert.equal(evaluateBasisLagEdge(lagObs({ paperMode: false, lagDollars: LAG_851 })), null);
  const sameSign = evaluateBasisLagEdge(lagObs({ paperMode: true, lagDollars: 20, leadDollars: 40 }));
  assert.ok(sameSign, "same-sign lead$ |lag$|>=16 fires");
  const stale = evaluateBasisLagEdge(lagObs({ paperMode: true, lagStale: true, lagDollars: 20, leadDollars: 40 }));
  assert.ok(stale, "must not skip LAG_STALE at early catch-up gate when lead$ agrees");
});

test("CONFLUENCE evaluate itself does not use $16; settlement-side was the starve", () => {
  const fired = evaluateConfluenceCascade(confluenceObs());
  assert.ok(fired, "CONFLUENCE evaluate has no |lag$| floor");
  assert.equal(fired!.strategyId, "CONFLUENCE_CASCADE");
});

test("settlement-side: $8.51 floors both modes; remake-preserve places CC/LAG paper=live", () => {
  const starved = apply15mSettlementSideBeforeSize({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: LAG_851,
  });
  assert.equal(starved.place, false);
  assert.equal(starved.decision.reason, "lag_dollars_too_small");

  const lagPaper = apply15mSettlementSideBeforeSize({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: LAG_851,
    paperMode: true, strategyId: "BASIS_LAG_EDGE",
  });
  assert.equal(lagPaper.decision.reason, "lag_dollars_too_small");
  assert.equal(lagPaper.place, true, "remake-preserve paper");

  const confPaper = apply15mSettlementSideBeforeSize({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: LAG_851,
    paperMode: true, strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(confPaper.place, true);

  const cheapPaper = apply15mSettlementSideBeforeSize({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: LAG_851,
    paperMode: true, strategyId: "CHEAP_SIDE_15M",
  });
  assert.equal(cheapPaper.place, false);
  assert.equal(cheapPaper.decision.reason, "lag_dollars_too_small");

  const liveLag = apply15mSettlementSideBeforeSize({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: LAG_851,
    paperMode: false, strategyId: "BASIS_LAG_EDGE",
  });
  assert.equal(liveLag.decision.reason, "lag_dollars_too_small");
  assert.equal(liveLag.place, true, "remake-preserve live parity");
  assert.equal(liveLag.place, lagPaper.place);
});

test("paper money-maker still skips lag_disagrees at $8.51 (not a flip)", () => {
  // Doctrine update: lag_disagrees demoted (book-lead) — remake-ignore for paper CC.
  // Later-preserver unstarves remake reasons only; disagrees still blocks place.
  const d = apply15mSettlementSideBeforeSize({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: -LAG_851,
    paperMode: true, strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(d.place, true, "lag_disagrees demoted — paper CC may place");
  assert.equal(d.decision.reason, "lag_disagrees");
  assert.equal(d.decision.side, "skip");
});

test("decideSettlementSide explicit lagMinAbsDollars 0 places YES at $8.51; default skips", () => {
  const def = decideSettlementSide({ pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: LAG_851 });
  assert.equal(def.reason, "lag_dollars_too_small");
  const paper = decideSettlementSide({
    pYes: 0.62, pNo: null, mtf: 0, lagStale: false, lagDollars: LAG_851, lagMinAbsDollars: 0,
  });
  assert.equal(paper.side, "yes");
  assert.equal(paper.pWin, 0.62);
});
