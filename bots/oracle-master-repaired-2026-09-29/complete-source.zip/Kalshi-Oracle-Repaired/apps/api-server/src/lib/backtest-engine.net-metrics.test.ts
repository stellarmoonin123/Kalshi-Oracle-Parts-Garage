/**
 * backtest-engine.net-metrics.test.ts
 *
 * Unit tests for the 2026-08-25 "backtest economics honesty" fix: the grid
 * search now stores BOTH a GROSS/RESEARCH baseline (frictionless, no live EV
 * floor) and a NET/LIVE-PROXY view (fee-adjusted, EV-floor-filtered) per
 * result, instead of a single frictionless number that could look
 * live-tradable when it wasn't.
 *
 * Covers:
 *   1. Gross P&L >= net P&L whenever any trade paid a nonzero fee.
 *   2. A trade that fails the live EV floor is excluded from netMetrics
 *      (and therefore from any "tradable" ranking based on it).
 *   3. researchOnly is set correctly by each engine.
 *
 * Run with:  tsx --test src/lib/backtest-engine.net-metrics.test.ts
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { summarizeNet, type TradeRecord } from "./backtest-engine.js";

function makeTrade(overrides: Partial<TradeRecord>): TradeRecord {
  return {
    periodIdx: 0, foldIdx: 0, signal: "LONG", velocity5: 10, velocity10: 10,
    modelProb: 0.6, edge: 5, stalling: false, accelerating: true, confidence: 70,
    entryPriceCents: 50, exitPriceCents: 100, outcome: "win", pnlCents: 50,
    contracts: 1, settledAbove: true, exitReason: "settlement",
    feeCentsPaid: 0, evPasses: true, netPnlCents: 50,
    ...overrides,
  };
}

// ── 1. Gross P&L >= net P&L whenever fees are nonzero ────────────────────────

test("gross pnlCents total >= net summarizeNet pnl when a fee was charged", () => {
  // A single winning trade: gross pnlCents ignores the fee entirely, but
  // netPnlCents (and therefore summarizeNet's total) already has it deducted.
  const trades: TradeRecord[] = [
    makeTrade({ pnlCents: 50, feeCentsPaid: 3, evPasses: true, netPnlCents: 47, outcome: "win" }),
  ];

  const grossTotal = trades.reduce((s, t) => s + t.pnlCents, 0);
  const net         = summarizeNet(trades, 1);

  assert.equal(grossTotal, 50);
  assert.equal(net.pnlCents, 47);
  assert.ok(grossTotal >= net.pnlCents, "gross P&L must be >= net P&L when a fee was charged");
});

test("gross and net pnl are equal only when fee is zero on every trade", () => {
  const trades: TradeRecord[] = [
    makeTrade({ pnlCents: 50, feeCentsPaid: 0, evPasses: true, netPnlCents: 50, outcome: "win" }),
    makeTrade({ pnlCents: -25, feeCentsPaid: 0, evPasses: true, netPnlCents: -25, outcome: "loss" }),
  ];
  const grossTotal = trades.reduce((s, t) => s + t.pnlCents, 0);
  const net         = summarizeNet(trades, 1);
  assert.equal(grossTotal, net.pnlCents);
});

// ── 2. EV-floor-failing trades are excluded from the net/tradable view ───────

test("a trade that fails the live EV floor (evPasses=false) is excluded from netMetrics", () => {
  const trades: TradeRecord[] = [
    makeTrade({ pnlCents: 50, feeCentsPaid: 3, evPasses: true,  netPnlCents: 47, outcome: "win" }),
    // This trade "won" on paper (gross), but would never have been placed
    // live because it failed the EV floor — evPasses=false, netPnlCents=0.
    makeTrade({ pnlCents: 80, feeCentsPaid: 5, evPasses: false, netPnlCents: 0,  outcome: "win" }),
  ];

  const net = summarizeNet(trades, 1);

  assert.equal(net.tradesEntered, 1, "only the evPasses=true trade should count toward net trades entered");
  assert.equal(net.excludedForEv, 1, "the EV-floor-failing trade must be tallied as excluded");
  assert.equal(net.pnlCents, 47, "net pnl must not include the EV-floor-failing trade's pnl");
  assert.equal(net.wins, 1);
});

test("a scenario with only EV-floor-failing trades yields zero net trades (not a crash)", () => {
  const trades: TradeRecord[] = [
    makeTrade({ pnlCents: 80, feeCentsPaid: 5, evPasses: false, netPnlCents: 0, outcome: "win" }),
    makeTrade({ pnlCents: 30, feeCentsPaid: 4, evPasses: false, netPnlCents: 0, outcome: "win" }),
  ];
  const net = summarizeNet(trades, 1);
  assert.equal(net.tradesEntered, 0);
  assert.equal(net.excludedForEv, 2);
  assert.equal(net.pnlCents, 0);
  assert.equal(net.winRate, 0);
});

// ── 3. no_trade (STAY_OUT) records never count toward net trades ────────────

test("no_trade records are excluded from both gross entered-count and net metrics", () => {
  const trades: TradeRecord[] = [
    makeTrade({ outcome: "no_trade", pnlCents: 0, feeCentsPaid: 0, evPasses: false, netPnlCents: 0, exitReason: "no_trade" }),
    makeTrade({ outcome: "win", pnlCents: 50, feeCentsPaid: 3, evPasses: true, netPnlCents: 47 }),
  ];
  const net = summarizeNet(trades, 2);
  assert.equal(net.tradesEntered, 1);
  assert.equal(net.excludedForEv, 0, "a no_trade record is not an EV-floor exclusion, it's a non-entry");
});
