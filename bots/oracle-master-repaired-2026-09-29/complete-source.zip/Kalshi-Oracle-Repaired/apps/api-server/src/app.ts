import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import fs from "node:fs";
import path from "node:path";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { isAllowedOrigin } from "./lib/cors-origin";
import { accountsApiGate } from "./lib/accounts/middleware.js";

const app: Express = express();

// Fly (and most PaaS proxies) terminate TLS in front of us. Required so
// production session cookies set with `secure: true` actually stick.
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

// ── CORS allowlist ──────────────────────────────────────────────────────────
// Previously `origin: true` reflected ANY origin back in
// Access-Control-Allow-Origin — any website could script a browser into
// reading responses from this API. Restrict to origins this project actually
// serves from: CORS_ORIGIN / PUBLIC_URL, localhost / 127.0.0.1 (Vite),
// and https://*.trycloudflare.com (quick tunnels rotate names).
//
// Fly: set CORS_ORIGIN and/or PUBLIC_URL to the public https origin
// (e.g. https://kalshi-oracle.fly.dev). FLY_APP_NAME is injected by Fly and
// is also allowlisted as https://$FLY_APP_NAME.fly.dev.
const allowedOrigins = new Set<string>();

function addOrigin(raw: string | undefined): void {
  if (!raw) return;
  for (const part of raw.split(",")) {
    const value = part.trim().replace(/\/$/, "");
    if (!value) continue;
    if (value.startsWith("http://") || value.startsWith("https://")) {
      allowedOrigins.add(value);
    } else {
      allowedOrigins.add(`https://${value}`);
    }
  }
}

addOrigin(process.env.CORS_ORIGIN);
addOrigin(process.env.PUBLIC_URL);
if (process.env.FLY_APP_NAME) {
  allowedOrigins.add(`https://${process.env.FLY_APP_NAME}.fly.dev`);
}

const corsOptions: cors.CorsOptions = {
  origin(origin, callback) {
    // No Origin / allowlist / localhost / trycloudflare — see isAllowedOrigin.
    // Deny with callback(null, false): throwing Error here becomes HTTP 500
    // and the chat path paints "Agent returned 500". Browser still blocks
    // disallowed origins; we just don't crash.
    if (isAllowedOrigin(origin, allowedOrigins)) return callback(null, true);
    callback(null, false);
  },
  credentials: true,
  allowedHeaders: ["Content-Type", "Authorization", "x-api-key", "X-Desk-Admin-Token"],
};
app.use(cors(corsOptions));
app.options(/{.*}/, cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// ── Auth ──────────────────────────────────────────────────────────────────
// Multi-user accounts (lib/accounts). DEFAULT-DENY: every /api route needs a
// valid server-side session except the tiny public allowlist in
// accounts/middleware.ts (healthz, public/status, auth login/logout/me).
// Config-writing / bot-control / admin routes additionally need role ADMIN.
// Supersedes the shared BOT_API_KEY login and the DESK_ADMIN_TOKEN passcode
// lock (no loopback / proxy-header / frontend bypass).
app.use("/api", accountsApiGate);
// Minimal public status (always open, no private data).
app.get("/api/public/status", (_req: Request, res: Response) => {
  res.json({ ok: true, service: "kalshi-oracle-desk", accounts: true });
});
app.use("/api", router);
// Unmatched /api/* must 404 as JSON, not fall through to the SPA index.html.
app.use("/api", (_req: Request, res: Response) => {
  res.status(404).json({ error: "Not found" });
});

// ── Production dashboard ──────────────────────────────────────────────────
// Serve the Vite-built kalshi-trader UI from this same process so Fly only
// needs one machine. BASE_PATH=/ at build time; /api is reserved above.
if (process.env.NODE_ENV === "production") {
  const dashboardDir = path.resolve(process.cwd(), "../kalshi-trader/dist/public");
  if (fs.existsSync(dashboardDir)) {
    app.use(express.static(dashboardDir, { index: false }));
    app.use((req: Request, res: Response, next: NextFunction) => {
      if (req.method !== "GET" && req.method !== "HEAD") return next();
      if (req.path.startsWith("/api")) return next();
      res.sendFile(path.join(dashboardDir, "index.html"), (err) => {
        if (err) next(err);
      });
    });
    logger.info({ dashboardDir }, "Serving kalshi-trader dashboard from this process");
  } else {
    logger.warn({ dashboardDir }, "Dashboard dist not found — API-only mode");
  }
}


// Fail-clean: never let Express default HTML 500 dumps hit Chat/API clients.
app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
  logger.error({ err }, "Unhandled request error");
  if (res.headersSent) return;
  const reqPath = (req.originalUrl ?? req.url ?? "").split("?")[0];
  if (reqPath.startsWith("/api")) {
    res.status(500).json({ error: "Internal server error" });
    return;
  }
  res.status(500).type("text/plain").send("Internal server error");
});

export default app;
