/**
 * 1s projectedSettlement vs floor is projAgainstSide, not Coinbase lag.
 * Does not import trading-bot.ts.
 */
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  projAgainstSide,
  projAgreesWithSide,
  PROJ_AGAINST_MIN_DISPLACEMENT_PCT,
  LAG_FLIP_MIN_HOLD_MS,
  LAG_FLIP_MIN_SAMPLES,
} from "./lag-flip.js";
import { lagAgreesWithSide } from "./lag-meter.js";
import { sanitizeLagSnapshot } from "./decision-trace.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const TRACE = fs.readFileSync(path.join(DIR, "decision-trace.ts"), "utf8");
const BOT = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");

test("locks: LAG_FLIP 20s / 16 samples unchanged", () => {
  assert.equal(LAG_FLIP_MIN_HOLD_MS, 20_000);
  assert.equal(LAG_FLIP_MIN_SAMPLES, 16);
  assert.equal(PROJ_AGAINST_MIN_DISPLACEMENT_PCT, 0.0005);
});

test("projAgainstSide: YES projected below floor is against; missing is not", () => {
  assert.equal(projAgainstSide({ tradeSide: "yes", projected: 64_900, floorStrike: 65_000 }), true);
  assert.equal(projAgainstSide({ tradeSide: "yes", projected: 65_200, floorStrike: 65_000 }), false);
  assert.equal(projAgainstSide({ tradeSide: "no", projected: 65_200, floorStrike: 65_000 }), true);
  assert.equal(projAgainstSide({ tradeSide: "yes", projected: null, floorStrike: 65_000 }), false);
  assert.equal(projAgainstSide({ tradeSide: "yes", projected: 65_000, floorStrike: 65_000 }), false);
  assert.equal(projAgreesWithSide({ tradeSide: "yes", projected: 65_200, floorStrike: 65_000 }), true);
  assert.equal(projAgreesWithSide({ tradeSide: "yes", projected: null, floorStrike: 65_000 }), null);
});

test("Coinbase lagAgreesWithSide still reads lagDollars, not 1s proj", () => {
  assert.equal(lagAgreesWithSide("yes", 40), true);
  assert.equal(lagAgreesWithSide("yes", -40), false);
  // Same YES trade: Coinbase down disagrees; 1s proj below floor is against.
  // Two meters, two answers — proving they are not aliases.
  assert.equal(lagAgreesWithSide("yes", -40), false);
  assert.equal(projAgainstSide({ tradeSide: "yes", projected: 64_900, floorStrike: 65_000 }), true);
});

test("trace LagSnapshot dropped lagAgrees alias; sanitize strips it", () => {
  const snapBlock = TRACE.slice(
    TRACE.indexOf("export interface LagSnapshot"),
    TRACE.indexOf("export function sanitizeLagSnapshot"),
  );
  assert.equal(/\blagAgrees\s*[?:]/.test(snapBlock), false);
  assert.match(snapBlock, /projAgrees\?:/);
  const cleaned = sanitizeLagSnapshot({
    projectedSettlement: 65_200,
    rollingBasis: 5,
    projAgrees: true,
    lagAgrees: false,
  });
  assert.equal(cleaned!.projAgrees, true);
  assert.equal("lagAgrees" in (cleaned as object), false);
  assert.equal(cleaned!.projectedSettlement, 65_200);
});

test("bot 1s-proj helper body is projAgainstSide; traces dropped lagAgrees alias", () => {
  // Use indexOf/includes on the god-file — RegExp on ~1MB BOT can hang (catastrophic backtracking).
  const helperAt = BOT.indexOf("private isLagAgainstSide(");
  assert.ok(helperAt >= 0, "isLagAgainstSide helper must exist");
  const helper = BOT.slice(helperAt, helperAt + 2000);
  assert.ok(
    helper.includes("return projAgainstSide({ tradeSide, projected: canon.proj, floorStrike })"),
    "helper must call projAgainstSide",
  );
  assert.ok(BOT.includes("let projAgreesWithSide:"), "projAgreesWithSide local must exist");
  assert.equal(
    BOT.includes("lagAgrees: ctx.lag.projAgreesWithSide"),
    false,
    "must not alias lagAgrees to projAgreesWithSide",
  );
});
