/**
 * mtf-analyzer.ts — Multi-Timeframe Bias Engine
 *
 * Redesigned 2026-08-09 for 15-minute BTC binaries: the original engine only
 * scored 1h + 4h, which is too slow to be relevant to a contract that settles
 * in 15 minutes. Now scores four timeframes:
 *
 *   - 1m, 5m, 15m  — PRIMARY. Sourced from real exchange candles
 *                    (fetchRealCandles: Coinbase → Binance → CoinGecko) so
 *                    they reflect genuine intrabar price action.
 *   - 1h           — SECONDARY filter, half weight. Prefers Kalshi settlement
 *                    candles; falls back to real exchange OHLC (fetchRealCandles)
 *                    when Kalshi returns empty/broken so HTF/MTF stay alive.
 *   - 4h           — kept for display/ARIA prompt context only (weight 0 —
 *                    excluded from the score). Same Kalshi-then-real fallback.
 *
 * IMPORTANT: 1m/5m must NOT be sourced from fetchKalshiCandles(). Below 15m,
 * that function linearly interpolates between a settled period's open and
 * the next period's close across the whole window — every "1-minute candle"
 * inside a period already reflects where price ends up at settlement. That's
 * a lookahead-bias trap (see market-candles.ts's header), and it would also
 * just be a smoothed, up-to-15-min-stale echo of the same slow data — not
 * genuine fast momentum. fetchRealCandles() avoids both problems.
 *
 * Two independent refresh loops, each with its own in-flight mutex:
 *   - FAST loop (1m/5m/15m): every 30s — fast enough to matter for a 15-min
 *     contract without hammering the exchange APIs.
 *   - SLOW loop (1h/4h): every 5 min, unchanged — hourly candles don't move
 *     fast enough to justify tighter polling.
 *
 * Score interpretation (weighted sum, clamped to -4..+4):
 *   +4 / +3  : STRONG BULL  — only take LONG trades, higher size
 *   +2 / +1  : BULL         — prefer LONG, allow SHORT with higher threshold
 *    0        : NEUTRAL      — trade both directions, standard rules
 *   -1 / -2  : BEAR         — prefer SHORT, allow LONG with higher threshold
 *   -3 / -4  : STRONG BEAR  — only take SHORT trades
 */

import { BTC_FLOOR_FALLBACK, MTF_STALE_MS, MTF_REFRESH_MS, MTF_FAST_REFRESH_MS } from "./constants.js";
import { fetchKalshiCandles } from "./kalshi-price.js";
import { fetchRealCandles } from "./market-candles.js";

const SLOW_REFRESH_MS = MTF_REFRESH_MS;
const FAST_REFRESH_MS = MTF_FAST_REFRESH_MS;

// Keep last successful OHLC arrays so transient API issues don't kill the
// signal. Data is used as a stale fallback for a bounded window per leg.
const SLOW_OHLC_CACHE_MAX_MS = 30 * 60_000; // 1h/4h — settlement data, can tolerate a longer stale window
const FAST_OHLC_CACHE_MAX_MS = 3 * 60_000;  // 1m/5m/15m — must not silently serve very stale "fast" data
const slowOhlcCache = new Map<number, { data: OHLC[]; ts: number }>();
const fastOhlcCache = new Map<number, { data: OHLC[]; ts: number }>();

// ── Types ─────────────────────────────────────────────────────────────────────

export type TF      = '1m' | '5m' | '15m' | '1h' | '4h';
export type TFBias  = 'strong_bull' | 'bull' | 'neutral' | 'bear' | 'strong_bear';
export type TFScore = -2 | -1 | 0 | 1 | 2;

interface TFConfig {
  fastPeriod: number;  // fast EMA period for this timeframe
  slowPeriod: number;  // slow EMA period for this timeframe
  weight:     number;  // contribution to the combined score
}

// 1m/5m use quicker EMAs (5/13, 8/21) so they react to genuinely fast moves;
// 15m/1h keep the original 9/21 pair. 4h keeps 9/21 too but weight 0 means it
// never affects the score — it's carried purely for ARIA's prompt context.
const TF_CONFIG: Record<TF, TFConfig> = {
  '1m':  { fastPeriod: 5, slowPeriod: 13, weight: 1.0 },
  '5m':  { fastPeriod: 8, slowPeriod: 21, weight: 1.25 },
  '15m': { fastPeriod: 9, slowPeriod: 21, weight: 1.5 },
  '1h':  { fastPeriod: 9, slowPeriod: 21, weight: 0.5 },
  '4h':  { fastPeriod: 9, slowPeriod: 21, weight: 0 },
};

const SCORE_CLAMP = 4; // keep the combined score in the same -4..+4 range existing gates expect

export interface TFAnalysis {
  tf:             TF;
  price:          number;
  emaFast:        number;
  emaSlow:        number;
  rsi14:          number;
  atr14:          number;        // Average True Range — used for dynamic stop sizing (1h leg only)
  score:          TFScore;
  bias:           TFBias;
  pctFromEmaSlow: number;
  trend:          'accelerating' | 'steady' | 'decelerating' | 'reversing';
}

export interface MTFSummary {
  score:        number;        // -4 to +4, weighted composite of 1m/5m/15m/1h (4h excluded)
  bias:         TFBias;
  alignedWith:  'LONG' | 'SHORT' | 'NEUTRAL';
  stronglyAligned: boolean;   // true if |score| >= 3
  m1:           TFAnalysis | null;
  m5:           TFAnalysis | null;
  m15:          TFAnalysis | null;
  h1:           TFAnalysis | null;
  h4:           TFAnalysis | null;   // context-only, not part of `score`
  atr1h:        number;       // ATR-14 on 1h (in $) — used for dynamic stop sizing
  updatedAt:    number;       // timestamp of the most recent leg to refresh (fast or slow)
  /** How many ¢ the stop-loss should be, derived from ATR (expert dynamic stop) */
  dynamicStopCents: number;
  /** How many ¢ the profit target should be, derived from ATR */
  dynamicProfitCents: number;
  /**
   * True when one or more of the 1m/5m/15m legs came from the bounded
   * stale-cache fallback (real fetch failed, last-known candles reused)
   * rather than a live fetch on the most recent fast refresh. `updatedAt`
   * still advances on every refresh attempt, so this is the only signal
   * that a "fresh-looking" summary is actually running on older fast data.
   */
  usedStaleFastCache: boolean;
  /** Which fast legs (of '1m'/'5m'/'15m') were served stale, if any. */
  staleFastLegs: string[];
  /** Age (ms) of the oldest stale fast-leg cache entry currently in use; 0 if none. */
  staleFastAgeMs: number;
}

// ── EMA ───────────────────────────────────────────────────────────────────────

function computeEMA(closes: number[], period: number): number[] {
  if (closes.length === 0) return [];
  const k   = 2 / (period + 1);
  const ema = [closes[0]];
  for (let i = 1; i < closes.length; i++) {
    ema.push(closes[i] * k + ema[i - 1] * (1 - k));
  }
  return ema;
}

// ── RSI-14 ────────────────────────────────────────────────────────────────────

function computeRSI14(closes: number[]): number {
  if (closes.length < 15) return 50;
  const last = closes.slice(-30);
  let gains = 0, losses = 0;
  for (let i = 1; i < last.length; i++) {
    const diff = last[i] - last[i - 1];
    if (diff > 0) gains += diff; else losses += Math.abs(diff);
  }
  const n = last.length - 1;
  const avgGain = gains / n;
  const avgLoss = losses / n;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

// ── ATR-14 ────────────────────────────────────────────────────────────────────

interface OHLC { open: number; high: number; low: number; close: number }

function computeATR14(candles: OHLC[]): number {
  if (candles.length < 2) return 0;
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const h  = candles[i].high;
    const l  = candles[i].low;
    const pc = candles[i - 1].close;
    trs.push(Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc)));
  }
  const last14 = trs.slice(-14);
  return last14.reduce((a, b) => a + b, 0) / last14.length;
}

// ── Trend acceleration classifier ──────────────────────────────────────────────

function classifyTrend(emaFastArr: number[], emaSlowArr: number[]): TFAnalysis['trend'] {
  if (emaFastArr.length < 4 || emaSlowArr.length < 4) return 'steady';
  const spread     = (i: number) => emaFastArr[i] - emaSlowArr[i];
  const spreadNow  = spread(emaFastArr.length - 1);
  const spreadPrev = spread(emaFastArr.length - 3);
  if (Math.abs(spreadNow) > Math.abs(spreadPrev) * 1.3 && Math.sign(spreadNow) === Math.sign(spreadPrev)) return 'accelerating';
  if (Math.sign(spreadNow) !== Math.sign(spreadPrev)) return 'reversing';
  if (Math.abs(spreadNow) < Math.abs(spreadPrev) * 0.7) return 'decelerating';
  return 'steady';
}

// ── Classify a single TF ──────────────────────────────────────────────────────

function classifyTF(candles: OHLC[], tf: TF): TFAnalysis {
  // MTF_FILTER score stays raw OHLC closes — that is the original live +$50
  // gate. HTF side/skip context (mtf-structure) is Heikin Ashi. Do not mix.
  const { fastPeriod, slowPeriod } = TF_CONFIG[tf];
  const closes = candles.map(c => c.close);
  const price  = closes[closes.length - 1];

  const emaFastArr = computeEMA(closes, fastPeriod);
  const emaSlowArr = computeEMA(closes, slowPeriod);
  const emaFast    = emaFastArr[emaFastArr.length - 1];
  const emaSlow    = emaSlowArr[emaSlowArr.length - 1];
  const rsi14      = computeRSI14(closes);
  const atr14      = computeATR14(candles);
  const trend      = classifyTrend(emaFastArr, emaSlowArr);
  const pctFromEmaSlow = ((price - emaSlow) / emaSlow) * 100;

  // Score logic — identical vote structure to the original 1h/4h engine,
  // now parameterised per-TF fast/slow EMA pair.
  let score: TFScore = 0;
  const priceAboveFast = price > emaFast;
  const priceAboveSlow = price > emaSlow;
  const fastAboveSlow  = emaFast > emaSlow;

  if (priceAboveFast && priceAboveSlow && fastAboveSlow) {
    // Full bull stack
    score = rsi14 > 60 ? 2 : 1;
  } else if (!priceAboveFast && !priceAboveSlow && !fastAboveSlow) {
    // Full bear stack
    score = rsi14 < 40 ? -2 : -1;
  } else if (priceAboveSlow && !fastAboveSlow) {
    // Price above slow EMA but EMAs haven't crossed — weak bull
    score = 1;
  } else if (!priceAboveSlow && fastAboveSlow) {
    // Price below slow EMA, EMAs still bullish — early bear warning
    score = -1;
  } else {
    score = 0;
  }

  // Trend state can adjust score one notch
  if (trend === 'accelerating' && score > 0 && score < 2) score = (score + 1) as TFScore;
  if (trend === 'accelerating' && score < 0 && score > -2) score = (score - 1) as TFScore;
  if (trend === 'reversing' && Math.abs(score) > 0) score = Math.sign(score) === 1 ? (score - 1) as TFScore : (score + 1) as TFScore;

  const biasMap: Record<TFScore, TFBias> = { 2: 'strong_bull', 1: 'bull', 0: 'neutral', [-1]: 'bear', [-2]: 'strong_bear' };

  return { tf, price, emaFast, emaSlow, rsi14, atr14, score, bias: biasMap[score], pctFromEmaSlow, trend };
}

// ── Dynamic stop / profit targets from ATR ────────────────────────────────────
// For Kalshi binary, we express stop/profit as ¢ movement in YES/NO price.
// ATR is in $ (BTC). We convert: ¢ ≈ ATR / floorStrike * 100 * scaleFactor
// scaleFactor for 15-min contracts is typically ~0.25 (a 15-min ATR is ~25% of 1h ATR)

function atrToCents(atr1h: number, floorStrike: number, fractionOf1h = 0.35): number {
  if (atr1h <= 0 || floorStrike <= 0) return 15;
  const fraction15m = atr1h * fractionOf1h;
  // Convert BTC $ movement to probability change: delta ≈ fraction / (floorStrike * σ√τ)
  // Simplified: ~ (fraction / floorStrike) * 100 * 2 (the 2 comes from the logistic scaling)
  const pctMove = (fraction15m / floorStrike) * 100;
  return Math.min(25, Math.max(8, Math.round(pctMove * 2)));
}

// ── Fetch: SLOW leg (1h/4h) — Kalshi first, real-exchange fallback ────────────
// Kalshi settlement OHLC for 60m/240m is sometimes empty/broken. When that
// happens, fall back to the same fetchRealCandles path the fast legs and
// chart/klines use so HTF structure and h1 bias stay alive.

async function fetchSlowOHLC(intervalMins: number, limit = 60): Promise<OHLC[]> {
  // 1) Prefer Kalshi settlement candles (original design).
  try {
    const candles = await fetchKalshiCandles(intervalMins, limit);
    if (candles.length === 0) throw new Error("empty response");
    const result = candles.map(c => ({ open: c.open, high: c.high, low: c.low, close: c.close }));
    slowOhlcCache.set(intervalMins, { data: result, ts: Date.now() });
    console.debug(`[mtf] fetchSlowOHLC(${intervalMins}m) — ${result.length} candles via kalshi`);
    return result;
  } catch (kalshiErr) {
    console.debug(`[mtf] fetchSlowOHLC(${intervalMins}m) kalshi: ${(kalshiErr as Error).message} — trying real exchange`);
  }

  // 2) Fall back to real exchange OHLC (Coinbase → Binance → CoinGecko).
  try {
    const { candles, source } = await fetchRealCandles(
      Date.now() - limit * intervalMins * 60_000,
      limit,
      intervalMins,
    );
    if (candles.length === 0) throw new Error("empty response");
    const result = candles.map(c => ({ open: c.open, high: c.high, low: c.low, close: c.close }));
    slowOhlcCache.set(intervalMins, { data: result, ts: Date.now() });
    console.debug(`[mtf] fetchSlowOHLC(${intervalMins}m) — ${result.length} candles via ${source}`);
    return result;
  } catch (realErr) {
    console.debug(`[mtf] fetchSlowOHLC(${intervalMins}m) real: ${(realErr as Error).message}`);
  }

  // 3) Bounded stale-cache fallback if both live paths fail.
  const cached = slowOhlcCache.get(intervalMins);
  if (cached && Date.now() - cached.ts < SLOW_OHLC_CACHE_MAX_MS) {
    const ageMins = Math.round((Date.now() - cached.ts) / 60_000);
    console.debug(`[mtf] Using cached OHLC(${intervalMins}m) — ${ageMins}m old`);
    return cached.data;
  }
  return [];
}

// ── Fetch: FAST leg (1m/5m/15m) — real exchange candles, NOT interpolated ────
// See file header: fetchKalshiCandles() below 15m linearly interpolates and
// would reintroduce a lookahead/staleness artifact, so this leg deliberately
// uses fetchRealCandles() (Coinbase → Binance → CoinGecko) instead.

interface FastOHLCResult {
  data:  OHLC[];
  /** true when this leg was served from the bounded stale-cache fallback rather than a live fetch */
  stale: boolean;
  /** age (ms) of the cache entry when served stale; 0 for a live fetch */
  staleAgeMs: number;
}

async function fetchFastOHLC(intervalMins: 1 | 5 | 15, limit = 60): Promise<FastOHLCResult> {
  try {
    const { candles, source } = await fetchRealCandles(Date.now() - limit * intervalMins * 60_000, limit, intervalMins);
    if (candles.length === 0) throw new Error("empty response");
    const result = candles.map(c => ({ open: c.open, high: c.high, low: c.low, close: c.close }));
    fastOhlcCache.set(intervalMins, { data: result, ts: Date.now() });
    console.debug(`[mtf] fetchFastOHLC(${intervalMins}m) — ${result.length} candles via ${source}`);
    return { data: result, stale: false, staleAgeMs: 0 };
  } catch (err) {
    console.debug(`[mtf] fetchFastOHLC(${intervalMins}m) error: ${(err as Error).message}`);
    // Bounded stale fallback only — never fall back to fetchKalshiCandles()
    // for this leg, that would silently reintroduce interpolated data.
    const cached = fastOhlcCache.get(intervalMins);
    if (cached && Date.now() - cached.ts < FAST_OHLC_CACHE_MAX_MS) {
      const ageMs = Date.now() - cached.ts;
      console.debug(`[mtf] Using cached fast OHLC(${intervalMins}m) — ${Math.round(ageMs / 1_000)}s old`);
      return { data: cached.data, stale: true, staleAgeMs: ageMs };
    }
    return { data: [], stale: false, staleAgeMs: 0 };
  }
}

// ── Synthesise summary ────────────────────────────────────────────────────────

/**
 * Weighted MTF score. Missing Coinbase/fast legs are omitted, not scored as 0.
 * If 1m/5m/15m are all missing, score is 0 (neutral) — do not let a lone 1h
 * Kalshi settlement candle invent bull/bear. h4 never contributes (weight 0).
 */
export function compositeMtfScore(legs: {
  m1: number | null;
  m5: number | null;
  m15: number | null;
  h1: number | null;
}): number {
  const fastMissing = legs.m1 == null && legs.m5 == null && legs.m15 == null;
  if (fastMissing) return 0;
  const parts: Array<[number | null, number]> = [
    [legs.m1, TF_CONFIG["1m"].weight],
    [legs.m5, TF_CONFIG["5m"].weight],
    [legs.m15, TF_CONFIG["15m"].weight],
    [legs.h1, TF_CONFIG["1h"].weight],
  ];
  let raw = 0;
  for (const [sc, w] of parts) {
    if (sc == null || !Number.isFinite(sc)) continue;
    raw += sc * w;
  }
  return Math.max(-SCORE_CLAMP, Math.min(SCORE_CLAMP, Math.round(raw)));
}


function synthesise(
  m1:  TFAnalysis | null,
  m5:  TFAnalysis | null,
  m15: TFAnalysis | null,
  h1:  TFAnalysis | null,
  h4:  TFAnalysis | null,
  floorStrike: number,
  staleFastLegs: string[] = [],
  staleFastAgeMs = 0,
): MTFSummary {
  const score = compositeMtfScore({
    m1: m1?.score ?? null,
    m5: m5?.score ?? null,
    m15: m15?.score ?? null,
    h1: h1?.score ?? null,
  });

  let bias: TFBias;
  if (score >= 3)       bias = 'strong_bull';
  else if (score >= 1)  bias = 'bull';
  else if (score <= -3) bias = 'strong_bear';
  else if (score <= -1) bias = 'bear';
  else                  bias = 'neutral';

  const alignedWith: MTFSummary['alignedWith'] =
    score >= 1 ? 'LONG' : score <= -1 ? 'SHORT' : 'NEUTRAL';

  const atr1h = h1?.atr14 ?? 0;
  const dynamicStopCents   = atrToCents(atr1h, floorStrike, 0.25);
  const dynamicProfitCents = atrToCents(atr1h, floorStrike, 0.40);

  return {
    score, bias, alignedWith,
    stronglyAligned: Math.abs(score) >= 3,
    m1, m5, m15, h1, h4, atr1h,
    updatedAt: Date.now(),
    dynamicStopCents,
    dynamicProfitCents,
    usedStaleFastCache: staleFastLegs.length > 0,
    staleFastLegs,
    staleFastAgeMs: staleFastAgeMs,
  };
}

// ── Singleton ─────────────────────────────────────────────────────────────────

class MTFAnalyzer {
  private summary: MTFSummary | null = null;

  private m1:  TFAnalysis | null = null;
  private m5:  TFAnalysis | null = null;
  private m15: TFAnalysis | null = null;
  private h1:  TFAnalysis | null = null;
  private h4:  TFAnalysis | null = null;

  private fastTimer: NodeJS.Timeout | null = null;
  private slowTimer: NodeJS.Timeout | null = null;
  private floorStrike = 0;
  // Separate in-flight mutexes so a slow candle fetch on one leg never blocks
  // (or gets overlapped by) a refresh of the other leg.
  private refreshingFast = false;
  private refreshingSlow = false;

  // Whether the most recent fast-leg refresh had to lean on the bounded
  // stale-cache fallback (see FAST_OHLC_CACHE_MAX_MS) for one or more legs.
  private fastCacheDegraded = false;
  private fastCacheStaleLegs: string[] = [];
  private fastCacheMaxStaleAgeMs = 0;

  start() {
    this.refreshFast();
    this.refreshSlow();
    this.fastTimer = setInterval(() => this.refreshFast(), FAST_REFRESH_MS);
    this.slowTimer = setInterval(() => this.refreshSlow(), SLOW_REFRESH_MS);
  }

  stop() {
    if (this.fastTimer) clearInterval(this.fastTimer);
    if (this.slowTimer) clearInterval(this.slowTimer);
  }

  setFloorStrike(strike: number) {
    this.floorStrike = strike;
  }

  /**
   * Returns the MTF summary if it is fresh enough, otherwise null.
   * Callers should treat null as "data unavailable — skip MTF-dependent decisions".
   */
  getSummary(): MTFSummary | null {
    if (!this.summary) return null;
    if (Date.now() - this.summary.updatedAt > MTF_STALE_MS) {
      console.warn(`[mtf] Summary is stale (${Math.round((Date.now() - this.summary.updatedAt) / 60_000)}m old) — returning null`);
      return null;
    }
    return this.summary;
  }

  /** Returns the raw summary regardless of staleness (for UI display). */
  getSummaryRaw(): MTFSummary | null {
    return this.summary;
  }

  /** True if no fresh MTF data is available. */
  isStale(): boolean {
    if (!this.summary) return true;
    return Date.now() - this.summary.updatedAt > MTF_STALE_MS;
  }

  /** Missing/stale summary → 0 (neutral), never an invented ±4. Callers that
   *  need fail-closed should use getSummary() === null. */
  getScore(): number {
    return this.getSummary()?.score ?? 0;
  }

  /** Age of last successful MTF refresh in seconds (or -1 if never refreshed). */
  ageSecs(): number {
    if (!this.summary) return -1;
    return Math.round((Date.now() - this.summary.updatedAt) / 1_000);
  }

  /**
   * Force an immediate MTF refresh outside the normal schedule.
   * Called by the watchdog when the summary is stale.
   */
  forceRefresh() {
    console.info("[mtf] forceRefresh() called by watchdog");
    void this.refreshFast();
    void this.refreshSlow();
  }

  /** Is a LONG signal aligned with the MTF bias? */
  allowsLong(minScore = -1): boolean {
    return (this.getSummary()?.score ?? 0) >= minScore;
  }

  /** Is a SHORT signal aligned with the MTF bias? */
  allowsShort(maxScore = 1): boolean {
    return (this.getSummary()?.score ?? 0) <= maxScore;
  }

  private async refreshFast() {
    if (this.refreshingFast) return; // interval and watchdog share this guard
    this.refreshingFast = true;
    try {
      await this._refreshFastBody();
    } finally {
      this.refreshingFast = false;
    }
  }

  private async refreshSlow() {
    if (this.refreshingSlow) return; // interval and watchdog share this guard
    this.refreshingSlow = true;
    try {
      await this._refreshSlowBody();
    } finally {
      this.refreshingSlow = false;
    }
  }

  private async _refreshFastBody() {
    try {
      const [m1Res, m5Res, m15Res] = await Promise.all([
        fetchFastOHLC(1, 60),
        fetchFastOHLC(5, 60),
        fetchFastOHLC(15, 60),
      ]);

      this.m1  = m1Res.data.length  > 20 ? classifyTF(m1Res.data,  '1m')  : null;
      this.m5  = m5Res.data.length  > 20 ? classifyTF(m5Res.data,  '5m')  : null;
      this.m15 = m15Res.data.length > 20 ? classifyTF(m15Res.data, '15m') : null;

      // Track whether this refresh leaned on the bounded stale-cache fallback
      // for any leg, and the oldest such cache entry — so a summary that
      // "just refreshed" (updatedAt = now) can still be flagged as degraded
      // instead of looking indistinguishable from a fully live refresh.
      const staleLegs: string[] = [];
      let maxStaleAgeMs = 0;
      for (const [label, res] of [['1m', m1Res], ['5m', m5Res], ['15m', m15Res]] as const) {
        if (res.stale) {
          staleLegs.push(label);
          maxStaleAgeMs = Math.max(maxStaleAgeMs, res.staleAgeMs);
        }
      }
      this.fastCacheDegraded = staleLegs.length > 0;
      this.fastCacheStaleLegs = staleLegs;
      this.fastCacheMaxStaleAgeMs = maxStaleAgeMs;
      if (staleLegs.length > 0) {
        console.warn(`[mtf] fast refresh degraded — using cached data for ${staleLegs.join(', ')} (oldest ${Math.round(maxStaleAgeMs / 1_000)}s)`);
      }

      this.rebuildSummary();
    } catch (err) {
      console.warn(`[mtf] fast refresh failed: ${(err as Error).message}`);
    }
  }

  private async _refreshSlowBody() {
    try {
      const [h1Candles, h4Candles] = await Promise.all([
        fetchSlowOHLC(60, 60),
        fetchSlowOHLC(240, 60),
      ]);

      this.h1 = h1Candles.length > 20 ? classifyTF(h1Candles, '1h') : null;
      this.h4 = h4Candles.length > 20 ? classifyTF(h4Candles, '4h') : null;

      this.rebuildSummary();
    } catch (err) {
      console.warn(`[mtf] slow refresh failed: ${(err as Error).message}`);
    }
  }

  private rebuildSummary() {
    // Need at least one primary (fast) leg or the 1h secondary to produce a
    // meaningful summary; otherwise leave the previous summary in place so
    // getSummary()'s staleness check (not an abrupt reset to neutral) governs.
    if (!this.m1 && !this.m5 && !this.m15 && !this.h1) return;

    const floor = this.floorStrike > 0
      ? this.floorStrike
      : (this.m15?.price ?? this.h1?.price ?? BTC_FLOOR_FALLBACK);

    this.summary = synthesise(
      this.m1, this.m5, this.m15, this.h1, this.h4, floor,
      this.fastCacheStaleLegs, this.fastCacheMaxStaleAgeMs,
    );

    console.info(`[mtf] score=${this.summary.score} bias=${this.summary.bias} ` +
      `1m=${this.m1?.bias ?? 'n/a'} 5m=${this.m5?.bias ?? 'n/a'} 15m=${this.m15?.bias ?? 'n/a'} 1h=${this.h1?.bias ?? 'n/a'} ` +
      `dynStop=${this.summary.dynamicStopCents}¢ dynProfit=${this.summary.dynamicProfitCents}¢` +
      (this.summary.usedStaleFastCache ? ` [degraded: stale ${this.summary.staleFastLegs.join(',')} @${Math.round(this.summary.staleFastAgeMs / 1000)}s]` : ''));
  }
}

export type MtfOhlcBar = { open: number; high: number; low: number; close: number };

/**
 * Read-only view of already-fetched OHLC. No extra API.
 * intervalMins: 1/5/15 (fast) or 60/240 (slow). Used by mtf-structure.
 */
export function getMtfOhlcBars(intervalMins: number): { bars: MtfOhlcBar[]; ts: number } | null {
  const cached = slowOhlcCache.get(intervalMins) ?? fastOhlcCache.get(intervalMins);
  if (!cached || cached.data.length === 0) return null;
  return { bars: cached.data, ts: cached.ts };
}

export const mtfAnalyzer = new MTFAnalyzer();
