/**
 * Integration coverage for daily execution-quality persistence. Uses a future
 * date so it cannot affect live dashboard totals.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { db, dailyFillStats } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import {
  ensureDailyFillStatsSchema,
  incrementDailyFillStats,
  loadDailyFillStats,
} from "./daily-fill-stats.js";

const TEST_DATE = "2099-02-15";

async function cleanup() {
  await db.delete(dailyFillStats).where(and(
    eq(dailyFillStats.date, TEST_DATE),
    eq(dailyFillStats.paperMode, false),
  ));
}

test("daily fill stats persist atomically and reload after a restart", async (t) => {
  await ensureDailyFillStatsSchema();
  await cleanup();
  t.after(cleanup);

  // Simulate independent order-status callbacks completing at nearly the same
  // time. Atomic upserts must preserve all counters.
  await Promise.all([
    incrementDailyFillStats({
      date: TEST_DATE, paperMode: false,
      delta: { placed: 1 },
    }),
    incrementDailyFillStats({
      date: TEST_DATE, paperMode: false,
      delta: { filled: 1, totalSlippageCents: 3, slippageSamples: 1 },
    }),
    incrementDailyFillStats({
      date: TEST_DATE, paperMode: false,
      delta: { placed: 1, cancelled: 1 },
    }),
  ]);

  // A fresh reader represents the new server process's startup hydration.
  assert.deepEqual(
    await loadDailyFillStats({ date: TEST_DATE, paperMode: false }),
    {
      placed: 2,
      filled: 1,
      cancelled: 1,
      totalSlippageCents: 3,
      slippageSamples: 1,
    },
  );
});