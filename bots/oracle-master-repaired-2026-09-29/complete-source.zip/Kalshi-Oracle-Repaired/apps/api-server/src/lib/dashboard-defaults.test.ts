/**
 * Dashboard / agent config surface (2026-08-27).
 *
 * Source-text: DEFAULT_CFG in bot.tsx and the agent BotConfig reference must
 * fail closed (paper, composer off, ExpertAgent off, 8% unused target, $313).
 * A Save-before-SSE must not POST live composer settings or a $100/$1000 start.
 *
 * Does NOT import trading-bot.ts.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT_TSX = readFileSync(
  path.resolve(DIR, "../../../kalshi-trader/src/pages/bot.tsx"),
  "utf8",
);
const AGENT = readFileSync(
  path.resolve(DIR, "../routes/agent.ts"),
  "utf8",
);

function defaultCfgBlock(): string {
  const start = BOT_TSX.indexOf("const DEFAULT_CFG");
  assert.ok(start >= 0, "DEFAULT_CFG missing from bot.tsx");
  const end = BOT_TSX.indexOf("export default function BotPage", start);
  assert.ok(end > start, "BotPage after DEFAULT_CFG missing");
  return BOT_TSX.slice(start, end);
}

test("DEFAULT_CFG fails closed: paper, composer off, ExpertAgent off, not 50%, $313", () => {
  const block = defaultCfgBlock();
  assert.match(block, /paperMode:\s*true/);
  assert.ok(!/paperMode:\s*false/.test(block), "DEFAULT_CFG must not default paperMode false");
  assert.match(block, /autoMode:\s*true/);
  assert.ok(!/autoMode:\s*false,/.test(block), "DEFAULT_CFG Adapt ON matches disk");
  assert.match(block, /useExpertAgent:\s*false/);
  assert.ok(!/useExpertAgent:\s*true/.test(block), "DEFAULT_CFG must not default useExpertAgent true");
  assert.match(block, /dailyTargetPct:\s*8/);
  assert.ok(!/dailyTargetPct:\s*50/.test(block), "DEFAULT_CFG must not default dailyTargetPct 50");
  assert.match(block, /useDailyTarget:\s*false/);
  assert.match(block, /paperStartingBalanceCents:\s*31_300/);
  assert.ok(!/paperStartingBalanceCents:\s*100_000/.test(block));
  assert.ok(!/paperStartingBalanceCents:\s*10000/.test(block));
  assert.match(block, /enable1HContracts:\s*false/);
  assert.match(block, /enable1HLive:\s*false/);
  assert.match(block, /dailyLossCapCents:\s*3000/);
  assert.match(block, /dailyLossCapPct:\s*10/);
  assert.ok(!/dailyLossCapCents:\s*150\b/.test(block), "DEFAULT_CFG must match server 3000¢ not toy 150");
  assert.ok(!/dailyLossCapCents:\s*5000/.test(block), "DEFAULT_CFG must match server 3000¢ not 5000");
  assert.ok(!/dailyLossCapPct:\s*18/.test(block), "DEFAULT_CFG must match server 10% not 18");
});

test("startingBalanceDollars pre-hydrate is $313, not $100 or $1000", () => {
  assert.match(
    BOT_TSX,
    /const \[startingBalanceDollars, setStartingBalanceDollars\] = useState\(313\);/,
  );
  assert.ok(
    !/setStartingBalanceDollars\] = useState\(100\)/.test(BOT_TSX),
    "useState(100) would POST \$100 on Save-before-SSE",
  );
  assert.ok(!/setStartingBalanceDollars\] = useState\(1000\)/.test(BOT_TSX));
});

test("agent BotConfig reference matches doctrine paper start, not \$100/\$1000", () => {
  assert.match(AGENT, /paperStartingBalanceCents: 31300/);
  assert.ok(
    !/paperStartingBalanceCents: 10000/.test(AGENT),
    "agent must not document \$100 as the paper start",
  );
  assert.match(AGENT, /paperStartingBalanceCents \?\? 31300/);
  assert.ok(!/paperStartingBalanceCents \?\? 10000/.test(AGENT));
  assert.match(AGENT, /autoMode: false/);
  assert.match(AGENT, /paperMode: true/);
  assert.match(AGENT, /useExpertAgent: false/);
});

test("agent EV gate docs name pWin, not confidence-as-p", () => {
  assert.match(AGENT, /pWin = winRateAtPrice/);
  assert.ok(
    !/EV = \(conf\/100\) \* payout_ratio/.test(AGENT),
    "agent must not document heuristic confidence as EV p",
  );
});

test("Bot page requires typing LIVE REAL MONEY to leave paper / arm 1H live / Quick Trade", () => {
  assert.match(BOT_TSX, /LiveRealMoneyDialog/);
  assert.match(BOT_TSX, /payloadNeedsLiveConfirm/);
  assert.match(BOT_TSX, /withLiveRealMoneyConfirm/);
  assert.match(BOT_TSX, /Turn off paper trading/);
  assert.match(BOT_TSX, /Enable 1H live trading/);
  assert.match(BOT_TSX, /Quick Trade spends real money/);
  assert.ok(
    !BOT_TSX.includes("onCheckedChange={v => updateCfg({ paperMode: v })}"),
    "paperMode Switch must not update without phrase confirm",
  );
  assert.ok(
    !BOT_TSX.includes("onCheckedChange={v => updateCfg({ enable1HLive: v })}"),
    "enable1HLive Switch must not update without phrase confirm",
  );
});
