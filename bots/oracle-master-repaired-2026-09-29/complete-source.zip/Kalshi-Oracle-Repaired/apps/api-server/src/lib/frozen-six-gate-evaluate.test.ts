import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import {
  FROZEN_LEFTOVER_FUNNEL_MARKERS,
  FROZEN_SIX_GATE_JUMPS_AFTER_OBS,
  frozenSixGateIsOnlyEvaluatePath,
} from "./frozen-six-gate-evaluate.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const FUNNEL = fs.readFileSync(path.join(DIR, "leftover-15m-funnel.ts"), "utf8");

test("frozen six-gate is the only evaluate path when frozenCcMode is on", () => {
  assert.equal(frozenSixGateIsOnlyEvaluatePath({ frozenCcMode: true }), true);
  assert.equal(frozenSixGateIsOnlyEvaluatePath({ frozenCcMode: false }), false);
  assert.equal(frozenSixGateIsOnlyEvaluatePath({}), false);
  assert.equal(FROZEN_SIX_GATE_JUMPS_AFTER_OBS, true);
});

test("evaluateEntry jumps to six-gate after lastObservation, before leftover mayRun/funnel.call", () => {
  const start = BOT.indexOf("private async evaluateEntry()");
  assert.ok(start >= 0, "evaluateEntry present");
  const body = BOT.slice(start, start + 250_000);
  const obsAt = body.indexOf("this.lastObservation = obs;");
  const jumpAt = body.indexOf("frozenSixGateIsOnlyEvaluatePath");
  const mayAt = body.indexOf("leftover15mEvaluateMayRun");
  const callAt = body.indexOf("leftover15mEvaluateFunnel.call");
  const frozenDecideAt = body.indexOf("decideFrozenCcEntry");
  assert.ok(obsAt >= 0 && jumpAt > obsAt, "jump after lastObservation");
  assert.ok(mayAt > jumpAt, "leftover mayRun stays after the jump");
  assert.ok(callAt > mayAt, "thin funnel.call after mayRun");
  assert.ok(
    frozenDecideAt > jumpAt && frozenDecideAt < mayAt,
    "decideFrozenCcEntry runs on the jump path, not after leftover door",
  );
  const jumpSlice = body.slice(jumpAt, mayAt);
  for (const marker of FROZEN_LEFTOVER_FUNNEL_MARKERS) {
    assert.equal(jumpSlice.includes(marker), false, `frozen jump must not run leftover marker ${marker}`);
  }
  assert.match(jumpSlice, /alignedTakeGate\(/);
  assert.match(jumpSlice, /FROZEN_CC_STRATEGY_ID/);
  // CC-only aligned gate: strategyId must be passed so considerLag is false
  // (missing strategyId → BASIS_LAG_EDGE → FROZEN_ALIGNED_NOT_CC).
  assert.match(jumpSlice, /alignedTakeGate\(\{[\s\S]*?strategyId:\s*FROZEN_CC_STRATEGY_ID/);
  assert.match(jumpSlice, /await this\.placeOrder\(/);
  assert.match(jumpSlice, /return;/);
  assert.match(body.slice(Math.max(0, jumpAt - 40), mayAt), /if \(frozenSixGateIsOnlyEvaluatePath\(this\.config\)\)/);
});

test("leftover funnel body lives in leftover-15m-funnel (host only mayRun+.call)", () => {
  assert.match(BOT, /leftover15mEvaluateFunnel\.call/);
  assert.equal(/from "\.\/trading-bot\.js"/.test(FUNNEL), false);
  assert.match(FUNNEL, /selectPaperDeskWinnerFromPool/);
  assert.match(FUNNEL, /classifyDetailedCondition/);
  assert.match(FUNNEL, /PACK_NOT_ELIGIBLE/);
  assert.match(FUNNEL, /overlayDirectionLock/);
});
