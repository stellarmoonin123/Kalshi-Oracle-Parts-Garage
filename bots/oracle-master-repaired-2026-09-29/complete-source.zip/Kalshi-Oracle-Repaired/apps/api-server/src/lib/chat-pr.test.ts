import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { splitUnifiedDiff, checkHardLocks, proposePatchPr, __resetChatPrRateLimit } from "./chat-pr.js";

function desk(): string {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "desk-"));
  fs.writeFileSync(path.join(root, "pnpm-workspace.yaml"), "packages: []\n");
  fs.mkdirSync(path.join(root, "apps/api-server/src/lib/organs"), { recursive: true });
  fs.writeFileSync(path.join(root, "apps/api-server/src/lib/foo.ts"), "export const a = 1;\nexport const b = 2;\n");
  fs.writeFileSync(path.join(root, "apps/api-server/src/lib/foo.test.ts"), "// test\n");
  return root;
}
const fooPatch = `diff --git a/apps/api-server/src/lib/foo.ts b/apps/api-server/src/lib/foo.ts
--- a/apps/api-server/src/lib/foo.ts
+++ b/apps/api-server/src/lib/foo.ts
@@ -1,2 +1,2 @@
 export const a = 1;
-export const b = 2;
+export const b = 3;
`;
const lockPatch = (p: string, minus: string, plus: string) => `--- a/${p}\n+++ b/${p}\n@@ -1,1 +1,1 @@\n-${minus}\n+${plus}\n`;

test("hard-lock files are denied (admission, size organ, *lock*, lock tests, fees, CI)", () => {
  for (const p of [
    "apps/api-server/src/lib/admission.ts", "apps/api-server/src/lib/organs/size.ts", "apps/api-server/src/lib/desk-lock.ts",
    "apps/api-server/src/lib/paper-size-lock.ts", "apps/api-server/src/lib/hard-locks.unify.test.ts", "apps/api-server/src/lib/risk-invariants.test.ts",
    "apps/api-server/src/lib/fees/kalshi-fee.ts", "apps/api-server/src/lib/organs/mind-place-bind.ts", "ci/github-workflows/locks.yml", ".env", "fly.toml",
    "apps/api-server/src/lib/chat-pr.ts",
  ]) {
    const r = checkHardLocks(splitUnifiedDiff(lockPatch(p, "a", "b")));
    assert.equal(r.ok, false, p);
  }
});

test("locked params are denied in any file (paperMode false, EV floor, Kelly, caps, reserve, band)", () => {
  for (const [minus, plus] of [
    ["const x = 1;", "config.paperMode = false;"], ["const f = EV_FLOOR;", "const f = EV_FLOOR - 1;"],
    ["k = kellyFraction(p)", "k = kellyFraction(p) * 2"], ["n = applyHardRiskLimits(a,b,c,d)", "n = c"],
    ["reservePct: 15", "reservePct: 5"], ["maxEntryPrice: 55", "maxEntryPrice: 70"],
  ]) {
    const r = checkHardLocks(splitUnifiedDiff(lockPatch("apps/api-server/src/lib/trading-bot.ts", minus!, plus!)));
    assert.equal(r.ok, false, plus);
  }
});

test("no token → validated patch returned (no PR), sandbox ran targeted test", async () => {
  __resetChatPrRateLimit();
  const root = desk();
  const seen: string[][] = [];
  const r = await proposePatchPr({ patch: fooPatch, title: "bump b" }, {
    deskRoot: root, env: {}, runTests: (_dir, tests) => { seen.push(tests); return { status: 0, out: "# pass 1\n# fail 0" }; },
  });
  assert.equal(r.ok, true);
  assert.equal((r as any).mode, "patch_only");
  assert.match((r as any).message, /CHAT_PR_GITHUB_TOKEN/);
  assert.deepEqual(seen, [["src/lib/foo.test.ts"]]);
  // live tree untouched
  assert.match(fs.readFileSync(path.join(root, "apps/api-server/src/lib/foo.ts"), "utf8"), /b = 2/);
});

test("failing sandbox tests → no PR, reason + tail returned", async () => {
  __resetChatPrRateLimit();
  const root = desk();
  const r = await proposePatchPr({ patch: fooPatch, title: "bump b" }, { deskRoot: root, env: { CHAT_PR_GITHUB_TOKEN: "t" },
    fetchImpl: (async () => new Response("{}", { status: 404 })) as unknown as typeof fetch,
    runTests: () => ({ status: 1, out: "# pass 0\n# fail 1" }) });
  assert.equal(r.ok, false);
});

test("with token → draft PR on a new chat/* branch via REST; never master; never merge", async () => {
  __resetChatPrRateLimit();
  const root = desk();
  const calls: { method: string; url: string; body?: any }[] = [];
  const base64 = Buffer.from("export const a = 1;\nexport const b = 2;\n").toString("base64");
  const fetchImpl = (async (url: string, init: any) => {
    const u = String(url).replace("https://api.github.com", "");
    const method = init?.method ?? "GET";
    const body = init?.body ? JSON.parse(init.body) : undefined;
    calls.push({ method, url: u, body });
    if (u.includes("/contents/apps/api-server/src/lib/foo.ts")) return new Response(JSON.stringify({ content: base64 }), { status: 200 });
    if (u.includes("/contents/")) return new Response("{}", { status: 404 });
    if (u.includes("/git/ref/heads/")) return new Response(JSON.stringify({ object: { sha: "base1" } }), { status: 200 });
    if (u.includes("/git/commits/base1")) return new Response(JSON.stringify({ tree: { sha: "tree0" } }), { status: 200 });
    if (u.endsWith("/git/blobs")) return new Response(JSON.stringify({ sha: "blob1" }), { status: 201 });
    if (u.endsWith("/git/trees")) return new Response(JSON.stringify({ sha: "tree1" }), { status: 201 });
    if (u.endsWith("/git/commits")) return new Response(JSON.stringify({ sha: "c1" }), { status: 201 });
    if (u.endsWith("/git/refs")) return new Response(JSON.stringify({}), { status: 201 });
    if (u.endsWith("/pulls")) return new Response(JSON.stringify({ html_url: "https://github.com/o/r/pull/9" }), { status: 201 });
    return new Response("{}", { status: 500 });
  }) as unknown as typeof fetch;
  const r = await proposePatchPr({ patch: fooPatch, title: "Bump B!" }, { deskRoot: root, env: { CHAT_PR_GITHUB_TOKEN: "tok", CHAT_PR_REPO: "o/r", CHAT_PR_BASE: "master" }, fetchImpl, runTests: () => ({ status: 0, out: "# pass 1\n# fail 0" }) });
  assert.equal(r.ok, true);
  assert.equal((r as any).mode, "pr");
  assert.match((r as any).branch, /^chat\/bump-b-/);
  const ref = calls.find((c) => c.url.endsWith("/git/refs"))!;
  assert.match(ref.body.ref, /^refs\/heads\/chat\//);
  const pr = calls.find((c) => c.url.endsWith("/pulls"))!;
  assert.equal(pr.body.draft, true);
  assert.notEqual(pr.body.head, "master");
  assert.ok(!calls.some((c) => /\/merge\b/.test(c.url)), "never merges");
});

test("denied patches never reach GitHub or the sandbox", async () => {
  __resetChatPrRateLimit();
  let touched = false;
  const r = await proposePatchPr({ patch: lockPatch("apps/api-server/src/lib/admission.ts", "a", "b"), title: "x" }, {
    deskRoot: desk(), env: { CHAT_PR_GITHUB_TOKEN: "t" }, fetchImpl: (async () => { touched = true; return new Response("{}"); }) as unknown as typeof fetch,
    runTests: () => { touched = true; return { status: 0, out: "" }; },
  });
  assert.equal(r.ok, false);
  assert.equal((r as any).denied, true);
  assert.equal(touched, false);
});
