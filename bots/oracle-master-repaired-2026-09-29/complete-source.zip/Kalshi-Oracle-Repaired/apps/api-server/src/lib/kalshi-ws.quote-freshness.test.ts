/**
 * Regression coverage for quote freshness and REST fallback identity.
 *
 * A WS heartbeat can have a fresh message timestamp while carrying an old
 * executable quote. The live entry gate must therefore receive the old
 * quoteTs, not a new Date.now(). The REST backstop must likewise never apply
 * a different active market's quote to the current ticker.
 *
 * ISOLATION: kalshiWS is a process singleton, so these tests snapshot and
 * restore the private state they exercise. No connection is started and no
 * external request is made.
 */
import assert from "node:assert/strict";
import test from "node:test";
import { kalshiWS, type KalshiTick } from "./kalshi-ws.js";

type WsInternals = {
  active: { ticker: string; floorStrike: number; closeTime: string };
  latest: KalshiTick | null;
  handleMessage: (raw: string) => void;
  pollRestPrices: () => Promise<void>;
  refreshMarket: () => Promise<void>;
  kickQuoteRecovery: (opts?: { reconnectWs?: boolean }) => void;
  _polling: boolean;
  _pollingStartedAt: number;
  _rolloverMissKickAt: number;
  _lastQuoteSig: string;
  _lastWsMessageTs: number | null;
};

const internals = kalshiWS as unknown as WsInternals;

function tickerMessage(fields: Record<string, unknown>): string {
  return JSON.stringify({
    type: "ticker",
    msg: {
      market_ticker: "KXBTC15M-QUOTE-TEST",
      ...fields,
    },
  });
}

test("all-zero WS heartbeat carries forward quoteTs instead of refreshing it", async () => {
  const originalActive = internals.active;
  const originalLatest = internals.latest;
  const originalQuoteSig = internals._lastQuoteSig;

  try {
    internals.active = {
      ticker: "KXBTC15M-QUOTE-TEST",
      floorStrike: 65_000,
      closeTime: new Date(Date.now() + 10 * 60_000).toISOString(),
    };
    internals.latest = null;
    internals._lastQuoteSig = "";

    internals.handleMessage(tickerMessage({
      yes_bid: 41,
      yes_ask: 43,
      no_bid: 57,
      no_ask: 59,
      last_price: 42,
      volume: 10,
      open_interest: 20,
    }));
    const realQuote = internals.latest as KalshiTick | null;
    if (!realQuote) throw new Error("real WS quote was not recorded");
    assert.equal(realQuote.quoteTs, realQuote.ts);

    // Ensure the heartbeat has a visibly newer message timestamp. The quote
    // timestamp must still remain exactly the timestamp of the real quote.
    await new Promise(resolve => setTimeout(resolve, 10));
    internals.handleMessage(tickerMessage({
      yes_bid: 0,
      yes_ask: 0,
      no_bid: 0,
      no_ask: 0,
      volume: 11,
      open_interest: 21,
    }));
    const heartbeat = internals.latest as KalshiTick | null;
    if (!heartbeat) throw new Error("WS heartbeat was not recorded");
    assert.ok(heartbeat.ts > realQuote.ts);
    assert.equal(heartbeat.quoteTs, realQuote.quoteTs);
    assert.equal(heartbeat.yesBid, realQuote.yesBid);
    assert.equal(heartbeat.yesAsk, realQuote.yesAsk);
    assert.equal(heartbeat.noBid, realQuote.noBid);
    assert.equal(heartbeat.noAsk, realQuote.noAsk);
  } finally {
    internals.active = originalActive;
    internals.latest = originalLatest;
    internals._lastQuoteSig = originalQuoteSig;
  }
});

test("REST fallback ignores an active market with a different ticker", async () => {
  const originalActive = internals.active;
  const originalLatest = internals.latest;
  const originalPolling = internals._polling;
  const originalFetch = globalThis.fetch;
  const originalRefresh = internals.refreshMarket;
  let refreshCalls = 0;
  const existingTick: KalshiTick = {
    ticker: "KXBTC15M-QUOTE-TEST",
    floorStrike: 65_000,
    closeTime: new Date(Date.now() + 10 * 60_000).toISOString(),
    yesPrice: 42,
    yesBid: 41,
    yesAsk: 43,
    noPrice: 58,
    noBid: 57,
    noAsk: 59,
    lastPrice: 42,
    volume: 10,
    openInterest: 20,
    source: "ws",
    ts: Date.now(),
    quoteTs: Date.now(),
  };

  try {
    internals.active = {
      ticker: "KXBTC15M-QUOTE-TEST",
      floorStrike: 65_000,
      closeTime: existingTick.closeTime,
    };
    internals.latest = existingTick;
    internals._polling = false;
    internals._rolloverMissKickAt = 0;
    internals._lastWsMessageTs = Date.now() - 8_000;
    // Miss-kick must not adopt the wrong ticker mid-test (refreshMarket mocked).
    internals.refreshMarket = (async () => { refreshCalls++; }) as typeof internals.refreshMarket;
    globalThis.fetch = (async () => ({
      ok: true,
      json: async () => ({
        markets: [{
          ticker: "KXBTC15M-WRONG-TEST",
          status: "active",
          close_time: existingTick.closeTime,
          floor_strike: 65_100,
          yes_bid_dollars: "0.10",
          yes_ask_dollars: "0.12",
          no_bid_dollars: "0.88",
          no_ask_dollars: "0.90",
        }],
      }),
    })) as unknown as typeof fetch;

    (internals as unknown as { _byTickerQuoteAt: number })._byTickerQuoteAt = 0; // R4: by-ticker read is throttled 1/s
    await internals.pollRestPrices();
    await new Promise(r => setTimeout(r, 0));
    assert.equal(internals.latest, existingTick);
    assert.equal(internals.latest.yesBid, 41);
    assert.equal(refreshCalls, 1, "wrong-ticker REST miss kicks refreshMarket");

    // The exact ticker is accepted, proving the matcher is identity-based
    // rather than merely requiring an active market in the response.
    globalThis.fetch = (async () => ({
      ok: true,
      json: async () => ({
        markets: [{
          ticker: "KXBTC15M-QUOTE-TEST",
          status: "active",
          close_time: existingTick.closeTime,
          floor_strike: 65_000,
          yes_bid_dollars: "0.45",
          yes_ask_dollars: "0.47",
          no_bid_dollars: "0.53",
          no_ask_dollars: "0.55",
        }],
      }),
    })) as unknown as typeof fetch;
    (internals as unknown as { _byTickerQuoteAt: number })._byTickerQuoteAt = 0; // R4: by-ticker read is throttled 1/s
    await internals.pollRestPrices();
    assert.notEqual(internals.latest, existingTick);
    assert.equal(internals.latest?.ticker, "KXBTC15M-QUOTE-TEST");
    assert.equal(internals.latest?.yesBid, 45);
    assert.equal(internals.latest?.yesAsk, 47);
  } finally {
    globalThis.fetch = originalFetch;
    internals.refreshMarket = originalRefresh;
    internals.active = originalActive;
    internals.latest = originalLatest;
    internals._polling = originalPolling;
  }
});

test("REST miss for active ticker defers refreshMarket (rollover gap heal)", async () => {
  const originalActive = internals.active;
  const originalLatest = internals.latest;
  const originalPolling = internals._polling;
  const originalPollingStartedAt = internals._pollingStartedAt;
  const originalMissKick = internals._rolloverMissKickAt;
  const originalFetch = globalThis.fetch;
  const originalRefresh = internals.refreshMarket;
  let refreshCalls = 0;

  try {
    internals.active = {
      ticker: "KXBTC15M-OLD-PERIOD",
      floorStrike: 65_000,
      closeTime: new Date(Date.now() - 5_000).toISOString(),
    };
    internals.latest = {
      ticker: "KXBTC15M-OLD-PERIOD",
      floorStrike: 65_000,
      closeTime: internals.active.closeTime,
      yesPrice: 42, yesBid: 41, yesAsk: 43,
      noPrice: 58, noBid: 57, noAsk: 59,
      lastPrice: 42, volume: 1, openInterest: 1,
      source: "ws",
      ts: Date.now() - 20_000,
      quoteTs: Date.now() - 20_000,
    };
    internals._polling = false;
    internals._pollingStartedAt = 0;
    internals._rolloverMissKickAt = 0;
    internals._lastWsMessageTs = Date.now() - 8_000;
    internals.refreshMarket = (async () => { refreshCalls++; }) as typeof internals.refreshMarket;
    globalThis.fetch = (async () => ({
      ok: true,
      json: async () => ({
        markets: [{
          ticker: "KXBTC15M-NEW-PERIOD",
          status: "active",
          close_time: new Date(Date.now() + 600_000).toISOString(),
          floor_strike: 65_100,
          yes_bid_dollars: "0.40",
          yes_ask_dollars: "0.42",
          no_bid_dollars: "0.58",
          no_ask_dollars: "0.60",
        }],
      }),
    })) as unknown as typeof fetch;

    (internals as unknown as { _byTickerQuoteAt: number })._byTickerQuoteAt = 0; // R4: by-ticker read is throttled 1/s
    await internals.pollRestPrices();
    await new Promise(r => setTimeout(r, 0));
    assert.equal(refreshCalls, 1, "rollover miss must kick refreshMarket");
    assert.equal(internals.latest?.ticker, "KXBTC15M-OLD-PERIOD", "exact-match miss must not adopt wrong ticker inline");
  } finally {
    globalThis.fetch = originalFetch;
    internals.refreshMarket = originalRefresh;
    internals.active = originalActive;
    internals.latest = originalLatest;
    internals._polling = originalPolling;
    internals._pollingStartedAt = originalPollingStartedAt;
    internals._rolloverMissKickAt = originalMissKick;
  }
});

test("kickQuoteRecovery clears stuck _pollingStartedAt and invokes refreshMarket", async () => {
  const originalPolling = internals._polling;
  const originalStarted = internals._pollingStartedAt;
  const originalRefresh = internals.refreshMarket;
  const originalFetch = globalThis.fetch;
  const originalActive = internals.active;
  let refreshCalls = 0;
  try {
    internals.active = {
      ticker: "KXBTC15M-QUOTE-TEST",
      floorStrike: 65_000,
      closeTime: new Date(Date.now() + 600_000).toISOString(),
    };
    internals._polling = true;
    internals._pollingStartedAt = Date.now() - 5_000; // > REST_POLL_TIMEOUT_MS
    const stuckStartedAt = internals._pollingStartedAt;
    internals.refreshMarket = (async () => { refreshCalls++; }) as typeof internals.refreshMarket;
    globalThis.fetch = (async () => ({
      ok: true,
      json: async () => ({ markets: [] }),
    })) as unknown as typeof fetch;
    internals.kickQuoteRecovery({ reconnectWs: false });
    await new Promise(r => setTimeout(r, 0));
    assert.ok(refreshCalls >= 1);
    // Stuck 5s-old mutex must not survive; a fresh in-flight poll may set _polling again.
    assert.notEqual(internals._pollingStartedAt, stuckStartedAt);
    assert.ok(
      internals._pollingStartedAt === 0 || (Date.now() - internals._pollingStartedAt) < 2_000,
    );
  } finally {
    globalThis.fetch = originalFetch;
    internals._polling = originalPolling;
    internals._pollingStartedAt = originalStarted;
    internals.refreshMarket = originalRefresh;
    internals.active = originalActive;
  }
});
