import { db, tasksTable, settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./logger";
import { aiComplete } from "./ai-client.js";

async function getModelFromSettings(): Promise<string | null> {
  const rows = await db.select().from(settingsTable).limit(1);
  const settings = rows[0];
  if (!settings?.openaiApiKey) return null;
  return settings.model ?? "grok-3-mini";
}

async function updateTask(id: number, updates: Partial<typeof tasksTable.$inferInsert>) {
  await db
    .update(tasksTable)
    .set({ ...updates, updatedAt: new Date() })
    .where(eq(tasksTable.id, id));
}

async function callLLM(systemPrompt: string, userPrompt: string): Promise<string> {
  return aiComplete(systemPrompt, userPrompt);
}

export async function runResearchAgent(taskId: number): Promise<void> {
  logger.info({ taskId }, "Agent starting");

  // Get task
  const taskRows = await db.select().from(tasksTable).where(eq(tasksTable.id, taskId));
  const task = taskRows[0];
  if (!task) {
    logger.error({ taskId }, "Task not found");
    return;
  }

  // Check if API key is configured
  const model = await getModelFromSettings();
  if (!model) {
    await updateTask(taskId, {
      status: "error",
      errorMessage: "No Grok API key configured. Go to Settings to add your xAI key.",
    });
    return;
  }

  const taskTitle = task.title;

  try {
    // ─── Phase 1: Research ───────────────────────────────────────────────
    await updateTask(taskId, { status: "running", phase: "research" });
    logger.info({ taskId }, "Phase: research");

    const researchResults = await callLLM(
      `You are a thorough research assistant for a solo indie developer. 
You provide detailed, practical, and technically grounded research findings. 
Focus on actionable information, real examples, and concrete data points.
Format your response with clear sections using markdown headers.`,
      `Research this task thoroughly and provide comprehensive findings:

"${taskTitle}"

Include:
- Key concepts and background context
- Current state of the art / existing solutions
- Relevant technical approaches, tools, or frameworks
- Real-world examples or case studies where applicable
- Key data points, metrics, or benchmarks
- Reliable sources and references (include URLs if known)

Be thorough and specific. This is the raw research phase — breadth and depth matter.`
    );

    await updateTask(taskId, { researchResults });

    // ─── Phase 2: Analysis ───────────────────────────────────────────────
    await updateTask(taskId, { phase: "analyze" });
    logger.info({ taskId }, "Phase: analyze");

    const analysis = await callLLM(
      `You are a strategic analyst for a solo indie developer. 
You identify opportunities, gaps, feasibility concerns, and practical implications.
Be direct and opinionated — no fluff. Think like a seasoned technical founder.`,
      `Analyze the following research for the task: "${taskTitle}"

Research findings:
${researchResults}

Provide a structured analysis covering:
- **Opportunities**: What are the highest-value opportunities identified?
- **Gaps**: What is missing, underserved, or poorly solved today?
- **Feasibility for solo dev**: What can realistically be built by one developer? What's the effort/impact tradeoff?
- **Risks & challenges**: What are the main technical, market, or execution risks?
- **Dependencies**: What external tools, APIs, or data sources would be needed?
- **Quick wins**: What could be prototyped or shipped in a week?`
    );

    await updateTask(taskId, { analysis });

    // ─── Phase 3: Critique ───────────────────────────────────────────────
    await updateTask(taskId, { phase: "critique" });
    logger.info({ taskId }, "Phase: critique");

    const critique = await callLLM(
      `You are a rigorous critic and devil's advocate for a solo indie developer.
Your job is to stress-test analysis, find blind spots, and improve the quality of conclusions.
Be constructively critical — your goal is to make the final output better, not just tear things down.`,
      `Critically review this analysis for the task: "${taskTitle}"

Analysis:
${analysis}

Provide a structured critique:
- **Completeness**: What important angles are missing from the analysis?
- **Bias check**: Are there assumptions or biases that could skew the conclusions?
- **Actionability**: Is the analysis concrete enough to act on? What's vague or hand-wavy?
- **Alternative perspectives**: What would a skeptic or competitor say?
- **Prioritization**: Are the right things being prioritized? What should move up or down?
- **Improved recommendations**: Based on your critique, what refined or additional recommendations would you make?`
    );

    await updateTask(taskId, { critique });

    // ─── Phase 4: Final Report ───────────────────────────────────────────
    await updateTask(taskId, { phase: "report" });
    logger.info({ taskId }, "Phase: report");

    const finalReport = await callLLM(
      `You are a senior technical writer and strategist synthesizing research for a solo indie developer.
Write clearly and concisely. Use markdown formatting for excellent readability.
Be actionable and specific — every section should help the developer decide what to do next.`,
      `Synthesize all the work below into a polished, structured final report for the task:

"${taskTitle}"

## Source Material

### Research Findings
${researchResults}

### Analysis
${analysis}

### Self-Critique & Improvements
${critique}

---

Write a final report with these sections:

# [Task Title] — Research Report

## Executive Summary
(3-5 sentences: what was researched, key finding, top recommendation)

## Key Findings
(Bullet points of the most important research insights)

## Opportunities & Gaps
(What's worth pursuing and why)

## Feasibility Assessment
(For a solo indie developer — what's realistic, what's a stretch)

## Risks to Watch
(Top 3-5 risks with brief mitigation notes)

## Recommended Actions
(Numbered list, ordered by priority — specific and immediately actionable)

## Quick Wins
(Things that can be prototyped or shipped within 1-2 weeks)

---
*Generated by SoloDev Researcher Agent*`
    );

    await updateTask(taskId, {
      finalReport,
      status: "done",
      phase: "report",
    });

    logger.info({ taskId }, "Agent completed successfully");
  } catch (err) {
    logger.error({ taskId, err }, "Agent error");
    await updateTask(taskId, {
      status: "error",
      errorMessage: err instanceof Error ? err.message : "Unknown error occurred",
    });
  }
}
