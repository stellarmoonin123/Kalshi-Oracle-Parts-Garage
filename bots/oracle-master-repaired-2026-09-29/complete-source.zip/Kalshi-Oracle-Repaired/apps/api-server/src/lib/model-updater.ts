/**
 * model-updater.ts — Daily model chain auto-updater
 *
 * Probes all known + speculative model slugs against the live OpenRouter
 * proxy every morning at 06:00 Eastern Time. Confirmed-live models are ranked
 * by capability and stored in memory. Both ai-client.ts and agent.ts read from
 * getConfirmedModels() so the fallback chain is always current without a deploy.
 *
 * Startup: probe runs immediately so the chain is populated before the first
 * trade. If the probe hasn't finished yet, the hardcoded SAFE_FALLBACK list
 * is used so the bot is never left with an empty chain.
 */

import cron   from "node-cron";
import { logger } from "./logger.js";

// ── Candidates to probe ────────────────────────────────────────────────────
// Includes current confirmed models + speculative "next-gen" slugs so newly
// released models are picked up automatically on the next daily probe.
const CANDIDATES: string[] = [
  // ── Anthropic ─────────────────────────────────────────────────────────────
  "anthropic/claude-opus-4-5",
  "anthropic/claude-opus-4",
  "anthropic/claude-sonnet-4-6",
  "anthropic/claude-sonnet-4-5",
  "anthropic/claude-haiku-4-5",
  // next-gen speculative
  "anthropic/claude-opus-5",
  "anthropic/claude-opus-5-5",
  "anthropic/claude-sonnet-5",
  "anthropic/claude-sonnet-5-5",
  "anthropic/claude-haiku-5",
  "anthropic/claude-haiku-5-5",
  // ── Google ────────────────────────────────────────────────────────────────
  "google/gemini-3.1-pro-preview",
  "google/gemini-2.5-flash",
  "google/gemini-2.5-pro-preview",
  "google/gemini-2.5-ultra",
  "google/gemini-3.0-pro",
  "google/gemini-3.0-flash",
  "google/gemini-3.0-ultra",
  // ── OpenAI (via OpenRouter slug) ──────────────────────────────────────────
  "openai/gpt-4.1",
  "openai/gpt-4.2",
  "openai/gpt-5",
  "openai/gpt-5.4-mini",
  "openai/o3",
  "openai/o3-mini",
  "openai/o4",
  "openai/o4-mini",
  // ── DeepSeek ──────────────────────────────────────────────────────────────
  "deepseek/deepseek-r1-0528",
  "deepseek/deepseek-r1",
  "deepseek/deepseek-r2",
  "deepseek/deepseek-v3-0324",
  // ── xAI ───────────────────────────────────────────────────────────────────
  "x-ai/grok-3",
  "x-ai/grok-4",
  "x-ai/grok-3-mini",
  "x-ai/grok-4-mini",
];

// ── Safe fallback (hardcoded last-known-good) ──────────────────────────────
// Used only if the probe hasn't completed yet on first startup.
// Ordered cheapest-capable-first so early requests don't accidentally land on
// expensive flagship models before the daily probe re-ranks the live list.
export const SAFE_FALLBACK: string[] = [
  "openai/gpt-4o-mini",           // cheapest confirmed-live (2026-09-24) — reliable JSON
  "openai/gpt-5.4-mini",          // cheap, listed 2026-09-24
  "google/gemini-2.5-flash",      // cheap; excellent structured JSON
  "openai/gpt-4.1",               // listed 2026-09-24
  "deepseek/deepseek-r1-0528",    // very cheap; good reasoning
  "google/gemini-3.1-pro-preview", // higher capability when needed
];

/** Keep only slugs present in the OpenRouter /models listing. */
export function filterListedModels(candidates: string[], listed: Set<string>): string[] {
  return candidates.filter(m => listed.has(m));
}

/**
 * Replace the working list when the probe confirms at least 2 live models.
 * (Was: >= SAFE_FALLBACK.length (6) — once several fallback slugs rotted, the
 * probe could never replace the dead list and every call failed.)
 */
export function shouldReplaceConfirmed(liveCount: number): boolean {
  return liveCount >= 2;
}

// ── Cost-efficiency scorer ─────────────────────────────────────────────────
// Ranks model slugs by cost-efficiency: cheap-but-capable models score higher
// than expensive flagship models. All confirmed-live models can handle the
// structured JSON tasks in this system; using the cheapest capable one first
// keeps API bills low and falls back to heavier models only when needed.
// Higher = preferred (cheaper & capable).
export function scoreModel(id: string): number {
  let s = 0;

  // Provider base tier — ordered by cost-efficiency (cheapest first)
  if (id.startsWith("google/"))    s += 50_000; // Flash is cheapest capable
  if (id.startsWith("deepseek/"))  s += 40_000; // very cheap, good reasoning
  if (id.startsWith("x-ai/"))      s += 30_000;
  if (id.startsWith("openai/"))    s += 20_000;
  if (id.startsWith("anthropic/")) s += 10_000; // most expensive provider

  // Model tier — prefer smaller/cheaper within each provider
  // Google: flash cheapest, then pro, then ultra
  if (id.includes("flash"))  s += 3_000;
  if (id.includes("pro") && !id.includes("ultra")) s += 1_500;
  if (id.includes("ultra"))  s +=   500;
  // Anthropic: haiku cheapest, then sonnet, then opus (most expensive)
  if (id.includes("haiku"))  s += 3_000;
  if (id.includes("sonnet")) s += 1_500;
  if (id.includes("opus"))   s +=   300; // last resort — very expensive
  // OpenAI: mini cheapest, then gpt-5.4-mini, then gpt-5 / gpt-4.1+
  if (id.includes("-mini"))  s += 3_000; // mini is preferred for cost
  if (id.includes("gpt-4o") && !id.includes("mini")) s += 1_500;
  if (id.includes("gpt-4.1")) s +=   800;
  if (id.includes("/o3"))    s +=   600;
  if (id.includes("/o4"))    s +=   400;
  if (id.includes("gpt-5"))  s +=   200;
  // DeepSeek: v3 cheapest, then r1, then r2
  if (id.includes("v3"))     s += 2_000;
  if (id.includes("r1"))     s += 1_500;
  if (id.includes("r2"))     s +=   800;
  // xAI: mini preferred
  if (id.includes("grok-3")) s += 1_500;
  if (id.includes("grok-4")) s += 1_000;

  // Version number bonus — higher version wins within family.
  // Only applies to 1–2 digit numbers (≤99) to avoid treating date-format
  // release tags like -0528 (May 28) as version 528 and falsely boosting models.
  const vMatches = [...id.matchAll(/[.\-](\d{1,2})[.\-](\d{1,2})\b/g)];
  for (const m of vMatches) {
    s += parseInt(m[1], 10) * 100 + parseInt(m[2], 10) * 10;
  }
  const singleVer = id.match(/[.\-](\d{1,2})$/);
  if (singleVer) s += parseInt(singleVer[1], 10) * 100;

  return s;
}

// ── Capability scorer ──────────────────────────────────────────────────────
// Ranks model slugs by raw reasoning capability, independent of cost. This is
// the opposite optimization target from scoreModel() above: ARIA's risk
// analysis should default to the smartest available model, not the cheapest.
// Higher = more capable (frontier flagship > mid-tier > fast/cheap tier).
export function scoreModelCapability(id: string): number {
  let s = 0;

  // Frontier tier — most capable reasoning models on the market.
  if (id.includes("opus"))    s += 100_000;
  if (id.includes("gpt-5"))   s +=  95_000;
  if (id.includes("/o3") || id.includes("/o4")) s += 90_000;
  if (id.includes("grok-4"))  s +=  85_000;
  if (id.includes("ultra"))   s +=  82_000;

  // High-capability mid tier.
  if (id.includes("sonnet")) s += 70_000;
  if (id.includes("gemini") && id.includes("pro")) s += 65_000;
  if (id.includes("gpt-4.1") || id.includes("gpt-4.2")) s += 60_000;
  if (id.includes("r1") || id.includes("r2")) s += 55_000; // deepseek reasoning models
  if (id.includes("grok-3")) s += 50_000;
  if (id.includes("gpt-4o")) s += 48_000;

  // Fast/cheap tier — capable enough for structured JSON but not frontier-grade.
  if (id.includes("haiku")) s += 20_000;
  if (id.includes("flash")) s += 18_000;
  if (id.includes("v3"))    s += 15_000; // deepseek non-reasoning

  // "mini" variants are the weakest member of whichever family they belong to.
  if (id.includes("-mini")) s -= 30_000;

  // Version bonus within a family — e.g. opus-5 > opus-4-5 > opus-4.
  // Trailing "-major-minor" (e.g. "-4-5") and trailing "-major" (e.g. "-5") are
  // mutually exclusive matches against the *same* trailing digits — checking
  // both unconditionally used to double-count the minor version and made a
  // major.minor release (opus-4-5) outrank a later major-only release
  // (opus-5), which is backwards. Minor defaults to 0 when absent so a bare
  // major version still compares correctly against major.minor siblings.
  const twoPart = id.match(/[.\-](\d{1,2})-(\d{1,2})$/);
  if (twoPart) {
    s += parseInt(twoPart[1], 10) * 10 + parseInt(twoPart[2], 10);
  } else {
    const singleVer = id.match(/[.\-](\d{1,2})$/);
    if (singleVer) s += parseInt(singleVer[1], 10) * 10;
  }

  return s;
}

// ── Human-readable label ───────────────────────────────────────────────────
export function labelFor(id: string): string {
  const slug = id.split("/").pop() ?? id;
  return slug
    .replace("claude-", "Claude ")
    .replace("gemini-", "Gemini ")
    .replace("gpt-",    "GPT-")
    .replace("deepseek-", "DeepSeek ")
    .replace("grok-", "Grok-")
    .replace(/-(\d)/g, " $1")
    .replace(/-/g, " ")
    .replace(/\b\w/g, c => c.toUpperCase())
    .trim();
}

// ── State ──────────────────────────────────────────────────────────────────
let confirmedModels: string[] = [...SAFE_FALLBACK]; // immediately usable
let lastProbeAt   = 0;
let probeRunning  = false;

// ── Probe ──────────────────────────────────────────────────────────────────
export async function probe(): Promise<void> {
  if (probeRunning) return;
  probeRunning = true;

  const base = process.env["AI_INTEGRATIONS_OPENROUTER_BASE_URL"];
  const key  = process.env["AI_INTEGRATIONS_OPENROUTER_API_KEY"];
  if (!base || !key) {
    logger.warn("[model-updater] Missing OPENROUTER env vars — keeping safe fallback list");
    probeRunning = false;
    return;
  }

  // Free listing first: never probe (or keep) slugs OpenRouter no longer lists.
  let candidates = [...new Set([...SAFE_FALLBACK, ...CANDIDATES])];
  try {
    const lr = await fetch(`${base.replace(/\/$/, "")}/models`, { signal: AbortSignal.timeout(10_000) });
    if (lr.ok) {
      const listed = new Set(((await lr.json()) as { data?: Array<{ id: string }> }).data?.map(m => m.id) ?? []);
      if (listed.size > 0) candidates = filterListedModels(candidates, listed);
    }
  } catch { /* listing optional — fall back to probing everything */ }
  logger.info(`[model-updater] 🔍 Probing ${candidates.length} model candidates…`);
  const started = Date.now();

  // Task #270: a previously-live model (e.g. Gemini 2.5 Pro) was dropping out of
  // the daily probe despite passing real ARIA calls fine. Root cause: all ~34
  // candidates fired in parallel against a tight 15s timeout — under that
  // simultaneous load a slow-but-healthy model's response can miss the window
  // and get marked dead for 24h+ even though it works with the longer timeouts
  // ARIA's real calls use. Fix: raise the per-model timeout, and give a model
  // that was live as of the last successful probe one retry on a timeout/
  // network error before concluding it's actually dead — a single-shot probe
  // under N-way parallel load is not reliable enough evidence to demote it.
  const PROBE_TIMEOUT_MS = 25_000;

  async function probeOnce(model: string): Promise<{ model: string; live: boolean; retryable: boolean }> {
    try {
      const resp = await fetch(`${base}/chat/completions`, {
        method:  "POST",
        headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          messages: [{ role: "user", content: "Reply with exactly the word ok." }],
          // Reasoning models (including Gemini Pro) can spend the first few
          // tokens thinking, leaving message.content null at very low budgets.
          // This is only a liveness probe, so leave enough room for reasoning
          // before deciding that an otherwise healthy model is unavailable.
          max_tokens: 20,
        }),
        signal: AbortSignal.timeout(PROBE_TIMEOUT_MS),
      });
      const body = await resp.json() as {
        choices?: { message?: { content?: string } }[];
        error?:   { message?: string };
      };

      if (!resp.ok) {
        // 400 with "not a valid model" = permanently bad slug — not retryable
        const errMsg = body.error?.message ?? "";
        if (resp.status === 400 && /not a valid model|invalid model/i.test(errMsg)) {
          return { model, live: false, retryable: false };
        }
        // 429 / 5xx = transient — treat as live to avoid false negatives
        if (resp.status === 429 || resp.status >= 500) {
          logger.debug(`[model-updater] ${model}: ${resp.status} (transient) → treated as live`);
          return { model, live: true, retryable: false };
        }
        return { model, live: false, retryable: false };
      }

      // 200: must have a non-null content to count as truly live
      const content = body.choices?.[0]?.message?.content;
      return { model, live: content != null, retryable: content == null };
    } catch (err) {
      // Timeout (AbortError) or network error under parallel-probe load — retryable.
      const isAbort = (err instanceof Error && err.name === "AbortError") || (err instanceof Error && err.name === "TimeoutError");
      return { model, live: false, retryable: isAbort || err instanceof TypeError };
    }
  }

  const previouslyLive = new Set(confirmedModels);

  // Probe all candidates in parallel.
  const firstPass = await Promise.all(candidates.map(model => probeOnce(model)));

  // Give previously-confirmed-live models one retry (staggered, not fully
  // parallel again) if their first pass failed for a retryable reason —
  // avoids re-creating the same simultaneous-load contention that likely
  // caused the miss in the first place.
  const retryCandidates = firstPass.filter(r => !r.live && r.retryable && previouslyLive.has(r.model));
  const retryResults = new Map<string, { model: string; live: boolean }>();
  for (const r of retryCandidates) {
    await new Promise(res => setTimeout(res, 250)); // small stagger, not a thundering herd
    const retried = await probeOnce(r.model);
    retryResults.set(r.model, retried);
    if (retried.live) {
      logger.info(`[model-updater] ${r.model}: recovered on retry (was previously live, first probe timed out under parallel load)`);
    }
  }

  const results = firstPass.map(r => retryResults.get(r.model) ?? r);

  const live = results
    .filter(r => r.live)
    .map(r => r.model)
    .sort((a, b) => scoreModel(b) - scoreModel(a));

  const elapsed = ((Date.now() - started) / 1000).toFixed(1);
  logger.info(
    `[model-updater] ✅ Probe complete in ${elapsed}s — ` +
    `${live.length}/${candidates.length} live: ${live.join(", ")}`
  );

  // Only update if probe found at least as many models as our fallback.
  // If the network is down and probe returns 0, don't clobber the working list.
  if (shouldReplaceConfirmed(live.length)) {
    confirmedModels = live;
  } else {
    logger.warn(
      `[model-updater] ⚠️  Only ${live.length} models confirmed — keeping previous list (${confirmedModels.length} entries)`
    );
  }

  lastProbeAt   = Date.now();
  probeRunning  = false;
}

// ── Public API ─────────────────────────────────────────────────────────────

/** Returns confirmed-live OpenRouter model slugs, best-first. */
export function getConfirmedModels(): string[] {
  return confirmedModels;
}

/**
 * Returns the single most capable confirmed-live model, ranked by
 * scoreModelCapability() rather than cost-efficiency. Used to give ARIA the
 * strongest available reasoning model by default. Re-evaluates against
 * whatever the current confirmed list is, so it self-corrects after every
 * daily probe without needing a restart or a hardcoded slug.
 */
export function getStrongestConfirmedModel(): string {
  const models = confirmedModels.length > 0 ? confirmedModels : SAFE_FALLBACK;
  return [...models].sort((a, b) => scoreModelCapability(b) - scoreModelCapability(a))[0]!;
}

/** Status snapshot for healthz and diagnostics. */
export function getModelUpdaterStatus(): {
  lastProbeAt: number;
  confirmedCount: number;
  models: string[];
  nextProbeEt: string;
} {
  const now  = new Date();
  const next = new Date(now);
  next.setHours(6, 0, 0, 0);
  if (next <= now) next.setDate(next.getDate() + 1);
  return {
    lastProbeAt,
    confirmedCount: confirmedModels.length,
    models:         [...confirmedModels],
    nextProbeEt:    next.toLocaleString("en-US", { timeZone: "America/New_York" }),
  };
}

/** Start the updater: probe immediately at startup, then daily at 06:00 ET. */
export function startModelUpdater(): void {
  // Immediate probe — fire-and-forget; chain falls back to SAFE_FALLBACK until done.
  probe().catch(err => logger.error({ err }, "[model-updater] startup probe failed"));

  // Daily at 06:00 Eastern Time (handles EST/EDT automatically)
  cron.schedule("0 6 * * *", () => {
    probe().catch(err => logger.error({ err }, "[model-updater] scheduled probe failed"));
  }, { timezone: "America/New_York" });

  logger.info("[model-updater] 🕐 Daily probe scheduled — 06:00 America/New_York");
}
