/**
 * decision-safety.ts
 *
 * Single source of truth for "is it safe to evaluate a NEW entry right now?".
 * Aggregates checks that already existed scattered across trading-bot.ts and
 * trade-path.ts (WS/MTF staleness, live balance staleness, auth failure, ARIA
 * DANGER veto, sustained-HIGH-risk streak) into one auditable gate, called
 * once per tick right before strategy evaluation.
 *
 * Deliberately does NOT gate management of an already-open position — the
 * tick body returns before this gate whenever a trade is open, so stop-loss /
 * profit-take / add-to-position monitoring always keeps running even when
 * data is stale or ARIA is in DANGER. Blocking that path would be far more
 * dangerous than a stale entry signal.
 */
import { logger } from "./logger.js";
import { kalshiWS } from "./kalshi-ws.js";
import { mtfAnalyzer } from "./mtf-analyzer.js";
import { tradingBot } from "./trading-bot.js";
import { expertAgent } from "./expert-agent.js";
import { isAriaDangerVeto } from "./trade-path.js";
import { watchdog } from "./watchdog.js";
import { getReconcileHealth } from "./strategy-learner.js";

export interface SafetyCheck {
  safe: boolean;
  reasons: string[];
  classification: "ok" | "data_stale" | "risk_blocked" | "circuit_open" | "aria_danger";
}

const STALE_WS_MS = 15_000;

export function isDecisionSafe(): SafetyCheck {
  const reasons: string[] = [];
  let classification: SafetyCheck["classification"] = "ok";

  const bot = tradingBot.getStatus();

  // 1. WebSocket freshness
  const { tick, stale: wsStale } = kalshiWS.getLatestWithStaleness(STALE_WS_MS);
  if (!tick || wsStale || kalshiWS.isDegraded()) {
    reasons.push("Kalshi WS stale or degraded");
    classification = "data_stale";
  }

  // 2. MTF freshness
  if (mtfAnalyzer.isStale()) {
    reasons.push("MTF analyzer stale");
    classification = "data_stale";
  }

  // 2b. Watchdog-reported subsystem degradation (Operational Resilience design
  // item #2, 2026-08-12). watchdog.ts tracks kalshi-ws/bot-tick/mtf/open-trade
  // independently of the direct staleness checks above and trips "degraded"
  // only after repeated automatic heal attempts (reconnect/nudge/refresh) have
  // already failed — a stronger, slower-moving signal than a single staleness
  // read. Before this, "bot-tick" degraded (the tick loop itself repeatedly
  // froze and needed forced restarts) was tracked but consumed by NO
  // entry-blocking gate anywhere. kalshi-ws/mtf are folded in too as a
  // redundant safety net — they already have equivalent direct checks above,
  // but a watchdog-tripped circuit breaker can lag or lead a point-in-time
  // staleness read, so checking both closes real timing gaps either single
  // check alone could miss.
  //
  // "open-trade" is deliberately NOT read here: it only ever measures the
  // age of a currently-open position, and isDecisionSafe() gates NEW entries
  // only (the tick body returns before this gate whenever a trade is open —
  // see the file header). The two states are structurally close to mutually
  // exclusive, and folding it in would blur this gate's documented scope
  // without adding real protection.
  const watchdogStatus = watchdog.getStatus();
  for (const name of ["kalshi-ws", "bot-tick", "mtf"] as const) {
    if (watchdogStatus[name]?.status === "degraded") {
      reasons.push(`Watchdog: ${name} degraded (${watchdogStatus[name]?.lastAction ?? "repeated heal failures"})`);
      classification = "data_stale";
    }
  }

  // 3. Live balance freshness (paper mode has no live balance to go stale)
  if (!bot.config.paperMode && bot.accountBalanceStale) {
    reasons.push("Live balance stale");
    classification = "data_stale";
  }

  // 4. Auth / key health
  if (bot.authFailed) {
    reasons.push("Kalshi auth failed");
    classification = "data_stale";
  }

  // 4b. Account-wide position reconciliation. A confirmed orphan, an exchange
  // count that differs from openTrade, or no successful reconciliation yet
  // means the bot cannot safely assert it has no untracked exposure. Block NEW
  // entries only; an existing trade continues through its exit/settlement path.
  const accountPosition = bot.accountPositionState;
  const accountAuditStale = accountPosition.checkedAt === null ||
    Date.now() - accountPosition.checkedAt > 2 * 3 * 60_000;
  if (!bot.config.paperMode && (
    accountAuditStale ||
    accountPosition.status === "unknown" ||
    accountPosition.status === "tracked-mismatch" ||
    accountPosition.status === "unmanaged"
  )) {
    reasons.push(
      accountAuditStale
        ? "Live position reconciliation has not completed recently"
        : `Live position reconciliation: ${accountPosition.status}`,
    );
    if (classification === "ok") classification = "risk_blocked";
  }

  // 5. ARIA DANGER hard veto
  const aria = expertAgent.getFreshAssessment();
  if (isAriaDangerVeto(aria)) {
    reasons.push(`ARIA DANGER: ${aria?.reasoning ?? "unspecified"}`);
    classification = "aria_danger";
  }

  // 6. Sustained HIGH risk streak (surfaced here for logging clarity — the
  //    per-path ARIA rules also apply their own tighter-only overrides).
  if (expertAgent.isSustainedHighRisk()) {
    reasons.push("Sustained HIGH risk streak active");
    if (classification === "ok") classification = "risk_blocked";
  }

  // 6b. Task #151: if the one-time prior-sync pass in strategy-learner.ts
  // failed on the most recent getStore() init, priors may not reflect the
  // library's current expectedWinRate — trading on a stale/un-synced prior
  // should not happen silently. This only blocks NEW entries (see file
  // header); it never touches an already-open position.
  const reconcileHealth = getReconcileHealth();
  if (reconcileHealth.ok === false) {
    reasons.push(`Strategy-learner prior sync failed: ${reconcileHealth.error ?? "unknown error"}`);
    classification = "data_stale";
  }

  // 7. External-API circuit breakers
  if (isCircuitOpen("kalshi-api")) {
    reasons.push("Kalshi API circuit open (repeated order/balance failures)");
    classification = "circuit_open";
  }
  if (isCircuitOpen("ai-provider")) {
    reasons.push("AI provider circuit open (repeated failures)");
    classification = "circuit_open";
  }

  const safe = reasons.length === 0;
  if (!safe) {
    logger.info({ reasons, classification }, "[decision-safety] new-entry evaluation skipped this tick");
  }
  return { safe, reasons, classification };
}

// ── External-API circuit breakers ───────────────────────────────────────────
// Namespaced "kalshi-api" (order placement / balance fetch failures) and
// "ai-provider" (AI completion failures across every configured model).
// These track *outbound HTTP call* failure streaks and are intentionally
// separate from watchdog.ts's subsystem-health circuits, which answer a
// different question ("is our own WS/tick pipeline healthy?"). Do not merge
// the two concepts — one is about us, the other is about the far end.
// Only these two circuits exist today. Typing the name prevents a typo'd
// circuit name from silently fail-opening (isCircuitOpen returns false for
// any name with no record — see below).
export type CircuitName = "kalshi-api" | "ai-provider";

const circuits = new Map<CircuitName, { failures: number; openedAt: number | null; state: "closed" | "open" | "half-open" }>();

const FAILURE_THRESHOLD = 5;
const OPEN_MS = 60_000; // stay open for 60s before allowing a half-open probe

export function recordSuccess(name: CircuitName): void {
  circuits.set(name, { failures: 0, openedAt: null, state: "closed" });
}

export function recordFailure(name: CircuitName): void {
  const c = circuits.get(name) ?? { failures: 0, openedAt: null, state: "closed" as const };
  c.failures += 1;
  if (c.failures >= FAILURE_THRESHOLD && c.state !== "open") {
    c.state = "open";
    c.openedAt = Date.now();
    logger.warn({ name, failures: c.failures }, "[circuit] opened");
  }
  circuits.set(name, c);
}

// NOTE on half-open exclusivity: once OPEN_MS elapses, exactly ONE caller
// transitions the circuit to "half-open" and receives `false` (the single
// probe). Every other caller — including re-entrant calls from the same
// tick or overlapping ticks — sees `state === "half-open"` already set and
// gets `true` (still blocked) until recordSuccess/recordFailure resolves the
// probe. Without this, every caller during the transition instant would
// pass the probe check simultaneously and all hit the failing API at once.
export function isCircuitOpen(name: CircuitName): boolean {
  const c = circuits.get(name);
  if (!c || c.state === "closed") return false;
  if (c.state === "open" && c.openedAt && Date.now() - c.openedAt > OPEN_MS) {
    c.state = "half-open";
    circuits.set(name, c);
    return false; // allow exactly one probe through
  }
  if (c.state === "half-open") return true; // probe already claimed — stay blocked
  return c.state === "open";
}
