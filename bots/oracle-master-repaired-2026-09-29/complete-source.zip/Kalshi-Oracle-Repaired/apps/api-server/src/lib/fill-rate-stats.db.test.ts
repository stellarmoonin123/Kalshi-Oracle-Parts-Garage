/**
 * A confirmed entry remains `outcome='pending'` until the binary contract
 * settles. It must still count as a placed order, or the execution-quality
 * card can show a fill rate above 100%.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { db, botTrades } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { acceptedOrderForFillRate, summarizeFillAggregate } from "./fill-rate-stats.js";

const TEST_TICKER = "TASK155-OPEN-FILLED-TEST";

async function cleanup() {
  await db.delete(botTrades).where(eq(botTrades.ticker, TEST_TICKER));
}

test("an open confirmed fill remains in the all-time fill-rate denominator", async (t) => {
  await cleanup();
  t.after(cleanup);

  const now = new Date();
  await db.insert(botTrades).values({
    ticker: TEST_TICKER,
    side: "yes",
    contracts: 1,
    entryPriceCents: 50,
    signal: "LONG",
    strategyId: "TASK155_TEST",
    orderId: "task155-open-filled",
    orderPlacedAt: now,
    filledAt: now,
    fillPriceCents: 51,
    slippageCents: 1,
    outcome: "pending",
    isPaper: false,
  });

  const [counts] = await db.select({
    placed: sql<number>`count(*) filter (where ${acceptedOrderForFillRate})::int`,
    filled: sql<number>`count(*) filter (where ${botTrades.filledAt} is not null)::int`,
    cancelled: sql<number>`count(*) filter (where ${botTrades.outcome} = 'cancelled')::int`,
    slippageSamples: sql<number>`count(${botTrades.slippageCents})::int`,
    totalSlippageCents: sql<number>`coalesce(sum(${botTrades.slippageCents}), 0)::int`,
  }).from(botTrades).where(eq(botTrades.ticker, TEST_TICKER));

  assert.deepEqual(
    summarizeFillAggregate(counts),
    { placed: 1, filled: 1, cancelled: 0, avgSlippageCents: 1, fillRate: 1 },
  );
});