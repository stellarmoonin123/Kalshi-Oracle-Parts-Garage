import { test } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, mkdirSync, copyFileSync, writeFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

for (const event of ["uncaughtException", "unhandledRejection"] as const) {
  test(`${event} exits nonzero before queued trading work can resume`, () => {
    const moduleUrl = new URL("./fatal-process.ts", import.meta.url).href;
    const child = spawnSync(process.execPath, ["--import", "tsx", "--input-type=module", "-e", `
      import { installFatalProcessHandlers } from ${JSON.stringify(moduleUrl)};
      installFatalProcessHandlers();
      setTimeout(() => process.stdout.write("UNSAFE_TRADE_CONTINUED"), 100);
      ${event === "uncaughtException"
        ? 'setImmediate(() => { throw new Error("test fatal"); });'
        : 'Promise.reject(new Error("test fatal"));'}
    `], { encoding: "utf8", timeout: 10_000 });
    assert.ifError(child.error);
    assert.equal(child.signal, null);
    assert.equal(child.status, 1);
    assert.equal(child.stdout, "");
    assert.match(child.stderr, new RegExp(event));
    assert.match(child.stderr, /supervisor recovery/);
  });
}

test("the real supervisor restarts a fatal child, then honors clean exit", () => {
  const directory = mkdtempSync(join(tmpdir(), "oracle-supervisor-"));
  try {
    copyFileSync(new URL("../../supervisor.mjs", import.meta.url), join(directory, "supervisor.mjs"));
    mkdirSync(join(directory, "dist"));
    const fatalUrl = new URL("./fatal-process.ts", import.meta.url).href;
    writeFileSync(join(directory, "dist/index.mjs"), `
      import fs from 'node:fs';
      import { installFatalProcessHandlers } from ${JSON.stringify(fatalUrl)};
      installFatalProcessHandlers();
      if (!fs.existsSync('first-boot')) {
        fs.writeFileSync('first-boot', '1');
        setImmediate(() => { throw new Error('injected crash'); });
      } else {
        process.stdout.write('RECOVERED_SECOND_BOOT\\n');
        process.exit(0);
      }
    `);
    const child = spawnSync(process.execPath, [join(directory, "supervisor.mjs")], {
      encoding: "utf8", timeout: 20_000,
      env: { ...process.env, NODE_OPTIONS: `${process.env.NODE_OPTIONS ?? ""} --import ${import.meta.resolve("tsx")}` },
    });
    assert.ifError(child.error);
    assert.equal(child.status, 0);
    assert.match(child.stderr, /uncaughtException/);
    assert.match(child.stdout, /RECOVERED_SECOND_BOOT/);
    assert.match(child.stdout, /child exited cleanly/);
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});
