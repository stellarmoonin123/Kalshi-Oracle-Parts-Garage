/**
 * BRTI-only identity for sit-WATCH / frozen FILL entryTheo.
 *
 * Theo must be stamped from fresh 5Hz CF Benchmarks BRTI (same pin as
 * settlement), never from book-inferred BTC proxy. Values outside [10, 90]¢
 * are absurd vs mid-band asks (~40¢) and are rejected as null + missing.
 *
 * OBSERVE only — does not gate entry/exit, EV, or Kelly.
 */

import { binaryCallPrice } from "./backtest-engine.js";

/** Inclusive sane band for stamped entry/exit theo (¢). */
export const ENTRY_THEO_MIN_CENTS = 10;
export const ENTRY_THEO_MAX_CENTS = 90;

/** ε time at expiry/settle so BSM can stamp when minsLeft=0 (1 second). */
export const THEO_EPS_MINUTES = 1 / 60;

export type StampEntryTheoInput = {
  /** Fresh BRTI USD from getFreshBrtiUsd; null/≤0 → miss (never invent proxy). */
  brtiUsd: number | null | undefined;
  floorStrike: number;
  /** Annualized vol from price buffer (vol estimate only — spot must still be BRTI). */
  vol: number;
  /**
   * Minutes to expiry. At CLOSE/settle minsLeft is often 0 — use THEO_EPS_MINUTES
   * (1s) rather than silent inputs_incomplete when BRTI is live.
   */
  minsLeft: number;
  side: "yes" | "no";
};

export type StampEntryTheoResult = {
  entryTheoCents: number | null;
  entryTheoMissing: boolean;
  /** Raw rounded BSM before band clamp (null if inputs incomplete). */
  rawTheoCents: number | null;
  reason:
    | "ok"
    | "brti_missing"
    | "inputs_incomplete"
    | "theo_nonfinite"
    | "theo_out_of_band";
};

/**
 * Clamp/reject: theo in [10, 90] → stamp; else null + entryTheoMissing.
 * Never invents book-proxy BTC when brtiUsd is absent.
 */
export function stampEntryTheoFromBrti(input: StampEntryTheoInput): StampEntryTheoResult {
  const brti = input.brtiUsd;
  if (brti == null || !(brti > 0) || !Number.isFinite(brti)) {
    return {
      entryTheoCents: null,
      entryTheoMissing: true,
      rawTheoCents: null,
      reason: "brti_missing",
    };
  }
  const { floorStrike, vol, minsLeft, side } = input;
  if (
    !(floorStrike > 0) ||
    !(vol > 0) ||
    !Number.isFinite(floorStrike) ||
    !Number.isFinite(vol) ||
    !Number.isFinite(minsLeft) ||
    minsLeft < 0
  ) {
    return {
      entryTheoCents: null,
      entryTheoMissing: true,
      rawTheoCents: null,
      reason: "inputs_incomplete",
    };
  }
  // CLOSE/settle: minsLeft=0 must not silent-null when BRTI live — ε T (1s).
  const tMins = minsLeft > 0 ? minsLeft : THEO_EPS_MINUTES;

  let raw: number;
  try {
    const theorYes = binaryCallPrice(brti, floorStrike, vol, tMins);
    raw = side === "yes" ? theorYes : 100 - theorYes;
  } catch {
    return {
      entryTheoCents: null,
      entryTheoMissing: true,
      rawTheoCents: null,
      reason: "theo_nonfinite",
    };
  }

  if (!Number.isFinite(raw)) {
    return {
      entryTheoCents: null,
      entryTheoMissing: true,
      rawTheoCents: null,
      reason: "theo_nonfinite",
    };
  }

  const rounded = Math.round(raw);
  if (rounded < ENTRY_THEO_MIN_CENTS || rounded > ENTRY_THEO_MAX_CENTS) {
    return {
      entryTheoCents: null,
      entryTheoMissing: true,
      rawTheoCents: rounded,
      reason: "theo_out_of_band",
    };
  }

  return {
    entryTheoCents: rounded,
    entryTheoMissing: false,
    rawTheoCents: rounded,
    reason: "ok",
  };
}

/**
 * Same [10, 90] band for exit theo / any already-computed ¢ value.
 * Reject absurd 1¢ (binaryCallPrice floor) and out-of-band. Null stays missing.
 * Callers must run FILL/CLOSE/shadow ledger theo through this before persist.
 */
export function sanitizeTheoCents(theo: number | null | undefined): {
  theoCents: number | null;
  theoMissing: boolean;
} {
  if (theo == null || !Number.isFinite(theo)) {
    return { theoCents: null, theoMissing: true };
  }
  const rounded = Math.round(theo);
  // Explicit reject of binaryCallPrice Math.max(1,…) floor leak and >90 absurd.
  if (rounded < ENTRY_THEO_MIN_CENTS || rounded > ENTRY_THEO_MAX_CENTS || rounded === 1) {
    return { theoCents: null, theoMissing: true };
  }
  return { theoCents: rounded, theoMissing: false };
}

/** True when a stamped theo must not be written (null/nonfinite/1¢/out-of-band). */
export function shouldRejectTheoWrite(theo: number | null | undefined): boolean {
  return sanitizeTheoCents(theo).theoCents == null;
}
