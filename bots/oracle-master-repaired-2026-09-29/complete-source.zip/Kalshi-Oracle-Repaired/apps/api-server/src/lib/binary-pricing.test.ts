import assert from "node:assert/strict";
import test from "node:test";
import {
  binaryCallFairValueCents,
  complementaryFairValueCents,
  fairValueEdgeCents,
} from "./binary-pricing.js";

test("binaryCallFairValueCents follows digital-call N(d2)", () => {
  const atTheMoney = binaryCallFairValueCents(100_000, 100_000, 900, 0.55);
  const aboveStrike = binaryCallFairValueCents(100_500, 100_000, 900, 0.55);
  const belowStrike = binaryCallFairValueCents(99_500, 100_000, 900, 0.55);

  assert.ok(atTheMoney != null && atTheMoney < 50, "d2 includes the -0.5σ²T term");
  assert.ok(aboveStrike != null && aboveStrike > atTheMoney!);
  assert.ok(belowStrike != null && belowStrike < atTheMoney!);
});

test("binaryCallFairValueCents handles invalid and expired inputs explicitly", () => {
  assert.equal(binaryCallFairValueCents(0, 100_000, 900), null);
  assert.equal(binaryCallFairValueCents(100_000, 100_000, 0), 100);
  assert.equal(binaryCallFairValueCents(99_999, 100_000, 0), 0);
  assert.equal(binaryCallFairValueCents(100_000, 100_000, 900, 0), null);
});

test("complementary fair value and signed edge stay in cents", () => {
  assert.equal(complementaryFairValueCents(54), 46);
  const edge = fairValueEdgeCents(54, 47);
  assert.equal(edge, 7);
  assert.ok(edge != null && edge > 0);
  assert.equal(fairValueEdgeCents(null, 47), null);
});