/**
 * Leftover live Kalshi order POST (entry + early exit). Paper KXBTC15M never runs it.
 * Host paper fills stay in _placeOrderBody. Does not ENABLE.
 */
export const LEFTOVER_LIVE_ORDER_EVALUATE_LOADED = true as const;

export const LEFTOVER_LIVE_ORDER_HOST_GUARD =
  "if (!leftoverLiveOrderMayRun(this.config))";

export const FROZEN_LIVE_ORDER_MARKERS = [
  "KALSHI_PATH_PORTFOLIO_ORDERS",
  "Auth signing failed — live order blocked",
  "executeConfirmedExit(journal",
  "Order submission AMBIGUOUS",
] as const;

export function leftoverLiveOrderMayRun(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  if (cfg.paperMode === true || cfg.frozenCcMode === true) return false;
  return true;
}

export function leftoverLiveOrderHostDenied(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverLiveOrderMayRun(cfg) === false;
}

export function leftoverLiveOrderRun<T>(
  cfg: { paperMode?: boolean; frozenCcMode?: boolean },
  run: () => Promise<T>,
): Promise<T | undefined> {
  if (!leftoverLiveOrderMayRun(cfg)) return Promise.resolve(undefined);
  return run();
}
