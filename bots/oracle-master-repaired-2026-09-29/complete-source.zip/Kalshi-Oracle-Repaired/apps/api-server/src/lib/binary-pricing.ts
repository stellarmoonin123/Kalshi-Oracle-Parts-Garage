/**
 * Binary option pricing helpers.
 *
 * A Kalshi YES contract is a cash-or-nothing call: its fair value is the
 * risk-neutral probability that BTC finishes above the floor strike. With a
 * zero rate assumption, that is N(d2) from Black-Scholes.
 */

import { BTC_ANNUALISED_VOL } from "./constants.js";

function normalCdf(z: number): number {
  const sign = z >= 0 ? 1 : -1;
  const x = Math.abs(z);
  const t = 1 / (1 + 0.2316419 * x);
  const polynomial = t * (
    0.319381530 +
    t * (-0.356563782 +
      t * (1.781477937 +
        t * (-1.821255978 + t * 1.330274429)))
  );
  const density = Math.exp(-x * x / 2) / Math.sqrt(2 * Math.PI);
  const probability = 1 - density * polynomial;
  return sign === 1 ? probability : 1 - probability;
}

/**
 * Returns the Black-Scholes digital-call fair value in cents.
 *
 * d2 = [ln(S/K) - 0.5 × σ² × T] / (σ × √T)
 *
 * Values are rounded to a tenth of a cent for a stable API/UI display. Null
 * means the market inputs are not usable yet; callers should not display a
 * stale value in that case.
 */
export function binaryCallFairValueCents(
  spot: number,
  floorStrike: number,
  secondsRemaining: number,
  annualVol = BTC_ANNUALISED_VOL,
): number | null {
  if (
    !Number.isFinite(spot) ||
    !Number.isFinite(floorStrike) ||
    !Number.isFinite(secondsRemaining) ||
    !Number.isFinite(annualVol) ||
    spot <= 0 ||
    floorStrike <= 0 ||
    annualVol <= 0
  ) {
    return null;
  }

  if (secondsRemaining <= 0) return spot >= floorStrike ? 100 : 0;

  const tauYears = secondsRemaining / (365 * 24 * 60 * 60);
  const sigmaRootTau = annualVol * Math.sqrt(tauYears);
  if (!Number.isFinite(tauYears) || !Number.isFinite(sigmaRootTau) || sigmaRootTau <= 0) {
    return null;
  }

  const d2 = (Math.log(spot / floorStrike) - 0.5 * annualVol ** 2 * tauYears) / sigmaRootTau;
  const fairValue = normalCdf(d2) * 100;
  return Number.isFinite(fairValue)
    ? Math.round(Math.max(0, Math.min(100, fairValue)) * 10) / 10
    : null;
}

/** Derives the complementary NO fair value from a YES fair value. */
export function complementaryFairValueCents(yesFairValueCents: number | null): number | null {
  return yesFairValueCents == null ? null : Math.round((100 - yesFairValueCents) * 10) / 10;
}

/** Signed model edge: positive means the model values the contract above market. */
export function fairValueEdgeCents(
  fairValueCents: number | null,
  marketPriceCents: number,
): number | null {
  if (fairValueCents == null || !Number.isFinite(marketPriceCents) || marketPriceCents <= 0) {
    return null;
  }
  return Math.round((fairValueCents - marketPriceCents) * 10) / 10;
}