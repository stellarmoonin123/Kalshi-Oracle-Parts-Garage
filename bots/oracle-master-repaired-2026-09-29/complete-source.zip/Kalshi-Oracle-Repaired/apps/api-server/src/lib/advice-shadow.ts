/**
 * advice-shadow.ts — Trade/Market thin SHADOW labels.
 *
 * If a new advice strategy WOULD fire, publish a SHADOW line.
 * Never APPROVED. Dual-gate ENABLE stays false. LIVE_APPLY false.
 */
import { dualAskUnder98, isDeadZone } from "./advice-observe.js";
import { cheapEarlyExitSignal } from "./cheap-early-exit.js";
import { panicFadeSignal } from "./panic-fade.js";
import { streakSatFadeSignal } from "./streak-sat-fade.js";
import type { StrategyObservation, StrategyResult } from "./strategy-library.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;

export type AdviceShadowLabel = {
  id: "CHEAP_EARLY_EXIT" | "PANIC_FADE" | "STREAK_SAT_FADE";
  side: "YES" | "NO";
  reason: string;
  /** Always false. Thin label is not a fill license. */
  approved: false;
};

export function collectAdviceShadow(obs: StrategyObservation): AdviceShadowLabel[] {
  const out: AdviceShadowLabel[] = [];
  const rows: Array<StrategyResult | null> = [
    cheapEarlyExitSignal(obs),
    panicFadeSignal(obs),
    streakSatFadeSignal(obs),
  ];
  for (const r of rows) {
    if (!r) continue;
    if (r.signal !== "YES" && r.signal !== "NO") continue;
    const id = r.strategyId;
    if (id !== "CHEAP_EARLY_EXIT" && id !== "PANIC_FADE" && id !== "STREAK_SAT_FADE") continue;
    out.push({ id, side: r.signal, reason: r.reason, approved: false });
  }
  return out;
}

export function formatAdviceShadowLine(labels: AdviceShadowLabel[]): string | null {
  if (labels.length === 0) return null;
  return labels.map(l => `SHADOW ${l.id} ${l.side}`).join(" · ");
}

/** SHADOW would-fire + OBSERVE helpers. Never APPROVED. Does not set lean. */
export function formatAdviceDeskLine(
  obs: Pick<StrategyObservation, "yesAsk" | "noAsk" | "secsRemaining"> | null | undefined,
  labels: AdviceShadowLabel[],
): string | null {
  const parts: string[] = [];
  const sh = formatAdviceShadowLine(labels);
  if (sh) parts.push(sh);
  if (obs && dualAskUnder98(obs.yesAsk, obs.noAsk)) parts.push("OBSERVE dual-ask<98");
  if (obs && isDeadZone(obs.secsRemaining)) parts.push("OBSERVE dead-zone");
  return parts.length ? parts.join(" · ") : null;
}
