/**
 * config-persist.test.ts
 *
 * Smoke-tests for the bot's on-disk config persistence layer.
 *
 * Scenario covered (mirrors the task requirement):
 *   "disable strategy → server writes config → server restarts →
 *    loadPersistedConfig() → disabledStrategies still contains the toggled strategy"
 *
 * All tests use a temporary file so they never touch the real .bot-config.json.
 *
 * Covered behaviours:
 *   (a) round-trip: saved disabledStrategies are present after load
 *   (b) multiple disabled strategies all survive the round-trip
 *   (c) re-enabling a strategy removes it from the persisted array
 *   (d) missing file returns {} (first-run / clean state)
 *   (e) defensive guard: non-array disabledStrategies is normalised to []
 *   (f) defensive guard: null disabledStrategies is normalised to []
 *   (g) atomic write: other config fields are preserved alongside disabledStrategies
 *   (h) empty disabledStrategies array round-trips correctly
 *   (i) a manual risk-profile lock survives a restart
 *
 * Run with:
 *   node --experimental-strip-types src/lib/config-persist.test.ts
 */

import { test } from "node:test";
import assert   from "node:assert/strict";
import fs       from "node:fs";
import os       from "node:os";
import path     from "node:path";
import { loadPersistedConfig, savePersistedConfig, mergePersistedRisk, mergeDiskFrozenCcMode, restartPersistDecision, normalizePersistedConfig, isConfigSecretKey } from "./config-persist.js";
import { PATCH_FAIL_CLOSED_DISABLED, PATCH_REFUSE_FLOOR_KEYS } from "./config-patch-surface.js";
import type { BotConfig } from "./trading-bot.js";

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Returns the path to a fresh temporary file that is removed after use. */
function makeTmpPath(): string {
  return path.join(os.tmpdir(), `bot-config-test-${process.pid}-${Date.now()}.json`);
}

/** Minimal BotConfig with only the fields we need to exercise. */
function makeConfig(overrides: Partial<BotConfig> = {}): BotConfig {
  return {
    specialistPacksMode:   'shadow',
    agentControlMode:      false,
    requireAgentEntryApproval: false,
    brainCenterAuthority:  false,
    autopilotMode:         false,
    enabled:               false,
    autoMode:              false,
    autoModeV2Mode:        'suggest',
    maxContractsPerTrade:  3,
    maxDepthFraction:      0.5,
    dailyLossCapCents:     500,
    dailyLossCapPct:       10,
    minConfidence:         70,
    minVelocity:           5,
    tradeWindowMinMin:     2,
    tradeWindowMaxMin:     13,
    maxEntryPrice:         65,
    minEntryPrice:         20,
    useProbEdge:           true,
    minProbEdge:           5,
    useStallFilter:        true,
    useAcceleration:       true,
    useLossCooldown:       true,
    cooldownMultiplier:    1.5,
    paperMode:             true,
    useKellySizing:        false,
    useMultiTfConfluence:  false,
    paperStartingBalanceCents: 100_000,
    useMTFFilter:          false,
    useStrongMTFDirectionLock: true,
    minMTFScoreForLong:    0.6,
    maxMTFScoreForShort:   0.4,
    useStopLoss:           true,
    stopLossCents:         8,
    hardStopCents:         12,
    minRewardRiskRatio:    1,
    useDynamicStop:        false,
    useProfitTake:         true,
    profitTakeCents:       10,
    trailingProfitCents:   5,
    useDynamicProfit:      false,
    useTimeDecayExit:      false,
    useAddToPosition:      false,
    addConfidenceThreshold: 85,
    useKellyFraction:      false,
    useDrawdownGuard:      false,
    drawdownGuardPct:      20,
    reservePct:            10,
    useCompoundMode:       false,
    usePctStops:           false,
    softStopPct:           5,
    hardStopPct:           8,
    useTimeStop:           false,
    timeStopMinutes:       10,
    timeStopMinGainCents:  3,
    useTieredSizing:       false,
    baseRiskPct:           1,
    usePortfolioRisk:      false,
    portfolioRiskPct:      1,
    equityCurveResetAt:    0,
    disabledStrategies:    [],
    useExpertAgent:        false,
    ariaModel:             'google/gemini-2.5-flash',
    ariaIntervalSecs:      45,
    useSettlementHold:     false,
    researchShadowLoggingEnabled: false,
    settlementHoldSecsThreshold: 300,
    settlementHoldMinProb: 0.7,
    settlementHoldMinGainCents: 0,
    enable1HContracts:     false,
    enable1HLive:          false,
    hourlyMaxContracts:    10,
    strategyOverride:      null,
    maxContractVolatility: 8,
    manualRiskProfile:     null,
    useDailyTarget:        true,
    dailyTargetPct:        50,
    protectModeBehavior:   'stand_down',
    giveBackCapPct:        10,
    holdToSettlement:      true,
    velocityStallReversalRiskBudgetCents: 250,
    velocityStallReversalEnabled: false,
    settlementConsensusVoteEnabled: false,
    settlementVetoEnabled: false,
    settlementVetoMinConfidence: 80,
    bollingerBandStrategyEnabled: false,
    candlestickPatternLiveEnabled: false,
    topReversalEnabled:    false,
    bottomReversalEnabled: false,
    cheapSide15mEnabled:   true,
    useSignalStackSizing:      true,
    signalStackBonusMult:      1.08,
    signalStackBasisThreshold: 5,
    useSessionLiquiditySizing: true,
    sessionLiquidityMult:      0.8,
    frozenCcMode:              false,
    frozenCcAndSit:            false,
    frozenCcFixedContracts:    null,
    frozenCcTakeProfitCents:   null,
    frozenCcCatastrophicCents: 5,
    cheapEarlyExitEnabled:     false,
    panicFadeEnabled:          false,
    streakSatFadeEnabled:      false,
    ...overrides,
  };
}

// ── Tests ─────────────────────────────────────────────────────────────────────

// (a) round-trip: a disabled strategy survives save → load
test("(a) single disabled strategy survives save/load round-trip", () => {
  const tmp = makeTmpPath();
  try {
    const cfg = makeConfig({ disabledStrategies: ["MOMENTUM_BURST"] });
    savePersistedConfig(cfg, tmp);

    const loaded = loadPersistedConfig(tmp);
    assert.ok(
      Array.isArray(loaded.disabledStrategies),
      "disabledStrategies should be an array after load"
    );
    assert.ok(
      loaded.disabledStrategies?.includes("MOMENTUM_BURST"),
      "disabled strategy must be present after simulated restart"
    );
    for (const id of PATCH_FAIL_CLOSED_DISABLED) {
      assert.ok(loaded.disabledStrategies?.includes(id), `fail-closed must keep ${id}`);
    }
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

// (b) multiple disabled strategies all survive
test("(b) multiple disabled strategies all survive the round-trip", () => {
  const tmp = makeTmpPath();
  try {
    const strategies = ["MOMENTUM_BURST", "OTM_HUNTER", "MEAN_REVERSION_SNAP"];
    const cfg = makeConfig({ disabledStrategies: strategies });
    savePersistedConfig(cfg, tmp);

    const loaded = loadPersistedConfig(tmp);
    for (const id of strategies) {
      assert.ok(loaded.disabledStrategies?.includes(id), `${id} must survive`);
    }
    for (const id of PATCH_FAIL_CLOSED_DISABLED) {
      assert.ok(loaded.disabledStrategies?.includes(id), `fail-closed must keep ${id}`);
    }
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

test("(i) manual risk-profile lock survives the round-trip", () => {
  const tmp = makeTmpPath();
  try {
    savePersistedConfig(
      makeConfig({ manualRiskProfile: "RECOVERY" }),
      tmp,
    );
    const loaded = loadPersistedConfig(tmp);
    assert.equal(
      loaded.manualRiskProfile,
      "RECOVERY",
      "a saved manual lock must still be active after a simulated restart",
    );
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

// (c) re-enabling a strategy removes it from the persisted array
test("(c) re-enabling a strategy removes it from the persisted array", () => {
  const tmp = makeTmpPath();
  try {
    // Step 1 — disable two strategies
    const cfg1 = makeConfig({ disabledStrategies: ["MOMENTUM_BURST", "OTM_HUNTER"] });
    savePersistedConfig(cfg1, tmp);

    // Step 2 — user re-enables OTM_HUNTER; frontend sends updated array
    const cfg2 = makeConfig({ disabledStrategies: ["MOMENTUM_BURST"] });
    savePersistedConfig(cfg2, tmp);

    const loaded = loadPersistedConfig(tmp);
    assert.ok(loaded.disabledStrategies?.includes("MOMENTUM_BURST"));
    assert.equal(
      loaded.disabledStrategies?.includes("OTM_HUNTER"),
      false,
      "OTM_HUNTER should not be in the disabled list after re-enabling"
    );
    assert.ok(loaded.disabledStrategies?.includes("OTM_ASYMMETRY"), "fail-closed OTM stays");
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

// (d) missing file returns {} (first run)
test("(d) missing config file returns empty object", () => {
  const tmp = makeTmpPath(); // deliberately do NOT create the file
  const loaded = loadPersistedConfig(tmp);
  assert.deepEqual(loaded, {}, "first-run / missing file must return {}");
});

// (e) defensive guard: non-array disabledStrategies is reset to []
test("(e) non-array disabledStrategies in config file is normalised to []", () => {
  const tmp = makeTmpPath();
  try {
    // Write a corrupt config where disabledStrategies is a plain string
    fs.writeFileSync(
      tmp,
      JSON.stringify({ enabled: false, disabledStrategies: "MOMENTUM_BURST" }),
      "utf8"
    );
    const loaded = loadPersistedConfig(tmp);
    // Corrupt non-array → [] then unioned with fail-closed SEV1/OTM/LATE.
    assert.ok(Array.isArray(loaded.disabledStrategies));
    assert.equal(loaded.disabledStrategies?.includes("MOMENTUM_BURST"), false);
    for (const id of PATCH_FAIL_CLOSED_DISABLED) {
      assert.ok(loaded.disabledStrategies?.includes(id), `fail-closed must keep ${id}`);
    }
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

// (f) defensive guard: null disabledStrategies is reset to []
test("(f) null disabledStrategies in config file is normalised to []", () => {
  const tmp = makeTmpPath();
  try {
    fs.writeFileSync(
      tmp,
      JSON.stringify({ enabled: false, disabledStrategies: null }),
      "utf8"
    );
    const loaded = loadPersistedConfig(tmp);
    assert.ok(Array.isArray(loaded.disabledStrategies));
    for (const id of PATCH_FAIL_CLOSED_DISABLED) {
      assert.ok(loaded.disabledStrategies?.includes(id), `fail-closed must keep ${id}`);
    }
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

// (g) other config fields are preserved alongside disabledStrategies
test("(g) other config fields survive alongside disabledStrategies", () => {
  const tmp = makeTmpPath();
  try {
    const cfg = makeConfig({
      paperMode:             true,
      enabled:               true,
      maxContractsPerTrade:  5,
      maxDepthFraction:      0.4,
      disabledStrategies:    ["MOMENTUM_BURST"],
    });
    savePersistedConfig(cfg, tmp);

    const loaded = loadPersistedConfig(tmp);
    assert.equal(loaded.paperMode,            true,            "paperMode must survive");
    assert.equal(loaded.enabled,              true,            "enabled must survive");
    assert.equal(loaded.maxContractsPerTrade, 5,               "maxContractsPerTrade must survive");
    assert.equal(loaded.maxDepthFraction,     0.4,             "maxDepthFraction must survive");
    assert.ok(loaded.disabledStrategies?.includes("MOMENTUM_BURST"), "disabledStrategies must survive");
    assert.equal(loaded.disabledStrategies?.includes("BRTI_PROBABILITY"), false, "BRTI not in fail-closed union");
    assert.ok(loaded.disabledStrategies?.includes("OTM_ASYMMETRY"), "fail-closed union on save");
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

// (h) empty disabledStrategies array round-trips correctly
test("(h) empty disabledStrategies array round-trips correctly", () => {
  const tmp = makeTmpPath();
  try {
    const cfg = makeConfig({ disabledStrategies: [] });
    savePersistedConfig(cfg, tmp);

    const loaded = loadPersistedConfig(tmp);
    // Empty operator list still persists fail-closed SEV1/OTM/LATE (never ENABLE leftovers).
    assert.ok(Array.isArray(loaded.disabledStrategies));
    assert.equal(loaded.disabledStrategies?.length, PATCH_FAIL_CLOSED_DISABLED.length);
    for (const id of PATCH_FAIL_CLOSED_DISABLED) {
      assert.ok(loaded.disabledStrategies?.includes(id), `fail-closed must keep ${id}`);
    }
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

test("#409 restartPersistDecision: paper stays paper, autoMode follows disk, enabled follows disk", () => {
  const running = restartPersistDecision({ paperMode: true, enabled: true, autoMode: true });
  assert.equal(running.paperMode, true);
  assert.equal(running.enabled, true);
  assert.equal(running.autoMode, true, "autoMode ADAPTATION persists across bounce");

  const idle = restartPersistDecision({ paperMode: false, enabled: false, autoMode: false });
  assert.equal(idle.paperMode, true, "boot never leaves paper without LIVE REAL MONEY");
  assert.equal(idle.enabled, false);
  assert.equal(idle.autoMode, false);
});

test("#404 mergePersistedRisk keeps daily halt / stops / confidence from disk", () => {
  const defaults = {
    paperMode: true,
    autoMode: true,
    enabled: false,
    dailyLossCapCents: 500,
    dailyLossCapPct: 18,
    minConfidence: 70,
    minVelocity: 5,
    minEntryPrice: 20,
    maxEntryPrice: 80,
    stopLossCents: 8,
    hardStopCents: 12,
    maxContractsPerTrade: 3,
    useKellySizing: false,
  };
  const saved = {
    paperMode: true,
    autoMode: false,
    enabled: true,
    dailyLossCapCents: 3000,
    dailyLossCapPct: 10,
    minConfidence: 52,
    minVelocity: 24,
    stopLossCents: 22,
    hardStopCents: 38,
    maxContractsPerTrade: 60,
    useKellySizing: true,
  };
  const merged = mergePersistedRisk(defaults, saved);
  assert.equal(merged.paperMode, true);
  assert.equal(merged.autoMode, false);
  assert.equal(merged.enabled, true);
  assert.equal(merged.dailyLossCapCents, 3000);
  assert.equal(merged.dailyLossCapPct, 10);
  assert.equal(merged.minConfidence, 52);
  assert.equal(merged.stopLossCents, 22);
  assert.equal(merged.hardStopCents, 38);
  assert.equal(merged.maxContractsPerTrade, 60);
  assert.equal(merged.useKellySizing, true);
});

test("#404/#409 mergePersistedRisk forces paperMode true even if disk says false", () => {
  const defaults = { paperMode: true, autoMode: false, enabled: true, dailyLossCapCents: 3000 };
  const merged = mergePersistedRisk(defaults, { paperMode: false, enabled: true });
  assert.equal(merged.paperMode, true);
  assert.equal(merged.enabled, true);
});

test("#409 mergePersistedRisk keeps autoMode true from disk (adaptation stays ON)", () => {
  const defaults = { paperMode: true, autoMode: false, enabled: false, dailyLossCapCents: 3000 };
  const merged = mergePersistedRisk(defaults, { paperMode: true, autoMode: true, enabled: true });
  assert.equal(merged.paperMode, true);
  assert.equal(merged.autoMode, true);
  assert.equal(merged.enabled, true);
});

test("savePersistedConfig never writes paperMode false", () => {
  const tmp = makeTmpPath();
  try {
    savePersistedConfig(makeConfig({ paperMode: false }), tmp);
    const loaded = loadPersistedConfig(tmp);
    assert.equal(loaded.paperMode, true);
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});


test("normalizePersistedConfig strips secrets and forces paperMode true", () => {
  const n = normalizePersistedConfig({
    paperMode: false,
    enabled: true,
    apiKey: "sk-live-secret",
    oraclekey: "pk-secret",
    openRouterApiKey: "x",
    minConfidence: 52,
  } as Record<string, unknown>);
  assert.equal(n.paperMode, true);
  assert.equal(n.enabled, true);
  assert.equal(n.minConfidence, 52);
  assert.equal("apiKey" in n, false);
  assert.equal("oraclekey" in n, false);
  assert.equal("openRouterApiKey" in n, false);
});

test("normalizePersistedConfig unions fail-closed SEV1/OTM/LATE and forces leftover ENABLE false", () => {
  const n = normalizePersistedConfig({
    paperMode: true,
    disabledStrategies: ["VELOCITY_MOMENTUM"],
    enable1HContracts: true,
    enable1HLive: true,
    cheapSide15mEnabled: true,
    panicFadeEnabled: true,
    candlestickPatternLiveEnabled: true,
  } as Record<string, unknown>);
  assert.equal(n.paperMode, true);
  assert.equal(n.enable1HContracts, false);
  assert.equal(n.enable1HLive, false);
  assert.equal(n.cheapSide15mEnabled, false);
  assert.equal(n.panicFadeEnabled, false);
  assert.equal(n.candlestickPatternLiveEnabled, false);
  const disabled = n.disabledStrategies as string[];
  for (const id of PATCH_FAIL_CLOSED_DISABLED) {
    assert.ok(disabled.includes(id), `must keep ${id}`);
  }
});

test("savePersistedConfig never writes secrets or paperMode false or ENABLE leftovers", () => {
  const tmp = makeTmpPath();
  try {
    const cfg = makeConfig({
      paperMode: false,
      enable1HContracts: true,
      cheapSide15mEnabled: true,
      disabledStrategies: [],
    }) as BotConfig & Record<string, unknown>;
    (cfg as Record<string, unknown>).apiKey = "must-not-persist";
    savePersistedConfig(cfg as BotConfig, tmp);
    const raw = JSON.parse(fs.readFileSync(tmp, "utf8")) as Record<string, unknown>;
    assert.equal(raw.paperMode, true);
    assert.equal(raw.enable1HContracts, false);
    assert.equal(raw.cheapSide15mEnabled, false);
    assert.equal("apiKey" in raw, false);
    const disabled = raw.disabledStrategies as string[];
    assert.equal(disabled.includes("BRTI_PROBABILITY"), false, "BRTI not fail-closed");
    assert.ok(disabled.includes("OTM_ASYMMETRY"));
    assert.ok(disabled.includes("SETTLEMENT_PREDICTION"));
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

test("loadPersistedConfig normalizes hostile hand-edited disk (secrets + ENABLE + missing SEV1)", () => {
  const tmp = makeTmpPath();
  try {
    fs.writeFileSync(tmp, JSON.stringify({
      paperMode: false,
      enabled: true,
      apiKey: "leak",
      enable1HLive: true,
      disabledStrategies: [],
    }), "utf8");
    const loaded = loadPersistedConfig(tmp);
    assert.equal(loaded.paperMode, true);
    assert.equal("apiKey" in loaded, false);
    assert.equal(loaded.enable1HLive, false);
    const disabled = loaded.disabledStrategies as string[];
    assert.ok(disabled.includes("DEEP_OTM_SNIPER"));
    assert.ok(disabled.includes("LATE_ENTRY_ANCHOR"));
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

test("isConfigSecretKey matches common credential key shapes", () => {
  assert.equal(isConfigSecretKey("apiKey"), true);
  assert.equal(isConfigSecretKey("ORACLEKEY"), true);
  assert.equal(isConfigSecretKey("private_key_pem"), true);
  assert.equal(isConfigSecretKey("minConfidence"), false);
  assert.equal(isConfigSecretKey("paperMode"), false);
});


test("normalizePersistedConfig drops EV/Kelly floor aliases (immutable — never on disk)", () => {
  const hostile: Record<string, unknown> = {
    paperMode: false,
    minConfidence: 52,
  };
  for (const key of PATCH_REFUSE_FLOOR_KEYS) hostile[key] = 0;
  const n = normalizePersistedConfig(hostile);
  assert.equal(n.paperMode, true);
  assert.equal(n.minConfidence, 52);
  for (const key of PATCH_REFUSE_FLOOR_KEYS) {
    assert.equal(key in n, false, `${key} must not persist`);
  }
});

test("paperMode cannot silently go false via save/load round-trip", () => {
  const tmp = makeTmpPath();
  try {
    savePersistedConfig(makeConfig({ paperMode: false }), tmp);
    const disk = JSON.parse(fs.readFileSync(tmp, "utf8")) as Record<string, unknown>;
    assert.equal(disk.paperMode, true);
    const loaded = loadPersistedConfig(tmp);
    assert.equal(loaded.paperMode, true);
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});


test("P0: frozenCcMode true survives save/load simulated restart", () => {
  const tmp = makeTmpPath();
  try {
    savePersistedConfig(makeConfig({ frozenCcMode: true, paperMode: true }), tmp);
    const disk = JSON.parse(fs.readFileSync(tmp, "utf8")) as Record<string, unknown>;
    assert.equal(disk.frozenCcMode, true, "disk must keep frozenCcMode true");
    assert.equal(disk.paperMode, true);

    const loaded = loadPersistedConfig(tmp);
    assert.equal(loaded.frozenCcMode, true, "load must restore frozenCcMode true");

    // Constructor-like defaults (false) must not overwrite disk true.
    const defaults = { frozenCcMode: false, paperMode: true, enabled: false };
    const merged = mergeDiskFrozenCcMode(defaults, loaded);
    assert.equal(merged.frozenCcMode, true, "disk true wins over constructor default false");

    const riskMerged = mergePersistedRisk(
      { ...defaults, dailyLossCapCents: 3000, autoMode: false },
      loaded as Record<string, unknown>,
    );
    assert.equal(riskMerged.frozenCcMode, true, "RESTART_PERSIST_KEYS must carry frozenCcMode");
  } finally {
    fs.rmSync(tmp, { force: true });
  }
});

test("P0: mergeDiskFrozenCcMode leaves default when disk omits key", () => {
  const defaults = { frozenCcMode: false, paperMode: true };
  const merged = mergeDiskFrozenCcMode(defaults, { paperMode: true });
  assert.equal(merged.frozenCcMode, false);
});

test("normalizePersistedConfig coerces frozenCcMode to strict boolean when present", () => {
  const n = normalizePersistedConfig({ frozenCcMode: true, paperMode: true });
  assert.equal(n.frozenCcMode, true);
  const n2 = normalizePersistedConfig({ frozenCcMode: false, paperMode: true });
  assert.equal(n2.frozenCcMode, false);
  const n3 = normalizePersistedConfig({ paperMode: true });
  assert.equal("frozenCcMode" in n3, false, "missing key stays missing");
});
