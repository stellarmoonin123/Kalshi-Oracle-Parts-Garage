/**
 * mind-uncertainty — conformal-style side confidence band + option value of SKIP.
 *
 * From settle-side-score ± scar-echo variance: interval on side affinity.
 * If interval covers both YES and NO (straddles 0) → prefer SKIP (option value).
 * Pure. No LLM. Labels ESTIMATE/INFERENCE honestly when n small.
 */
import type { SettleSideScoreResult } from "./settle-side-score.js";

export const MIND_UNCERTAINTY_LOADED = "MIND_UNCERTAINTY_LOADED" as const;

/** secs remaining above this → "time left" term in option-value formula. */
export const OV_SECS_HIGH = 420 as const;

/** Half-width floor when sensors thin (affinity units ≈ scoreYes−scoreNo scale). */
export const SIDE_BAND_FLOOR = 1.5 as const;

/** Half-width shrinks with scar echo n (1/√n style). */
export const SIDE_BAND_ECHO_SCALE = 3.0 as const;

export type EpistemicLabel = "MEASUREMENT" | "ESTIMATE" | "INFERENCE";

export type SideConfidenceBand = {
  /** Point affinity: scoreYes − scoreNo (settle-side). >0 leans YES. */
  point: number;
  lo: number;
  hi: number;
  /** True when [lo,hi] straddles 0 → both sides plausible. */
  coversBoth: boolean;
  /** Preferred lean if not coversBoth. */
  lean: "yes" | "no" | "skip";
  label: EpistemicLabel;
  n: number;
  note: string;
};

/**
 * Option value of waiting (SKIP).
 *
 * Formula (documented, deterministic):
 *   OV = clamp(
 *     0.15 · I(secsRemaining ≥ OV_SECS_HIGH)
 *   + 0.25 · I(coversBoth)
 *   + 0.20 · I(vel/MTF conflict)
 *   + 0.10 · I(calibrationUnreliable)
 *   , 0, 0.55)
 *
 * preferSkip := OV ≥ 0.25 OR coversBoth.
 */
export type OptionValueSkip = {
  score: number;
  preferSkip: boolean;
  formula: string;
  terms: {
    secsHigh: number;
    coversBoth: number;
    velMtfConflict: number;
    calibUnreliable: number;
  };
  reasons: string[];
};

export type UncertaintyReport = {
  sideConfidence: SideConfidenceBand;
  optionValueSkip: OptionValueSkip;
};

function round3(n: number): number {
  return Math.round(n * 1000) / 1000;
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

/**
 * Build side confidence interval from settle-side scores + optional echo n.
 * Half-width = max(SIDE_BAND_FLOOR, SIDE_BAND_ECHO_SCALE / √max(n,1)).
 * When settle pick is skip / inputs thin → widen and mark coversBoth.
 */
export function buildSideConfidenceBand(input: {
  settleSide: SettleSideScoreResult | null | undefined;
  /** Closed scar / echo count supporting this conflict+side (optional). */
  echoN?: number | null;
  /** Soft prior from echoes mean fee-net (unused for center; informs label). */
  echoMeanFeeNet?: number | null;
}): SideConfidenceBand {
  const ss = input.settleSide ?? null;
  const echoN =
    typeof input.echoN === "number" && Number.isFinite(input.echoN)
      ? Math.max(0, Math.floor(input.echoN))
      : 0;
  const n = echoN + (ss?.factors.inputsPresent ? 1 : 0);

  if (!ss || !ss.factors.inputsPresent) {
    return {
      point: 0,
      lo: -SIDE_BAND_FLOOR * 2,
      hi: SIDE_BAND_FLOOR * 2,
      coversBoth: true,
      lean: "skip",
      label: "ESTIMATE",
      n,
      note: "settle-side inputs thin — band covers both (ESTIMATE)",
    };
  }

  const point = ss.scoreYes - ss.scoreNo;
  const half = Math.max(
    SIDE_BAND_FLOOR,
    SIDE_BAND_ECHO_SCALE / Math.sqrt(Math.max(echoN, 1)),
  );
  // Penalize width when hard penalties / conflict present
  const conflictWiden =
    (ss.factors.velAgainst ? 0.5 : 0) + (ss.factors.mtfVelConflict ? 0.75 : 0);
  const lo = point - half - conflictWiden;
  const hi = point + half + conflictWiden;
  const coversBoth = lo < 0 && hi > 0;

  let lean: SideConfidenceBand["lean"] = "skip";
  if (!coversBoth) {
    lean = point > 0 ? "yes" : point < 0 ? "no" : "skip";
  } else if (ss.pick === "skip") {
    lean = "skip";
  }

  const label: EpistemicLabel =
    echoN >= 20
      ? "MEASUREMENT"
      : echoN >= 5
        ? "INFERENCE"
        : "ESTIMATE";

  return {
    point: round3(point),
    lo: round3(lo),
    hi: round3(hi),
    coversBoth,
    lean,
    label,
    n,
    note: coversBoth
      ? `band [${round3(lo)},${round3(hi)}] covers YES+NO — option value of waiting (${label})`
      : `band [${round3(lo)},${round3(hi)}] leans ${lean} (${label} n=${n})`,
  };
}

/**
 * Explicit option value of SKIP — ties to GoldenEgg "skip is valid".
 */
export function computeOptionValueSkip(input: {
  secsRemaining?: number | null;
  coversBoth: boolean;
  velMtfConflict: boolean;
  calibrationUnreliable: boolean;
}): OptionValueSkip {
  const secs =
    typeof input.secsRemaining === "number" && Number.isFinite(input.secsRemaining)
      ? input.secsRemaining
      : null;
  const secsHigh = secs != null && secs >= OV_SECS_HIGH ? 0.15 : 0;
  const coversBoth = input.coversBoth ? 0.25 : 0;
  const velMtf = input.velMtfConflict ? 0.2 : 0;
  const calib = input.calibrationUnreliable ? 0.1 : 0;
  const raw = secsHigh + coversBoth + velMtf + calib;
  const score = round3(clamp(raw, 0, 0.55));
  const preferSkip = score >= 0.25 || input.coversBoth;
  const reasons: string[] = [];
  if (secsHigh > 0) reasons.push(`secs≥${OV_SECS_HIGH} → +0.15`);
  if (coversBoth > 0) reasons.push("side band covers both → +0.25");
  if (velMtf > 0) reasons.push("vel/MTF conflict → +0.20");
  if (calib > 0) reasons.push("calibration unreliable → +0.10");
  if (reasons.length === 0) reasons.push("no OV terms — skip not extra-scored");

  return {
    score,
    preferSkip,
    formula:
      "OV=clamp(0.15·I(secs≥420)+0.25·I(coversBoth)+0.20·I(velMtfConflict)+0.10·I(calibUnreliable),0,0.55); preferSkip:=OV≥0.25∨coversBoth",
    terms: {
      secsHigh,
      coversBoth,
      velMtfConflict: velMtf,
      calibUnreliable: calib,
    },
    reasons,
  };
}

export function buildUncertaintyReport(input: {
  settleSide: SettleSideScoreResult | null | undefined;
  echoN?: number | null;
  echoMeanFeeNet?: number | null;
  secsRemaining?: number | null;
  calibrationUnreliable: boolean;
}): UncertaintyReport {
  const sideConfidence = buildSideConfidenceBand({
    settleSide: input.settleSide,
    echoN: input.echoN,
    echoMeanFeeNet: input.echoMeanFeeNet,
  });
  const velMtfConflict =
    input.settleSide?.factors.velAgainst === true ||
    input.settleSide?.factors.mtfVelConflict === true;
  const optionValueSkip = computeOptionValueSkip({
    secsRemaining: input.secsRemaining,
    coversBoth: sideConfidence.coversBoth,
    velMtfConflict,
    calibrationUnreliable: input.calibrationUnreliable,
  });
  return { sideConfidence, optionValueSkip };
}
