/**
 * Kalshi taker/maker fee organ — single source of truth.
 *
 * Official quadratic fee (NOT min(P,1-P)×7%):
 *   P = priceCents / 100
 *   C = contracts
 *   takerRawCents = 0.07   * C * P * (1-P) * 100
 *   makerRawCents = 0.0175 * C * P * (1-P) * 100
 *   feeDollars    = ceil(rawCents - 1e-9) / 100
 *   feeCents      = round(feeDollars * 100), kept as integer cents
 *
 * Settlement fee = 0. Early sell = SECOND fee at exit price.
 * ORACLE_V2 OS §3 aligns: taker≈0.07*P*(1-P) ceil — this file is SoT; no rewrite.
 * Ceil is applied once on the whole order (not per-contract × C).
 */

export const KALSHI_TAKER_FEE_RATE = 0.07;
export const KALSHI_MAKER_FEE_RATE = 0.0175;

function clampPriceCents(priceCents: number): number {
  if (!Number.isFinite(priceCents)) return NaN;
  return priceCents;
}

function rawFeeCents(
  priceCents: number,
  contracts: number,
  rate: number,
): number {
  const C = contracts;
  const P = priceCents / 100;
  if (!(C > 0) || !(P > 0) || !(P < 1)) return 0;
  return rate * C * P * (1 - P) * 100;
}

function ceilFeeDollars(rawCents: number): number {
  if (!(rawCents > 0)) return 0;
  return Math.ceil(rawCents - 1e-9) / 100;
}

/** Taker fee in dollars for an order of `contracts` at `priceCents`. */
export function kalshiTakerFeeDollars(
  priceCents: number,
  contracts: number,
): number {
  const pc = clampPriceCents(priceCents);
  if (!Number.isFinite(pc)) return 0;
  return ceilFeeDollars(rawFeeCents(pc, contracts, KALSHI_TAKER_FEE_RATE));
}

/** Maker fee in dollars for an order of `contracts` at `priceCents`. */
export function kalshiMakerFeeDollars(
  priceCents: number,
  contracts: number,
): number {
  const pc = clampPriceCents(priceCents);
  if (!Number.isFinite(pc)) return 0;
  return ceilFeeDollars(rawFeeCents(pc, contracts, KALSHI_MAKER_FEE_RATE));
}

/** Taker fee in cents (whole cents after ceil). */
export function kalshiTakerFeeCents(
  priceCents: number,
  contracts: number,
): number {
  // Preserve whole cents; binary float dollars must not leak into the money book.
  return Math.round(kalshiTakerFeeDollars(priceCents, contracts) * 100);
}

/** Maker fee in cents (whole cents after ceil). */
export function kalshiMakerFeeCents(
  priceCents: number,
  contracts: number,
): number {
  return Math.round(kalshiMakerFeeDollars(priceCents, contracts) * 100);
}

/**
 * Legacy per-contract wrapper (C=1). Prefer kalshiTakerFeeCents / kalshiMakerFeeCents
 * when the order size is known so ceil applies once on the whole order.
 */
export function kalshiFeeCents(
  priceCents: number,
  kind: "taker" | "maker" = "taker",
): number {
  return kind === "maker"
    ? kalshiMakerFeeCents(priceCents, 1)
    : kalshiTakerFeeCents(priceCents, 1);
}

/**
 * Win rate (0–1) needed to break even after entry fee only (no slippage).
 * W * 100 * C - price * C - fee = 0 → W = (price*C + fee) / (100*C)
 */
export function breakevenWinRate(
  priceCents: number,
  contracts: number,
  kind: "taker" | "maker" = "taker",
): number {
  const C = contracts;
  if (!(C > 0) || !Number.isFinite(priceCents)) return 1;
  const P = priceCents / 100;
  if (!(P > 0) || !(P < 1)) return 1;
  const feeCents =
    kind === "maker"
      ? kalshiMakerFeeCents(priceCents, C)
      : kalshiTakerFeeCents(priceCents, C);
  const denom = 100 * C;
  if (!(denom > 0)) return 1;
  const w = (priceCents * C + feeCents) / denom;
  if (!Number.isFinite(w)) return 1;
  return Math.min(1, Math.max(0, w));
}

/**
 * Round-trip fee if you buy at entry and sell early at exit (two taker fees).
 * Settlement has no second fee — do not add a third.
 */
export function expectedRoundTripFeeCents(
  entryCents: number,
  exitCents: number,
  contracts: number,
): number {
  return (
    kalshiTakerFeeCents(entryCents, contracts) +
    kalshiTakerFeeCents(exitCents, contracts)
  );
}

/** Fee as % of notional cost (price * contracts), 0–100 scale. */
export function feePctOfCost(
  priceCents: number,
  contracts: number,
  kind: "taker" | "maker" = "taker",
): number {
  const cost = priceCents * contracts;
  if (!(cost > 0)) return 0;
  const fee =
    kind === "maker"
      ? kalshiMakerFeeCents(priceCents, contracts)
      : kalshiTakerFeeCents(priceCents, contracts);
  return (fee / cost) * 100;
}
