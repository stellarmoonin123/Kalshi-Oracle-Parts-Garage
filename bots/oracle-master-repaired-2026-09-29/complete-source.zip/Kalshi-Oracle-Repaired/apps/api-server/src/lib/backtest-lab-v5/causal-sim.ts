/**
 * backtest-lab-v5/causal-sim.ts
 *
 * GO — BACKTEST LAB v5 + CONTINUOUS POLICY REGRESSION (2026-08-22), PART I-A.
 *
 * A causal, falsifiable simulator that replays a `SimPolicy` against REAL
 * historical BTC OHLC (market-candles.ts's fetchRealCandles — Coinbase /
 * Binance / CoinGecko, never Kalshi-interpolated sub-candles) and produces
 * one admit/skip decision per 15-minute period.
 *
 * Causal-safety guarantees (see the poison test in
 * backtest-lab-v5/__tests__/causal-sim.test.ts for the executable proof):
 *   - Every decision is built ONLY from candles up to and including the
 *     decision-time candle (minute 5 = c0 only, minute 10 = c0+c1). The
 *     period's settlement candle (c2) is held back and used ONLY afterward,
 *     to grade an already-made decision — it is never in scope when the
 *     decision itself is computed.
 *   - Observation construction reuses historical-backtester.ts's
 *     `buildSimObs()` (already causal-safety-audited and documented) instead
 *     of a second hand-rolled builder. The one piece of real randomness in
 *     that function (simulated yesAsk/noAsk quotes) is made reproducible via
 *     a seeded Math.random substitute keyed off the period's own timestamp —
 *     see `withSeededRandom` below — so the SAME period always produces the
 *     SAME observation and decision, deterministically, across runs.
 *
 * Reuses the REAL admission machinery wherever it is pure and exported,
 * rather than re-deriving a second approximation of it:
 *   - strategy-library.ts:  evaluateAllStrategies, classifyRegimeFromBuffer
 *   - pre-trade-sim.ts:     checkStrategyConsensus (with the new, additive
 *                           `requireMode` param — see that function's doc
 *                           comment)
 *   - specialist-packs.ts:  getPack, computePackConfFloor,
 *                           computeConsensusDisabledIds, filterPoolByPack
 *   - wrong-kit.ts (local): isWrongKitFamily — the fair, policy-neutral
 *                           regime/family conflict map added by the FAIR
 *                           METRICS HARDENING pass (2026-08-22), replacing
 *                           the earlier LEAN-pack-allowlist-based
 *                           wrong-kit measure (see that file's doc comment).
 *   - condition-adapter.ts: getConditionOverrides (the PURE overlay
 *                           resolver — NOT classifyDetailedCondition, which
 *                           reads the live regime-engine.ts singleton and is
 *                           therefore unsafe to call from an offline sim)
 *   - volume-risk.ts:       computeVolumeScore
 *   - trade-path.ts:        computeTradeEV
 *   - constants.ts:         kalshiFeeCents, kalshiNetWinCents,
 *                           kalshiNetCostCents
 *   - historical-backtester.ts: selectBestFromPool, buildSimObs
 *
 * DOCUMENTED LIMITATIONS (Part I(A) "print limitations" requirement):
 *   1. `fairDistFromFloorPct`/`estimatedFairBRTI` are never populated (same
 *      documented gap as historical-backtester.ts — no historical dual-feed
 *      basis series exists). The 11 fair-price-aware strategies fall back to
 *      raw `distFromFloorPct`, exactly as they do in every other backtest.
 *   2. `classifyRegimeFromBuffer` never emits 'squeeze' or 'fakeout' — those
 *      two of the ten DetailedCondition/RegimeId values are structurally
 *      unreachable here (same known gap as historical-backtester.ts's pack
 *      backtest; SQUEEZE pack and 'squeeze' condition overlay will show 0
 *      observations in this lab, by design, not a bug).
 *   3. Sizing is fixed at 1 contract per admitted trade. This lab measures
 *      per-trade fee-net economics and admit-rate behavior, not a full
 *      Kelly/position-sizing model — consistent with Part III's explicit
 *      "not optimizing for trade-count/10%-day" scope guardrail.
 *   4. `packConfBumpMax` in a SimPolicy is documentation-only right now —
 *      the actual per-pack confBump values always come from
 *      specialist-packs.ts's live table (see sim-policy.ts's doc comment).
 *   5. ARIA (the LLM risk agent) is not modeled at all — this lab measures
 *      the mechanical admit pipeline only, upstream of any ARIA veto/sizing
 *      overlay that would apply live.
 */

import type { RealCandle } from '../market-candles.js';
import { fetchRealCandles } from '../market-candles.js';
import type { StrategyObservation, StrategyId, StrategyResult, MarketRegimeTag } from '../strategy-library.js';
import { evaluateAllStrategies, getAllStrategyMeta, getStrategyFamily } from '../strategy-library.js';
import { buildSimObs, selectBestFromPool } from '../historical-backtester.js';
import { checkStrategyConsensus } from '../pre-trade-sim.js';
import {
  getPack, computePackConfFloor, computeConsensusDisabledIds, filterPoolByPack,
} from '../specialist-packs.js';
import type { SpecialistPack, PackId } from '../specialist-packs.js';
import { getConditionOverrides } from '../condition-adapter.js';
import type { DetailedCondition } from '../condition-adapter.js';
import { computeVolumeScore } from '../volume-risk.js';
import type { VolumeBucket } from '../volume-risk.js';
import { computeTradeEV } from '../trade-path.js';
import { kalshiNetWinCents, kalshiNetCostCents } from '../constants.js';
import type { SimPolicy } from './sim-policy.js';
import { isWrongKitFamily } from './wrong-kit.js';

// ── Flag → strategy-id gate (mirrors trading-bot.ts's opt-in table) ───────────

const FLAG_GATED_STRATEGIES: Record<keyof SimPolicy['flags'], StrategyId[]> = {
  topBottom:      ['TOP_REVERSAL', 'BOTTOM_REVERSAL'] as StrategyId[],
  bollinger:      ['BOLLINGER_BAND'] as StrategyId[],
  settlementVote: ['SETTLEMENT_PREDICTION'] as StrategyId[],
};

// ── Deterministic RNG (seeded Math.random substitute) ──────────────────────────

function mulberry32(seed: number): () => number {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashSeed(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/**
 * Runs `fn` with the global Math.random temporarily replaced by a seeded
 * generator, then restores the real Math.random unconditionally. Scoped
 * entirely to this module — `buildSimObs`'s own behavior and every other
 * caller of it (e.g. runHistoricalSim) are unaffected, since the swap is
 * reverted before control returns to any other code, including via
 * exceptions (finally).
 */
function withSeededRandom<T>(seedKey: string, fn: () => T): T {
  const original = Math.random;
  Math.random = mulberry32(hashSeed(seedKey));
  try {
    return fn();
  } finally {
    Math.random = original;
  }
}

// ── Period grouping ────────────────────────────────────────────────────────────

export interface CausalPeriod {
  /** Index of this period's first candle within the full fetched series. */
  startIndex:  number;
  periodStartMs: number;
  /** Real 5-min candles for this period only: [c0 (0-5m), c1 (5-10m), c2 (10-15m)]. */
  candles:     [RealCandle, RealCandle, RealCandle];
  /** floor_strike proxy = price at period open (c0.open) — matches how a
   *  real Kalshi 15-min contract's floor strike is set at period start. */
  floorStrike: number;
  /** Settlement price = price at period close (c2.close). NEVER read before
   *  a decision is made — only used afterward, to grade it. */
  settlementClose: number;
}

/** Groups a continuous 5-minute candle series into non-overlapping 15-minute
 *  periods. Any trailing partial period (< 3 candles) is dropped. */
export function groupIntoPeriods(candles: RealCandle[]): CausalPeriod[] {
  const sorted = [...candles].sort((a, b) => a.time - b.time);
  const periods: CausalPeriod[] = [];
  for (let i = 0; i + 2 < sorted.length; i += 3) {
    const c0 = sorted[i], c1 = sorted[i + 1], c2 = sorted[i + 2];
    periods.push({
      startIndex: i,
      periodStartMs: c0.time * 1000,
      candles: [c0, c1, c2],
      floorStrike: c0.open,
      settlementClose: c2.close,
    });
  }
  return periods;
}

// ── Decision-time observation ──────────────────────────────────────────────────

/**
 * Builds a causal observation for a decision at `minuteMark` (5 or 10) of the
 * period starting at `period.startIndex`. `fullSeries` is the FULL candle
 * array the periods were grouped from (needed so longer-lookback fields like
 * the 60-candle MTF proxy SMA in buildSimObs can see PRIOR periods too, not
 * just the current one) — this function truncates it to strictly
 * pre-decision-time before calling buildSimObs, so no post-decision data
 * (including this period's own c1/c2 when at minute 5) ever reaches it.
 */
export function buildDecisionObservation(
  fullSeries: RealCandle[],
  period: CausalPeriod,
  minuteMark: 5 | 10,
): StrategyObservation {
  const cutoffIndex = minuteMark === 5 ? period.startIndex : period.startIndex + 1; // last INCLUDED candle index
  const window = fullSeries.slice(0, cutoffIndex + 1); // strictly past-and-current-candle-only
  const secsRemaining = minuteMark === 5 ? 600 : 300;
  const seedKey = `${period.periodStartMs}:${minuteMark}`;
  return withSeededRandom(seedKey, () =>
    buildSimObs(window as any, period.floorStrike, secsRemaining),
  );
}

// ── Single-decision pipeline: signals → pack filter → conf → consensus → EV/fee → size → log ──

export interface SimDecision {
  periodStartMs: number;
  minuteMark:    5 | 10;
  regime:        MarketRegimeTag;
  vBucket:       VolumeBucket;
  packId:        PackId | null;
  admitted:      boolean;
  skipReason?:   'NO_CANDIDATE' | 'MIN_CONF' | 'MIN_VEL' | 'CONSENSUS' | 'EV_FLOOR';
  strategyId?:   StrategyId;
  side?:         'YES' | 'NO';
  confidence?:   number;      // 0-1
  entryPriceCents?: number;
  consensusCount?: number;
  /** true when the selected strategy's family conflicts with the causal
   *  regime label at decision time, under wrong-kit.ts's shared,
   *  policy-neutral map (FAIR METRICS HARDENING, 2026-08-22). Computed
   *  identically for both LEAN and LEGACY, and does not depend on pack
   *  membership — replaces the earlier LEAN-pack-allowlist-based measure. */
  wrongKitFamily?: boolean;
}

function buildEffectiveDisabledSet(
  obs: StrategyObservation,
  policy: SimPolicy,
  pack: SpecialistPack | null,
): Set<StrategyId> {
  const disabled = new Set<StrategyId>();
  for (const [flagName, ids] of Object.entries(FLAG_GATED_STRATEGIES) as [keyof SimPolicy['flags'], StrategyId[]][]) {
    if (!policy.flags[flagName]) ids.forEach(id => disabled.add(id));
  }
  if (policy.conditionSuppressLive) {
    // classifyRegimeFromBuffer's tag space is a subset of DetailedCondition's
    // 10 values (both share the same string literals except 'squeeze'/
    // 'fakeout', which classifyRegimeFromBuffer never emits — see module
    // doc's Limitation #2), so obs.regime can be passed directly as the
    // already-committed condition to the PURE overlay resolver.
    const overlay = getConditionOverrides((obs.regime ?? 'unclear') as DetailedCondition, obs.mtfScore ?? 0, obs);
    for (const id of overlay.suppressStrategies) disabled.add(id as StrategyId);
  }
  if (pack) {
    const allIds = getAllStrategyMeta().map(m => m.id) as StrategyId[];
    const packEligibleIds = new Set(pack.eligibleStrategyIds);
    const merged = computeConsensusDisabledIds(disabled, allIds, packEligibleIds);
    return new Set(merged as StrategyId[]);
  }
  return disabled;
}

export function decideAtPoint(obs: StrategyObservation, policy: SimPolicy): SimDecision {
  const regime  = (obs.regime ?? 'unclear') as MarketRegimeTag;
  const vBucket = computeVolumeScore(obs).bucket;
  const pack    = policy.packMode === 'enforce' ? getPack(regime as any, vBucket) : null;

  const base: SimDecision = {
    periodStartMs: 0, minuteMark: 5, // caller overwrites these two below
    regime, vBucket, packId: pack?.id ?? null, admitted: false,
  };

  const disabledIds = buildEffectiveDisabledSet(obs, policy, pack);
  const { all } = evaluateAllStrategies(obs, disabledIds);
  const pool = pack ? filterPoolByPack(all, new Set(pack.eligibleStrategyIds)) : all;
  const best = selectBestFromPool(pool);

  if (!best) return { ...base, skipReason: 'NO_CANDIDATE' };

  const confFloor = computePackConfFloor(policy.minConfidence, pack) / 100;
  if (best.confidence < confFloor) return { ...base, skipReason: 'MIN_CONF' };

  if (Math.abs(obs.velocityDolPerMin) < policy.minVelocity) {
    return { ...base, skipReason: 'MIN_VEL' };
  }

  const direction: 'LONG' | 'SHORT' = best.signal === 'YES' ? 'LONG' : 'SHORT';
  const { check: consensusCheck, consensusCount } = checkStrategyConsensus(
    obs, direction, disabledIds, policy.consensusMode,
  );
  if (!consensusCheck.passed) {
    return { ...base, skipReason: 'CONSENSUS', consensusCount, strategyId: best.strategyId };
  }

  const entryPriceCents = best.signal === 'YES' ? (obs.yesAsk ?? 50) : (obs.noAsk ?? 50);
  const evResult = computeTradeEV({
    entryPriceCents,
    winRate: best.confidence,
    strategyId: best.strategyId,
    secsRemaining: obs.secsRemaining,
    velocityDolPerMin: obs.velocityDolPerMin,
    minEVCents: entryPriceCents * 0.03,
  });
  if (!evResult.passes) {
    return { ...base, skipReason: 'EV_FLOOR', consensusCount, strategyId: best.strategyId, entryPriceCents };
  }

  const wrongKitFamily = isWrongKitFamily(regime, getStrategyFamily(best.strategyId));

  return {
    ...base,
    admitted: true,
    strategyId: best.strategyId,
    side: best.signal as 'YES' | 'NO',
    confidence: best.confidence,
    entryPriceCents,
    consensusCount,
    wrongKitFamily,
  };
}

// ── Full-series trade record (decision + graded outcome) ──────────────────────

export interface SimTrade extends SimDecision {
  won:      boolean;
  pnlCents: number; // fee-net (real Kalshi fee + policy.feeCents + policy.slipCents already subtracted)
}

/**
 * Runs one policy across every period in `periods`, taking at most one
 * admitted trade per period (mirrors live: once in a trade, the bot does not
 * also re-enter the same 15-min contract). Tries minute 5 first, then
 * minute 10 only if minute 5 did not admit — this models the real trade
 * window without a second, redundant entry.
 */
export function runPolicyOverPeriods(
  fullSeries: RealCandle[],
  periods:    CausalPeriod[],
  policy:     SimPolicy,
): { decisions: SimDecision[]; trades: SimTrade[] } {
  const decisions: SimDecision[] = [];
  const trades: SimTrade[] = [];

  for (const period of periods) {
    let admittedDecision: SimDecision | null = null;
    for (const minuteMark of [5, 10] as const) {
      const obs = buildDecisionObservation(fullSeries, period, minuteMark);
      const decision = decideAtPoint(obs, policy);
      decision.periodStartMs = period.periodStartMs;
      decision.minuteMark = minuteMark;
      decisions.push(decision);
      if (decision.admitted) { admittedDecision = decision; break; }
    }
    if (admittedDecision && admittedDecision.side && admittedDecision.entryPriceCents != null) {
      const settleAboveFloor = period.settlementClose > period.floorStrike;
      const won = (admittedDecision.side === 'YES') === settleAboveFloor;
      const entryPriceCents = admittedDecision.entryPriceCents;
      const extraFriction = policy.feeCents + policy.slipCents;
      const pnlCents = won
        ? kalshiNetWinCents(entryPriceCents) - extraFriction
        : -kalshiNetCostCents(entryPriceCents) - extraFriction;
      trades.push({ ...admittedDecision, won, pnlCents });
    }
  }
  return { decisions, trades };
}

/**
 * Convenience: fetch real candles and run a policy end to end. `startMs`/
 * `count`/`intervalMins` are passed straight to fetchRealCandles (real
 * Coinbase/Binance/CoinGecko OHLC only — see that function's own doc for its
 * source-order and why it refuses Kalshi-interpolated sub-candles).
 */
export async function fetchAndRunPolicy(
  startMs: number, count: number, intervalMins: 5,
  policy: SimPolicy,
): Promise<{ periods: CausalPeriod[]; decisions: SimDecision[]; trades: SimTrade[] }> {
  const { candles } = await fetchRealCandles(startMs, count, intervalMins);
  const periods = groupIntoPeriods(candles);
  const { decisions, trades } = runPolicyOverPeriods(candles, periods, policy);
  return { periods, decisions, trades };
}

// ── Poison test primitive ──────────────────────────────────────────────────────

/**
 * Returns a copy of `candles` with every candle AFTER `afterIndex` (the last
 * candle a decision at `minuteMark` for the period starting at
 * `periodStartIndex` is allowed to see) scrambled — prices shuffled and
 * volume zeroed. Used by the poison test to prove a decision never actually
 * depends on data past its own cutoff: the decision computed against this
 * poisoned series must be byte-identical to the one computed against the
 * real series, because `buildDecisionObservation` slices the window to
 * `cutoffIndex` before ever touching `fn`.
 */
export function poisonSeriesAfter(candles: RealCandle[], afterIndex: number, seed = 1234): RealCandle[] {
  const rng = mulberry32(seed);
  const out = candles.map(c => ({ ...c }));
  const futureIndices: number[] = [];
  for (let i = afterIndex + 1; i < out.length; i++) futureIndices.push(i);
  const shuffledCloses = futureIndices.map(i => out[i].close);
  // Fisher-Yates shuffle of just the future closes among themselves.
  for (let i = shuffledCloses.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [shuffledCloses[i], shuffledCloses[j]] = [shuffledCloses[j], shuffledCloses[i]];
  }
  futureIndices.forEach((idx, k) => {
    const close = shuffledCloses[k];
    out[idx] = { ...out[idx], open: close, high: close, low: close, close, volume: 0 };
  });
  return out;
}
