import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  composeAnalystReport,
  hasDeskSnapshot,
  DESK_SNAPSHOT_MISSING,
} from "./compose-analyst-report.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const ROUTE = readFileSync(path.resolve(DIR, "../routes/analyst.ts"), "utf8");

const CTX = `## Desk Snapshot (quote these numbers; do not invent)
paperMode: true (LOCKED paper — never recommend paperMode false)
cash: $313.00 (paper virtual)
YES mid 48¢ bid 47¢ ask 49¢ | NO mid 52¢ bid 51¢ ask 53¢
secs left: 412 | strike/floor: $111,250
BTC proxy: $111,301.40
Coinbase $111,298 | Bitstamp $111,304
lag meter: quoteAge 120ms
path conf: 76 (25–92 tape heuristic from spread/chop/quote age — NOT winRateAtPrice, not P(settle))
settlement-side call: skip — no clear edge
p = winRateAtPrice: n/a on this client snapshot — do not substitute path conf / bot score / liveModelProb
EV ¢: YES edge 2.1¢ | NO edge -1.4¢
Kelly: frac cap 0.60 (locked). Contracts: sized at entry, not this tick
ticket: still (still tickets skip)
open position: none
fail-closed: engines skip on stale book / lag disagree / missing p; never cut EV 3¢ / OTM 5¢ / PATH MULT 7¢
`;

test("analyst route does not call Grok / aiComplete", () => {
  assert.equal(ROUTE.includes("aiComplete"), false);
  assert.equal(ROUTE.includes("composeAnalystReport"), true);
  assert.equal(ROUTE.includes("OpenRouter"), false);
});

test("composeAnalystReport is Oracle 5-section skip without a key", () => {
  const report = composeAnalystReport({ extraContext: CTX, btcPrice: 111301.4 });
  assert.match(report, /\*\*Snapshot\*\*/);
  assert.match(report, /\*\*Side call\*\*/);
  assert.match(report, /\*\*Numbers\*\*/);
  assert.match(report, /\*\*Risks \/ skips\*\*/);
  assert.match(report, /\*\*Oracle recommendation\*\*/);
  assert.match(report, /paperMode: true/);
  assert.match(report, /p = winRateAtPrice: n\/a/);
  assert.match(report, /SKIP/);
  assert.equal(/\b500\b/.test(report), false);
});

test("missing snapshot is a clean fail", () => {
  assert.equal(hasDeskSnapshot({ extraContext: null, btcPrice: 0 }), false);
  assert.throws(() => composeAnalystReport({ extraContext: "hello", btcPrice: 0 }), (err: unknown) => {
    assert.equal((err as Error).message, DESK_SNAPSHOT_MISSING);
    return true;
  });
});
