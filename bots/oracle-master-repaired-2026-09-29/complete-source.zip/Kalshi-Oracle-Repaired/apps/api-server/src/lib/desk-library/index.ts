/**
 * desk-library — 15m contract library (shadow until fee-net).
 *
 * The old 20 names in strategy-library.ts are mediocre soup. They stay in
 * that file (live bot keeps importing it). They are retired-from-new-library
 * (NOT deleted from strategy-library.ts):
 *
 *   VELOCITY_MOMENTUM, FLOOR_DISTANCE, BREAKOUT_CAPTURE, FAKEOUT_FADE,
 *   EXHAUSTION_ANCHOR, BRTI_PROBABILITY, SQUEEZE_EXPANSION, CONFLUENCE_CASCADE,
 *   LATE_ENTRY_ANCHOR, MTF_ALIGNED, CHANNEL_BOUNCE, OTM_BREAKOUT_EXPANSION,
 *   OTM_ASYMMETRY, DEEP_OTM_SNIPER, VELOCITY_STALL_REVERSAL,
 *   SAKATA_CANDLE_PATTERN, LATE_MOMENTUM_CONTINUATION, BASIS_LAG_EDGE,
 *   MEAN_REVERSION_STRETCH, CHEAP_SIDE_15M
 *
 * Locked extras, also retired-from-new-library (not deleted):
 *   BOLLINGER_BAND, SETTLEMENT_PREDICTION, TOP_REVERSAL, BOTTOM_REVERSAL
 *
 * Director: skip → side → one predicate.
 * paperMode true. autoMode false. LIVE_APPLY false on every predicate.
 * Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR. Never register StrategyIds
 * on TradingBot.evaluate.
 */
import { decideSettlementSide, type SettlementSide } from "../settlement-side.js";
import { deskSkip, type DeskBook } from "./skip.js";
import { isPersistCheapAsk, shouldPersistCheapTake } from "./persist-cheap.js";
import { shouldMeteredLagTake } from "./metered-lag.js";
import { shouldTrendConfluenceTake } from "./trend-confluence.js";
import { shouldScalpVelocityTake } from "./scalp-velocity.js";
import { shouldStructureReversalTake } from "./structure-reversal.js";
import { shouldCheapEarlyExitTake } from "./cheap-early-exit.js";
export {
  LIVE_APPLY as PANIC_FADE_LIVE_APPLY,
} from "./panic-fade.js";
export {
  LIVE_APPLY as STREAK_SAT_FADE_LIVE_APPLY,
} from "./streak-sat-fade.js";
export {
  LIVE_APPLY as STREAK_CHANNEL_BB_LIVE_APPLY,
} from "./streak-channel-bb.js";
import type { StructureReversalSnapshot } from "../structure-reversal.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;

export type DeskPredicate =
  | "skip"
  | "persist-cheap"
  | "metered-lag"
  | "trend-confluence"
  | "structure-reversal"
  | "scalp-velocity"
  | "cheap-early-exit"
  | "panic-fade"
  | "streak-sat-fade"
  | "streak-channel-bb";

export type DeskLibraryDecision = {
  book: DeskBook;
  side: SettlementSide;
  predicate: DeskPredicate;
  take: boolean;
  reason: string;
};

/**
 * Catalog of NEW predicates. Old StrategyIds are retired-from-new-library
 * (listed in the file header). LIVE_APPLY is false on every row.
 */
export const DESK_LIBRARY_CATALOG = [
  { id: "skip" as const, book: "skip" as const, liveApply: false, paperMode: true, autoMode: false },
  { id: "persist-cheap" as const, book: "settlement" as const, liveApply: false, paperMode: true, autoMode: false },
  { id: "metered-lag" as const, book: "settlement" as const, liveApply: false, paperMode: true, autoMode: false },
  { id: "trend-confluence" as const, book: "settlement" as const, liveApply: false, paperMode: true, autoMode: false },
  { id: "structure-reversal" as const, book: "settlement" as const, liveApply: false, paperMode: true, autoMode: false },
  { id: "scalp-velocity" as const, book: "scalp" as const, liveApply: false, paperMode: true, autoMode: false },
  { id: "cheap-early-exit" as const, book: "green-sell" as const, liveApply: false, paperMode: true, autoMode: false },
  { id: "panic-fade" as const, book: "green-sell" as const, liveApply: false, paperMode: true, autoMode: false },
  { id: "streak-sat-fade" as const, book: "green-sell" as const, liveApply: false, paperMode: true, autoMode: false },
  { id: "streak-channel-bb" as const, book: "green-sell" as const, liveApply: false, paperMode: true, autoMode: false },
] as const;

/** Old 20-name soup + locked extras. Not deleted from strategy-library.ts. */
export const RETIRED_FROM_NEW_LIBRARY = [
  "VELOCITY_MOMENTUM",
  "FLOOR_DISTANCE",
  "BREAKOUT_CAPTURE",
  "FAKEOUT_FADE",
  "EXHAUSTION_ANCHOR",
  "BRTI_PROBABILITY",
  "SQUEEZE_EXPANSION",
  "CONFLUENCE_CASCADE",
  "LATE_ENTRY_ANCHOR",
  "MTF_ALIGNED",
  "CHANNEL_BOUNCE",
  "OTM_BREAKOUT_EXPANSION",
  "OTM_ASYMMETRY",
  "DEEP_OTM_SNIPER",
  "VELOCITY_STALL_REVERSAL",
  "SAKATA_CANDLE_PATTERN",
  "LATE_MOMENTUM_CONTINUATION",
  "BASIS_LAG_EDGE",
  "MEAN_REVERSION_STRETCH",
  "CHEAP_SIDE_15M",
  "BOLLINGER_BAND",
  "SETTLEMENT_PREDICTION",
  "TOP_REVERSAL",
  "BOTTOM_REVERSAL",
] as const;

export type DeskObservation = {
  book?: DeskBook | null;
  ticker?: string | null;
  askCents?: number | null;
  yesAsk?: number | null;
  noAsk?: number | null;
  secsRemaining?: number | null;
  /** winRateAtPrice. Never confidence. */
  pYes?: number | null;
  pNo?: number | null;
  mtf?: number | null;
  still?: boolean;
  dMidCents?: number | null;
  inBuyDirection?: boolean;
  open?: boolean;
  openSide?: "yes" | "no" | null;
  remainingBudgetCents?: number;
  fillCostCents?: number;
  msFairAgree?: number;
  floor?: number | null;
  /** Live BTC. Optional pinRisk input. */
  spot?: number | null;
  projectedSettlement?: number | null;
  ha?: { color: "green" | "red"; consecutive?: number } | null;
  lagStale?: boolean;
  lagDollars?: number | null;
  msOnSideOfFloor?: number;
  evCents?: number;
  regime?: string | null;
  /** Shadow STRUCTURE_REVERSAL snapshot. Armed only after 30s-median persist. */
  structureReversal?: StructureReversalSnapshot | null;
};

function askForSide(obs: DeskObservation, side: "yes" | "no"): number | null {
  if (typeof obs.askCents === "number" && Number.isFinite(obs.askCents)) return obs.askCents;
  const ask = side === "yes" ? obs.yesAsk : obs.noAsk;
  return typeof ask === "number" && Number.isFinite(ask) ? ask : null;
}

function hasLagFields(obs: DeskObservation): boolean {
  return obs.lagStale != null || obs.lagDollars != null || obs.msOnSideOfFloor != null;
}

function decision(
  book: DeskBook,
  side: SettlementSide,
  predicate: DeskPredicate,
  take: boolean,
  reason: string,
): DeskLibraryDecision {
  return { book, side, predicate, take, reason };
}

/**
 * Director: skip → side → one predicate.
 * Never returns ENABLE / ENABLE_STRATEGY. LIVE_APPLY stays false.
 */
export function evaluateDeskLibrary(obs: DeskObservation): DeskLibraryDecision {
  const skipDec = deskSkip({
    askCents: obs.askCents ?? obs.yesAsk ?? obs.noAsk ?? null,
    secsRemaining: obs.secsRemaining ?? null,
    book: obs.book ?? null,
    still: obs.still,
    dMidCents: obs.dMidCents ?? null,
    ticker: obs.ticker ?? null,
    spot: obs.spot ?? null,
    floor: obs.floor ?? null,
  });
  if (skipDec.skip) {
    return decision(skipDec.book, "skip", "skip", false, skipDec.reason);
  }

  const bookEarly: DeskBook = obs.book ?? "settlement";
  if (bookEarly === "settlement" && obs.structureReversal?.armed) {
    const d = shouldStructureReversalTake({
      snapshot: obs.structureReversal,
      secsRemaining: obs.secsRemaining ?? 0,
      yesAsk: obs.yesAsk ?? obs.askCents,
      noAsk: obs.noAsk,
      pWin: obs.pYes ?? obs.pNo ?? null,
    });
    return decision("settlement", d.side, "structure-reversal", d.take, d.reason);
  }

  const pYes = obs.pYes ?? null;
  const pNo = obs.pNo ?? null;
  const sideDec = decideSettlementSide({
    pYes,
    pNo,
    mtf: obs.mtf ?? 0,
    ...(obs.lagStale !== undefined
      ? { lagStale: obs.lagStale, lagDollars: obs.lagDollars ?? null }
      : {}),
  });
  if (sideDec.side === "skip") {
    return decision(skipDec.book, "skip", "skip", false, sideDec.reason);
  }

  const side = sideDec.side;
  const book: DeskBook = obs.book ?? "settlement";
  const ask = askForSide(obs, side);
  const askCents = ask ?? 0;
  const secsRemaining = obs.secsRemaining ?? 0;

  if (book === "scalp") {
    const d = shouldScalpVelocityTake({
      side,
      askCents,
      secsRemaining,
      open: obs.open,
      openSide: obs.openSide,
      remainingBudgetCents: obs.remainingBudgetCents,
      fillCostCents: obs.fillCostCents,
      mtf: obs.mtf ?? 0,
      inBuyDirection: obs.inBuyDirection,
      dMidCents: obs.dMidCents,
      still: obs.still,
    });
    return decision("scalp", side, "scalp-velocity", d.take, d.reason);
  }

  if (book === "green-sell") {
    const d = shouldCheapEarlyExitTake({
      side,
      askCents,
      secsRemaining,
      msFairAgree: obs.msFairAgree ?? 0,
      mtf: obs.mtf ?? 0,
      ha: obs.ha,
      floor: obs.floor,
      projectedSettlement: obs.projectedSettlement,
    });
    return decision("green-sell", side, "cheap-early-exit", d.take, d.reason);
  }

  // settlement: pick ONE predicate
  if (ask != null && isPersistCheapAsk(ask)) {
    const wr = sideDec.pWin;
    if (wr == null) {
      return decision("settlement", "skip", "skip", false, "p_null_or_invalid");
    }
    const d = shouldPersistCheapTake({
      side,
      askCents: ask,
      secsRemaining,
      msFairAgree: obs.msFairAgree ?? 0,
      mtf: obs.mtf ?? 0,
      ha: obs.ha,
      pWin: wr,
      floor: obs.floor,
      projectedSettlement: obs.projectedSettlement,
    });
    return decision("settlement", side, "persist-cheap", d.take, d.reason);
  }

  if (hasLagFields(obs)) {
    const d = shouldMeteredLagTake({
      side,
      askCents,
      msOnSideOfFloor: obs.msOnSideOfFloor ?? 0,
      evCents: obs.evCents ?? 0,
      mtf: obs.mtf ?? 0,
      lagStale: obs.lagStale === true,
      lagDollars: obs.lagDollars ?? null,
    });
    return decision("settlement", side, "metered-lag", d.take, d.reason);
  }

  const d = shouldTrendConfluenceTake({
    side,
    askCents,
    regime: obs.regime,
    still: obs.still,
    dMidCents: obs.dMidCents,
    mtf: obs.mtf ?? 0,
    pWin: sideDec.pWin,
    spot: obs.spot ?? null,
    floor: obs.floor ?? null,
  });
  return decision("settlement", side, "trend-confluence", d.take, d.reason);
}

export {
  deskSkip,
  LOTTERY_LAST_SECS,
  LOTTERY_ASK_MIN_CENTS,
  LOTTERY_ASK_MAX_CENTS,
  STILL_MID_MIN_CENTS,
  STILL_MID_MAX_CENTS,
} from "./skip.js";
export {
  shouldPersistCheapTake,
  isPersistCheapAsk,
  PERSIST_CHEAP_MIN_MS,
  PERSIST_CHEAP_ASK_MIN_CENTS,
  PERSIST_CHEAP_ASK_MAX_CENTS,
  PERSIST_CHEAP_HOLD_DEFAULT,
} from "./persist-cheap.js";
export {
  shouldMeteredLagTake,
  METERED_LAG_MIN_ABS_DOLLARS,
} from "./metered-lag.js";
export {
  shouldTrendConfluenceTake,
  isActualTrend,
  TREND_REGIMES,
} from "./trend-confluence.js";
export {
  shouldScalpVelocityTake,
  SCALP_BAR_RISK_PCT,
} from "./scalp-velocity.js";
export {
  shouldStructureReversalTake,
} from "./structure-reversal.js";
export {
  shouldCheapEarlyExitTake,
  isCheapEarlyAsk,
  CHEAP_EARLY_PERSIST_MS,
  CHEAP_EARLY_GREEN_CENTS,
  CHEAP_EARLY_ASK_MIN_CENTS,
  CHEAP_EARLY_ASK_MAX_CENTS,
  CHEAP_EARLY_EXIT_PAPER,
  cheapEarlyExitPaperMayFill,
} from "./cheap-early-exit.js";
