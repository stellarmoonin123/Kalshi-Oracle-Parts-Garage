/**
 * aria-lesson-effectiveness.ts
 *
 * MEASUREMENT-ONLY: computes a before/after effectiveness report for each
 * persisted ARIA lesson by comparing win-rate and expected-value (EV) in
 * settled bot_trades BEFORE vs. AFTER the lesson's createdAt timestamp.
 *
 * This is purely observational — it answers "did lessons targeting strategy X
 * or regime Y correlate with improved outcomes afterward?" without changing
 * any live ARIA behaviour or trading logic.
 *
 * Methodology
 * ───────────
 * For each unique (strategyId, regime) target dimension found across all
 * persisted lessons:
 *
 *   1. Collect every settled bot_trade matching that dimension (win|loss
 *      outcomes only; regime may be null for cross-regime / strategy-only
 *      lessons).
 *   2. Split on the EARLIEST lesson.createdAt for that bucket (the first time
 *      ARIA captured this concern): trades settled before that timestamp go
 *      into the BEFORE window; trades settled at or after go into the AFTER
 *      window.  "Settled" = settledAt if present, otherwise createdAt (legacy
 *      rows that pre-date the settledAt column).
 *   3. Compute win-rate (wins/n) and avg EV (mean pnlCents) for each window.
 *   4. Report the delta and flag low-confidence windows (< MIN_SAMPLE).
 *
 * No mutations, no gates, no side-effects — read-only DB queries only.
 */

import { db, ariaLessons, botTrades } from "@workspace/db";
import { inArray, isNotNull, and, eq, sql } from "drizzle-orm";

/** Minimum settled trades for a window to be considered statistically reportable. */
const MIN_SAMPLE = 10;

export interface WindowStats {
  n:           number;
  wins:        number;
  losses:      number;
  winRate:     number | null;  // null when n === 0
  avgEvCents:  number | null;  // mean pnlCents; null when n === 0
  lowConfidence: boolean;      // n < MIN_SAMPLE
}

export interface LessonEffectivenessRecord {
  /** The bucket key this record covers: "strategyId" or "strategyId|regime". */
  bucketKey:    string;
  strategyId:   string | null;
  regime:       string | null;

  /** Lesson text and metadata for the EARLIEST (anchor) lesson in this bucket. */
  anchorLessonId:             number;
  anchorLessonText:           string;
  anchorLessonCreatedAt:      Date;
  anchorLessonTimesReinforced: number;

  /** All lesson IDs that target this (strategyId, regime) bucket. */
  lessonIds: number[];

  before: WindowStats;
  after:  WindowStats;

  /** winRate delta (after.winRate - before.winRate); null if either window has 0 trades. */
  winRateDelta:  number | null;
  /** avgEv delta (after.avgEvCents - before.avgEvCents); null if either window is empty. */
  evDelta:       number | null;

  /** Narrative verdict for quick human reading. */
  verdict: string;
}

export interface AriaLessonEffectivenessReport {
  generatedAt:      string;
  totalLessons:     number;
  bucketsAnalyzed:  number;
  /** Note reminding the consumer this is correlation only, not causation. */
  caveat:           string;
  records:          LessonEffectivenessRecord[];
}

// ─────────────────────────────────────────────────────────────────────────────

function windowStats(pnls: number[]): WindowStats {
  const n = pnls.length;
  if (n === 0) return { n: 0, wins: 0, losses: 0, winRate: null, avgEvCents: null, lowConfidence: true };
  const wins   = pnls.filter(p => p > 0).length;
  const losses = pnls.filter(p => p < 0).length;
  const sum    = pnls.reduce((a, b) => a + b, 0);
  return {
    n,
    wins,
    losses,
    winRate:    wins / n,
    avgEvCents: sum / n,
    lowConfidence: n < MIN_SAMPLE,
  };
}

function verdict(rec: Omit<LessonEffectivenessRecord, "verdict">): string {
  const { before, after, winRateDelta, evDelta } = rec;

  if (before.n === 0 && after.n === 0) {
    return "No settled trades found for this strategy/regime bucket — cannot assess lesson impact.";
  }
  if (before.n === 0) {
    return "No settled trades BEFORE this lesson was created — lesson predates available history for this bucket.";
  }
  if (after.n === 0) {
    return "No settled trades AFTER this lesson was created — need more live data to measure impact.";
  }

  const parts: string[] = [];

  if (before.lowConfidence || after.lowConfidence) {
    parts.push(`⚠ Low-confidence (before n=${before.n}, after n=${after.n}; threshold=${MIN_SAMPLE}).`);
  }

  if (winRateDelta !== null) {
    const dir = winRateDelta > 0.01 ? "↑ improved" : winRateDelta < -0.01 ? "↓ worsened" : "→ unchanged";
    parts.push(`Win-rate ${dir}: ${(before.winRate! * 100).toFixed(1)}% → ${(after.winRate! * 100).toFixed(1)}% (Δ${(winRateDelta * 100).toFixed(1)}pp).`);
  }

  if (evDelta !== null) {
    const dir = evDelta > 0 ? "↑ improved" : evDelta < 0 ? "↓ worsened" : "→ unchanged";
    parts.push(`Avg EV ${dir}: ${before.avgEvCents!.toFixed(1)}¢ → ${after.avgEvCents!.toFixed(1)}¢ (Δ${evDelta.toFixed(1)}¢).`);
  }

  return parts.length > 0 ? parts.join(" ") : "Insufficient data to determine impact.";
}

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Computes the lesson effectiveness report.  Read-only — no mutations.
 */
export async function computeAriaLessonEffectiveness(): Promise<AriaLessonEffectivenessReport> {
  // 1. Load all lessons.
  const lessons = await db
    .select()
    .from(ariaLessons)
    .orderBy(ariaLessons.createdAt);

  // 2. Load all settled trades (win|loss) with the columns we need.
  //    Use settledAt when present, fall back to createdAt for legacy rows.
  const trades = await db
    .select({
      id:           botTrades.id,
      strategyId:   botTrades.strategyId,
      regime:       botTrades.regime,
      outcome:      botTrades.outcome,
      pnlCents:     botTrades.pnlCents,
      settledAt:    botTrades.settledAt,
      createdAt:    botTrades.createdAt,
    })
    .from(botTrades)
    .where(inArray(botTrades.outcome, ["win", "loss"]));

  // Pre-compute effective settlement time per trade.
  const settleTime = (t: typeof trades[number]): number =>
    (t.settledAt ?? t.createdAt).getTime();

  // 3. Group lessons into (strategyId, regime) buckets.
  //    regime is NOT stored in aria_lessons — lessons only know strategyId.
  //    So our primary bucket dimension is just strategyId (null = general).
  //    We cannot filter by regime at the lesson level; instead we group trades
  //    by regime separately when a lesson has strategyId set.
  //
  //    Bucket key: `{strategyId}` or `__general__` for null strategyId.
  type Bucket = {
    strategyId: string | null;
    regime: null;  // kept for future expansion; always null today
    lessonIds: number[];
    anchorAt: number;  // earliest createdAt ms for this bucket
    anchorLesson: typeof lessons[number];
  };

  const bucketMap = new Map<string, Bucket>();

  for (const l of lessons) {
    const key = l.strategyId ?? "__general__";
    const existing = bucketMap.get(key);
    const createdMs = l.createdAt.getTime();
    if (!existing) {
      bucketMap.set(key, {
        strategyId: l.strategyId,
        regime: null,
        lessonIds: [l.id],
        anchorAt: createdMs,
        anchorLesson: l,
      });
    } else {
      existing.lessonIds.push(l.id);
      if (createdMs < existing.anchorAt) {
        existing.anchorAt = createdMs;
        existing.anchorLesson = l;
      }
    }
  }

  // 4. For each bucket, split the matching trades into before/after windows.
  const records: LessonEffectivenessRecord[] = [];

  for (const [bucketKey, bucket] of bucketMap.entries()) {
    // Filter trades matching this bucket's strategyId.
    // null strategyId = general lesson → compare against ALL trades (cross-strategy).
    const relevant = bucket.strategyId === null
      ? trades
      : trades.filter(t => t.strategyId === bucket.strategyId);

    const anchorMs   = bucket.anchorAt;
    const beforePnls = relevant.filter(t => settleTime(t) < anchorMs).map(t => t.pnlCents ?? 0);
    const afterPnls  = relevant.filter(t => settleTime(t) >= anchorMs).map(t => t.pnlCents ?? 0);

    const before = windowStats(beforePnls);
    const after  = windowStats(afterPnls);

    const winRateDelta =
      before.winRate !== null && after.winRate !== null
        ? after.winRate - before.winRate
        : null;
    const evDelta =
      before.avgEvCents !== null && after.avgEvCents !== null
        ? after.avgEvCents - before.avgEvCents
        : null;

    const rec: Omit<LessonEffectivenessRecord, "verdict"> = {
      bucketKey,
      strategyId: bucket.strategyId,
      regime: null,
      anchorLessonId:              bucket.anchorLesson.id,
      anchorLessonText:            bucket.anchorLesson.lesson,
      anchorLessonCreatedAt:       bucket.anchorLesson.createdAt,
      anchorLessonTimesReinforced: bucket.anchorLesson.timesReinforced,
      lessonIds: bucket.lessonIds,
      before,
      after,
      winRateDelta,
      evDelta,
    };

    records.push({ ...rec, verdict: verdict(rec) });
  }

  // Sort: buckets with the most "after" data first (best chance of meaningful signal).
  records.sort((a, b) => b.after.n - a.after.n);

  return {
    generatedAt:     new Date().toISOString(),
    totalLessons:    lessons.length,
    bucketsAnalyzed: records.length,
    caveat:
      "MEASUREMENT ONLY — correlation, not causation. A positive delta after a lesson was recorded does not prove the lesson caused improvement; many other variables (market regime changes, strategy mix changes, sample noise) can drive the same signal. Use alongside the risk-report and edge-drift-report for context.",
    records,
  };
}
