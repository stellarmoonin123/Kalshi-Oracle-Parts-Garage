/**
 * Restart log hole: "Cannot access 'STRATEGIES' before initialization"
 * was caused by warnOnOrphanedStrategiesAtStartup() at admission module load
 * while strategy-library → cheap-*-exit → admission was still initializing.
 */
import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { warnOnOrphanedStrategiesAtStartup } from "./admission.js";
import { getAllStrategyMeta } from "./strategy-library.js";

const here = path.dirname(fileURLToPath(import.meta.url));

test("admission module body must not call warnOnOrphanedStrategiesAtStartup (STRATEGIES TDZ)", () => {
  const src = readFileSync(path.join(here, "admission.ts"), "utf8");
  // The export may remain; the eager module-level call must be gone.
  assert.match(src, /export function warnOnOrphanedStrategiesAtStartup/);
  assert.doesNotMatch(
    src,
    /^warnOnOrphanedStrategiesAtStartup\(\);\s*$/m,
  );
  assert.match(src, /TradingBot\.start\(\)/);
});

test("warnOnOrphanedStrategiesAtStartup runs after STRATEGIES init (no TDZ throw)", () => {
  assert.doesNotThrow(() => warnOnOrphanedStrategiesAtStartup());
  assert.ok(getAllStrategyMeta().length > 0);
});

test("trading-bot start() wires deferred orphan check", () => {
  const bot = readFileSync(path.join(here, "trading-bot.ts"), "utf8");
  assert.match(bot, /warnOnOrphanedStrategiesAtStartup\(\)/);
  assert.match(bot, /Post-init: strategy-library STRATEGIES/);
});
