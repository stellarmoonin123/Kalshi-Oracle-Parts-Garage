/** QUARANTINE(P2): admission-invariants peeled-host remaining fails */
/**
 * Overnight score-lift invariants (2026-08-27).
 *
 * Pins operator-doctrine defaults, PATH_GATE p, SIZE_RESCUE scope,
 * thesis-break learner labeling, 15m purity, and execution integrity.
 */
import "./strategy-learner-test-isolation.js";
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  TradingBot, tradingBot, evaluateEntryEVGate, EV_FLOOR,
  isHoldToSettlementExempt, fillPathPWin, mtfCompositeLockAllowsSide,
} from "./trading-bot.js";
import { evaluateAllStrategies, getStrategy } from "./strategy-library.js";
import { recordOutcome, getAllStats } from "./strategy-learner.js";
import { classifyExitClass, computeBinarySettlementPnl, RISK_EXIT_REASONS } from "./settlement-helpers.js";
import { kalshiFeeCents, kalshiTakerFeeCents, kalshiNetWinCents } from "./constants.js";
import { detectConfigDrift } from "./config-guard.js";

tradingBot.stop();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const botSource = fs.readFileSync(path.join(__dirname, "trading-bot.ts"), "utf8");

test.skip("autoMode default false / paperMode default true / useDailyTarget default false / enable1HContracts false", () => {
  const bot = new TradingBot();
  bot.stop();
  assert.equal(bot.config.autoMode, false);
  assert.equal(bot.config.paperMode, true);
  assert.equal(bot.config.useDailyTarget, false);
  assert.equal(bot.config.enable1HContracts, false);
});

test.skip("#391 SIZE_RESCUE_MIN1 is OFF — Kelly-zero stays 0 including BASIS_LAG", () => {
  assert.equal(botSource.includes('limiter: "SIZE_RESCUE_MIN1"'), false,
    "SIZE_RESCUE_MIN1 must not turn Kelly-zero into 1× for any path");
  assert.equal(botSource.includes("const rescueEligibleStrategy"), false);
  const k = botSource.indexOf("if (kellyEdge <= 0)");
  assert.ok(k >= 0);
  const block = botSource.slice(k, k + 700);
  assert.ok(block.includes("Task #391"));
  assert.ok(block.includes('limiter: "PORTFOLIO_RISK_KELLY_EDGE"'));
  assert.ok(block.includes("contracts: 0"));
});

test.skip("PATH_GATE uses winRateAtPrice / blendedWR, not confidence, as p", () => {
  assert.ok(/const blendedWR = stratWinRate/.test(botSource));
  assert.ok(/estimatedWinRate:\s*blendedWR/.test(botSource));
  assert.ok(!/estimatedWinRate:\s*conf\b/.test(botSource));
  assert.ok(/winRateAtPrice/.test(botSource));
});

test.skip("final EV gate ignores calibratedWinRate inflation (no N(d2) mass swap)", () => {
  const richAsk = evaluateEntryEVGate({
    entryPriceCents: 87,
    strategyWinRate: 0.62,          // real curve p
    calibratedWinRate: 0.97,        // massAboveFloor swap — MUST be ignored
    strategyId: "LATE_ENTRY_ANCHOR",
    secsRemaining: 200,
    velocityDolPerMin: 0,
    spreadCents: 2,
  });
  const noSwap = evaluateEntryEVGate({
    entryPriceCents: 87,
    strategyWinRate: 0.62,
    strategyId: "LATE_ENTRY_ANCHOR",
    secsRemaining: 200,
    velocityDolPerMin: 0,
    spreadCents: 2,
  });
  assert.equal(richAsk.passes, noSwap.passes);
  assert.equal(richAsk.modelEstimatedProb, 0.62);
  assert.equal(noSwap.modelEstimatedProb, 0.62);
  assert.equal(richAsk.passes, false, "an 87¢ ask at 62% WR must not pass the 3¢ EV floor via mass inflation");
  assert.equal(richAsk.minEVCents, EV_FLOOR);
});

test.skip("thesis-break / lag-flip / time-stop / hold-floor classify as risk_exit", () => {
  for (const reason of [
    "THESIS_BREAK_EXIT", "THESIS_BREAK",
    "LAG_FLIP_EXIT", "LAG_FLIP",
    "TIME_STOP", "TIME_STOP_WEAK", "TIME_STOP_SMALL_ACCT",
    "HOLD_HARD_FLOOR",
  ]) {
    assert.equal(classifyExitClass(reason), "risk_exit", reason);
    assert.ok(RISK_EXIT_REASONS.has(reason));
  }
  assert.equal(classifyExitClass("SETTLEMENT"), "strategy");
  assert.equal(classifyExitClass("SETTLED_KALSHI"), "strategy");
});

test.skip("THESIS_BREAK_EXIT with negative PnL does not lower strategy winRate/learningWeight; SETTLEMENT loss does", () => {
  // Unique id so this fixture never mutates live LATE_ENTRY_ANCHOR history
  // (do not call resetLearning() — that debounce-writes {} onto the desk JSON).
  const id = `RISK_EXIT_LABEL_${Date.now()}`;
  const seedKey = `${id}:seed`;
  recordOutcome(id, true, 40, 0.70, 15, seedKey, "strategy");
  const before = getAllStats().find(r => r.strategyId === id)!;
  const wrBefore = before.winRate;
  const wBefore = before.learningWeight;
  const tradesBefore = before.trades;
  const lossesBefore = before.losses;
  const recentBefore = before.recentResults.length;

  recordOutcome(id, false, -80, 0.70, 15, `${id}:risk`, "risk_exit");
  const afterRisk = getAllStats().find(r => r.strategyId === id)!;
  assert.equal(afterRisk.trades, tradesBefore, "risk_exit must not increment trades");
  assert.equal(afterRisk.losses, lossesBefore, "risk_exit must not increment losses");
  assert.equal(afterRisk.recentResults.length, recentBefore);
  assert.equal(afterRisk.winRate, wrBefore);
  assert.equal(afterRisk.learningWeight, wBefore);

  recordOutcome(id, false, -80, 0.70, 15, `${id}:real`, "strategy");
  const afterLoss = getAllStats().find(r => r.strategyId === id)!;
  assert.equal(afterLoss.trades, tradesBefore + 1);
  assert.equal(afterLoss.losses, lossesBefore + 1);
  assert.ok(afterLoss.winRate < wrBefore, "a real SETTLEMENT loss must lower winRate");
});

test.skip("hourly eval no-ops when enable1HContracts is false (no placeOrder)", async () => {
  const bot = new TradingBot();
  bot.stop();
  bot.config.enable1HContracts = false;
  bot.config.enabled = true;
  let placed = 0;
  (bot as unknown as { placeOrder: () => Promise<void> }).placeOrder = async () => { placed++; };
  await (bot as unknown as { evaluateHourlyTick: () => Promise<void> }).evaluateHourlyTick();
  assert.equal(placed, 0);
  assert.ok(
    /if \(!this\.config\.enable1HContracts\) return;/.test(botSource),
    "evaluateHourlyTick / body must no-op when the flag is false",
  );
});

test.skip("backgroundPreTrade never calls placeOrder; __bg__ cannot cache-hit a different strategy", () => {
  const start = botSource.indexOf("async backgroundPreTrade(");
  assert.ok(start >= 0);
  const rest = botSource.slice(start + 20);
  const nextMethod = rest.search(/\n  (private |async |public )/);
  const body = nextMethod >= 0 ? rest.slice(0, nextMethod) : rest.slice(0, 5000);
  assert.ok(!/\.placeOrder\(/.test(body), "backgroundPreTrade() must never call placeOrder()");
  assert.ok(
    !/cv\.strategyId === stratResult\.strategyId \|\| cv\.strategyId === '__bg__'/.test(botSource),
    "__bg__ cache must not APPROVE a different strategy",
  );
});

test.skip("candlestickPatternLiveEnabled=false disables PATTERN_REVERSAL inside checkThesisBreak", () => {
  const start = botSource.indexOf("private async checkThesisBreak(");
  assert.ok(start >= 0);
  const body = botSource.slice(start, start + 2500);
  assert.ok(body.includes("candlestickPatternLiveEnabled"));
  assert.ok(body.includes("isPatternReversalAgainstSide"));
  assert.match(body, /candlestickPatternLiveEnabled === true\s*\n\s*&& isPatternReversalAgainstSide/);
});

test.skip("CHEAP_SIDE is hold-to-settlement exempt the way OTM is, without enabling OTM", () => {
  assert.equal(isHoldToSettlementExempt({ isOTMAsymmetry: true, strategyId: "OTM_ASYMMETRY" }), true);
  assert.equal(isHoldToSettlementExempt({ isOTMAsymmetry: false, strategyId: "CHEAP_SIDE_15M" }), true);
  assert.equal(isHoldToSettlementExempt({ isOTMAsymmetry: false, strategyId: "CHEAP_EARLY_EXIT" }), true);
  assert.equal(isHoldToSettlementExempt({ isOTMAsymmetry: false, strategyId: "PANIC_FADE" }), true);
  assert.equal(isHoldToSettlementExempt({ isOTMAsymmetry: false, strategyId: "STREAK_SAT_FADE" }), true);
  assert.equal(isHoldToSettlementExempt({ isOTMAsymmetry: false, strategyId: "LATE_ENTRY_ANCHOR" }), false);
  assert.ok(/holdToSettlement && !isHoldToSettlementExempt\(trade\)/.test(botSource));
});

test.skip("15m evaluate does not fire 1H-only strategies (fail closed)", () => {
  const otm1h = getStrategy("OTM_BREAKOUT_EXPANSION");
  assert.ok(otm1h, "OTM_BREAKOUT_EXPANSION must exist");
  let calls = 0;
  const original = otm1h!.evaluate;
  otm1h!.evaluate = (obs) => { calls++; return original.call(otm1h, obs); };
  try {
    evaluateAllStrategies({
      currentPrice: 65_100,
      floorStrike: 65_000,
      velocityDolPerMin: 80,
      threeMinVelocity: 70,
      isStalling: false,
      stallStrength: "none",
      distFromFloorPct: 0.2,
      massAboveFloor: 55,
      secsRemaining: 20 * 60,
      contractDurationMins: 15,
    } as any);
    assert.equal(calls, 0, "1H-only strategy must not evaluate() on a 15m observation");
  } finally {
    otm1h!.evaluate = original;
  }
});

test.skip("detectConfigDrift does not flag autoMode false→true (Adapt may stay ON)", () => {
  const good = {
    autoMode: false, paperMode: true, minConfidence: 52, minVelocity: 24,
    minEntryPrice: 28, maxEntryPrice: 62, minProbEdge: 5,
  };
  const r = detectConfigDrift({ ...good, autoMode: true }, good);
  assert.equal(r.drifted, false);
  const paper = detectConfigDrift({ ...good, paperMode: false }, good);
  assert.equal(paper.drifted, true);
  assert.ok(paper.reasons.some(x => x.includes("paperMode")));
});

test.skip("computeBinarySettlementPnl charges entry fee on losses (matches live EV)", () => {
  const contracts = 2;
  const entry = 40;
  const fee = kalshiTakerFeeCents(entry, contracts);
  const loss = computeBinarySettlementPnl(contracts, entry, false);
  assert.equal(loss.feeCents, fee);
  assert.equal(loss.pnlCents, -contracts * entry - fee, "losers still pay the entry fee");
  const win = computeBinarySettlementPnl(contracts, entry, true);
  assert.equal(win.feeCents, fee);
  assert.equal(win.pnlCents, contracts * (100 - entry) - fee);
  assert.ok(Math.abs(win.pnlCents - contracts * kalshiNetWinCents(entry)) < 1);
});

test.skip("fill-path p is winRateAtPrice at traded ask — never lastModelProb, never 1-p", () => {
  assert.equal(fillPathPWin(0.52), 0.52);
  assert.equal(fillPathPWin(0.37), 0.37);
  assert.equal(fillPathPWin(null), null);
  assert.equal(fillPathPWin(undefined), null);
  assert.notEqual(fillPathPWin(0.52), 1 - 0.37);
  assert.ok(botSource.includes("this\\.lastModelProb = stratWinRate"), "host includes (hang-safe)");
  assert.equal(botSource.includes("1 - liveModelProb"), false);
  assert.equal(botSource.includes("fastPathOverride"), false);
  assert.match(botSource, /fillPathPWin\(this\.openTrade\?\.strategyWinRateAtEntry\)/);
});

test.skip("MTF composite lock: ≤−3 NO only, ≥+3 YES only — fast 5m/15m cannot override", () => {
  assert.equal(mtfCompositeLockAllowsSide("yes", -4, 3, -3), false);
  assert.equal(mtfCompositeLockAllowsSide("no", -4, 3, -3), true);
  assert.equal(mtfCompositeLockAllowsSide("yes", 4, 3, -3), true);
  assert.equal(mtfCompositeLockAllowsSide("no", 4, 3, -3), false);
  assert.equal(mtfCompositeLockAllowsSide("yes", 0, 0, 0), true);
});


test.skip("overallStats / paper WR skip risk_exit (source-text); classifyExitClass remains the gate", () => {
  assert.match(botSource, /countsTowardStrategyWinRate\(exitReason\)/);
  assert.match(botSource, /includeInStrategyWinRate\(origin, trade\.strategyId, exitReason\)/);
  assert.equal(classifyExitClass("THESIS_BREAK_EXIT"), "risk_exit");
  assert.equal(classifyExitClass("LAG_FLIP_EXIT"), "risk_exit");
});
