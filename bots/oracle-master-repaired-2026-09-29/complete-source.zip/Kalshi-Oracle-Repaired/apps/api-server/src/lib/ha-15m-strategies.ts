/**
 * ha-15m-strategies.ts — HA_RIVER, HA_FLIP, TICKET_WAVE, NO_CROSS.
 *
 * HA is permission only. Ask / EV / strike distance stay raw Kalshi / OHLC.
 * Fail-closed if HA 1m or 5m series missing — no fake HA.
 *
 * Paper = live brain (same evaluate). Not OPT_IN fail-closed. Not SEV1.
 * Dual-gate leftover (cheapEarlyExit / panicFade / cheapSide) stays false.
 */
import { EV_FLOOR } from "./admission.js";
import { computeTradeEV } from "./trade-path.js";
import { isKxbct15mTicker } from "./15m-product.js";
import { lagAgreesWithSide } from "./lag-meter.js";
import {
  HA_RIVER_MIN_SAME_COLOR,
  NO_CROSS_LAST_SECS,
  PATH_RIDE_MIN_HA_BARS,
  colorFlipped,
  distanceIsFat,
  haEmaBias,
  haFromRaw,
  huggingStrike,
  isStrikePin,
  lastColor,
  remainingVolDollars,
  sameColorRun,
  sideForColor,
  type RawOhlc,
} from "./path-ride.js";
import type { StrategyObservation, StrategyResult } from "./strategy-library.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;

export const HA_RIVER_ID = "HA_RIVER" as const;
export const HA_FLIP_ID = "HA_FLIP" as const;
export const TICKET_WAVE_ID = "TICKET_WAVE" as const;
export const NO_CROSS_ID = "NO_CROSS" as const;

export const HA_15M_ASK_MAX_CENTS = 55;
export const HA_15M_MIN_SECS = 3 * 60;
export const HA_15M_MAX_SECS = 12 * 60;
export const TICKET_WAVE_ASK_MIN = 15;
export const TICKET_WAVE_ASK_MAX = 40;

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

function is15m(obs: StrategyObservation): boolean {
  if ((obs.contractDurationMins ?? 15) !== 15) return false;
  if (obs.ticker && !isKxbct15mTicker(obs.ticker)) {
    const t = obs.ticker.toUpperCase();
    if (t.includes("KXBTCD") || t.includes("KXBTCH") || t.includes("PERP")) return false;
  }
  return true;
}

type HaPair = { ha1m: NonNullable<ReturnType<typeof haFromRaw>>; ha5m: NonNullable<ReturnType<typeof haFromRaw>> };

export type HaStarveReason = "ha1m_missing" | "ha5m_missing" | "ha_bars_short" | "ha_bar_gap";

let lastHaStarve: { ticker: string | null; reason: HaStarveReason; ts: number } | null = null;
const haStarveLogAt = new Map<string, number>();

export function peekHaStarveForTests(): { ticker: string | null; reason: HaStarveReason; ts: number } | null {
  return lastHaStarve;
}

export function resetHaStarveForTests(): void {
  lastHaStarve = null;
  haStarveLogAt.clear();
}

function barTs(b: RawOhlc & { t?: number; ts?: number; time?: number }): number | null {
  const n = b.t ?? b.ts ?? b.time;
  return typeof n === "number" && Number.isFinite(n) ? n : null;
}

/** Missing / gapped OHLC → starve. Never interpolate a fake HA bar. */
export function ohlcSeriesStarved(
  raw: RawOhlc[] | null | undefined,
  minBars: number,
  maxGapMs: number,
): HaStarveReason | null {
  if (!raw || raw.length === 0) return "ha1m_missing";
  if (raw.length < minBars) return "ha_bars_short";
  const ts: number[] = [];
  for (const b of raw) {
    if (!Number.isFinite(b.open) || !Number.isFinite(b.high) || !Number.isFinite(b.low) || !Number.isFinite(b.close)) {
      return "ha_bars_short";
    }
    const t = barTs(b as RawOhlc & { t?: number; ts?: number; time?: number });
    if (t != null) ts.push(t);
  }
  if (ts.length === raw.length && ts.length >= 2) {
    for (let i = 1; i < ts.length; i++) {
      if (ts[i]! - ts[i - 1]! > maxGapMs) return "ha_bar_gap";
    }
  }
  return null;
}

function logHaStarve(obs: StrategyObservation, reason: HaStarveReason): void {
  lastHaStarve = { ticker: obs.ticker ?? null, reason, ts: Date.now() };
  const key = `${obs.ticker ?? "?"}:${reason}`;
  const now = Date.now();
  const prev = haStarveLogAt.get(key) ?? 0;
  if (now - prev < 15_000) return;
  haStarveLogAt.set(key, now);
  try {
    console.warn(`[HA_STARVE] ticker=${obs.ticker ?? "?"} reason=${reason} never fake HA`);
  } catch {
    /* never throw from evaluate */
  }
}

function requireHa(obs: StrategyObservation): HaPair | null {
  const starve1 = ohlcSeriesStarved(obs.ohlc1m ?? null, PATH_RIDE_MIN_HA_BARS, 90_000);
  const starve5 = ohlcSeriesStarved(obs.ohlc5m ?? null, PATH_RIDE_MIN_HA_BARS, 6 * 60_000);
  if (starve1) {
    logHaStarve(obs, starve1 === "ha1m_missing" ? "ha1m_missing" : starve1);
    return null;
  }
  if (starve5) {
    logHaStarve(obs, starve5 === "ha1m_missing" ? "ha5m_missing" : starve5);
    return null;
  }
  const ha1m = haFromRaw(obs.ohlc1m ?? null);
  const ha5m = haFromRaw(obs.ohlc5m ?? null);
  if (!ha1m || !ha5m) {
    logHaStarve(obs, !ha1m ? "ha1m_missing" : "ha5m_missing");
    return null;
  }
  if (ha1m.length < PATH_RIDE_MIN_HA_BARS || ha5m.length < PATH_RIDE_MIN_HA_BARS) {
    logHaStarve(obs, "ha_bars_short");
    return null;
  }
  return { ha1m, ha5m };
}

function askOf(side: "yes" | "no", obs: StrategyObservation): number | undefined {
  return side === "yes" ? obs.yesAsk : obs.noAsk;
}

function bidOf(side: "yes" | "no", obs: StrategyObservation): number | undefined {
  return side === "yes" ? obs.yesBid : obs.noBid;
}

/** Conservative cheap-to-mid curve so EV 3¢ can admit ≤55 without cutting the floor. */
export function ha15mWinRate(entryPriceCents: number, minutesLeft: number): number {
  let wr: number;
  if (entryPriceCents <= 40) wr = 0.58;
  else if (entryPriceCents <= 55) wr = 0.58 - ((entryPriceCents - 40) / 15) * 0.06;
  else wr = 0.50;
  if (minutesLeft >= 10) wr -= 0.02;
  else if (minutesLeft <= 3) wr -= 0.01;
  return Math.max(0.46, Math.min(0.62, wr));
}

function evOk(obs: StrategyObservation, side: "yes" | "no", ask: number, strategyId: string): { netEV: number } | null {
  const wr = ha15mWinRate(ask, obs.secsRemaining / 60);
  const bid = bidOf(side, obs);
  const spreadCents = bid !== undefined ? ask - bid : undefined;
  const ev = computeTradeEV({
    entryPriceCents: ask,
    winRate: wr,
    strategyId,
    secsRemaining: obs.secsRemaining,
    velocityDolPerMin: obs.velocityDolPerMin,
    spreadCents,
  });
  if (!(ev.netEV >= EV_FLOOR) || ev.netEV <= 0) return null;
  return { netEV: ev.netEV };
}

function logWouldTake(id: string, detail: string): void {
  try {
    console.info(`would-take ${id} ${detail}`);
  } catch {
    // never throw from evaluate
  }
}

function result(
  id: string,
  name: string,
  side: "yes" | "no",
  ask: number,
  netEV: number,
  reason: string,
  earlyExitRule: string,
): StrategyResult {
  const signal = side === "yes" ? "YES" : "NO";
  logWouldTake(id, `${signal} @ ${ask}c ev=${netEV.toFixed(1)}c ${reason}`);
  return {
    signal,
    confidence: clamp(0.56 + Math.min(0.12, (HA_15M_ASK_MAX_CENTS - ask) / 400), 0.55, 0.70),
    strategyId: id as StrategyResult["strategyId"],
    strategyName: name,
    edgePct: netEV / 100,
    reason,
    earlyExitRule,
  };
}

function midWindow(secs: number): boolean {
  return secs >= HA_15M_MIN_SECS && secs <= HA_15M_MAX_SECS;
}

function riverSide(ha1m: HaPair["ha1m"], ha5m: HaPair["ha5m"]): "yes" | "no" | null {
  if (!sameColorRun(ha1m, HA_RIVER_MIN_SAME_COLOR)) return null;
  const c1 = lastColor(ha1m);
  const c5 = lastColor(ha5m);
  if (!c1 || !c5 || c1 !== c5) return null;
  const bias = haEmaBias(ha1m);
  if (!bias) return null;
  if (c1 === "green" && bias !== "bull") return null;
  if (c1 === "red" && bias !== "bear") return null;
  return sideForColor(c1);
}

export function evaluateHaRiver(obs: StrategyObservation): StrategyResult | null {
  if (!is15m(obs)) return null;
  if (obs.openStrategyId) return null;
  if (!midWindow(obs.secsRemaining)) return null;
  const ha = requireHa(obs);
  if (!ha) return null;
  if (isStrikePin({ ohlc1m: obs.ohlc1m, floor: obs.floorStrike, ha1m: ha.ha1m, ha5m: ha.ha5m, haOk: true })) return null;
  const side = riverSide(ha.ha1m, ha.ha5m);
  if (!side) return null;
  const ask = askOf(side, obs);
  if (typeof ask !== "number" || !Number.isFinite(ask) || ask > HA_15M_ASK_MAX_CENTS) return null;
  const ev = evOk(obs, side, ask, HA_RIVER_ID);
  if (!ev) return null;
  return result(
    HA_RIVER_ID,
    "HA River",
    side,
    ask,
    ev.netEV,
    `HA_RIVER ${side.toUpperCase()} @ ${ask}c 1m≥${HA_RIVER_MIN_SAME_COLOR} ${lastColor(ha.ha1m)} EMA8/21+5m agree`,
    "PATH_RIDE: TP 1.5×/2× cap 85; HA flip+cross if green or ≥3¢ adverse; last-2m hold-to-settle only if river+fat vol",
  );
}

export function evaluateHaFlip(obs: StrategyObservation): StrategyResult | null {
  if (!is15m(obs)) return null;
  if (!midWindow(obs.secsRemaining)) return null;
  const ha = requireHa(obs);
  if (!ha) return null;
  if (isStrikePin({ ohlc1m: obs.ohlc1m, floor: obs.floorStrike, ha1m: ha.ha1m, ha5m: ha.ha5m, haOk: true })) return null;
  if (!colorFlipped(ha.ha1m)) return null;
  const newColor = lastColor(ha.ha1m);
  if (!newColor) return null;
  const bias = haEmaBias(ha.ha1m);
  if (!bias) return null;
  if (newColor === "green" && bias !== "bull") return null;
  if (newColor === "red" && bias !== "bear") return null;

  // Open CC/LAG/HA_RIVER: exit only (monitor PATH_RIDE). Do not enter.
  if (obs.openStrategyId) return null;

  const c5 = lastColor(ha.ha5m);
  if (c5 !== newColor) return null; // flat: cheap new side only if 5m also flipped/agrees

  const side = sideForColor(newColor);
  const ask = askOf(side, obs);
  if (typeof ask !== "number" || !Number.isFinite(ask) || ask > HA_15M_ASK_MAX_CENTS) return null;
  const ev = evOk(obs, side, ask, HA_FLIP_ID);
  if (!ev) return null;
  return result(
    HA_FLIP_ID,
    "HA Flip",
    side,
    ask,
    ev.netEV,
    `HA_FLIP ${side.toUpperCase()} @ ${ask}c 1m color+EMA8/21 cross, 5m agrees`,
    "PATH_RIDE: sell green or ≥3¢ adverse on HA flip; TP 1.5×/2× cap 85",
  );
}

function ticketWaveBounce(obs: StrategyObservation, side: "yes" | "no", ha: HaPair): boolean {
  const lagOk = obs.lagStale === false
    && lagAgreesWithSide(side, obs.lagDollars ?? null);
  const paint = lastColor(ha.ha1m) === (side === "yes" ? "green" : "red");
  return lagOk || paint;
}

export function evaluateTicketWave(obs: StrategyObservation): StrategyResult | null {
  if (!is15m(obs)) return null;
  if (obs.openStrategyId) return null;
  if (!midWindow(obs.secsRemaining)) return null;
  const ha = requireHa(obs);
  if (!ha) return null;
  if (isStrikePin({ ohlc1m: obs.ohlc1m, floor: obs.floorStrike, ha1m: ha.ha1m, ha5m: ha.ha5m, haOk: true })) return null;

  const candidates: { side: "yes" | "no"; ask: number }[] = [];
  for (const side of ["yes", "no"] as const) {
    const ask = askOf(side, obs);
    if (typeof ask !== "number" || !Number.isFinite(ask)) continue;
    if (ask < TICKET_WAVE_ASK_MIN || ask > TICKET_WAVE_ASK_MAX) continue;
    if (!ticketWaveBounce(obs, side, ha)) continue;
    candidates.push({ side, ask });
  }
  if (candidates.length === 0) return null;
  candidates.sort((a, b) => a.ask - b.ask);
  const pick = candidates[0]!;
  const ev = evOk(obs, pick.side, pick.ask, TICKET_WAVE_ID);
  if (!ev) return null;
  return result(
    TICKET_WAVE_ID,
    "Ticket Wave",
    pick.side,
    pick.ask,
    ev.netEV,
    `TICKET_WAVE ${pick.side.toUpperCase()} @ ${pick.ask}c bounce lag|HA paint`,
    "PATH_RIDE: +8..+20¢ or 90s. Never HOLD_SETTLE.",
  );
}

export function evaluateNoCross(obs: StrategyObservation): StrategyResult | null {
  if (!is15m(obs)) return null;
  if (obs.openStrategyId) return null; // only if flat
  if (!Number.isFinite(obs.secsRemaining) || obs.secsRemaining > NO_CROSS_LAST_SECS) return null;
  if (obs.secsRemaining <= 0) return null;
  const ha = requireHa(obs);
  if (!ha) return null;
  const c1 = lastColor(ha.ha1m);
  const c5 = lastColor(ha.ha5m);
  if (!c1 || !c5 || c1 !== c5) return null;
  const remainingVol = remainingVolDollars(obs.ohlc1m ?? null, obs.secsRemaining);
  if (remainingVol == null) return null; // vol not honest
  if (huggingStrike({ spot: obs.currentPrice, floor: obs.floorStrike, remainingVol })) return null;
  if (!distanceIsFat({
    spot: obs.currentPrice,
    floor: obs.floorStrike,
    secsRemaining: obs.secsRemaining,
    remainingVol,
  })) return null;
  const side = sideForColor(c1);
  const ask = askOf(side, obs);
  if (typeof ask !== "number" || !Number.isFinite(ask)) return null;
  const ev = evOk(obs, side, ask, NO_CROSS_ID);
  if (!ev) return null;
  return result(
    NO_CROSS_ID,
    "No Cross",
    side,
    ask,
    ev.netEV,
    `NO_CROSS ${side.toUpperCase()} @ ${ask}c last-90s HA agree fat distance`,
    "Hold to settle. Skip mixed HA or hugging strike.",
  );
}

export const HA_15M_ENTRY_PREFERENCE = [
  HA_RIVER_ID,
  HA_FLIP_ID,
  TICKET_WAVE_ID,
  NO_CROSS_ID,
] as const;

export function preferHa15mResults<T extends { strategyId: string }>(results: T[]): T[] {
  const fired = HA_15M_ENTRY_PREFERENCE.filter((id) => results.some((r) => r.strategyId === id));
  if (fired.length <= 1) return results;
  const keep = fired[0];
  return results.filter((r) => !HA_15M_ENTRY_PREFERENCE.includes(r.strategyId as typeof keep) || r.strategyId === keep);
}

