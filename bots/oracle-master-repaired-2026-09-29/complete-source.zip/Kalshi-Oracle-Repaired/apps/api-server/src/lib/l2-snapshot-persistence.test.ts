import assert from "node:assert/strict";
import test from "node:test";
import {
  L2_PERSIST_FAILURE_THRESHOLD,
  L2SnapshotPersistence,
  type L2SnapshotRow,
} from "./l2-snapshot-persistence.js";

const snapshot = (ticker: string): L2SnapshotRow => ({
  ticker,
  yesBids: "[[52,1.5]]",
  yesAsks: "[[55,2.25]]",
  bestYesBid: 52,
  bestYesAsk: 55,
  spread: 3,
  midPrice: 54,
  bidDepth5: 1.5,
  askDepth5: 2.25,
});

test("L2 persistence retains failed batches, raises an incident after sustained failures, and recovers cleanly", async () => {
  let attempts = 0;
  let openedReason: string | null = null;
  let closed = 0;
  const written: L2SnapshotRow[][] = [];
  const persistence = new L2SnapshotPersistence({
    async insert(rows) {
      attempts += 1;
      if (attempts <= L2_PERSIST_FAILURE_THRESHOLD) throw new Error("invalid input syntax for type integer");
      written.push(rows);
    },
    async enterDegraded(reason) { openedReason = reason; },
    async exitDegraded() { closed += 1; },
  });

  for (let i = 0; i < 3; i += 1) persistence.enqueue(snapshot(`KXBTC-${i}`));

  for (let i = 0; i < L2_PERSIST_FAILURE_THRESHOLD; i += 1) {
    assert.equal(await persistence.flushIfReady(), false);
  }

  assert.equal(persistence.getStatus().pendingSnapshots, 3, "failed observations must remain queued");
  assert.equal(persistence.getStatus().consecutiveFailures, L2_PERSIST_FAILURE_THRESHOLD);
  assert.equal(persistence.getStatus().degraded, true);
  assert.match(openedReason ?? "", /L2 snapshot insert failed 3 consecutive times/);

  assert.equal(await persistence.flushIfReady(), true);
  assert.deepEqual(written[0].map(row => row.ticker), ["KXBTC-0", "KXBTC-1", "KXBTC-2"], "retry must preserve FIFO history");
  assert.deepEqual(persistence.getStatus(), {
    pendingSnapshots: 0,
    consecutiveFailures: 0,
    degraded: false,
  });
  assert.equal(closed, 1, "a successful retry must close the persistence incident");
});