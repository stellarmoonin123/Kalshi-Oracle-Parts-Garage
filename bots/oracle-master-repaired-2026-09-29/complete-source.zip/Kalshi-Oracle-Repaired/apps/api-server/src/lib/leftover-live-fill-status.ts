/**
 * Leftover live Kalshi fill-status poll. Paper fills never call it.
 * leftoverLiveFillStatusMayRun is leftoverLiveOrderMayRun. Does not ENABLE.
 */
import { leftoverLiveOrderMayRun, leftoverLiveOrderRun } from "./leftover-live-order.js";

export const LEFTOVER_LIVE_FILL_STATUS_LOADED = true as const;

export const LEFTOVER_LIVE_FILL_STATUS_HOST_GUARD =
  "leftoverLivePollOrderFillStatus.call";

export const FROZEN_LIVE_FILL_STATUS_MARKERS = [
  "kalshiOrderStatusPath(orderId)",
  "executed-without-count",
  "Partial entry",
  "remainder cancellation outcome is unknown",
] as const;

export function leftoverIsTerminalEntryOrderStatus(status: string): boolean {
  return status === "executed" || status === "canceled" || status === "cancelled" || status === "rejected";
}

export function leftoverResolveEntryFillOutcome(
  filledCount: number,
  requestedContracts: number,
): { action: "unfilled" | "partial" | "full"; filled: number; remainingContracts: number } {
  const requested = Math.max(0, Math.floor(requestedContracts));
  const filled = Math.max(0, Math.min(Math.floor(filledCount), requested));
  const remainingContracts = requested - filled;
  if (filled <= 0) return { action: "unfilled", filled: 0, remainingContracts };
  if (remainingContracts > 0) return { action: "partial", filled, remainingContracts };
  return { action: "full", filled, remainingContracts: 0 };
}

export function leftoverLiveFillStatusMayRun(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverLiveOrderMayRun(cfg);
}

export function leftoverLiveFillStatusHostDenied(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverLiveFillStatusMayRun(cfg) === false;
}

export function leftoverLiveFillStatusRun(
  cfg: { paperMode?: boolean; frozenCcMode?: boolean },
  run: () => Promise<void>,
): Promise<void> {
  if (!leftoverLiveFillStatusMayRun(cfg)) return Promise.resolve();
  return leftoverLiveOrderRun(cfg, run).then(() => undefined);
}
