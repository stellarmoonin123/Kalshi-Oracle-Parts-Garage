/**
 * Regression tests for the scheduled fresh accuracy health monitor.
 *
 * This module is deliberately dependency-free, so these checks do not start
 * the bot singleton or make network calls while exercising outage behavior.
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import {
  ACCURACY_UNAVAILABLE,
  AccuracyFetchFailureTracker,
  runFreshAccuracyWithRetry,
} from "./accuracy-fetch-health.js";

test("scheduled fresh accuracy failures retry once and become unhealthy only after two failed cycles", async () => {
  const tracker = new AccuracyFetchFailureTracker();
  let attempts = 0;
  let retries = 0;
  const failFreshAttempt = async () => {
    attempts++;
    return ACCURACY_UNAVAILABLE;
  };

  const firstResult = await runFreshAccuracyWithRetry(
    failFreshAttempt,
    async () => { retries++; },
  );
  tracker.recordScheduledFreshResult(firstResult);

  assert.equal(firstResult, ACCURACY_UNAVAILABLE);
  assert.equal(attempts, 2, "a failed fresh measurement should be retried exactly once");
  assert.equal(retries, 1);
  assert.deepEqual(tracker.getHealth(), {
    consecutiveFailures: 1,
    accuracyFetchFailing: false,
  });

  const secondResult = await runFreshAccuracyWithRetry(
    failFreshAttempt,
    async () => { retries++; },
  );
  tracker.recordScheduledFreshResult(secondResult);

  assert.equal(attempts, 4, "the second failed cycle should also make two fresh attempts");
  assert.equal(retries, 2);
  assert.deepEqual(tracker.getHealth(), {
    consecutiveFailures: 2,
    accuracyFetchFailing: true,
  });
});

test("cached or manual accuracy calculations cannot clear a fresh-feed outage", async () => {
  const tracker = new AccuracyFetchFailureTracker();
  tracker.recordScheduledFreshResult(ACCURACY_UNAVAILABLE);
  tracker.recordScheduledFreshResult(ACCURACY_UNAVAILABLE);

  // This mirrors a successful cached snapshot/manual calculation: it may
  // produce a valid number, but it does not call recordScheduledFreshResult.
  const cachedAccuracy = await runFreshAccuracyWithRetry(
    async () => 67,
    async () => assert.fail("a successful cached calculation should not retry"),
  );

  assert.equal(cachedAccuracy, 67);
  assert.deepEqual(tracker.getHealth(), {
    consecutiveFailures: 2,
    accuracyFetchFailing: true,
  });
});

test("a subsequent successful scheduled fresh measurement clears the outage", () => {
  const tracker = new AccuracyFetchFailureTracker();
  tracker.recordScheduledFreshResult(ACCURACY_UNAVAILABLE);
  tracker.recordScheduledFreshResult(ACCURACY_UNAVAILABLE);
  tracker.recordScheduledFreshResult(61);

  assert.deepEqual(tracker.getHealth(), {
    consecutiveFailures: 0,
    accuracyFetchFailing: false,
  });
});