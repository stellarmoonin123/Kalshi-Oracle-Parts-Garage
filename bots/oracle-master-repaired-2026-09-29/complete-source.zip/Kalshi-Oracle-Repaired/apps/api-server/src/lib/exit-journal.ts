/**
 * Exit journal store — durable exit volume ledger for live Kalshi closes.
 * Paper/frozen leftoverLiveOrderMayRun deny never touches this.
 * Does not ENABLE or cut floors.
 */
export type ExitJournalState = {
  version: number;
  key: string;
  ticker: string;
  side: "yes" | "no";
  originalContracts: number;
  entryPriceCents: number;
  soldContracts: number;
  proceedsCents: number;
  exitFeeCents: number;
  completedOrderIds: string[];
  pending?: boolean;
};

const mem = new Map<string, ExitJournalState>();

export function exitJournalKey(accountNs: string, paper: boolean, dbId: number): string {
  return `${accountNs}:${paper ? "paper" : "live"}:exit:${dbId}`;
}

export function configuredExitJournalStore(): {
  load: (key: string) => ExitJournalState | null;
  save: (state: ExitJournalState) => void;
} {
  return {
    load: (key) => mem.get(key) ?? null,
    save: (state) => { mem.set(state.key, { ...state }); },
  };
}
