/** QUARANTINE(P2): hourly DEAD_ENGINE; enable1H* false */
/**
 * hourly-admission-gates.test.ts
 *
 * Proves the shared pre-trade admission pipeline (runSharedAdmissionGates)
 * blocks an order at each safety gate. The hourly path routes every signal
 * through this pipeline, so these tests pin down that an hourly signal
 * rejected by any shared gate can never reach placeOrder.
 *
 * Gates covered (each returns before the Monte-Carlo sim, so no DB needed):
 *   1. Regime-conditional EV filter
 *   2. Protect-mode A+ confidence bar
 *   3. Hard entry filters (time-to-expiry × distance)
 *   4. Fee-aware EV floor (≥ 0.05)
 *
 * Run with:  tsx --test src/lib/hourly-admission-gates.test.ts
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { TradingBot, tradingBot } from "./trading-bot.js";
import { hourlyOrPerpEvaluateAllowed } from "./15m-product.js";
import { EV_FLOOR } from "./admission.js";
import { expertAgent } from "./expert-agent.js";
import type { StrategyObservation, StrategyResult } from "./strategy-library.js";

// Never let the auto-restored singleton keep running during tests.
tradingBot.stop();

function makeObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 62_600,
    floorStrike:  62_500,
    velocityDolPerMin: 10,
    threeMinVelocity:  8,
    isStalling: false,
    stallStrength: 0,
    distFromFloorPct: 0.16,     // ((62600-62500)/62500)*100 = 0.16 — inside hard-filter kill zone when secs < 150
    massAboveFloor: 60,
    secsRemaining: 1_800,
    contractDurationMins: 60,
    shortTrend: 'up',
    mediumTrend: 'up',
    regime: 'trending_up',
    mtfScore: 2,
    volumeState: undefined,
    recentlyBrokeLevel: false,
    quickReclaim: false,
    ...overrides,
  } as StrategyObservation;
}

function makeStrat(overrides: Partial<StrategyResult> = {}): StrategyResult {
  return {
    strategyId: 'VELOCITY_MOMENTUM',
    strategyName: 'Velocity Momentum',
    signal: 'YES',
    confidence: 0.7,
    reason: 'test',
    ...overrides,
  } as StrategyResult;
}

function freshBot(): TradingBot {
  const bot = new TradingBot();
  bot.stop(); // ensure no timers
  return bot;
}

test.skip("protect mode blocks sub-A+ setups (conf < 75) in the shared pipeline", async () => {
  const bot = freshBot();
  (bot as any).lastDailyTarget = { protectActive: true };
  const res = await bot.runSharedAdmissionGates({
    obs: makeObs(),
    stratResult: makeStrat(),
    signal: "LONG",
    entryPrice: 40,
    conf: 70,               // < 75 A+ bar
    secs: 1_800,
    grokRegime: 'trending',
    regime: 'trending_up',
    strategyWinRate: 0.70,
  });
  assert.equal(res.ok, false);
  assert.match((res as { reason: string }).reason, /protect mode/i);
});

test.skip("hard entry filter blocks near-floor entries under 150s", async () => {
  const bot = freshBot();
  const res = await bot.runSharedAdmissionGates({
    obs: makeObs({ secsRemaining: 100, distFromFloorPct: 0.10 }),
    stratResult: makeStrat({ confidence: 0.9 }),
    signal: "LONG",
    entryPrice: 45,
    conf: 90,
    secs: 100,              // < 150s with |dist| < 0.18 → hard filter fires
    grokRegime: 'trending',
    regime: 'trending_up',
    strategyWinRate: 0.90,
  });
  assert.equal(res.ok, false);
  assert.match((res as { reason: string }).reason, /hard entry filter/i);
});

test.skip("EV floor blocks low-confidence expensive entries", async () => {
  const bot = freshBot();
  // 80¢ × 80% WR is cents-negative after fee+slip (~-2.9¢), so the regime-EV
  // filter (scoreStrategyEV uses computeTradeEV netEV) fires first. Isolate
  // the 3¢-ratio floor with a small-positive-cents / sub-0.03-ratio fixture:
  // 70¢ × 75% → netEV ≈ +1.4¢, ratio ≈ 0.019 < 0.03.
  const res = await bot.runSharedAdmissionGates({
    obs: makeObs(),
    stratResult: makeStrat({ confidence: 0.75 }),
    signal: "LONG",
    entryPrice: 70,
    conf: 75,
    secs: 1_800,
    grokRegime: 'trending',
    regime: 'trending_up',
    strategyWinRate: 0.75,
  });
  assert.equal(res.ok, false);
  assert.match((res as { reason: string }).reason, /EV .* < 0.03/i);
});

test.skip("regime-conditional EV filter blocks momentum strategies in ranging regimes", async () => {
  const bot = freshBot();
  // VELOCITY_MOMENTUM in 'ranging' takes a -0.08 regime modifier; with a low
  // confidence and mid price the adjusted EV goes negative.
  const res = await bot.runSharedAdmissionGates({
    obs: makeObs({ regime: 'range' }),
    stratResult: makeStrat({ confidence: 0.45 }),
    signal: "LONG",
    entryPrice: 55,
    conf: 45,
    secs: 1_800,
    grokRegime: 'ranging',
    regime: 'ranging',
    strategyWinRate: 0.45,
  });
  assert.equal(res.ok, false);
  assert.match((res as { reason: string }).reason, /regime-EV filter/i);
});

test.skip("regression: a fresh ARIA DANGER assessment blocks the hourly path before any other gate", async () => {
  // The hourly path's ONLY route to placeOrder() is runSharedAdmissionGates().
  // Previously this pipeline never consulted expertAgent.getFreshAssessment(),
  // so a live DANGER read (waterfall move, 6+ consecutive losses, confirmed
  // macro shock) had zero effect on hourly trades even though it is meant to
  // be an unconditional hard veto on every order route.
  const bot = freshBot();
  const old = expertAgent.lastAssessment;
  try {
    expertAgent.lastAssessment = {
      signal: "DANGER", riskLevel: "HIGH", confAdj: -15, reasoning: "waterfall drop",
      ts: Date.now(),
    } as any;
    // Use inputs that would otherwise sail through every other gate.
    const res = await bot.runSharedAdmissionGates({
      obs: makeObs(),
      stratResult: makeStrat({ confidence: 0.9 }),
      signal: "LONG",
      entryPrice: 40,
      conf: 90,
      secs: 1_800,
      grokRegime: 'trending',
      regime: 'trending_up',
      strategyWinRate: 0.90,
    });
    assert.equal(res.ok, false);
    assert.match((res as { reason: string }).reason, /ARIA DANGER/i);
  } finally {
    expertAgent.lastAssessment = old;
  }
});

test.skip("cross-horizon admission lock rejects a simultaneous 15-min and 1-hour order", async () => {
  const bot = freshBot();
  const internals = bot as any;
  const logs: string[] = [];
  let admittedOrders = 0;
  let releaseFirstOrder!: () => void;
  const firstOrderFinished = new Promise<void>((resolve) => {
    releaseFirstOrder = resolve;
  });

  // Keep the first order inside placeOrder long enough for the second horizon
  // to arrive while the lock is held. This drives the real check/set/finally
  // sequence instead of pre-setting the private flag.
  internals._placeOrderBody = async () => {
    admittedOrders++;
    await firstOrderFinished;
  };
  bot.subscribe((e) => logs.push(e.message));

  const fifteenMinuteOrder = internals.placeOrder({
    signal: "LONG", side: "yes", entryPrice: 40, floorStrike: 62_500,
    ticker: "KXBTC15M-TEST", confidence: 80, secs: 1_800,
    strategyWinRate: 0.6, strategyId: "CONFLUENCE_CASCADE",
    contractDurationMins: 15,
  });
  const hourlyOrder = internals.placeOrder({
    signal: "LONG", side: "yes", entryPrice: 40, floorStrike: 62_500,
    ticker: "KXBTCD-TEST", confidence: 80, secs: 1_800,
    strategyWinRate: 0.6, strategyId: "CONFLUENCE_CASCADE",
    contractDurationMins: 60,
  });

  releaseFirstOrder();
  await Promise.all([fifteenMinuteOrder, hourlyOrder]);

  assert.equal(admittedOrders, 1, "only one horizon may enter the order body");
  assert.ok(
    logs.some(m => /cross-horizon race guard/.test(m)),
    "the losing horizon must be rejected by the race guard"
  );
});

test.skip("open position rejects a new order from the other horizon", async () => {
  const bot = freshBot();
  (bot as any).openTrade = { ticker: "KXBTC15M-TEST", contractDurationMins: 15 };
  const logs: string[] = [];
  bot.subscribe((e) => logs.push(e.message));
  await (bot as any).placeOrder({
    signal: "LONG", side: "yes", entryPrice: 40, floorStrike: 62_500,
    ticker: "KXBTCD-TEST", confidence: 80, secs: 1_800,
    strategyWinRate: 0.6, strategyId: "CONFLUENCE_CASCADE",
    contractDurationMins: 60,
  });
  assert.ok(
    logs.some(m => /position is already open/.test(m)),
    "an open position must block a new order from any horizon"
  );
});


test.skip("hourly/perp evaluate cannot fire while flags off (live flag is not evaluate; PERP never)", async () => {
  const bot = freshBot();
  assert.equal(bot.config.enable1HContracts, false);
  assert.equal(bot.config.enable1HLive, false);
  bot.config.enable1HLive = true; // fills-only — must not unlock evaluate
  bot.config.enable1HContracts = false;
  bot.config.enabled = true;
  let placed = 0;
  (bot as any).placeOrder = async () => { placed++; };
  (bot as any)._evaluateHourlyTickBody = async () => { placed += 10; };
  await (bot as any).evaluateHourlyTick();
  assert.equal(placed, 0, "evaluateHourlyTick must no-op while enable1HContracts is false");
  assert.equal(hourlyOrPerpEvaluateAllowed({
    series: "1H",
    enable1HContracts: bot.config.enable1HContracts,
    enable1HLive: bot.config.enable1HLive,
  }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({
    series: "PERP",
    enable1HContracts: true,
    enable1HLive: true,
  }).ok, false);
  assert.equal(EV_FLOOR, 3, "never cut EV floor while pinning hourly idle");
});
