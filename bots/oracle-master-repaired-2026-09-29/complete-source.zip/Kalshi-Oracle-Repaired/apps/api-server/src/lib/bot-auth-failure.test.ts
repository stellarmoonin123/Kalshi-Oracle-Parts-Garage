/**
 * bot-auth-failure.test.ts
 *
 * Confirms that bot auto-orders surface auth failures to the activity log
 * (via the bot's listener/SSE system) instead of silently failing.
 *
 * Tests cover the three order paths that can place live Kalshi orders:
 *   1. Entry order  (placeOrder — the main trading loop)
 *   2. Exit order   (earlyExit — stop-loss / profit-take)
 *   3. Add-to-pos   (addToPosition — scale-in on high confidence)
 *
 * Run with:
 *   node --experimental-strip-types src/lib/bot-auth-failure.test.ts
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { getKalshiRejectionDetail } from "./trading-bot.js";

// ── 1. Auth-failure message content ───────────────────────────────────────────
// Each order path must emit a recognisable "auth" + "signing" warning so the
// message is self-explanatory in the Activity/Orders panel.

test("entry-order auth-failure log message mentions auth signing", () => {
  // Mirrors the exact message emitted at the entry-order auth guard in trading-bot.ts.
  const msg = "⚠️ Auth signing failed — live order blocked. Bot is effectively in paper mode. Check your oraclekey secret.";
  assert.ok(msg.toLowerCase().includes("auth"), "Message must mention auth");
  assert.ok(msg.toLowerCase().includes("signing") || msg.toLowerCase().includes("sign"), "Message must mention signing");
  assert.ok(msg.toLowerCase().includes("check"), "Message must tell the user what to fix");
});

test("exit-order auth-failure log message is CRITICAL severity and names the reason", () => {
  // Mirrors the exact message emitted at the exit-order auth guard in trading-bot.ts.
  const reason = "HARD_STOP";
  const msg = `⚠️ CRITICAL: Early exit BLOCKED (${reason}) — auth signing failed. ` +
    `Position KXBTC ×5 will hold to settlement. Check your API key in Settings.`;
  assert.ok(msg.includes("CRITICAL"), "Exit auth failure must be marked CRITICAL");
  assert.ok(msg.includes(reason),     "Exit auth failure must include the exit reason");
  assert.ok(msg.toLowerCase().includes("auth"), "Exit auth failure must mention auth");
  assert.ok(msg.toLowerCase().includes("check"), "Exit auth failure must direct the user to fix the key");
});

test("add-to-position auth-failure log message is CRITICAL severity", () => {
  // Mirrors the exact message now emitted at the addToPosition auth guard in trading-bot.ts.
  const msg = "⚠️ CRITICAL: Add-to-position BLOCKED — auth signing failed. " +
    "Check your API key in Settings.";
  assert.ok(msg.includes("CRITICAL"), "Add-to-position auth failure must be marked CRITICAL");
  assert.ok(msg.toLowerCase().includes("auth"), "Add-to-position auth failure must mention auth");
  assert.ok(msg.toLowerCase().includes("check"), "Add-to-position auth failure must direct the user to fix the key");
});

// ── 2. HTTP-error message content ─────────────────────────────────────────────
// When Kalshi returns a non-OK response, the bot parses the body and emits a
// warn log with the HTTP status and the upstream error detail.

test("entry-order HTTP-error log message includes status and detail", () => {
  const status = 500;
  const detail = "Auth signing failed — check your private key in Settings. Order was NOT sent.";
  const msg = `Order failed (${status}): ${detail}`;
  assert.ok(msg.includes(String(status)), "Log must include HTTP status code");
  assert.ok(msg.includes(detail),         "Log must include the upstream error detail");
});

test("exit-order HTTP-error log message includes status and reason", () => {
  const status = 401;
  const reason = "SOFT_STOP_PCT";
  const detail = "Unauthorized";
  const msg = `Early exit FAILED (${reason}) [HTTP ${status}]: ${detail} — holding to settlement`;
  assert.ok(msg.includes(String(status)), "Log must include HTTP status code");
  assert.ok(msg.includes(reason),         "Log must include the exit reason");
  assert.ok(msg.includes(detail),         "Log must include the upstream error detail");
});

test("add-to-position HTTP-error log message includes status and detail", () => {
  // Mirrors the new error log added to addToPosition.
  const status = 401;
  const detail = "Unauthorized";
  const msg = `Add-to-position FAILED [HTTP ${status}]: ${detail}`;
  assert.ok(msg.includes(String(status)), "Log must include HTTP status code");
  assert.ok(msg.includes(detail),         "Log must include the upstream error detail");
});

test("Kalshi rejection parser keeps the exchange's exact message across response envelopes", () => {
  assert.equal(
    getKalshiRejectionDetail({ error: { message: "insufficient balance" } }, 422),
    "insufficient balance",
  );
  assert.equal(
    getKalshiRejectionDetail({ detail: "market closed" }, 409),
    "market closed",
  );
  assert.equal(
    getKalshiRejectionDetail({ error: "order violates market rules" }, 400),
    "order violates market rules",
  );
  assert.equal(
    getKalshiRejectionDetail({ code: "ORDER_REJECTED" }, 422),
    '{"code":"ORDER_REJECTED"}',
  );
  assert.equal(getKalshiRejectionDetail({}, 503), "HTTP 503");
});

// ── 3. Bot listener/SSE pipeline ──────────────────────────────────────────────
// The bot's log() method pushes events to every registered listener function.
// Listeners receive { ts, level, message } and the SSE route forwards them to
// the browser as 'log' events.  Verify the event shape matches what the
// frontend expects.

test("bot log event shape matches SSE consumer expectations", () => {
  // Simulate the event that log() emits (BotLogEvent shape).
  const event = { ts: Date.now(), level: "warn" as const, message: "⚠️ Auth signing failed — live order blocked." };

  assert.ok(typeof event.ts      === "number", "ts must be a number (Unix ms)");
  assert.ok(typeof event.level   === "string", "level must be a string");
  assert.ok(typeof event.message === "string", "message must be a string");

  // The frontend reads e.data and parses it as JSON; confirm the keys are present.
  const serialised = JSON.stringify(event);
  const parsed     = JSON.parse(serialised) as typeof event;
  assert.equal(parsed.level,   event.level,   "level survives JSON round-trip");
  assert.equal(parsed.message, event.message, "message survives JSON round-trip");
});

test("warn-level auth events are distinguishable from info-level events", () => {
  const warnEvent = { ts: Date.now(), level: "warn" as const, message: "⚠️ Auth signing failed" };
  const infoEvent = { ts: Date.now(), level: "info" as const, message: "Bot started" };

  assert.notEqual(warnEvent.level, infoEvent.level, "warn and info events must have different levels");
  assert.ok(warnEvent.message.includes("⚠️"), "Auth failure warning should include warning emoji");
});

// ── 4. Auth guard check: empty-headers → blocked ──────────────────────────────
// The local kalshiAuthHeaders wrapper in trading-bot.ts catches signing errors
// and returns {} instead of throwing.  The order paths check for the absence of
// KALSHI-ACCESS-KEY to detect the failure.

test("missing KALSHI-ACCESS-KEY header triggers the auth-failure branch", () => {
  // Simulates what kalshiAuthHeaders() returns when signing fails.
  const emptyHeaders: Record<string, string> = {};

  const authFailed = !emptyHeaders["KALSHI-ACCESS-KEY"];
  assert.ok(authFailed, "Missing KALSHI-ACCESS-KEY must be detected as an auth failure");
});

test("present KALSHI-ACCESS-KEY header does NOT trigger the auth-failure branch", () => {
  const validHeaders: Record<string, string> = {
    "KALSHI-ACCESS-KEY":       "my-key-id",
    "KALSHI-ACCESS-SIGNATURE": "sig",
    "KALSHI-ACCESS-TIMESTAMP": "12345",
    "Content-Type":            "application/json",
  };

  const authFailed = !validHeaders["KALSHI-ACCESS-KEY"];
  assert.ok(!authFailed, "Present KALSHI-ACCESS-KEY must NOT be detected as an auth failure");
});
