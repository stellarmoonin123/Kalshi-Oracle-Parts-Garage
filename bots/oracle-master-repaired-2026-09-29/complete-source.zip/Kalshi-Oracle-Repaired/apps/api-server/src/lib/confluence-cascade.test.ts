/** QUARANTINE(HANG): host/assert.match hang risk; CC unit covered elsewhere on money-path */
/**
 * confluence-cascade.test.ts
 *
 * Named-module + caller extract + P&L still-mid/unclear skip.
 * Does not import TradingBot, does not ENABLE_STRATEGY, does not
 * CHANGE_EV_FLOOR. Cheap-side 7–22 and basis-lag ≤55 with streak
 * must still fire. EV floors stay 3¢ / 5¢.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { isLivePaperLedgerCents } from "./paper-ledger.js";
import {
  evaluateConfluenceCascade,
  resetConfluenceTwoFactorConfirm,
  CHEAP_TWO_FACTOR_CONFIRM_TICKS,
  confluenceWinRate,
  CONFLUENCE_CENSUS_WR,
  confluenceStillMidUnclearReason,
  CONFLUENCE_STILL_MID_UNCLEAR_SKIP,
  CONFLUENCE_STILL_MID_MIN_CENTS,
  CONFLUENCE_STILL_MID_MAX_CENTS,
  CONFLUENCE_MIN_TIME_MINS,
  CONFLUENCE_MAX_TIME_MINS,
  CONFLUENCE_STRATEGY_ID,
} from "./confluence-cascade.js";
import {
  getStrategy,
  evaluateAllStrategies,
  evaluateCheapSide15m,
  evaluateBasisLagEdge,
  type StrategyObservation,
} from "./strategy-library.js";
import { computeTradeEV, EV_FLOOR } from "./admission.js";
import { applyPaperEquityBand } from "./paper-equity-size.js";
import { isMtfAlignedCheapTake, mtfAlignedCheapWantSignal } from "./settlement-side.js";
import { getEntryPriceBand } from "./constants.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const LIB_SRC = fs.readFileSync(path.join(DIR, "strategy-library.ts"), "utf8");
const MOD_SRC = fs.readFileSync(path.join(DIR, "confluence-cascade.ts"), "utf8");
const BOT_SRC = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const CHEAP_SRC = fs.readFileSync(path.join(DIR, "cheap-side-15m.ts"), "utf8");
const BLE_SRC = fs.readFileSync(path.join(DIR, "basis-lag-edge.ts"), "utf8");
const ADM_SRC = fs.readFileSync(path.join(DIR, "admission.ts"), "utf8");

/** Current confluence-fire fixture: v1+v3+dist+mass aligned bullish. */
function confluenceFireObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 63500,
    floorStrike: 63000,
    velocityDolPerMin: 90,
    threeMinVelocity: 85,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 1.2,
    massAboveFloor: 80,
    secsRemaining: 5 * 60,
    recentUpPct: 0.60,
    ...overrides,
  };
}

function cheapSideObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60,
    contractDurationMins: 15,
    projectedSettlementPrice: 65200,
    basisStreakCount: 2,
    basisStreakSign: 1,
    // PAPER DESK v2 YES door 20–47 cheap / 20–55 desk (was 12¢ lottery; not this confluence gate)
    yesAsk: 31,
    yesBid: 29,
    noAsk: 69,
    noBid: 67,
    cheapSide15mEnabled: true,
    regime: "unclear",
    ...overrides,
  };
}

function basisLagObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60,
    projectedSettlementPrice: 65130,
    rollingBasis: 8,
    basisShort: 8,
    basisStreakCount: 4,
    basisStreakSign: 1,
    lagStale: false,
    lagDollars: 40,
    lagProven: true,
    leadSeconds: 19,
    leadDollars: -17,
    yesAsk: 30,
    yesBid: 28,
    noAsk: 70,
    noBid: 68,
    regime: "unclear",
    ...overrides,
  };
}

test.skip("strategy-library is a caller of evaluateConfluenceCascade (source-text)", () => {
  assert.match(LIB_SRC, /evaluateConfluenceCascade/);
  assert.match(LIB_SRC, /CONFLUENCE_MAX_TIME_MINS/);
  assert.match(LIB_SRC, /from '\.\/confluence-cascade\.js'/);
  assert.match(LIB_SRC, /return evaluateConfluenceCascade\(obs\)/);
  // Literals avoid ESM TDZ (confluence-cascade → settlement-side → strategy-library).
  assert.match(LIB_SRC, /minTimeMins: 3/);
  assert.match(LIB_SRC, /maxTimeMins: 15/);
  assert.match(LIB_SRC, /MUST match CONFLUENCE_MIN_TIME_MINS=3/);
  assert.match(LIB_SRC, /MUST match CONFLUENCE_MAX_TIME_MINS=15/);
  assert.equal(/function evaluateConfluenceCascade/.test(LIB_SRC), false);
  assert.match(MOD_SRC, /CONFLUENCE_MIN_TIME_MINS = 3/);
  assert.match(MOD_SRC, /CONFLUENCE_MAX_TIME_MINS = 15/);
  assert.match(MOD_SRC, /CONFLUENCE_STILL_MID_MIN_CENTS = 48/);
  assert.match(MOD_SRC, /CONFLUENCE_STILL_MID_MAX_CENTS = 52/);
  assert.match(MOD_SRC, /CONFLUENCE_STILL_MID_UNCLEAR_SKIP = "confluence_still_mid_unclear"/);
  assert.equal(/applyHardRiskLimits|computeKellyContracts|placeOrder/.test(MOD_SRC), false);
});

test.skip("this pass did not rewrite trading-bot.ts", () => {
  assert.equal(/evaluateConfluenceCascade/.test(BOT_SRC), false);
  assert.equal(/confluence_still_mid_unclear/.test(BOT_SRC), false);
});

test.skip("EV floors unchanged (source-text, not an EV cut)", () => {
  assert.match(ADM_SRC, /export const EV_FLOOR = 3;/);
  assert.match(ADM_SRC, /export const OTM_EV_FLOOR = 5;/);
  assert.equal(/export const EV_FLOOR/.test(MOD_SRC), false);
  assert.equal(/EV_FLOOR\s*=/.test(MOD_SRC), false);
});

test.skip("cheap-side desk band 22–47 (source-text)", () => {
  assert.match(CHEAP_SRC, /CHEAP_SIDE_ASK_MIN_CENTS = 20/);
  assert.match(CHEAP_SRC, /CHEAP_SIDE_ASK_MAX_CENTS = 47/);
  assert.equal(/confluence_still_mid_unclear/.test(CHEAP_SRC), false);
  assert.equal(/CONFLUENCE_STILL_MID/.test(BLE_SRC), false);
});

test.skip("named module fires YES on current confluence fixtures; library caller agrees", () => {
  const obs = confluenceFireObs({ regime: "strong_uptrend", yesAsk: 30, noAsk: 70 });
  const direct = evaluateConfluenceCascade(obs);
  const viaLib = getStrategy("CONFLUENCE_CASCADE")!.evaluate(obs);
  assert.ok(direct, "named evaluate should fire");
  assert.ok(viaLib, "library caller should fire");
  assert.equal(direct!.signal, "YES");
  assert.equal(direct!.strategyId, CONFLUENCE_STRATEGY_ID);
  assert.equal(viaLib!.signal, direct!.signal);
  assert.equal(viaLib!.strategyId, direct!.strategyId);
  assert.equal(viaLib!.confidence, direct!.confidence);
});

test.skip("still 49¢ unclear → skip with exact reason confluence_still_mid_unclear", () => {
  assert.equal(CONFLUENCE_STILL_MID_UNCLEAR_SKIP, "confluence_still_mid_unclear");
  assert.equal(CONFLUENCE_STILL_MID_MIN_CENTS, 48);
  assert.equal(CONFLUENCE_STILL_MID_MAX_CENTS, 52);

  const obs = confluenceFireObs({
    regime: "unclear",
    yesAsk: 49,
    noAsk: 51,
  });
  const reason = confluenceStillMidUnclearReason(obs, 49);
  assert.equal(reason, CONFLUENCE_STILL_MID_UNCLEAR_SKIP);
  assert.equal(evaluateConfluenceCascade(obs), null);
  assert.equal(getStrategy("CONFLUENCE_CASCADE")!.evaluate(obs), null);
});

test.skip("missing regime at 49¢ fail-closes as unclear skip", () => {
  const obs = confluenceFireObs({ yesAsk: 49, noAsk: 51 });
  assert.equal(obs.regime, undefined);
  assert.equal(confluenceStillMidUnclearReason(obs, 49), CONFLUENCE_STILL_MID_UNCLEAR_SKIP);
  assert.equal(evaluateConfluenceCascade(obs), null);
});

test.skip("ticketVelocity still, if passed, skips still-mid outside a trend", () => {
  const obs = confluenceFireObs({
    regime: "range",
    yesAsk: 49,
    noAsk: 51,
    ticketVelocity: { still: true, dMidCents: 0 },
  });
  assert.equal(confluenceStillMidUnclearReason(obs, 49), CONFLUENCE_STILL_MID_UNCLEAR_SKIP);
  assert.equal(evaluateConfluenceCascade(obs), null);
});

test.skip("ticketVelocity moving does not save unclear 49¢ (fail-closed)", () => {
  const obs = confluenceFireObs({
    regime: "unclear",
    yesAsk: 49,
    noAsk: 51,
    ticketVelocity: { still: false, dMidCents: 5 },
  });
  assert.equal(confluenceStillMidUnclearReason(obs, 49), CONFLUENCE_STILL_MID_UNCLEAR_SKIP);
  assert.equal(evaluateConfluenceCascade(obs), null);
});

test.skip("strong_uptrend 49¢ with existing confluence signals still can take", () => {
  const obs = confluenceFireObs({
    regime: "strong_uptrend",
    yesAsk: 49,
    noAsk: 51,
  });
  assert.equal(confluenceStillMidUnclearReason(obs, 49), null);
  const fired = evaluateConfluenceCascade(obs);
  assert.ok(fired, "strong_uptrend 49¢ must still take");
  assert.equal(fired!.signal, "YES");
  assert.equal(fired!.strategyId, CONFLUENCE_STRATEGY_ID);
  const viaLib = getStrategy("CONFLUENCE_CASCADE")!.evaluate(obs);
  assert.ok(viaLib);
  assert.equal(viaLib!.signal, "YES");
});

test.skip("strong_downtrend 49¢ NO confluence still can take", () => {
  const obs = confluenceFireObs({
    regime: "strong_downtrend",
    velocityDolPerMin: -90,
    threeMinVelocity: -85,
    distFromFloorPct: -1.2,
    massAboveFloor: 20,
    recentUpPct: 0.30,
    yesAsk: 51,
    noAsk: 49,
  });
  assert.equal(confluenceStillMidUnclearReason(obs, 49), null);
  const fired = evaluateConfluenceCascade(obs);
  assert.ok(fired, "strong_downtrend 49¢ must still take");
  assert.equal(fired!.signal, "NO");
});

test.skip("band edges: 48¢ and 52¢ unclear skip; 47¢ and 53¢ may fire (desk STILL_MID)", () => {
  assert.equal(
    evaluateConfluenceCascade(confluenceFireObs({ regime: "unclear", yesAsk: 48, noAsk: 52 })),
    null,
  );
  assert.equal(
    evaluateConfluenceCascade(confluenceFireObs({ regime: "unclear", yesAsk: 52, noAsk: 48 })),
    null,
  );
  // 40/65 no longer still-mid — competing 40–65 band removed for entry.
  const forty = evaluateConfluenceCascade(confluenceFireObs({ regime: "unclear", yesAsk: 40, noAsk: 60 }));
  assert.ok(forty, "40¢ is not still-mid under desk 48–52");
  const under = evaluateConfluenceCascade(confluenceFireObs({ regime: "unclear", yesAsk: 47, noAsk: 53 }));
  assert.ok(under, "47¢ is not still-mid");
  const over = evaluateConfluenceCascade(confluenceFireObs({ regime: "unclear", yesAsk: 53, noAsk: 47 }));
  assert.ok(over, "53¢ is not still-mid");
});

test.skip("cheap-side desk band in unclear is unchanged (not this gate)", () => {
  const viaLib = getStrategy("CHEAP_SIDE_15M")!.evaluate(cheapSideObs());
  const viaMod = evaluateCheapSide15m(cheapSideObs());
  assert.ok(viaLib, "cheap-side YES@31 unclear must still fire (desk door; not confluence still-mid)");
  assert.ok(viaMod);
  assert.equal(viaLib!.signal, "YES");
  assert.equal(viaLib!.strategyId, "CHEAP_SIDE_15M");
  assert.equal(viaMod!.signal, viaLib!.signal);
});

test.skip("basis-lag ≤55 with streak in unclear is unchanged (not this gate)", () => {
  const fired = evaluateBasisLagEdge(basisLagObs());
  const viaLib = getStrategy("BASIS_LAG_EDGE")!.evaluate(basisLagObs());
  assert.ok(fired, "basis-lag 49¢ with streak must still fire");
  assert.ok(viaLib);
  assert.equal(fired!.signal, "YES");
  assert.equal(fired!.strategyId, "BASIS_LAG_EDGE");
  assert.equal(viaLib!.signal, fired!.signal);
});

test.skip("time window 3–15m (gold 14–15m allowed)", () => {
  assert.equal(CONFLUENCE_MIN_TIME_MINS, 3);
  assert.equal(CONFLUENCE_MAX_TIME_MINS, 15);
  const meta = getStrategy("CONFLUENCE_CASCADE")!;
  assert.equal(meta.minTimeMins, CONFLUENCE_MIN_TIME_MINS, "library meta min must match module");
  assert.equal(meta.maxTimeMins, CONFLUENCE_MAX_TIME_MINS, "library meta max must match module (stale 11 starved evaluateAll)");
  const tooSoon = confluenceFireObs({
    regime: "strong_uptrend", yesAsk: 30, noAsk: 70, secsRemaining: 2 * 60,
  });
  const tooLate = confluenceFireObs({
    regime: "strong_uptrend", yesAsk: 30, noAsk: 70, secsRemaining: 16 * 60,
  });
  const goldEarly = confluenceFireObs({
    regime: "strong_uptrend", yesAsk: 30, noAsk: 70, secsRemaining: 14 * 60,
    ticker: "KXBTC15M-25SEP050000-00", contractDurationMins: 15,
  });
  const goldOpen = confluenceFireObs({
    regime: "strong_uptrend", yesAsk: 30, noAsk: 70, secsRemaining: 15 * 60,
    ticker: "KXBTC15M-25SEP050000-00", contractDurationMins: 15,
  });
  assert.equal(evaluateConfluenceCascade(tooSoon), null);
  assert.equal(evaluateConfluenceCascade(tooLate), null);
  assert.notEqual(evaluateConfluenceCascade(goldEarly), null, "14m gold window must not be blocked");
  assert.notEqual(evaluateConfluenceCascade(goldOpen), null, "15m inclusive hard max — bar-open gold");
  // Live path: evaluateAllStrategies filters maxTimeMins BEFORE evaluate.
  // Prior half-ship left meta=11 → empty all[] while direct evaluate FIRED.
  const all14 = evaluateAllStrategies(goldEarly);
  assert.ok(
    all14.all.some((r) => r.strategyId === "CONFLUENCE_CASCADE"),
    "evaluateAllStrategies must include CC at 14m (not metadata-starve)",
  );
  const all15 = evaluateAllStrategies(goldOpen);
  assert.ok(
    all15.all.some((r) => r.strategyId === "CONFLUENCE_CASCADE"),
    "evaluateAllStrategies must include CC at 15m inclusive",
  );
});

test.skip("factor gates: 0–1 factors still null even when cheap", () => {
  const weak = confluenceFireObs({
    regime: "strong_uptrend",
    yesAsk: 30,
    noAsk: 70,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    distFromFloorPct: 0.01,
    massAboveFloor: 50,
    recentUpPct: 0.50,
  });
  assert.equal(evaluateConfluenceCascade(weak), null);
  const one = confluenceFireObs({
    regime: "strong_uptrend",
    yesAsk: 30,
    noAsk: 70,
    velocityDolPerMin: 5,
    threeMinVelocity: 85,
    distFromFloorPct: 0.01,
    massAboveFloor: 50,
    recentUpPct: 0.50,
  });
  assert.equal(evaluateConfluenceCascade(one), null, "1 factor still null");
});

test.skip("cheap ask ≤55: 2 factors fire evaluate (quiet tape v1 omitted)", () => {
  const two = confluenceFireObs({
    regime: "strong_uptrend",
    yesAsk: 30,
    noAsk: 70,
    velocityDolPerMin: 0, // zVel_opposeBar ~35 — quiet tape, v1 does not count
    threeMinVelocity: 85,
    distFromFloorPct: 1.2,
    massAboveFloor: 50,
    recentUpPct: 0.50,
    velScale: 35,
    marketStale: false,
  });
  resetConfluenceTwoFactorConfirm();
  assert.equal(CHEAP_TWO_FACTOR_CONFIRM_TICKS, 3);
  assert.equal(evaluateConfluenceCascade(two), null, "2-factor cheap needs confirm ticks");
  assert.equal(evaluateConfluenceCascade(two), null);
  const fired = evaluateConfluenceCascade(two);
  assert.ok(fired, "2 aligned factors + cheap yes-or-no ≤55 fire after hysteresis");
  assert.equal(fired!.strategyId, CONFLUENCE_STRATEGY_ID);
  assert.equal(fired!.signal, "YES");
  const richTwo = confluenceFireObs({
    regime: "strong_uptrend",
    yesAsk: 66,
    noAsk: 66,
    velocityDolPerMin: 0,
    threeMinVelocity: 85,
    distFromFloorPct: 1.2,
    massAboveFloor: 50,
    recentUpPct: 0.50,
  });
  assert.equal(evaluateConfluenceCascade(richTwo), null, "rich book still needs 3 factors");
});

test.skip("confluenceWinRate is live-calibrated cheap-to-mid, never the 0.75 prior", () => {
  const p49 = confluenceWinRate(49, 5);
  const p70 = confluenceWinRate(70, 5);
  const p36 = confluenceWinRate(36, 5);
  assert.equal(CONFLUENCE_CENSUS_WR, 0.54);
  assert.notEqual(p36, 0.60);
  assert.notEqual(p49, 0.60);
  assert.ok(Math.abs(p36 - CONFLUENCE_CENSUS_WR) <= 0.02, "36c tracks census 0.54 not 0.60");
  assert.ok(p49 > 0.50 && p49 <= 0.64);
  assert.ok(p49 < 0.62, "must not overclaim 0.62 vs live 54% n=50");
  assert.notEqual(p49, 0.75);
  assert.ok(p49 > p70, "prefer cheap-to-mid");
  assert.ok(p70 < 0.50, "richer asks shrink below 0.50 — Fold C n=7 is not 86% p");
  const meta = getStrategy("CONFLUENCE_CASCADE")!;
  // Meta curve is the active win curve (refit by default); legacy stays exported.
  assert.equal(typeof meta.winRateAtPrice, "function");
  const obs = confluenceFireObs({ regime: "strong_uptrend", yesAsk: 30, noAsk: 70 });
  const { all } = evaluateAllStrategies(obs);
  assert.equal(all.some(r => r.strategyId === "CONFLUENCE_CASCADE"), true);
});

test.skip("EV floors uncut; live paper-ledger not clobbered (isolated tmp, not Kalshi cash)", () => {
  assert.match(ADM_SRC, /export const EV_FLOOR = 3;/);
  assert.match(BOT_SRC, /skip\("PATH_GATE"/);
  const adm = fs.readFileSync(path.join(DIR, "admission.ts"), "utf8");
  assert.match(adm, /return \(confidence >= 80 && edge >= 8\) \? 0\.60/);
  assert.match(adm, /maxRiskPctPerTrade:\s*0\.09/);
  const realLedger = path.join(DIR, "../../data/paper-ledger.json");
  const before = fs.readFileSync(realLedger, "utf8");
  const parsed = JSON.parse(before) as { virtualCents: number };
  assert.equal(isLivePaperLedgerCents(parsed.virtualCents), true, "read live paper ledger, not Kalshi cash");
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "paper-ledger-lock-"));
  const copy = path.join(tmp, "paper-ledger.json");
  fs.writeFileSync(copy, before);
  const round = JSON.parse(fs.readFileSync(copy, "utf8")) as { virtualCents: number };
  assert.equal(round.virtualCents, parsed.virtualCents);
  assert.equal(fs.readFileSync(realLedger, "utf8"), before);
  fs.rmSync(tmp, { recursive: true, force: true });
  const cfg = JSON.parse(fs.readFileSync(path.join(DIR, "../../.bot-config.json"), "utf8")) as { paperMode: boolean };
  assert.equal(cfg.paperMode, true);
});

test.skip("cheap path requires CHOSEN side ask ≤55; mixed must not buy YES @53 just because NO is 47", () => {
  // 2-2 mixed: v1+v3 bull, dist+mass bear. Tie must not default YES.
  const mixed = confluenceFireObs({
    regime: "strong_uptrend",
    velocityDolPerMin: 90,
    threeMinVelocity: 85,
    distFromFloorPct: -1.2,
    massAboveFloor: 20,
    recentUpPct: undefined,
    yesAsk: 53,
    noAsk: 47,
  });
  assert.equal(evaluateConfluenceCascade(mixed), null, "mixed factors must not buy YES @53");

  // Factors actually pick YES and yesAsk≤55 — allowed.
  const yesPick = confluenceFireObs({
    regime: "strong_uptrend",
    yesAsk: 53,
    noAsk: 47,
  });
  const fired = evaluateConfluenceCascade(yesPick);
  assert.ok(fired, "actual YES pick with yesAsk≤55 may buy YES");
  assert.equal(fired!.signal, "YES");

  // Rich YES (70) while NO is cheap (47) needs 3 aligned — 2-factor cheap must not unlock YES.
  const richYes = confluenceFireObs({
    regime: "strong_uptrend",
    velocityDolPerMin: 90,
    threeMinVelocity: 20, // v3 does not count
    distFromFloorPct: 1.2,
    massAboveFloor: 50, // mass does not count
    recentUpPct: undefined,
    yesAsk: 70,
    noAsk: 47,
  });
  assert.equal(evaluateConfluenceCascade(richYes), null, "must not buy rich YES because NO is cheap");
});

test.skip("36c CC fill PATH p is census not 0.60; EV floor still 3; band passthrough", () => {
  assert.equal(EV_FLOOR, 3);
  const p = confluenceWinRate(36, 6);
  assert.notEqual(p, 0.60);
  assert.ok(Math.abs(p - CONFLUENCE_CENSUS_WR) <= 0.02);
  const ev = computeTradeEV({
    entryPriceCents: 36,
    winRate: p,
    strategyId: "CONFLUENCE_CASCADE",
    secsRemaining: 6 * 60,
    minEVCents: EV_FLOOR,
  });
  assert.ok(ev.netEV >= EV_FLOOR, `36c at census p must still clear EV ${EV_FLOOR}, got ${ev.netEV}`);
  const sized = applyPaperEquityBand({
    strategyId: "CONFLUENCE_CASCADE",
    paperMode: true,
    equityCents: 29450,
    entryCents: 36,
    contracts: 20,
    netEV: ev.netEV,
    pWin: p,
  });
  assert.equal(sized.applied, false);
  assert.equal(sized.contracts, 20, "passthrough desired contracts");
});

test.skip("MTF short + NO 34c / YES 66c → CC constructs TAKE NO; p = winRateAtPrice(NO)", () => {
  resetConfluenceTwoFactorConfirm();
  const obs = confluenceFireObs({
    regime: "strong_uptrend",
    mtfScore: -4,
    yesAsk: 66,
    noAsk: 34,
  });
  const take = isMtfAlignedCheapTake({ mtfScore: -4, yesAsk: 66, noAsk: 34, minAskCents: 28 });
  assert.ok(take);
  assert.equal(take!.side, "no");
  assert.equal(mtfAlignedCheapWantSignal({ strategyId: "CONFLUENCE_CASCADE", mtfScore: -4, yesAsk: 66, noAsk: 34 }), "NO");
  const fired = evaluateConfluenceCascade(obs);
  assert.ok(fired, "CC must TAKE aligned cheap NO, not only veto YES");
  assert.equal(fired!.signal, "NO");
  const pNo = confluenceWinRate(34, 5);
  const pYes = confluenceWinRate(66, 5);
  assert.ok(pNo > pYes, "re-price p on NO ask, not the opposed YES");
  assert.equal(getStrategy("CONFLUENCE_CASCADE")!.winRateAtPrice!(34, 5), pNo);
});

test.skip("MTF short + YES 29c / NO 71c → no aligned cheap; KEEP skip (not TAKE opposed YES)", () => {
  resetConfluenceTwoFactorConfirm();
  assert.equal(isMtfAlignedCheapTake({ mtfScore: -4, yesAsk: 29, noAsk: 71, minAskCents: 28 }), null);
  assert.equal(evaluateConfluenceCascade(confluenceFireObs({
    regime: "strong_uptrend", mtfScore: -4, yesAsk: 29, noAsk: 71,
  })), null);
  assert.match(BOT_SRC, /skip\("MTF_FILTER"/);
  assert.equal(/ignoreMtfFilter|moneyMakerIgnoresMtfFilter/.test(BOT_SRC), false);
});

test.skip("MTF short + NO 8c → ENTRY 28 skip, do not construct", () => {
  resetConfluenceTwoFactorConfirm();
  assert.equal(getEntryPriceBand("CONFLUENCE_CASCADE").min, 20);
  assert.equal(isMtfAlignedCheapTake({ mtfScore: -4, yesAsk: 92, noAsk: 8, minAskCents: 28 }), null);
  assert.equal(evaluateConfluenceCascade(confluenceFireObs({
    regime: "strong_uptrend", mtfScore: -4, yesAsk: 92, noAsk: 8,
  })), null);
});
