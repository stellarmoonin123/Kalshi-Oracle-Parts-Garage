/**
 * historical-backtester.test.ts
 *
 * Regression coverage for simulateKalshiTrade()'s P&L formula. A prior bug
 * pre-netted the win case as `100 - entryPrice` and then subtracted
 * entryPrice a SECOND time, turning real wins into apparent losses for any
 * entry price above 50¢ and understating every other win's P&L. Every
 * downstream metric (totalPnlCents, byStrategy averages, pattern-learner
 * edge signals) was built on this corrupted number.
 *
 * Run with:
 *   node --experimental-strip-types src/lib/historical-backtester.test.ts
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { simulateKalshiTrade } from "./historical-backtester.js";
import { kalshiFeeCents } from "./constants.js";
import type { StrategyObservation } from "./strategy-library.js";

// 2026-08-11 (backtest/live parity): simulateKalshiTrade now charges the same
// price-dependent Kalshi fee live pays (kalshiFeeCents), not a flat 3¢
// approximation — see historical-backtester.ts's CONTRACT_FEE_CENTS comment.

function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 95_500,
    floorStrike: 95_000,
    velocityDolPerMin: 0,
    threeMinVelocity: 0,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.5,
    massAboveFloor: 60,
    secsRemaining: 300,
    shortTrend: "sideways",
    mediumTrend: "sideways",
    regime: "unclear",
    mtfScore: 0,
    ...overrides,
  } as StrategyObservation;
}

test("simulateKalshiTrade: a WIN pays out 100¢ minus entry minus fee — not double-netted", () => {
  // Force a deterministic entry price by pinning massAboveFloor to a value
  // where the spread-jitter range (2-5¢) can't push entryPrice past 50 in a
  // way that changes the sign under either formula, then verify the EXACT
  // relationship holds for every entry price the jitter can produce.
  for (let trial = 0; trial < 50; trial++) {
    const result = simulateKalshiTrade(
      "YES", "TEST_STRAT", "Test Strategy", 0.7,
      baseObs({ massAboveFloor: 60 }),
      96_000, // settlement well above strike -> YES always wins
    );
    assert.equal(result.won, true, "YES with settlement above strike must win");
    const expectedPnl = 100 - result.entryPrice - kalshiFeeCents(result.entryPrice);
    assert.equal(
      result.pnlCents, expectedPnl,
      `win P&L must be (100 - entryPrice - fee); got ${result.pnlCents} for entry ${result.entryPrice}`
    );
    // The old buggy formula was (100-entryPrice) - entryPrice - fee — confirm
    // we are NOT reproducing that for entries above 50¢.
    if (result.entryPrice > 50) {
      assert.ok(result.pnlCents > 0, `a win at entry ${result.entryPrice}¢ (>50¢) must show a profit, not a loss`);
    }
  }
});

test("simulateKalshiTrade: a LOSS pays out 0 minus entry minus fee", () => {
  for (let trial = 0; trial < 20; trial++) {
    const result = simulateKalshiTrade(
      "YES", "TEST_STRAT", "Test Strategy", 0.7,
      baseObs({ massAboveFloor: 60 }),
      94_000, // settlement below strike -> YES always loses
    );
    assert.equal(result.won, false);
    const expectedPnl = 0 - result.entryPrice - kalshiFeeCents(result.entryPrice);
    assert.equal(result.pnlCents, expectedPnl);
    assert.ok(result.pnlCents < 0, "a loss must always show a negative P&L");
  }
});

test("simulateKalshiTrade: win P&L is symmetric with (100 - loss's absolute cost) at the same entry price", () => {
  // At a fixed entry price, win P&L + loss P&L (magnitude) should sum to
  // exactly 100 - 2*fee: win = 100-entry-fee, loss = -(entry+fee), sum = 100-2*fee.
  // We can't pin entryPrice directly (it has jitter), so instead assert the
  // invariant win_pnl - (-loss_pnl) == 100 - entry*2 relationship per-trade
  // by re-deriving entryPrice from the result and checking both formulas.
  const win = simulateKalshiTrade("NO", "TEST_STRAT", "Test Strategy", 0.7, baseObs({ massAboveFloor: 40 }), 94_000);
  assert.equal(win.won, true, "NO with settlement below strike must win");
  assert.equal(win.pnlCents, 100 - win.entryPrice - kalshiFeeCents(win.entryPrice));
});

test("simulateKalshiTrade: fee is price-dependent (Kalshi taker fee), not a flat approximation", () => {
  // Distance-from-50¢ fee formula means a near-50¢ entry pays more fee than
  // a far-OTM entry — confirm the two differ (would be equal under the old
  // flat-3¢ model), and that pnlCents reflects whichever fee actually applies.
  const nearFifty = simulateKalshiTrade("YES", "TEST_STRAT", "Test Strategy", 0.7, baseObs({ massAboveFloor: 50 }), 96_000);
  const feeAtEntry = kalshiFeeCents(nearFifty.entryPrice);
  assert.equal(nearFifty.pnlCents, 100 - nearFifty.entryPrice - feeAtEntry);
  // Sanity: fee scales with min(price, 100-price) — never negative, never
  // more than the flat rate applied to the closer-to-50 side of the price.
  assert.ok(feeAtEntry >= 0);
});
