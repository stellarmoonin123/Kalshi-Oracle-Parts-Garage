/**
 * cheap-early-exit.test.ts
 * Dual-gate fail-closed. LIVE_APPLY false. Not hold-to-settle.
 */
import assert from "node:assert/strict";
import test from "node:test";
import {
  CHEAP_EARLY_ASK_MAX_CENTS,
  CHEAP_EARLY_ASK_MIN_CENTS,
  CHEAP_EARLY_GREEN_CENTS,
  CHEAP_EARLY_STRATEGY_ID,
  LIVE_APPLY,
  LIVE_APPLY_ENABLED,
  PAPER_MODE,
  cheapEarlyExitSignal,
  evaluateCheapEarlyExit,
  isCheapEarlyExitDualGateOpen,
} from "./cheap-early-exit.js";
import { getStrategy, type StrategyObservation } from "./strategy-library.js";
import { EV_FLOOR } from "./admission.js";

function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 6 * 60,
    contractDurationMins: 15,
    yesAsk: 18,
    yesBid: 16,
    noAsk: 83,
    noBid: 81,
    cheapEarlyExitEnabled: true,
    ...overrides,
  };
}

test("locks and band from stillCheap 7-55", () => {
  assert.equal(LIVE_APPLY, false);
  assert.equal(LIVE_APPLY_ENABLED, false);
  assert.equal(PAPER_MODE, true);
  assert.equal(CHEAP_EARLY_ASK_MIN_CENTS, 7);
  assert.equal(CHEAP_EARLY_ASK_MAX_CENTS, 55);
  assert.equal(CHEAP_EARLY_GREEN_CENTS, 20);
  assert.equal(EV_FLOOR, 3);
  assert.equal(isCheapEarlyExitDualGateOpen(undefined), false);
  assert.equal(isCheapEarlyExitDualGateOpen(false), false);
  assert.equal(isCheapEarlyExitDualGateOpen(true), true);
});

test("signal fires YES when yesAsk is the cheap side in band", () => {
  const r = cheapEarlyExitSignal(baseObs());
  assert.ok(r);
  assert.equal(r!.signal, "YES");
  assert.equal(r!.strategyId, CHEAP_EARLY_STRATEGY_ID);
  assert.match(r!.earlyExitRule, /Never HOLD_SETTLE/);
});

test("signal fires NO when noAsk is cheaper", () => {
  const r = cheapEarlyExitSignal(baseObs({ yesAsk: 82, yesBid: 80, noAsk: 19, noBid: 17 }));
  assert.ok(r);
  assert.equal(r!.signal, "NO");
});

test("evaluate fail-closes unless enabled === true", () => {
  assert.equal(evaluateCheapEarlyExit(baseObs({ cheapEarlyExitEnabled: false })), null);
  assert.equal(evaluateCheapEarlyExit(baseObs({ cheapEarlyExitEnabled: undefined })), null);
  assert.ok(evaluateCheapEarlyExit(baseObs({ cheapEarlyExitEnabled: true })));
});

test("does not fire in dead zone last 120s", () => {
  assert.equal(cheapEarlyExitSignal(baseObs({ secsRemaining: 100 })), null);
});

test("does not fire lottery 8c last 150s", () => {
  assert.equal(cheapEarlyExitSignal(baseObs({ yesAsk: 8, yesBid: 7, noAsk: 93, noBid: 92, secsRemaining: 140 })), null);
});

test("does not fire outside 7-55", () => {
  assert.equal(cheapEarlyExitSignal(baseObs({ yesAsk: 4, noAsk: 96 })), null);
  assert.equal(cheapEarlyExitSignal(baseObs({ yesAsk: 70, noAsk: 62 })), null);
});

test("hourly duration is skip", () => {
  assert.equal(cheapEarlyExitSignal(baseObs({ contractDurationMins: 60 })), null);
});

test("library dual-gate matches module", () => {
  const strategy = getStrategy("CHEAP_EARLY_EXIT");
  assert.ok(strategy);
  assert.equal(strategy!.evaluate(baseObs({ cheapEarlyExitEnabled: false })), null);
  const viaLib = strategy!.evaluate(baseObs({ cheapEarlyExitEnabled: true }));
  const viaMod = evaluateCheapEarlyExit(baseObs({ cheapEarlyExitEnabled: true }));
  assert.ok(viaLib);
  assert.ok(viaMod);
  assert.equal(viaLib!.signal, viaMod!.signal);
});
