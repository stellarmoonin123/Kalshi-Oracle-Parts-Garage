/**
 * Label honesty: Kalshi YES/NO from official result or BTC vs floor.
 * Never paper W/L. Never period up/down. MTF "strongly aligned" matches lock |score|>=3.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  kalshiSettleFromTruth,
  labeledProjectionPair,
  labeledCanonicalAndModel,
  mtfAgreementLabel,
  MTF_STRONG_LOCK,
  isExpirySettleReason,
} from "./kalshi-settle-label.js";
import { buildTradeStory, collapsedStoryFields } from "./trade-story.js";
import { FILL_ORIGIN_BOT, FILL_ORIGIN_MANUAL, MANUAL_STRATEGY_ID } from "./fill-origin.js";
import { flushPaperBar, notePaperBarEvaluate, notePaperBarExit, resetPaperBarTapeForTests } from "./paper-bar-tape.js";
import os from "node:os";
import fs from "node:fs";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const tapeFile = path.join(os.tmpdir(), `label-honesty-tape-${Date.now()}.jsonl`);
process.env.PAPER_BAR_TAPE_PATH = tapeFile;

test("BTC close vs floor is Kalshi YES/NO; up/down is not used", () => {
  assert.equal(kalshiSettleFromTruth({ btcClose: 65010, floorStrike: 65000 }), "YES");
  assert.equal(kalshiSettleFromTruth({ btcClose: 64990, floorStrike: 65000 }), "NO");
  assert.equal(kalshiSettleFromTruth({ officialKalshi: "yes" }), "YES");
  assert.equal(kalshiSettleFromTruth({ officialKalshi: "NO" }), "NO");
  assert.equal(kalshiSettleFromTruth({ officialKalshi: "up" }), null);
  assert.equal(kalshiSettleFromTruth({ officialKalshi: "down" }), null);
  assert.equal(kalshiSettleFromTruth({ officialKalshi: "win" }), null);
  // Official Kalshi YES/NO wins when present; floor used when official is absent.
  assert.equal(kalshiSettleFromTruth({ officialKalshi: "YES", btcClose: 64000, floorStrike: 65000 }), "YES");
  // Kalshi "greater" strike: YES iff close > floor (equal → NO). Matches labels organ.
  assert.equal(kalshiSettleFromTruth({ btcClose: 65000, floorStrike: 65000 }), "NO");
});

test("dumped winner is WIN; settlement is official/BTC vs floor, never inferred LOSS", () => {
  const dumped = buildTradeStory({
    fillOrigin: FILL_ORIGIN_BOT,
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    outcome: "loss",
    pnlCents: 18,
    entryPriceCents: 42,
    contracts: 2,
    ticker: "KXBTC15M-DUMP",
    exitReason: "THESIS_BREAK_EXIT",
    btcClose: 65100,
    floorStrike: 65000,
    filledAt: "2026-09-02T16:00:00.000Z",
    settledAt: "2026-09-02T16:04:00.000Z",
  });
  assert.ok(dumped);
  assert.equal(dumped!.result, "WIN");
  assert.equal(dumped!.settlement, "YES");
  assert.equal(dumped!.soldEarly, true);

  const dumpedUnknown = buildTradeStory({
    fillOrigin: FILL_ORIGIN_BOT,
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    outcome: "win",
    pnlCents: 18,
    exitReason: "THESIS_BREAK_EXIT",
  });
  assert.ok(dumpedUnknown);
  assert.equal(dumpedUnknown!.result, "WIN");
  assert.equal(dumpedUnknown!.settlement, "unknown");

  const officialAgainst = collapsedStoryFields({
    side: "yes",
    outcome: "win",
    pnlCents: 12,
    settledSide: "NO",
    exitReason: "CHEAP_EARLY_GREEN",
  });
  assert.equal(officialAgainst.result, "WIN");
  assert.equal(officialAgainst.settlement, "NO");
});

test("hold-to-settlement may use W/L as Kalshi PnL; manuals never teach", () => {
  const hold = buildTradeStory({
    fillOrigin: FILL_ORIGIN_BOT,
    strategyId: "BASIS_LAG_EDGE",
    side: "no",
    outcome: "loss",
    pnlCents: -40,
    exitReason: "SETTLEMENT",
  });
  assert.equal(hold!.settlement, "YES");
  assert.equal(buildTradeStory({
    fillOrigin: FILL_ORIGIN_MANUAL,
    strategyId: MANUAL_STRATEGY_ID,
    side: "yes",
    outcome: "win",
    pnlCents: 50,
    exitReason: "SETTLEMENT",
  }), null);
});

test("MTF strongly aligned matches lock |score|>=3 not >=2", () => {
  assert.equal(MTF_STRONG_LOCK, 3);
  assert.equal(mtfAgreementLabel(2).label, "aligned");
  assert.notEqual(mtfAgreementLabel(2).label, "strongly aligned");
  assert.equal(mtfAgreementLabel(3).label, "strongly aligned");
  assert.equal(mtfAgreementLabel(-2).label, "opposed");
  assert.equal(mtfAgreementLabel(-3).label, "strongly opposed");
});

test("disagreeing proj vs basisState are both labeled", () => {
  const agree = labeledProjectionPair(65100.2, 65100.4);
  assert.equal(agree.agree, true);
  assert.match(agree.line, /^proj \$65100$/);
  const split = labeledProjectionPair(65100, 64800);
  assert.equal(split.agree, false);
  assert.match(split.line, /basis proj \$65100/);
  assert.match(split.line, /model proj \$64800/);
});

test("paper-bar-tape does not store intra-bar live favorite as kalshiSettle", () => {
  resetPaperBarTapeForTests();
  try { fs.unlinkSync(tapeFile); } catch { /* */ }
  const T = "KXBTC15M-26SEP021200-00";
  notePaperBarEvaluate({
    obs: {
      currentPrice: 64000,
      floorStrike: 63000,
      velocityDolPerMin: 10,
      threeMinVelocity: 10,
      isStalling: false,
      stallStrength: "none",
      distFromFloorPct: 1.5,
      massAboveFloor: 80,
      secsRemaining: 8 * 60,
      paperMode: true,
      contractDurationMins: 15,
      ticker: T,
      regime: "unclear",
      yesAsk: 48,
      noAsk: 52,
    } as never,
  });
  notePaperBarExit({ ticker: T, exitReason: "THESIS_BREAK_EXIT", holdMs: 20_000 });
  const mid = flushPaperBar(T);
  assert.ok(mid);
  assert.equal(mid!.kalshiSettle, null, "intra-bar flush without expiry must not invent Kalshi settle");

  resetPaperBarTapeForTests();
  notePaperBarEvaluate({
    obs: {
      currentPrice: 62900,
      floorStrike: 63000,
      velocityDolPerMin: 10,
      threeMinVelocity: 10,
      isStalling: false,
      stallStrength: "none",
      distFromFloorPct: -0.16,
      massAboveFloor: 20,
      secsRemaining: 8 * 60,
      paperMode: true,
      contractDurationMins: 15,
      ticker: T,
      regime: "unclear",
      yesAsk: 48,
      noAsk: 52,
    } as never,
  });
  const expired = flushPaperBar(T, { expiry: true });
  assert.equal(expired!.kalshiSettle, "NO");
});

test("dump lastPx is not bar-expiry settle; later evaluate then expiry flush wins", () => {
  resetPaperBarTapeForTests();
  try { fs.unlinkSync(tapeFile); } catch { /* */ }
  const T = "KXBTC15M-26SEP021245-45";
  const base = {
    velocityDolPerMin: 10,
    threeMinVelocity: 10,
    isStalling: false,
    stallStrength: "none",
    massAboveFloor: 80,
    secsRemaining: 8 * 60,
    paperMode: true,
    contractDurationMins: 15,
    ticker: T,
    regime: "unclear",
    yesAsk: 48,
    noAsk: 52,
  };
  notePaperBarEvaluate({
    obs: { ...base, currentPrice: 64000, floorStrike: 63000, distFromFloorPct: 1.6 } as never,
  });
  notePaperBarExit({ ticker: T, exitReason: "THESIS_BREAK_EXIT", holdMs: 20_000, kalshiSettle: null });
  notePaperBarEvaluate({
    obs: { ...base, currentPrice: 62900, floorStrike: 63000, distFromFloorPct: -0.16, massAboveFloor: 20 } as never,
  });
  const expired = flushPaperBar(T, { expiry: true });
  assert.ok(expired);
  assert.equal(expired!.kalshiSettle, "NO", "later bar-expiry lastPx vs floor, not dump 64000 YES");
});

test("canonical vs model split-brain is labeled, never a silent pick", () => {
  const split = labeledCanonicalAndModel({ proj: undefined, splitBrain: true }, 65100);
  assert.equal(split.splitBrain, true);
  assert.match(split.line, /split-brain/);
  assert.match(split.line, /model proj \$65100/);
  const one = labeledCanonicalAndModel({ proj: 65100.2, splitBrain: false }, 65100.4);
  assert.equal(one.splitBrain, false);
  assert.match(one.line, /^proj \$65100$/);
});

test("isExpirySettleReason only SETTLEMENT / SETTLED_KALSHI", () => {
  assert.equal(isExpirySettleReason("SETTLEMENT"), true);
  assert.equal(isExpirySettleReason("SETTLED_KALSHI"), true);
  assert.equal(isExpirySettleReason("THESIS_BREAK_EXIT"), false);
});

test("source locks: no ENABLE leftover engines, display routes not raw 500, expiry-only tape settle", () => {
  const bot = readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
  const story = readFileSync(path.join(DIR, "trade-story.ts"), "utf8");
  const label = readFileSync(path.join(DIR, "kalshi-settle-label.ts"), "utf8");
  const routes = readFileSync(path.join(DIR, "../routes/bot.ts"), "utf8");
  const ml = readFileSync(path.join(DIR, "market-learning.ts"), "utf8");
  assert.doesNotMatch(label, /paperMode\s*=\s*false/);
  assert.doesNotMatch(story, /ENABLE_(CHEAP_SIDE|SEV1|OTM)/);
  assert.match(routes, /trades_unavailable/);
  assert.match(routes, /desk_snapshot_unavailable/);
  assert.match(ml, /Period "up"\/"down" is NOT YES\/NO/);
  // P0-D (Sep 19 base): tape settle stamps officialSettle on expiry OR once the
  // period has closed (truth only from BTC@close vs floor) — never from paper W/L.
  assert.match(bot, /truthSettleOk \? officialSettle : null/);
  assert.match(bot, /const truthSettleOk = expirySettle \|\| periodClosed;/);
  assert.match(bot, /labeledCanonicalAndModel/);
  assert.match(bot, /canonicalLagProjectedSettlement/);
  assert.match(bot, /canonicalLagProj:/);
  assert.match(bot, /projLine:/);
});
