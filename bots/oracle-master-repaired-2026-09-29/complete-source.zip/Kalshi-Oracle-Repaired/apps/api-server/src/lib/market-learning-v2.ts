/**
 * market-learning-v2.ts — GO: MARKET-LEARNING v2 (SHADOW EV + STATE MACHINE,
 * ZERO LIVE APPLY), 2026-08-24.
 *
 * Evolves market-learning.ts's ±0.03 confidence-bump base-rate adjustment
 * (still active, unchanged, governed by its own LIVE_APPLY_ENABLED flag —
 * see that file's header) into a proper shadow expected-value policy with
 * an explicit rollout state machine. This module NEVER places a real or
 * paper order and NEVER modifies any live entry/exit/sizing/consensus/
 * quarantine/minConfidence value. It only computes and LOGS what a lag-first
 * EV policy would have done, for later human review.
 *
 * ── State machine (the ONE source of truth for this feature's live impact) ─
 *   mode ∈ {shadow, canary, full} — persisted in learning_state (id=1 row).
 *     shadow (default, sizeMult 0) — fully observational.
 *     canary (sizeMult 0.25)       — ONLY reached via an explicit human
 *                                    "APPLY" call to applyLearningMode();
 *                                    never auto-set by sample count, uptime,
 *                                    or any other trigger. Auto-reverts to
 *                                    shadow if evaluateShadowPassFail() fails
 *                                    (autoRevertCanaryIfFailing()).
 *     full (sizeMult 1.0)          — ONLY reached via a second explicit
 *                                    human APPLY, and only if canary's
 *                                    pass/fail metrics currently pass.
 *   `mode` is what any FUTURE live-order integration must check — there is
 *   no bare boolean flag in this file for that integration to bypass.
 *
 * ── Feature store v2 ─────────────────────────────────────────────────────
 * Adds 7 nullable columns to the existing market_observations table (see
 * lib/db/src/schema/market-observations.ts): leadExchangeDelta, displacement,
 * spreadCents, volumeScore, sessionLabel (recorded per-snapshot), plus
 * feeNetIfYesCents/feeNetIfNoCents (backfilled at resolution). Additive only
 * — v1 readers/writers are unaffected; existing poison/lookahead-test
 * guarantees on market_observations are untouched (no existing column's
 * write timing changed).
 *
 * ── Shadow EV policy ─────────────────────────────────────────────────────
 * p_up is looked up from an empirically-refreshed bucket cache keyed by
 * sign(leadExchangeDelta) × sign(distFromFloorPct) — "lag-first" per spec:
 * the lead-exchange lag proxy is the primary axis, floor-distance is the
 * secondary tie-breaker. Falls back to a neutral 0.5 / sampleSize=0 below
 * V2_MIN_SAMPLE_SIZE, exactly like v1's base-rate cache — an empty bucket
 * must never fabricate a confident-looking probability. EV_hat reuses
 * trade-path.ts's computeTradeEV() (same fee + dynamic-slippage formula the
 * live bot uses) so the shadow number is realistic. The admission bar
 * (LIVE_EV_FLOOR_CENTS_MIRROR) is a duplicated CONSTANT, not a call into
 * trading-bot.ts — see the constant's own comment for why, and keep it
 * numerically in sync by hand; the shadow gate is only meaningful if it is
 * at least as strict as the real one, never looser.
 *
 * ── Locks (do not touch from this file) ─────────────────────────────────
 * Live EV/PATH_GATE, packs, consensus, quarantine, minConfidence values;
 * BRTI/MTF/SAKATA/OTM enablement; any auto shadow→canary trigger at any
 * sample/contract count; any BotConfig write.
 */

import { db, marketObservations, learningState, shadowDecisions } from "@workspace/db";
import { and, eq, isNotNull, isNull, sql } from "drizzle-orm";
import { computeTradeEV } from "./trade-path.js";
import { kalshiFeeCents } from "./constants.js";
import { getSessionBias } from "./market-intelligence.js";

// ── Mirrored live constant (see file header) ───────────────────────────────
// Mirrors trading-bot.ts's `export const EV_FLOOR = 3;` (~line 1774).
// Duplicated rather than imported so this shadow-only research module never
// pulls in trading-bot.ts (a large stateful module with import-time side
// effects) — same "duplicate a tiny constant to keep a one-way dependency"
// convention market-learning.ts already uses for currentPeriodOpenTs().
const LIVE_EV_FLOOR_CENTS_MIRROR = 3;

const V2_MIN_SAMPLE_SIZE  = 150;          // mirrors v1's MIN_SAMPLE_SIZE — per-bucket floor before a bucket may influence p_up
const V2_REFRESH_MS       = 5 * 60_000;   // mirrors v1's BASE_RATE_REFRESH_MS
const NEAR_ZERO_EPS_LEAD  = 0.01;         // $ — sign() dead zone for leadExchangeDelta
const NEAR_ZERO_EPS_FLOOR = 0.05;         // % — sign() dead zone for distFromFloorPct
export const CURRENT_POLICY_VERSION = "ml-v2.0.0";

// ── State machine ────────────────────────────────────────────────────────

export type LearningMode = "shadow" | "canary" | "full";

export interface LearningStateSnapshot {
  mode: LearningMode;
  policyVersion: string;
  sizeMult: number;
  lastTransitionReason: string | null;
  canaryStartedAt: Date | null;
  updatedAt: Date;
}

let cachedState: LearningStateSnapshot | null = null;
let cachedStateAt = 0;
const STATE_CACHE_MS = 5_000;

/** Reads learning_state (id=1). Fails closed to shadow/sizeMult=0 if the row is somehow missing — never assumes canary/full. */
export async function getLearningState(forceRefresh = false): Promise<LearningStateSnapshot> {
  if (!forceRefresh && cachedState && Date.now() - cachedStateAt < STATE_CACHE_MS) return cachedState;
  try {
    const [row] = await db.select().from(learningState).where(eq(learningState.id, 1)).limit(1);
    if (!row) {
      console.warn("[market-learning-v2] learning_state row missing — failing closed to shadow");
      cachedState = { mode: "shadow", policyVersion: CURRENT_POLICY_VERSION, sizeMult: 0, lastTransitionReason: "row missing — fail-closed default", canaryStartedAt: null, updatedAt: new Date() };
    } else {
      cachedState = {
        mode: (row.mode as LearningMode) ?? "shadow",
        policyVersion: row.policyVersion,
        sizeMult: row.sizeMult,
        lastTransitionReason: row.lastTransitionReason,
        canaryStartedAt: row.canaryStartedAt,
        updatedAt: row.updatedAt,
      };
    }
  } catch (err) {
    console.warn("[market-learning-v2] getLearningState failed, failing closed to shadow:", (err as Error).message);
    cachedState = { mode: "shadow", policyVersion: CURRENT_POLICY_VERSION, sizeMult: 0, lastTransitionReason: "DB read failed — fail-closed default", canaryStartedAt: null, updatedAt: new Date() };
  }
  cachedStateAt = Date.now();
  return cachedState;
}

const VALID_TRANSITIONS: Record<LearningMode, LearningMode[]> = {
  shadow: ["canary"],
  canary: ["full", "shadow"],
  full:   ["shadow"],
};

export interface ApplyModeResult {
  success: boolean;
  reason?: string;
  state: LearningStateSnapshot;
}

/**
 * The ONLY way `mode` ever changes upward (shadow→canary, canary→full).
 * Callers are responsible for this being a genuine, explicit human decision
 * (e.g. an operator hitting an "APPLY" button/endpoint) — this function
 * itself has no caller anywhere in the live tick/order path, and nothing in
 * this codebase invokes it automatically for an upward transition.
 * Downward transitions (canary→shadow, full→shadow) are always allowed,
 * including the automatic one from autoRevertCanaryIfFailing().
 */
export async function applyLearningMode(targetMode: LearningMode, reason: string, opts?: { auto?: boolean }): Promise<ApplyModeResult> {
  const current = await getLearningState(true);
  if (targetMode === current.mode) {
    return { success: true, reason: "already in target mode", state: current };
  }
  if (!VALID_TRANSITIONS[current.mode].includes(targetMode)) {
    return { success: false, reason: `invalid transition ${current.mode} -> ${targetMode}; must step through canary`, state: current };
  }
  if (current.mode === "canary" && targetMode === "full" && !opts?.auto) {
    const passFail = await evaluateShadowPassFail();
    if (!passFail.pass) {
      return { success: false, reason: `canary->full blocked by pre-registered metrics: ${passFail.reasons.join("; ")}`, state: current };
    }
  }

  const sizeMult = targetMode === "shadow" ? 0 : targetMode === "canary" ? CANARY_ENVELOPE.sizeMult : 1.0;
  const canaryStartedAt = targetMode === "canary" ? new Date() : targetMode === "shadow" ? null : current.canaryStartedAt;

  await db.update(learningState).set({
    mode: targetMode,
    sizeMult,
    lastTransitionReason: reason,
    canaryStartedAt,
    updatedAt: new Date(),
  }).where(eq(learningState.id, 1));

  cachedState = null;
  const next = await getLearningState(true);
  console.info(`[market-learning-v2] mode transition ${current.mode} -> ${targetMode} (${opts?.auto ? "AUTO-REVERT" : "human APPLY"}): ${reason}`);
  return { success: true, state: next };
}

/**
 * Periodic dormant-until-canary check. Never auto-advances shadow→canary or
 * canary→full — only ever reverts canary→shadow, and only on a failing
 * pre-registered metric. A no-op while mode==='shadow' (the default and, as
 * of this build, the only mode ever set).
 */
export async function autoRevertCanaryIfFailing(): Promise<void> {
  const state = await getLearningState();
  if (state.mode !== "canary") return;
  const passFail = await evaluateShadowPassFail();
  if (!passFail.pass) {
    await applyLearningMode("shadow", `auto-revert: ${passFail.reasons.join("; ")}`, { auto: true });
  }
}

// ── Canary envelope (defined now, enforced by nothing while mode=shadow) ──

export interface CanaryEnvelope {
  sizeMult: number;
  maxCanaryTradesPerDay: number;
  maxCanaryDailyLossPctEquity: number;
}

/**
 * Per spec section D. NOT wired into any live order-admission path today —
 * mode never leaves 'shadow' in this build, so nothing calls
 * evaluateCanaryAdmission() yet. A future live-order integration must call
 * it at the same admission point the live bot already uses for its own
 * 9%-equity hard cap / daily halt (trading-bot.ts HARD_RISK_LIMITS /
 * effectiveDailyLossCapCents) — this envelope NARROWS that admission, it
 * never replaces or loosens it.
 */
export const CANARY_ENVELOPE: CanaryEnvelope = {
  sizeMult: 0.25,
  maxCanaryTradesPerDay: 5,
  maxCanaryDailyLossPctEquity: 2, // comfortably inside the live 9%-of-equity hard cap
};

export function evaluateCanaryAdmission(opts: {
  canaryTradesToday: number;
  canaryPnlPctEquityToday: number; // negative = loss
}): { allowed: boolean; reason?: string } {
  if (opts.canaryTradesToday >= CANARY_ENVELOPE.maxCanaryTradesPerDay) {
    return { allowed: false, reason: `canary daily trade cap reached (${opts.canaryTradesToday}/${CANARY_ENVELOPE.maxCanaryTradesPerDay})` };
  }
  if (opts.canaryPnlPctEquityToday <= -CANARY_ENVELOPE.maxCanaryDailyLossPctEquity) {
    return { allowed: false, reason: `canary daily loss cap reached (${opts.canaryPnlPctEquityToday.toFixed(2)}% vs -${CANARY_ENVELOPE.maxCanaryDailyLossPctEquity}%)` };
  }
  return { allowed: true };
}

// ── Pre-registered pass/fail metrics ────────────────────────────────────────

export const SHADOW_PASS_CRITERIA = {
  minSettledCount: 300,               // resolved, non-SKIP shadow_decisions rows
  minWeeklyFeeNetVsBaselineCents: 0,  // must beat the neutral (never-trade, 0¢) baseline over the trailing week
};

export interface ShadowPassFailResult {
  pass: boolean;
  reasons: string[];
  settledCount: number;
  weeklyFeeNetCents: number;
  maxDrawdownCents: number;
}

/**
 * Evaluates the shadow (or canary) policy's own logged/resolved decisions
 * against pre-registered thresholds. `maxDrawdownCents` is reported for
 * visibility but is NOT a hard pass/fail criterion here — a meaningful
 * dollar-drawdown cap depends on the canary account's actual equity, which
 * isn't known pre-canary; a future canary run must set that bound
 * explicitly before this function treats it as a hard fail condition.
 */
export async function evaluateShadowPassFail(): Promise<ShadowPassFailResult> {
  const resolvedTaken = await db.select({
    feeNetCents: shadowDecisions.feeNetCents,
    resolvedAt: shadowDecisions.resolvedAt,
  }).from(shadowDecisions)
    .where(and(isNotNull(shadowDecisions.resolvedAt), sql`${shadowDecisions.action} != 'SKIP'`));

  const settledCount = resolvedTaken.length;
  const weekAgoMs = Date.now() - 7 * 24 * 60 * 60_000;
  const weeklyFeeNetCents = resolvedTaken
    .filter(r => r.resolvedAt && r.resolvedAt.getTime() >= weekAgoMs)
    .reduce((sum, r) => sum + (r.feeNetCents ?? 0), 0);

  let cum = 0, peak = 0, maxDrawdownCents = 0;
  for (const r of resolvedTaken) {
    cum += r.feeNetCents ?? 0;
    peak = Math.max(peak, cum);
    maxDrawdownCents = Math.max(maxDrawdownCents, peak - cum);
  }

  const reasons: string[] = [];
  if (settledCount < SHADOW_PASS_CRITERIA.minSettledCount) {
    reasons.push(`only ${settledCount} settled taken decisions, need >= ${SHADOW_PASS_CRITERIA.minSettledCount}`);
  }
  if (settledCount >= SHADOW_PASS_CRITERIA.minSettledCount && weeklyFeeNetCents < SHADOW_PASS_CRITERIA.minWeeklyFeeNetVsBaselineCents) {
    reasons.push(`weekly fee-net ${weeklyFeeNetCents.toFixed(1)}c is below the neutral 0c baseline`);
  }

  return { pass: reasons.length === 0, reasons, settledCount, weeklyFeeNetCents, maxDrawdownCents };
}

// ── Feature store v2 helpers (called from market-learning.ts's snapshot path) ─

const periodOpenFairPrice = new Map<string, { periodOpenTsMs: number; price: number }>();

/**
 * First fairPrice seen for a ticker's period becomes that period's zero
 * point; every later call for the same ticker+period returns
 * fairPrice - anchor (intra-period momentum, distinct from
 * distFromFloorPct's distance-from-floor). Resets automatically the moment
 * a new periodOpenTs is seen for that ticker.
 */
export function trackDisplacement(ticker: string, periodOpenTsMs: number, fairPrice: number | null): number | null {
  if (fairPrice == null) return null;
  const cached = periodOpenFairPrice.get(ticker);
  if (!cached || cached.periodOpenTsMs !== periodOpenTsMs) {
    periodOpenFairPrice.set(ticker, { periodOpenTsMs, price: fairPrice });
    return 0;
  }
  return fairPrice - cached.price;
}

/** Standard binary-market spread/overround: yesAsk + noAsk - 100. */
export function computeSpreadCents(yesAskCents: number | null, noAskCents: number | null): number | null {
  if (yesAskCents == null || noAskCents == null) return null;
  return yesAskCents + noAskCents - 100;
}

/**
 * Simplified [0,1] liquidity proxy for feature-store v2, built only from
 * spread width — the one liquidity signal available to the independent,
 * tick-agnostic snapshot driver. NOT the same as volume-risk.ts's live
 * volumeScore(), which needs velocityDolPerMin/atrPct/volumeState inputs
 * only available on the hot bot-tick path. Narrower spread -> higher score.
 */
export function proxyVolumeScore(spreadCents: number | null): number {
  if (spreadCents == null) return 0.5; // unknown — neutral, not a guess in either direction
  return Math.max(0, Math.min(1, 1 - Math.abs(spreadCents) / 10));
}

export function currentSessionLabel(): string {
  return getSessionBias(new Date().getUTCHours()).label;
}

// ── Shadow EV bucket cache (lag-first empirical p_up) ───────────────────────

interface ShadowBucketRow { n: number; upRate: number; }
const shadowBucketCache = new Map<string, ShadowBucketRow>();

function sign3(x: number | null | undefined, eps: number): -1 | 0 | 1 {
  if (x == null || !Number.isFinite(x)) return 0;
  if (x > eps) return 1;
  if (x < -eps) return -1;
  return 0;
}

function shadowBucketKeyFor(leadExchangeDelta: number | null, distFromFloorPct: number | null): string {
  return `${sign3(leadExchangeDelta, NEAR_ZERO_EPS_LEAD)}:${sign3(distFromFloorPct, NEAR_ZERO_EPS_FLOOR)}`;
}

async function refreshShadowBuckets(): Promise<void> {
  try {
    const rows = await db.select({
      leadExchangeDelta: marketObservations.leadExchangeDelta,
      distFromFloorPct:  marketObservations.distFromFloorPct,
      settledDirection:  marketObservations.settledDirection,
    }).from(marketObservations)
      .where(and(isNotNull(marketObservations.settledDirection), isNotNull(marketObservations.leadExchangeDelta)));

    const buckets = new Map<string, { n: number; up: number }>();
    for (const r of rows) {
      const key = shadowBucketKeyFor(r.leadExchangeDelta, r.distFromFloorPct);
      const b = buckets.get(key) ?? { n: 0, up: 0 };
      b.n += 1;
      if (r.settledDirection === "up") b.up += 1;
      buckets.set(key, b);
    }
    shadowBucketCache.clear();
    for (const [key, b] of buckets) shadowBucketCache.set(key, { n: b.n, upRate: b.n > 0 ? b.up / b.n : 0.5 });
  } catch (err) {
    console.warn("[market-learning-v2] bucket refresh failed:", (err as Error).message);
  }
}

/** Sync, hot-path-safe — reads the in-memory cache only. Returns neutral 0.5 / sampleSize 0 below V2_MIN_SAMPLE_SIZE, exactly like v1's base-rate cache. */
export function lookupShadowPUp(leadExchangeDelta: number | null, distFromFloorPct: number | null): { pUp: number; sampleSize: number } {
  const row = shadowBucketCache.get(shadowBucketKeyFor(leadExchangeDelta, distFromFloorPct));
  if (!row || row.n < V2_MIN_SAMPLE_SIZE) return { pUp: 0.5, sampleSize: row?.n ?? 0 };
  return { pUp: row.upRate, sampleSize: row.n };
}

// ── Shadow EV decision engine (log-only — never places an order) ──────────

export type ShadowAction = "TAKE_BASE" | "TAKE_PROBE" | "SKIP";

export interface ShadowDecisionInput {
  ticker: string;
  periodOpenTs: Date;
  secsRemaining: number;
  yesAskCents: number | null;
  noAskCents: number | null;
  leadExchangeDelta: number | null;
  distFromFloorPct: number | null;
  spreadCents: number | null;
}

export interface ShadowDecisionResult {
  side: "YES" | "NO";
  askCents: number;
  pUp: number;       // probability of the SIDE chosen winning (not always P(up))
  sampleSize: number;
  evHatCents: number;
  action: ShadowAction;
}

/**
 * Pure function: computes what the shadow policy would do. Evaluates both
 * sides at their real ask prices via the SAME computeTradeEV() the live bot
 * uses (fee + dynamic slippage), picks whichever side has the higher net
 * EV, then classifies TAKE_BASE/TAKE_PROBE/SKIP against
 * LIVE_EV_FLOOR_CENTS_MIRROR. Both TAKE tiers require clearing the exact
 * same real floor — TAKE_PROBE is a lower-conviction LABEL, not a lower
 * admission bar.
 */
export function computeShadowDecision(input: ShadowDecisionInput): ShadowDecisionResult | null {
  if (input.yesAskCents == null || input.noAskCents == null) return null;
  const { pUp, sampleSize } = lookupShadowPUp(input.leadExchangeDelta, input.distFromFloorPct);

  const evYes = computeTradeEV({ entryPriceCents: input.yesAskCents, winRate: pUp, secsRemaining: input.secsRemaining, spreadCents: input.spreadCents ?? undefined });
  const evNo  = computeTradeEV({ entryPriceCents: input.noAskCents,  winRate: 1 - pUp, secsRemaining: input.secsRemaining, spreadCents: input.spreadCents ?? undefined });

  const useYes = evYes.netEV >= evNo.netEV;
  const side = useYes ? "YES" as const : "NO" as const;
  const askCents = useYes ? input.yesAskCents : input.noAskCents;
  const evHatCents = useYes ? evYes.netEV : evNo.netEV;
  const sideWinRate = useYes ? pUp : 1 - pUp;

  let action: ShadowAction = "SKIP";
  if (evHatCents >= LIVE_EV_FLOOR_CENTS_MIRROR * 2) action = "TAKE_BASE";
  else if (evHatCents >= LIVE_EV_FLOOR_CENTS_MIRROR) action = "TAKE_PROBE";

  return { side, askCents, pUp: sideWinRate, sampleSize, evHatCents, action };
}

const loggedShadowPeriods = new Set<string>();

/**
 * Fire-and-forget, once per ticker+period (in-memory guard + a DB unique
 * index backstop identical in spirit to recordMarketObservation's
 * per-ticker throttle map). Never awaited into any tick loop, never
 * places an order.
 */
export async function maybeLogShadowDecision(input: ShadowDecisionInput): Promise<void> {
  const key = `${input.ticker}:${input.periodOpenTs.toISOString()}`;
  if (loggedShadowPeriods.has(key)) return;
  loggedShadowPeriods.add(key);
  if (loggedShadowPeriods.size > 1000) loggedShadowPeriods.clear(); // bounded memory; DB unique index is the real dedupe backstop

  try {
    const decision = computeShadowDecision(input);
    if (!decision) return;
    const state = await getLearningState();

    await db.insert(shadowDecisions).values({
      ticker:        input.ticker,
      periodOpenTs:  input.periodOpenTs,
      side:          decision.side,
      askCents:      decision.askCents,
      pUp:           decision.pUp,
      sampleSize:    decision.sampleSize,
      evHatCents:    decision.evHatCents,
      action:        decision.action,
      policyVersion: state.policyVersion,
    }).onConflictDoNothing();
  } catch (err) {
    console.warn("[market-learning-v2] shadow decision log failed:", (err as Error).message);
  }
}

// ── Resolution ───────────────────────────────────────────────────────────

/**
 * Called from market-learning.ts's resolveMarketObservationsForPeriod
 * (same trigger point — period-recorder.ts already owns "a period just
 * settled"). Backfills feeNetIfYes/feeNetIfNo on this period's
 * market_observations rows, then resolves this period's shadow_decisions
 * rows, using the SAME kalshiFeeCents() formula the live bot uses.
 */
export async function resolveMarketLearningV2ForPeriod(periodOpenTs: Date, direction: "up" | "down", _settledPrice: number | null): Promise<void> {
  try {
    const obsRows = await db.select({
      id:          marketObservations.id,
      yesAskCents: marketObservations.yesAskCents,
      noAskCents:  marketObservations.noAskCents,
    }).from(marketObservations)
      .where(and(eq(marketObservations.periodOpenTs, periodOpenTs), isNull(marketObservations.feeNetIfYesCents)));

    for (const row of obsRows) {
      if (row.yesAskCents == null && row.noAskCents == null) continue;
      const feeNetIfYesCents = row.yesAskCents != null
        ? (direction === "up" ? 100 : 0) - row.yesAskCents - kalshiFeeCents(row.yesAskCents)
        : null;
      const feeNetIfNoCents = row.noAskCents != null
        ? (direction === "down" ? 100 : 0) - row.noAskCents - kalshiFeeCents(row.noAskCents)
        : null;
      await db.update(marketObservations)
        .set({ feeNetIfYesCents, feeNetIfNoCents })
        .where(eq(marketObservations.id, row.id));
    }

    const decRows = await db.select({
      id:       shadowDecisions.id,
      side:     shadowDecisions.side,
      askCents: shadowDecisions.askCents,
      action:   shadowDecisions.action,
    }).from(shadowDecisions)
      .where(and(eq(shadowDecisions.periodOpenTs, periodOpenTs), isNull(shadowDecisions.settleSide)));

    for (const row of decRows) {
      const won = (row.side === "YES" && direction === "up") || (row.side === "NO" && direction === "down");
      const feeNetCents = row.action === "SKIP" ? null : (won ? 100 : 0) - row.askCents - kalshiFeeCents(row.askCents);
      await db.update(shadowDecisions)
        .set({ settleSide: direction, feeNetCents, resolvedAt: new Date() })
        .where(eq(shadowDecisions.id, row.id));
    }
  } catch (err) {
    console.warn("[market-learning-v2] resolution failed for period", periodOpenTs.toISOString(), (err as Error).message);
  }
}

// ── Reporting ────────────────────────────────────────────────────────────

export interface MarketLearningV2Report {
  mode: LearningMode;
  policyVersion: string;
  sizeMult: number;
  totalObservedV2: number;
  totalResolvedV2: number;
  buckets: Array<{ key: string; n: number; upRate: number }>;
  shadowDecisions: {
    totalLogged: number;
    totalResolved: number;
    takenCount: number;
    skipCount: number;
    skipRate: number;
    weeklyFeeNetCents: number;
    weeklyFeeNetVsLeanBaselineNote: string;
  };
  passFail: ShadowPassFailResult;
}

export async function getMarketLearningV2Report(): Promise<MarketLearningV2Report> {
  const state = await getLearningState();

  const [totalObsRow]    = await db.select({ n: sql<number>`count(*)` }).from(marketObservations).where(isNotNull(marketObservations.leadExchangeDelta));
  const [resolvedObsRow] = await db.select({ n: sql<number>`count(*)` }).from(marketObservations).where(and(isNotNull(marketObservations.leadExchangeDelta), isNotNull(marketObservations.settledDirection)));

  const allDecisions = await db.select({
    action:      shadowDecisions.action,
    resolvedAt:  shadowDecisions.resolvedAt,
    feeNetCents: shadowDecisions.feeNetCents,
  }).from(shadowDecisions);

  const totalLogged   = allDecisions.length;
  const totalResolved = allDecisions.filter(d => d.resolvedAt != null).length;
  const skipCount     = allDecisions.filter(d => d.action === "SKIP").length;
  const takenCount    = totalLogged - skipCount;
  const skipRate      = totalLogged > 0 ? skipCount / totalLogged : 0;

  const weekAgoMs = Date.now() - 7 * 24 * 60 * 60_000;
  const weeklyFeeNetCents = allDecisions
    .filter(d => d.action !== "SKIP" && d.resolvedAt && d.resolvedAt.getTime() >= weekAgoMs)
    .reduce((sum, d) => sum + (d.feeNetCents ?? 0), 0);

  const passFail = await evaluateShadowPassFail();

  return {
    mode: state.mode,
    policyVersion: state.policyVersion,
    sizeMult: state.sizeMult,
    totalObservedV2: Number(totalObsRow?.n ?? 0),
    totalResolvedV2: Number(resolvedObsRow?.n ?? 0),
    buckets: Array.from(shadowBucketCache.entries()).map(([key, row]) => ({ key, n: row.n, upRate: row.upRate })),
    shadowDecisions: {
      totalLogged,
      totalResolved,
      takenCount,
      skipCount,
      skipRate,
      weeklyFeeNetCents,
      weeklyFeeNetVsLeanBaselineNote:
        "Compared against a neutral 0c (never-trade) baseline. A byte-exact replay against backtest-lab-v5's POLICY_LEAN over the same periods is a documented follow-up, not yet wired — see market-learning-v2-2026-08-24.md.",
    },
    passFail,
  };
}

// ── Lifecycle ────────────────────────────────────────────────────────────

let v2RefreshTimer: NodeJS.Timeout | null = null;

/** Called once from market-learning.ts's startMarketLearning(). Refreshes the shadow bucket cache and checks for a canary auto-revert every 5m — the auto-revert check is a no-op while mode is 'shadow' (the only mode this build ever sets). */
export function startMarketLearningV2(): void {
  if (v2RefreshTimer) return;
  void refreshShadowBuckets();
  void autoRevertCanaryIfFailing();
  v2RefreshTimer = setInterval(() => {
    void refreshShadowBuckets();
    void autoRevertCanaryIfFailing();
  }, V2_REFRESH_MS);
  console.info("[market-learning-v2] Started — shadow EV bucket refresh + canary auto-revert check every 5m (mode governs all live impact; default 'shadow' = zero live effect)");
}
