/**
 * jsonl-rotate — size/age rotation for chatty observational JSONL traces
 * (evaluate-decision-trace.jsonl ≈ 310 MB, regime-decision-trace.jsonl ≈ 75 MB
 * of the 1 GB Fly volume on 2026-09-24).
 *
 * When the live file exceeds maxBytes it is renamed to
 * `<name>.<UTC-stamp>.jsonl`, gzipped in the background (stream, libuv pool)
 * to `.jsonl.gz`, and the raw copy removed. Archives beyond `keep` or older
 * than `maxAgeDays` are deleted. Appends continue into a fresh file.
 *
 * ONLY for opt-in observational traces. Never used for calibration / shadow
 * ledgers, paper trades, scars or episodes. Never throws.
 */
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { pipeline } from "node:stream/promises";

export type RotateOpts = {
  maxBytes: number;
  keep: number;
  maxAgeDays: number;
  /** Min ms between stat() checks per file (default 60 s). */
  checkEveryMs?: number;
  nowMs?: number;
};

export const DECISION_TRACE_ROTATE: RotateOpts = {
  maxBytes: 50 * 1024 * 1024,
  keep: 3,
  maxAgeDays: 14,
};
export const REGIME_TRACE_ROTATE: RotateOpts = {
  maxBytes: 20 * 1024 * 1024,
  keep: 3,
  maxAgeDays: 14,
};

const lastCheck = new Map<string, number>();
const gzipInFlight = new Set<string>();

export function resetJsonlRotateForTests(): void {
  lastCheck.clear();
}

function stamp(ms: number): string {
  return new Date(ms).toISOString().replace(/[-:]/g, "").replace(/\..*$/, "Z");
}

/** Archive files for `file`, newest first: <base>.<stamp>.jsonl[.gz]. */
export function listArchives(file: string): string[] {
  const dir = path.dirname(file);
  const base = path.basename(file, ".jsonl");
  let names: string[] = [];
  try {
    names = fs.readdirSync(dir);
  } catch {
    return [];
  }
  const re = new RegExp(`^${base.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\.\\d{8}T\\d{6}Z(-\\d+)?\\.jsonl(\\.gz)?$`);
  return names.filter((n) => re.test(n)).sort().reverse().map((n) => path.join(dir, n));
}

export function pruneArchives(file: string, opts: RotateOpts): string[] {
  const nowMs = opts.nowMs ?? Date.now();
  const removed: string[] = [];
  const archives = listArchives(file);
  archives.forEach((a, i) => {
    if (gzipInFlight.has(a)) return;
    let tooOld = false;
    try {
      tooOld = nowMs - fs.statSync(a).mtimeMs > opts.maxAgeDays * 86_400_000;
    } catch {
      return;
    }
    if (i >= opts.keep || tooOld) {
      try {
        fs.unlinkSync(a);
        removed.push(a);
      } catch {
        /* ignore */
      }
    }
  });
  return removed;
}

async function gzipAndRemove(raw: string): Promise<void> {
  gzipInFlight.add(raw);
  try {
    await pipeline(fs.createReadStream(raw), zlib.createGzip({ level: 6 }), fs.createWriteStream(`${raw}.gz`));
    fs.unlinkSync(raw);
  } catch {
    // Keep the raw archive if gzip failed; prune still bounds the count.
    try { fs.rmSync(`${raw}.gz`, { force: true }); } catch { /* ignore */ }
  } finally {
    gzipInFlight.delete(raw);
  }
}

/**
 * Rotate `file` if it exceeds maxBytes. Sync rename (cheap); gzip async.
 * Returns the archive path (pre-gzip) when rotated, else null.
 */
export function maybeRotateJsonl(
  file: string,
  opts: RotateOpts,
): { rotated: string | null; gzip: Promise<void> | null } {
  const nowMs = opts.nowMs ?? Date.now();
  const every = opts.checkEveryMs ?? 60_000;
  const prev = lastCheck.get(file) ?? 0;
  if (every > 0 && nowMs - prev < every) return { rotated: null, gzip: null };
  lastCheck.set(file, nowMs);
  try {
    if (!fs.existsSync(file)) return { rotated: null, gzip: null };
    const size = fs.statSync(file).size;
    if (size <= opts.maxBytes) return { rotated: null, gzip: null };
    const dir = path.dirname(file);
    const base = path.basename(file, ".jsonl");
    let target = path.join(dir, `${base}.${stamp(nowMs)}.jsonl`);
    for (let i = 1; fs.existsSync(target) || fs.existsSync(`${target}.gz`); i++) {
      target = path.join(dir, `${base}.${stamp(nowMs)}-${i}.jsonl`);
    }
    fs.renameSync(file, target);
    const gz = gzipAndRemove(target).then(() => {
      pruneArchives(file, { ...opts, nowMs });
    });
    pruneArchives(file, { ...opts, nowMs });
    return { rotated: target, gzip: gz };
  } catch {
    return { rotated: null, gzip: null };
  }
}
