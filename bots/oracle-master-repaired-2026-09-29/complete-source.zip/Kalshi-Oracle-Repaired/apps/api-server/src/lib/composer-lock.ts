/**
 * Composer / Aria / v2 lock.
 *
 * autoMode is NOT "desk on" and is NOT Aria. On paper desk v2 it stays FALSE
 * unless the operator types CONFIRM AUTO MODE (explicit Adapt arm). Live can
 * still Adapt with that phrase. The OLD composer that copied condition-adapter
 * over minConfidence / minVelocity / stops / window / minProbEdge is fail-closed
 * in trading-bot.ts even when autoMode is true.
 *
 * Desk on = enabled + paper. Aria (useExpertAgent) may only tighten after EV,
 * and only when a model is actually wired. autoMode v2 is suggest-only;
 * bounded_write is not implemented.
 *
 * applyComposerLocks is the single coerce so persist-restore and updateConfig
 * cannot disagree.
 */
import { applyFrozenCcLocks, restoreFrozenCcSaved, type FrozenCcLockableConfig } from "./frozen-cc.js";

export type ComposerLockConfig = {
  autoMode: boolean;
  autoPolicyMode?: string;
  autoModeV2Mode: "off" | "suggest" | "bounded_write";
  useExpertAgent: boolean;
  ariaModel: string;
  paperMode: boolean;
};

export type ComposerLockEnv = {
  openRouterKey?: string;
  /** Exact "LIVE REAL MONEY" — required to keep paperMode false. */
  confirmLiveRealMoney?: string;
  /** Exact "CONFIRM AUTO MODE" — required to keep autoMode true on paper desk. */
  confirmAutoMode?: string;
};

/** Paper desk v2: autoMode stays false unless operator types this phrase. */
export const CONFIRM_AUTO_MODE_PHRASE = "CONFIRM AUTO MODE";

export type ComposerLockResult<T extends ComposerLockConfig> = {
  config: T;
  notes: string[];
};

export function applyComposerLocks<T extends ComposerLockConfig>(
  config: T,
  env: ComposerLockEnv = {},
): ComposerLockResult<T> {
  const next = { ...config };
  const notes: string[] = [];

  if (next.autoPolicyMode !== undefined && !["off", "shadow", "live"].includes(next.autoPolicyMode)) {
    next.autoPolicyMode = "off";
    notes.push("unknown autoPolicyMode forced off");
  }

  // Paper first — then autoMode lock sees the coerced paperMode.
  // HARD LOCK (unify 2026-09-24): paper-only desk. Anything but boolean true
  // (false, 0, null, "false", undefined) is coerced back to paper, phrase or not.
  if (next.paperMode !== true) {
    void env.confirmLiveRealMoney; // phrase no longer unlocks live on this build
    next.paperMode = true;
    notes.push("paperMode forced true — paper-only desk (hard lock)");
  }

  // Paper desk v2: autoMode false unless explicit CONFIRM AUTO MODE.
  // Composer gate-write stays fail-closed in evaluateEntry either way.
  if (next.autoMode === true) {
    if (env.confirmAutoMode === CONFIRM_AUTO_MODE_PHRASE) {
      // Operator explicitly armed Adapt on paper.
    } else {
      next.autoMode = false;
      notes.push("autoMode true refused on paper desk — type CONFIRM AUTO MODE to arm Adapt");
    }
  }

  if (next.autoModeV2Mode === "bounded_write") {
    next.autoModeV2Mode = "suggest";
    notes.push("autoMode v2 bounded_write not implemented — staying suggest-only.");
  }

  const modelReady = Boolean(next.ariaModel?.trim()) && Boolean(env.openRouterKey?.trim());
  if (next.useExpertAgent && !modelReady) {
    next.useExpertAgent = false;
    notes.push("useExpertAgent refused — no Aria model/key wired. Guide-only once a model exists.");
  }

  // FROZEN_CC runs last so it wins over every other coerce above.
  let frozen = applyFrozenCcLocks(next as T & FrozenCcLockableConfig);
  if ((next as { frozenCcMode?: boolean }).frozenCcMode !== true) {
    frozen = restoreFrozenCcSaved(frozen.config as T & FrozenCcLockableConfig) as typeof frozen;
  }
  notes.push(...frozen.notes);
  return { config: frozen.config as T, notes };
}

/** Aria may reduce confidence, never boost a tick over the operator floor. */
export function clampAriaConfidenceAdj(adj: number): number {
  if (!Number.isFinite(adj)) return 0;
  return Math.min(0, adj);
}
