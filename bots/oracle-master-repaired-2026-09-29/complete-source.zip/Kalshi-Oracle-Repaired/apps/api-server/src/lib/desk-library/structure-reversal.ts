/**
 * desk-library/structure-reversal.ts — settlement book, shadow caller.
 *
 * Wraps lib/structure-reversal.ts. LIVE_APPLY false. Not a live StrategyId.
 * TradingBot stays director — this predicate cannot placeOrder.
 *
 * paperMode true. autoMode false. Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR.
 */
import {
  LIVE_APPLY as ENGINE_LIVE,
  LIVE_APPLY_ENABLED as ENGINE_LIVE_ENABLED,
  evaluateStructureReversal,
  peekStructureReversal,
  type StructureReversalEval,
  type StructureReversalSnapshot,
} from "../structure-reversal.js";
import { cheapSideWinRate } from "../cheap-side-15m.js";
import { computeTradeEV } from "../trade-path.js";
import { EV_FLOOR } from "../admission.js";

export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
export const AUTO_MODE = false as const;

export type StructureReversalTakeOpts = {
  snapshot?: StructureReversalSnapshot | null;
  secsRemaining?: number | null;
  yesAsk?: number | null;
  noAsk?: number | null;
  pWin?: number | null;
};

export type StructureReversalTakeDecision = {
  take: boolean;
  reason: string;
  side: "yes" | "no" | "skip";
  pWin: number | null;
};

function skip(reason: string): StructureReversalTakeDecision {
  return { take: false, reason, side: "skip", pWin: null };
}

/**
 * Shadow predicate. LIVE_APPLY true → refuse. Unarmed → skip.
 * EV still goes through computeTradeEV (3¢ floor, not cut).
 */
export function shouldStructureReversalTake(opts: StructureReversalTakeOpts): StructureReversalTakeDecision {
  if (LIVE_APPLY || LIVE_APPLY_ENABLED || ENGINE_LIVE || ENGINE_LIVE_ENABLED) {
    return skip("live_apply_refused");
  }
  const snap = opts.snapshot ?? peekStructureReversal();
  if (!snap.armed || !snap.side) {
    return skip(snap.skipReason ?? "not_armed");
  }
  const ask = snap.side === "yes"
    ? (opts.yesAsk ?? snap.askCents)
    : (opts.noAsk ?? snap.askCents);
  if (typeof ask !== "number" || !Number.isFinite(ask) || ask <= 0) {
    return skip("no_ask");
  }
  const secs = opts.secsRemaining ?? 0;
  const pWin = opts.pWin != null && Number.isFinite(opts.pWin)
    ? opts.pWin
    : cheapSideWinRate(ask, secs / 60);
  const ev = computeTradeEV({
    entryPriceCents: ask,
    winRate: pWin,
    minEVCents: EV_FLOOR,
    secsRemaining: secs,
  });
  if (!ev.passes || ev.netEV < EV_FLOOR) {
    return skip("ev_below_floor");
  }
  return {
    take: true,
    reason: snap.reason,
    side: snap.side,
    pWin,
  };
}

export { evaluateStructureReversal };
export type { StructureReversalEval, StructureReversalSnapshot };
