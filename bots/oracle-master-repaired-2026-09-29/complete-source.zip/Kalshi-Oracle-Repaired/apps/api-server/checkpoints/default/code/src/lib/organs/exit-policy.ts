/**
 * exit-policy organ — PATH_RIDE decideExit first-match law (operator A).
 *
 * Owns the documented first-match order. Implementation stays in
 * path-ride.decidePathRideExit + exit-first-match.mayFlickerSoftExit.
 * No new branches. No EXIT rewrite of the law already shipped.
 *
 * First-match (strict):
 *   1. ruin ≤5¢ immediate / ≤8¢ after 20s (mark>0 only; markAsk 0/neg ignored)
 *   2. age < 20s → HOLD
 *   3. VALID + green → PATH_RIDE_TP / HIGH_ODDS_EXIT only (2×/85; all sizes HOLD through 1.5× (no HALF_RIDE);
 *      never TB/LAG_FLIP/fuse/HA_FLIP/GAMMA/PIN; live markCents outranks disagreeing markAsk)
 *      green = filled-side mark>entry (YES+NO) OR caller ticketGreen; lying false cannot un-green
 *   4. BROKEN persist≥20s + adverse≥3¢ → soft/TB exits may fire
 *   5. else HOLD
 *
 * TradingBot PATH_RIDE call sites import decideExit / decidePathRideExit
 * from this surface (same semantics as path-ride gold).
 */
import {
  decidePathRideExit,
  type PathRideExit,
  type PathRideExitInput,
  PATH_RIDE_CATASTROPHIC_CENTS,
  PATH_RIDE_CATASTROPHIC_SUSTAIN_MS,
  PATH_RIDE_MIN_HOLD_MS,
  PATH_RIDE_RUIN_CENTS,
  pathRideIsRuinMark,
  holdHardFloorMaySell,
} from "../path-ride.js";
import {
  mayFlickerSoftExit,
  falsifyValidGreenExit,
  EXIT_FORBIDDEN_ON_VALID_GREEN,
  type ExitThesisStatus,
} from "./exit-first-match.js";

export const EXIT_POLICY_LOADED = true as const;
/** Durable falsify line when organ is missing from the live wire. */
export const EXIT_POLICY_NOT_LOADED = "[EXIT_POLICY] not loaded";

export function formatExitPolicyLoadedLog(): string {
  return "[EXIT_POLICY] loaded";
}

export {
  decidePathRideExit,
  PATH_RIDE_CATASTROPHIC_CENTS,
  PATH_RIDE_CATASTROPHIC_SUSTAIN_MS,
  PATH_RIDE_MIN_HOLD_MS,
  PATH_RIDE_RUIN_CENTS,
  pathRideIsRuinMark,
  holdHardFloorMaySell,
  mayFlickerSoftExit,
  falsifyValidGreenExit,
  EXIT_FORBIDDEN_ON_VALID_GREEN,
};
export type { PathRideExit, PathRideExitInput, ExitThesisStatus };

/** PATH_RIDE decideExit — thin alias; first-match law above. */
export function decideExit(input: PathRideExitInput): PathRideExit {
  return decidePathRideExit(input);
}

export function leftoverExitStackMayRunOnPathRide(): false {
  return false;
}

/** Leftover TB/ARIA/hold/trail stack. Paper and frozen CC never run it. */
export function leftoverExitStackMayRun(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  if (cfg.paperMode === true || cfg.frozenCcMode === true) return false;
  return true;
}

export function leftoverExitStackHostDenied(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  return leftoverExitStackMayRun(cfg) === false;
}


/**
 * Log-only after PATH_RIDE decideExit — disposition stays authoritative in
 * decideExit / path-ride. Peeled from trading-bot (void no-op; no judgment).
 */
export function classifyExitDecision(_ride: unknown): void {
  // Log-only after decideExit — PATH_RIDE disposition stays authoritative.
}

/** Named leftover exit runner. Paper or frozen config returns without invoking `run`. */
export function leftoverExitStackRun(
  cfg: { paperMode?: boolean; frozenCcMode?: boolean },
  run: () => Promise<void>,
): Promise<void> {
  if (!leftoverExitStackMayRun(cfg)) return Promise.resolve();
  return run();
}
