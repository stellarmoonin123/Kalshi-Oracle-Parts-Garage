/**
 * accounts/users.ts — user store. `id` (UUID) is the immutable ownership key.
 * `username` / `email` are normalised to lower-case so UNIQUE is
 * case-insensitive. `password_hash` never leaves this module except to the
 * login verifier: every outward shape goes through toPublicUser().
 */
import { accountsPool, withTransaction, type QueryClientLike } from "./db.js";
import { accountsReady } from "./migrate.js";
import { hashPassword } from "./passwords.js";

export type Role = "ADMIN" | "USER";
export type Status = "ACTIVE" | "DISABLED";

export interface UserRow {
  id: string;
  username: string;
  email: string;
  display_name: string;
  password_hash: string;
  role: Role;
  status: Status;
  must_change_password: boolean;
  created_at: Date;
  updated_at: Date;
  last_login_at: Date | null;
}

export interface PublicUser {
  id: string;
  username: string;
  email: string;
  displayName: string;
  role: Role;
  status: Status;
  mustChangePassword: boolean;
  createdAt: string;
  updatedAt: string;
  lastLoginAt: string | null;
}

const iso = (d: Date | string | null): string | null =>
  d == null ? null : (d instanceof Date ? d.toISOString() : new Date(d).toISOString());

/** The ONLY outward user shape. Never includes password_hash. */
export function toPublicUser(r: UserRow): PublicUser {
  return {
    id: r.id,
    username: r.username,
    email: r.email,
    displayName: r.display_name,
    role: r.role,
    status: r.status,
    mustChangePassword: r.must_change_password,
    createdAt: iso(r.created_at)!,
    updatedAt: iso(r.updated_at)!,
    lastLoginAt: iso(r.last_login_at),
  };
}

export class AccountError extends Error {
  constructor(readonly status: number, message: string, readonly code: string) {
    super(message);
  }
}

// ── Validation ───────────────────────────────────────────────────────────────

const USERNAME_RE = /^[a-z0-9][a-z0-9._-]{2,31}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function normalizeIdentifier(v: unknown): string {
  return typeof v === "string" ? v.trim().toLowerCase().slice(0, 254) : "";
}

export function normalizeUsername(v: unknown): string {
  const u = normalizeIdentifier(v);
  if (!USERNAME_RE.test(u)) {
    throw new AccountError(400, "Username must be 3–32 characters: letters, numbers, dot, dash or underscore.", "INVALID_USERNAME");
  }
  return u;
}

export function normalizeEmail(v: unknown): string {
  const e = normalizeIdentifier(v);
  if (e.length > 254 || !EMAIL_RE.test(e)) throw new AccountError(400, "Enter a valid email address.", "INVALID_EMAIL");
  return e;
}

export function normalizeDisplayName(v: unknown): string {
  const d = typeof v === "string" ? v.replace(/[\u0000-\u001f\u007f]/g, "").trim() : "";
  if (d.length < 1 || d.length > 80) throw new AccountError(400, "Display name must be 1–80 characters.", "INVALID_DISPLAY_NAME");
  return d;
}

export function normalizeRole(v: unknown): Role {
  if (v === "ADMIN" || v === "USER") return v;
  throw new AccountError(400, "Role must be ADMIN or USER.", "INVALID_ROLE");
}

function uniqueViolation(err: unknown): AccountError | null {
  const e = err as { code?: string; constraint?: string };
  if (e?.code !== "23505") return null;
  if (e.constraint === "oracle_users_email_unique") return new AccountError(409, "That email is already in use.", "EMAIL_TAKEN");
  return new AccountError(409, "That username is already taken.", "USERNAME_TAKEN");
}

// ── Queries ──────────────────────────────────────────────────────────────────

async function db(): Promise<QueryClientLike> {
  await accountsReady();
  return accountsPool();
}

export async function getUserById(id: string): Promise<UserRow | null> {
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  const { rows } = await (await db()).query<UserRow>("SELECT * FROM oracle_users WHERE id = $1", [id]);
  return rows[0] ?? null;
}

/** Username OR email, case-insensitive (both stored lower-case). */
export async function findUserByIdentifier(identifier: string): Promise<UserRow | null> {
  const id = normalizeIdentifier(identifier);
  if (!id) return null;
  const { rows } = await (await db()).query<UserRow>(
    "SELECT * FROM oracle_users WHERE username = $1 OR email = $1 ORDER BY (username = $1) DESC LIMIT 1",
    [id],
  );
  return rows[0] ?? null;
}

export async function listUsers(): Promise<UserRow[]> {
  const { rows } = await (await db()).query<UserRow>(
    "SELECT * FROM oracle_users ORDER BY role ASC, created_at ASC",
  );
  return rows;
}

export async function countActiveAdmins(c?: QueryClientLike): Promise<number> {
  const q = c ?? (await db());
  const { rows } = await q.query<{ n: number }>(
    "SELECT COUNT(*)::int AS n FROM oracle_users WHERE role = 'ADMIN' AND status = 'ACTIVE'",
  );
  return rows[0]?.n ?? 0;
}

export async function countAdmins(): Promise<number> {
  const { rows } = await (await db()).query<{ n: number }>("SELECT COUNT(*)::int AS n FROM oracle_users WHERE role = 'ADMIN'");
  return rows[0]?.n ?? 0;
}

export interface CreateUserInput {
  username: unknown;
  email: unknown;
  displayName: unknown;
  password: string;
  role: unknown;
  mustChangePassword?: boolean;
}

export async function createUser(input: CreateUserInput): Promise<UserRow> {
  const username = normalizeUsername(input.username);
  const email = normalizeEmail(input.email);
  const displayName = normalizeDisplayName(input.displayName);
  const role = normalizeRole(input.role);
  const passwordHash = await hashPassword(input.password);
  try {
    const { rows } = await (await db()).query<UserRow>(
      `INSERT INTO oracle_users (username, email, display_name, password_hash, role, status, must_change_password)
       VALUES ($1, $2, $3, $4, $5, 'ACTIVE', $6) RETURNING *`,
      [username, email, displayName, passwordHash, role, input.mustChangePassword !== false],
    );
    return rows[0]!;
  } catch (err) {
    throw uniqueViolation(err) ?? err;
  }
}

/**
 * Lock the active-admin set (FOR UPDATE) and refuse a change that would leave
 * zero ACTIVE ADMINs. Runs inside the caller's transaction.
 */
async function assertNotLastActiveAdmin(c: QueryClientLike, target: UserRow, next: { role: Role; status: Status }): Promise<void> {
  const wasActiveAdmin = target.role === "ADMIN" && target.status === "ACTIVE";
  const staysActiveAdmin = next.role === "ADMIN" && next.status === "ACTIVE";
  if (!wasActiveAdmin || staysActiveAdmin) return;
  const { rows } = await c.query<{ id: string }>(
    "SELECT id FROM oracle_users WHERE role = 'ADMIN' AND status = 'ACTIVE' FOR UPDATE",
  );
  if (rows.filter((r) => r.id !== target.id).length === 0) {
    throw new AccountError(409, "This is the last active Administrator. Add or enable another Administrator first.", "LAST_ADMIN");
  }
}

export interface UpdateUserInput {
  username?: unknown;
  email?: unknown;
  displayName?: unknown;
  role?: unknown;
  status?: Status;
}

/** Generic guarded update (admin edit / enable / disable / self profile). */
export async function updateUser(id: string, patch: UpdateUserInput): Promise<UserRow> {
  await accountsReady();
  try {
    return await withTransaction(async (c) => {
      const cur = (await c.query<UserRow>("SELECT * FROM oracle_users WHERE id = $1 FOR UPDATE", [id])).rows[0];
      if (!cur) throw new AccountError(404, "User not found.", "NOT_FOUND");
      const next = {
        username: patch.username !== undefined ? normalizeUsername(patch.username) : cur.username,
        email: patch.email !== undefined ? normalizeEmail(patch.email) : cur.email,
        displayName: patch.displayName !== undefined ? normalizeDisplayName(patch.displayName) : cur.display_name,
        role: patch.role !== undefined ? normalizeRole(patch.role) : cur.role,
        status: patch.status ?? cur.status,
      };
      if (next.status !== "ACTIVE" && next.status !== "DISABLED") throw new AccountError(400, "Invalid status.", "INVALID_STATUS");
      await assertNotLastActiveAdmin(c, cur, next);
      const { rows } = await c.query<UserRow>(
        `UPDATE oracle_users SET username = $2, email = $3, display_name = $4, role = $5, status = $6, updated_at = now()
         WHERE id = $1 RETURNING *`,
        [id, next.username, next.email, next.displayName, next.role, next.status],
      );
      if (next.status === "DISABLED" && cur.status !== "DISABLED") {
        await c.query("DELETE FROM oracle_sessions WHERE user_id = $1", [id]);
      }
      return rows[0]!;
    });
  } catch (err) {
    throw uniqueViolation(err) ?? err;
  }
}

/**
 * Replace the password hash. `mustChange` true for admin resets. Sessions are
 * invalidated: all of them, or all except `keepSessionId` (self change).
 */
export async function setPassword(id: string, plain: string, opts: { mustChange: boolean; keepSessionId?: string | null }): Promise<UserRow> {
  const passwordHash = await hashPassword(plain);
  await accountsReady();
  return withTransaction(async (c) => {
    const { rows } = await c.query<UserRow>(
      `UPDATE oracle_users SET password_hash = $2, must_change_password = $3, updated_at = now()
       WHERE id = $1 RETURNING *`,
      [id, passwordHash, opts.mustChange],
    );
    if (!rows[0]) throw new AccountError(404, "User not found.", "NOT_FOUND");
    if (opts.keepSessionId) {
      await c.query("DELETE FROM oracle_sessions WHERE user_id = $1 AND id <> $2", [id, opts.keepSessionId]);
    } else {
      await c.query("DELETE FROM oracle_sessions WHERE user_id = $1", [id]);
    }
    return rows[0];
  });
}

/** Opportunistic Argon2 parameter upgrade after a successful login. */
export async function replacePasswordHashOnly(id: string, newHash: string): Promise<void> {
  await (await db()).query("UPDATE oracle_users SET password_hash = $2 WHERE id = $1", [id, newHash]);
}

export async function touchLastLogin(id: string): Promise<void> {
  await (await db()).query("UPDATE oracle_users SET last_login_at = now() WHERE id = $1", [id]);
}
