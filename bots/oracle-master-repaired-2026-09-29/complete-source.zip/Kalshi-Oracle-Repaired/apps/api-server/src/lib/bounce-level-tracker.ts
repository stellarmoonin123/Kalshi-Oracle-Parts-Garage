/**
 * bounce-level-tracker.ts — Task #341.
 *
 * "Boost confidence for reversal trades that happen at price levels BTC has
 * actually bounced off before."
 *
 * A lightweight zigzag/swing detector fed one raw BTC price sample per tick
 * (same cadence as velocity-reversal-detector.ts). Whenever price completes a
 * directional leg of at least ZIGZAG_THRESHOLD_DOLLARS and then reverses by
 * the same threshold, the turning point is recorded as a "bounce" at that
 * price level, tagged with which way price turned there:
 *   - 'up'   — price fell into this level then turned upward (support-like)
 *   - 'down' — price rose into this level then turned downward (resistance-like)
 *
 * Bounces are bucketed into $BAND_WIDTH-wide price bands (raw BTC price, not
 * relative to any one contract's floor strike — the same $63,750 zone can
 * recur across many different 15-minute contracts) and persisted to
 * data/bounce-level-memory.json so evidence accumulates across restarts,
 * mirroring pattern-learner.ts's persistence approach.
 *
 * Consumers (trading-bot.ts's confidence-bonus step) call getBounceInfo() at
 * decision time to check whether the CURRENT price sits in a band with a
 * real, recent history of turning the same direction the reversal strategy
 * is now betting on — only reversal-capable strategies (CHANNEL_BOUNCE,
 * MEAN_REVERSION_STRETCH, BOLLINGER_BAND, FAKEOUT_FADE,
 * VELOCITY_STALL_REVERSAL) consult this; it is not part of StrategyObservation
 * or any strategy's own evaluate() — it is an environment-level enrichment
 * applied once at the top of the confidence pipeline, same tier as the
 * existing floor-proximity/velocity-alignment/MTF bonuses.
 *
 * Deliberately boost-only (no penalty term): the task asked for a confidence
 * boost when a real bounce history exists, not a new veto. Evidence
 * requirements (MIN_EVIDENCE, lookback window) keep a single fluke reversal
 * from moving confidence.
 */

import fs   from 'fs';
import path from 'path';

// ── Paths — same process.cwd()-relative convention as pattern-learner.ts.
// See that file's comment for why __dirname would silently break in the
// esbuild-bundled production run.
const DATA_DIR   = path.resolve(process.env.BACKTEST_SCRATCH_DIR || process.cwd(), 'data');
const STORE_FILE = path.join(DATA_DIR, 'bounce-level-memory.json');

// ── Tunables ─────────────────────────────────────────────────────────────────
const ZIGZAG_THRESHOLD_DOLLARS = 15;                      // min leg size before a reversal counts
const BAND_WIDTH_DOLLARS       = 40;                      // price-band bucket width
const LOOKBACK_MS              = 21 * 24 * 3600 * 1000;   // only trust bounces from the last 21 days
const MAX_PER_BAND             = 40;                      // cap stored bounces per band (ring buffer)
const MIN_EVIDENCE             = 2;                       // need >=2 same-direction bounces to trust a band
const MAX_BONUS                = 8;                       // confidence-point cap (same order as other bonuses)
const BONUS_PER_BOUNCE         = 2;

export type BounceDirection = 'up' | 'down';

interface BounceEvent {
  ts:  number;             // unix ms
  dir: BounceDirection;
}

type BounceStore = Record<string, BounceEvent[]>; // key = band label, e.g. "63760"

export interface BounceInfo {
  band:              number;
  bouncedUpCount:    number;
  bouncedDownCount:  number;
  dominant:          BounceDirection | 'mixed';
  lastBounceAgeMs:   number;
}

// ── Persisted store (module singleton — one bot process) ──────────────────────

let _store: BounceStore | null = null;
let _writeTimer: ReturnType<typeof setTimeout> | null = null;

function getStore(): BounceStore {
  if (_store) return _store;
  try {
    if (fs.existsSync(STORE_FILE)) {
      _store = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8')) as BounceStore;
    }
  } catch { /* corrupt file — start fresh, never crash the bot over this */ }
  _store = _store ?? {};
  return _store;
}

function scheduleWrite(): void {
  if (_writeTimer) clearTimeout(_writeTimer);
  _writeTimer = setTimeout(async () => {
    try {
      await fs.promises.mkdir(DATA_DIR, { recursive: true });
      await fs.promises.writeFile(STORE_FILE, JSON.stringify(getStore(), null, 2));
    } catch { /* non-fatal */ }
  }, 1_000);
}

function bandFor(price: number): number {
  return Math.round(price / BAND_WIDTH_DOLLARS) * BAND_WIDTH_DOLLARS;
}

function recordBounce(price: number, dir: BounceDirection, ts: number): void {
  const store = getStore();
  const key = String(bandFor(price));
  const arr = store[key] ?? (store[key] = []);
  arr.push({ ts, dir });
  // Ring-buffer cap — keep only the most recent MAX_PER_BAND entries.
  if (arr.length > MAX_PER_BAND) arr.splice(0, arr.length - MAX_PER_BAND);
  scheduleWrite();
}

// ── Zigzag leg-tracking state (module singleton — one live price stream) ──────

interface LegState {
  direction:    BounceDirection | null; // direction of the CURRENT leg (null = not yet established)
  extremePrice: number;                 // running high (up leg) / low (down leg) of the current leg
}

let leg: LegState = { direction: null, extremePrice: NaN };

/**
 * Feed one raw price sample. Fed every tick regardless of whether any
 * reversal strategy is currently enabled, mirroring velocity-reversal-
 * detector.ts — the leg state needs continuous observation to stay accurate;
 * strategy enablement gating happens later, same as every other strategy.
 */
export function recordBounceTick(price: number, ts: number): void {
  if (!Number.isFinite(price)) return;

  if (leg.direction === null) {
    // Not yet in a leg — just anchor the extreme; direction is established
    // once price moves ZIGZAG_THRESHOLD_DOLLARS away from it in one call below.
    if (!Number.isFinite(leg.extremePrice)) { leg.extremePrice = price; return; }
    const delta = price - leg.extremePrice;
    if (Math.abs(delta) >= ZIGZAG_THRESHOLD_DOLLARS) {
      leg = { direction: delta > 0 ? 'up' : 'down', extremePrice: price };
    }
    return;
  }

  if (leg.direction === 'up') {
    if (price > leg.extremePrice) { leg.extremePrice = price; return; }
    const pullback = leg.extremePrice - price;
    if (pullback >= ZIGZAG_THRESHOLD_DOLLARS) {
      // Price rallied into leg.extremePrice then turned down — resistance-like bounce.
      recordBounce(leg.extremePrice, 'down', ts);
      leg = { direction: 'down', extremePrice: price };
    }
    return;
  }

  // leg.direction === 'down'
  if (price < leg.extremePrice) { leg.extremePrice = price; return; }
  const bounceUp = price - leg.extremePrice;
  if (bounceUp >= ZIGZAG_THRESHOLD_DOLLARS) {
    // Price fell into leg.extremePrice then turned up — support-like bounce.
    recordBounce(leg.extremePrice, 'up', ts);
    leg = { direction: 'up', extremePrice: price };
  }
}

/**
 * Look up whether `price`'s band has a real, recent bounce history. Returns
 * undefined when there isn't enough evidence to trust (fewer than
 * MIN_EVIDENCE bounces within LOOKBACK_MS, or the split is exactly tied).
 */
export function getBounceInfo(price: number, now: number): BounceInfo | undefined {
  const band = bandFor(price);
  const arr = getStore()[String(band)];
  if (!arr || arr.length === 0) return undefined;

  const recent = arr.filter(e => now - e.ts <= LOOKBACK_MS);
  if (recent.length === 0) return undefined;

  let up = 0, down = 0, lastTs = 0;
  for (const e of recent) {
    if (e.dir === 'up') up++; else down++;
    if (e.ts > lastTs) lastTs = e.ts;
  }
  if (Math.max(up, down) < MIN_EVIDENCE) return undefined;

  const dominant: BounceDirection | 'mixed' = up === down ? 'mixed' : (up > down ? 'up' : 'down');
  return { band, bouncedUpCount: up, bouncedDownCount: down, dominant, lastBounceAgeMs: now - lastTs };
}

/**
 * Confidence-point bonus for a reversal-capable strategy's trade direction,
 * given the current price's bounce history. 0 when there's no evidence, the
 * evidence is mixed, or the trade direction disagrees with the dominant
 * historical bounce direction (no penalty is applied in that case — see
 * file header). Scales with evidence strength, capped at MAX_BONUS.
 */
export function getBounceConfidenceBonus(price: number, now: number, side: 'yes' | 'no'): number {
  const info = getBounceInfo(price, now);
  if (!info || info.dominant === 'mixed') return 0;
  const aligned = (side === 'yes' && info.dominant === 'up') || (side === 'no' && info.dominant === 'down');
  if (!aligned) return 0;
  const dominantCount = Math.max(info.bouncedUpCount, info.bouncedDownCount);
  return Math.min(MAX_BONUS, dominantCount * BONUS_PER_BOUNCE);
}

// ── Test/introspection helpers ─────────────────────────────────────────────

/** Reset all in-memory state (tests only — does not touch the persisted file). */
export function resetBounceLevelsForTest(): void {
  _store = {};
  leg = { direction: null, extremePrice: NaN };
  if (_writeTimer) { clearTimeout(_writeTimer); _writeTimer = null; }
}

/** Total number of price bands with at least one recorded bounce. */
export function getBounceLevelBandCount(): number {
  return Object.keys(getStore()).length;
}
