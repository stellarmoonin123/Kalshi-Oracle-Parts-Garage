/**
 * candlestick-patterns.ts — Sakata Goho reversal/continuation pattern detector
 *
 * Sourced from "The Candlestick Trading Bible" (Munehisa Homma) and the
 * classical "Sakata's Five Methods" (Sakata Goho) framework that grew out of
 * his 18th-century rice-trading records. Two pieces of that tradition are
 * implemented here:
 *
 *  1. Heikin Ashi smoothing — Homma's own technique for averaging out noisy
 *     prints before reading the shape of a move. We run pattern detection on
 *     Heikin Ashi bars (not raw OHLC) so a single noisy tick doesn't create a
 *     false engulfing/hammer signal.
 *
 *  2. Sanpei ("three soldiers/crows") + classic single/double-candle reversal
 *     shapes — Bullish/Bearish Engulfing, Hammer, Shooting Star, Doji, Three
 *     White Soldiers, Three Black Crows. These are the patterns with the most
 *     consistent, well-documented statistical edge across markets; more
 *     exotic Sakata shapes (Sanzan/Sansen/Sanku/Sanpo) need swing-level
 *     structure that doesn't resolve inside a 15-minute contract window, so
 *     they're deliberately left out rather than approximated.
 *
 * Data source: fetchRealCandles() (Binance→Coinbase, non-interpolated 1m
 * candles) — NOT the 500ms tick buffer, which is far too fine-grained/noisy
 * to resolve a candlestick shape, and NOT fetchKalshiCandles(), which
 * linearly interpolates sub-15-minute granularity and would leak lookahead
 * bias into pattern detection (see market-candles.ts's module doc).
 *
 * This is intentionally orthogonal to the existing velocity/momentum
 * strategies (VELOCITY_MOMENTUM, BREAKOUT_CAPTURE, etc.) — it reads candle
 * *shape* (open/high/low/close geometry), not tick-to-tick speed, so it
 * shouldn't co-fire with them purely because BTC is moving fast.
 */

import { fetchRealCandles, type RealCandle } from './market-candles.js';

const REFRESH_MS = 60_000;      // re-poll every 60s — plenty for 1m-candle patterns
const STALE_MS = 150_000;       // treat cached result as unusable after 2.5 refresh cycles
const LOOKBACK_CANDLES = 45;    // enough history for prior-trend context + the recent-events scan window
const RECENT_SCAN_BARS_BACK = 20; // how many bars back scanRecentPatterns() looks for the Markets page list

export type CandlePatternName =
  | 'BULLISH_ENGULFING'
  | 'BEARISH_ENGULFING'
  | 'HAMMER'
  | 'SHOOTING_STAR'
  | 'DOJI'
  | 'THREE_WHITE_SOLDIERS'
  | 'THREE_BLACK_CROWS'
  | 'BULLISH_HARAMI'
  | 'BEARISH_HARAMI'
  | 'PIERCING_LINE'
  | 'DARK_CLOUD_COVER'
  | 'TWEEZER_TOP'
  | 'TWEEZER_BOTTOM'
  | 'MORNING_STAR'
  | 'EVENING_STAR'
  | 'MORNING_DOJI_STAR'
  | 'EVENING_DOJI_STAR'
  | 'BULLISH_MARUBOZU'
  | 'BEARISH_MARUBOZU'
  | 'SPINNING_TOP'
  | 'HANGING_MAN'
  | 'INVERTED_HAMMER'
  | 'DRAGONFLY_DOJI'
  | 'GRAVESTONE_DOJI'
  | 'LONG_LEGGED_DOJI'
  | 'DOUBLE_BOTTOM'
  | 'DOUBLE_TOP';

/**
 * Patterns treated as a genuine "market is bottoming/topping" reversal read
 * for live risk purposes (2026-08-18, user report: "bot isn't identifying
 * bottom reversal chart patterns"). Deliberately NOT derived from
 * candlestick-pattern-catalog.ts — that file documents itself as
 * display/education-only and explicitly promises it "never feeds sizing,
 * EV, or gating logic"; duplicating its reliability/direction fields here
 * would quietly break that boundary. This is its own curated subset: bullish
 * (resp. bearish) patterns whose classical definition IS a reversal-off-an-
 * extreme (excludes continuation reads like Marubozu/Three White Soldiers
 * and excludes the weakest single-signal reads like plain Tweezer/Doji) so a
 * live stop only fires on a read with real conviction behind it.
 */
export const BOTTOM_REVERSAL_PATTERNS: ReadonlySet<CandlePatternName> = new Set([
  'HAMMER', 'INVERTED_HAMMER', 'DRAGONFLY_DOJI', 'BULLISH_ENGULFING',
  'BULLISH_HARAMI', 'PIERCING_LINE', 'MORNING_STAR', 'MORNING_DOJI_STAR',
  'DOUBLE_BOTTOM',
]);
export const TOP_REVERSAL_PATTERNS: ReadonlySet<CandlePatternName> = new Set([
  'SHOOTING_STAR', 'HANGING_MAN', 'GRAVESTONE_DOJI', 'BEARISH_ENGULFING',
  'BEARISH_HARAMI', 'DARK_CLOUD_COVER', 'EVENING_STAR', 'EVENING_DOJI_STAR',
  'DOUBLE_TOP',
]);

/**
 * Pure predicate: does this pattern signal contradict `tradeSide`'s thesis?
 * Used by trading-bot.ts's checkThesisBreak() PATTERN_REVERSAL_AGAINST rule
 * (2026-08-18, user report: "bot isn't identifying bottom reversal chart
 * patterns... needs to stop-loss out as a thesis broken"). A "no" position
 * bets price stays below the floor, so a bottom-reversal pattern (price about
 * to turn up) is what breaks it; a "yes" position is broken by a top-reversal
 * pattern. Requires the pattern to have been detected strictly after trade
 * entry (`pattern.updatedAt > tradeOpenedAt`) — a pattern already visible
 * (and evidently not disqualifying) at entry time shouldn't immediately stop
 * the trade back out; only genuinely new evidence counts. Kept as a
 * standalone exported function (not inlined in trading-bot.ts) so it's
 * unit-testable without mocking bot/class state.
 */
export function isPatternReversalAgainstSide(
  pattern: CandlePatternSignal | null | undefined,
  tradeSide: 'yes' | 'no',
  tradeOpenedAt: number,
): boolean {
  if (!pattern || pattern.updatedAt <= tradeOpenedAt) return false;
  return tradeSide === 'no'
    ? BOTTOM_REVERSAL_PATTERNS.has(pattern.pattern)
    : TOP_REVERSAL_PATTERNS.has(pattern.pattern);
}

export interface CandlePatternSignal {
  pattern:    CandlePatternName;
  signal:     'YES' | 'NO' | 'STAY_OUT';  // YES = bullish (price up), NO = bearish, STAY_OUT = indecision
  strength:   number;   // 0-1, relative confidence in the pattern read
  reason:     string;
  updatedAt:  number;
}

/** One historical occurrence of a pattern, for the Markets page's "recently detected" list. */
export interface CandlePatternEvent extends Omit<CandlePatternSignal, 'updatedAt'> {
  /** How many completed candles ago this pattern's final candle closed (0 = the current/latest candle). */
  barsAgo: number;
  /** Wall-clock time of the pattern's final candle (candle.time, ms). */
  timestamp: number;
}

// ── Heikin Ashi transform (same formula as the frontend's heikin-ashi.ts) ──────
// Exported so backtest replay paths (historical-backtester.ts) can run the
// exact same transform + detector on past-only candle windows instead of
// re-deriving a second copy that could drift from this one.
export function toHeikinAshi(candles: RealCandle[]): RealCandle[] {
  if (candles.length === 0) return [];
  const result: RealCandle[] = new Array(candles.length);
  let prevHAOpen = (candles[0].open + candles[0].close) / 2;
  let prevHAClose = candles[0].close;
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const haClose = (c.open + c.high + c.low + c.close) / 4;
    const haOpen = i === 0 ? (c.open + c.close) / 2 : (prevHAOpen + prevHAClose) / 2;
    const haHigh = Math.max(c.high, haOpen, haClose);
    const haLow = Math.min(c.low, haOpen, haClose);
    result[i] = { ...c, open: haOpen, high: haHigh, low: haLow, close: haClose };
    prevHAOpen = haOpen;
    prevHAClose = haClose;
  }
  return result;
}

function body(c: RealCandle): number { return Math.abs(c.close - c.open); }
function range(c: RealCandle): number { return Math.max(c.high - c.low, 1e-9); }
function isBullish(c: RealCandle): boolean { return c.close > c.open; }
function isBearish(c: RealCandle): boolean { return c.close < c.open; }
function upperWick(c: RealCandle): number { return c.high - Math.max(c.open, c.close); }
function lowerWick(c: RealCandle): number { return Math.min(c.open, c.close) - c.low; }

/** Simple prior-trend read over the N candles before the pattern (excludes it). */
function priorTrend(candles: RealCandle[], endIdxExclusive: number, lookback = 5): 'up' | 'down' | 'flat' {
  const start = Math.max(0, endIdxExclusive - lookback);
  const slice = candles.slice(start, endIdxExclusive);
  if (slice.length < 3) return 'flat';
  const chg = slice[slice.length - 1].close - slice[0].close;
  const avgRange = slice.reduce((s, c) => s + range(c), 0) / slice.length;
  if (Math.abs(chg) < avgRange * 0.5) return 'flat';
  return chg > 0 ? 'up' : 'down';
}

interface SwingPivot { idx: number; price: number; }

/** Bars whose low (mode='low') or high (mode='high') is the extreme among `arm` neighbors on each side. */
function findSwingPivots(candles: RealCandle[], mode: 'low' | 'high', arm = 2): SwingPivot[] {
  const pivots: SwingPivot[] = [];
  for (let i = arm; i < candles.length - arm; i++) {
    const price = mode === 'low' ? candles[i].low : candles[i].high;
    let isPivot = true;
    for (let k = 1; k <= arm && isPivot; k++) {
      const neighborBefore = mode === 'low' ? candles[i - k].low : candles[i - k].high;
      const neighborAfter  = mode === 'low' ? candles[i + k].low : candles[i + k].high;
      if (mode === 'low' ? (neighborBefore < price || neighborAfter < price)
                          : (neighborBefore > price || neighborAfter > price)) {
        isPivot = false;
      }
    }
    if (isPivot) pivots.push({ idx: i, price });
  }
  return pivots;
}

/**
 * Double Bottom / Double Top — the one classical "bottom reversal" shape the
 * detector didn't cover (added 2026-08-18, user report: "bot isn't
 * identifying bottom reversal chart patterns"). Unlike every other pattern
 * in this file, this is a SWING structure, not a single/double/triple-candle
 * shape — it needs two comparable extremes separated by a real bounce, so it
 * scans the full lookback window (not just the last 2-3 candles) for two
 * matching pivots with a confirmed neckline break on the final candle.
 * Deliberately excludes the confirmation candle itself from pivot scanning
 * (`candles.slice(0, n-1)`) so the breakout read never uses the same bar
 * it's trying to confirm.
 */
function detectDoubleBottomTop(candles: RealCandle[]): Omit<CandlePatternSignal, 'updatedAt'> | null {
  const n = candles.length;
  if (n < 16) return null;
  const confirmCandle = candles[n - 1];
  const scan = candles.slice(0, n - 1);

  const tryMode = (mode: 'low' | 'high'): Omit<CandlePatternSignal, 'updatedAt'> | null => {
    const pivots = findSwingPivots(scan, mode, 2);
    if (pivots.length < 2) return null;
    const recent = pivots.slice(-5); // only consider the handful of most recent candidate extremes
    const necklinePivots = findSwingPivots(scan, mode === 'low' ? 'high' : 'low', 2);

    // Check most-recent-pair-first so a fresher double bottom/top wins over an older one.
    for (let b = recent.length - 1; b >= 1; b--) {
      for (let a = b - 1; a >= 0; a--) {
        const p1 = recent[a], p2 = recent[b];
        const sep = p2.idx - p1.idx;
        if (sep < 4 || sep > 30) continue;
        const avgExtreme = (p1.price + p2.price) / 2;
        const diffPct = Math.abs(p1.price - p2.price) / avgExtreme;
        if (diffPct > 0.0015) continue; // the two extremes must land within ~0.15% of each other

        const between = necklinePivots.filter(h => h.idx > p1.idx && h.idx < p2.idx);
        if (between.length === 0) continue;
        const neckline = mode === 'low'
          ? Math.max(...between.map(h => h.price))
          : Math.min(...between.map(h => h.price));
        const necklineDepthPct = Math.abs(neckline - avgExtreme) / avgExtreme;
        if (necklineDepthPct < 0.0025) continue; // neckline must be a meaningful bounce, not noise

        // Price must not have broken back past the first extreme in between p2 and now —
        // that would be trend continuation, not a held double bottom/top.
        const after = scan.slice(p2.idx + 1);
        const broke = after.some(c => mode === 'low'
          ? c.low  < p1.price - avgExtreme * 0.001
          : c.high > p1.price + avgExtreme * 0.001);
        if (broke) continue;

        // Confirmation: the final (most recent) candle closes back through the neckline.
        const confirmed = mode === 'low' ? confirmCandle.close > neckline : confirmCandle.close < neckline;
        if (!confirmed) continue;

        const symmetry = 1 - diffPct / 0.0015; // 0-1, how closely the two extremes matched
        const strength = Math.min(0.55 + symmetry * 0.1 + Math.min(necklineDepthPct / 0.01, 1) * 0.1, 0.78);
        return mode === 'low'
          ? {
              pattern: 'DOUBLE_BOTTOM', signal: 'YES', strength,
              reason: `Double Bottom: two comparable lows ${sep} bars apart with a confirmed close back above the ~${neckline.toFixed(0)} neckline — classic 'W' bottoming reversal.`,
            }
          : {
              pattern: 'DOUBLE_TOP', signal: 'NO', strength,
              reason: `Double Top: two comparable highs ${sep} bars apart with a confirmed close back below the ~${neckline.toFixed(0)} neckline — classic 'M' topping reversal.`,
            };
      }
    }
    return null;
  };

  return tryMode('low') ?? tryMode('high');
}

/**
 * Runs Sakata/Homma-style pattern detection on the most recent Heikin-Ashi
 * candle(s). `haCandles` must be ordered oldest→newest with the pattern
 * candle(s) at the end. Returns null when nothing recognizable is present —
 * callers should treat that as "no signal," not as an error.
 */
export function detectCandlePattern(haCandles: RealCandle[]): Omit<CandlePatternSignal, 'updatedAt'> | null {
  const n = haCandles.length;
  if (n < 5) return null;
  const last = haCandles[n - 1];
  const prev = haCandles[n - 2];

  // ── Double Bottom / Double Top (swing structure) — checked first since it's
  // the most information-rich, least-noise-prone read when it's genuinely
  // present, and it needs more history than the shape checks below have access to.
  const swingPattern = detectDoubleBottomTop(haCandles);
  if (swingPattern) return swingPattern;

  // ── Three White Soldiers / Three Black Crows (Sanpei) ──────────────────────
  const last3 = haCandles.slice(n - 3);
  const avgRange3 = last3.reduce((s, c) => s + range(c), 0) / 3;
  const allBullish = last3.every(isBullish);
  const allBearish = last3.every(isBearish);
  const meaningfulBodies = last3.every(c => body(c) > avgRange3 * 0.35);
  const eachHigherClose = last3[1].close > last3[0].close && last3[2].close > last3[1].close;
  const eachLowerClose = last3[1].close < last3[0].close && last3[2].close < last3[1].close;
  const opensInsidePriorBody = (a: RealCandle, b: RealCandle) =>
    b.open >= Math.min(a.open, a.close) && b.open <= Math.max(a.open, a.close);

  if (allBullish && meaningfulBodies && eachHigherClose &&
      opensInsidePriorBody(last3[0], last3[1]) && opensInsidePriorBody(last3[1], last3[2])) {
    return {
      pattern: 'THREE_WHITE_SOLDIERS', signal: 'YES', strength: 0.62,
      reason: 'Three White Soldiers (Sanpei): three consecutive rising HA candles with solid bodies — established bullish momentum.',
    };
  }
  if (allBearish && meaningfulBodies && eachLowerClose &&
      opensInsidePriorBody(last3[0], last3[1]) && opensInsidePriorBody(last3[1], last3[2])) {
    return {
      pattern: 'THREE_BLACK_CROWS', signal: 'NO', strength: 0.62,
      reason: 'Three Black Crows (Sanpei): three consecutive falling HA candles with solid bodies — established bearish momentum.',
    };
  }

  // ── Morning/Evening Star (three-candle reversal, middle candle is the "star") ──
  const midpoint = (c: RealCandle) => (c.open + c.close) / 2;
  const [s0, s1, s2] = last3;
  const body0 = body(s0), body1 = body(s1), body2 = body(s2);
  const starIsSmall = body1 < Math.max(body0, body2) * 0.5 && body1 < range(s1) * 0.5;
  const starIsDoji = body1 < range(s1) * 0.08;

  if (isBearish(s0) && body0 > avgRange3 * 0.3 && starIsSmall &&
      Math.max(s1.open, s1.close) <= s0.close + range(s0) * 0.2 &&
      isBullish(s2) && body2 > avgRange3 * 0.3 && s2.close > midpoint(s0)) {
    return starIsDoji
      ? { pattern: 'MORNING_DOJI_STAR', signal: 'YES', strength: 0.72,
          reason: 'Morning Doji Star: sharp decline, a Doji pause, then a rising candle reclaiming the midpoint of the first candle — a precise bottoming pivot.' }
      : { pattern: 'MORNING_STAR', signal: 'YES', strength: 0.66,
          reason: 'Morning Star: sharp decline, a small-bodied pause, then a rising candle reclaiming the midpoint of the first candle — a classic bottoming reversal.' };
  }
  if (isBullish(s0) && body0 > avgRange3 * 0.3 && starIsSmall &&
      Math.min(s1.open, s1.close) >= s0.close - range(s0) * 0.2 &&
      isBearish(s2) && body2 > avgRange3 * 0.3 && s2.close < midpoint(s0)) {
    return starIsDoji
      ? { pattern: 'EVENING_DOJI_STAR', signal: 'NO', strength: 0.72,
          reason: 'Evening Doji Star: sharp advance, a Doji pause, then a falling candle giving back the midpoint of the first candle — a precise topping pivot.' }
      : { pattern: 'EVENING_STAR', signal: 'NO', strength: 0.66,
          reason: 'Evening Star: sharp advance, a small-bodied pause, then a falling candle giving back the midpoint of the first candle — a classic topping reversal.' };
  }

  // ── Engulfing (two-candle reversal) ─────────────────────────────────────────
  const prevBody = body(prev);
  const lastBody = body(last);
  const bodyTop = (c: RealCandle) => Math.max(c.open, c.close);
  const bodyBottom = (c: RealCandle) => Math.min(c.open, c.close);

  if (prevBody > 0 && lastBody > prevBody * 1.05) {
    if (isBearish(prev) && isBullish(last) && last.open <= prev.close && last.close >= prev.open) {
      const trend = priorTrend(haCandles, n - 2);
      return {
        pattern: 'BULLISH_ENGULFING', signal: 'YES',
        strength: trend === 'down' ? 0.68 : 0.55,
        reason: `Bullish Engulfing: rising HA candle's body fully swallows the prior falling candle${trend === 'down' ? ' after a downtrend — classic reversal setup' : ''}.`,
      };
    }
    if (isBullish(prev) && isBearish(last) && last.open >= prev.close && last.close <= prev.open) {
      const trend = priorTrend(haCandles, n - 2);
      return {
        pattern: 'BEARISH_ENGULFING', signal: 'NO',
        strength: trend === 'up' ? 0.68 : 0.55,
        reason: `Bearish Engulfing: falling HA candle's body fully swallows the prior rising candle${trend === 'up' ? ' after an uptrend — classic reversal setup' : ''}.`,
      };
    }
  }

  // ── Piercing Line / Dark Cloud Cover (two-candle partial reversal) ─────────
  if (prevBody > 0) {
    if (isBearish(prev) && isBullish(last) && last.open <= prev.close &&
        last.close > midpoint(prev) && last.close < prev.open) {
      return {
        pattern: 'PIERCING_LINE', signal: 'YES', strength: 0.58,
        reason: "Piercing Line: rising HA candle opens at/below the prior low and closes back above the midpoint of the prior falling candle's body.",
      };
    }
    if (isBullish(prev) && isBearish(last) && last.open >= prev.close &&
        last.close < midpoint(prev) && last.close > prev.open) {
      return {
        pattern: 'DARK_CLOUD_COVER', signal: 'NO', strength: 0.58,
        reason: "Dark Cloud Cover: falling HA candle opens at/above the prior high and closes back below the midpoint of the prior rising candle's body.",
      };
    }
  }

  // ── Harami (two-candle compression — momentum stalling, not yet reversed) ──
  if (prevBody > 0 && lastBody < prevBody * 0.6 &&
      bodyTop(last) <= bodyTop(prev) && bodyBottom(last) >= bodyBottom(prev)) {
    if (isBearish(prev) && prevBody > avgRange3 * 0.3) {
      return {
        pattern: 'BULLISH_HARAMI', signal: 'YES', strength: 0.5,
        reason: "Bullish Harami: a small candle's body sits entirely inside the prior large falling candle's body — selling momentum has abruptly compressed.",
      };
    }
    if (isBullish(prev) && prevBody > avgRange3 * 0.3) {
      return {
        pattern: 'BEARISH_HARAMI', signal: 'NO', strength: 0.5,
        reason: "Bearish Harami: a small candle's body sits entirely inside the prior large rising candle's body — buying momentum has abruptly compressed.",
      };
    }
  }

  // ── Tweezer Top / Bottom (two-candle matching extremes) ────────────────────
  const avgRange2 = (range(prev) + range(last)) / 2;
  if (Math.abs(prev.high - last.high) < avgRange2 * 0.12 && isBullish(prev) && isBearish(last)) {
    const trend = priorTrend(haCandles, n - 2);
    if (trend !== 'down') {
      return {
        pattern: 'TWEEZER_TOP', signal: 'NO', strength: 0.45,
        reason: 'Tweezer Top: two consecutive HA candles topped out at essentially the same high — buyers failed twice at the same ceiling.',
      };
    }
  }
  if (Math.abs(prev.low - last.low) < avgRange2 * 0.12 && isBearish(prev) && isBullish(last)) {
    const trend = priorTrend(haCandles, n - 2);
    if (trend !== 'up') {
      return {
        pattern: 'TWEEZER_BOTTOM', signal: 'YES', strength: 0.45,
        reason: 'Tweezer Bottom: two consecutive HA candles bottomed out at essentially the same low — sellers failed twice at the same floor.',
      };
    }
  }

  // ── Marubozu (single-candle, no meaningful wicks — full conviction) ────────
  const r = range(last);
  const b = body(last);
  const uw = upperWick(last);
  const lw = lowerWick(last);
  if (b > r * 0.9) {
    if (isBullish(last)) {
      return {
        pattern: 'BULLISH_MARUBOZU', signal: 'YES', strength: 0.55,
        reason: 'Bullish Marubozu: opened near the low and closed near the high with almost no wick — buyers in full control the entire period.',
      };
    }
    if (isBearish(last)) {
      return {
        pattern: 'BEARISH_MARUBOZU', signal: 'NO', strength: 0.55,
        reason: 'Bearish Marubozu: opened near the high and closed near the low with almost no wick — sellers in full control the entire period.',
      };
    }
  }

  // ── Hammer / Hanging Man / Shooting Star / Inverted Hammer (single-candle) ─
  const smallBody = b < r * 0.35;

  if (smallBody && lw > b * 2 && lw > r * 0.5 && uw < r * 0.15) {
    const trend = priorTrend(haCandles, n - 1);
    if (trend === 'down') {
      return {
        pattern: 'HAMMER', signal: 'YES', strength: 0.6,
        reason: 'Hammer: small body near the top of a long lower wick after a decline — buyers rejected the lows.',
      };
    }
    if (trend === 'up') {
      return {
        pattern: 'HANGING_MAN', signal: 'NO', strength: 0.48,
        reason: 'Hanging Man: small body near the top of a long lower wick after an advance — sellers dragged price down intraperiod despite the uptrend.',
      };
    }
  }
  if (smallBody && uw > b * 2 && uw > r * 0.5 && lw < r * 0.15) {
    const trend = priorTrend(haCandles, n - 1);
    if (trend === 'up') {
      return {
        pattern: 'SHOOTING_STAR', signal: 'NO', strength: 0.6,
        reason: 'Shooting Star: small body near the bottom of a long upper wick after a rally — sellers rejected the highs.',
      };
    }
    if (trend === 'down') {
      return {
        pattern: 'INVERTED_HAMMER', signal: 'YES', strength: 0.48,
        reason: 'Inverted Hammer: small body near the bottom of a long upper wick after a decline — the first real buying push after a slide.',
      };
    }
  }

  // ── Spinning Top (small body, moderate wicks on both sides — indecision) ──
  if (smallBody && uw > r * 0.15 && lw > r * 0.15 && b > r * 0.08) {
    return {
      pattern: 'SPINNING_TOP', signal: 'STAY_OUT', strength: 0.35,
      reason: 'Spinning Top: small body with wicks on both sides — a modest tug-of-war between buyers and sellers with no clear winner.',
    };
  }

  // ── Doji variants (indecision — explicit stay-out, not a directional bet) ──
  if (b < r * 0.08 && r > 0) {
    if (lw > r * 0.4 && uw < r * 0.1) {
      return {
        pattern: 'DRAGONFLY_DOJI', signal: 'YES', strength: 0.5,
        reason: 'Dragonfly Doji: open ≈ close sitting at the top of a long lower wick — a sharp, exact-tie rejection of the lows.',
      };
    }
    if (uw > r * 0.4 && lw < r * 0.1) {
      return {
        pattern: 'GRAVESTONE_DOJI', signal: 'NO', strength: 0.5,
        reason: 'Gravestone Doji: open ≈ close sitting at the bottom of a long upper wick — a sharp, exact-tie rejection of the highs.',
      };
    }
    if (uw > r * 0.25 && lw > r * 0.25) {
      return {
        pattern: 'LONG_LEGGED_DOJI', signal: 'STAY_OUT', strength: 0.35,
        reason: 'Long-Legged Doji: open ≈ close but with long wicks on both sides — extreme two-way volatility with no net winner.',
      };
    }
    return {
      pattern: 'DOJI', signal: 'STAY_OUT', strength: 0.4,
      reason: 'Doji: open ≈ close on the latest HA candle — the market is undecided, no directional edge here.',
    };
  }

  return null;
}

/**
 * Scans a bounded lookback window for distinct recent pattern occurrences,
 * newest first, for the Markets page's "recently detected" list. Slides
 * `detectCandlePattern` across successively shorter candle windows (each
 * ending one bar earlier) rather than re-implementing detection — same
 * shapes, same thresholds, just evaluated at each historical point in time.
 * Consecutive identical matches (the same pattern re-triggering on adjacent
 * bars, e.g. because a big body persists) collapse into a single event at
 * its most recent occurrence.
 */
export function scanRecentPatterns(
  haCandles: RealCandle[],
  opts: { maxBarsBack?: number; maxEvents?: number } = {},
): CandlePatternEvent[] {
  const maxBarsBack = opts.maxBarsBack ?? 20;
  const maxEvents = opts.maxEvents ?? 8;
  const events: CandlePatternEvent[] = [];
  const n = haCandles.length;

  // Tracks the pattern (if any) still "in progress" from the previous
  // (one-bar-more-recent) iteration, so a shape that keeps re-triggering on
  // adjacent bars — e.g. a persistent Doji — collapses into a single event
  // at its most recent occurrence instead of one entry per bar.
  let streakPattern: string | null = null;
  let streakBarsAgo = -1;

  for (let barsAgo = 0; barsAgo <= maxBarsBack && events.length < maxEvents; barsAgo++) {
    const endIdx = n - 1 - barsAgo;
    if (endIdx < 4) break; // detectCandlePattern needs >= 5 candles
    const window = haCandles.slice(0, endIdx + 1);
    const detected = detectCandlePattern(window);
    if (!detected) {
      streakPattern = null;
      streakBarsAgo = -1;
      continue;
    }
    if (detected.pattern === streakPattern && barsAgo === streakBarsAgo + 1) {
      streakBarsAgo = barsAgo; // continuation of the same streak — not a new event
      continue;
    }
    events.push({ ...detected, barsAgo, timestamp: haCandles[endIdx].time * 1000 });
    streakPattern = detected.pattern;
    streakBarsAgo = barsAgo;
  }
  return events;
}

// ── Singleton analyzer (background poll, sync read) ────────────────────────────
// Mirrors mtf-analyzer.ts's pattern: an interval-driven async refresh feeds a
// cached, synchronously-readable result so trading-bot.ts's per-tick
// evaluate() calls never block on network I/O.
class CandlePatternAnalyzer {
  private latest: CandlePatternSignal | null = null;
  private recentEvents: CandlePatternEvent[] = [];
  private recentEventsUpdatedAt = 0;
  private refreshTimer: NodeJS.Timeout | null = null;
  private refreshing = false;

  start() {
    this.refresh();
    this.refreshTimer = setInterval(() => this.refresh(), REFRESH_MS);
  }

  stop() {
    if (this.refreshTimer) clearInterval(this.refreshTimer);
  }

  /** Returns the latest pattern read if fresh, otherwise null. */
  getLatest(): CandlePatternSignal | null {
    if (!this.latest) return null;
    if (Date.now() - this.latest.updatedAt > STALE_MS) return null;
    return this.latest;
  }

  isStale(): boolean {
    if (!this.latest) return true;
    return Date.now() - this.latest.updatedAt > STALE_MS;
  }

  /** Recent distinct pattern occurrences (newest first) for the Markets page's display list. */
  getRecent(): { events: CandlePatternEvent[]; updatedAt: number; stale: boolean } {
    return {
      events: this.recentEvents,
      updatedAt: this.recentEventsUpdatedAt,
      stale: this.recentEventsUpdatedAt === 0 || Date.now() - this.recentEventsUpdatedAt > STALE_MS,
    };
  }

  forceRefresh() {
    void this.refresh();
  }

  private async refresh() {
    if (this.refreshing) return;
    this.refreshing = true;
    try {
      await this._refreshBody();
    } finally {
      this.refreshing = false;
    }
  }

  private async _refreshBody() {
    try {
      const startMs = Date.now() - LOOKBACK_CANDLES * 60_000;
      const { candles } = await fetchRealCandles(startMs, LOOKBACK_CANDLES, 1);
      if (candles.length < 5) return;
      const ha = toHeikinAshi(candles);
      const detected = detectCandlePattern(ha);
      if (detected) {
        this.latest = { ...detected, updatedAt: Date.now() };
        console.info(`[candle-patterns] ${detected.pattern} → ${detected.signal} (strength=${detected.strength})`);
      } else {
        // No recognizable pattern right now — clear any stale prior read so
        // callers don't act on a shape that no longer applies.
        this.latest = null;
      }
      this.recentEvents = scanRecentPatterns(ha, { maxBarsBack: RECENT_SCAN_BARS_BACK });
      this.recentEventsUpdatedAt = Date.now();
    } catch (err) {
      console.warn(`[candle-patterns] refresh failed: ${(err as Error).message}`);
    }
  }
}

export const candlePatternAnalyzer = new CandlePatternAnalyzer();
