/**
 * hold-sell.ts — take-profit vs locked-ITM settlement hold.
 *
 * Does not import trading-bot.ts (cycle + BOT_CONFIG_PATH). Source-text
 * checks pin the settlement-hold wire and the existing exit order.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  decideHoldOrSell,
  maxWickDollars,
  type HoldSellInput,
} from "./hold-sell.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const botSource = fs.readFileSync(path.join(__dirname, "trading-bot.ts"), "utf8");
const holdSource = fs.readFileSync(path.join(__dirname, "hold-sell.ts"), "utf8");

function base(over: Partial<HoldSellInput> = {}): HoldSellInput {
  return {
    strategyId: "LATE_ENTRY_ANCHOR",
    isOTMAsymmetry: false,
    markCents: 55,
    entryCents: 50,
    peakUnrealizedCents: 5,
    secsRemaining: 480,
    projectedSettlement: 100_400,
    floor: 100_000,
    side: "yes",
    hardStop: false,
    thesisBreak: false,
    lagFlip: false,
    trailingGivebackCents: 12,
    ...over,
  };
}

test("maxWickDollars is max(80, 1.5 * secs) — $80 floor, ~$1.50/s", () => {
  assert.equal(maxWickDollars(0), 80);
  assert.equal(maxWickDollars(10), 80);
  assert.equal(maxWickDollars(60), 90);
  assert.equal(maxWickDollars(400), 600);
});

test("green + lagFlip → SELL LAG_FLIP (even if green)", () => {
  const d = decideHoldOrSell(base({
    markCents: 70,
    entryCents: 50,
    peakUnrealizedCents: 20,
    lagFlip: true,
  }));
  assert.equal(d.action, "SELL");
  assert.equal(d.reason, "LAG_FLIP");
});

test("green + thesisBreak → SELL THESIS_BREAK (even if green)", () => {
  const d = decideHoldOrSell(base({
    markCents: 70,
    entryCents: 50,
    thesisBreak: true,
  }));
  assert.equal(d.action, "SELL");
  assert.equal(d.reason, "THESIS_BREAK");
});

test("hardStop → SELL HARD_STOP even if locked ITM", () => {
  const d = decideHoldOrSell(base({
    markCents: 92,
    secsRemaining: 60,
    projectedSettlement: 100_400,
    floor: 100_000,
    hardStop: true,
  }));
  assert.equal(d.action, "SELL");
  assert.equal(d.reason, "HARD_STOP");
});

test("cheap-side mark 92 never HOLD_SETTLE", () => {
  const locked = decideHoldOrSell(base({
    strategyId: "CHEAP_SIDE_15M",
    markCents: 92,
    secsRemaining: 200,
    projectedSettlement: 100_400,
    floor: 100_000,
  }));
  assert.notEqual(locked.action, "HOLD_SETTLE");
  assert.equal(locked.action, "HOLD_TRAIL");

  const near = decideHoldOrSell(base({
    strategyId: "CHEAP_SIDE_15M",
    markCents: 92,
    secsRemaining: 60,
    projectedSettlement: 100_400,
    floor: 100_000,
    holdMs: 20_000,
  }));
  assert.notEqual(near.action, "HOLD_SETTLE");
  assert.equal(near.action, "SELL");
  assert.equal(near.reason, "CHEAP_SIDE_NEAR_EXPIRY");

  const otm = decideHoldOrSell(base({
    strategyId: "OTM_ASYMMETRY",
    isOTMAsymmetry: true,
    markCents: 92,
    secsRemaining: 200,
  }));
  assert.notEqual(otm.action, "HOLD_SETTLE");
});

test("locked yes 92¢ proj $400 above 60s left → HOLD_SETTLE", () => {
  // maxWickDollars(60) = max(80, 90) = 90; $400 cushion is locked.
  assert.ok(400 >= maxWickDollars(60));
  const d = decideHoldOrSell(base({
    strategyId: "LATE_ENTRY_ANCHOR",
    markCents: 92,
    entryCents: 50,
    peakUnrealizedCents: 42,
    secsRemaining: 60,
    projectedSettlement: 100_400,
    floor: 100_000,
    side: "yes",
  }));
  assert.equal(d.action, "HOLD_SETTLE");
  assert.equal(d.reason, "LOCKED_ITM");
});

test("green peak +20 now +5 with trail 12 → SELL TRAIL_GIVEBACK", () => {
  const d = decideHoldOrSell(base({
    markCents: 55,
    entryCents: 50,
    peakUnrealizedCents: 20,
    trailingGivebackCents: 12,
    secsRemaining: 400,
    // not locked: mark 55 < 90
  }));
  assert.equal(d.action, "SELL");
  assert.equal(d.reason, "TRAIL_GIVEBACK");
});

test("red -2 with 8 min left not lag/thesis → HOLD_TRAIL not instant dump", () => {
  const d = decideHoldOrSell(base({
    markCents: 48,
    entryCents: 50,
    peakUnrealizedCents: 0,
    secsRemaining: 8 * 60,
    lagFlip: false,
    thesisBreak: false,
    hardStop: false,
  }));
  assert.equal(d.action, "HOLD_TRAIL");
  assert.notEqual(d.reason, "DEAD_RED");
});

test("0.58-only hold is dead: mark 70 + locked proj is not HOLD_SETTLE", () => {
  // Old settlement-hold: evalSidePrice > 55 && minProb 0.58. A 70¢ mark
  // with a deep projection used to ride. LOCKED_ITM requires mark >= 90.
  const d = decideHoldOrSell(base({
    markCents: 70,
    entryCents: 50,
    peakUnrealizedCents: 20,
    secsRemaining: 200,
    projectedSettlement: 100_400,
    floor: 100_000,
    side: "yes",
  }));
  assert.notEqual(d.action, "HOLD_SETTLE");
});

test("dead red: <=120s left or ≥15¢ underwater → SELL DEAD_RED", () => {
  const near = decideHoldOrSell(base({
    markCents: 48,
    entryCents: 50,
    peakUnrealizedCents: 0,
    secsRemaining: 120,
  }));
  assert.equal(near.action, "SELL");
  assert.equal(near.reason, "DEAD_RED");

  const deep = decideHoldOrSell(base({
    markCents: 35,
    entryCents: 50,
    peakUnrealizedCents: 0,
    secsRemaining: 8 * 60,
  }));
  assert.equal(deep.action, "SELL");
  assert.equal(deep.reason, "DEAD_RED");
});

test("LOCKED_ITM does not use confidence as p (no p/conf fields; wick is USD)", () => {
  const keys = Object.keys(base());
  assert.ok(!keys.includes("confidence") && !keys.includes("winRate") && !keys.includes("pWin"));
  assert.ok(holdSource.includes("Do NOT use confidence as p"));
  assert.ok(holdSource.includes("max(80, 1.5 * secs)"));
  assert.ok(holdSource.includes("Wick budget is USD, not a probability"));
});

test("trading-bot keeps hold-sell import; PATH_RIDE owns HOLD_SETTLE disposition", () => {
  // Peeled: leftover settlementHoldEligible / holdSell.action host is gone.
  // PATH_RIDE organs/exit returns HOLD_SETTLE; hold-sell remains imported for leftover stack.
  assert.ok(botSource.includes('from "./hold-sell.js"'));
  assert.ok(botSource.includes("isHoldToSettlementExempt"));
  assert.ok(botSource.includes('disp.kind === "HOLD_SETTLE"') || botSource.includes("HOLD_SETTLE"));
  assert.equal(botSource.includes("const settlementHoldEligible"), false);
  assert.equal(botSource.includes('holdSell.action === "HOLD_SETTLE"'), false);
});

test("monitorOpenTrade: PATH_RIDE first; leftover stack denied on paper/frozen", () => {
  const pathRide = botSource.indexOf("PATH_RIDE");
  const leftoverDeny = botSource.indexOf("leftover exit stack skipped");
  const leftoverMay = botSource.indexOf("leftoverExitStackMayRun");
  assert.ok(pathRide >= 0, "PATH_RIDE present");
  assert.ok(leftoverMay >= 0, "leftoverExitStackMayRun present");
  // check* leftover exits may still exist as methods but must not run under frozen leftover deny.
  assert.ok(botSource.includes("checkHardStop") && botSource.includes("checkThesisBreak"));
});

test("thesisBreak outranks hardStop (Stellar: TB/lag over % hard stop)", () => {
  const d = decideHoldOrSell(base({
    markCents: 20,
    entryCents: 50,
    thesisBreak: true,
    hardStop: true,
    lagFlip: true,
  }));
  assert.equal(d.action, "SELL");
  assert.equal(d.reason, "THESIS_BREAK");
});

test("lagFlip outranks hardStop when thesis is not broken", () => {
  const d = decideHoldOrSell(base({
    markCents: 20,
    entryCents: 50,
    thesisBreak: false,
    hardStop: true,
    lagFlip: true,
  }));
  assert.equal(d.action, "SELL");
  assert.equal(d.reason, "LAG_FLIP");
});

test("hold-sell.ts does not import aria-guardian (no cycle); Guardian imports hold-sell", () => {
  const guardianSource = fs.readFileSync(path.join(__dirname, "aria-guardian.ts"), "utf8");
  assert.equal(holdSource.includes("aria-guardian"), false);
  assert.ok(guardianSource.includes('from "./hold-sell.js"'));
  assert.ok(guardianSource.includes("decideHoldOrSell"));
});

test("holdToSettlement stays false (doctrine); useSettlementHold stays a helper", () => {
  assert.match(botSource, /holdToSettlement:\s*false/);
  assert.doesNotMatch(botSource, /holdToSettlement:\s*true/);
});

test("PAPER_SCALP never HOLD_SETTLE; sells green / 2x / 90s", () => {
  // Adaptive green (not rigid +20): entry 40 mid → ~8–10¢ bar; mark 50 = +10, < 2×80.
  const locked = decideHoldOrSell(base({
    strategyId: "PAPER_SCALP",
    markCents: 50,
    entryCents: 40,
    peakUnrealizedCents: 12,
    secsRemaining: 200,
    projectedSettlement: 100_400,
    floor: 100_000,
  }));
  assert.notEqual(locked.action, "HOLD_SETTLE");
  assert.equal(locked.action, "SELL");
  assert.equal(locked.reason, "PAPER_SCALP_GREEN");

  // 2× outranks adaptive green when mark >= min(99, 2×entry).
  const twoX = decideHoldOrSell(base({
    strategyId: "PAPER_SCALP",
    markCents: 24,
    entryCents: 12,
    peakUnrealizedCents: 12,
    secsRemaining: 400,
  }));
  assert.notEqual(twoX.action, "HOLD_SETTLE");
  assert.equal(twoX.action, "SELL");
  assert.equal(twoX.reason, "PAPER_SCALP_TWO_X");

  const near = decideHoldOrSell(base({
    strategyId: "PAPER_SCALP",
    markCents: 42,
    entryCents: 40,
    peakUnrealizedCents: 2,
    secsRemaining: 60,
  }));
  assert.notEqual(near.action, "HOLD_SETTLE");
  assert.equal(near.action, "SELL");
  assert.equal(near.reason, "PAPER_SCALP_TIME_STOP");

  const lag = decideHoldOrSell(base({
    strategyId: "PAPER_SCALP",
    markCents: 70,
    entryCents: 40,
    lagFlip: true,
  }));
  assert.equal(lag.action, "SELL");
  assert.equal(lag.reason, "LAG_FLIP");

  const thesis = decideHoldOrSell(base({
    strategyId: "PAPER_SCALP",
    markCents: 70,
    entryCents: 40,
    thesisBreak: true,
  }));
  assert.equal(thesis.action, "SELL");
  assert.equal(thesis.reason, "THESIS_BREAK");
});

test("preferEarlyExit + green ≥8¢ → SELL STREAK_SAT_EARLY_EXIT", () => {
  const d = decideHoldOrSell(base({
    markCents: 60,
    entryCents: 50,
    preferEarlyExit: true,
  }));
  assert.equal(d.action, "SELL");
  assert.equal(d.reason, "STREAK_SAT_EARLY_EXIT");
});

test("preferEarlyExit does not dump red", () => {
  const d = decideHoldOrSell(base({
    markCents: 45,
    entryCents: 50,
    peakUnrealizedCents: 0,
    preferEarlyExit: true,
  }));
  assert.notEqual(d.reason, "STREAK_SAT_EARLY_EXIT");
});

test("thesis-break still outranks preferEarlyExit", () => {
  const d = decideHoldOrSell(base({
    markCents: 70,
    entryCents: 50,
    thesisBreak: true,
    preferEarlyExit: true,
  }));
  assert.equal(d.reason, "THESIS_BREAK");
});

test("CHEAP_EARLY_EXIT never HOLD_SETTLE; sells adaptive green / 2x / 90s", () => {
  // entry 15 cheap → greenBar ~6; +8 clears green without hitting 2×30.
  const green = decideHoldOrSell(base({
    strategyId: "CHEAP_EARLY_EXIT",
    markCents: 23,
    entryCents: 15,
    peakUnrealizedCents: 8,
    secsRemaining: 400,
  }));
  assert.equal(green.action, "SELL");
  assert.equal(green.reason, "CHEAP_EARLY_GREEN");

  const twoX = decideHoldOrSell(base({
    strategyId: "CHEAP_EARLY_EXIT",
    markCents: 14,
    entryCents: 7,
    peakUnrealizedCents: 7,
    secsRemaining: 400,
  }));
  assert.equal(twoX.action, "SELL");
  assert.equal(twoX.reason, "CHEAP_EARLY_TWO_X");

  const near = decideHoldOrSell(base({
    strategyId: "CHEAP_EARLY_EXIT",
    markCents: 16,
    entryCents: 15,
    peakUnrealizedCents: 1,
    secsRemaining: 60,
  }));
  assert.equal(near.action, "SELL");
  assert.equal(near.reason, "CHEAP_EARLY_TIME_STOP");
});

test("PANIC_FADE and STREAK_SAT_FADE never HOLD_SETTLE; sell green +20 / 2x / 90s", () => {
  // PANIC_FADE: dedicated early-exit (not PATH_RIDE A).
  const panicGreen = decideHoldOrSell(base({
    strategyId: "PANIC_FADE",
    markCents: 40,
    entryCents: 18,
    peakUnrealizedCents: 22,
    secsRemaining: 400,
    holdMs: 20_000,
  }));
  assert.notEqual(panicGreen.action, "HOLD_SETTLE");
  assert.equal(panicGreen.action, "SELL");
  assert.equal(panicGreen.reason, "PANIC_FADE_GREEN");

  const panicNear = decideHoldOrSell(base({
    strategyId: "PANIC_FADE",
    markCents: 19,
    entryCents: 18,
    peakUnrealizedCents: 1,
    secsRemaining: 60,
  }));
  assert.equal(panicNear.action, "SELL");
  assert.equal(panicNear.reason, "PANIC_FADE_TIME_STOP");

  // STREAK_SAT_FADE stays on exempt early-exit book (not PATH_RIDE).
  const streakGreen = decideHoldOrSell(base({
    strategyId: "STREAK_SAT_FADE",
    markCents: 40,
    entryCents: 18,
    peakUnrealizedCents: 22,
    secsRemaining: 400,
  }));
  assert.notEqual(streakGreen.action, "HOLD_SETTLE");
  assert.equal(streakGreen.action, "SELL");
  assert.equal(streakGreen.reason, "STREAK_SAT_FADE_GREEN");

  const streakNear = decideHoldOrSell(base({
    strategyId: "STREAK_SAT_FADE",
    markCents: 19,
    entryCents: 18,
    peakUnrealizedCents: 1,
    secsRemaining: 60,
  }));
  assert.equal(streakNear.action, "SELL");
  assert.equal(streakNear.reason, "STREAK_SAT_FADE_TIME_STOP");

});

test("PATH_RIDE green + lagFlip without BROKEN → not early LAG_FLIP", () => {
  // mark only +2¢ green so PATH_RIDE_TP first-hit does not fire; lagFlip alone
  // must not bypass decidePathRideExit VALID shield.
  const d = decideHoldOrSell(base({
    strategyId: "CONFLUENCE_CASCADE",
    markCents: 52,
    entryCents: 50,
    peakUnrealizedCents: 2,
    lagFlip: true,
    thesisStatus: "VALID",
    holdMs: 20_000,
  }));
  assert.notEqual(d.reason, "LAG_FLIP");
  assert.notEqual(d.reason, "THESIS_BREAK");
});

test("PATH_RIDE red + BROKEN + lagFlip after 15s → SELL via decidePathRideExit", () => {
  // PATH_RIDE_MIN_HOLD_MS is 20s; HoldSellInput does not wire lagProven → use TB path.
  const d = decideHoldOrSell(base({
    strategyId: "CONFLUENCE_CASCADE",
    markCents: 30,
    entryCents: 50,
    peakUnrealizedCents: 0,
    lagFlip: false,
    thesisBreak: true,
    thesisStatus: "BROKEN",
    holdMs: 20_000,
    brokenPersistedMs: 20_000,
  }));
  assert.equal(d.action, "SELL");
  assert.equal(d.reason, "THESIS_BREAK");
});

test("PATH_RIDE deep-ITM VALID + BRTI clear → HOLD_SETTLE not soft PATH_RIDE_TP", () => {
  const d = decideHoldOrSell(base({
    strategyId: "CONFLUENCE_CASCADE",
    entryCents: 46,
    markCents: 52,
    peakUnrealizedCents: 10,
    secsRemaining: 400,
    thesisStatus: "VALID",
    thesisBreak: false,
    lagFlip: false,
    hardStop: false,
    holdMs: 25_000,
    spot: 100_147,
    brtiSpot: 100_147,
    floor: 100_000,
    projectedSettlement: 100_147,
    // fat-ish 1m candles so remainingVol honest (optional; CLEAR_USD alone suffices)
  }));
  assert.equal(d.action, "HOLD_SETTLE", `got ${d.action}/${d.reason}`);
  assert.equal(d.reason, "PATH_RIDE_SETTLEMENT_HOLD");
});

test("PATH_RIDE mark≥85 VALID → HOLD_SETTLE (defer HIGH_ODDS)", () => {
  const d = decideHoldOrSell(base({
    strategyId: "CONFLUENCE_CASCADE",
    entryCents: 40,
    markCents: 90,
    peakUnrealizedCents: 50,
    secsRemaining: 300,
    thesisStatus: "VALID",
    thesisBreak: false,
    lagFlip: false,
    hardStop: false,
    holdMs: 25_000,
    projectedSettlement: 100_200,
    floor: 100_000,
    spot: 100_200,
  }));
  assert.equal(d.action, "HOLD_SETTLE", `got ${d.action}/${d.reason}`);
  assert.equal(d.reason, "PATH_RIDE_SETTLEMENT_HOLD");
});
