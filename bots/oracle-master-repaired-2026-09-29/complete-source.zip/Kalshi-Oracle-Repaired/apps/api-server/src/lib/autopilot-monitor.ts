/**
 * autopilot-monitor.ts — GO — AUTOPILOT MONITOR (READ-ONLY + ALERTS, NO SILENT MUTATIONS)
 *
 * Hourly, overlap-guarded sweep that reproduces the "full health-check report"
 * (mode / regime / packs / skips / orders / anomalies / fee-net) automatically
 * and raises ALERTs on specific thresholds, persisting a rolling snapshot so
 * an operator (or the agent, on request) can see history without waiting for
 * the next cycle.
 *
 * STRICT SCOPE — this module NEVER:
 *   - changes EV floors, minConfidence, or any entry-quality gate
 *   - changes specialistPacksMode, a pack's eligibleStrategyIds, or packCap
 *   - enables/disables any strategy (DB quarantine, LOCKED_DISABLED, manual)
 *   - changes any size cap (maxContractsPerTrade, portfolio-risk band, etc.)
 * Any of the above requires an explicit future human "APPLY" directive acted
 * on by a separate, deliberate code change — never by this module.
 *
 * The ONLY actions this module is allowed to take automatically:
 *   1. Persist a snapshot (rolling JSON file under data/).
 *   2. Re-emit DecisionTrace-derived stats (skip histogram, pack mix) to logs.
 *   3. Restart the workflow — and ONLY if the process looks dead/crash-looping.
 *      NOTE (scoped down, documented per "GO — AUTOPILOT MONITOR" ack): no
 *      safe in-process self-restart mechanism exists in this codebase (no
 *      process.exit()-triggered supervisor hook was found inside api-server;
 *      crash-loop detection here is therefore ALERT-ONLY — it logs a clearly
 *      flagged ALERT and records the condition in the snapshot/actions-taken
 *      list, but never calls process.exit() or any restart primitive itself.
 *      A human (or a future, separately-approved change) decides whether to
 *      actually restart.
 *
 * Everything else here is a pure read (DB queries + in-memory getters already
 * used elsewhere for logging/health) plus formatting.
 */

import { promises as fs } from "fs";
import path from "path";
import { and, desc, eq, gte, inArray, isNotNull, sql } from "drizzle-orm";
import { db, botTrades, botTradeSkips, decisionTraces } from "@workspace/db";
import { logger } from "./logger.js";
import { tradingBot } from "./trading-bot.js";
import { getRegime, getRegimeSwitchHistory, getRegimeDebug } from "./regime-engine.js";
import { mapToClosedCode, CLOSED_SKIP_CODES, type ClosedSkipCode } from "./decision-trace.js";
import { isStrategyEnabledSync, QUARANTINE_EXEMPT, getLiveTradeStatsSync, getDbDisabledStrategies } from "./strategy-performance.js";
import { kalshiWS } from "./kalshi-ws.js";
import { watchdog } from "./watchdog.js";
import { etDateKey } from "./daily-target.js";

// ── Types ─────────────────────────────────────────────────────────────────────

export interface AutopilotAlert {
  code: string;
  severity: "warn" | "critical";
  message: string;
}

export interface AutopilotReport {
  generatedAt: string;
  cycleMs: number;
  status: {
    autoMode: boolean;
    paperMode: boolean;
    specialistPacksMode: string;
    regime: string;
    regimeHeldBy: string | null;
    botState: string;
    kalshiWsDegraded: boolean;
    dailyTargetBlockReason: string | null;
  };
  regimeSwitches: {
    lastHour: number;
    last10: Array<{ from: string; to: string; ts: string; reason: string }>;
  };
  packMix: Array<{ pack: string; count: number; orders: number; skips: number }>;
  skipHistogram: {
    lastHour: Record<ClosedSkipCode, number>;
    last24h: Record<ClosedSkipCode, number>;
    lastHourTotal: number;
    last24hTotal: number;
    /** Raw rejection codes behind the closed-taxonomy OTHER bucket (e.g. FROZEN_TIME_WINDOW). */
    lastHourOtherRaw?: Record<string, number>;
    last24hOtherRaw?: Record<string, number>;
  };
  lastOrders: Array<{
    ts: string;
    ticker: string;
    side: string | null;
    strategyId: string | null;
    pack: string | null;
    combinedMult: number | null;
    contracts: number | null;
  }>;
  feeNet: {
    today: { pnlCents: number; feeCents: number; netCents: number; trades: number; isPaper: boolean }[];
    byPackToday: Array<{ pack: string; pnlCents: number; feeCents: number; netCents: number; trades: number }>;
  };
  anomalies: string[];
  alerts: AutopilotAlert[];
  actionsTaken: string[];
}

// ── Persistence (rolling JSON snapshot file, no new DB table/migration) ─────

const DATA_DIR = path.join(process.cwd(), "data");
const SNAPSHOT_FILE = path.join(DATA_DIR, "autopilot-monitor-snapshots.json");
const MAX_SNAPSHOTS = 500; // ~3 weeks at hourly cadence

let latestReport: AutopilotReport | null = null;
let lastSpecialistPacksMode: string | null = null;

async function loadSnapshots(): Promise<AutopilotReport[]> {
  try {
    const raw = await fs.readFile(SNAPSHOT_FILE, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return []; // missing/corrupt file — start fresh, never throw (read-only monitor)
  }
}

async function appendSnapshot(report: AutopilotReport): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const existing = await loadSnapshots();
  existing.push(report);
  const trimmed = existing.length > MAX_SNAPSHOTS ? existing.slice(existing.length - MAX_SNAPSHOTS) : existing;
  await fs.writeFile(SNAPSHOT_FILE, JSON.stringify(trimmed, null, 0));
}

export async function getRecentSnapshots(limit = 24): Promise<AutopilotReport[]> {
  const all = await loadSnapshots();
  return all.slice(-limit);
}

/**
 * Latest report, hydrated from the persisted snapshot file after a restart
 * (the in-memory copy is empty until the next :20 cycle).
 */
export async function getLatestReportOrHydrate(): Promise<AutopilotReport | null> {
  if (latestReport) return latestReport;
  const all = await loadSnapshots();
  const last = all.length ? all[all.length - 1] : null;
  if (last && typeof last === "object" && last.generatedAt) latestReport = last;
  return latestReport;
}

export function getLatestReport(): AutopilotReport | null {
  return latestReport;
}

// ── Section computations ─────────────────────────────────────────────────────

function emptyHistogram(): Record<ClosedSkipCode, number> {
  const h = {} as Record<ClosedSkipCode, number>;
  for (const c of CLOSED_SKIP_CODES) h[c] = 0;
  return h;
}

/**
 * Reconstructs the closed-taxonomy skip histogram from `bot_trade_skips`
 * (unconditional, throttled 1/sec/key) rather than `decision_traces.code`
 * (only unconditionally written for EV_FAIL/SIZE_ZERO SKIP outcomes in
 * Phase 0 — see decision-trace.ts's own doc comment). Reuses the already-
 * tested `mapToClosedCode()` so this never re-implements taxonomy logic.
 */
async function computeSkipHistogram(sinceMs: number): Promise<{ hist: Record<ClosedSkipCode, number>; total: number; otherRaw: Record<string, number> }> {
  const rows = await db
    .select({ rejectionCode: botTradeSkips.rejectionCode, reasons: botTradeSkips.reasons })
    .from(botTradeSkips)
    .where(gte(botTradeSkips.ts, new Date(sinceMs)));
  const hist = emptyHistogram();
  const otherRaw: Record<string, number> = {};
  for (const r of rows) {
    const closed = mapToClosedCode(r.rejectionCode, r.reasons ? r.reasons.split(",") : []);
    hist[closed] = (hist[closed] ?? 0) + 1;
    if (closed === "OTHER") {
      const raw = String(r.rejectionCode || "UNKNOWN");
      otherRaw[raw] = (otherRaw[raw] ?? 0) + 1;
    }
  }
  return { hist, total: rows.length, otherRaw };
}

async function computePackMix(sinceMs: number): Promise<Array<{ pack: string; count: number; orders: number; skips: number }>> {
  const rows = await db
    .select({
      pack: decisionTraces.pack,
      outcome: decisionTraces.outcome,
      count: sql<number>`count(*)::int`,
    })
    .from(decisionTraces)
    .where(gte(decisionTraces.ts, new Date(sinceMs)))
    .groupBy(decisionTraces.pack, decisionTraces.outcome);

  const byPack = new Map<string, { count: number; orders: number; skips: number }>();
  for (const r of rows) {
    const key = r.pack ?? "(none/shadow)";
    const cur = byPack.get(key) ?? { count: 0, orders: 0, skips: 0 };
    cur.count += r.count;
    if (r.outcome === "ORDER") cur.orders += r.count;
    else cur.skips += r.count;
    byPack.set(key, cur);
  }
  return [...byPack.entries()]
    .map(([pack, v]) => ({ pack, ...v }))
    .sort((a, b) => b.count - a.count);
}

async function computeLastOrders(limit = 10) {
  const rows = await db
    .select({
      ts: decisionTraces.ts,
      ticker: decisionTraces.ticker,
      side: decisionTraces.side,
      strategyId: decisionTraces.strategyId,
      pack: decisionTraces.pack,
      combinedMult: decisionTraces.combinedMult,
      contracts: decisionTraces.contracts,
      eligible: decisionTraces.eligible,
    })
    .from(decisionTraces)
    .where(eq(decisionTraces.outcome, "ORDER"))
    .orderBy(desc(decisionTraces.ts))
    .limit(limit);

  return rows;
}

async function computeFeeNetToday() {
  const todayKey = etDateKey();
  // ET-day boundary: compare each row's own etDateKey(createdAt) rather than a
  // single UTC cutoff, so this lines up with the bot's own day-roll definition
  // (daily-target.ts) instead of drifting at UTC midnight.
  const recentRows = await db
    .select({
      pnlCents: botTrades.pnlCents,
      feeCents: botTrades.feeCents,
      isPaper: botTrades.isPaper,
      createdAt: botTrades.createdAt,
      traceId: botTrades.traceId,
    })
    .from(botTrades)
    .where(and(inArray(botTrades.outcome, ["win", "loss"]), gte(botTrades.createdAt, new Date(Date.now() - 36 * 3600_000))));

  const todayRows = recentRows.filter(r => etDateKey(r.createdAt ?? new Date()) === todayKey);

  const byPaper = new Map<boolean, { pnlCents: number; feeCents: number; trades: number }>();
  for (const r of todayRows) {
    const cur = byPaper.get(r.isPaper) ?? { pnlCents: 0, feeCents: 0, trades: 0 };
    cur.pnlCents += r.pnlCents ?? 0;
    cur.feeCents += r.feeCents ?? 0;
    cur.trades += 1;
    byPaper.set(r.isPaper, cur);
  }
  const today = [...byPaper.entries()].map(([isPaper, v]) => ({
    isPaper,
    pnlCents: v.pnlCents,
    feeCents: v.feeCents,
    netCents: v.pnlCents - v.feeCents,
    trades: v.trades,
  }));

  // Per-pack breakdown: join today's settled trades to their decision_traces
  // row via traceId (only trades placed after Phase 0 shipped carry one).
  const traceIds = todayRows.map(r => r.traceId).filter((t): t is string => !!t);
  let byPackToday: Array<{ pack: string; pnlCents: number; feeCents: number; netCents: number; trades: number }> = [];
  if (traceIds.length > 0) {
    const traceRows = await db
      .select({ traceId: decisionTraces.traceId, pack: decisionTraces.pack })
      .from(decisionTraces)
      .where(inArray(decisionTraces.traceId, traceIds));
    const packByTrace = new Map(traceRows.map(t => [t.traceId, t.pack]));
    const byPack = new Map<string, { pnlCents: number; feeCents: number; trades: number }>();
    for (const r of todayRows) {
      const pack = (r.traceId && packByTrace.get(r.traceId)) || null;
      if (!pack) continue; // no pack attribution available for this trade
      const cur = byPack.get(pack) ?? { pnlCents: 0, feeCents: 0, trades: 0 };
      cur.pnlCents += r.pnlCents ?? 0;
      cur.feeCents += r.feeCents ?? 0;
      cur.trades += 1;
      byPack.set(pack, cur);
    }
    byPackToday = [...byPack.entries()].map(([pack, v]) => ({ pack, ...v, netCents: v.pnlCents - v.feeCents }));
  }

  return { today, byPackToday };
}

// ── Anomaly / alert detection (pure, given already-computed report parts) ──

const OTHER_SKIP_ALERT_THRESHOLD = 0.5; // >50% OTHER in an hour with a meaningful sample
const OTHER_SKIP_MIN_SAMPLE = 5;

/** "FROZEN_TIME_WINDOW=192, FROZEN_CC_NOT_FIRED=8" — top raw codes inside OTHER. */
export function formatTopRawCodes(raw: Record<string, number> | undefined, limit = 3): string {
  if (!raw) return "";
  return Object.entries(raw)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([k, n]) => `${k}=${n}`)
    .join(", ");
}
const PACK_NET_LOSS_ALERT_CENTS = -1000; // -$10, documented heuristic threshold, not a live gate
const NEAR_ZERO_SAMPLE_N = 3;
const NO_UNCERTAINTY_DISCOUNT_UMULT = 0.95;

function detectAnomaliesAndAlerts(
  report: Pick<AutopilotReport, "status" | "skipHistogram" | "lastOrders" | "feeNet">,
): { anomalies: string[]; alerts: AutopilotAlert[] } {
  const anomalies: string[] = [];
  const alerts: AutopilotAlert[] = [];

  // (a) BASIS_LAG_EDGE exemption / disable check
  const basisExempt = QUARANTINE_EXEMPT.has("BASIS_LAG_EDGE");
  const basisEnabled = isStrategyEnabledSync("BASIS_LAG_EDGE");
  const basisLockedDisabled = getDbDisabledStrategies().includes("BASIS_LAG_EDGE");
  if (!basisExempt) {
    anomalies.push("BASIS_LAG_EDGE quarantine exemption is no longer present in QUARANTINE_EXEMPT");
    alerts.push({ code: "BASIS_LAG_EXEMPTION_LOST", severity: "critical", message: "BASIS_LAG_EDGE lost its quarantine exemption (QUARANTINE_EXEMPT no longer contains it)." });
  }
  if (!basisEnabled || basisLockedDisabled) {
    anomalies.push(`BASIS_LAG_EDGE is currently disabled (enabled=${basisEnabled}, lockedDisabled=${basisLockedDisabled})`);
    alerts.push({ code: "BASIS_LAG_DISABLED", severity: "warn", message: "BASIS_LAG_EDGE is disabled despite its exemption — verify this is intentional." });
  }

  // (b) ORDER placed outside its own pack's eligible set (enforce violation)
  for (const o of report.lastOrders as any[]) {
    const eligible = Array.isArray(o.eligible) ? (o.eligible as string[]) : null;
    if (o.pack && eligible && o.strategyId && !eligible.includes(o.strategyId)) {
      anomalies.push(`ORDER ${o.ticker} @ ${o.ts}: strategy ${o.strategyId} placed under pack ${o.pack} but not in its eligible set [${eligible.join(",")}]`);
      alerts.push({ code: "PACK_ENFORCE_VIOLATION", severity: "critical", message: `Strategy ${o.strategyId} traded outside pack ${o.pack}'s eligible set.` });
    }
  }

  // (c) n≈0 strategy sized at/near max contracts (possible uMult failure)
  const maxContracts = tradingBot.getStatus().config.maxContractsPerTrade;
  for (const o of report.lastOrders as any[]) {
    if (!o.strategyId) continue;
    const stats = getLiveTradeStatsSync(o.strategyId);
    if (stats.n < NEAR_ZERO_SAMPLE_N && o.combinedMult != null && o.combinedMult >= NO_UNCERTAINTY_DISCOUNT_UMULT && o.contracts != null && maxContracts != null && o.contracts >= maxContracts) {
      anomalies.push(`ORDER ${o.ticker} @ ${o.ts}: strategy ${o.strategyId} has n=${stats.n} live trades but sized at max contracts (${o.contracts}) with combinedMult=${o.combinedMult}`);
      alerts.push({ code: "LOW_SAMPLE_MAX_SIZE", severity: "warn", message: `${o.strategyId} traded at max size with only ${stats.n} live samples — check its uncertainty multiplier.` });
    }
  }

  // (d) feed/watchdog degraded, or FEED_DEAD closed-code skips present
  if (report.status.kalshiWsDegraded) {
    anomalies.push("Kalshi WS reports degraded");
    alerts.push({ code: "FEED_DEGRADED", severity: "critical", message: "Kalshi WebSocket feed is degraded." });
  }
  if (report.skipHistogram.lastHour.FEED_DEAD > 0) {
    anomalies.push(`${report.skipHistogram.lastHour.FEED_DEAD} FEED_DEAD skips in the last hour`);
    alerts.push({ code: "FEED_DEAD_SKIPS", severity: "warn", message: `${report.skipHistogram.lastHour.FEED_DEAD} FEED_DEAD skip(s) in the last hour.` });
  }

  // (e) daily halt tripped
  if (report.status.dailyTargetBlockReason) {
    anomalies.push(`Daily target engine is blocking entries: ${report.status.dailyTargetBlockReason}`);
    alerts.push({ code: "DAILY_HALT_ACTIVE", severity: "warn", message: `Daily target engine block active: ${report.status.dailyTargetBlockReason}` });
  }

  // (f) >50% OTHER skip in the last hour with a meaningful sample
  if (report.skipHistogram.lastHourTotal >= OTHER_SKIP_MIN_SAMPLE) {
    const otherFrac = report.skipHistogram.lastHour.OTHER / report.skipHistogram.lastHourTotal;
    if (otherFrac > OTHER_SKIP_ALERT_THRESHOLD) {
      anomalies.push(`OTHER skip code is ${(otherFrac * 100).toFixed(0)}% of skips in the last hour (n=${report.skipHistogram.lastHourTotal})`);
      const top = formatTopRawCodes(report.skipHistogram.lastHourOtherRaw);
      alerts.push({ code: "OTHER_SKIP_DOMINANT", severity: "warn", message: `OTHER is ${(otherFrac * 100).toFixed(0)}% of the last hour's skips — closed taxonomy is losing visibility.${top ? ` Raw codes: ${top}.` : ""}` });
    }
  }

  // (g) a pack materially fee-net negative today
  for (const p of report.feeNet.byPackToday) {
    if (p.trades >= 5 && p.netCents <= PACK_NET_LOSS_ALERT_CENTS) {
      anomalies.push(`Pack ${p.pack} is fee-net ${(p.netCents / 100).toFixed(2)} today over ${p.trades} trades`);
      alerts.push({ code: "PACK_NET_LOSS", severity: "warn", message: `Pack ${p.pack} is fee-net $${(p.netCents / 100).toFixed(2)} today (${p.trades} trades).` });
    }
  }

  return { anomalies, alerts };
}

// ── Crash-loop detection (alert-only, see file header) ──────────────────────

function detectCrashLoop(): AutopilotAlert | null {
  const wd = watchdog.getStatus?.();
  if (!wd) return null;
  const degraded = Object.entries(wd).filter(([, v]: [string, any]) => v?.status === "degraded");
  if (degraded.length > 0) {
    return {
      code: "SUBSYSTEM_DEGRADED",
      severity: "critical",
      message: `Watchdog reports degraded subsystem(s): ${degraded.map(([k]) => k).join(", ")}. No automatic restart attempted (alert-only — see autopilot-monitor.ts scope note).`,
    };
  }
  return null;
}

// ── Cycle orchestration ──────────────────────────────────────────────────────

let running = false;

export async function runAutopilotCycle(): Promise<AutopilotReport> {
  if (running) {
    throw new Error("autopilot-monitor cycle already in progress");
  }
  running = true;
  const startTs = Date.now();
  try {
    const now = Date.now();
    const hourAgo = now - 3600_000;
    const dayAgo = now - 24 * 3600_000;

    const botStatus = tradingBot.getStatus();
    const regimeDebug = getRegimeDebug();

    const [hourHist, dayHist, packMix, lastOrders, feeNet] = await Promise.all([
      computeSkipHistogram(hourAgo),
      computeSkipHistogram(dayAgo),
      computePackMix(dayAgo),
      computeLastOrders(10),
      computeFeeNetToday(),
    ]);

    const switches = getRegimeSwitchHistory(hourAgo);
    const last10 = getRegimeSwitchHistory().slice(-10).map(s => ({
      from: s.from, to: s.to, ts: new Date(s.ts).toISOString(), reason: s.reason,
    }));

    const report: AutopilotReport = {
      generatedAt: new Date(now).toISOString(),
      cycleMs: 0,
      status: {
        autoMode: botStatus.config.autoMode,
        paperMode: botStatus.config.paperMode,
        specialistPacksMode: botStatus.config.specialistPacksMode,
        regime: getRegime(),
        regimeHeldBy: regimeDebug.regimeHeldBy,
        botState: botStatus.state,
        kalshiWsDegraded: kalshiWS.isDegraded(),
        dailyTargetBlockReason: botStatus.dailyTarget?.blockReason ?? null,
      },
      regimeSwitches: { lastHour: switches.length, last10 },
      packMix,
      skipHistogram: {
        lastHour: hourHist.hist,
        last24h: dayHist.hist,
        lastHourTotal: hourHist.total,
        last24hTotal: dayHist.total,
        lastHourOtherRaw: hourHist.otherRaw,
        last24hOtherRaw: dayHist.otherRaw,
      },
      lastOrders: lastOrders.map(o => ({
        ts: new Date(o.ts).toISOString(),
        ticker: o.ticker,
        side: o.side,
        strategyId: o.strategyId,
        pack: o.pack,
        combinedMult: o.combinedMult,
        contracts: o.contracts,
      })),
      feeNet: {
        today: feeNet.today,
        byPackToday: feeNet.byPackToday,
      },
      anomalies: [],
      alerts: [],
      actionsTaken: [],
    };

    // Attach eligible arrays temporarily for anomaly detection (b), without
    // polluting the persisted/report lastOrders shape's public contract.
    const lastOrdersWithEligible = lastOrders.map(o => ({ ...o, ts: new Date(o.ts).toISOString() }));
    const { anomalies, alerts } = detectAnomaliesAndAlerts({ ...report, lastOrders: lastOrdersWithEligible as any });

    // Mode-change watch: specialistPacksMode flipping between cycles is worth
    // flagging even though this module itself never causes it.
    if (lastSpecialistPacksMode !== null && lastSpecialistPacksMode !== report.status.specialistPacksMode) {
      anomalies.push(`specialistPacksMode changed: ${lastSpecialistPacksMode} → ${report.status.specialistPacksMode}`);
      alerts.push({ code: "PACKS_MODE_CHANGED", severity: "warn", message: `specialistPacksMode changed from ${lastSpecialistPacksMode} to ${report.status.specialistPacksMode} (this module never makes this change itself).` });
    }
    lastSpecialistPacksMode = report.status.specialistPacksMode;

    const crashAlert = detectCrashLoop();
    if (crashAlert) alerts.push(crashAlert);

    report.anomalies = anomalies;
    report.alerts = alerts;
    report.actionsTaken = ["persisted snapshot", "re-emitted skip histogram + pack mix to logs"];
    report.cycleMs = Date.now() - startTs;

    for (const a of alerts) {
      logger.warn({ alert: a }, `[autopilot-monitor] ALERT ${a.code}: ${a.message}`);
    }
    logger.info(
      { skipHistLastHour: hourHist.hist, packMix: packMix.map(p => `${p.pack}:${p.count}`) },
      "[autopilot-monitor] cycle complete",
    );

    await appendSnapshot(report);
    latestReport = report;
    return report;
  } finally {
    running = false;
  }
}

// ── Markdown formatting (matches the requested per-cycle report format) ────

export function formatReportMarkdown(r: AutopilotReport): string {
  const lines: string[] = [];
  lines.push("## Status");
  lines.push(`- Generated: ${r.generatedAt} (cycle ${r.cycleMs}ms)`);
  lines.push(`- Mode: autoMode=${r.status.autoMode} paperMode=${r.status.paperMode} specialistPacksMode=${r.status.specialistPacksMode}`);
  lines.push(`- Regime: ${r.status.regime}${r.status.regimeHeldBy ? ` (held: ${r.status.regimeHeldBy})` : ""} — ${r.regimeSwitches.lastHour} switch(es) in the last hour`);
  lines.push(`- Bot state: ${r.status.botState} | Kalshi WS degraded: ${r.status.kalshiWsDegraded} | Daily halt: ${r.status.dailyTargetBlockReason ?? "none"}`);
  lines.push("");
  lines.push("## Alerts");
  if (r.alerts.length === 0) {
    lines.push("- none");
  } else {
    for (const a of r.alerts) lines.push(`- [${a.severity.toUpperCase()}] ${a.code}: ${a.message}`);
  }
  lines.push("");
  lines.push("## Skip histogram");
  lines.push(`- Last hour (n=${r.skipHistogram.lastHourTotal}): ` + CLOSED_SKIP_CODES.map(c => `${c}=${r.skipHistogram.lastHour[c]}`).join(", "));
  lines.push(`- Last 24h (n=${r.skipHistogram.last24hTotal}): ` + CLOSED_SKIP_CODES.map(c => `${c}=${r.skipHistogram.last24h[c]}`).join(", "));
  { const top = formatTopRawCodes(r.skipHistogram.lastHourOtherRaw, 6); if (top) lines.push(`- OTHER breakdown (last hour): ${top}`); }
  lines.push(`- Pack mix (24h): ` + (r.packMix.length ? r.packMix.map(p => `${p.pack}[orders=${p.orders},skips=${p.skips}]`).join(", ") : "none"));
  lines.push("");
  lines.push("## Last orders");
  if (r.lastOrders.length === 0) {
    lines.push("- none in the tracked window");
  } else {
    for (const o of r.lastOrders) {
      lines.push(`- ${o.ts} ${o.ticker} ${o.side ?? "?"} strategy=${o.strategyId ?? "?"} pack=${o.pack ?? "none"} combinedMult=${o.combinedMult ?? "?"} contracts=${o.contracts ?? "?"}`);
    }
  }
  lines.push(`- Fee-net today: ` + (r.feeNet.today.length ? r.feeNet.today.map(t => `${t.isPaper ? "paper" : "live"} net=$${(t.netCents / 100).toFixed(2)} (${t.trades} trades)`).join(", ") : "no settled trades yet"));
  lines.push("");
  lines.push("## Actions taken");
  for (const a of r.actionsTaken) lines.push(`- ${a}`);
  lines.push("- No mutation to EV floors, packs, strategy enable/disable, or size caps was made or attempted.");
  lines.push("");
  lines.push("## STOP");
  return lines.join("\n");
}
