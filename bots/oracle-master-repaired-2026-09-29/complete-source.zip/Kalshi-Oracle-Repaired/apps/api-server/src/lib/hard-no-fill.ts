/** hard-no-fill.ts — HARD_NO_FILL / LOCKED denylist (PhD peel from trading-bot).
 * Never ENABLE leftovers. Re-exported from trading-bot.ts for stable paths.
 */
/**
 * Incident-response-protocol L3 (SEV1 audit, 2026-08-18): these strategy IDs
 * must ALWAYS be treated as disabled, independent of whatever
 * config.disabledStrategies happens to contain. Before this fix, L3
 * compliance rested entirely on (a) the in-code default array — which only
 * listed 2 of these 3 — and (b) DB performance-quarantine coincidentally
 * also blocking the other one right now. Neither is a real lock: a config
 * update, a persisted-file edit, or a strategy's quarantine simply clearing
 * once its stats improve would each silently re-enable a permanently-locked
 * strategy with no code path stopping it. This set is the actual lock —
 * never remove an ID from here without an explicit human policy change, and
 * never let it be satisfied indirectly (e.g. via DB quarantine) instead of
 * unconditionally.
 */
export const LOCKED_DISABLED_STRATEGIES: readonly string[] = [
  'SAKATA_CANDLE_PATTERN',
  'MTF_ALIGNED',
  // BRTI_PROBABILITY unlocked for PAPER DESK v2 placeable set (paper Tier A).
  // Still fail-closed on live via disabledStrategies defaults; not SEV1.
  // Profit Doctrine hard lock (2026-08-25): "never re-enable ... any OTM_*
  // strategy" is unconditional — it does not carve out an exception for a
  // separate allowlist. Added here so the 2026-08-25 LIVE_CORE-cap removal
  // (eligibility expansion order) cannot accidentally admit these; they were
  // never individually reviewed/backtested for live money.
  'DEEP_OTM_SNIPER',
  'OTM_ASYMMETRY',
  'OTM_BREAKOUT_EXPANSION',
];

export const HARD_NO_FILL_STRATEGY_IDS: readonly string[] = [
  "LATE_ENTRY_ANCHOR",
  "SETTLEMENT_PREDICTION",
  "PAPER_SCALP",
  "FLOOR_DISTANCE",
  "TICKET_WAVE",
  "HA_RIVER",
  "HA_FLIP",
  "NO_CROSS",
  "LATE_MOMENTUM_CONTINUATION",
  // Phase A quarantine: CHEAP_EARLY_EXIT shadow — never fill. CHEAP_SIDE_15M stays
  // PAPER_TIER_A (dual-gate + disabled + leftover mayRun deny); not HARD_NO_FILL.
  "CHEAP_EARLY_EXIT",
  // PAPER DESK v2: VELOCITY_MOMENTUM + BRTI_PROBABILITY placeable — not HARD_NO_FILL.
  ...LOCKED_DISABLED_STRATEGIES,
];

export function isHardNoFillStrategy(strategyId: string | null | undefined): boolean {
  if (!strategyId) return false;
  if ((HARD_NO_FILL_STRATEGY_IDS as readonly string[]).includes(strategyId)) return true;
  if (strategyId === "LATE_ENTRY" || strategyId.startsWith("OTM_")) return true;
  return false;
}

export const LEFTOVER_PLACEORDER_DENYLIST: readonly string[] = HARD_NO_FILL_STRATEGY_IDS;

