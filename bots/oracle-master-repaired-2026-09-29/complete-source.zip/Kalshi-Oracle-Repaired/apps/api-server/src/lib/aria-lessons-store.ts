/**
 * aria-lessons-store.ts
 *
 * Persistent memory layer behind ARIA's learning loop. Backed by the
 * `aria_lessons` table so lessons survive process restarts and accumulate
 * across cycles — unlike the raw last-N-trades context expert-agent.ts feeds
 * into every prompt, which forgets a trade the moment it scrolls out of that
 * window.
 *
 * Cached in memory (same pattern as strategy-performance.ts / regime-ev-stats.ts)
 * so the 45s ARIA loop never blocks its prompt-building on a DB round-trip;
 * the cache is refreshed after every write.
 */
import { db, ariaLessons } from "@workspace/db";
import { desc, eq, isNull, sql } from "drizzle-orm";
import { logger } from "./logger.js";

const MAX_LESSONS_PER_STRATEGY = 6;   // most reinforced lessons kept per strategy bucket
const MAX_TOTAL_LESSONS        = 60;  // hard cap across all strategies + general bucket
const SIMILARITY_PREFIX_LEN    = 40;  // crude "same lesson again" dedupe: compare normalized text

let cache: import("@workspace/db").AriaLesson[] = [];
let cacheLoaded = false;

function normalize(text: string): string {
  return text.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();
}

/** Crude similarity check: same strategy bucket + a long shared normalized prefix,
 *  or one string containing the other. Good enough to avoid the same conclusion
 *  ("Confluence Cascade underperforms in ranging regime with unknown win-rate")
 *  being re-inserted every cycle as a new row instead of reinforcing the existing one. */
function isSimilar(a: string, b: string): boolean {
  const na = normalize(a), nb = normalize(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  if (na.includes(nb) || nb.includes(na)) return true;
  const len = Math.min(SIMILARITY_PREFIX_LEN, na.length, nb.length);
  return len >= 15 && na.slice(0, len) === nb.slice(0, len);
}

async function refreshCache(): Promise<void> {
  cache = await db.select().from(ariaLessons).orderBy(desc(ariaLessons.lastReinforcedAt));
  cacheLoaded = true;
}

/** Ensures the cache is populated at least once (call at startup). */
export async function loadAriaLessons(): Promise<void> {
  try {
    await refreshCache();
    logger.info({ count: cache.length }, "[aria-lessons] cache hydrated from DB");
  } catch (err) {
    logger.warn({ err: (err as Error).message }, "[aria-lessons] initial load failed — starting empty");
  }
}

/**
 * Synchronous read for prompt-building — safe to call every ARIA cycle.
 * Returns the top lessons (most-reinforced/most-recent first), grouped
 * general-first then by strategy, capped so the prompt never grows unbounded.
 */
export function getRelevantLessons(strategyIds?: string[]): { strategyId: string | null; lesson: string; timesReinforced: number }[] {
  const wanted = strategyIds ? new Set(strategyIds) : null;
  const filtered = cache.filter(l => !wanted || l.strategyId === null || wanted.has(l.strategyId));
  return filtered
    .slice(0, 25)
    .map(l => ({ strategyId: l.strategyId, lesson: l.lesson, timesReinforced: l.timesReinforced }));
}

/** Read-only snapshot for the API/UI — every stored lesson, most recent first. */
export function getAllLessons() {
  return cache;
}

/**
 * Merge a batch of newly-proposed lessons (from ARIA's structured response)
 * into the store: reinforce an existing similar lesson for the same strategy
 * bucket instead of duplicating it, otherwise insert a new row. Fire-and-forget
 * safe — callers should not let a failure here interrupt the ARIA loop.
 */
export async function recordLessons(
  proposed: { strategyId: string | null; lesson: string; sourceTradeId?: number | null }[],
): Promise<void> {
  if (proposed.length === 0) return;
  if (!cacheLoaded) await refreshCache();

  for (const p of proposed) {
    const text = p.lesson.trim().slice(0, 400);
    if (!text) continue;

    const existing = cache.find(l => l.strategyId === p.strategyId && isSimilar(l.lesson, text));
    try {
      if (existing) {
        await db.update(ariaLessons)
          .set({ timesReinforced: existing.timesReinforced + 1, lastReinforcedAt: new Date(), sourceTradeId: p.sourceTradeId ?? existing.sourceTradeId })
          .where(eq(ariaLessons.id, existing.id));
      } else {
        await db.insert(ariaLessons).values({
          strategyId: p.strategyId, lesson: text, sourceTradeId: p.sourceTradeId ?? null,
        });
      }
    } catch (err) {
      logger.warn({ err: (err as Error).message, lesson: text }, "[aria-lessons] write failed for one lesson");
    }
  }

  await pruneIfNeeded();
  await refreshCache();
}

/** Keep the store bounded: drop least-reinforced/oldest rows beyond the cap,
 *  per-strategy first (so no single strategy can crowd out the rest), then
 *  overall. Never throws — a failed prune just leaves the store slightly
 *  over-cap until the next successful cycle. */
async function pruneIfNeeded(): Promise<void> {
  try {
    const rows = await db.select().from(ariaLessons);
    const byStrategy = new Map<string | null, typeof rows>();
    for (const r of rows) {
      const key = r.strategyId;
      const list = byStrategy.get(key) ?? [];
      list.push(r);
      byStrategy.set(key, list);
    }
    const idsToDelete: number[] = [];
    for (const list of byStrategy.values()) {
      if (list.length <= MAX_LESSONS_PER_STRATEGY) continue;
      const sorted = [...list].sort((a, b) =>
        b.timesReinforced - a.timesReinforced || b.lastReinforcedAt.getTime() - a.lastReinforcedAt.getTime());
      idsToDelete.push(...sorted.slice(MAX_LESSONS_PER_STRATEGY).map(r => r.id));
    }
    if (rows.length - idsToDelete.length > MAX_TOTAL_LESSONS) {
      const remaining = rows.filter(r => !idsToDelete.includes(r.id))
        .sort((a, b) => b.timesReinforced - a.timesReinforced || b.lastReinforcedAt.getTime() - a.lastReinforcedAt.getTime());
      idsToDelete.push(...remaining.slice(MAX_TOTAL_LESSONS).map(r => r.id));
    }
    if (idsToDelete.length > 0) {
      await db.delete(ariaLessons).where(sql`${ariaLessons.id} in (${sql.join(idsToDelete.map(id => sql`${id}`), sql`, `)})`);
    }
  } catch (err) {
    logger.warn({ err: (err as Error).message }, "[aria-lessons] prune failed");
  }
}
