/**
 * backtest-suggestions.test.ts
 *
 * Unit tests for the backtest suggestion diff logic:
 *   - n≥30 sample-size gate
 *   - ci.p5 > 0.50 conservative-bound gate
 *   - a field with too few samples never appears as "recommended"
 *   - a field with a losing ci.p5 never appears as "recommended"
 *   - fields that DO pass both gates are surfaced with correct values
 *   - observationMinute is never surfaced as a suggestion
 *
 * Run with:  tsx --test src/lib/backtest-suggestions.test.ts
 * (or via `pnpm run test` which globs all *.test.ts)
 */

import { test } from "node:test";
import assert from "node:assert/strict";

// Import from the route file (pure computeSuggestions is exported).
// We import the compiled JS extension; tsx/node strips types at runtime.
import {
  computeSuggestions,
  SUGGESTIONS_MIN_SAMPLE,
  SUGGESTIONS_CI_P5_FLOOR,
  type SuggestionRow,
} from "../routes/backtest.js";

// ── Helpers ───────────────────────────────────────────────────────────────────

function makeTop1(overrides: {
  tradesEntered?: number;
  winRate?: number;
  ciP5?: number;
  strategyOverrides?: Record<string, unknown>;
}) {
  return {
    oos: {
      tradesEntered: overrides.tradesEntered ?? 50,
      winRate:       overrides.winRate       ?? 0.65,
      strategy: {
        // All fields that configFromBacktest() maps — mirrors MAPPED_FIELDS in the route.
        minVelocity:        25,
        useEdge:            true,
        minEdge:            5,
        useStallFilter:     true,
        useAcceleration:    false,
        useLossCooldown:    true,
        cooldownMultiplier: 1.5,
        useStopLoss:        true,
        stopLossCents:      12,
        useProfitTake:      false,
        profitTakeCents:    10,
        drawdownGuardPct:   20,
        // observationMinute intentionally included to verify it is NOT surfaced.
        observationMinute:  10,
        ...overrides.strategyOverrides,
      },
    },
    ci: { p5: overrides.ciP5 ?? 0.58 },
  };
}

function makeLiveConfig(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  // Default live config that differs from top1 on several fields.
  return {
    minVelocity:        15,   // differs → suggestion candidate
    useProbEdge:        false, // differs (strat.useEdge=true) → suggestion candidate
    minProbEdge:        0,
    useStallFilter:     false, // differs → suggestion candidate
    useAcceleration:    false, // same as strat → not a candidate
    useLossCooldown:    true,  // same → not a candidate
    cooldownMultiplier: 1.5,   // same → not a candidate
    useStopLoss:        true,  // same → not a candidate
    stopLossCents:      12,    // same → not a candidate
    useProfitTake:      false, // same → not a candidate
    profitTakeCents:    10,    // same → not a candidate
    drawdownGuardPct:   25,    // differs → suggestion candidate
    ...overrides,
  };
}

// ── Tests ─────────────────────────────────────────────────────────────────────

test("SUGGESTIONS_MIN_SAMPLE is 30", () => {
  assert.equal(SUGGESTIONS_MIN_SAMPLE, 30);
});

test("SUGGESTIONS_CI_P5_FLOOR is 0.50", () => {
  assert.equal(SUGGESTIONS_CI_P5_FLOOR, 0.50);
});

test("gate: sample size below 30 → gated=true, no suggestions", () => {
  const top1 = makeTop1({ tradesEntered: 29, ciP5: 0.58 });
  const { suggestions, gated, gateReason } = computeSuggestions(
    top1, makeLiveConfig(), 200
  );
  assert.equal(gated, true);
  assert.equal(suggestions.length, 0);
  assert.ok(gateReason?.includes("30"), `gateReason should mention 30, got: ${gateReason}`);
});

test("gate: sample size exactly 30 → not gated by sample-size gate", () => {
  const top1 = makeTop1({ tradesEntered: 30, ciP5: 0.58 });
  const { gated } = computeSuggestions(top1, makeLiveConfig(), 200);
  // ci.p5=0.58 > 0.50, so should NOT be gated at all
  assert.equal(gated, false);
});

test("gate: ci.p5 exactly at floor (0.50) → gated=true, no suggestions", () => {
  const top1 = makeTop1({ tradesEntered: 50, ciP5: 0.50 });
  const { suggestions, gated } = computeSuggestions(top1, makeLiveConfig(), 200);
  assert.equal(gated, true);
  assert.equal(suggestions.length, 0);
});

test("gate: ci.p5 below floor (0.48) → gated=true, no suggestions", () => {
  const top1 = makeTop1({ tradesEntered: 50, ciP5: 0.48 });
  const { suggestions, gated } = computeSuggestions(top1, makeLiveConfig(), 200);
  assert.equal(gated, true);
  assert.equal(suggestions.length, 0);
});

test("gate: ci.p5 above floor and sample >= 30 → suggestions surfaced", () => {
  const top1 = makeTop1({ tradesEntered: 50, ciP5: 0.55 });
  const { suggestions, gated } = computeSuggestions(top1, makeLiveConfig(), 200);
  assert.equal(gated, false);
  assert.ok(suggestions.length > 0, "expected at least one suggestion");
});

test("only fields that differ from live config are surfaced", () => {
  const top1 = makeTop1({ tradesEntered: 50, ciP5: 0.55 });
  const live = makeLiveConfig();
  const { suggestions } = computeSuggestions(top1, live, 200);

  // Fields where strat === live should not appear
  for (const s of suggestions) {
    assert.notEqual(
      s.liveValue, s.recommendedValue,
      `field "${s.field}" has the same value on both sides but was still surfaced`
    );
  }
});

test("observationMinute is NEVER surfaced as a suggestion", () => {
  // observationMinute=10 in strat, live config has no minProbEdge or similar —
  // it must not appear regardless.
  const top1 = makeTop1({ tradesEntered: 50, ciP5: 0.62, strategyOverrides: { observationMinute: 10 } });
  const live = { ...makeLiveConfig(), observationMinute: 5 }; // intentionally include it in live
  const { suggestions } = computeSuggestions(top1, live, 200);

  const obsRow = suggestions.find(s => s.field.toLowerCase().includes("observation"));
  assert.equal(obsRow, undefined, "observationMinute must never appear in suggestions");
});

test("each suggestion carries oosWinRate, sampleSize, and ciP5", () => {
  const top1 = makeTop1({ tradesEntered: 42, winRate: 0.67, ciP5: 0.59 });
  const { suggestions } = computeSuggestions(top1, makeLiveConfig(), 200);
  for (const s of suggestions) {
    assert.equal(s.oosWinRate, 0.67);
    assert.equal(s.sampleSize, 42);
    assert.equal(s.ciP5, 0.59);
  }
});

test("no suggestions when strat and live config are identical", () => {
  // Make live config match all the strat fields exactly
  const live = makeLiveConfig({
    minVelocity:        25,  // match strat
    useProbEdge:        true,
    minProbEdge:        5,
    useStallFilter:     true,
    drawdownGuardPct:   20,
  });
  const top1 = makeTop1({ tradesEntered: 50, ciP5: 0.58 });
  const { suggestions, gated } = computeSuggestions(top1, live, 200);
  assert.equal(gated, false);
  assert.equal(suggestions.length, 0);
});

test("minVelocity suggestion shows correct live/recommended values", () => {
  const top1 = makeTop1({ tradesEntered: 50, ciP5: 0.58, strategyOverrides: { minVelocity: 40 } });
  const live = makeLiveConfig({ minVelocity: 15 });
  const { suggestions } = computeSuggestions(top1, live, 200);

  const row = suggestions.find(s => s.field.toLowerCase().includes("velocity"));
  assert.ok(row, "expected a minVelocity suggestion");
  assert.equal(row!.liveValue, 15);
  assert.equal(row!.recommendedValue, 40);
});

test("useEdge/useProbEdge mapping: strat.useEdge maps to config.useProbEdge", () => {
  // strat.useEdge=true, live.useProbEdge=false → should surface
  const top1 = makeTop1({ tradesEntered: 50, ciP5: 0.58, strategyOverrides: { useEdge: true } });
  const live = makeLiveConfig({ useProbEdge: false });
  const { suggestions } = computeSuggestions(top1, live, 200);

  const row = suggestions.find(s => s.field.toLowerCase().includes("edge filter"));
  assert.ok(row, "expected a useProbEdge suggestion");
  assert.equal(row!.liveValue, false);
  assert.equal(row!.recommendedValue, true);
});
