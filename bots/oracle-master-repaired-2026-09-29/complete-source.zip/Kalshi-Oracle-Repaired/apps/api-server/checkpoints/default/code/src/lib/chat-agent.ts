/**
 * chat-agent.ts — the desk chat agent loop (round 2): free-model routing
 * (chat-router), native tool calls, read-only desk tools + propose_fix
 * (chat-desk-tools), small desk-specific prompt, clear errors.
 */
import { DESK_KNOWLEDGE_SUMMARY } from "./desk-knowledge.js";
import { CooldownBook, completeWithFallback, budgetMessages, userFacingRouteError, ChatRouteError, availableRoute, estTokens, CONTEXT_TOKEN_BUDGET, type Msg, type ProviderEnv, type RouteAttempt } from "./chat-router.js";
import { DESK_TOOL_SPECS, runDeskTool, type DeskToolDeps } from "./chat-desk-tools.js";

export const chatCooldowns = new CooldownBook();
/** R3 — soft budget: tools offered for up to 5 rounds, extended to 8 while the
 *  compacted working context still fits CONTEXT_TOKEN_BUDGET; then one forced
 *  no-tools answer round. */
export const MAX_AGENT_TOOL_ROUNDS = 5;
export const MAX_AGENT_TOOL_ROUNDS_EXTENDED = 8;
/** Older tool results shrink to this many chars once a newer round exists. */
export const OLD_TOOL_RESULT_CHARS = 400;
export const FINAL_ANSWER_INSTRUCTION = "Tool budget reached. Do NOT call any more tools. Answer the question now in plain prose using only the tool results above; say plainly what you could not verify.";

/** Shrink tool results from rounds before `keepFromIndex` (the newest round stays full). */
export function compactOldToolResults(turns: Msg[], keepFromIndex: number, maxChars = OLD_TOOL_RESULT_CHARS): Msg[] {
  return turns.map((t, i) => (i < keepFromIndex && t.role === "tool" && t.content.length > maxChars)
    ? { ...t, content: `${t.content.slice(0, maxChars)}…[older tool output compacted, ${t.content.length - maxChars} chars dropped]` }
    : t);
}

/** Budget the context but never lose the question being answered. */
export function budgetWithPinnedQuestion(system: string, turns: Msg[], questionIndex: number): Msg[] {
  const kept = budgetMessages(system, turns);
  const q = questionIndex >= 0 ? turns[questionIndex] : undefined;
  if (!q || kept.includes(q)) return kept;
  const rest = budgetMessages(system + "\n" + q.content, turns.slice(questionIndex + 1));
  while (rest.length > 0 && rest[0]!.role === "tool") rest.shift();
  return [q, ...rest];
}

/** Fallback when the model still won't answer: plain digest of what the tools returned. */
export function digestToolResults(turns: Msg[], fromIndex: number): string {
  const rows = turns.slice(fromIndex).filter((t) => t.role === "tool").slice(-4);
  if (rows.length === 0) return "I couldn't finish that within the tool budget. Try a narrower question (one file or one metric).";
  return ["I hit the tool budget before writing a full answer. Raw results from the last tools I ran:",
    ...rows.map((t) => `• ${t.toolName ?? "tool"}: ${t.content.replace(/\s+/g, " ").slice(0, 280)}`)].join("\n");
}

export function deskAgentSystemPrompt(snap: { paperMode: boolean; state: string; balance$: string; lastSignal?: string; regime?: string | null }): string {
  return [
    "You are the Oracle desk agent for a Kalshi KXBTC15M (15-minute BTC) PAPER trading bot. Be concise and concrete.",
    "Use tools for facts; never invent balances, fills, trades or code. Prefer: get_status, get_entry_funnel, get_decision_traces, tail_log, get_recent_trades, get_healthz, search_code/read_file (read ≤200 lines at a time).",
    "Frozen desk: only CONFLUENCE_CASCADE trades; entries need the aligned-take gate and the Mind/brain bind; p = winRateAtPrice; EV floor 3¢ after fees; Kelly ≤0.60; 9% per trade / 18% day caps; 15% reserve; paperMode stays true. Skipping is a valid outcome.",
    "You cannot change config, trade, restart or deploy. For code fixes call propose_fix with a git-style unified diff (paths from repo root, e.g. apps/api-server/src/lib/x.ts). It refuses hard-lock files/params (EV/Kelly/band/reserve/caps/paperMode/organ locks, lock tests), runs targeted tests in a temp copy, and opens a draft PR only on a new branch. Never claim a fix is merged or live.",
    "Never print secrets or tool-call markup. Answer in plain prose, short lists when useful.",
    DESK_KNOWLEDGE_SUMMARY,
    `Now: ${snap.paperMode ? "PAPER" : "LIVE"} · ${snap.state} · balance $${snap.balance$}${snap.regime ? ` · regime ${snap.regime}` : ""}${snap.lastSignal ? ` · last: ${snap.lastSignal.slice(0, 160)}` : ""}`,
  ].join("\n");
}

export type AgentEvent =
  | { type: "tool_start"; name: string; label: string }
  | { type: "tool_done"; name: string; summary: string }
  | { type: "delta"; content: string }
  | { type: "meta"; model: string | null; provider: string | null; attempts: RouteAttempt[]; error?: string };

export async function* runDeskAgent(opts: {
  question: string;
  history: { role: string; content: string }[];
  deps: DeskToolDeps;
  env?: ProviderEnv;
  fetchImpl?: typeof fetch;
  cooldowns?: CooldownBook;
  timeoutMs?: number;
  sleepImpl?: (ms: number) => Promise<void>;
  /** Role gate (accounts/chat-policy.ts): when set, only these tools are offered or run. */
  allowedTools?: ReadonlySet<string>;
}): AsyncGenerator<AgentEvent, { text: string; failed: boolean }> {
  const env = (opts.env ?? process.env) as ProviderEnv;
  const cooldowns = opts.cooldowns ?? chatCooldowns;
  const s = (() => { try { return opts.deps.getStatus() ?? {}; } catch { return {}; } })();
  const system = deskAgentSystemPrompt({
    paperMode: s?.config?.paperMode !== false,
    state: String(s?.state ?? "UNKNOWN"),
    balance$: typeof s?.paperVirtualBalanceCents === "number" ? (s.paperVirtualBalanceCents / 100).toFixed(2) : "?",
    lastSignal: typeof s?.lastSignal === "string" ? s.lastSignal : undefined,
    regime: s?.detectedRegime ?? null,
  });
  const turns: Msg[] = [];
  for (const m of opts.history.slice(-12)) {
    const c = typeof m.content === "string" ? m.content.trim() : "";
    if (!c) continue;
    turns.push({ role: m.role === "assistant" || m.role === "model" ? "assistant" : "user", content: c });
  }
  const q = opts.question.trim();
  if (q && (turns.length === 0 || turns[turns.length - 1]!.content !== q || turns[turns.length - 1]!.role !== "user")) turns.push({ role: "user", content: q });
  const attempts: RouteAttempt[] = [];
  let lastModel: { model: string; provider: string } | null = null;
  const route = availableRoute(env);
  const allowed = opts.allowedTools;
  const toolSpecs = allowed ? DESK_TOOL_SPECS.filter((t) => allowed.has(t.name)) : DESK_TOOL_SPECS;
  const questionIndex = turns.length - 1;
  const seenCalls = new Map<string, string>();
  let toolRounds = 0;
  for (let round = 0; round <= MAX_AGENT_TOOL_ROUNDS_EXTENDED; round++) {
    const working = budgetWithPinnedQuestion(system, turns, questionIndex);
    const workingTokens = estTokens(system) + working.reduce((a, t) => a + estTokens(t.content) + 8, 0);
    const offerTools = toolRounds < MAX_AGENT_TOOL_ROUNDS
      || (toolRounds < MAX_AGENT_TOOL_ROUNDS_EXTENDED && workingTokens <= CONTEXT_TOKEN_BUDGET);
    const msgs: Msg[] = offerTools ? working : [...working, { role: "user", content: FINAL_ANSWER_INSTRUCTION }];
    let res;
    try {
      res = await completeWithFallback({ system, messages: msgs, tools: offerTools ? toolSpecs : [], env, cooldowns, fetchImpl: opts.fetchImpl, route, timeoutMs: opts.timeoutMs, sleepImpl: opts.sleepImpl, attempts });
    } catch (e) {
      const err = e instanceof ChatRouteError ? e : new ChatRouteError("all_failed", attempts, null);
      const text = userFacingRouteError(err, cooldowns);
      // Diagnosable failures (R2): model, kind, HTTP status and a short provider message; never keys.
      console.warn("[chat-agent] all free models failed", JSON.stringify({ round, code: err.code, attempts: attempts.slice(-12) }));
      yield { type: "meta", model: lastModel?.model ?? null, provider: lastModel?.provider ?? null, attempts, error: err.code };
      // R3: don't throw away tool work already done this turn.
      return { text: toolRounds > 0 ? `${text}\n\n${digestToolResults(turns, questionIndex + 1)}` : text, failed: true };
    }
    lastModel = { model: res.model.model, provider: res.model.provider };
    // Final (no-tools) round: ignore any tool calls the model still emits.
    if (res.out.toolCalls.length === 0 || !offerTools) {
      yield { type: "meta", model: res.model.model, provider: res.model.provider, attempts };
      const text = res.out.text.trim();
      if (text) return { text, failed: false };
      return { text: digestToolResults(turns, questionIndex + 1), failed: true };
    }
    // Compact the previous rounds before appending this one.
    const roundStart = turns.length;
    turns.splice(0, turns.length, ...compactOldToolResults(turns, roundStart));
    turns.push({ role: "assistant", content: res.out.text, toolCalls: res.out.toolCalls });
    for (const call of res.out.toolCalls.slice(0, 4)) {
      const key = `${call.name}:${JSON.stringify(call.args ?? {})}`;
      yield { type: "tool_start", name: call.name, label: `${call.name.replace(/_/g, " ")}…` };
      let result: string;
      const prior = seenCalls.get(key);
      if (prior !== undefined) {
        result = JSON.stringify({ note: "Same call already made this turn; its result is above. Use it or answer now." });
      } else {
        if (allowed && !allowed.has(call.name)) {
          result = JSON.stringify({ refused: true, reason: "tool not available for this account (Administrator only)" });
        } else {
          try { result = await runDeskTool(call.name, call.args, opts.deps); } catch (e) { result = JSON.stringify({ error: String((e as Error)?.message ?? e) }); }
        }
        seenCalls.set(key, result);
      }
      yield { type: "tool_done", name: call.name, summary: result.slice(0, 90) };
      turns.push({ role: "tool", content: result, toolCallId: call.id, toolName: call.name });
    }
    toolRounds++;
  }
  yield { type: "meta", model: lastModel?.model ?? null, provider: lastModel?.provider ?? null, attempts };
  return { text: digestToolResults(turns, questionIndex + 1), failed: true };
}
