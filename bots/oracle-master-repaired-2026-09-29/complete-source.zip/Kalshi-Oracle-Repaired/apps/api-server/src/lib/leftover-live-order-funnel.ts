/**
 * Leftover live Kalshi order POST (entry + early exit). Paper KXBTC15M never runs it.
 * Paper fills/exits stay in host. Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
import { randomUUID } from "node:crypto";
import { db, botTrades } from "@workspace/db";
import { eq } from "drizzle-orm";
import { KALSHI_API_DOMAIN, KALSHI_PATH_PORTFOLIO_ORDERS, kalshiEventsOrderPath, kalshiTakerFeeCents } from "./constants.js";
import { configuredExitJournalStore, exitJournalKey } from "./exit-journal.js";
import { executeConfirmedExit, carriedExitEconomics } from "./exit-execution.js";
import { definitiveOrderRejection } from "./settlement-commit.js";
import { buildKalshiV2Body, buildKalshiV2ExitBody, stableClientOrderId } from "./kalshi-order-body.js";
import { recordFailure, recordSuccess } from "./decision-safety.js";

export const LEFTOVER_LIVE_ORDER_FUNNEL_LOADED = true as const;

export const FROZEN_LIVE_ORDER_MARKERS = [
  "KALSHI_PATH_PORTFOLIO_ORDERS",
  "Auth signing failed — live order blocked",
  "executeConfirmedExit(journal",
  "Order submission AMBIGUOUS",
] as const;

export type LeftoverLiveOrderHelpers = {
  kalshiAuthHeaders: (method: string, apiPath: string) => Promise<Record<string, string>>;
  getKalshiRejectionDetail: (body: unknown, status: number) => string;
  kalshiSameSidePosition: (position: number, side: "yes" | "no") => number;
  isAuthSigningFailed: (headers: Partial<Record<string, string>>) => boolean;
  deleteTradeIntent: (dbId: number) => Promise<void>;
};

export type LeftoverLiveExitResult =
  | { kind: "abort" }
  | { kind: "ok"; confirmedExitCents: number; confirmedLivePnl: number; confirmedLiveFee: number };

export async function leftoverLiveExitFunnel(
  this: any,
  args: {
    trade: any;
    reason: string;
    exitPriceCents: number;
    sweepBuf: number;
    _isStop: boolean;
  } & LeftoverLiveOrderHelpers,
): Promise<LeftoverLiveExitResult> {
  const { trade, reason, exitPriceCents, sweepBuf, _isStop, kalshiAuthHeaders, getKalshiRejectionDetail, kalshiSameSidePosition } = args;
  let confirmedExitCents: number | null = null;
  let confirmedLivePnl: number | null = null;
  let confirmedLiveFee: number | null = null;
      if (!trade.dbId) {
        this.log("error", "Exit blocked: durable trade identity is missing");
        return { kind: "abort" };
      }
      const store = configuredExitJournalStore();
      const key = exitJournalKey(process.env.KALSHI_ACCOUNT_NAMESPACE ?? "default", false, trade.dbId);
      try {
        let journal = store.load(key);
        // Mark expected durable state before sending an exit. Missing state
        // after this marker is never interpreted as permission to start over.
        const rows = await db.select({ outcome: botTrades.outcome }).from(botTrades)
          .where(eq(botTrades.id, trade.dbId)).limit(1);
        if (rows.length !== 1) throw new Error("Trade ledger row missing");
        if (!journal && ["exit_pending", "exit_partial"].includes(rows[0]!.outcome ?? "")) {
          throw new Error("Expected exit journal missing; reconcile durable volume before continuing");
        }
        if (!journal) {
          journal = { version: 1, key, ticker: trade.ticker, side: trade.side,
            originalContracts: trade.contracts, entryPriceCents: trade.entryPriceCents,
            soldContracts: 0, proceedsCents: 0, exitFeeCents: 0, completedOrderIds: [] };
          store.save(journal);
        }
        if (journal.ticker !== trade.ticker || journal.side !== trade.side
          || journal.entryPriceCents !== trade.entryPriceCents) throw new Error("Exit journal identity mismatch");
        await db.update(botTrades).set({ outcome: "exit_pending" }).where(eq(botTrades.id, trade.dbId));
        trade.lastExitAttemptAt = Date.now();
        const priorPartialPnl = trade.realizedPartialPnlCents ?? 0;
        const priorPartialFee = trade.realizedPartialFeeCents ?? 0;
        const result = await executeConfirmedExit(journal,
          reason === "SHUTDOWN_GRACEFUL_CLOSE" ? 1 : (_isStop ? 2 : 1), {
          save: async state => { store.save(state); },
          newIntentId: randomUUID,
          submit: async (contracts, attempt) => {
            // Every POST checks current same-side exposure. Unknown position
            // also blocks shutdown; reduce_only=false has no venue backstop.
            const position = await this.fetchKalshiPosition(trade.ticker,
              reason === "SHUTDOWN_GRACEFUL_CLOSE" ? { attempts: 1, timeoutMs: 1_500 } : undefined);
            if (position == null || kalshiSameSidePosition(position.position, trade.side) < contracts) {
              // No POST occurred: definitive local refusal, not an ambiguous submission.
              return { kind: "blocked" as const };
            }
            const apiPath = KALSHI_PATH_PORTFOLIO_ORDERS;
            const headers = await kalshiAuthHeaders("POST", apiPath);
            if (!headers["KALSHI-ACCESS-KEY"]) return { kind: "blocked" as const };
            const attemptSweep = attempt === 1 ? sweepBuf : Math.min(10, sweepBuf * 2 || 4);
            // D7 — keyed by exit journal state: a re-submit while the journal is
            // unchanged (after an "unknown" POST) reuses the id → Kalshi dedupes.
            const body = buildKalshiV2ExitBody(trade.ticker, trade.side, contracts, exitPriceCents, attemptSweep,
              stableClientOrderId("exit", journal!.key, journal!.soldContracts, journal!.completedOrderIds.length, contracts));
            const response = await fetch(`${KALSHI_API_DOMAIN}${apiPath}`, {
              method: "POST", headers, body: JSON.stringify(body), signal: AbortSignal.timeout(4_000),
            });
            if (!response.ok) {
              recordFailure("kalshi-api");
              const data = await response.json().catch(() => ({})) as Record<string, unknown>;
              this.publishOrderRejection(trade.ticker, trade.side, getKalshiRejectionDetail(data, response.status));
              // Gateway/timeouts/rate limits and malformed successful responses
              // retain the intent. A second sell could create opposite exposure.
              return definitiveOrderRejection(response.status)
                ? { kind: "rejected" as const } : { kind: "unknown" as const };
            }
            recordSuccess("kalshi-api");
            const data = await response.json().catch(() => ({})) as { order_id?: string; order?: { order_id?: string } };
            const orderId = data.order_id ?? data.order?.order_id;
            return orderId ? { kind: "accepted" as const, orderId } : { kind: "unknown" as const };
          },
          read: async (orderId, expectedContracts) => {
            const fill = await this.pollOrderFillStatus(orderId, { attempts: 2, intervalMs: 300, expectedContracts });
            return { ...fill,
              // Order-level schedule estimate, explicitly not an exchange fee
              // receipt. Both entry and every exit order are charged once.
              feeCents: fill.avgPriceCents == null ? null : kalshiTakerFeeCents(fill.avgPriceCents, fill.filled),
            };
          },
          cancel: async orderId => {
            const cancelPath = kalshiEventsOrderPath(orderId);
            const response = await fetch(`${KALSHI_API_DOMAIN}${cancelPath}`, {
              method: "DELETE", headers: await kalshiAuthHeaders("DELETE", cancelPath), signal: AbortSignal.timeout(4_000),
            });
            if (!response.ok) throw new Error(`Exit cancellation HTTP ${response.status}`);
          },
        });
        const economics = carriedExitEconomics(result.state, kalshiTakerFeeCents);
        if (result.kind !== "closed") {
          // This projection follows the already committed journal. Never
          // discard confirmed sales just because the latest order is unknown.
          trade.contracts = economics.remainingContracts;
          trade.realizedPartialContracts = result.state.soldContracts;
          trade.realizedPartialPnlCents = economics.pnlCents;
          trade.realizedPartialFeeCents = economics.feeCents;
          trade.consecutiveExitFailures = (trade.consecutiveExitFailures ?? 0) + 1;
          this.heldPendingFromRestart = true;
          await db.update(botTrades).set({ outcome: result.state.pending ? "exit_pending" : "exit_partial" })
            .where(eq(botTrades.id, trade.dbId));
          this.log("warn", `Exit ${result.kind}: ${result.state.soldContracts} confirmed sold; ${economics.remainingContracts} remain. Journal retained.`);
          return { kind: "abort" };
        }
        confirmedExitCents = Math.round(result.state.proceedsCents / result.state.originalContracts);
        confirmedLivePnl = economics.pnlCents - priorPartialPnl;
        confirmedLiveFee = economics.feeCents - priorPartialFee;
        trade.consecutiveExitFailures = 0;
      } catch (err) {
        this.heldPendingFromRestart = true;
        this.log("error", `Exit reconciliation required; no replacement submitted: ${(err as Error).message}`);
        return { kind: "abort" };
      }

  if (confirmedExitCents == null || confirmedLivePnl == null || confirmedLiveFee == null) {
    return { kind: "abort" };
  }
  return { kind: "ok", confirmedExitCents, confirmedLivePnl, confirmedLiveFee };
}


export type LeftoverLivePlaceResult = { ok: boolean; orderId: string | null };

export async function leftoverLivePlaceFunnel(
  this: any,
  args: {
    ticker: string;
    side: "yes" | "no";
    contracts: number;
    entryPrice: number;
    dbId: number | null;
    strategyId?: string;
  } & LeftoverLiveOrderHelpers,
): Promise<LeftoverLivePlaceResult> {
  const { ticker, side, contracts, entryPrice, dbId, strategyId, kalshiAuthHeaders, getKalshiRejectionDetail, isAuthSigningFailed, deleteTradeIntent } = args;
  let orderId: string | null = null;
      // Kalshi V2 order API: bid/ask side, string price in dollars, required V2 fields
      // Buy YES → bid at yes ask; Buy NO → ask at (100 - no_ask) / 100
      const apiPath = KALSHI_PATH_PORTFOLIO_ORDERS;
      // D7 — one client_order_id per trade intent (DB row), reused on any retry.
      const body    = buildKalshiV2Body(ticker, side, contracts, entryPrice,
        dbId != null ? stableClientOrderId("entry", dbId) : stableClientOrderId("entry", ticker, side, contracts, entryPrice, Date.now()));

      // Guard: if auth headers are empty, signing failed — flag it and abort the live order.
      const orderHeaders = await kalshiAuthHeaders("POST", apiPath);
      if (isAuthSigningFailed(orderHeaders)) {
        this.authFailed = true;
        this.authFailedReason = "signing";
        this.log("warn", "⚠️ Auth signing failed — live order blocked. Bot is effectively in paper mode. Check your oraclekey secret.");
        // Clean up the intent record so the DB stays consistent
        if (dbId) deleteTradeIntent(dbId).catch(() => {});
        return { ok: false, orderId: null };
      }
      // Signing succeeded — clear any prior auth failure flag so the warning banner resets.
      if (this.authFailed) {
        this.authFailed = false;
        this.authFailedReason = null;
        this.log("info", "✅ Auth signing recovered — warning cleared.");
      }

      let apiSuccess = false;
      let ambiguousSubmission = false;   // transport error/timeout — order MAY have been accepted
      try {
        // Task #158/#161: log the base URL used for every live order so
        // endpoint routing can be audited from logs alone (e.g. after a
        // future Kalshi domain migration like the 2026-07 one).
        this.log("order", `POST ${KALSHI_API_DOMAIN}${apiPath} · ticker=${ticker} side=${side}`);
        const r = await fetch(`${KALSHI_API_DOMAIN}${apiPath}`, {
          method: "POST", headers: orderHeaders,
          body: JSON.stringify(body), signal: AbortSignal.timeout(4_000),
        });
        if (!r.ok) {
          recordFailure("kalshi-api");
          const errBody = await r.json().catch(() => ({})) as Record<string, unknown>;
          const reason = getKalshiRejectionDetail(errBody, r.status);
          this.log("warn", `Order failed (${r.status}): ${reason}`);
          // Task #204: surface the exact rejection reason on BotStatus, not just the log stream.
          this.publishOrderRejection(ticker, side, reason);
          ambiguousSubmission = !definitiveOrderRejection(r.status);
        } else {
          recordSuccess("kalshi-api");
          // V2 API returns order_id at the top level (not nested under "order")
          const data = (await r.json()) as { order_id?: string; order?: { order_id?: string } };
          const observedOrderId = data.order_id ?? data.order?.order_id;
          orderId = typeof observedOrderId === "string" && observedOrderId.trim() ? observedOrderId : null;
          // Acceptance with no exchange identity remains ambiguous. Never
          // poll a local intent ID or treat it as a confirmed opening fill.
          this.recordSessionOrderPlaced(strategyId);
          apiSuccess = orderId != null;
          ambiguousSubmission = !apiSuccess;
          // Update intent record with real exchange order ID + acceptance time
          // (distinct from createdAt, which marks signal/intent time above).
          if (dbId && orderId) {
            db.update(botTrades).set({ orderId, orderPlacedAt: new Date() }).where(eq(botTrades.id, dbId)).catch(() => {});
          }
        }
      } catch (err) {
        // Transport error / timeout: the POST may have been ACCEPTED by the
        // exchange even though we never saw the response. Deleting the intent
        // here would destroy the only recovery record for a possibly-live
        // position (reliability critic #2). Still counts as a circuit-breaker
        // failure signal — an ambiguous transport error is exactly the kind
        // of repeated symptom the breaker exists to catch.
        ambiguousSubmission = true;
        recordFailure("kalshi-api");
        this.log("warn", `Order error (submission ambiguous — intent retained): ${(err as Error).message}`);
      }

      if (!apiSuccess) {
        if (ambiguousSubmission) {
          // Keep the intent, mark it for operator review, and do NOT trade
          // again this period — a live position may exist on the exchange.
          this.heldPendingFromRestart = true;
          if (dbId) {
            try { await db.update(botTrades).set({ outcome: "unknown_submission" }).where(eq(botTrades.id, dbId)); }
            catch (err) { this.log("error", `Unknown submission marker failed; durable entry intent retained: ${(err as Error).message}`); }
          }
          this.tradedThisPeriod = true;
          this.lastSignalDesc = "⚠️ Order submission ambiguous (timeout) — check Kalshi for a live position";
          this.log("warn", "⚠️ Order submission AMBIGUOUS — intent kept as 'unknown_submission'; verify on Kalshi before re-enabling.");
        } else {
          // Definitive rejection — order never reached the exchange
          if (dbId) deleteTradeIntent(dbId).catch(() => {});
        }
        return { ok: false, orderId: null };
      }

  return { ok: true, orderId };
}
