/**
 * Leftover specialist-pack shadow/enforce observation on skip + place.
 * Paper KXBTC15M never runs it. Does not change contracts or ENABLE.
 */
import { getRegimeDebug } from "./regime-engine.js";
import { evaluateSpecialistPackShadow, type ShadowPackEvaluation, type SpecialistPack } from "./specialist-packs.js";
import { computeVolumeScore, type VolumeBucket } from "./volume-risk.js";
import type { StrategyId } from "./strategy-library.js";

export const LEFTOVER_PACK_OBSERVE_FUNNEL_LOADED = true as const;

export const FROZEN_PACK_OBSERVE_MARKERS = [
  "specialistPacksMode === 'enforce'",
  "[pack-shadow]",
  "[pack-enforce]",
  "evaluateSpecialistPackShadow({",
] as const;

export type LeftoverPackObserve = {
  packShadow: ShadowPackEvaluation | null;
  realPack: SpecialistPack | null;
  realEligible: StrategyId[] | null;
};

export const EMPTY_LEFTOVER_PACK_OBSERVE: LeftoverPackObserve = {
  packShadow: null,
  realPack: null,
  realEligible: null,
};

export type LeftoverPackObserveHelpers = {
  effectiveDisabledStrategies: (cfg: any) => string[];
  getDbDisabledStrategies: (durationMins: number) => string[];
};

export function leftoverPackSkipObserveFunnel(
  this: any,
  ctx: { strategyId?: string; entryPriceCents?: number },
  helpers: LeftoverPackObserveHelpers,
): LeftoverPackObserve {
  let packShadow: ShadowPackEvaluation | null = null;
  let realPack: SpecialistPack | null = null;
  let realEligible: StrategyId[] | null = null;
  if (this.config.specialistPacksMode === "enforce") {
    realPack = this.lastEnforcedPack;
    realEligible = this.lastPackEligibleIds;
  } else if (this.config.specialistPacksMode !== "off") {
    try {
      const regimeDebug = getRegimeDebug();
      const skipVBucket: VolumeBucket = this.lastObservation
        ? computeVolumeScore(this.lastObservation).bucket
        : "NORMAL";
      packShadow = evaluateSpecialistPackShadow({
        regime: regimeDebug.current,
        vBucket: skipVBucket,
        disabledSet: [...helpers.effectiveDisabledStrategies(this.config), ...helpers.getDbDisabledStrategies(15)],
        dwellMs: Date.now() - regimeDebug.sinceMs,
        candidate: ctx.strategyId && typeof ctx.entryPriceCents === "number"
          ? { strategyId: ctx.strategyId as StrategyId, askCents: ctx.entryPriceCents }
          : null,
      });
    } catch {
      // Shadow compute must never affect a real skip.
    }
  }
  return { packShadow, realPack, realEligible };
}

export function leftoverPackPlaceObserveFunnel(
  this: any,
  args: {
    strategyId?: string;
    durationMins: number;
    contracts: number;
    volumeBucket?: VolumeBucket;
    edgePct?: number;
    entryPriceCents: number;
  } & LeftoverPackObserveHelpers,
): LeftoverPackObserve {
  const { strategyId, durationMins, contracts, volumeBucket, edgePct, entryPriceCents, effectiveDisabledStrategies, getDbDisabledStrategies } = args;
  let packShadow: ShadowPackEvaluation | null = null;
  let realPack: SpecialistPack | null = null;
  try {
    if (this.config.specialistPacksMode === "enforce") {
      realPack = this.lastEnforcedPack;
    } else if (this.config.specialistPacksMode !== "off") {
      const regimeDebug = getRegimeDebug();
      const orderVBucket: VolumeBucket = volumeBucket ?? "NORMAL";
      packShadow = evaluateSpecialistPackShadow({
        regime: regimeDebug.current,
        vBucket: orderVBucket,
        disabledSet: [...effectiveDisabledStrategies(this.config), ...getDbDisabledStrategies(durationMins)],
        dwellMs: Date.now() - regimeDebug.sinceMs,
        candidate: { strategyId: strategyId as StrategyId, askCents: entryPriceCents, edgePct },
      });
      if (packShadow.packId) {
        this.log("info",
          `🧪 [pack-shadow] R=${regimeDebug.current} pack=${packShadow.packId} ` +
          `eligible=[${packShadow.wouldEligible.join(",")}] cap=${packShadow.wouldSizeCap} ` +
          `bump=${packShadow.wouldConfBump} live=ORDER(${strategyId}) would=${packShadow.wouldOutcome}`);
      }
    }
    if (realPack) {
      this.log("info",
        `📦 [pack-enforce] pack=${realPack.id} live=ORDER(${strategyId}) ` +
        `sizeCap=${realPack.sizeCapMult} confBump=${realPack.confBump} contracts=${contracts}`);
    }
  } catch (err) {
    this.log("warn", `[pack-enforce] compute error (non-fatal, mode=${this.config.specialistPacksMode}): ${(err as Error).message}`);
  }
  return { packShadow, realPack, realEligible: this.lastPackEligibleIds ?? null };
}
