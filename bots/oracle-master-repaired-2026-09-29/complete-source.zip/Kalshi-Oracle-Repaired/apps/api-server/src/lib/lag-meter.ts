/**
 * lag-meter.ts
 *
 * Department module (like persist-lag.ts). Observable, not a strategy.
 * Does NOT: place orders, cut EV/Kelly/9%/18%, flip paperMode/autoMode,
 * CHANGE_EV_FLOOR, ENABLE_STRATEGY, or register STRATEGY_OPT_IN / LOCKED.
 *
 * Honesty: TradingBot.evaluate DOES import lagAgreesWithSide and uses it as
 * a skip/veto (autoMode LAG_AGAINST, settlement-side, BASIS_LAG_EDGE).
 * evaluate does NOT own the meter — it never constructs LagMeter or calls
 * estimateLag. BasisTracker.tick() runs LagMeter.update on every basis
 * update; evaluate only reads BasisState.{lagSeconds,lagDollars,lagCorr,lagStale}.
 *
 * Problem: basis-tracker.ts tracks dollar gap (exchange − brtiProxy EWMA)
 * + streak. It does NOT measure how many SECONDS Kalshi is behind Coinbase.
 * Comments elsewhere assume a fixed 5–15s. That assumed lag is why 1s proj
 * flickers get treated as lag (4pm confluence dump). This module counts lag
 * in seconds AND dollars every tick. Winning tau is EWMA'd (half-life ~60s)
 * so it DRIFTS when tape/vol changes — not a constant, not a one-window jump.
 *
 * THE numbers Stellar sees:
 *   lagSeconds = EWMA of best 1s-bucket cross-corr delay
 *                (selected leader → Kalshi-implied follower), tau=1..30.
 *   lagDollars = leader px[now] − px[now − round(tau)].
 *   leadSeconds / leadDollars = catch-up proof (clock until Kalshi recovers
 *                a majority of a real leader Δ$). Not a fake 5–15s.
 *   residualDollars = (exchange − brtiProxy) − rollingBasis — instantaneous
 *                short-gap, NOT the lag-$ Stellar line. Exposed separately.
 *
 * Leader race: Coinbase default; Binance BTCUSDT is the usual #2. Pick
 * proven catch-up AND highest corr AND earliest median lead, with hysteresis.
 * Follower: kalshiImplied = inferBtcPrice / brtiProxy. NOT the BRTI live feed
 * (BRTI_PROBABILITY stays SEV1-locked).
 *
 * Callers FAIL CLOSED: do not fire BASIS_LAG when stale, when !proven, when
 * !lagAgreesWithSide, or when |lagDollars| is too small. Never use a 1s
 * proj flicker as lag. Stale / unproven / corr junk / thin sample → null,
 * not a fake 5–15s constant.
 */

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { deskDataDir } from "./desk-data-dir.js";

export const LAG_METER_MAX_LAG_SEC = 30;
/** Cold EWMA seed cap — raw bestTau can be 20–30s on first window and paints a huge lag$ flash. */
export const LAG_METER_COLD_SEED_MAX_SEC = 8;
export const LAG_METER_MIN_CORR = 0.25;
export const LAG_METER_MIN_N = 60;
/** EWMA half-life of the winning tau. ~60s so lag can change without jumping. */
export const LAG_METER_HALF_LIFE_MS = 60_000;
/** Same 45s fail-closed window as basis-tracker FAIR_VALUE_STALE_MS. */
export const LAG_METER_STALE_MS = 45_000;
/** Adjacent 1s buckets whose keys differ by this many seconds (2 missing) → gaps. */
export const LAG_METER_GAP_SEC = 3;
export const LAG_METER_MIN_COVERAGE = 0.8;

/** Short window for a "real" leader move that starts a catch-up clock. */
export const LAG_CATCHUP_WINDOW_SEC = 3;
/** |Δ$| over that window that counts as a real move (not a 1s flicker). */
export const LAG_CATCHUP_MOVE_USD = 15;
/** Majority of the leader Δ Kalshi-implied must recover to count a hit. */
export const LAG_CATCHUP_RECOVERY = 0.51;
export const LAG_CATCHUP_TIMEOUT_SEC = 30;
export const LAG_PROOF_MIN_EVENTS = 6;
export const LAG_PROOF_MIN_HIT_RATE = 0.5;
export const LAG_PROOF_ROLLING_N = 20;
export const LAG_PROOF_PERSIST_N = 50;
export const LAG_LEADER_CORR_HYSTERESIS = 0.05;
export const LAG_LEADER_LEAD_HYSTERESIS_SEC = 1;
export const LAG_LEADER_SWITCH_CONFIRM = 3;
export const DEFAULT_LAG_LEADER = "coinbase" as const;

export type LagLeaderName = "coinbase" | "binance";

export type LagTick = { tMs: number; px: number };

export type LagSeries = {
  coinbase: LagTick[];
  kalshiImplied: LagTick[];
  /** Optional second public leader. Empty/omit → Coinbase-only still works. */
  binance?: LagTick[];
};

export type LagProof = {
  leadSeconds: number;
  leadDollars: number;
  source: LagLeaderName | string;
  ts: number;
};

export type LagReading = {
  /** EWMA of the winning 1s-bucket cross-corr tau. THE seconds Stellar sees. */
  lagSeconds: number | null;
  /** Leader px[now] − px[now − round(lagSeconds)]. THE dollars Stellar sees. */
  lagDollars: number | null;
  /** Instantaneous (exchange − brtiProxy) − rollingBasis. Not lagDollars. */
  residualDollars: number | null;
  corr: number | null;
  stale: boolean;
  sampleN: number;
  reason: string;
  /** Instantaneous winning tau this window, before EWMA. Null when stale. */
  rawTau: number | null;
  /** Selected leader for this reading. Default coinbase. */
  leaderName: LagLeaderName | null;
  /** Catch-up proof: seconds until Kalshi recovered a majority of Δ$. */
  leadSeconds: number | null;
  /** Catch-up proof: leader Δ$ that started the clock (signed). */
  leadDollars: number | null;
  proofHitRate: number | null;
  /** True only after enough catch-up hits. Missing/false → do not trade lag. */
  proven: boolean;
};

export type EstimateLagOpts = {
  maxLagSec?: number;
  minCorr?: number;
  minN?: number;
  /** Wall-clock for the 45s staleness check. Defaults to Date.now(). */
  nowMs?: number;
  /** Previous EWMA tau (seconds). Null seeds from this window's winning tau. */
  prevEwmaTau?: number | null;
  /** Elapsed ms since the previous reading. Used for the tau EWMA. */
  dtMs?: number;
  /** Optional short-gap residual: (exchange − brtiProxy) − rollingBasis. */
  exchange?: number | null;
  brtiProxy?: number | null;
  rollingBasis?: number | null;
  /** Paper desk: log Coinbase-cold honestly. Never invents fills. */
  paperMode?: boolean;
  /** Which leader series estimateLag is scoring. Default coinbase. */
  leaderName?: LagLeaderName;
};

function residualDollarsOf(opts: EstimateLagOpts): number | null {
  const ex = opts.exchange;
  const proxy = opts.brtiProxy;
  const basis = opts.rollingBasis;
  if (ex == null || proxy == null || basis == null) return null;
  if (!Number.isFinite(ex) || !Number.isFinite(proxy) || !Number.isFinite(basis)) return null;
  return (ex - proxy) - basis;
}

function staleReading(
  reason: string,
  sampleN: number,
  opts: EstimateLagOpts,
  corr: number | null = null,
): LagReading {
  return {
    lagSeconds: null,
    lagDollars: null,
    residualDollars: residualDollarsOf(opts),
    corr,
    stale: true,
    sampleN,
    reason,
    rawTau: null,
    leaderName: opts.leaderName ?? null,
    leadSeconds: null,
    leadDollars: null,
    proofHitRate: null,
    proven: false,
  };
}

/** Last finite px wins the 1s bucket (series is newest-last). */
export function alignTo1sBuckets(ticks: LagTick[]): Map<number, number> {
  const buckets = new Map<number, number>();
  for (const tick of ticks) {
    if (!Number.isFinite(tick.tMs) || !Number.isFinite(tick.px) || tick.px <= 0) continue;
    buckets.set(Math.floor(tick.tMs / 1000), tick.px);
  }
  return buckets;
}

function sortedSecs(buckets: Map<number, number>): number[] {
  return [...buckets.keys()].sort((a, b) => a - b);
}

function coverageAndMaxGap(secs: number[], windowStart: number, windowEnd: number): {
  coverage: number;
  maxGap: number;
  expected: number;
  actual: number;
} {
  const inWindow = secs.filter((s) => s >= windowStart && s <= windowEnd);
  const expected = windowEnd - windowStart + 1;
  if (expected <= 0 || inWindow.length === 0) {
    return { coverage: 0, maxGap: Infinity, expected, actual: 0 };
  }
  let maxGap = 1;
  for (let i = 1; i < inWindow.length; i++) {
    maxGap = Math.max(maxGap, inWindow[i] - inWindow[i - 1]);
  }
  return { coverage: inWindow.length / expected, maxGap, expected, actual: inWindow.length };
}

/**
 * Carry last known px across holes of at most `maxFillSec` seconds (default 2).
 * Brief WS/REST misses must not mark a live Coinbase+BRTI pair as series_gaps.
 * Does not invent a 5–15s lag constant — only reuses the last real print.
 */
export function forwardFill1sBuckets(
  buckets: Map<number, number>,
  windowStart: number,
  windowEnd: number,
  maxFillSec = LAG_METER_GAP_SEC - 1,
): Map<number, number> {
  const out = new Map(buckets);
  let lastPx: number | null = null;
  let lastSec: number | null = null;
  for (let s = windowStart; s <= windowEnd; s++) {
    const px = out.get(s);
    if (px != null && Number.isFinite(px) && px > 0) {
      lastPx = px;
      lastSec = s;
      continue;
    }
    if (lastPx != null && lastSec != null && s - lastSec <= maxFillSec) {
      out.set(s, lastPx);
      // keep lastSec at the real print so a 3s+ hole still gaps
    }
  }
  return out;
}

/** Log-return at second `s` (ln(px[s]/px[s-1])) when both consecutive buckets exist. */
function logReturns(buckets: Map<number, number>, secs: number[]): Map<number, number> {
  const out = new Map<number, number>();
  for (let i = 1; i < secs.length; i++) {
    const s = secs[i];
    const prev = secs[i - 1];
    if (s !== prev + 1) continue;
    const px = buckets.get(s);
    const pxPrev = buckets.get(prev);
    if (px == null || pxPrev == null || pxPrev <= 0 || px <= 0) continue;
    out.set(s, Math.log(px / pxPrev));
  }
  return out;
}

export function pearsonCorr(x: number[], y: number[]): number | null {
  const n = x.length;
  if (n < 2 || n !== y.length) return null;
  let sx = 0;
  let sy = 0;
  let sxx = 0;
  let syy = 0;
  let sxy = 0;
  for (let i = 0; i < n; i++) {
    const xi = x[i];
    const yi = y[i];
    if (!Number.isFinite(xi) || !Number.isFinite(yi)) return null;
    sx += xi;
    sy += yi;
    sxx += xi * xi;
    syy += yi * yi;
    sxy += xi * yi;
  }
  const cov = sxy - (sx * sy) / n;
  const vx = sxx - (sx * sx) / n;
  const vy = syy - (sy * sy) / n;
  if (!(vx > 0) || !(vy > 0)) return null;
  const r = cov / Math.sqrt(vx * vy);
  if (!Number.isFinite(r)) return null;
  return Math.max(-1, Math.min(1, r));
}

function ewmaTau(prev: number | null | undefined, rawTau: number, dtMs: number, halfLifeMs: number): number {
  if (prev == null || !Number.isFinite(prev)) {
    // Never seed at noisy max-lag (≤30s) — UI lag$ = Coinbase Δ over tau; 30s → flash.
    return Math.min(rawTau, LAG_METER_COLD_SEED_MAX_SEC);
  }
  // Pull down faster when a cold/noisy high tau is still stuck above a calmer raw.
  let hl = halfLifeMs;
  if (prev > LAG_METER_COLD_SEED_MAX_SEC && rawTau < prev - 4) {
    hl = Math.min(halfLifeMs, 15_000);
  }
  const alpha = 1 - Math.exp((-Math.LN2 * Math.max(0, dtMs)) / hl);
  return prev + alpha * (rawTau - prev);
}

/**
 * THE lag-$ formula: Coinbase last px minus Coinbase px `round(tauSec)` seconds
 * earlier. Not residualDollars. Not 1s projectedSettlement flicker.
 */
/** Positive Coinbase px at `sec`, else nearest earlier bucket within `slackSec`. Never 0-as-missing. */
function coinbasePxAt(
  cbBuckets: Map<number, number>,
  sec: number,
  slackSec = 1,
): number | null {
  for (let d = 0; d <= slackSec; d++) {
    const px = cbBuckets.get(sec - d);
    if (px != null && Number.isFinite(px) && px > 0) return px;
  }
  return null;
}

function lagDollarsAt(
  cbBuckets: Map<number, number>,
  cbSecs: number[],
  tauSec: number,
): number | null {
  if (cbSecs.length === 0) return null;
  const nowSec = cbSecs[cbSecs.length - 1];
  const lookback = Math.max(1, Math.round(tauSec));
  const nowPx = coinbasePxAt(cbBuckets, nowSec);
  const thenPx = coinbasePxAt(cbBuckets, nowSec - lookback);
  if (nowPx == null || thenPx == null) return null;
  return nowPx - thenPx;
}

/**
 * Cross-correlation lag of Kalshi-implied BTC vs Coinbase, in seconds and dollars.
 * Aligns to 1s buckets, log-returns, Pearson corr(Coinbase[t-tau], Kalshi[t]) for
 * tau=1..maxLagSec. Winning tau is EWMA'd (half-life ~60s) so it tracks when
 * tape/vol changes, without jumping 8→22 on one noisy window.
 *
 * stale=true when n is low, corr is junk, series have gaps, or timestamps are
 * >45s old. Callers FAIL CLOSED — do not fire BASIS_LAG on stale. Returns null
 * lagSeconds/lagDollars, never a fake 5–15s constant.
 */
export function estimateLag(series: LagSeries, opts: EstimateLagOpts = {}): LagReading {
  const maxLagSec = opts.maxLagSec ?? LAG_METER_MAX_LAG_SEC;
  const minCorr = opts.minCorr ?? LAG_METER_MIN_CORR;
  const minN = opts.minN ?? LAG_METER_MIN_N;
  const nowMs = opts.nowMs ?? Date.now();
  const dtMs = opts.dtMs ?? 0;

  const coinbase = series.coinbase ?? [];
  const kalshi = series.kalshiImplied ?? [];
  if (coinbase.length === 0 || kalshi.length === 0) {
    return staleReading("empty_series", 0, opts);
  }

  const lastCb = coinbase[coinbase.length - 1];
  const lastK = kalshi[kalshi.length - 1];
  if (
    !Number.isFinite(lastCb?.tMs) ||
    !Number.isFinite(lastK?.tMs) ||
    nowMs - lastCb.tMs > LAG_METER_STALE_MS ||
    nowMs - lastK.tMs > LAG_METER_STALE_MS
  ) {
    return staleReading("timestamps_stale", 0, opts);
  }

  let cbBuckets = alignTo1sBuckets(coinbase);
  let kBuckets = alignTo1sBuckets(kalshi);
  let cbSecs = sortedSecs(cbBuckets);
  let kSecs = sortedSecs(kBuckets);
  if (cbSecs.length === 0 || kSecs.length === 0) {
    return staleReading("empty_series", 0, opts);
  }

  const windowStart = Math.max(cbSecs[0], kSecs[0]);
  const windowEnd = Math.min(cbSecs[cbSecs.length - 1], kSecs[kSecs.length - 1]);
  if (windowEnd - windowStart + 1 < minN + 2) {
    return staleReading("short_series", Math.max(0, windowEnd - windowStart + 1), opts);
  }

  // Warm path: fill ≤2s holes so a live Coinbase+BRTI desk is not stuck
  // series_gaps/short_series from brief feed misses (never fake lagProven).
  cbBuckets = forwardFill1sBuckets(cbBuckets, windowStart, windowEnd);
  kBuckets = forwardFill1sBuckets(kBuckets, windowStart, windowEnd);
  cbSecs = sortedSecs(cbBuckets);
  kSecs = sortedSecs(kBuckets);

  const cbCov = coverageAndMaxGap(cbSecs, windowStart, windowEnd);
  const kCov = coverageAndMaxGap(kSecs, windowStart, windowEnd);
  if (
    cbCov.coverage < LAG_METER_MIN_COVERAGE ||
    kCov.coverage < LAG_METER_MIN_COVERAGE ||
    cbCov.maxGap >= LAG_METER_GAP_SEC ||
    kCov.maxGap >= LAG_METER_GAP_SEC
  ) {
    return staleReading("series_gaps", Math.min(cbCov.actual, kCov.actual), opts);
  }

  const cbRet = logReturns(cbBuckets, cbSecs);
  const kRet = logReturns(kBuckets, kSecs);

  let bestTau: number | null = null;
  let bestCorr: number | null = null;
  let bestN = 0;
  let maxN = 0;
  let sawZeroVar = false;

  for (let tau = 1; tau <= maxLagSec; tau++) {
    const xs: number[] = [];
    const ys: number[] = [];
    for (const [s, kVal] of kRet) {
      const cbVal = cbRet.get(s - tau);
      if (cbVal == null) continue;
      xs.push(cbVal);
      ys.push(kVal);
    }
    const n = xs.length;
    if (n > maxN) maxN = n;
    if (n < minN) continue;
    const r = pearsonCorr(xs, ys);
    if (r == null) {
      sawZeroVar = true;
      continue;
    }
    if (bestCorr == null || r > bestCorr + 1e-12 || (Math.abs(r - bestCorr) <= 1e-12 && bestTau != null && tau < bestTau)) {
      bestCorr = r;
      bestTau = tau;
      bestN = n;
    }
  }

  if (bestTau == null || bestCorr == null) {
    if (maxN < minN) return staleReading("n_low", maxN, opts);
    if (sawZeroVar) return staleReading("zero_variance", maxN, opts);
    return staleReading("n_low", maxN, opts);
  }
  if (bestCorr < minCorr) {
    return staleReading("corr_junk", bestN, opts, bestCorr);
  }

  const smoothed = ewmaTau(opts.prevEwmaTau, bestTau, dtMs, LAG_METER_HALF_LIFE_MS);
  const dollars = lagDollarsAt(cbBuckets, cbSecs, smoothed);

  return {
    lagSeconds: smoothed,
    lagDollars: dollars,
    residualDollars: residualDollarsOf(opts),
    corr: bestCorr,
    stale: false,
    sampleN: bestN,
    reason: "ok",
    rawTau: bestTau,
    leaderName: opts.leaderName ?? DEFAULT_LAG_LEADER,
    leadSeconds: null,
    leadDollars: null,
    proofHitRate: null,
    proven: false,
  };
}

/**
 * yes agrees if lagDollars > 0 (Coinbase up → book should lift YES).
 * no agrees if lagDollars < 0. Zero / null / non-finite → false (fail closed).
 */
export function lagAgreesWithSide(
  side: "yes" | "no",
  lagDollars: number | null,
  gate?: { proven?: boolean; stale?: boolean },
): boolean {
  if (gate) {
    if (gate.stale !== false) return false;
    if (gate.proven !== true) return false;
  }
  if (lagDollars == null || !Number.isFinite(lagDollars) || lagDollars === 0) return false;
  return side === "yes" ? lagDollars > 0 : lagDollars < 0;
}

function medianOf(xs: number[]): number | null {
  const v = xs.filter((n) => Number.isFinite(n)).slice().sort((a, b) => a - b);
  if (v.length === 0) return null;
  const mid = Math.floor(v.length / 2);
  return v.length % 2 === 1 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
}

export type CatchupSnapshot = {
  pending: boolean;
  hitRate: number | null;
  proven: boolean;
  medianLeadSeconds: number | null;
  medianAbsDollars: number | null;
  lastProof: LagProof | null;
  events: number;
  reason: string;
};

type CatchupEvent = {
  hit: boolean;
  leadSeconds: number | null;
  leadDollars: number;
  ts: number;
};

/**
 * Always-on catch-up clock. On a real leader Δ$, start a timer; when
 * Kalshi-implied recovers a majority of that Δ, record leadSeconds/$.
 * Too many misses → unproven (do not trade lag; never fake 5–15s).
 */
export class CatchupProof {
  private lastSec: number | null = null;
  private readonly leaderBySec = new Map<number, number>();
  private pending: { startSec: number; delta: number; followAtStart: number } | null = null;
  private events: CatchupEvent[] = [];
  private proofs: LagProof[] = [];

  constructor(
    readonly source: LagLeaderName | string,
    private readonly persist?: (proof: LagProof) => void,
  ) {}

  reset(): void {
    this.lastSec = null;
    this.leaderBySec.clear();
    this.pending = null;
    this.events = [];
    this.proofs = [];
  }

  getProofs(): LagProof[] {
    return this.proofs.slice();
  }

  snapshot(reason: string): CatchupSnapshot {
    const rolled = this.events.slice(-LAG_PROOF_ROLLING_N);
    const hits = rolled.filter((e) => e.hit).length;
    const hitRate = rolled.length > 0 ? hits / rolled.length : null;
    const proven = rolled.length >= LAG_PROOF_MIN_EVENTS
      && hitRate != null
      && hitRate >= LAG_PROOF_MIN_HIT_RATE;
    const hitLeads = rolled.filter((e) => e.hit && e.leadSeconds != null).map((e) => e.leadSeconds!);
    const absD = rolled.map((e) => Math.abs(e.leadDollars));
    return {
      pending: this.pending != null,
      hitRate,
      proven,
      medianLeadSeconds: medianOf(hitLeads),
      medianAbsDollars: medianOf(absD),
      lastProof: this.proofs.length > 0 ? this.proofs[this.proofs.length - 1] : null,
      events: rolled.length,
      reason,
    };
  }

  replayFromRings(leader: LagTick[], follow: LagTick[]): CatchupSnapshot {
    const lb = alignTo1sBuckets(leader);
    const fb = alignTo1sBuckets(follow);
    const secs = [...lb.keys()].sort((a, b) => a - b);
    let snap = this.snapshot("warm");
    let lastFollow: number | null = null;
    for (const sec of secs) {
      const fp = fb.get(sec);
      if (fp != null) lastFollow = fp;
      if (this.lastSec != null && sec <= this.lastSec) continue;
      const lp = lb.get(sec);
      if (lp == null || lastFollow == null) continue;
      snap = this.update(sec * 1000, lp, lastFollow);
    }
    return snap;
  }

  update(nowMs: number, leaderPx: number, followPx: number): CatchupSnapshot {
    if (!Number.isFinite(nowMs) || !Number.isFinite(leaderPx) || leaderPx <= 0
      || !Number.isFinite(followPx) || followPx <= 0) {
      return this.snapshot("bad_px");
    }
    const sec = Math.floor(nowMs / 1000);
    this.leaderBySec.set(sec, leaderPx);
    const cutoff = sec - 90;
    for (const k of [...this.leaderBySec.keys()]) {
      if (k < cutoff) this.leaderBySec.delete(k);
    }
    if (this.lastSec === sec) return this.snapshot("same_sec");
    this.lastSec = sec;

    if (this.pending) {
      const rec = followPx - this.pending.followAtStart;
      const need = LAG_CATCHUP_RECOVERY * this.pending.delta;
      const recovered = this.pending.delta >= 0 ? rec >= need : rec <= need;
      const elapsed = sec - this.pending.startSec;
      if (recovered) {
        const proof: LagProof = {
          leadSeconds: elapsed,
          leadDollars: this.pending.delta,
          source: this.source,
          ts: nowMs,
        };
        this.events.push({ hit: true, leadSeconds: elapsed, leadDollars: this.pending.delta, ts: nowMs });
        this.trimEvents();
        this.proofs.push(proof);
        while (this.proofs.length > LAG_PROOF_PERSIST_N) this.proofs.shift();
        try { this.persist?.(proof); } catch { /* never throw into the tick */ }
        this.pending = null;
        return this.snapshot("caught_up");
      }
      if (elapsed >= LAG_CATCHUP_TIMEOUT_SEC) {
        this.events.push({ hit: false, leadSeconds: null, leadDollars: this.pending.delta, ts: nowMs });
        this.trimEvents();
        this.pending = null;
        return this.snapshot("timeout_miss");
      }
      return this.snapshot("pending");
    }

    const then = this.leaderBySec.get(sec - LAG_CATCHUP_WINDOW_SEC);
    if (then == null) return this.snapshot("warm");
    const delta = leaderPx - then;
    if (Math.abs(delta) >= LAG_CATCHUP_MOVE_USD) {
      this.pending = { startSec: sec, delta, followAtStart: followPx };
      return this.snapshot("started");
    }
    return this.snapshot("quiet");
  }

  private trimEvents(): void {
    if (this.events.length > LAG_PROOF_ROLLING_N * 2) {
      this.events = this.events.slice(-LAG_PROOF_ROLLING_N);
    }
  }
}

export type LeaderScore = {
  name: LagLeaderName;
  latencyMs: number | null;
  corr: number | null;
  hitRate: number | null;
  medianLeadSeconds: number | null;
  medianAbsDollars: number | null;
  proven: boolean;
  stale: boolean;
};

export function leaderBeats(challenger: LeaderScore, incumbent: LeaderScore): boolean {
  if (!challenger.proven || challenger.stale) return false;
  if (!incumbent.proven || incumbent.stale) return true;
  const cCorr = challenger.corr ?? -1;
  const iCorr = incumbent.corr ?? -1;
  const cLead = challenger.medianLeadSeconds ?? 99;
  const iLead = incumbent.medianLeadSeconds ?? 99;
  const betterCorr = cCorr > iCorr + LAG_LEADER_CORR_HYSTERESIS;
  const notWorseCorr = cCorr + 1e-12 >= iCorr;
  const earlier = cLead + LAG_LEADER_LEAD_HYSTERESIS_SEC <= iLead;
  if (betterCorr && cLead <= iLead + LAG_LEADER_LEAD_HYSTERESIS_SEC) return true;
  if (notWorseCorr && earlier) return true;
  return false;
}

export type LeaderPickState = {
  leaderName: LagLeaderName;
  challenger: LagLeaderName | null;
  votes: number;
};

export function pickLagLeader(
  scores: LeaderScore[],
  state: LeaderPickState,
): LeaderPickState {
  const byName = new Map(scores.map((s) => [s.name, s]));
  const incumbent = byName.get(state.leaderName);
  const proven = scores.filter((s) => s.proven && !s.stale);
  if (proven.length === 0) {
    return { leaderName: state.leaderName || DEFAULT_LAG_LEADER, challenger: null, votes: 0 };
  }
  let best = proven[0];
  for (const s of proven.slice(1)) {
    if (leaderBeats(s, best) && !leaderBeats(best, s)) best = s;
    else if (leaderBeats(s, best)) best = s;
  }
  // Prefer incumbent on a dead heat.
  const incOk = incumbent && incumbent.proven && !incumbent.stale;
  if (incOk && !leaderBeats(best, incumbent!)) {
    return { leaderName: incumbent!.name, challenger: null, votes: 0 };
  }
  if (best.name === state.leaderName) {
    return { leaderName: state.leaderName, challenger: null, votes: 0 };
  }
  const need = (incOk ? LAG_LEADER_SWITCH_CONFIRM : 1);
  if (state.challenger === best.name && state.votes + 1 >= need) {
    return { leaderName: best.name, challenger: null, votes: 0 };
  }
  const votes = state.challenger === best.name ? state.votes + 1 : 1;
  return { leaderName: state.leaderName, challenger: best.name, votes };
}

function lastTick(ticks: LagTick[] | undefined): LagTick | null {
  if (!ticks || ticks.length === 0) return null;
  return ticks[ticks.length - 1];
}

export type LagMeterOpts = {
  /** Persist catch-up proofs under apps/api-server/data/. Off in unit tests. */
  persistProofs?: boolean;
  persistDir?: string;
  persist?: (proof: LagProof) => void;
};

let proofRing: LagProof[] = [];

export function defaultLagProofDir(): string {
  return deskDataDir();
}

export function persistLagProof(proof: LagProof, dir?: string): void {
  proofRing.push(proof);
  while (proofRing.length > LAG_PROOF_PERSIST_N) proofRing.shift();
  try {
    const dataDir = dir ?? defaultLagProofDir();
    fs.mkdirSync(dataDir, { recursive: true });
    const body = proofRing.map((row) => JSON.stringify(row)).join("\n") + "\n";
    fs.writeFileSync(path.join(dataDir, "lag-proofs.jsonl"), body);
    fs.writeFileSync(path.join(dataDir, "lag-proofs.json"), JSON.stringify({ n: proofRing.length, proofs: proofRing }));
  } catch {
    /* never throw into the tick; no secrets */
  }
}

/**
 * Small stateful wrapper around estimateLag + catch-up proof + leader race.
 * One instance per desk. Does not place orders.
 */
export class LagMeter {
  private readonly ewmaByLeader = new Map<LagLeaderName, number | null>();
  private lastMs: number | null = null;
  private lastReading: LagReading | null = null;
  private readonly catchup = new Map<LagLeaderName, CatchupProof>();
  private pick: LeaderPickState = { leaderName: DEFAULT_LAG_LEADER, challenger: null, votes: 0 };
  private readonly persistFn: ((proof: LagProof) => void) | undefined;

  constructor(meterOpts: LagMeterOpts = {}) {
    const persist = meterOpts.persist
      ?? (meterOpts.persistProofs ? (pr: LagProof) => persistLagProof(pr, meterOpts.persistDir) : undefined);
    this.persistFn = persist;
    this.catchup.set("coinbase", new CatchupProof("coinbase", persist));
    this.catchup.set("binance", new CatchupProof("binance", persist));
    this.ewmaByLeader.set("coinbase", null);
    this.ewmaByLeader.set("binance", null);
  }

  getReading(): LagReading | null {
    return this.lastReading;
  }

  getStatus(): LagMeterStatusFields {
    return lagMeterStatusFromReading(this.lastReading);
  }

  getLeaderName(): LagLeaderName {
    return this.pick.leaderName;
  }

  reset(): void {
    this.ewmaByLeader.set("coinbase", null);
    this.ewmaByLeader.set("binance", null);
    this.lastMs = null;
    this.lastReading = null;
    this.catchup.get("coinbase")?.reset();
    this.catchup.get("binance")?.reset();
    this.pick = { leaderName: DEFAULT_LAG_LEADER, challenger: null, votes: 0 };
  }

  update(series: LagSeries, opts: EstimateLagOpts = {}): LagReading {
    const nowMs = opts.nowMs ?? Date.now();
    const dtMs = opts.dtMs ?? (this.lastMs != null ? nowMs - this.lastMs : 0);
    const sources: Array<{ name: LagLeaderName; ticks: LagTick[] }> = [
      { name: "coinbase", ticks: series.coinbase ?? [] },
    ];
    if (series.binance && series.binance.length > 0) {
      sources.push({ name: "binance", ticks: series.binance });
    }

    const scores: LeaderScore[] = [];
    const readings = new Map<LagLeaderName, LagReading>();
    const proofs = new Map<LagLeaderName, CatchupSnapshot>();

    for (const src of sources) {
      const last = lastTick(src.ticks);
      const snap = this.catchup.get(src.name)!.replayFromRings(src.ticks, series.kalshiImplied);
      proofs.set(src.name, snap);
      const prevOwn = this.ewmaByLeader.get(src.name);
      const prevFallback = prevOwn ?? this.ewmaByLeader.get(this.pick.leaderName) ?? null;
      const reading = estimateLag(
        { coinbase: src.ticks, kalshiImplied: series.kalshiImplied },
        {
          ...opts,
          nowMs,
          dtMs,
          prevEwmaTau: prevFallback,
          leaderName: src.name,
        },
      );
      readings.set(src.name, reading);
      if (!reading.stale && reading.lagSeconds != null) {
        this.ewmaByLeader.set(src.name, reading.lagSeconds);
      }
      const latencyMs = last ? Math.max(0, nowMs - last.tMs) : null;
      scores.push({
        name: src.name,
        latencyMs,
        corr: reading.corr,
        hitRate: snap?.hitRate ?? null,
        medianLeadSeconds: snap?.medianLeadSeconds ?? null,
        medianAbsDollars: snap?.medianAbsDollars ?? null,
        proven: snap?.proven === true,
        stale: reading.stale || (latencyMs != null && latencyMs > LAG_METER_STALE_MS),
      });
    }

    this.pick = pickLagLeader(scores, this.pick);
    const leaderName = this.pick.leaderName;
    const leaderReading = readings.get(leaderName) ?? readings.get(DEFAULT_LAG_LEADER) ?? estimateLag(series, {
      ...opts, nowMs, dtMs, prevEwmaTau: this.ewmaByLeader.get(DEFAULT_LAG_LEADER) ?? null, leaderName: DEFAULT_LAG_LEADER,
    });
    const snap = proofs.get(leaderName) ?? proofs.get(DEFAULT_LAG_LEADER);
    let proven = snap?.proven === true;
    const failedProof = snap != null && snap.events >= LAG_PROOF_MIN_EVENTS && !proven;
    let stale = leaderReading.stale || failedProof;
    // Honesty: never advertise proven while stale (n_low/short_series/corr_junk/unproven).
    if (stale) proven = false;
    let reason = leaderReading.reason;
    if (failedProof) {
      reason = "lag_unproven";
    } else if (opts.paperMode === true && leaderReading.stale && (reason === "timestamps_stale" || reason === "empty_series")) {
      reason = `${reason}:paper_coinbase_cold`;
    }

    // Honesty: do not freeze lastProof leadSeconds=21 while series is
    // short_series/series_gaps — UI showed a stuck meter all day with Coinbase live.
    const leadLive = !leaderReading.stale;
    const reading: LagReading = {
      ...leaderReading,
      stale,
      reason,
      leaderName,
      leadSeconds: leadLive
        ? (snap?.lastProof?.leadSeconds ?? snap?.medianLeadSeconds ?? null)
        : null,
      leadDollars: leadLive ? (snap?.lastProof?.leadDollars ?? null) : null,
      proofHitRate: snap?.hitRate ?? null,
      proven,
    };
    if (failedProof) {
      reading.lagSeconds = null;
      reading.lagDollars = null;
      reading.rawTau = null;
    }
    // corr_junk keeps tau/dollars null (never leftover 5–15s). Catch-up Δ$
    // stays on leadDollars for status only — evaluate must not fill corr_junk.
    this.lastReading = reading;
    this.lastMs = nowMs;
    return reading;
  }
}


export type LagMeterStatusFields = {
  tau: number | null;
  corr: number | null;
  stale: boolean;
  leadDollars: number | null;
  lagSeconds: number | null;
  lagDollars: number | null;
  leadSeconds: number | null;
  proven: boolean;
  reason: string;
};

/** Sibling getStatus helper. Null/stale → null tau. Never invents 5–15s. */
export function lagMeterStatusFromReading(r: LagReading | null | undefined): LagMeterStatusFields {
  if (!r) {
    return {
      tau: null,
      corr: null,
      stale: true,
      leadDollars: null,
      lagSeconds: null,
      lagDollars: null,
      leadSeconds: null,
      proven: false,
      reason: "no_reading",
    };
  }
  const stale = r.stale === true;
  return {
    tau: stale ? null : (r.lagSeconds ?? r.rawTau),
    corr: r.corr,
    stale,
    leadDollars: r.leadDollars,
    lagSeconds: stale ? null : r.lagSeconds,
    lagDollars: stale ? null : r.lagDollars,
    leadSeconds: r.leadSeconds,
    // Never report proven=true alongside stale (UI honesty / lagProven∧lagStale).
    proven: stale ? false : (r.proven === true),
    reason: r.reason,
  };
}

export function getLagMeterStatus(meter: { getReading(): LagReading | null }): LagMeterStatusFields {
  return lagMeterStatusFromReading(meter.getReading());
}
