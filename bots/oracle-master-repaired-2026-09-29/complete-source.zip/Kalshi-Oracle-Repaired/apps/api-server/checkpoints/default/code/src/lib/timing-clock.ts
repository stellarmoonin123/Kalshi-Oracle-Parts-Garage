/**
 * timing-clock.ts
 *
 * TIMING department. Pure clocks. TradingBot stays the director.
 * LIVE_APPLY false. TIMING_CLOCK_LIVE default false. Do not flip TIMING_CLOCK_LIVE
 * (would extra-gate 15s + flicker globally, including lag-flip wrappers).
 * Money-maker VELOCITY_FLIP_AGAINST in checkThesisBreak ANDs THESIS_BREAK_MIN_HOLD_MS
 * without enabling this flag.
 *
 * Three clocks, first principles, 900s KXBTC15M bar:
 *   1) BAR WINDOW — classifyBarWindow(secsRemaining)
 *   2) ENTRY PERSIST — persistOk(persistSec) for shadow persist-eval cheap 19–22
 *   3) EXIT HOLD — shouldThesisBreakExit (SHADOW numbers; documented)
 *
 * Cheap-side 2–12m IS 120–720s inclusive. Do not invent a second window.
 * Do NOT live-enable persist-cheap. Do not cut EV floors. Do not ENABLE_STRATEGY.
 *
 * Tape (do not invent) — 6 paper fills all THESIS_BREAK in 2–26s, all still-mid 45–65:
 *   dumped winners: 1600 hold 2.06s (ticket did not move against; 1s proj flicker);
 *                   1745 hold 22.59s (proj above-floor vs short; ticket later settled 100)
 *   dumped losers saved vs hold-to-0: 1500 10.9s, 1515 8.1s, 1530 15.2s, 1645 26.4s
 *     (ticket moved WITH the short, theo-led dump)
 * Failure mode of slowing TB globally: sit longer in the four wrong-side dumps.
 * Skip still-mid entries first (other worker). Timing must not cut EV floors.
 */

/** Shadow lock — never flip true in this module. Not a live engine. */
export const LIVE_APPLY = false as const;
export const LIVE_APPLY_ENABLED = false as const;

/**
 * Live TB thesis-break extra-gate. Default false.
 * A future caller MUST fail closed to CURRENT TB behavior when this is false
 * (passthrough currentWouldExit). Prefer not touching trading-bot.ts this pass.
 */
export const TIMING_CLOCK_LIVE = false;

/** KXBTC15M bar length. */
export const BAR_SECS = 900;

/** secsRemaining > this → TOO_EARLY (first ~3 min of the bar). 1500 fill was 804s left. */
export const BAR_TOO_EARLY_SECS = 720;

/** secsRemaining < this → LOTTERY (last 2 min). Cheap 7–12 last-150s is skip. */
export const BAR_LOTTERY_SECS = 120;

/** persist-eval cheap 19–22 needs ≥60s fair-agree. Do not live-enable persist-cheap. */
export const PERSIST_MIN_SEC = 60;

/** Same floor as LAG_FLIP_MIN_HOLD_MS. Do not cut. */
export const THESIS_BREAK_MIN_HOLD_MS = 15_000;

/** Filled-side mid must have moved AGAINST by at least this many cents. */
export const THESIS_BREAK_MIN_ADVERSE_CENTS = 3;

export type BarWindow = "TOO_EARLY" | "OK_MID" | "LOTTERY";

/**
 * Bar window on a 900s KXBTC15M contract.
 * TOO_EARLY if secsRemaining > 720 (first ~3 min).
 * LOTTERY if secsRemaining < 120 (last 2 min).
 * OK_MID if 120–720 inclusive (cheap-side 2–12m already uses this).
 */
export function classifyBarWindow(secsRemaining: number): BarWindow {
  if (!Number.isFinite(secsRemaining)) return "LOTTERY";
  if (secsRemaining > BAR_TOO_EARLY_SECS) return "TOO_EARLY";
  if (secsRemaining < BAR_LOTTERY_SECS) return "LOTTERY";
  return "OK_MID";
}

/**
 * Entry persist. persist-eval cheap 19–22 needs ≥60s fair-agree.
 * Does not size, place, or live-enable persist-cheap.
 */
export function persistOk(persistSec: number, minSec: number = PERSIST_MIN_SEC): boolean {
  if (!Number.isFinite(persistSec) || !Number.isFinite(minSec)) return false;
  return persistSec >= minSec;
}

export type ThesisBreakExitOpts = {
  holdMs: number;
  /** Filled-side mid move AGAINST the ticket, in cents. WITH-the-trade is 0/negative. */
  ticketAdverseCents: number;
  /** True when the only "break" is a 1s projectedSettlement flicker across the floor. */
  projFlickerOnly: boolean;
  minHoldMs?: number;
  minAdverseCents?: number;
};

/**
 * SHADOW thesis-break extra-gate. Not wired into trading-bot.ts this pass.
 *
 * Allow TB exit only when:
 *   - holdMs >= 15000 (same floor as lag-flip)
 *   - filled-side mid moved AGAINST by at least 3 cents
 *   - not a 1s projectedSettlement flicker across the floor
 *
 * 1600 2.06s flicker + no ticket-against → false.
 * 1745 22.59s flicker-only + ticketAdverse 0 → false (winner dumped; settled 100).
 * 1645 26.4s theo-led WITH-the-short → false on adverse (failure mode of slowing TB).
 */
/**
 * Adverse-ticket leg only. AND onto live checkThesisBreak without enabling
 * TIMING_CLOCK_LIVE (which would also require 15s hold + no flicker).
 * 15s money-maker VELOCITY hold is a separate AND in checkThesisBreak.
 * Do not disable lag-flip.
 */
export function ticketAdverseThesisBreakOk(
  ticketAdverseCents: number,
  minAdverseCents: number = THESIS_BREAK_MIN_ADVERSE_CENTS,
): boolean {
  return Number.isFinite(ticketAdverseCents) && ticketAdverseCents >= minAdverseCents;
}

/**
 * TB / FAST_REVERSAL / non-catastrophic HARD_STOP on CC/LAG/PATH_RIDE/HA_*.
 * holdMs >= 15s AND ticket adverse >= 3¢. Green coupon (adverse < 3) never.
 * Catastrophic <=5¢ is a separate immediate path — do not call this for it.
 */
export function pathRideAntiFlickerExitOk(opts: {
  holdMs: number;
  ticketAdverseCents: number;
}): boolean {
  if (!Number.isFinite(opts.holdMs) || opts.holdMs < THESIS_BREAK_MIN_HOLD_MS) return false;
  return ticketAdverseThesisBreakOk(opts.ticketAdverseCents);
}

export function shouldThesisBreakExit(opts: ThesisBreakExitOpts): boolean {
  const minHoldMs = opts.minHoldMs ?? THESIS_BREAK_MIN_HOLD_MS;
  const minAdverseCents = opts.minAdverseCents ?? THESIS_BREAK_MIN_ADVERSE_CENTS;
  if (!Number.isFinite(opts.holdMs) || opts.holdMs < minHoldMs) return false;
  if (opts.projFlickerOnly) return false;
  if (!ticketAdverseThesisBreakOk(opts.ticketAdverseCents, minAdverseCents)) {
    return false;
  }
  return true;
}

/**
 * Fail-closed live wrapper for a future TradingBot caller.
 * TIMING_CLOCK_LIVE false → return currentWouldExit (CURRENT TB behavior).
 * Never extra-gates while the flag is false.
 */
export function thesisBreakExitIfLive(
  currentWouldExit: boolean,
  opts: ThesisBreakExitOpts,
): boolean {
  if (!TIMING_CLOCK_LIVE) return currentWouldExit;
  return currentWouldExit && shouldThesisBreakExit(opts);
}
