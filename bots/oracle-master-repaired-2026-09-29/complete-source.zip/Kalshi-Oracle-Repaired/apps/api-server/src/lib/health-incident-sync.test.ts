import { test, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { noteHealthIncident, flushHealthIncidents, resetHealthIncidentSyncForTests, getPendingHealthIncidents } from "./health-incident-sync.js";

beforeEach(() => resetHealthIncidentSyncForTests());

function fakeStore() {
  const calls: string[] = [];
  return {
    calls,
    store: {
      enterDegraded: async (s: string, r?: string | null) => { calls.push(`enter:${s}:${r ?? ""}`); },
      exitDegraded: async (s: string) => { calls.push(`exit:${s}`); },
    } as never,
  };
}

test("GET /healthz handler never writes incidents (source guard)", () => {
  const src = readFileSync(new URL("../routes/health.ts", import.meta.url), "utf8");
  const handler = src.slice(src.indexOf('router.get("/healthz"'));
  assert.equal(/incidentStore\.(enterDegraded|exitDegraded)\(/.test(handler), false);
  assert.ok(handler.includes("noteHealthIncident("));
});

test("note is memory-only; flush applies transitions once per change", async () => {
  const f = fakeStore();
  noteHealthIncident("database", true, "db down");
  noteHealthIncident("mtf", false);
  assert.equal(f.calls.length, 0);
  assert.equal(getPendingHealthIncidents().size, 2);
  assert.equal(await flushHealthIncidents(f.store), 2);
  assert.deepEqual(f.calls.sort(), ["enter:database:db down", "exit:mtf"]);
  // repeated identical GET verdicts → no new writes
  noteHealthIncident("database", true, "db down");
  noteHealthIncident("mtf", false);
  assert.equal(await flushHealthIncidents(f.store), 0);
  noteHealthIncident("database", false);
  assert.equal(await flushHealthIncidents(f.store), 1);
  assert.equal(f.calls.at(-1), "exit:database");
});
