/**
 * Integration tests against the real database for the cash-flow ledger:
 * confirmation gating (T3, T4) and auto-detect idempotency (T5).
 */
import test from "node:test";
import assert from "node:assert/strict";
import { db, cashFlowEvents } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  ensureCashFlowSchema, insertAutoCashFlowEvent, createManualCashFlowEvent,
  setCashFlowStatus, listConfirmedFlowsInWindow, listCashFlowEvents,
} from "./cash-flow.js";

// Far-future date + a distinctive amount so we never collide with real rows.
const TEST_TS = new Date("2099-06-15T12:00:00.000Z");
const WINDOW_SINCE = new Date("2099-06-01T00:00:00.000Z");
const WINDOW_UNTIL = new Date("2099-06-30T00:00:00.000Z");

async function cleanup() {
  await db.delete(cashFlowEvents).where(eq(cashFlowEvents.paperMode, true));
}

test("cash-flow ledger DB integration", async (t) => {
  await ensureCashFlowSchema();
  await cleanup();
  t.after(cleanup);

  await t.test("T3: a provisional row is excluded from the confirmed-only window until confirmed", async () => {
    const row = await createManualCashFlowEvent({
      ts: TEST_TS, paperMode: true, amountCents: 12_345, status: "provisional",
    });
    let confirmed = await listConfirmedFlowsInWindow("paper", WINDOW_SINCE, WINDOW_UNTIL);
    assert.equal(confirmed.filter(f => f.id === row.id).length, 0, "provisional must not count toward ROI yet");

    await setCashFlowStatus(row.id, "confirmed");
    confirmed = await listConfirmedFlowsInWindow("paper", WINDOW_SINCE, WINDOW_UNTIL);
    assert.equal(confirmed.filter(f => f.id === row.id).length, 1, "confirming must make it count");
  });

  await t.test("T4: a rejected row is permanently excluded from the confirmed-only window", async () => {
    const row = await createManualCashFlowEvent({
      ts: TEST_TS, paperMode: true, amountCents: -5_000, status: "provisional",
    });
    await setCashFlowStatus(row.id, "rejected");
    const confirmed = await listConfirmedFlowsInWindow("paper", WINDOW_SINCE, WINDOW_UNTIL);
    assert.equal(confirmed.filter(f => f.id === row.id).length, 0);

    // Still visible in the full ledger for audit purposes.
    const all = await listCashFlowEvents({ paperMode: true, status: "rejected" });
    assert.equal(all.filter(f => f.id === row.id).length, 1, "rejected rows are kept, not deleted");
  });

  await t.test("T5: auto-detecting the same real-world flow twice does not double-count it", async () => {
    const before = await listCashFlowEvents({ paperMode: true, status: "provisional" });
    const startCount = before.length;

    const insertOnce = () => insertAutoCashFlowEvent({
      ts: TEST_TS, paperMode: true, amountCents: 8_800,
      balanceBeforeCents: 10_000, balanceAfterCents: 18_800,
    });
    await insertOnce();
    await insertOnce(); // simulated retry of the same tick / same detected flow

    const after = await listCashFlowEvents({ paperMode: true, status: "provisional" });
    assert.equal(after.length - startCount, 1, "the retried insert must be deduped by client_key, not double-counted");
  });

  await t.test("manual create defaults to confirmed (no extra confirm step required)", async () => {
    const row = await createManualCashFlowEvent({ ts: TEST_TS, paperMode: true, amountCents: 2_500 });
    assert.equal(row.status, "confirmed");
  });
});
