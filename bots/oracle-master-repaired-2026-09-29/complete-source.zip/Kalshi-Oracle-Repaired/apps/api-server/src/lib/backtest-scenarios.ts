/**
 * backtest-scenarios.ts
 *
 * Runs 8 pre-defined scenario configurations through the walk-forward backtest
 * engine and returns a detailed comparison matrix including:
 *  - All standard metrics (Sharpe, Calmar, PF, WR, max DD, ROI, expectancy)
 *  - Per-trade detail with exit reasons
 *  - Equity curve data points
 *  - Slippage-adjusted net metrics using real L2 spread data
 *  - Settlement hold sensitivity analysis
 *  - Kelly fraction sensitivity
 */

import {
  binaryCallPrice,
  summarizeNet,
  type OHLCCandle,
  type StrategyDef,
  type BacktestResult,
  type GridResult,
  type TradeRecord,
} from "./backtest-engine.js";
import { fetchRealCandles } from "./market-candles.js";
import { db, kalshiL2Snapshots } from "@workspace/db";
import { desc, sql } from "drizzle-orm";
import { kalshiFeeCents, kalshiTakerFeeCents } from "./constants.js";
import { computeTradeEV } from "./trade-path.js";

// ── Scenario definitions ───────────────────────────────────────────────────────

export interface ScenarioConfig {
  id:          string;
  name:        string;
  emoji:       string;
  description: string;
  strat:       StrategyDef;
  /** Kelly fraction used for sizing (0.5 = half-Kelly, 1.0 = full Kelly) */
  kellyFrac:   number;
  /** Max contracts per trade in this scenario */
  maxContracts: number;
  /** Whether to model settlement hold (suppresses early exits near expiry) */
  settlementHold: boolean;
}

export const SCENARIOS: ScenarioConfig[] = [
  {
    id: "ultra_conservative",
    name: "Ultra Conservative",
    emoji: "🛡️",
    description: "Minute-10 entry, velocity ≥40, edge ≥10, 3× max, tight 10¢ stop. Best drawdown protection.",
    kellyFrac: 0.40, maxContracts: 3, settlementHold: true,
    strat: {
      name: "ultra_conservative",
      minVelocity: 40, useEdge: true, minEdge: 10,
      useStallFilter: true, useAcceleration: false,
      useLossCooldown: true, cooldownMultiplier: 2.0,
      useStopLoss: true, stopLossCents: 10,
      useProfitTake: false, profitTakeCents: 12,
      drawdownGuardPct: 15, observationMinute: 10,
    },
  },
  {
    id: "conservative",
    name: "Conservative",
    emoji: "🔵",
    description: "Minute-10, velocity ≥25, edge ≥6, 5× max. Lower frequency, higher precision.",
    kellyFrac: 0.50, maxContracts: 5, settlementHold: true,
    strat: {
      name: "conservative",
      minVelocity: 25, useEdge: true, minEdge: 6,
      useStallFilter: true, useAcceleration: false,
      useLossCooldown: true, cooldownMultiplier: 1.5,
      useStopLoss: true, stopLossCents: 12,
      useProfitTake: false, profitTakeCents: 12,
      drawdownGuardPct: 20, observationMinute: 10,
    },
  },
  {
    id: "current_config",
    name: "Current Config",
    emoji: "⚙️",
    description: "Mirrors live bot settings. Baseline for all other comparisons.",
    kellyFrac: 0.50, maxContracts: 8, settlementHold: true,
    strat: {
      name: "current_config",
      minVelocity: 15, useEdge: true, minEdge: 5,
      useStallFilter: true, useAcceleration: false,
      useLossCooldown: true, cooldownMultiplier: 1.5,
      useStopLoss: true, stopLossCents: 18,
      useProfitTake: false, profitTakeCents: 12,
      drawdownGuardPct: 25, observationMinute: 5,
    },
  },
  {
    id: "wider_stop",
    name: "Wider Stop",
    emoji: "📐",
    description: "Same as current but stop widened to 28¢ — prevents premature exits like the 70¢ trade.",
    kellyFrac: 0.50, maxContracts: 8, settlementHold: true,
    strat: {
      name: "wider_stop",
      minVelocity: 15, useEdge: true, minEdge: 5,
      useStallFilter: true, useAcceleration: false,
      useLossCooldown: true, cooldownMultiplier: 1.5,
      useStopLoss: true, stopLossCents: 28,
      useProfitTake: false, profitTakeCents: 12,
      drawdownGuardPct: 25, observationMinute: 5,
    },
  },
  {
    id: "hold_to_settlement",
    name: "Hold to Settlement",
    emoji: "⏳",
    description: "Stops disabled. Pure model accuracy test — all trades held to 100¢ or 0¢.",
    kellyFrac: 0.50, maxContracts: 8, settlementHold: true,
    strat: {
      name: "hold_to_settlement",
      minVelocity: 15, useEdge: true, minEdge: 5,
      useStallFilter: true, useAcceleration: false,
      useLossCooldown: true, cooldownMultiplier: 1.5,
      useStopLoss: false, stopLossCents: 50,
      useProfitTake: false, profitTakeCents: 50,
      drawdownGuardPct: 25, observationMinute: 5,
    },
  },
  {
    id: "high_edge_only",
    name: "High Edge Only",
    emoji: "🎯",
    description: "Only enter when model edge ≥12%. Fewest trades, highest confidence bar.",
    kellyFrac: 0.60, maxContracts: 8, settlementHold: true,
    strat: {
      name: "high_edge_only",
      minVelocity: 20, useEdge: true, minEdge: 12,
      useStallFilter: false, useAcceleration: false,
      useLossCooldown: true, cooldownMultiplier: 1.5,
      useStopLoss: true, stopLossCents: 15,
      useProfitTake: false, profitTakeCents: 12,
      drawdownGuardPct: 20, observationMinute: 5,
    },
  },
  {
    id: "momentum_pure",
    name: "Momentum Pure",
    emoji: "🚀",
    description: "Velocity + acceleration required, no edge filter. Trend-following only.",
    kellyFrac: 0.50, maxContracts: 8, settlementHold: false,
    strat: {
      name: "momentum_pure",
      minVelocity: 20, useEdge: false, minEdge: 0,
      useStallFilter: false, useAcceleration: true,
      useLossCooldown: true, cooldownMultiplier: 1.5,
      useStopLoss: true, stopLossCents: 18,
      useProfitTake: false, profitTakeCents: 12,
      drawdownGuardPct: 20, observationMinute: 5,
    },
  },
  {
    id: "full_kelly",
    name: "Full Kelly",
    emoji: "💎",
    description: "Full Kelly sizing (vs half-Kelly). Maximises long-run growth at higher variance.",
    kellyFrac: 1.00, maxContracts: 10, settlementHold: true,
    strat: {
      name: "full_kelly",
      minVelocity: 15, useEdge: true, minEdge: 5,
      useStallFilter: true, useAcceleration: false,
      useLossCooldown: true, cooldownMultiplier: 1.5,
      useStopLoss: true, stopLossCents: 18,
      useProfitTake: false, profitTakeCents: 12,
      drawdownGuardPct: 20, observationMinute: 5,
    },
  },
];

// ── Types ─────────────────────────────────────────────────────────────────────

export interface ScenarioEquityPoint {
  tradeIdx:     number;
  balanceCents: number;
  pnlCents:     number;
  outcome:      string;
  entryPrice:   number;
  exitReason:   string;
}

export interface SlippageEstimate {
  avgSpreadCents:    number;          // historical avg spread from L2 snapshots
  avgSlippageCents:  number;          // expected slippage per contract given avg size
  totalSlippageCents: number;         // total slippage cost across all scenario trades
  netPnlCents:       number;          // PnL after deducting slippage
  sampleCount:       number;          // number of L2 snapshots used
}

export interface ScenarioResult {
  scenario:        ScenarioConfig;
  oos:             BacktestResult;
  train:           BacktestResult;
  ci:              { p5: number; p50: number; p95: number; mean: number };
  equityCurve:     ScenarioEquityPoint[];
  slippage:        SlippageEstimate;
  // Derived highlights
  netRoiPct:       number;            // ROI after slippage
  riskRating:      "LOW" | "MEDIUM" | "HIGH" | "EXTREME";
  rank:            number;            // 1 = best composite score
}

export interface ScenarioReport {
  generatedAt:   string;
  periodsTotal:  number;
  periodsOos:    number;
  btcPriceStart: number;
  btcPriceEnd:   number;
  scenarios:     ScenarioResult[];
  bestScenario:  string;              // id of the top-ranked scenario
  worstScenario: string;
}

// ── Slippage model ────────────────────────────────────────────────────────────
// (Fee model lives in ./constants.js's kalshiFeeCents — see simulateScenario;
// this file previously declared its own KALSHI_TAKER_FEE = 0.07 constant here
// but never actually used it anywhere, so every simulated trade's pnlCents
// was fee-free. Removed in favor of the one shared fee function live uses.)

async function estimateSlippage(trades: TradeRecord[], avgContracts: number): Promise<SlippageEstimate> {
  // Fetch recent L2 snapshots to compute avg spread
  let avgSpreadCents = 6;  // conservative fallback if no L2 data
  let sampleCount    = 0;

  try {
    const snaps = await db
      .select({ spread: kalshiL2Snapshots.spread })
      .from(kalshiL2Snapshots)
      .where(sql`${kalshiL2Snapshots.spread} IS NOT NULL AND ${kalshiL2Snapshots.spread} > 0`)
      .orderBy(desc(kalshiL2Snapshots.ts))
      .limit(200);

    if (snaps.length > 0) {
      const total = snaps.reduce((s, r) => s + (r.spread ?? 0), 0);
      avgSpreadCents = Math.round(total / snaps.length);
      sampleCount    = snaps.length;
    }
  } catch { /* no L2 data yet — use fallback */ }

  // Model: slippage per contract ≈ spread/2 × (1 + 0.05 × sqrt(contracts))
  // Larger orders walk the book slightly; sqrt scaling keeps it realistic
  const slippagePerContract = (avgSpreadCents / 2) * (1 + 0.05 * Math.sqrt(avgContracts));
  const entered = trades.filter(t => t.outcome !== "no_trade");
  const totalSlippage = entered.length * avgContracts * slippagePerContract;
  const rawPnl = entered.reduce((s, t) => s + t.pnlCents, 0);

  return {
    avgSpreadCents:     Math.round(avgSpreadCents),
    avgSlippageCents:   Math.round(slippagePerContract * 10) / 10,
    totalSlippageCents: Math.round(totalSlippage),
    netPnlCents:        Math.round(rawPnl - totalSlippage),
    sampleCount,
  };
}

// ── Risk rating ───────────────────────────────────────────────────────────────

function riskRating(maxDD: number, kellyFrac: number): "LOW" | "MEDIUM" | "HIGH" | "EXTREME" {
  const score = maxDD * 100 + kellyFrac * 20;
  if (score < 20) return "LOW";
  if (score < 35) return "MEDIUM";
  if (score < 55) return "HIGH";
  return "EXTREME";
}

// ── Equity curve builder ──────────────────────────────────────────────────────

function buildEquityCurve(trades: TradeRecord[]): ScenarioEquityPoint[] {
  let balance = 10_000;  // starting ¢
  const curve: ScenarioEquityPoint[] = [];
  let idx = 0;
  for (const t of trades) {
    if (t.outcome === "no_trade") continue;
    balance += t.pnlCents;
    curve.push({
      tradeIdx:     idx++,
      balanceCents: balance,
      pnlCents:     t.pnlCents,
      outcome:      t.outcome,
      entryPrice:   t.entryPriceCents,
      exitReason:   t.exitReason,
    });
  }
  return curve;
}

// ── Walk-forward runner ───────────────────────────────────────────────────────
// Simulation is fully inlined below so we can pass kellyFrac overrides directly.
// Single candle fetch is shared across all 8 scenarios.

// ── Main entry point ──────────────────────────────────────────────────────────

/**
 * Run all 8 scenarios against 2,000 5-min Kalshi settlement candles and return a full
 * comparison report.  Takes ~5–8 s (one candle fetch + 8 walk-forward runs).
 */
export async function runScenarioComparison(
  onProgress?: (msg: string, pct: number) => void,
): Promise<ScenarioReport> {
  onProgress?.("Fetching real 5-min BTC candles (Binance/Coinbase)…", 5);

  // Real candles only — see backtest-engine.ts's runGridSearch() header comment
  // (2026-08-02) for why the old Kalshi-settlement-interpolated candles are no
  // longer used here: they baked the future settlement price into every
  // intra-period 5-min bar, which is a lookahead-bias bug. 8,000 candles
  // (≈ 28 days) matches runGridSearch's window — enough OOS trades to be
  // meaningful without OOMing (20k crashed the grid search's combo sweep).
  const CANDLE_COUNT = 8_000;
  const startMs       = Date.now() - CANDLE_COUNT * 5 * 60 * 1000;
  const { candles: c5m } = await fetchRealCandles(startMs, CANDLE_COUNT, 5);
  const c15m: OHLCCandle[] = []; // synthesized from real 5m triples — see groupPeriods()

  if (c5m.length < 200) throw new Error("Insufficient real 5-min candle data");

  const btcPriceStart = c5m[0]?.open ?? 0;
  const btcPriceEnd   = c5m[c5m.length - 1]?.close ?? 0;

  onProgress?.("Running 8 scenarios via grid search…", 15);

  // Run a focused grid search with exactly the 8 scenario strats.
  // We override the grid by temporarily monkey-patching — instead, we call
  // the exported runGridSearch but filter on scenario names.
  // More cleanly: import the walk-forward function via a mini grid with 1 combo per scenario.

  const results: ScenarioResult[] = [];

  // Use a shared grid-search result so we only fetch candles once.
  // Map each scenario to a StrategyDef, run via runGridSearch with custom combos.
  // Since we can't inject custom combos into runGridSearch, use the lower-level
  // backtest functions directly by importing them here.

  // Import the internals we need (they are not exported — use dynamic import workaround)
  // Instead, run via a targeted grid search: pass each scenario strat as a single-combo grid.

  // We call runGridSearch which does its own candle fetch, but that's acceptable
  // for this endpoint (run once, cache result).  We use a workaround: for each scenario
  // we call runGridSearch with a modified grid that only explores that one strategy.
  // To avoid 8 × candle fetches, we use a cached candle approach via direct implementation.

  // ── Direct implementation using the exported primitives ────────────────────
  // Re-implement the essential walk-forward loop here to avoid the private API problem.

  const CANDLES_PER_YEAR = (365 * 24 * 60) / 15;

  function normCDF(z: number): number {
    const sign = z >= 0 ? 1 : -1;
    const za   = Math.abs(z);
    const t    = 1 / (1 + 0.2316419 * za);
    const poly = t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
    const pdf  = Math.exp(-za * za / 2) / Math.sqrt(2 * Math.PI);
    const p    = 1 - pdf * poly;
    return sign === 1 ? p : 1 - p;
  }

  function realizedVol(prices: number[]): number {
    if (prices.length < 3) return 0.007;
    const rets: number[] = [];
    for (let i = 1; i < prices.length; i++) rets.push(Math.log(prices[i] / prices[i - 1]));
    const mean = rets.reduce((a, b) => a + b, 0) / rets.length;
    const v    = rets.map(r => (r - mean) ** 2).reduce((a, b) => a + b, 0) / (rets.length - 1);
    return Math.sqrt(v) * Math.sqrt(CANDLES_PER_YEAR);
  }

  function probEdge(S: number, K: number, vol: number, minutesLeft: number) {
    if (vol <= 0 || minutesLeft <= 0 || K <= 0 || S <= 0) return { prob: 0.5, edge: 0 };
    const T  = minutesLeft / (365 * 24 * 60);
    const d1 = (Math.log(S / K) + 0.5 * vol * vol * T) / (vol * Math.sqrt(T));
    return { prob: normCDF(d1), edge: Math.abs(normCDF(d1) - 0.5) * 100 };
  }

  interface P15 {
    periodOpen: number;
    c0: OHLCCandle; c1: OHLCCandle; c1b?: OHLCCandle; c2: OHLCCandle;
    settledAbove: boolean;
  }

  // Group 5-min candles into 15-min periods
  const sorted5m = [...new Map(c5m.map(c => [c.time, c])).values()].sort((a, b) => a.time - b.time);
  const c15mMap  = new Map(c15m.map(c => [c.time, c]));

  let startIdx = 0;
  while (startIdx < sorted5m.length && sorted5m[startIdx].time % 900 !== 0) startIdx++;

  const periods: P15[] = [];
  for (let i = startIdx; i + 2 < sorted5m.length; i += 3) {
    const c0  = sorted5m[i];
    const c1  = sorted5m[i + 1];
    const c1b = sorted5m[i + 2];
    if (c1.time - c0.time !== 300 || c1b.time - c0.time !== 600) continue;
    const match = c15mMap.get(c0.time) ?? c15m.find(c => Math.abs(c.time - c0.time) < 30);
    const c2: OHLCCandle = match ?? { time: c0.time, open: c0.open, high: Math.max(c0.high, c1.high, c1b.high), low: Math.min(c0.low, c1.low, c1b.low), close: c1b.close, volume: c0.volume + c1.volume + c1b.volume };
    periods.push({ periodOpen: c0.open, c0, c1, c1b, c2, settledAbove: c2.close > c0.open });
  }

  if (periods.length < 60) throw new Error(`Only ${periods.length} periods — need ≥60`);

  const fold    = Math.floor(periods.length / 4);
  const trainPs = periods.slice(0, fold * 3);
  const oosPs   = periods.slice(fold * 3);
  const closes  = periods.map(p => p.c2.close);

  function kellyContracts(winRate: number, entry: number, maxC: number, frac: number): number {
    const p = winRate, q = 1 - p;
    const b = entry > 0 ? (100 - entry) / entry : 1;
    const k = p - q / b;
    if (k <= 0) return 1;
    return Math.max(1, Math.min(maxC, Math.floor(k * frac * maxC)));
  }

  function simulateScenario(ps: P15[], sc: ScenarioConfig, foldIdx: number): BacktestResult {
    const strat = sc.strat;
    const trades: TradeRecord[] = [];
    let equity = 10_000, peak = 10_000;
    const equityCurve = [equity];
    const pnlSeries: number[] = [];
    let consecutiveLosses = 0, cooldown = 0, tradedThisPeriod = false, lastIdx = -1;

    for (let i = 20; i < ps.length; i++) {
      const p   = ps[i];
      const vol = realizedVol(closes.slice(Math.max(0, i - 40), i));

      if (i !== lastIdx) { tradedThisPeriod = false; lastIdx = i; if (cooldown > 0) cooldown--; }
      if (tradedThisPeriod || cooldown > 0) continue;

      // Observation
      const currentPrice = strat.observationMinute === 5 ? p.c1.open : p.c1.close;
      const vel          = strat.observationMinute === 5
        ? (p.c1.open - p.c0.open) / 5
        : (p.c1.close - p.c0.open) / 10;
      const minsLeft     = strat.observationMinute === 5 ? 10 : 5;
      const { prob, edge } = probEdge(currentPrice, p.periodOpen, vol, minsLeft);
      // Lookahead fix (same class as Task #354 / backtest-engine.ts's
      // observeAtMinute5): at the minute-5 decision point only c0 (minutes
      // 0-5) has fully elapsed — p.c1.close is the price at minute 10, future
      // data relative to this decision. Comparing it here let the minute-5
      // stall filter "see" 5 minutes ahead. Derive stalling from c0's own
      // shape only (net move vs its own high-low range) at minute 5; the
      // minute-10 branch already only reads c0/c1 data that has elapsed by
      // minute 10, so it keeps the original formula.
      const c0Range      = p.c0.high - p.c0.low;
      const c0Net        = Math.abs(p.c0.close - p.c0.open);
      const stalling     = strat.observationMinute === 5
        ? c0Range > 0 && (c0Net / c0Range) < 0.35 && Math.abs(vel) > 5
        : Math.abs(p.c1.close - p.c1.open) < Math.abs(p.c0.close - p.c0.open) * 0.35 && Math.abs(vel) > 5;
      const accelerating = Math.abs(vel) > 1.3;  // simplified for scenario engine

      const noTrade = (r: string) => {
        trades.push({ periodIdx: i, foldIdx, signal: "STAY_OUT", velocity5: vel, velocity10: 0, modelProb: prob, edge, stalling, accelerating, confidence: 0, entryPriceCents: 50, exitPriceCents: null, outcome: "no_trade", pnlCents: 0, contracts: 0, settledAbove: p.settledAbove, exitReason: "no_trade", feeCentsPaid: 0, evPasses: false, netPnlCents: 0 });
      };

      if (Math.abs(vel) < strat.minVelocity) { noTrade("vel"); continue; }
      if (strat.useEdge && edge < strat.minEdge) { noTrade("edge"); continue; }
      if (strat.useStallFilter && stalling) { noTrade("stall"); continue; }
      if (strat.useAcceleration && !accelerating) { noTrade("accel"); continue; }
      if (strat.useLossCooldown && consecutiveLosses >= 2 && Math.abs(vel) < strat.minVelocity * strat.cooldownMultiplier) { noTrade("cooldown"); continue; }

      const ddPct      = peak > 0 ? (peak - equity) / peak * 100 : 0;
      const guard      = ddPct < strat.drawdownGuardPct ? 1 : ddPct < strat.drawdownGuardPct * 1.5 ? 0.5 : 0.25;
      const signal: "LONG" | "SHORT" = vel > 0 ? "LONG" : "SHORT";
      const entry      = Math.max(25, Math.min(75, Math.round(prob * 100)));

      // Fee/slippage-aware EV floor (backtest/live parity, 2026-08-11): live
      // never places an order with EV ratio < 0.03 (estimateTradeEV /
      // passesPathEVGate in trading-bot.ts / trade-path.ts). This scenario
      // engine had no equivalent gate at all — it would size and record any
      // trade that passed the velocity/edge/stall filters regardless of
      // whether the edge survived Kalshi's fee. winRate is the probability
      // of the side actually taken (prob for LONG, 1-prob for SHORT), not
      // the raw up-probability used for entry pricing.
      const sideWinRate = signal === "LONG" ? prob : 1 - prob;
      const { netEV: preTradeNetEV, totalFriction: preTradeFriction } = computeTradeEV({
        entryPriceCents: entry,
        winRate:         sideWinRate,
      });
      const preTradeCost  = entry + preTradeFriction;
      const preTradeEVRatio = (preTradeCost > 0 && preTradeCost < 100) ? preTradeNetEV / preTradeCost : -1;
      if (preTradeEVRatio < 0.03) { noTrade("ev_floor"); continue; }

      const contracts  = Math.max(1, Math.round(kellyContracts(0.70, entry, sc.maxContracts, sc.kellyFrac) * guard));
      if (equity < contracts * entry) { noTrade("equity"); continue; }

      // Simulate P&L using mid-period binary option price
      const midBtcPrice = p.c1b?.open ?? p.c2.open;
      const safeVol     = Math.max(0.20, Math.min(3.0, vol));
      const midYesPrice = binaryCallPrice(midBtcPrice, p.periodOpen, safeVol, 2.5);
      const midSidePrice = signal === "LONG" ? midYesPrice : 100 - midYesPrice;
      const perContrPnl  = midSidePrice - entry;

      // Kalshi taker fee — price-dependent, same formula live pays (see
      // kalshiFeeCents in constants.ts). Charged once per contract on every
      // exit path; this file previously charged no fee at all (see the dead
      // KALSHI_TAKER_FEE constant removed above).
      const feePerContract = kalshiTakerFeeCents(entry, 1);
      const feeOrderCents = kalshiTakerFeeCents(entry, contracts);

      let outcome: TradeRecord["outcome"];
      let pnlCents: number;
      let exitP: number;
      let exitReason: TradeRecord["exitReason"];

      if (strat.useStopLoss && perContrPnl < -strat.stopLossCents) {
        exitP      = Math.max(1, entry - strat.stopLossCents);
        pnlCents   = (exitP - entry - feePerContract) * contracts;
        outcome    = "early_loss";
        exitReason = "stop_loss";
      } else if (strat.useProfitTake && perContrPnl > strat.profitTakeCents) {
        exitP      = Math.min(99, entry + strat.profitTakeCents);
        pnlCents   = (exitP - entry - feePerContract) * contracts;
        outcome    = "early_win";
        exitReason = "profit_take";
      } else {
        const settledUp = p.c2.close > p.periodOpen;
        const won       = signal === "LONG" ? settledUp : !settledUp;
        pnlCents   = won ? contracts * (100 - entry - feePerContract) : -contracts * (entry + feePerContract);
        exitP      = won ? 100 : 0;
        outcome    = won ? "win" : "loss";
        exitReason = "settlement";
      }

      equity += pnlCents;
      if (equity > peak) peak = equity;
      pnlSeries.push(pnlCents);
      equityCurve.push(equity);
      tradedThisPeriod = true;

      const conf = Math.min(95, Math.round(edge * 3 + Math.abs(vel) / 5 + 55));
      const won2 = outcome === "win" || outcome === "early_win";
      if (won2) consecutiveLosses = 0; else consecutiveLosses++;

      // This engine already gates entry on the live EV floor above
      // (preTradeEVRatio < 0.03 → noTrade) and already bakes the real
      // Kalshi fee into pnlCents at every exit path — every entered trade
      // here already IS the live-proxy trade, unlike backtest-engine.ts's
      // grid search (which stamps gross+net side by side without gating).
      trades.push({ periodIdx: i, foldIdx, signal, velocity5: vel, velocity10: 0, modelProb: prob, edge, stalling, accelerating, confidence: conf, entryPriceCents: entry, exitPriceCents: exitP, outcome, pnlCents, contracts, settledAbove: p.settledAbove, exitReason, feeCentsPaid: feeOrderCents, evPasses: true, netPnlCents: pnlCents });
    }

    const entered    = trades.filter(t => t.outcome !== "no_trade");
    const wins       = entered.filter(t => t.outcome === "win"  || t.outcome === "early_win");
    const losses     = entered.filter(t => t.outcome === "loss" || t.outcome === "early_loss");
    const earlyExits = entered.filter(t => t.exitReason !== "settlement" && t.exitReason !== "no_trade");
    const totalPnl   = entered.reduce((s, t) => s + t.pnlCents, 0);
    const winPnls    = wins.map(t => t.pnlCents);
    const lossPnls   = losses.map(t => Math.abs(t.pnlCents));

    function maxDD(eq: number[]): number {
      let pk = eq[0] ?? 0, md = 0;
      for (const e of eq) { if (e > pk) pk = e; const dd = pk > 0 ? (pk - e) / pk : 0; if (dd > md) md = dd; }
      return md;
    }
    function sharpe(series: number[]): number {
      if (series.length < 2) return 0;
      const mn = series.reduce((a, b) => a + b, 0) / series.length;
      const sd = Math.sqrt(series.map(x => (x - mn) ** 2).reduce((a, b) => a + b, 0) / (series.length - 1));
      return sd === 0 ? (mn > 0 ? 3 : 0) : (mn / sd) * Math.sqrt(CANDLES_PER_YEAR / series.length);
    }
    function pf(w: number[], l: number[]): number {
      const gw = w.reduce((a, b) => a + b, 0), gl = l.reduce((a, b) => a + b, 0);
      return gl > 0 ? gw / gl : gw > 0 ? 10 : 0;
    }

    const mDD    = maxDD(equityCurve);
    const sh     = sharpe(pnlSeries);
    const pfVal  = pf(winPnls, lossPnls);
    const annRet = pnlSeries.length > 0 ? (pnlSeries.reduce((a, b) => a + b, 0) / pnlSeries.length) * CANDLES_PER_YEAR / 100 : 0;
    const calmar = mDD > 0 ? annRet / mDD : annRet > 0 ? 10 : 0;
    const comp   = 0.4 * Math.min(sh, 5) / 5 + 0.3 * Math.min(pfVal, 5) / 5 + 0.3 * Math.min(Math.max(calmar, 0), 5) / 5;

    return {
      strategy: strat, phase: foldIdx === 0 ? "train" : "oos",
      totalPeriods: ps.length, tradesEntered: entered.length,
      wins: wins.length, losses: losses.length,
      winRate: entered.length > 0 ? wins.length / entered.length : 0,
      pnlCents: totalPnl, pnlDollars: totalPnl / 100,
      roi: totalPnl / 10_000,
      sharpe: sh, profitFactor: pfVal, maxDrawdown: mDD, calmar,
      compositeScore: comp,
      avgWinCents:  wins.length > 0   ? winPnls.reduce((a, b)  => a + b, 0) / wins.length : 0,
      avgLossCents: losses.length > 0 ? lossPnls.reduce((a, b) => a + b, 0) / losses.length : 0,
      expectancyCents: entered.length > 0 ? totalPnl / entered.length : 0,
      trades, regimeStats: [], earlyExits: earlyExits.length,
      // researchOnly=false: this engine already gates entry on the live EV
      // floor and bakes the real fee into pnlCents above (2026-08-11 fix),
      // so the top-level numbers here already ARE the live-proxy view.
      // netMetrics mirrors them (via the same trades, all evPasses=true).
      researchOnly: false,
      netMetrics: summarizeNet(trades, ps.length),
    };
  }

  function bootstrapCI(result: BacktestResult): { p5: number; p50: number; p95: number; mean: number } {
    const oosTrades = result.trades.filter(t => t.outcome !== "no_trade");
    const raw       = oosTrades.map(t => (t.outcome === "win" || t.outcome === "early_win") ? 1 : 0);
    if (raw.length < 5) return { p5: 0, p50: result.winRate, p95: 1, mean: result.winRate };
    const samples: number[] = [];
    for (let i = 0; i < 500; i++) {
      let wins = 0;
      for (let j = 0; j < raw.length; j++) wins += raw[Math.floor(Math.random() * raw.length)];
      samples.push(wins / raw.length);
    }
    samples.sort((a, b) => a - b);
    return { p5: samples[Math.floor(samples.length * 0.05)], p50: samples[Math.floor(samples.length * 0.50)], p95: samples[Math.floor(samples.length * 0.95)], mean: samples.reduce((a, b) => a + b, 0) / samples.length };
  }

  for (let s = 0; s < SCENARIOS.length; s++) {
    const sc = SCENARIOS[s];
    onProgress?.(`Running scenario ${s + 1}/8: ${sc.name}…`, 15 + (s / 8) * 70);

    const trainResult = simulateScenario(trainPs, sc, 0);
    const oosResult   = simulateScenario(oosPs,   sc, 1);
    const ci          = bootstrapCI(oosResult);
    const curve       = buildEquityCurve(oosResult.trades);
    const avgCtrcts   = oosResult.tradesEntered > 0
      ? oosResult.trades.filter(t => t.outcome !== "no_trade").reduce((s, t) => s + t.contracts, 0) / oosResult.tradesEntered
      : sc.maxContracts / 2;
    const slip        = await estimateSlippage(oosResult.trades, avgCtrcts);
    const netRoi      = oosResult.roi * 100 - (slip.totalSlippageCents / 10_000) * 100;

    results.push({
      scenario:    sc,
      oos:         oosResult,
      train:       trainResult,
      ci,
      equityCurve: curve,
      slippage:    slip,
      netRoiPct:   Math.round(netRoi * 100) / 100,
      riskRating:  riskRating(oosResult.maxDrawdown, sc.kellyFrac),
      rank:        0,  // filled below
    });
  }

  // Rank by composite OOS score
  results.sort((a, b) => b.oos.compositeScore - a.oos.compositeScore);
  results.forEach((r, i) => { r.rank = i + 1; });
  results.sort((a, b) => a.scenario.id.localeCompare(b.scenario.id));  // stable sort for UI

  onProgress?.("Done!", 100);

  return {
    generatedAt:   new Date().toISOString(),
    periodsTotal:  periods.length,
    periodsOos:    oosPs.length,
    btcPriceStart: Math.round(btcPriceStart),
    btcPriceEnd:   Math.round(btcPriceEnd),
    scenarios:     results,
    bestScenario:  results.slice().sort((a, b) => a.rank - b.rank)[0]?.scenario.id ?? "",
    worstScenario: results.slice().sort((a, b) => b.rank - a.rank)[0]?.scenario.id ?? "",
  };
}

// ── CSV export ────────────────────────────────────────────────────────────────

export function scenarioReportToCsv(report: ScenarioReport): string {
  const esc = (v: unknown) => {
    const s = String(v ?? "");
    return s.includes(",") || s.includes('"') ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const pct = (n: number) => `${(n * 100).toFixed(1)}%`;
  const d   = (cents: number) => `$${(cents / 100).toFixed(2)}`;

  const lines: string[] = [];

  // ── Summary ──
  lines.push("BTC 15-MIN BINARY OPTIONS BOT — SCENARIO COMPARISON REPORT");
  lines.push(`Generated,${report.generatedAt}`);
  lines.push(`Total 15-min Periods,${report.periodsTotal}`);
  lines.push(`Out-of-Sample Periods,${report.periodsOos}`);
  lines.push(`BTC Price Range,$${report.btcPriceStart.toLocaleString()} → $${report.btcPriceEnd.toLocaleString()}`);
  lines.push(`Best Scenario,${report.bestScenario}`);
  lines.push(`Worst Scenario,${report.worstScenario}`);
  lines.push("");

  // ── Scenario comparison matrix ──
  lines.push([
    "Rank", "Scenario", "Risk", "Trades (OOS)", "Win Rate", "Win Rate 5th%",
    "Win Rate 95th%", "Avg Win (¢)", "Avg Loss (¢)", "Expectancy (¢)",
    "Gross ROI", "Net ROI (after slip)", "Sharpe", "Calmar", "Profit Factor",
    "Max Drawdown", "Avg Spread (¢)", "Est. Slippage/trade (¢)", "Composite Score",
    "Kelly Fraction", "Max Contracts", "Settlement Hold", "Obs Minute",
  ].map(esc).join(","));

  for (const r of report.scenarios.slice().sort((a, b) => a.rank - b.rank)) {
    const { oos, ci, slippage: sl } = r;
    lines.push([
      r.rank,
      `${r.scenario.emoji} ${r.scenario.name}`,
      r.riskRating,
      oos.tradesEntered,
      pct(oos.winRate),
      pct(ci.p5),
      pct(ci.p95),
      Math.round(oos.avgWinCents),
      Math.round(oos.avgLossCents),
      Math.round(oos.expectancyCents),
      `${(oos.roi * 100).toFixed(1)}%`,
      `${r.netRoiPct.toFixed(1)}%`,
      oos.sharpe.toFixed(2),
      oos.calmar.toFixed(2),
      oos.profitFactor.toFixed(2),
      pct(oos.maxDrawdown),
      sl.avgSpreadCents,
      sl.avgSlippageCents.toFixed(1),
      oos.compositeScore.toFixed(3),
      r.scenario.kellyFrac,
      r.scenario.maxContracts,
      r.scenario.settlementHold ? "YES" : "NO",
      r.scenario.strat.observationMinute,
    ].map(esc).join(","));
  }
  lines.push("");

  // ── Per-scenario trade detail ──
  for (const r of report.scenarios.slice().sort((a, b) => a.rank - b.rank)) {
    lines.push(`=== ${r.scenario.emoji} ${r.scenario.name.toUpperCase()} — OOS TRADE DETAIL ===`);
    lines.push(`Description,${r.scenario.description}`);
    lines.push([
      "Trade #", "Period Idx", "Signal", "Entry ¢", "Exit ¢",
      "Contracts", "P&L (¢)", "Outcome", "Exit Reason",
      "Model Prob", "Edge %", "Velocity", "Stalling", "Accelerating",
      "Running Balance (¢)",
    ].map(esc).join(","));

    let balance = 10_000;
    let tradeNum = 0;
    for (const t of r.oos.trades) {
      if (t.outcome === "no_trade") continue;
      balance += t.pnlCents;
      tradeNum++;
      lines.push([
        tradeNum,
        t.periodIdx,
        t.signal,
        t.entryPriceCents,
        t.exitPriceCents ?? (t.outcome === "win" ? 100 : 0),
        t.contracts,
        t.pnlCents,
        t.outcome.toUpperCase(),
        t.exitReason.toUpperCase(),
        `${(t.modelProb * 100).toFixed(1)}%`,
        `${t.edge.toFixed(1)}%`,
        t.velocity5.toFixed(1),
        t.stalling ? "YES" : "NO",
        t.accelerating ? "YES" : "NO",
        balance,
      ].map(esc).join(","));
    }
    lines.push("");
  }

  return lines.join("\n");
}
