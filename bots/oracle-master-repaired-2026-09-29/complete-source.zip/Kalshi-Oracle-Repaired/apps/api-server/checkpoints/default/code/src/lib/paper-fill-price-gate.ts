/**
 * paper-fill-price-gate — PR #14 (item 3): re-check the EV floor and the CC
 * entry band at the PAPER FILL PRICE (quote + simulated adverse slippage),
 * before the virtual book is debited.
 *
 * Why: admission (alignedTakeGate / decideFrozenCcEntry) judges the DECISION
 * quote. The paper branch of placeOrder then adds estimatePaperSlippageCents()
 * and fills at quote+slip. A quote that passed EV ≥ 3¢ and 20–55¢ could fill
 * at a price that fails either (the #72 pattern: quote passes, stale/slipped
 * fill fails). Such a fill is now SKIPPED with a clear reason code.
 *
 * EV at fill (per contract, cents):
 *   gross = p·(100 − fill) − (1 − p)·fill            (= 100·p − fill)
 *   fee   = exact Kalshi fee on the real order at the fill price / contracts
 *           (maker fee for a maker paper fill, else taker)
 *   evAtFill = gross − fee
 * No extra *modeled* slippage is subtracted: at the fill price the slippage
 * is already realized inside `fill`. Floors are the unchanged hard locks
 * (EV_FLOOR = 3¢, band FROZEN_CC_ASK_MIN..MAX = 20..55). Pure. No I/O.
 * Never raises size, never changes EV/Kelly/sizing math — skip-only.
 */
import { EV_FLOOR } from "./admission.js";
import { FROZEN_CC_ASK_MIN, FROZEN_CC_ASK_MAX } from "./frozen-cc.js";
import { kalshiTakerFeeCents, kalshiMakerFeeCents } from "./fees/kalshi-fee.js";

export const FILL_PRICE_EV_FAIL = "FILL_PRICE_EV_FAIL" as const;
export const FILL_PRICE_BAND_FAIL = "FILL_PRICE_BAND_FAIL" as const;

export type PaperFillPriceCheckInput = {
  /** Win probability of the side being bought (same p admission used). */
  p: number | null | undefined;
  /** Decision quote (ask) the take was approved at — for the reason text. */
  quoteCents: number;
  /** Simulated paper fill price (quote + slippage), cents. */
  fillPriceCents: number;
  /** Real order size (fee is ceil'd once on the whole order). */
  contracts: number;
  /** Maker paper fill → maker fee; default taker. */
  maker?: boolean;
  /** Apply the 20–55¢ entry band (CC / frozen-CC fills). */
  checkBand: boolean;
  evFloorCents?: number;
  bandMinCents?: number;
  bandMaxCents?: number;
};

export type PaperFillPriceCheck =
  | { ok: true; evAtFillCents: number; feePerContractCents: number }
  | {
      ok: false;
      code: typeof FILL_PRICE_EV_FAIL | typeof FILL_PRICE_BAND_FAIL;
      reason: string;
      evAtFillCents: number | null;
      feePerContractCents: number | null;
    };

export function paperFillEvAtFillCents(opts: {
  p: number;
  fillPriceCents: number;
  contracts: number;
  maker?: boolean;
}): { evAtFillCents: number; feePerContractCents: number } {
  const c = Math.max(1, Math.floor(opts.contracts));
  const fill = opts.fillPriceCents;
  const feeTotal = opts.maker === true ? kalshiMakerFeeCents(fill, c) : kalshiTakerFeeCents(fill, c);
  const feePer = feeTotal / c;
  const gross = opts.p * (100 - fill) - (1 - opts.p) * fill;
  return { evAtFillCents: gross - feePer, feePerContractCents: feePer };
}

function r2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function checkPaperFillPrice(input: PaperFillPriceCheckInput): PaperFillPriceCheck {
  const floor = input.evFloorCents ?? EV_FLOOR;
  const lo = input.bandMinCents ?? FROZEN_CC_ASK_MIN;
  const hi = input.bandMaxCents ?? FROZEN_CC_ASK_MAX;
  const fill = input.fillPriceCents;
  const slip = Number.isFinite(fill) && Number.isFinite(input.quoteCents) ? fill - input.quoteCents : null;
  const at = `fill ${fill}¢ (quote ${input.quoteCents}¢${slip != null ? ` + slip ${slip}¢` : ""})`;

  if (!Number.isFinite(fill) || fill < 1 || fill > 99) {
    return {
      ok: false, code: input.checkBand ? FILL_PRICE_BAND_FAIL : FILL_PRICE_EV_FAIL,
      reason: `${at} is not a valid 1–99¢ price`, evAtFillCents: null, feePerContractCents: null,
    };
  }
  if (input.checkBand && (fill < lo || fill > hi)) {
    return {
      ok: false, code: FILL_PRICE_BAND_FAIL,
      reason: `${at} outside entry band ${lo}–${hi}¢`, evAtFillCents: null, feePerContractCents: null,
    };
  }
  const p = input.p;
  if (typeof p !== "number" || !Number.isFinite(p) || p <= 0 || p >= 1) {
    return {
      ok: false, code: FILL_PRICE_EV_FAIL,
      reason: `${at}: p=${String(p)} invalid — EV at fill unknown (fail closed)`,
      evAtFillCents: null, feePerContractCents: null,
    };
  }
  const { evAtFillCents, feePerContractCents } = paperFillEvAtFillCents({
    p, fillPriceCents: fill, contracts: input.contracts, maker: input.maker,
  });
  if (!(evAtFillCents >= floor)) {
    return {
      ok: false, code: FILL_PRICE_EV_FAIL,
      reason: `${at}: EV at fill ${r2(evAtFillCents)}¢ < ${floor}¢ floor (p=${p}, fee ${r2(feePerContractCents)}¢/ct)`,
      evAtFillCents, feePerContractCents,
    };
  }
  return { ok: true, evAtFillCents, feePerContractCents };
}
