import test from "node:test";
import assert from "node:assert/strict";
import {
  expertAgent,
  parseExitPolicy,
  parseEntryFilters,
} from "./expert-agent.js";
import { applyHardRiskLimits, tradingBot } from "./trading-bot.js";

// Importing the bot restores its singleton; don't allow its timer to run in this
// pure policy test.
tradingBot.stop();

test("AI exit policy clamps values to conservative ranges", () => {
  assert.deepEqual(parseExitPolicy({
    stopLossCents: -100,
    profitTakeCents: 999,
    trailingProfitCents: 0,
    timeStopMinutes: 99,
    timeStopMinGainCents: -1,
  }), {
    stopLossCents: 3,
    profitTakeCents: 60,
    trailingProfitCents: 2,
    timeStopMinutes: 10,
    timeStopMinGainCents: 0,
  });
});

test("invalid AI exit policy is ignored instead of changing exits", () => {
  assert.equal(parseExitPolicy({ stopLossCents: "disabled", profitTakeCents: null }), undefined);
  assert.equal(parseExitPolicy(null), undefined);
});

test("AI entry filters clamp every numeric safety rail to its hard range", () => {
  assert.deepEqual(parseEntryFilters({
    minConfidence: -100,
    minVelocity: 999,
    minEntryPrice: -10,
    maxEntryPrice: 999,
    useProbEdge: true,
    minProbEdge: -50,
    useStallFilter: false,
    useAcceleration: true,
    maxContractVolatility: 999,
  }), {
    minConfidence: 50,
    minVelocity: 120,
    minEntryPrice: 5,
    maxEntryPrice: 95,
    useProbEdge: true,
    minProbEdge: 0,
    useStallFilter: false,
    useAcceleration: true,
    maxContractVolatility: 20,
  });
});

test("inverted AI entry price bands are discarded rather than widening admission", () => {
  assert.deepEqual(parseEntryFilters({
    minEntryPrice: 80,
    maxEntryPrice: 20,
    minConfidence: 70,
  }), { minConfidence: 70 });
});

test("non-numeric and empty AI entry filters are ignored", () => {
  assert.equal(parseEntryFilters({
    minConfidence: "50",
    minVelocity: null,
    minEntryPrice: "5",
    maxEntryPrice: {},
    useProbEdge: 1,
    minProbEdge: "10",
    useStallFilter: "false",
    useAcceleration: null,
    maxContractVolatility: NaN,
  }), undefined);
  assert.equal(parseEntryFilters({}), undefined);
  assert.equal(parseEntryFilters(null), undefined);
});

test("stale AI assessment supplies no entry-filter overrides", () => {
  const old = expertAgent.lastAssessment;
  try {
    expertAgent.lastAssessment = {
      ts: Date.now() - 301_000,
      signal: "YES",
      confidence: 90,
      reasoning: "old",
      observations: [],
      riskLevel: "LOW",
      confAdj: 10,
      entryFilters: { minConfidence: 85, maxEntryPrice: 20 },
    };
    assert.equal(expertAgent.getEntryFilterOverrides(), null);
  } finally {
    expertAgent.lastAssessment = old;
  }
});

test("AI exit policy only moves every static threshold in the safer direction", () => {
  const staticPolicy = {
    stopLossCents: 15,
    profitTakeCents: 20,
    trailingProfitCents: 10,
    timeStopMinutes: 5,
    timeStopMinGainCents: 4,
  };
  const proposed = parseExitPolicy({
    stopLossCents: 30,          // looser loss width — must retain 15
    profitTakeCents: 60,        // later profit take — must retain 20
    trailingProfitCents: 25,    // wider trailing band — must retain 10
    timeStopMinutes: 10,        // later time stop — must retain 5
    timeStopMinGainCents: 0,    // weaker-profit threshold — must retain 4
  })!;
  const effective = {
    stopLossCents: Math.min(staticPolicy.stopLossCents, proposed.stopLossCents!),
    profitTakeCents: Math.min(staticPolicy.profitTakeCents, proposed.profitTakeCents!),
    trailingProfitCents: Math.min(staticPolicy.trailingProfitCents, proposed.trailingProfitCents!),
    timeStopMinutes: Math.min(staticPolicy.timeStopMinutes, proposed.timeStopMinutes!),
    timeStopMinGainCents: Math.max(staticPolicy.timeStopMinGainCents, proposed.timeStopMinGainCents!),
  };
  assert.deepEqual(effective, staticPolicy);

  const tighter = parseExitPolicy({
    stopLossCents: 8,
    profitTakeCents: 12,
    trailingProfitCents: 4,
    timeStopMinutes: 2,
    timeStopMinGainCents: 12,
  })!;
  assert.deepEqual({
    stopLossCents: Math.min(staticPolicy.stopLossCents, tighter.stopLossCents!),
    profitTakeCents: Math.min(staticPolicy.profitTakeCents, tighter.profitTakeCents!),
    trailingProfitCents: Math.min(staticPolicy.trailingProfitCents, tighter.trailingProfitCents!),
    timeStopMinutes: Math.min(staticPolicy.timeStopMinutes, tighter.timeStopMinutes!),
    timeStopMinGainCents: Math.max(staticPolicy.timeStopMinGainCents, tighter.timeStopMinGainCents!),
  }, tighter);
});

test("AI profit target caps the final normal-trade target, not only its base setting", () => {
  const entryPriceCents = 40;
  const staticProfitCents = 20;
  const aiProfitCents = parseExitPolicy({ profitTakeCents: 5 })!.profitTakeCents!;
  const normalDerivedTarget = Math.max(staticProfitCents, Math.round((100 - entryPriceCents) * 0.75));
  // Regression: this used to remain 45¢ despite a fresh AI request for 5¢.
  const effectiveTarget = Math.min(normalDerivedTarget, aiProfitCents);
  assert.equal(normalDerivedTarget, 45);
  assert.equal(effectiveTarget, 5);
  assert.ok(effectiveTarget < normalDerivedTarget);
});

test("stale AI assessment supplies no exit or sizing controls", () => {
  const old = expertAgent.lastAssessment;
  try {
    expertAgent.lastAssessment = {
      ts: Date.now() - 301_000,
      signal: "YES",
      confidence: 90,
      reasoning: "old",
      observations: [],
      riskLevel: "LOW",
      confAdj: 10,
      exitPolicy: { stopLossCents: 3 },
      sizeMultiplier: 0.25,
    };
    assert.deepEqual(expertAgent.getRiskOverrides(), { exitPolicy: null, sizeMultiplier: null });
  } finally {
    expertAgent.lastAssessment = old;
  }
});

test("hard risk limits still cap AI-reduced sizing and halt daily-loss accounts", () => {
  // Even if the model proposes a valid multiplier, the final independent limit
  // remains the source of truth: 9% of equity (the sole per-trade cap — no
  // fixed-dollar/fixed-contract floor, so this scales correctly at any balance).
  // $100 balance, 50¢ entry (kalshiNetCostCents→52¢ ceil): floor(10_000 * 0.09 / 52) = 17.
  assert.equal(applyHardRiskLimits(10_000, 50, Math.floor(50 * 1), 0), 17);
  assert.equal(applyHardRiskLimits(10_000, 50, Math.floor(50 * 0.25), 0), 12);
  assert.equal(applyHardRiskLimits(10_000, 20, 1, -1_800), 0);
});