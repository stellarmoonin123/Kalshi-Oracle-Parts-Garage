/**
 * paper-ledger.ts
 *
 * Persists paper-sim cash across process restarts so start() does not snap
 * paperVirtualBalanceCents back to paperStartingBalanceCents ($313).
 *
 * File: data/paper-ledger.json (same directory as strategy-learning.json).
 * Path is process.cwd()-relative so the esbuild bundle does not write into
 * the wrong tree (see strategy-learner.ts). Tests pass an explicit path or
 * set PAPER_LEDGER_PATH / PAPER_LEDGER_DATA_DIR.
 *
 * Sanity on load: virtualCents must be a finite number inside 50–150% of
 * paperStartingBalanceCents, and must not be the stale $1000 field default
 * (100_000¢). start() falls back to paperStartingBalanceCents when the
 * file is missing or rejected.
 */

import { isPostCloseEarlyExit } from "./exit-quote-guard.js";
import fs from "node:fs";
import { inspectLegacyRecoveryTexts } from "./ge-legacy-tape-integrity.js";
import path from "node:path";
import { paperFillCostCents } from "./settlement-helpers.js";
import {
  MANUAL_STRATEGY_ID,
  includeInBotWinRate,
} from "./fill-origin.js";

/** Stale in-memory field default ($1000). Never restore this as session cash. */
export const STALE_PAPER_DEFAULT_CENTS = 100_000;

export const PAPER_LEDGER_FILENAME = "paper-ledger.json";

export interface PaperLedger {
  virtualCents: number;
  peakCents: number;
  pnlCents: number;
  wins: number;
  losses: number;
  trades: number;
  /** Epoch ms of last paper reset; restore filters bot_trades to this session. */
  sessionStartTs?: number;
  /**
   * Reserve pool (15% of each bot win) already locked OUT of virtualCents.
   * Persisted so a restart does not reset the pool to 0 while virtualCents
   * stays net of it (Sep 25: cash 30883 + reserve 0 = 49¢ below the 30932 ledger).
   * Accounting only; optional for back-compat with older ledger files.
   */
  reserveCents?: number;
}

export function resolvePaperLedgerPath(): string {
  if (process.env.PAPER_LEDGER_PATH) return process.env.PAPER_LEDGER_PATH;
  const dir = process.env.PAPER_LEDGER_DATA_DIR
    ? path.resolve(process.env.PAPER_LEDGER_DATA_DIR)
    : path.resolve(process.cwd(), "data");
  return path.join(dir, PAPER_LEDGER_FILENAME);
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}


/** Epoch ms must be a real 2020+ desk clock — reject 1060000-style garbage. */
export const PAPER_SESSION_START_MIN_MS = Date.UTC(2020, 0, 1);
export function isSanePaperSessionStartTs(ts: unknown): ts is number {
  return typeof ts === "number"
    && Number.isFinite(ts)
    && ts >= PAPER_SESSION_START_MIN_MS
    && ts < Date.now() + 86_400_000; // allow ≤1d clock skew forward
}


function nonNegInt(value: unknown, fallback = 0): number {
  if (!isFiniteNumber(value) || value < 0) return fallback;
  return Math.round(value);
}

/**
 * True when `raw` is a loadable paper ledger for this starting balance.
 * Virtual must sit in [50%, 150%] of start and must not be $1000 (100_000¢).
 */
export function isSanePaperLedger(raw: unknown, startCents: number): raw is PaperLedger {
  if (!raw || typeof raw !== "object") return false;
  const virtual = (raw as PaperLedger).virtualCents;
  if (!isFiniteNumber(virtual)) return false;
  if (!isFiniteNumber(startCents) || startCents <= 0) return false;
  const v = Math.round(virtual);
  if (v === STALE_PAPER_DEFAULT_CENTS) return false;
  const lo = startCents * 0.5;
  const hi = startCents * 1.5;
  return v >= lo && v <= hi;
}

export const PAPER_STARTING_BALANCE_CENTS = 31_300;

/** Live paper virtualCents: in-band vs $313 start, never Kalshi $1000 cash. Read the file; do not pin a stale snapshot. */
export function isLivePaperLedgerCents(virtualCents: number, startCents = PAPER_STARTING_BALANCE_CENTS): boolean {
  return isSanePaperLedger({
    virtualCents,
    peakCents: Math.max(virtualCents, startCents),
    pnlCents: 0,
    wins: 0,
    losses: 0,
    trades: 0,
  }, startCents);
}

function normalizeLedger(raw: PaperLedger): PaperLedger {
  const virtualCents = Math.round(raw.virtualCents);
  const peakRaw = isFiniteNumber(raw.peakCents) ? Math.round(raw.peakCents) : virtualCents;
  const wins = nonNegInt(raw.wins);
  const losses = nonNegInt(raw.losses);
  const trades = nonNegInt(raw.trades, wins + losses);
  const out: PaperLedger = {
    virtualCents,
    peakCents: Math.max(peakRaw, virtualCents),
    pnlCents: isFiniteNumber(raw.pnlCents) ? Math.round(raw.pnlCents) : 0,
    wins,
    losses,
    trades: trades > 0 ? trades : wins + losses,
  };
  // Round-trip optional sessionStartTs; drop epoch garbage (e.g. 1060000) that
  // would make session filters include the entire bot_trades history.
  if (isFiniteNumber(raw.sessionStartTs) && isSanePaperSessionStartTs(raw.sessionStartTs)) {
    out.sessionStartTs = Math.round(raw.sessionStartTs);
  }
  if (isFiniteNumber(raw.reserveCents) && raw.reserveCents >= 0) {
    out.reserveCents = Math.round(raw.reserveCents);
  }
  return out;
}

/**
 * Load a sane ledger, or null so the caller can pin to paperStartingBalanceCents.
 */
export function loadPaperLedger(startCents: number, filePath?: string): PaperLedger | null {
  const target = filePath ?? resolvePaperLedgerPath();
  try {
    if (!fs.existsSync(target)) return null;
    const parsed: unknown = JSON.parse(fs.readFileSync(target, "utf8"));
    if (!isSanePaperLedger(parsed, startCents)) return null;
    return normalizeLedger(parsed);
  } catch {
    return null;
  }
}

/**
 * Dual-ledger SEV1: read sessionStartTs even when virtualCents fails the
 * 50–150% sanity band (so a bounce can keep the session watermark without
 * inventing a new reset or calling paper/reset).
 */
export function peekPaperLedgerSessionStartTs(filePath?: string): number | null {
  const target = filePath ?? resolvePaperLedgerPath();
  try {
    if (!fs.existsSync(target)) return null;
    const parsed: unknown = JSON.parse(fs.readFileSync(target, "utf8"));
    if (!parsed || typeof parsed !== "object") return null;
    const ts = (parsed as PaperLedger).sessionStartTs;
    if (typeof ts === "number" && isSanePaperSessionStartTs(ts)) return Math.round(ts);
    return null;
  } catch {
    return null;
  }
}

/**
 * Balance start() should use: restored virtual, or the pin when missing/insane.
 */
export function paperBalanceOnStart(startCents: number, filePath?: string): number {
  return loadPaperLedger(startCents, filePath)?.virtualCents ?? startCents;
}

/**
 * Rebuild paper ledger from bot_trades (paper rows).
 * virtualCents = start + settled PnL − open paper cost.
 * Never copies Kalshi cash onto virtualCents.
 */
export function paperLedgerFromBotTrades(opts: {
  startCents: number;
  settledPnlCents: number;
  openCostCents?: number;
  wins: number;
  losses: number;
  peakCents?: number;
}): PaperLedger {
  const openCost = Math.max(0, Math.round(opts.openCostCents ?? 0));
  const virtualCents = Math.round(opts.startCents + opts.settledPnlCents - openCost);
  const peak = Math.max(
    Math.round(opts.peakCents ?? opts.startCents),
    virtualCents,
    Math.round(opts.startCents),
  );
  return {
    virtualCents,
    peakCents: peak,
    pnlCents: Math.round(opts.settledPnlCents),
    wins: opts.wins,
    losses: opts.losses,
    trades: opts.wins + opts.losses,
  };
}

/**
 * Atomically write the paper ledger (tmp + rename). Non-fatal on I/O errors.
 */
export function savePaperLedger(ledger: PaperLedger, filePath?: string): void {
  const target = filePath ?? resolvePaperLedgerPath();
  try {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const json = JSON.stringify(normalizeLedger(ledger), null, 2);
    const tmpPath = `${target}.tmp.${process.pid}`;
    fs.writeFileSync(tmpPath, json, "utf8");
    fs.renameSync(tmpPath, target);
  } catch (err) {
    console.error("[bot] Failed to persist paper ledger:", err);
  }
}

/** Task #442: durable paper fill tape (jsonl) so history survives restart without DB. */
export const PAPER_TRADES_FILENAME = "paper-trades.jsonl";

export interface PaperTradeTapeRow {
  /** PR #16 option B — advisory Mind heave terms that would have blocked (evidence tag). */
  advisoryVetoes?: string[] | null;
  /** PR #16 — Mind heave value at entry (key = window|side). */
  mindHeave?: {
    key: string | null;
    voyageOrder: string | null;
    heaveTo: boolean;
    ovScore: number | null;
    preferSkip: boolean;
    reasons: string[];
  } | null;
  ts: number;
  ticker: string;
  /** GE_013 — durable bot_trades id when known (never fabricated). */
  tradeId?: number;
  side: "yes" | "no";
  contracts: number;
  entryPriceCents: number;
  strategyId: string | null;
  isPaper: true;
  fillOrigin?: "bot" | "manual";
  /** pending at fill; win/loss/unresolved on settle/close append. */
  outcome?: string;
  /** PATH_RIDE CEE exit book on CC/LAG fills. Not a new strategyId. */
  pathRide?: boolean;
  exitBook?: "PATH_RIDE";
  /** Settle/close fields — written by appendPaperTradeClose so tape matches stories. */
  pnlCents?: number;
  exitReason?: string | null;
  exitPriceCents?: number | null;
  holdMs?: number | null;
  settledAt?: number | null;
  event?: "fill" | "close";
  /** STORY_STAMP — fee-net score fields on every CC/LAG close. Null = unknown (never invent). */
  fillAsk?: number | null;
  yesAsk?: number | null;
  noAsk?: number | null;
  pFilledSide?: number | null;
  evCents?: number | null;
  thesisStatus?: "VALID" | "BROKEN" | "UNKNOWN" | null;
  ticketGreen?: boolean | null;
  SESSION_MODE?: string | null;
  lockSide?: {
    mtf: "yes" | "no" | null;
    ha: "yes" | "no" | null;
    analog: "yes" | "no" | null;
    lagProven: boolean | null;
    result: string | null;
  } | null;
  /** GG R3#1 — fee-net quartet on every CC/LAG close (backfill before write). */
  feeNetCents?: number | null;
  skipBaselineCents?: number | null;
  skipBaselineSource?: string | null;
  feeNetVsSkip?: number | null;
  officialSettle?: "YES" | "NO" | null;
  exitClass?: "strategy" | "risk_exit" | null;
  /** ok | STORY_STAMP_INCOMPLETE when quartet still missing after settle-truth backfill. */
  stampStatus?: "ok" | "STORY_STAMP_INCOMPLETE" | null;
  /** Exit != SETTLEMENT (PATH_RIDE_TP etc.) — not side-skill. */
  soldEarly?: boolean;
  /** Held to settle and side != officialSettle. */
  heldWrongSide?: boolean;
  holdToSettlement?: boolean;
  /** BTC path snapshot for trade-log chart (ENTRY/EXIT/HOLD). Display-only. */
  chartSnapshot?: {
    points: { t: number; btc: number; yesMid?: number }[];
    entryTs: number;
    exitTs: number | null;
    heldToSettle: boolean;
    floorStrike: number;
    signal: string;
  } | null;
}

export function resolvePaperTradesPath(): string {
  if (process.env.PAPER_TRADES_PATH) return process.env.PAPER_TRADES_PATH;
  const dir = process.env.PAPER_LEDGER_DATA_DIR
    ? path.resolve(process.env.PAPER_LEDGER_DATA_DIR)
    : path.resolve(process.cwd(), "data");
  return path.join(dir, PAPER_TRADES_FILENAME);
}

export function appendPaperTrade(row: PaperTradeTapeRow, filePath?: string): void {
  if (row.isPaper !== true) return;
  const target = filePath ?? resolvePaperTradesPath();
  try {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const out: PaperTradeTapeRow = {
      ...row,
      event: row.event ?? (row.outcome && row.outcome !== "pending" ? "close" : "fill"),
    };
    fs.appendFileSync(target, JSON.stringify(out) + "\n", "utf8");
  } catch (err) {
    console.error("[bot] Failed to append paper trade:", err);
  }
}

/**
 * Append a settle/close row so paper-trades.jsonl matches stories + ledger.
 * Fill rows stay outcome=pending; this is an additional close line (append-only).
 * Does not rewrite history. paper=live brain. Never touches EV/Kelly floors.
 */
export function appendPaperTradeClose(
  row: Omit<PaperTradeTapeRow, "isPaper" | "event"> & {
    outcome: string;
    pnlCents: number;
  },
  filePath?: string,
): void {
  if (!row.outcome || row.outcome === "pending") return;
  // GG R3#1 belt: fee-net ≡ pnl when caller omitted; vsSkip = feeNet − 0.
  // Does not invent officialSettle / exitClass — settle hook must stamp those.
  const feeNetCents =
    typeof row.feeNetCents === "number" && Number.isFinite(row.feeNetCents)
      ? Math.round(row.feeNetCents)
      : Math.round(row.pnlCents);
  const skipBaselineCents =
    typeof row.skipBaselineCents === "number" && Number.isFinite(row.skipBaselineCents)
      ? Math.round(row.skipBaselineCents)
      : 0;
  const skipBaselineSource = row.skipBaselineSource ?? "never_took";
  const feeNetVsSkip =
    typeof row.feeNetVsSkip === "number" && Number.isFinite(row.feeNetVsSkip)
      ? Math.round(row.feeNetVsSkip)
      : feeNetCents - skipBaselineCents;
  const isCcLag =
    row.strategyId === "CONFLUENCE_CASCADE" || row.strategyId === "BASIS_LAG_EDGE";
  const settleOk = row.officialSettle === "YES" || row.officialSettle === "NO";
  const classOk = row.exitClass === "strategy" || row.exitClass === "risk_exit";
  const stampStatus =
    row.stampStatus
    ?? (isCcLag && !(settleOk && classOk) ? "STORY_STAMP_INCOMPLETE" : "ok");
  appendPaperTrade({
    ...row,
    feeNetCents,
    skipBaselineCents,
    skipBaselineSource,
    feeNetVsSkip,
    stampStatus,
    isPaper: true,
    event: "close",
    settledAt: row.settledAt ?? Date.now(),
  }, filePath);
}

/**
 * R4 — idempotent close append for a durable trade id: skips when the tape
 * already holds a close for the same tradeId + exitReason (a restart / retry
 * of D5 orphan settlement or a rebook must not append a second settle row).
 * Returns true when a row was appended.
 */
export function appendPaperTradeCloseOnce(
  row: Parameters<typeof appendPaperTradeClose>[0] & { tradeId: number },
  filePath?: string,
): boolean {
  const existing = loadPaperTrades(filePath);
  const dup = existing.some((r) => r.tradeId === row.tradeId
    && (r.event === "close" || (r.outcome != null && r.outcome !== "pending"))
    && (r.exitReason ?? null) === (row.exitReason ?? null));
  if (dup) return false;
  appendPaperTradeClose(row, filePath);
  return true;
}

/** Sum fee-net ¢ on close rows (prefers feeNetCents, falls back to pnlCents). */
export function sumPaperCloseFeeNetCents(rows: PaperTradeTapeRow[]): number {
  let sum = 0;
  for (const r of rows) {
    const isClose = r.event === "close" || (r.outcome != null && r.outcome !== "pending");
    if (!isClose) continue;
    if (typeof r.feeNetCents === "number" && Number.isFinite(r.feeNetCents)) {
      sum += Math.round(r.feeNetCents);
    } else if (typeof r.pnlCents === "number" && Number.isFinite(r.pnlCents)) {
      sum += Math.round(r.pnlCents);
    }
  }
  return sum;
}

/** GG R3#1 — sum(paper-trades fee-net) must equal ledger.pnlCents on fixture tape. */
export function reconcilePaperTapeFeeNetToLedger(opts: {
  rows: PaperTradeTapeRow[];
  ledgerPnlCents: number;
}): { ok: boolean; tapeFeeNetCents: number; ledgerPnlCents: number; deltaCents: number } {
  const tapeFeeNetCents = sumPaperCloseFeeNetCents(opts.rows);
  const ledgerPnlCents = Math.round(opts.ledgerPnlCents);
  const deltaCents = tapeFeeNetCents - ledgerPnlCents;
  return { ok: deltaCents === 0, tapeFeeNetCents, ledgerPnlCents, deltaCents };
}

export function loadPaperTrades(filePath?: string): PaperTradeTapeRow[] {
  const target = filePath ?? resolvePaperTradesPath();
  try {
    if (!fs.existsSync(target)) return [];
    const rows: PaperTradeTapeRow[] = [];
    for (const line of fs.readFileSync(target, "utf8").split("\n")) {
      if (!line.trim()) continue;
      try {
        const parsed = JSON.parse(line) as PaperTradeTapeRow;
        if (parsed && parsed.isPaper === true && typeof parsed.ticker === "string") rows.push(parsed);
      } catch { /* skip bad line */ }
    }
    return rows;
  } catch {
    return [];
  }
}

/**
 * Rebuild paper ledger from session paper-trades.jsonl (fills + closes).
 * Prefers tape closes over stale bot_trades "pending" so a PATH_RIDE_TP
 * close that credited cash cannot be clobbered back to open-cost-only.
 * virtualCents = start + settledPnl − openCost − reserveTaken (wins only).
 */
export function paperLedgerFromSessionTape(opts: {
  startCents: number;
  sessionStartTs: number;
  rows: PaperTradeTapeRow[];
  peakCents?: number;
  /** Operator reservePct; defaults 0 (no lock). Matching bot win path. */
  reservePct?: number;
}): PaperLedger {
  const sessionStart = Math.max(0, Math.round(opts.sessionStartTs || 0));
  const reservePct = Math.max(0, opts.reservePct ?? 0);
  const session = opts.rows.filter((r) => {
    const ts = typeof r.ts === "number" && Number.isFinite(r.ts) ? r.ts : 0;
    return sessionStart <= 0 || ts >= sessionStart;
  });

  // Honesty: one settled book row per fill→best-close pair (PATH_RIDE over
  // SETTLEMENT ghosts; spam closes collapse). Session cash stays virtualCents.
  const paired = paperTapeToDisplayTrades(session);
  let settledPnl = 0;
  let wins = 0;
  let losses = 0;
  let reserveTaken = 0;
  let openCost = 0;
  for (const t of paired) {
    if (t.outcome === "win" || t.outcome === "loss") {
      const pnl = typeof t.pnlCents === "number" && Number.isFinite(t.pnlCents)
        ? Math.round(t.pnlCents)
        : 0;
      settledPnl += pnl;
      if (t.outcome === "win") {
        wins++;
        // Live path only skims reserve on BOT wins (includeInBotWinRate); match it.
        if (reservePct > 0 && pnl > 0 && (t.fillOrigin ?? "bot") === "bot") {
          reserveTaken += Math.round(pnl * reservePct / 100);
        }
      } else {
        losses++;
      }
    } else if (t.outcome === "pending" || t.outcome == null) {
      const n = Math.max(0, Math.round(t.contracts ?? 0));
      const px = Math.max(0, Math.round(t.entryPriceCents ?? 0));
      if (n > 0 && px > 0) openCost += paperFillCostCents(n, px);
    }
  }

  const next = paperLedgerFromBotTrades({
    startCents: opts.startCents,
    settledPnlCents: settledPnl,
    openCostCents: openCost,
    wins,
    losses,
    // Peak is finalized AFTER reserve lock — pre-reserve cash is not a real peak.
    peakCents: opts.startCents,
  });
  // Reserve is locked out of spendable virtual (same as recordSettlement).
  next.virtualCents = Math.round(next.virtualCents - reserveTaken);
  const priorPeak = Math.round(opts.peakCents ?? opts.startCents);
  next.peakCents = Math.max(priorPeak, next.virtualCents, Math.round(opts.startCents));
  if (isSanePaperSessionStartTs(sessionStart)) next.sessionStartTs = sessionStart;
  // Return the locked reserve so the caller can restore reservePoolCents;
  // otherwise cash (net of reserve) + pool (0 after restart) < ledger.
  next.reserveCents = Math.max(0, Math.round(reserveTaken));
  return next;
}


/**
 * SEV0 (#727): paper tape PATH_RIDE_* / early-exit closes are authoritative for
 * paper orphans. Startup recovery must NOT re-score them via Kalshi binary wipe.
 * Binary settlement labels are NOT authoritative early closes.
 */
const PAPER_TAPE_BINARY_EXIT_REASONS = new Set([
  "SETTLEMENT",
  "SETTLED_KALSHI",
  "STARTUP_RECOVERY",
  "STARTUP_RECOVERY_UNRESOLVED",
  "STARTUP_RECOVERY_NEVER_FILLED",
]);

export function isPaperTapeAuthoritativeEarlyClose(
  exitReason: string | null | undefined,
): boolean {
  if (!exitReason || typeof exitReason !== "string") return false;
  const reason = exitReason.trim();
  if (!reason) return false;
  if (PAPER_TAPE_BINARY_EXIT_REASONS.has(reason)) return false;
  if (reason.startsWith("PATH_RIDE_")) return true;
  if (reason === "HIGH_ODDS_EXIT" || reason === "HALF_RIDE") return true;
  // Any other non-binary exit on a close row is an early exit (TB, LAG_FLIP, …).
  return true;
}

export type PaperTapeRecoveryClose = {
  outcome: "win" | "loss";
  pnlCents: number;
  exitReason: string;
  settledAtMs: number | null;
  exitPriceCents: number | null;
  contracts: number | null;
  entryPriceCents: number | null;
  side: "yes" | "no" | null;
};

/**
 * Latest authoritative paper-trades.jsonl close for ticker (PATH_RIDE_* / early exit).
 * Pure — pass rows from loadPaperTrades(). Paper-only callers must gate isPaper.
 */
export function lookupPaperTapeCloseForRecovery(
  rows: readonly PaperTradeTapeRow[],
  opts: {
    ticker: string;
    side?: "yes" | "no" | string | null;
    /** When set, require matching contracts (blocks sibling same-ticker orphan stamp). */
    contracts?: number | null;
    /** When set, require matching entry (blocks YES15@43 getting YES16@40 close). */
    entryPriceCents?: number | null;
  },
): PaperTapeRecoveryClose | null {
  const ticker = opts.ticker;
  if (!ticker) return null;
  const sideFilter = opts.side === "yes" || opts.side === "no" ? opts.side : null;
  const wantContracts = typeof opts.contracts === "number" && Number.isFinite(opts.contracts)
    ? Math.round(opts.contracts) : null;
  const wantEntry = typeof opts.entryPriceCents === "number" && Number.isFinite(opts.entryPriceCents)
    ? Math.round(opts.entryPriceCents) : null;
  let best: PaperTradeTapeRow | null = null;
  for (const r of rows) {
    if (r.ticker !== ticker) continue;
    if (sideFilter && r.side && r.side !== sideFilter) continue;
    if (wantContracts != null && Math.round(r.contracts ?? NaN) !== wantContracts) continue;
    if (wantEntry != null && Math.round(r.entryPriceCents ?? NaN) !== wantEntry) continue;
    const isClose = r.event === "close"
      || r.outcome === "win"
      || r.outcome === "loss";
    if (!isClose) continue;
    if (r.outcome !== "win" && r.outcome !== "loss") continue;
    if (!isPaperTapeAuthoritativeEarlyClose(r.exitReason ?? null)) continue;
    if (!best || (r.ts ?? 0) >= (best.ts ?? 0)) best = r;
  }
  if (!best) return null;
  const pnl = typeof best.pnlCents === "number" && Number.isFinite(best.pnlCents)
    ? Math.round(best.pnlCents)
    : 0;
  return {
    outcome: best.outcome as "win" | "loss",
    pnlCents: pnl,
    exitReason: String(best.exitReason),
    settledAtMs: typeof best.settledAt === "number" && Number.isFinite(best.settledAt)
      ? best.settledAt
      : (typeof best.ts === "number" && Number.isFinite(best.ts) ? best.ts : null),
    exitPriceCents: typeof best.exitPriceCents === "number" && Number.isFinite(best.exitPriceCents)
      ? best.exitPriceCents
      : null,
    contracts: typeof best.contracts === "number" ? best.contracts : null,
    entryPriceCents: typeof best.entryPriceCents === "number" ? best.entryPriceCents : null,
    side: best.side === "yes" || best.side === "no" ? best.side : null,
  };
}

/**
 * SEV0 mid-trade bounce: unpaired pending fill on paper tape (no later close).
 * Used to rehydrate openTrade after kill mid-trade so PATH_RIDE can continue
 * without STARTUP_RECOVERY wrong-side / ghost day-loss reinjection.
 */
export type PaperTapeOpenPending = {
  ticker: string;
  side: "yes" | "no";
  contracts: number;
  entryPriceCents: number;
  strategyId: string | null;
  openedAtMs: number;
  pathRide?: boolean;
};

/** Max age for an unpaired paper fill to still count as open (15m + buffer). */
export const PAPER_TAPE_OPEN_PENDING_MAX_AGE_MS = 20 * 60 * 1000;

export function lookupPaperTapeOpenPending(
  rows: readonly PaperTradeTapeRow[],
  opts?: { sessionStartTs?: number; nowMs?: number; maxAgeMs?: number },
): PaperTapeOpenPending | null {
  const sessionStart = Math.max(0, Math.round(opts?.sessionStartTs ?? 0));
  const nowMs = typeof opts?.nowMs === "number" && Number.isFinite(opts.nowMs) ? opts.nowMs : Date.now();
  const maxAgeMs = typeof opts?.maxAgeMs === "number" && Number.isFinite(opts.maxAgeMs)
    ? Math.max(0, opts.maxAgeMs)
    : PAPER_TAPE_OPEN_PENDING_MAX_AGE_MS;
  const closes = new Map<string, number>();
  const fills = new Map<string, PaperTradeTapeRow>();
  for (const r of rows) {
    const ts = typeof r.ts === "number" && Number.isFinite(r.ts) ? r.ts : 0;
    if (sessionStart > 0 && ts < sessionStart) continue;
    const isClose = r.event === "close" || (r.outcome != null && r.outcome !== "pending");
    if (isClose) {
      const prev = closes.get(r.ticker) ?? 0;
      if (ts >= prev) closes.set(r.ticker, ts);
      continue;
    }
    if (r.outcome === "pending" || r.event === "fill" || r.event == null) {
      const prev = fills.get(r.ticker);
      if (!prev || ts >= (prev.ts ?? 0)) fills.set(r.ticker, r);
    }
  }
  let best: PaperTradeTapeRow | null = null;
  for (const [ticker, f] of fills) {
    const closeTs = closes.get(ticker);
    if (closeTs != null && closeTs >= (f.ts ?? 0)) continue;
    const age = nowMs - (f.ts ?? 0);
    if (age > maxAgeMs) continue; // days-old unpaired pending must not ghost-hold
    if (!best || (f.ts ?? 0) >= (best.ts ?? 0)) best = f;
  }
  if (!best) return null;
  const side = best.side === "yes" || best.side === "no" ? best.side : null;
  const contracts = Math.round(best.contracts ?? 0);
  const entry = Math.round(best.entryPriceCents ?? 0);
  if (!side || contracts <= 0 || entry <= 0 || !best.ticker) return null;
  return {
    ticker: best.ticker,
    side,
    contracts,
    entryPriceCents: entry,
    strategyId: best.strategyId ?? null,
    openedAtMs: typeof best.ts === "number" && Number.isFinite(best.ts) ? best.ts : Date.now(),
    pathRide: best.pathRide === true || best.exitBook === "PATH_RIDE",
  };
}

/**
 * Pure ledger math for mid-trade bounce proof: open pending cost reduces
 * virtual but must NOT invent settled day loss (pnlCents stays settled-only).
 */
export function paperLedgerOpenCostDoesNotInjectDayLoss(opts: {
  startCents: number;
  settledPnlCents: number;
  openCostCents: number;
  wins: number;
  losses: number;
}): { virtualCents: number; pnlCents: number; dayLossInvented: boolean } {
  const next = paperLedgerFromBotTrades({
    startCents: opts.startCents,
    settledPnlCents: opts.settledPnlCents,
    openCostCents: opts.openCostCents,
    wins: opts.wins,
    losses: opts.losses,
  });
  return {
    virtualCents: next.virtualCents,
    pnlCents: next.pnlCents,
    dayLossInvented: next.pnlCents !== Math.round(opts.settledPnlCents),
  };
}

/**
 * Collapse paper-trades.jsonl fill+close lines into blotter rows for GET /bot/trades.
 * Full history (not session-filtered) — session cash stays on the ledger file.
 * Synthetic negative ids avoid colliding with PG serials. orderId uses paper- prefix
 * so UI isPaperTrade() recognizes rows when isPaper is omitted by older clients.
 */
export type PaperTapeDisplayTrade = {
  id: number;
  ticker: string;
  side: string;
  contracts: number;
  entryPriceCents: number;
  signal: string;
  strategyId: string | null;
  confidence: null;
  outcome: string | null;
  pnlCents: number | null;
  exitReason: string | null;
  exitTheoPrice: null;
  exitMktPrice: number | null;
  createdAt: string;
  orderId: string;
  contractsFilled: number | null;
  entryReason: null;
  exitReasonText: null;
  expectedPnlCents: number | null;
  postmortem: null;
  feeCents: null;
  cancelReason: null;
  fillPriceCents: number | null;
  slippageCents: null;
  orderPlacedAt: string | null;
  filledAt: string | null;
  settledAt: string | null;
  cancelledAt: null;
  balanceBeforeCents: null;
  balanceAfterCents: null;
  contractDurationMins: number | null;
  fillOrigin: string;
  isPaper: true;
  source: "paper-trades.jsonl";
  chartSnapshot?: PaperTradeTapeRow["chartSnapshot"];
  /** Durable PG bot_trades id when the tape row names one (D5 orphan settle / audited rebook). */
  tradeId?: number;
};

function isTapeCloseRow(r: PaperTradeTapeRow): boolean {
  return r.event === "close" || (r.outcome != null && r.outcome !== "pending");
}

function tapeKey(r: Pick<PaperTradeTapeRow, "ticker" | "side">): string {
  return `${r.ticker}|${r.side}`;
}

function synthTapeTradeId(ts: number, ticker: string, side: string): number {
  // Stable negative id in int32-ish range for React keys / story lookup miss.
  let h = 0;
  const s = `${ts}|${ticker}|${side}`;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  return h === 0 ? -1 : (h > 0 ? -h : h);
}

function durationMinsFromTicker(ticker: string): number | null {
  if (/15M/i.test(ticker)) return 15;
  if (/BTCH|1H|60/i.test(ticker)) return 60;
  return null;
}

function rowToDisplay(
  fill: PaperTradeTapeRow,
  close: PaperTradeTapeRow | null,
): PaperTapeDisplayTrade {
  const ts = typeof fill.ts === "number" && Number.isFinite(fill.ts) ? fill.ts : Date.now();
  const settledTs = close?.settledAt ?? (close && typeof close.ts === "number" ? close.ts : null);
  const created = new Date(ts).toISOString();
  const filledIso = created;
  const settledIso = settledTs != null ? new Date(settledTs).toISOString() : null;
  const contracts = Math.max(0, Math.round(fill.contracts ?? close?.contracts ?? 0));
  const entry = Math.max(0, Math.round(fill.entryPriceCents ?? close?.entryPriceCents ?? 0));
  const outcome = close?.outcome ?? fill.outcome ?? "pending";
  const exitPx = close?.exitPriceCents ?? null;
  return {
    id: synthTapeTradeId(ts, fill.ticker, fill.side),
    ticker: fill.ticker,
    side: fill.side,
    contracts,
    entryPriceCents: entry,
    signal: fill.side === "no" ? "SHORT" : "LONG",
    strategyId: fill.strategyId ?? close?.strategyId ?? null,
    confidence: null,
    outcome: outcome ?? null,
    pnlCents: typeof close?.pnlCents === "number" ? Math.round(close.pnlCents) : (typeof fill.pnlCents === "number" ? Math.round(fill.pnlCents) : null),
    exitReason: close?.exitReason ?? fill.exitReason ?? null,
    exitTheoPrice: null,
    exitMktPrice: exitPx != null ? Math.round(exitPx) : null,
    createdAt: created,
    orderId: `paper-tape-${ts}-${fill.ticker}`,
    contractsFilled: contracts > 0 ? contracts : null,
    entryReason: null,
    exitReasonText: null,
    expectedPnlCents: typeof (close?.evCents ?? fill.evCents) === "number"
      ? Math.round((close?.evCents ?? fill.evCents) as number)
      : null,
    postmortem: null,
    feeCents: null,
    cancelReason: null,
    fillPriceCents: typeof fill.fillAsk === "number" ? Math.round(fill.fillAsk) : entry,
    slippageCents: null,
    orderPlacedAt: filledIso,
    filledAt: filledIso,
    settledAt: settledIso,
    cancelledAt: null,
    balanceBeforeCents: null,
    balanceAfterCents: null,
    contractDurationMins: durationMinsFromTicker(fill.ticker),
    fillOrigin: fill.fillOrigin ?? close?.fillOrigin ?? "bot",
    isPaper: true,
    source: "paper-trades.jsonl",
    ...(typeof (close?.tradeId ?? fill.tradeId) === "number" ? { tradeId: (close?.tradeId ?? fill.tradeId) as number } : {}),
    chartSnapshot: close?.chartSnapshot ?? fill.chartSnapshot ?? null,
  };
}

/**
 * Prefer an early-exit / PATH_RIDE close over a later SETTLEMENT ghost for the
 * same fill. Spam PATH_RIDE_TP lines (persist-fail KEEP loop) collapse to one.
 */
export function selectBestTapeClose(closes: PaperTradeTapeRow[]): PaperTradeTapeRow | null {
  if (!closes.length) return null;
  // R2 (trade #72) — a 0-pnl void close is superseded by a later Kalshi-result
  // settlement of the same fill (D5 ORPHAN_SETTLED_KALSHI, incl. audited
  // corrections). Voids erased real losses; the official result wins.
  const kalshiSettled = closes.filter((c) => c.exitReason === "ORPHAN_SETTLED_KALSHI" && (c.outcome === "win" || c.outcome === "loss"));
  if (kalshiSettled.length > 0) {
    const nonVoid = closes.filter((c) => c.outcome !== "cancelled" && c.outcome !== "void");
    closes = nonVoid;
  }
  // SEV0 (sweep S2/S1): an early close stamped at/after the contract closed is
  // a phantom (priced off the NEXT contract's book). Prefer any other close.
  const notPhantom = closes.filter((c) => !isPostCloseEarlyExit(c));
  if (notPhantom.length > 0) closes = notPhantom;
  const early = closes.filter((c) => isPaperTapeAuthoritativeEarlyClose(c.exitReason));
  const pool = early.length > 0 ? early : closes;
  // Earliest authoritative close wins (first real exit).
  return [...pool].sort((a, b) => (a.ts ?? 0) - (b.ts ?? 0))[0] ?? null;
}

/**
 * Pair chronological fill → best close (same ticker+side). Unpaired fills stay
 * pending. Orphan close spam after a settled fill is dropped (ghost fix).
 * Newest-first display order.
 */
export function paperTapeToDisplayTrades(rows: PaperTradeTapeRow[]): PaperTapeDisplayTrade[] {
  const chrono = [...rows].sort((a, b) => (a.ts ?? 0) - (b.ts ?? 0));
  const opens = new Map<string, PaperTradeTapeRow[]>();
  const pendingCloses = new Map<string, PaperTradeTapeRow[]>();
  const out: PaperTapeDisplayTrade[] = [];
  const settledKeys = new Set<string>();

  const flushClose = (key: string, close: PaperTradeTapeRow) => {
    const q = opens.get(key);
    const fill = q && q.length > 0 ? q.shift()! : null;
    if (fill) {
      out.push(rowToDisplay(fill, close));
      settledKeys.add(key);
      return;
    }
    // Orphan close: emit once per ticker|side only when nothing settled yet.
    if (settledKeys.has(key)) return;
    out.push(rowToDisplay({ ...close, outcome: "pending", event: "fill" }, close));
    settledKeys.add(key);
  };

  const finalizeKey = (key: string) => {
    const buf = pendingCloses.get(key) ?? [];
    if (buf.length === 0) return;
    const best = selectBestTapeClose(buf);
    if (best) flushClose(key, best);
    pendingCloses.set(key, []);
  };

  for (const r of chrono) {
    if (!r?.ticker || r.isPaper !== true) continue;
    const key = tapeKey(r);
    if (isTapeCloseRow(r)) {
      // Buffer closes until the next fill (or end) so PATH_RIDE can beat an
      // earlier SETTLEMENT ghost on the same fill, and spam collapses to one.
      const buf = pendingCloses.get(key) ?? [];
      buf.push(r);
      pendingCloses.set(key, buf);
    } else {
      finalizeKey(key);
      const q = opens.get(key) ?? [];
      q.push(r);
      opens.set(key, q);
      // Re-entry on same ticker|side after a settle is a new book row.
      settledKeys.delete(key);
    }
  }
  for (const key of new Set([...pendingCloses.keys(), ...opens.keys()])) {
    finalizeKey(key);
  }
  for (const q of opens.values()) {
    for (const fill of q) out.push(rowToDisplay(fill, null));
  }
  out.sort((a, b) => {
    const ta = Date.parse(a.createdAt) || 0;
    const tb = Date.parse(b.createdAt) || 0;
    return tb - ta;
  });
  return out;
}

/**
 * Dedupe key for paper blotter merge (PG ↔ paper-trades.jsonl).
 * Prefer orderId timestamps (`paper-<ms>` / `paper-tape-<ms>-…`) so fill+PG match.
 */
export function paperTradeDedupeKey(t: {
  orderId?: string | null;
  ticker?: string | null;
  side?: string | null;
  entryPriceCents?: number | null;
  createdAt?: string | Date | null;
}): string {
  const orderId = typeof t.orderId === "string" ? t.orderId : "";
  const ticker = String(t.ticker ?? "");
  const side = String(t.side ?? "");
  const m = /^paper-(?:tape-)?(\d+)/.exec(orderId);
  // PG orderId ms and jsonl fill ts often differ by a few ms — bucket to 5s.
  // Do NOT key on entryPriceCents: PG quoted entry vs tape fillAsk often differ
  // by 1–3¢ and used to leave ghost negative-id tape rows beside the PG fill.
  if (m) {
    const bucket = Math.floor(Number(m[1]) / 5000);
    return `tb:${ticker}|${side}|${bucket}`;
  }
  const createdRaw = t.createdAt;
  const createdMs =
    createdRaw instanceof Date
      ? createdRaw.getTime()
      : Date.parse(String(createdRaw ?? "")) || 0;
  return `tb:${ticker}|${side}|${Math.floor(createdMs / 5000)}`;
}

export type MergedTradesDisplay = {
  trades: Record<string, unknown>[];
  total: number;
  paperTotal: number;
  source: "pg" | "paper-trades.jsonl" | "pg+paper-trades.jsonl";
};

/**
 * Safe read-merge for GET /bot/trades display.
 * Prefer PG rows when they collide with tape (richer fields / real serial ids).
 * Does not write to PG — avoids unique-index races on paper pending tickers.
 */
export function mergePgAndPaperTapeForDisplay(opts: {
  pgTrades: Record<string, unknown>[];
  tapeTrades: PaperTapeDisplayTrade[];
}): MergedTradesDisplay {
  const pg = opts.pgTrades ?? [];
  const tape = opts.tapeTrades ?? [];
  const livePg = pg.filter((t) => !((t as { isPaper?: boolean; orderId?: string }).isPaper === true
    || (typeof (t as { orderId?: string }).orderId === "string"
      && String((t as { orderId?: string }).orderId).startsWith("paper-"))));
  const paperPg = pg.filter((t) => (t as { isPaper?: boolean; orderId?: string }).isPaper === true
    || (typeof (t as { orderId?: string }).orderId === "string"
      && String((t as { orderId?: string }).orderId).startsWith("paper-")));

  const byKey = new Map<string, Record<string, unknown>>();
  for (const t of paperPg) {
    byKey.set(paperTradeDedupeKey(t as Parameters<typeof paperTradeDedupeKey>[0]), t);
  }
  let tapeOnly = 0;
  // R4 (#72 phantom) — a tape row that names a durable PG trade id (D5 orphan
  // settle / audited rebook close, written at settle time — days after the PG
  // fill, so no ts bucket or 15m fingerprint can pair them) IS that PG trade.
  // PG is authoritative; the tape row never becomes a second trade.
  const paperPgIds = new Set<number>();
  for (const t of paperPg) {
    const id = (t as { id?: unknown }).id;
    if (typeof id === "number" && id > 0) paperPgIds.add(id);
  }
  for (const t of tape) {
    if (typeof t.tradeId === "number" && paperPgIds.has(t.tradeId)) continue;
    const k = paperTradeDedupeKey(t);
    const existing = byKey.get(k);
    if (!existing) {
      byKey.set(k, t as unknown as Record<string, unknown>);
      tapeOnly += 1;
    } else if (
      t.chartSnapshot
      && !(existing as { chartSnapshot?: unknown }).chartSnapshot
    ) {
      // Prefer PG row identity but keep tape chart snapshot when PG lacks one.
      byKey.set(k, { ...existing, chartSnapshot: t.chartSnapshot });
    }
  }
  // Void pass: a tape orphan-close row ("cancelled", written when a PG pending
  // was voided) carries the VOID timestamp, not the fill time, so its orderId
  // bucket never matches the PG fill. Drop it when a PG paper row for the same
  // ticker|side is already cancelled within 15m of the tape close — otherwise
  // one voided fill shows as two trades and double-counts contracts.
  const pgCancelled = paperPg.filter((t) => t.outcome === "cancelled");
  if (pgCancelled.length > 0) {
    const tsOf = (v: unknown): number => {
      if (v instanceof Date) return v.getTime();
      const n = Date.parse(String(v ?? ""));
      return Number.isFinite(n) ? n : 0;
    };
    for (const [k, t] of [...byKey.entries()]) {
      if (t.source !== "paper-trades.jsonl" || t.outcome !== "cancelled") continue;
      const tapeTs = tsOf(t.settledAt) || tsOf(t.createdAt);
      const twin = pgCancelled.find((p) =>
        String(p.ticker ?? "") === String(t.ticker ?? "")
        && String(p.side ?? "") === String(t.side ?? "")
        && Math.abs((tsOf(p.cancelledAt) || tsOf(p.settledAt)) - tapeTs) <= 15 * 60_000,
      );
      if (twin) {
        byKey.delete(k);
        tapeOnly = Math.max(0, tapeOnly - 1);
      }
    }
  }
  // Second pass: same ticker|side|outcome|pnl within 15m → keep PG (orderId
  // buckets miss when fill ts and paper-<ms> drift by minutes on recovery).
  const finger = (t: Record<string, unknown>): string | null => {
    const outcome = t.outcome;
    if (outcome !== "win" && outcome !== "loss") return null;
    const pnl = typeof t.pnlCents === "number" ? Math.round(t.pnlCents) : null;
    if (pnl == null) return null;
    return `${String(t.ticker ?? "")}|${String(t.side ?? "")}|${outcome}|${pnl}`;
  };
  const createdMs = (t: Record<string, unknown>) =>
    Date.parse(String(t.createdAt ?? "")) || 0;
  const byFinger = new Map<string, Record<string, unknown>>();
  for (const t of byKey.values()) {
    const f = finger(t);
    if (!f) {
      byFinger.set(`id:${String(t.id ?? Math.random())}`, t);
      continue;
    }
    const prev = byFinger.get(f);
    if (!prev) {
      byFinger.set(f, t);
      continue;
    }
    const dt = Math.abs(createdMs(t) - createdMs(prev));
    if (dt > 15 * 60_000) {
      byFinger.set(`id:${String(t.id ?? Math.random())}`, t);
      continue;
    }
    const prefer =
      typeof t.id === "number" && t.id > 0
        ? t
        : typeof prev.id === "number" && prev.id > 0
          ? prev
          : createdMs(t) >= createdMs(prev) ? t : prev;
    byFinger.set(f, prefer);
  }

  const paperMerged = [...byFinger.values()].sort((a, b) => {
    const ta = Date.parse(String((a as { createdAt?: string }).createdAt ?? "")) || 0;
    const tb = Date.parse(String((b as { createdAt?: string }).createdAt ?? "")) || 0;
    return tb - ta;
  });
  const merged = [...paperMerged, ...livePg].sort((a, b) => {
    const ta = Date.parse(String((a as { createdAt?: string }).createdAt ?? "")) || 0;
    const tb = Date.parse(String((b as { createdAt?: string }).createdAt ?? "")) || 0;
    return tb - ta;
  });

  let source: MergedTradesDisplay["source"] = "pg";
  if (paperPg.length > 0 && (tape.length > 0 && tapeOnly > 0)) source = "pg+paper-trades.jsonl";
  else if (paperPg.length === 0 && tape.length > 0) source = "paper-trades.jsonl";
  else if (paperPg.length > 0 && tape.length === 0) source = "pg";
  else if (paperPg.length > 0 && tapeOnly === 0) source = "pg";
  else if (tape.length > 0) source = "paper-trades.jsonl";

  return {
    trades: merged,
    total: merged.length,
    paperTotal: paperMerged.length,
    source,
  };
}

export type StrategyStatsAggRow = {
  strategyId: string;
  trades: number;
  wins: number;
  totalPnlCents: number;
};

/**
 * Per-strategy aggregates from a blotter read-merge (PG ∪ paper-trades.jsonl).
 * Same filters as GET /bot/strategy-stats PG path: settled win/loss, bot fills,
 * exclude MANUAL. Prevents performance cards from undercounting vs blotter when
 * tape has settled rows not yet (or never) INSERTed into bot_trades.
 */
export function aggregateStrategyStatsFromMergedTrades(
  trades: Array<Record<string, unknown>>,
): StrategyStatsAggRow[] {
  const map = new Map<string, StrategyStatsAggRow>();
  for (const t of trades) {
    const outcome = t.outcome;
    if (outcome !== "win" && outcome !== "loss") continue;
    const strategyId = typeof t.strategyId === "string" ? t.strategyId : null;
    if (strategyId == null || strategyId === "") continue;
    if (strategyId === MANUAL_STRATEGY_ID) continue;
    const fillOrigin =
      typeof t.fillOrigin === "string"
        ? t.fillOrigin
        : t.fillOrigin == null
          ? null
          : String(t.fillOrigin);
    if (!includeInBotWinRate(fillOrigin, strategyId)) continue;
    const row = map.get(strategyId) ?? {
      strategyId,
      trades: 0,
      wins: 0,
      totalPnlCents: 0,
    };
    row.trades += 1;
    if (outcome === "win") row.wins += 1;
    const pnl = typeof t.pnlCents === "number" && Number.isFinite(t.pnlCents) ? Math.round(t.pnlCents) : 0;
    row.totalPnlCents += pnl;
    map.set(strategyId, row);
  }
  return [...map.values()].sort((a, b) => b.trades - a.trades || a.strategyId.localeCompare(b.strategyId));
}

/** Convenience: merge PG + tape then aggregate (paperMode performance cards). */
export function strategyStatsFromPgAndTape(opts: {
  pgTrades: Record<string, unknown>[];
  tapeTrades: PaperTapeDisplayTrade[];
}): { rows: StrategyStatsAggRow[]; source: MergedTradesDisplay["source"]; totalMerged: number; settledCounted: number } {
  const merged = mergePgAndPaperTapeForDisplay(opts);
  const rows = aggregateStrategyStatsFromMergedTrades(merged.trades);
  const settledCounted = rows.reduce((s, r) => s + r.trades, 0);
  return { rows, source: merged.source, totalMerged: merged.total, settledCounted };
}



/**
 * Idle-book reconciliation: with no open position, no settled W/L and zero
 * realised P&L, the paper virtual balance MUST equal the starting balance.
 * A voided paper fill (outcome "cancelled", 0 pnl) must release its cost+fee
 * debit. Returns the corrected balance, or null when no correction applies.
 * Never touches Kalshi cash.
 */
export function reconcileIdlePaperLedgerCents(opts: {
  startCents: number;
  virtualCents: number;
  wins: number;
  losses: number;
  pnlCents: number;
  openTradeNull: boolean;
  openCostCents: number;
}): number | null {
  const start = Math.round(opts.startCents);
  if (!Number.isFinite(start) || start <= 0) return null;
  if (!opts.openTradeNull) return null;
  if ((opts.wins ?? 0) + (opts.losses ?? 0) !== 0) return null;
  if (Math.round(opts.pnlCents ?? 0) !== 0) return null;
  if (Math.round(opts.openCostCents ?? 0) !== 0) return null;
  if (Math.round(opts.virtualCents) === start) return null;
  return start;
}


/**
 * GE_013 (safe port) — read-only preflight of the local paper ledger + tape.
 * Detects corrupt / ambiguous history; never repairs or rewrites. The host
 * decides whether to only warn (default) or refuse start (PAPER_RECOVERY_ENFORCE=1).
 */
export function inspectPaperRecovery(startCents: number, ledgerPath?: string, tapePath?: string): import("./ge-legacy-tape-integrity.js").RecoveryInspection {
  const read = (target: string): string | null => {
    try { return fs.readFileSync(target, "utf8"); }
    catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return null; throw error; }
  };
  try {
    return inspectLegacyRecoveryTexts(read(ledgerPath ?? resolvePaperLedgerPath()), read(tapePath ?? resolvePaperTradesPath()), Math.round(startCents));
  } catch {
    return { ok: false, code: "PAPER_RECOVERY_IO_FAILED", rows: 0, ordersAuthorized: false };
  }
}

/**
 * SEV1 (sweep S3): before a restart rehydrates a PG "pending" paper row as an
 * open trade, check whether the tape already booked a close for that fill (a
 * failed settle DB write leaves PG pending while tape + ledger were credited).
 * Match by tradeId when both carry it, else ticker+side+contracts after entry.
 */
export function findTapeCloseForPendingFill(
  rows: readonly PaperTradeTapeRow[],
  fill: { tradeId?: number | null; ticker: string; side?: string | null; contracts?: number | null; openedAtMs?: number | null },
): PaperTradeTapeRow | null {
  const matches = rows.filter((r) => {
    if (r.outcome !== "win" && r.outcome !== "loss") return false;
    if (r.event != null && r.event !== "close") return false;
    if (typeof fill.tradeId === "number" && typeof r.tradeId === "number") return r.tradeId === fill.tradeId;
    if (r.ticker !== fill.ticker) return false;
    if (fill.side && r.side && r.side !== fill.side) return false;
    if (typeof fill.contracts === "number" && typeof r.contracts === "number" && Math.round(r.contracts) !== Math.round(fill.contracts)) return false;
    if (typeof fill.openedAtMs === "number" && typeof r.ts === "number" && r.ts < fill.openedAtMs - 5_000) return false;
    return true;
  });
  return selectBestTapeClose(matches);
}

/**
 * Paper sizing bankroll. virtualCents is already net of the reserve lock, so
 * the reserve pool must NOT be subtracted again (sweep S4 double count).
 */
export function paperEffectiveBalanceCents(virtualCents: number): number {
  return Math.round(virtualCents);
}


/** America/New_York calendar day (YYYY-MM-DD) for an epoch-ms instant. */
function etDayKeyForMs(ms: number): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/New_York", year: "numeric", month: "2-digit", day: "2-digit",
  }).format(new Date(ms));
}

/**
 * Daily-loss-halt seed for the paper desk (Stellar 2026-09-26: paper halts like
 * live). Sum of fee-net realized P&L of BOT-origin paper trades whose close
 * (settledAt) falls on the given ET day. Same basis as live todayStats
 * (bot fills only, fee-net, ET midnight boundary). Manual fills never count.
 * Used to re-seed todayStats after a restart so a bounce cannot clear the halt.
 */
export function paperBotDayPnlFromTape(
  rows: PaperTradeTapeRow[],
  etDayKey: string,
  sessionStartTs = 0,
): { pnlCents: number; wins: number; losses: number } {
  const sessionStart = Math.max(0, Math.round(sessionStartTs || 0));
  const session = rows.filter((r) => {
    const ts = typeof r.ts === "number" && Number.isFinite(r.ts) ? r.ts : 0;
    return sessionStart <= 0 || ts >= sessionStart;
  });
  let pnlCents = 0;
  let wins = 0;
  let losses = 0;
  for (const t of paperTapeToDisplayTrades(session)) {
    if (t.outcome !== "win" && t.outcome !== "loss") continue;
    if ((t.fillOrigin ?? "bot") !== "bot") continue;
    const closedMs = t.settledAt ? Date.parse(t.settledAt) : NaN;
    if (!Number.isFinite(closedMs) || etDayKeyForMs(closedMs) !== etDayKey) continue;
    pnlCents += typeof t.pnlCents === "number" && Number.isFinite(t.pnlCents) ? Math.round(t.pnlCents) : 0;
    if (t.outcome === "win") wins++; else losses++;
  }
  return { pnlCents, wins, losses };
}
