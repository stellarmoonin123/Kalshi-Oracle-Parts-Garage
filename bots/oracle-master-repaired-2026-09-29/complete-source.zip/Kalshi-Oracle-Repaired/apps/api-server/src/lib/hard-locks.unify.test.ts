/**
 * Unify-branch hard-lock guard (2026-09-24). These must NEVER be weakened:
 *   paperMode stays true · EV floor ≥ 3¢ (OTM 5¢) · Kelly cap ≤ 0.60 ·
 *   ask band 20–55¢ · 15% reserve · 9% per trade / 18% daily halt ·
 *   no engine ENABLE · no LLM on tick/fill · soft CC_VEL stays soft.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { sanitizeConfigPatch, PAPER_ONLY_DESK, PATCH_REFUSE_FLOOR_KEYS } from "./config-patch-surface.js";
import { applyComposerLocks } from "./composer-lock.js";
import { normalizePersistedConfig, loadPersistedConfig } from "./config-persist.js";
import { EV_FLOOR, OTM_EV_FLOOR, HARD_RISK_LIMITS, kellyLambdaFromNetEV, kellyFraction } from "./admission.js";
import * as kernel from "./risk-kernel.js";
import { FROZEN_CC_ASK_MIN, FROZEN_CC_ASK_MAX } from "./frozen-cc.js";
import { AGENT_FLOORS } from "./agent-control.js";
import { ccVelocityAgainstGate } from "./cc-velocity-gate.js";

const HERE = path.dirname(new URL(import.meta.url).pathname);
const read = (f: string) => fs.readFileSync(path.join(HERE, f), "utf8");

test("paperMode: paper-only constant is on", () => {
  assert.equal(PAPER_ONLY_DESK, true);
});

test("paperMode: no patch value other than true is accepted, phrase or not", () => {
  for (const v of [false, 0, null, "", "false", "0", undefined, {}]) {
    for (const phrase of [undefined, "LIVE REAL MONEY"]) {
      const r = sanitizeConfigPatch({ paperMode: v, ...(phrase ? { confirmLiveRealMoney: phrase } : {}) });
      assert.equal("paperMode" in r.accepted, false, `paperMode=${JSON.stringify(v)} phrase=${phrase}`);
    }
  }
  assert.equal(sanitizeConfigPatch({ paperMode: true }).accepted.paperMode, true);
});

test("paperMode: composer lock coerces every non-true value back to paper", () => {
  const base = { autoMode: false, autoModeV2Mode: "off" as const, useExpertAgent: false, ariaModel: "", paperMode: true };
  for (const v of [false, 0, null, "false", undefined]) {
    const r = applyComposerLocks({ ...base, paperMode: v as unknown as boolean }, { confirmLiveRealMoney: "LIVE REAL MONEY" });
    assert.equal(r.config.paperMode, true);
  }
});

test("paperMode: a .bot-config overlay with paperMode false boots paper", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "botcfg-"));
  const p = path.join(dir, ".bot-config.json");
  fs.writeFileSync(p, JSON.stringify({ paperMode: false, enabled: true, confirmLiveRealMoney: "LIVE REAL MONEY" }));
  const loaded = loadPersistedConfig(p);
  assert.notEqual(loaded.paperMode, false);
  const norm = normalizePersistedConfig({ paperMode: false } as never);
  assert.equal(norm.paperMode, true);
  fs.rmSync(dir, { recursive: true, force: true });
});

test("EV floors: standard ≥ 3¢, OTM ≥ 5¢ (admission and risk-kernel agree)", () => {
  assert.ok(EV_FLOOR >= 3); assert.equal(EV_FLOOR, 3);
  assert.ok(OTM_EV_FLOOR >= 5);
  assert.equal(kernel.EV_FLOOR, EV_FLOOR);
  assert.equal(kernel.OTM_EV_FLOOR, OTM_EV_FLOOR);
  assert.equal(kellyLambdaFromNetEV(2.99), 0, "below EV floor sizes zero");
});

test("Kelly cap ≤ 0.60 everywhere", () => {
  for (const ev of [3, 5, 8, 20, 99, 1e9]) assert.ok(kellyLambdaFromNetEV(ev) <= 0.60);
  for (const c of [0, 50, 80, 100, 1000]) for (const e of [0, 3, 8, 50, 1000]) assert.ok(kellyFraction(c, e) <= 0.60);
  assert.ok(kernel.FRACTIONAL_KELLY_CAP <= 0.60);
  assert.ok(AGENT_FLOORS.kellyCap <= 0.60);
});

test("per-trade 9% / daily 18% caps unchanged", () => {
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(HARD_RISK_LIMITS.maxDailyLossPct, 0.18);
  assert.equal(kernel.HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(kernel.HARD_RISK_LIMITS.maxDailyLossPct, 0.18);
  for (const k of ["maxRiskPctPerTrade", "maxDailyLossPct", "kellyCap", "EV_FLOOR"]) {
    assert.ok((PATCH_REFUSE_FLOOR_KEYS as readonly string[]).includes(k), k);
    assert.equal(k in sanitizeConfigPatch({ [k]: 1 }).accepted, false, k);
  }
});

test("ask band 20–55¢", () => {
  assert.equal(FROZEN_CC_ASK_MIN, 20);
  assert.equal(FROZEN_CC_ASK_MAX, 55);
  assert.equal(AGENT_FLOORS.askMinCents, 20);
  assert.equal(AGENT_FLOORS.askMaxCents, 55);
});

test("15% reserve floor: patch below 15 refused; default 15", () => {
  assert.equal("reservePct" in sanitizeConfigPatch({ reservePct: 10 }).accepted, false);
  assert.equal(AGENT_FLOORS.reservePctFloor, 15);
  assert.match(read("trading-bot.ts"), /reservePct:\s+15,/);
});

test("no engine ENABLE: hourly live / leftovers stay refused via patch", () => {
  const r = sanitizeConfigPatch({ enable1HLive: true, confirmLiveRealMoney: "LIVE REAL MONEY" });
  assert.equal("enable1HLive" in r.accepted, false);
  const src = ["trading-bot.ts", "admission.ts", "config-patch-surface.ts"].map(read).join("\n");
  assert.doesNotMatch(src.replace(/\/\/.*$/gm, ""), /\bENABLE_(SEV1|OTM|HOURLY|PERPS|LEFTOVER)\s*=\s*true/);
});

test("no LLM on tick/fill: settlement predictor AI runs on its own 90s loop; trading tick has no aiComplete", () => {
  const bot = read("trading-bot.ts");
  assert.doesNotMatch(bot, /\baiComplete(JSON)?\s*\(/, "trading-bot must not call an LLM");
  assert.doesNotMatch(read("kalshi-ws.ts"), /\baiComplete(JSON)?\s*\(/);
});

test("soft CC_VEL stays soft: gate is pure and trading-bot records it as advisory", () => {
  assert.deepEqual(ccVelocityAgainstGate({ strategyId: "CONFLUENCE_CASCADE", side: "no", velocityDolPerMin: null }), { block: false });
  const bot = read("trading-bot.ts");
  assert.match(bot, /Soft CC_VEL alone does NOT hard-gate/);
  assert.match(bot, /ccVelocityWouldBlock/);
});
