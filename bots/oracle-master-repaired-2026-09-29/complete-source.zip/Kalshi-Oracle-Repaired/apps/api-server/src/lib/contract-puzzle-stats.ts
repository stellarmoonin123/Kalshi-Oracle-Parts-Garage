/**
 * contract-puzzle-stats.ts
 *
 * PhD-level (honest, small-n) stats over contract-puzzles.jsonl.
 * Surfaces +EV take cells (persist-cheap / lag-agree / moving-ticket) as
 * OBSERVE → fee-net candidates. Skip-correct rates are one axis, not the
 * only outcome — starving fills is a failed desk.
 *
 * Numbers only from tape. Do NOT claim 9/10 P&L.
 * Never ENABLE. Never CHANGE_EV_FLOOR. Never paperMode false.
 * Skip puzzles do not write bot-fill weights (0.72–1.18x stays on fills).
 */
import fs from "node:fs";
import path from "node:path";
import {
  LIVE_APPLY_ENABLED,
  PUZZLE_KELLY_F,
  classifyTakeCells,
  inferLagClass,
  type AskBand,
  type ContractPuzzle,
  type LagClass,
  type PuzzleSide,
  type TakeCellId,
  logGrowthFromFeeNet,
  puzzleAlreadyRecorded,
  puzzleJsonlPath,
  readPuzzleJsonl,
  rememberPuzzleSkip,
  rememberPuzzleTake,
  recordPuzzleOnSettlement,
} from "./contract-puzzle.js";
import { computeEarlyExit, loadTapeQuotes, UNKNOWN_HTF_SUMMARY } from "./tick-tape-labels.js";
import { researchDir, researchPath } from "./desk-data-dir.js";

export const STATS_NOTE =
  "numbers only from tape; do not claim 9/10 P&L; OBSERVE only; skip puzzles do not update bot-fill weights (0.72–1.18x)";

export interface RateCI {
  n: number;
  successes: number;
  mean: number | null;
  lo: number | null;
  hi: number | null;
}

export interface CellG {
  n: number;
  meanG: number | null;
  meanFeeNetCents: number | null;
  thin: boolean;
  note: string;
}

export interface PlusEvTakeCell {
  cell: TakeCellId;
  n: number;
  takeCorrect: RateCI;
  skipCorrect: RateCI;
  sideCorrect: RateCI;
  meanFeeNetVsSkipCents: number | null;
  meanEarlyExitPnLCents: number | null;
  geometric: CellG;
  observeCandidate: boolean;
  enable: false;
  liveApplyEnabled: false;
  note: string;
}

export interface PuzzleStats {
  n: number;
  nTake: number;
  nSkip: number;
  skipQuality: {
    overall: RateCI;
    byReason: Record<string, RateCI>;
  };
  sideAccuracy: {
    taken: RateCI;
    skippedWouldHave: RateCI;
  };
  takeCorrect: RateCI;
  skipCorrect: RateCI;
  contingency: {
    stillMid: Record<string, RateCI>;
    lag: Record<string, RateCI>;
    htfBias: Record<string, RateCI>;
    earlyExit: {
      nWithMfe: number;
      meanMfeCents: number | null;
      meanPnLAtMfeCents: number | null;
      nGreenX: number;
      meanPnLAtGreenXCents: number | null;
      nSettleWrongEarlyWin: number;
    };
    askBandG: Record<string, CellG>;
  };
  geometric: {
    kellyF: typeof PUZZLE_KELLY_F;
    formula: string;
    actualSkip: CellG;
    actualTake: CellG;
    counterfactualWouldTake: CellG;
  };
  plusEvTakeCells: PlusEvTakeCell[];
  liveApplyEnabled: false;
  paperMode: true;
  updatedAt: string;
  note: string;
}

export interface PuzzleStatsSummary {
  n: number;
  nTake: number;
  nSkip: number;
  skipCorrect: RateCI;
  takeCorrect: RateCI;
  sideAccuracyTaken: RateCI;
  plusEvTakeCells: Array<{
    cell: TakeCellId;
    n: number;
    meanFeeNetVsSkipCents: number | null;
    meanEarlyExitPnLCents: number | null;
    takeCorrectMean: number | null;
    observe: boolean;
  }>;
  updatedAt: string;
  liveApplyEnabled: false;
  note: string;
}

const THIN_N = 5;
const OBSERVE_MIN_N = 3;

function researchRoot(): string {
  return researchDir();
}

export function statsJsonPath(): string {
  return process.env.CONTRACT_PUZZLE_STATS_PATH
    ?? path.join(researchRoot(), "contract-puzzle-stats.json");
}

export function statsMdPath(): string {
  return process.env.CONTRACT_PUZZLE_STATS_MD_PATH
    ?? path.join(researchRoot(), "contract-puzzle-stats.md");
}

export function shadowLearnPath(): string {
  return path.join(researchRoot(), "shadow-learn.json");
}

export function strategyProposalsPath(): string {
  return path.join(researchRoot(), "strategy-proposals.md");
}

/**
 * Wilson score interval (z=1.96). Full lo/hi, not just lower bound.
 * Same center/margin shape as strategy-performance.wilsonLowerBound.
 */
export function wilsonInterval(successes: number, n: number, z = 1.96): RateCI {
  if (n <= 0) return { n: 0, successes: 0, mean: null, lo: null, hi: null };
  const p = successes / n;
  const z2 = z * z;
  const denom = 1 + z2 / n;
  const center = p + z2 / (2 * n);
  const margin = z * Math.sqrt((p * (1 - p) + z2 / (4 * n)) / n);
  return {
    n,
    successes,
    mean: p,
    lo: (center - margin) / denom,
    hi: (center + margin) / denom,
  };
}

function rateFromBools(flags: Array<boolean | null | undefined>): RateCI {
  const known = flags.filter((x): x is boolean => x === true || x === false);
  const successes = known.filter(x => x).length;
  return wilsonInterval(successes, known.length);
}

function mean(xs: number[]): number | null {
  if (xs.length === 0) return null;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function cellG(feeNets: number[], asks: number[], nMark: number, note: string): CellG {
  const gs: number[] = [];
  for (let i = 0; i < feeNets.length; i++) {
    const ask = asks[i];
    const fn = feeNets[i];
    if (ask == null || fn == null || !(ask > 0)) continue;
    const g = logGrowthFromFeeNet(ask, fn);
    if (g == null) continue;
    if (!Number.isFinite(g)) continue; // drop -Inf ruin from the mean; mark n
    gs.push(g);
  }
  return {
    n: nMark,
    meanG: mean(gs),
    meanFeeNetCents: mean(feeNets),
    thin: nMark < THIN_N,
    note,
  };
}

function stillKey(p: ContractPuzzle): string {
  const motion = p.features.ticketMotion;
  const mid = p.features.askBand === "mid_40_65";
  if (mid && motion === "still") return "still-mid";
  if (mid && motion === "moving") return "moving-mid";
  if (mid) return "mid-unknown-motion";
  if (motion === "still") return "still-not-mid";
  if (motion === "moving") return "moving-not-mid";
  return "other";
}

function takeCorrectFlag(p: ContractPuzzle): boolean | null {
  if (p.labels.earlyExitCorrect === true) return true;
  return p.labels.takeCorrect;
}

export function aggregatePuzzles(rows: ContractPuzzle[]): PuzzleStats {
  const puzzles = rows.filter(r => r && r.kind === "contract_puzzle" && (r.settled === "YES" || r.settled === "NO"));
  const takes = puzzles.filter(p => p.botAction === "TAKE");
  const skips = puzzles.filter(p => p.botAction === "SKIP");

  const byReason: Record<string, boolean[]> = {};
  for (const p of skips) {
    const codes = p.skip?.reasonCodes ?? [];
    const flag = p.labels.skipCorrect;
    const use = codes.length > 0 ? codes : ["UNKNOWN"];
    for (const c of use) {
      (byReason[c] ??= []).push(flag as boolean);
    }
  }
  const byReasonCI: Record<string, RateCI> = {};
  for (const [k, flags] of Object.entries(byReason)) {
    byReasonCI[k] = rateFromBools(flags);
  }

  const stillMid: Record<string, RateCI> = {};
  const stillBuckets = new Map<string, boolean[]>();
  for (const p of puzzles) {
    const k = stillKey(p);
    (stillBuckets.get(k) ?? (stillBuckets.set(k, []), stillBuckets.get(k)!)).push(p.labels.takeCorrect as boolean);
  }
  for (const [k, flags] of stillBuckets) stillMid[k] = rateFromBools(flags);

  const lag: Record<string, RateCI> = {};
  const lagBuckets = new Map<LagClass, boolean[]>();
  for (const p of puzzles) {
    const k = (p.features?.lagClass ?? "unknown") as LagClass;
    (lagBuckets.get(k) ?? (lagBuckets.set(k, []), lagBuckets.get(k)!)).push(p.labels.takeCorrect as boolean);
  }
  for (const [k, flags] of lagBuckets) lag[k] = rateFromBools(flags);

  const htfBias: Record<string, RateCI> = {};
  const htfBuckets = new Map<string, boolean[]>();
  for (const p of puzzles) {
    const k = p.features?.htfStructure?.biasFor15m ?? "UNKNOWN";
    (htfBuckets.get(k) ?? (htfBuckets.set(k, []), htfBuckets.get(k)!)).push(p.labels.takeCorrect as boolean);
  }
  for (const [k, flags] of htfBuckets) htfBias[k] = rateFromBools(flags);

  const mfeVals: number[] = [];
  const mfePnls: number[] = [];
  const greenPnls: number[] = [];
  let nSettleWrongEarlyWin = 0;
  for (const p of puzzles) {
    const ee = p.earlyExit;
    if (!ee) continue;
    if (ee.maxFavorableExcursionCents != null) mfeVals.push(ee.maxFavorableExcursionCents);
    if (ee.earlyExitPnLAtMfeCents != null) mfePnls.push(ee.earlyExitPnLAtMfeCents);
    if (ee.earlyExitPnLAtGreenXCents != null) greenPnls.push(ee.earlyExitPnLAtGreenXCents);
    if (ee.settleSideCorrect === false && ee.earlyExitPnLAtMfeCents != null && ee.earlyExitPnLAtMfeCents > 0) {
      nSettleWrongEarlyWin += 1;
    }
  }
  const earlyExit = {
    nWithMfe: mfeVals.length,
    meanMfeCents: mean(mfeVals),
    meanPnLAtMfeCents: mean(mfePnls),
    nGreenX: greenPnls.length,
    meanPnLAtGreenXCents: mean(greenPnls),
    nSettleWrongEarlyWin,
  };

  const askBandG: Record<string, CellG> = {};
  const bandFee = new Map<AskBand, { fee: number[]; ask: number[] }>();
  for (const p of puzzles) {
    const fn = p.counterfactual.takeFeeNetCents;
    const ask = p.counterfactual.takeAskCents;
    if (fn == null || ask == null) continue;
    const b = p.features.askBand;
    const slot = bandFee.get(b) ?? { fee: [], ask: [] };
    slot.fee.push(fn);
    slot.ask.push(ask);
    bandFee.set(b, slot);
  }
  for (const [k, slot] of bandFee) {
    askBandG[k] = cellG(slot.fee, slot.ask, slot.fee.length, "counterfactual hold-to-settle G by ask band");
  }

  const TAKE_CELLS: TakeCellId[] = ["persist-cheap", "lag-agree", "moving-ticket", "htf-aligned-cheap", "cheap-early-exit"];
  const plusEvTakeCells: PlusEvTakeCell[] = TAKE_CELLS.map(cell => {
    const members = puzzles.filter(p => (p.features?.takeCells ?? []).includes(cell));
    const fee = members.map(p => p.counterfactual.takeFeeNetCents).filter((x): x is number => x != null);
    const asks = members
      .filter(p => p.counterfactual.takeFeeNetCents != null && p.counterfactual.takeAskCents != null)
      .map(p => p.counterfactual.takeAskCents as number);
    const meanFn = mean(fee);
    const earlyPnls = members
      .map(p => p.earlyExit?.earlyExitPnLAtMfeCents)
      .filter((x): x is number => x != null);
    const meanEarly = mean(earlyPnls);
    const takeCI = rateFromBools(members.map(takeCorrectFlag));
    const geo = cellG(fee, asks, members.length, `counterfactual G for ${cell}; skip G = 0`);
    const beatsSkip = (meanFn != null && meanFn > 0) || (meanEarly != null && meanEarly > 0);
    const observeCandidate = members.length >= OBSERVE_MIN_N && beatsSkip;
    const unlabeled = members.length === 0;
    const note = unlabeled
      ? "no rows in this cell on tape (unlabeled → empty; fail-closed unknown is not agree/HTF-aligned)"
      : observeCandidate
        ? (geo.meanG != null && geo.meanG <= 0 && !(meanEarly != null && meanEarly > 0)
            ? "arithmetic fee-net beat skip but G≤0 — OBSERVE / fee-net replay, not a take license. Not ENABLE."
            : "OBSERVE → fee-net candidate (hold-to-settle OR early-exit beat skip). settleSideCorrect is not required. Not ENABLE.")
        : meanFn != null && meanFn <= 0 && (meanEarly == null || meanEarly <= 0)
          ? "cell did not beat skip on tape (hold or early-exit) — not a take candidate"
          : "thin n — OBSERVE only, no claim";
    return {
      cell,
      n: members.length,
      takeCorrect: takeCI,
      skipCorrect: rateFromBools(members.map(p => p.labels.skipCorrect)),
      sideCorrect: rateFromBools(members.map(p => p.labels.sideCorrect)),
      meanFeeNetVsSkipCents: meanFn,
      meanEarlyExitPnLCents: meanEarly,
      geometric: geo,
      observeCandidate,
      enable: false,
      liveApplyEnabled: false,
      note,
    };
  });

  const takeFees = takes.map(p => p.counterfactual.takeFeeNetCents).filter((x): x is number => x != null);
  const takeAsks = takes
    .filter(p => p.counterfactual.takeFeeNetCents != null && p.counterfactual.takeAskCents != null)
    .map(p => p.counterfactual.takeAskCents as number);
  const wouldFees = puzzles.map(p => p.counterfactual.takeFeeNetCents).filter((x): x is number => x != null);
  const wouldAsks = puzzles
    .filter(p => p.counterfactual.takeFeeNetCents != null && p.counterfactual.takeAskCents != null)
    .map(p => p.counterfactual.takeAskCents as number);

  return {
    n: puzzles.length,
    nTake: takes.length,
    nSkip: skips.length,
    skipQuality: {
      overall: rateFromBools(skips.map(p => p.labels.skipCorrect)),
      byReason: byReasonCI,
    },
    sideAccuracy: {
      taken: rateFromBools(takes.map(p => p.labels.sideCorrect)),
      skippedWouldHave: rateFromBools(skips.map(p => p.labels.sideCorrect)),
    },
    takeCorrect: rateFromBools(puzzles.map(p => p.labels.takeCorrect)),
    skipCorrect: rateFromBools(puzzles.map(p => p.labels.skipCorrect)),
    contingency: { stillMid, lag, htfBias, earlyExit, askBandG },
    geometric: {
      kellyF: PUZZLE_KELLY_F,
      formula: "G=log(1+fX) with f=0.09 (not cut); X=feeNet/stake, stake=ask+takerFee; skip X=0 so G=0",
      actualSkip: {
        n: skips.length,
        meanG: 0,
        meanFeeNetCents: 0,
        thin: skips.length < THIN_N,
        note: "skip PnL is 0 by construction",
      },
      actualTake: cellG(takeFees, takeAsks, takes.length, "hold-to-settle G of bot TAKEs (not dump PnL)"),
      counterfactualWouldTake: cellG(wouldFees, wouldAsks, wouldFees.length, "if every bar took cheap/ATM (or actual take) hold-to-settle"),
    },
    plusEvTakeCells,
    liveApplyEnabled: false,
    paperMode: true,
    updatedAt: new Date().toISOString(),
    note: STATS_NOTE,
  };
}

function pct(x: number | null | undefined): string {
  if (x == null || !Number.isFinite(x)) return "—";
  return `${(x * 100).toFixed(1)}%`;
}

function num(x: number | null | undefined, d = 2): string {
  if (x == null || !Number.isFinite(x)) return "—";
  return x.toFixed(d);
}

export function renderPuzzleStatsMd(stats: PuzzleStats): string {
  const reasons = Object.entries(stats.skipQuality.byReason)
    .sort((a, b) => (b[1].n - a[1].n))
    .map(([k, r]) => `| ${k} | ${r.n} | ${r.successes} | ${pct(r.mean)} | ${pct(r.lo)}–${pct(r.hi)} |`)
    .join("\n");
  const cells = stats.plusEvTakeCells.map(c =>
    `| ${c.cell} | ${c.n} | ${pct(c.takeCorrect.mean)} | ${num(c.meanFeeNetVsSkipCents)} | ${num(c.meanEarlyExitPnLCents)} | ${num(c.geometric.meanG, 4)} | ${c.observeCandidate ? "OBSERVE" : "no"} | false | ${c.note} |`
  ).join("\n");
  const still = Object.entries(stats.contingency.stillMid)
    .map(([k, r]) => `| ${k} | ${r.n} | ${pct(r.mean)} takeCorrect | ${pct(r.lo)}–${pct(r.hi)} |`)
    .join("\n");
  const lag = Object.entries(stats.contingency.lag)
    .map(([k, r]) => `| ${k} | ${r.n} | ${pct(r.mean)} takeCorrect | ${pct(r.lo)}–${pct(r.hi)} |`)
    .join("\n");
  const htfBias = Object.entries(stats.contingency.htfBias ?? {})
    .map(([k, r]) => `| ${k} | ${r.n} | ${pct(r.mean)} takeCorrect | ${pct(r.lo)}–${pct(r.hi)} |`)
    .join("\n");
  const bands = Object.entries(stats.contingency.askBandG)
    .map(([k, g]) => `| ${k} | ${g.n} | ${num(g.meanFeeNetCents)} | ${num(g.meanG, 4)} | ${g.thin ? "thin" : "ok"} |`)
    .join("\n");

  return `# Contract puzzle stats (shadow)

Paper desk. LIVE_APPLY false. paperMode true. Never ENABLE. Never cut EV/Kelly/9%.
Skip puzzles do **not** update bot-fill weights (0.72–1.18x stays on actual fills).
${stats.note}

Updated: ${stats.updatedAt}

## Census

- n = ${stats.n} contracts (TAKE ${stats.nTake} / SKIP ${stats.nSkip})
- takeCorrect (take beat skip on fee-net): ${pct(stats.takeCorrect.mean)} n=${stats.takeCorrect.n}  Wilson ${pct(stats.takeCorrect.lo)}–${pct(stats.takeCorrect.hi)}
- skipCorrect (skip beat take on fee-net): ${pct(stats.skipCorrect.mean)} n=${stats.skipCorrect.n}  Wilson ${pct(stats.skipCorrect.lo)}–${pct(stats.skipCorrect.hi)}
- side accuracy TAKEN: ${pct(stats.sideAccuracy.taken.mean)} n=${stats.sideAccuracy.taken.n}
- side accuracy SKIP would-have: ${pct(stats.sideAccuracy.skippedWouldHave.mean)} n=${stats.sideAccuracy.skippedWouldHave.n}

Stricter = fewer trades is a **failed** sole outcome. takeCorrect / +EV cells are first-class.

## +EV take cells (OBSERVE → fee-net, never ENABLE)

| cell | n | takeCorrect | mean fee-net vs skip (¢) | mean early-exit MFE ¢ | mean G (nats) | observe? | enable | note |
|---|---|---|---|---|---|---|---|---|
${cells || "| (none) | 0 | — | — | — | no | false | |"}

## Skip quality by reason (SKIP rows only)

| reason | n | skipCorrect successes | rate | Wilson 95% |
|---|---|---|---|---|
| ALL_SKIPS | ${stats.skipQuality.overall.n} | ${stats.skipQuality.overall.successes} | ${pct(stats.skipQuality.overall.mean)} | ${pct(stats.skipQuality.overall.lo)}–${pct(stats.skipQuality.overall.hi)} |
${reasons}

## Contingency — still-mid × takeCorrect

| slice | n | takeCorrect | Wilson |
|---|---|---|---|
${still}

## Contingency — lag × takeCorrect

| lag | n | takeCorrect | Wilson |
|---|---|---|---|
${lag}

## Contingency — HTF bias × takeCorrect

| biasFor15m | n | takeCorrect | Wilson |
|---|---|---|---|
${htfBias}

Unlabeled / missing HTF is **UNKNOWN** (fail-closed). UNKNOWN is not HTF-aligned.

## Early-exit (MFE / +20¢ green) — first-class, settle-side not required

- n with MFE = ${stats.contingency.earlyExit.nWithMfe}; mean MFE = ${num(stats.contingency.earlyExit.meanMfeCents)}¢
- mean fee-net sold-at-MFE = ${num(stats.contingency.earlyExit.meanPnLAtMfeCents)}¢
- n that reached +20¢ green = ${stats.contingency.earlyExit.nGreenX}; mean fee-net at +20 = ${num(stats.contingency.earlyExit.meanPnLAtGreenXCents)}¢
- settle-wrong but early-exit WIN = ${stats.contingency.earlyExit.nSettleWrongEarlyWin}

Cheap ask sold green before expiry can be +EV with the **wrong** settlement side. Do not require settleCorrect for a take cell to be +EV.

## Ask band × G (counterfactual hold-to-settle)

| band | n | mean fee-net ¢ | mean G | n flag |
|---|---|---|---|---|
${bands}

## Geometric (honest, n marked)

f = ${stats.geometric.kellyF} (9% cap, not cut). ${stats.geometric.formula}

- actual SKIP: n=${stats.geometric.actualSkip.n} meanG=0 (skip PnL is 0)
- actual TAKE: n=${stats.geometric.actualTake.n} meanG=${num(stats.geometric.actualTake.meanG, 4)} meanFeeNet=${num(stats.geometric.actualTake.meanFeeNetCents)}¢ ${stats.geometric.actualTake.thin ? "(thin)" : ""}
- counterfactual would-take every bar: n=${stats.geometric.counterfactualWouldTake.n} meanG=${num(stats.geometric.counterfactualWouldTake.meanG, 4)} meanFeeNet=${num(stats.geometric.counterfactualWouldTake.meanFeeNetCents)}¢ ${stats.geometric.counterfactualWouldTake.thin ? "(thin)" : ""}

Hold-to-settle, 1 contract, Kalshi taker FEE ORGAN P*(1-P) ceil. No invented dump PnL. No 9/10 P&L claim.

## Teach boundary

jsonl → Oracle → strategy-proposals **OBSERVE** → fee-net replay → bot only after human + proof.
Forbidden: CHANGE_EV_FLOOR, ENABLE_STRATEGY, paperMode false, LIVE_APPLY true.
`;
}

export function statsSummary(stats: PuzzleStats): PuzzleStatsSummary {
  return {
    n: stats.n,
    nTake: stats.nTake,
    nSkip: stats.nSkip,
    skipCorrect: stats.skipCorrect,
    takeCorrect: stats.takeCorrect,
    sideAccuracyTaken: stats.sideAccuracy.taken,
    plusEvTakeCells: stats.plusEvTakeCells.map(c => ({
      cell: c.cell,
      n: c.n,
      meanFeeNetVsSkipCents: c.meanFeeNetVsSkipCents,
      meanEarlyExitPnLCents: c.meanEarlyExitPnLCents,
      takeCorrectMean: c.takeCorrect.mean,
      observe: c.observeCandidate,
    })),
    updatedAt: stats.updatedAt,
    liveApplyEnabled: false,
    note: stats.note,
  };
}

export function writePuzzleStats(stats: PuzzleStats, opts?: { jsonPath?: string; mdPath?: string }): void {
  const jsonFile = opts?.jsonPath ?? statsJsonPath();
  const mdFile = opts?.mdPath ?? statsMdPath();
  fs.mkdirSync(path.dirname(jsonFile), { recursive: true });
  fs.writeFileSync(jsonFile, JSON.stringify(stats, null, 2) + "\n");
  fs.writeFileSync(mdFile, renderPuzzleStatsMd(stats));
}

export function computeAndWritePuzzleStats(jsonlFile?: string): PuzzleStats {
  const rows = readPuzzleJsonl(jsonlFile ?? puzzleJsonlPath());
  const stats = aggregatePuzzles(rows);
  writePuzzleStats(stats);
  return stats;
}

const PUZZLE_MARK_START = "<!-- contract-puzzle-observe -->";
const PUZZLE_MARK_END = "<!-- /contract-puzzle-observe -->";

function observeSection(stats: PuzzleStats): string {
  const cells = stats.plusEvTakeCells
    .filter(c => c.observeCandidate)
    .map(c =>
      `- **${c.cell}** n=${c.n} takeCorrect=${c.takeCorrect.mean == null ? "—" : (c.takeCorrect.mean * 100).toFixed(1)}% meanFeeNetVsSkip=${c.meanFeeNetVsSkipCents?.toFixed(2) ?? "—"}¢ G=${c.geometric.meanG?.toFixed(4) ?? "—"} — OBSERVE, enable=false`
    );
  const body = cells.length > 0
    ? cells.join("\n")
    : "- No +EV take cell beat skip on this tape yet (or n < 3). Do not starve fills by adding skip reasons only.";
  return `${PUZZLE_MARK_START}
## Contract-puzzle OBSERVE (shadow, auto)

OBSERVE only. LIVE_APPLY false. Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR.
Bot-fill weight updates stay on actual bot fills (0.72–1.18x). Skip puzzles rank skip reasons / emit take-cell OBSERVE; they do not write live floors.

Census n=${stats.n} TAKE=${stats.nTake} SKIP=${stats.nSkip}. takeCorrect=${stats.takeCorrect.mean == null ? "—" : (stats.takeCorrect.mean * 100).toFixed(1)}% skipCorrect=${stats.skipCorrect.mean == null ? "—" : (stats.skipCorrect.mean * 100).toFixed(1)}%.

${body}

Path: contract-puzzles.jsonl → Oracle → this OBSERVE → fee-net replay → bot only after human + proof.
${PUZZLE_MARK_END}
`;
}

/**
 * Merge puzzle census into shadow-learn.json. Does not touch
 * cheapSideSettledITM counts or bot-fill weights.
 */
export function teachShadowLearn(stats: PuzzleStats): void {
  const file = shadowLearnPath();
  let existing: Record<string, unknown> = {};
  try {
    existing = JSON.parse(fs.readFileSync(file, "utf8")) as Record<string, unknown>;
  } catch {
    existing = {};
  }
  existing.puzzle = {
    n: stats.n,
    nTake: stats.nTake,
    nSkip: stats.nSkip,
    takeCorrect: stats.takeCorrect,
    skipCorrect: stats.skipCorrect,
    plusEvTakeCells: stats.plusEvTakeCells.map(c => ({
      cell: c.cell,
      n: c.n,
      observeCandidate: c.observeCandidate,
      meanFeeNetVsSkipCents: c.meanFeeNetVsSkipCents,
      enable: false,
    })),
    liveApplyEnabled: false,
    teach: "OBSERVE only; skip puzzles do not update bot-fill weights (0.72–1.18x stays on fills)",
    updatedAt: stats.updatedAt,
  };
  existing.liveApplyEnabled = false;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(existing, null, 2) + "\n");
}

/**
 * Upsert OBSERVE section in strategy-proposals.md. Never writes ENABLE
 * or CHANGE_EV_FLOOR as an applied action.
 */
export function teachStrategyProposals(stats: PuzzleStats): void {
  const file = strategyProposalsPath();
  const section = observeSection(stats);
  let existing = "";
  try {
    existing = fs.readFileSync(file, "utf8");
  } catch {
    existing = "# Strategy proposals (shadow only)\n\nShadow-only. LIVE_APPLY_ENABLED stays false.\n";
  }
  if (existing.includes("ENABLE_STRATEGY of") && section.includes("Never ENABLE_STRATEGY")) {
    // keep
  }
  let next: string;
  const start = existing.indexOf(PUZZLE_MARK_START);
  const end = existing.indexOf(PUZZLE_MARK_END);
  if (start >= 0 && end > start) {
    next = existing.slice(0, start) + section + existing.slice(end + PUZZLE_MARK_END.length);
  } else {
    next = existing.replace(/\s*$/, "") + "\n\n" + section + "\n";
  }
  if (next.includes("CHANGE_EV_FLOOR") && !next.includes("Never CHANGE_EV_FLOOR")) {
    // existing file already forbids it; do not add an apply action
  }
  if (next === existing) return;
  fs.writeFileSync(file, next);
}

export function teachFromPuzzles(stats: PuzzleStats): void {
  try { teachShadowLearn(stats); } catch (err) {
    console.warn("[contract-puzzle-stats] shadow-learn teach failed:", (err as Error).message);
  }
  try { teachStrategyProposals(stats); } catch (err) {
    console.warn("[contract-puzzle-stats] proposals teach failed:", (err as Error).message);
  }
}

export function readPuzzleStatsSummary(): PuzzleStatsSummary | null {
  try {
    const raw = JSON.parse(fs.readFileSync(statsJsonPath(), "utf8")) as PuzzleStats;
    if (!raw || typeof raw.n !== "number") return null;
    return statsSummary(raw);
  } catch {
    return null;
  }
}

/** Quiet refresh after a bar. Fail-open. */
export function refreshPuzzleStatsQuiet(): PuzzleStats | null {
  try {
    const stats = computeAndWritePuzzleStats();
    teachFromPuzzles(stats);
    return stats;
  } catch (err) {
    console.warn("[contract-puzzle-stats] quiet refresh failed:", (err as Error).message);
    return null;
  }
}


function readJsonlObjects(file: string): Record<string, unknown>[] {
  try {
    if (!fs.existsSync(file)) return [];
    return fs.readFileSync(file, "utf8").trim().split("\n").filter(Boolean).map(l => JSON.parse(l) as Record<string, unknown>);
  } catch {
    return [];
  }
}

/**
 * Reconstruct one puzzle per settled 15m contract from shadow-tape +
 * contract-labels + trade-debriefs. Idempotent (skips tickers already in
 * contract-puzzles.jsonl). Shadow only.
 */
export function backfillPuzzlesFromResearch(opts?: { researchDir?: string }): { wrote: number; skippedExisting: number } {
  const root = opts?.researchDir ?? researchRoot();
  const existing = new Set(readPuzzleJsonl().map(p => p.ticker));
  const tape = readJsonlObjects(path.join(root, "shadow-tape.jsonl"));
  const labels = readJsonlObjects(path.join(root, "contract-labels.jsonl"));
  const debriefs = readJsonlObjects(path.join(root, "trade-debriefs.jsonl"));

  const settlements = new Map<string, { settled: PuzzleSide; periodOpenTs: string | null; ts: string }>();
  const skips: Record<string, Record<string, unknown>[]> = {};
  for (const row of tape) {
    const ticker = String(row.ticker ?? "");
    if (!ticker) continue;
    if (row.kind === "contract_settlement" && (row.settled === "YES" || row.settled === "NO")) {
      settlements.set(ticker, {
        settled: row.settled as PuzzleSide,
        periodOpenTs: (row.periodOpenTs as string) ?? null,
        ts: String(row.ts ?? ""),
      });
    }
    if (row.kind === "skip_settlement") {
      (skips[ticker] ??= []).push(row);
    }
  }
  for (const row of labels) {
    const ticker = String(row.ticker ?? "");
    if (!ticker) continue;
    if ((row.settled === "YES" || row.settled === "NO") && !settlements.has(ticker)) {
      settlements.set(ticker, {
        settled: row.settled as PuzzleSide,
        periodOpenTs: (row.periodOpenTs as string) ?? null,
        ts: String(row.ts ?? ""),
      });
    }
  }
  const takeByTicker = new Map<string, Record<string, unknown>>();
  for (const row of debriefs) {
    if (row.kind !== "paper_fill") continue;
    const ticker = String(row.ticker ?? "");
    if (!ticker || takeByTicker.has(ticker)) continue;
    takeByTicker.set(ticker, row);
  }
  const labelByTicker = new Map<string, Record<string, unknown>>();
  for (const row of labels) {
    const ticker = String(row.ticker ?? "");
    if (ticker) labelByTicker.set(ticker, row);
  }

  let wrote = 0;
  let skippedExisting = 0;
  for (const [ticker, settle] of settlements) {
    if (existing.has(ticker) || puzzleAlreadyRecorded(ticker)) {
      skippedExisting += 1;
      continue;
    }
    for (const s of skips[ticker] ?? []) {
      rememberPuzzleSkip({
        ticker,
        side: String(s.side ?? ""),
        strategyId: (s.strategyId as string) ?? null,
        rejectionCode: String(s.rejectionCode ?? "UNKNOWN"),
        entryPriceCents: typeof s.entryPriceCents === "number" ? s.entryPriceCents : null,
        secsRemaining: typeof s.secsRemaining === "number" ? s.secsRemaining : null,
        ts: typeof s.ts === "number" ? s.ts : Date.now(),
        lastSignal: typeof s.lastSignal === "string" ? s.lastSignal : null,
        floor: typeof s.floor === "number" ? s.floor : null,
        lagClass: typeof s.lagClass === "string" ? s.lagClass as LagClass : null,
        lagSeconds: typeof s.lagSeconds === "number" ? s.lagSeconds : null,
        lagDollars: typeof s.lagDollars === "number" ? s.lagDollars : null,
        htfStructure: s.htfStructure && typeof s.htfStructure === "object" ? s.htfStructure as ContractPuzzle["features"]["htfStructure"] : null,
        streakSaturation: typeof s.streakSaturation === "number" ? s.streakSaturation : null,
      });
    }
    const fill = takeByTicker.get(ticker);
    if (fill) {
      const before = (fill.before ?? {}) as Record<string, unknown>;
      const vel = (before.ticketVelocity ?? {}) as Record<string, unknown>;
      const sideRaw = String(before.side ?? fill.side ?? "");
      const side = sideRaw.toLowerCase() === "no" ? "NO" : sideRaw.toLowerCase() === "yes" ? "YES" : null;
      const ask = typeof before.entryCents === "number" ? before.entryCents
        : typeof before.tapeAskCents === "number" ? before.tapeAskCents
        : null;
      if (side && ask != null) {
        rememberPuzzleTake({
          ticker,
          side,
          strategyId: typeof before.strategyId === "string" ? before.strategyId : null,
          askCents: ask,
          secsRemaining: typeof before.secsRemaining === "number" ? before.secsRemaining : null,
          ts: Date.now(),
          lastSignal: typeof before.strategyId === "string" ? String(before.strategyId) : null,
          floor: typeof before.floor === "number" ? before.floor : null,
          ticketMotion: vel.state === "still" || vel.state === "moving" ? vel.state : null,
          regime: typeof before.regime === "string" ? before.regime : null,
        });
      }
    }
    const lab = labelByTicker.get(ticker);
    const minCheap = lab?.minCheapAsk as { side?: string; price?: number } | null | undefined;
    const quotes = lab ? {
      yesAsk: (lab.lastQuote as { yesAsk?: number } | undefined)?.yesAsk
        ?? (lab.midQuote as { yesAsk?: number } | undefined)?.yesAsk
        ?? null,
      noAsk: (lab.lastQuote as { noAsk?: number } | undefined)?.noAsk
        ?? (lab.midQuote as { noAsk?: number } | undefined)?.noAsk
        ?? null,
      minCheapAsk: minCheap && (minCheap.side === "YES" || minCheap.side === "NO") && typeof minCheap.price === "number"
        ? {
            side: minCheap.side as PuzzleSide,
            price: minCheap.price,
            secsRemaining: typeof lab.cheapFirstAppearedSecsToExpiry === "number"
              ? lab.cheapFirstAppearedSecsToExpiry as number
              : null,
          }
        : null,
    } : null;
    // lastQuote at close is 0/100 — prefer mid-period quotes for would-take when no cheap print
    if (quotes && lab?.midQuote) {
      const mid = lab.midQuote as { yesAsk?: number; noAsk?: number };
      quotes.yesAsk = mid.yesAsk ?? quotes.yesAsk;
      quotes.noAsk = mid.noAsk ?? quotes.noAsk;
    }
    const row = recordPuzzleOnSettlement({
      ticker,
      settled: settle.settled,
      floor: typeof lab?.floor === "number" ? lab.floor as number : null,
      periodOpenTs: settle.periodOpenTs ?? (lab?.periodOpenTs as string | null) ?? null,
      quotes,
      regime: null,
    });
    if (row) wrote += 1;
  }
  return { wrote, skippedExisting };
}

/**
 * Enrich existing puzzles with lag/HTF/early-exit labels where the tape
 * allows. Does not invent agree/break. Historical ticks lack Coinbase lag
 * series and HTF OHLC → those stay unknown unless skip reason codes already
 * named LAG_AGREE / LAG_AGAINST / LAG_STALE. Early-exit MFE CAN be scored
 * from yesAsk/noAsk/bids already on the tick files.
 *
 * Does not rewrite historical tick files.
 */
export function enrichPuzzlesWithTapeLabels(opts?: { jsonlFile?: string; ticksDir?: string }): {
  n: number;
  earlyExitLabeled: number;
  lagFromCodes: number;
  htfStillUnknown: number;
} {
  const file = opts?.jsonlFile ?? puzzleJsonlPath();
  const rows = readPuzzleJsonl(file);
  let earlyExitLabeled = 0;
  let lagFromCodes = 0;
  let htfStillUnknown = 0;
  const out: ContractPuzzle[] = [];
  for (const p of rows) {
    const codes = p.skip?.reasonCodes ?? [];
    let lagClass: LagClass = (p.features?.lagClass ?? "unknown") as LagClass;
    if (lagClass === "unknown") {
      const inferred = inferLagClass(codes, null);
      if (inferred !== "unknown") {
        lagClass = inferred;
        lagFromCodes += 1;
      }
    }
    const htf = p.features?.htfStructure && p.features.htfStructure.biasFor15m
      ? p.features.htfStructure
      : { ...UNKNOWN_HTF_SUMMARY };
    if (!htf.biasFor15m || htf.biasFor15m === "UNKNOWN") htfStillUnknown += 1;

    let earlyExit = p.earlyExit;
    const needMfe = !earlyExit || earlyExit.maxFavorableExcursionCents == null;
    if (needMfe && p.counterfactual.takeAskCents != null && p.counterfactual.takeSide) {
      const quotes = loadTapeQuotes(p.ticker, opts?.ticksDir);
      earlyExit = computeEarlyExit({
        entryAsk: p.counterfactual.takeAskCents,
        takeSide: p.counterfactual.takeSide,
        settled: p.settled,
        quotes,
      });
      if (earlyExit.maxFavorableExcursionCents != null) earlyExitLabeled += 1;
    }
    if (!earlyExit) {
      earlyExit = {
        entryAsk: p.counterfactual.takeAskCents ?? null,
        maxFavorableExcursionCents: null,
        earlyExitPnLAtMfeCents: null,
        earlyExitPnLAtGreenXCents: null,
        greenXCents: 20,
        settleSideCorrect: p.labels.settleSideCorrect ?? p.labels.sideCorrect ?? null,
        quotesAfterEntry: 0,
      };
    }

    const takeCells = classifyTakeCells({
      askCents: p.counterfactual.takeAskCents,
      secsRemaining: p.features?.secsRemaining ?? null,
      askBand: p.features?.askBand ?? "other",
      lagClass,
      ticketMotion: p.features?.ticketMotion ?? "unknown",
      takeSide: p.counterfactual.takeSide,
      htfStructure: htf,
    });

    const settleSideCorrect = p.labels.settleSideCorrect ?? p.labels.sideCorrect ?? null;
    const earlyExitCorrect = earlyExit.earlyExitPnLAtMfeCents == null
      ? (p.labels.earlyExitCorrect ?? null)
      : earlyExit.earlyExitPnLAtMfeCents > 0;

    out.push({
      ...p,
      features: {
        ...p.features,
        lagClass,
        lagSeconds: p.features?.lagSeconds ?? null,
        lagDollars: p.features?.lagDollars ?? null,
        htfStructure: htf,
        streakSaturation: p.features?.streakSaturation ?? null,
        takeCells,
      },
      earlyExit,
      labels: {
        ...p.labels,
        settleSideCorrect,
        earlyExitCorrect,
      },
    });
  }
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, out.map(r => JSON.stringify(r)).join("\n") + (out.length ? "\n" : ""));
  return { n: out.length, earlyExitLabeled, lagFromCodes, htfStillUnknown };
}

void LIVE_APPLY_ENABLED;
