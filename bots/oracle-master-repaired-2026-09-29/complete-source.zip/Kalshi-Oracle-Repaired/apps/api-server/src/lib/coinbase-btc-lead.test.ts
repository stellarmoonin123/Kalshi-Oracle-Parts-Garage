/**
 * coinbase-btc-lead.test.ts — public Coinbase BTC-USD lead.
 *
 * Missing leader → no quote. Heartbeats do not stamp. Fresh ticker can
 * be live. Aged print is stale. CC TAKE without lagProven stays TAKE.
 * Does not ENABLE leftovers or cut EV/Kelly. No live WS required.
 */
import test from "node:test";
import assert from "node:assert/strict";
import {
  CoinbaseBtcLead,
  parseCoinbaseTickerBody,
  DECLARED_LAG_LEAD,
  COINBASE_REST_TICKER_URL,
  COINBASE_WS_URL,
  COINBASE_PRODUCT,
  COINBASE_LEAD_STALE_MS,
} from "./coinbase-btc-lead.js";
import { alignedTakeGate } from "./aligned-take-gate.js";
import { confluenceWinRate } from "./confluence-cascade.js";

const T0 = 1_724_000_000_000;

test("declared lead is public Coinbase BTC-USD (not Binance)", () => {
  assert.equal(DECLARED_LAG_LEAD, "coinbase");
  assert.equal(COINBASE_PRODUCT, "BTC-USD");
  assert.equal(COINBASE_REST_TICKER_URL, "https://api.exchange.coinbase.com/products/BTC-USD/ticker");
  assert.equal(COINBASE_WS_URL, "wss://ws-feed.exchange.coinbase.com");
  assert.equal(COINBASE_REST_TICKER_URL.includes("binance"), false);
});

test("missing leader → getQuote null, lag cannot be proven from this feed", () => {
  const lead = new CoinbaseBtcLead();
  assert.equal(lead.getQuote(T0), null);
  assert.equal(lead.getFreshQuote(T0), null);
  assert.equal(lead.getRing().length, 0);
});

test("heartbeat / subscribe ack / error do not stamp a Coinbase print", () => {
  const lead = new CoinbaseBtcLead();
  assert.equal(parseCoinbaseTickerBody({ type: "heartbeat", time: "2026-09-03T00:00:00.000Z" }, T0, "ws"), null);
  assert.equal(lead.ingestJson({ type: "heartbeat" }, T0, "ws"), false);
  assert.equal(lead.ingestJson({ type: "subscriptions", channels: [] }, T0, "ws"), false);
  assert.equal(lead.ingestJson({ type: "error", message: "nope" }, T0, "ws"), false);
  assert.equal(lead.getQuote(T0), null);
});

test("fresh Coinbase ticker stamps a live print; aged → stale / not fresh", () => {
  const lead = new CoinbaseBtcLead();
  const ok = lead.ingestJson({
    type: "ticker",
    product_id: "BTC-USD",
    price: "81546.85",
    time: "2026-09-03T21:26:20.790Z",
  }, T0, "ws");
  assert.equal(ok, true);
  const fresh = lead.getFreshQuote(T0 + 200);
  assert.ok(fresh);
  assert.equal(fresh!.source, "coinbase");
  assert.equal(fresh!.price, 81546.85);
  assert.equal(fresh!.stale, false);
  assert.equal(fresh!.via, "ws");

  const aged = lead.getQuote(T0 + COINBASE_LEAD_STALE_MS + 1);
  assert.ok(aged);
  assert.equal(aged!.stale, true);
  assert.equal(lead.getFreshQuote(T0 + COINBASE_LEAD_STALE_MS + 1), null);
  assert.equal(lead.getRing().length, 1);
});

test("CC take without lagProven is still TAKE (does not inherit LAG_UNPROVEN)", () => {
  const wr = (side: "yes" | "no", ask: number) => confluenceWinRate(ask, 7);
  const cc = alignedTakeGate({
    strategyId: "CONFLUENCE_CASCADE",
    mtfSign: "long",
    yesAsk: 31,
    noAsk: 69,
    lagProven: false,
    winRateAtPrice: wr,
    quoteAgeMs: 100,
    spot: 81_600,
    floorStrike: 81_500,
  });
  assert.equal(cc.kind, "TAKE");
  if (cc.kind === "TAKE") assert.equal(cc.strategyId, "CONFLUENCE_CASCADE");
});
