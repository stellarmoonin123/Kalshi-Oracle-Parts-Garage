/**
 * live-btc-proxy.ts — server-side Live BTC Proxy.
 *
 * Same number the Trade tab shows: prefer a fresh Kalshi-aligned observation,
 * else a composite of fresh Kraken + Bitstamp + Coinbase BTC/USD (stale
 * excluded), else last good kalshi-inferred.
 *
 * avg60s is a derived 60-second average of THIS proxy. It is NEVER official
 * CF BRTI. We do not have a CF Benchmarks socket. Do not enable
 * BRTI_PROBABILITY. Do not wire this into TradingBot.evaluate this turn.
 *
 * Director: export getLiveBtcProxy(). BasisTracker.tick already takes
 * brtiProxy as an input — pass snapshot.price if you want the hook; that
 * call is NOT made from evaluate here.
 *
 * Never CHANGE_EV_FLOOR. Never ENABLE_STRATEGY. Never paperMode false.
 */
import { BTC_FLOOR_FALLBACK } from "./constants.js";
import { getCurrentBtcPriceFromKalshi, kalshiTickQuoteAgeMs } from "./kalshi-price.js";
import type { KalshiTick } from "./kalshi-ws.js";

export const KALSHI_ALIGNED_STALE_MS = 30_000;
export const EXCHANGE_STALE_MS = 15_000;
export const AVG60S_WINDOW_MS = 60_000;
export const CONSTITUENT_CACHE_MS = 2_500;
export const FETCH_TIMEOUT_MS = 2_000;

/** Derived 60s average of this proxy — not official CF BRTI. */
export const AVG60S_NOTE =
  "derived 60s average of this live BTC proxy; not official CF BRTI";

export type LiveBtcProxySource = "kalshi-aligned" | "exchange-composite" | "fallback";

export interface ConstituentQuote {
  price: number;
  ts: number;
}

export interface LiveBtcProxyConstituents {
  kraken: ConstituentQuote | null;
  bitstamp: ConstituentQuote | null;
  coinbase: ConstituentQuote | null;
  binance: ConstituentQuote | null;
}

export interface LiveBtcProxy {
  price: number;
  source: LiveBtcProxySource;
  ts: number;
  stale: boolean;
  avg60s: number;
  avg60sNote: typeof AVG60S_NOTE;
  constituents: LiveBtcProxyConstituents;
}

export interface KalshiAlignedObservation {
  price: number;
  ts: number;
}

export interface LiveBtcProxyDeps {
  now?: () => number;
  getKalshiAligned?: (now: number, staleMs: number) => KalshiAlignedObservation | null;
  fetchConstituents?: (now: number) => Promise<LiveBtcProxyConstituents>;
  kalshiStaleMs?: number;
  exchangeStaleMs?: number;
  lastGood?: KalshiAlignedObservation | null;
}

const PRIMARY_KEYS = ["kraken", "bitstamp", "coinbase"] as const;

function isFreshQuote(q: ConstituentQuote | null, now: number, staleMs: number): q is ConstituentQuote {
  return q != null
    && Number.isFinite(q.price)
    && q.price > 0
    && Number.isFinite(q.ts)
    && now - q.ts <= staleMs;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

async function fetchWithTimeout(url: string): Promise<Response> {
  return fetch(url, {
    headers: { Accept: "application/json", "User-Agent": "kalshi-live-btc-proxy/1.0" },
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
  });
}

function parsePrice(raw: unknown): number | null {
  const n = typeof raw === "number" ? raw : typeof raw === "string" ? parseFloat(raw) : NaN;
  return Number.isFinite(n) && n > 0 ? n : null;
}

async function fetchKraken(now: number): Promise<ConstituentQuote | null> {
  try {
    const resp = await fetchWithTimeout("https://api.kraken.com/0/public/Ticker?pair=XBTUSD");
    if (!resp.ok) return null;
    const body = (await resp.json()) as { result?: Record<string, { c?: string[] }> };
    const result = body.result ?? {};
    const row = result.XXBTZUSD ?? result.XBTUSD ?? Object.values(result)[0];
    const price = parsePrice(row?.c?.[0]);
    if (price == null) return null;
    return { price, ts: now };
  } catch {
    return null;
  }
}

async function fetchBitstamp(now: number): Promise<ConstituentQuote | null> {
  try {
    const resp = await fetchWithTimeout("https://www.bitstamp.net/api/v2/ticker/btcusd/");
    if (!resp.ok) return null;
    const body = (await resp.json()) as { last?: string; timestamp?: string };
    const price = parsePrice(body.last);
    if (price == null) return null;
    const tsSec = body.timestamp ? Number(body.timestamp) : NaN;
    const ts = Number.isFinite(tsSec) && tsSec > 1_000_000_000 ? tsSec * 1000 : now;
    return { price, ts };
  } catch {
    return null;
  }
}

async function fetchCoinbase(now: number): Promise<ConstituentQuote | null> {
  try {
    const resp = await fetchWithTimeout("https://api.exchange.coinbase.com/products/BTC-USD/ticker");
    if (!resp.ok) return null;
    const body = (await resp.json()) as { price?: string; time?: string };
    const price = parsePrice(body.price);
    if (price == null) return null;
    const parsed = body.time ? Date.parse(body.time) : NaN;
    const ts = Number.isFinite(parsed) ? parsed : now;
    return { price, ts };
  } catch {
    return null;
  }
}

async function fetchBinance(now: number): Promise<ConstituentQuote | null> {
  try {
    const resp = await fetchWithTimeout("https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT");
    if (!resp.ok) return null;
    const body = (await resp.json()) as { price?: string };
    const price = parsePrice(body.price);
    if (price == null) return null;
    return { price, ts: now };
  } catch {
    return null;
  }
}

export async function fetchDefaultConstituents(now: number): Promise<LiveBtcProxyConstituents> {
  const [kraken, bitstamp, coinbase, binance] = await Promise.all([
    fetchKraken(now),
    fetchBitstamp(now),
    fetchCoinbase(now),
    fetchBinance(now),
  ]);
  return { kraken, bitstamp, coinbase, binance };
}

let _wsGetter: (() => KalshiTick | null) | null = null;

export function bindKalshiTickGetter(fn: () => KalshiTick | null): void {
  _wsGetter = fn;
}

function productionGetKalshiAligned(now: number, staleMs: number): KalshiAlignedObservation | null {
  const getLatest = _wsGetter;
  if (!getLatest) return null;
  const tick = getLatest();
  // Heartbeats refresh ts; BRTI inference must key off quoteTs (last real book).
  if (!tick || kalshiTickQuoteAgeMs(tick, now) >= staleMs) return null;
  const price = getCurrentBtcPriceFromKalshi(getLatest, staleMs);
  if (!(price > 0)) return null;
  const quoteTs = typeof tick.quoteTs === "number" && tick.quoteTs > 0 ? tick.quoteTs : tick.ts;
  return { price, ts: quoteTs };
}

export class LiveBtcProxyEngine {
  private readonly nowFn: () => number;
  private readonly getKalshiAlignedFn: (now: number, staleMs: number) => KalshiAlignedObservation | null;
  private readonly fetchConstituentsFn: (now: number) => Promise<LiveBtcProxyConstituents>;
  private readonly kalshiStaleMs: number;
  private readonly exchangeStaleMs: number;
  private lastGood: KalshiAlignedObservation | null;
  private constituentCache: { data: LiveBtcProxyConstituents; ts: number } | null = null;
  private readonly avgBuf: { price: number; ts: number }[] = [];

  constructor(deps: LiveBtcProxyDeps = {}) {
    this.nowFn = deps.now ?? Date.now;
    this.getKalshiAlignedFn = deps.getKalshiAligned ?? productionGetKalshiAligned;
    this.fetchConstituentsFn = deps.fetchConstituents ?? fetchDefaultConstituents;
    this.kalshiStaleMs = deps.kalshiStaleMs ?? KALSHI_ALIGNED_STALE_MS;
    this.exchangeStaleMs = deps.exchangeStaleMs ?? EXCHANGE_STALE_MS;
    this.lastGood = deps.lastGood ?? null;
  }

  private now(): number {
    return this.nowFn();
  }

  private pushAvg(price: number, ts: number): number {
    this.avgBuf.push({ price, ts });
    const cutoff = ts - AVG60S_WINDOW_MS;
    while (this.avgBuf.length > 0 && this.avgBuf[0].ts < cutoff) this.avgBuf.shift();
    const sum = this.avgBuf.reduce((s, p) => s + p.price, 0);
    return this.avgBuf.length > 0 ? sum / this.avgBuf.length : price;
  }

  private async constituents(now: number): Promise<LiveBtcProxyConstituents> {
    if (this.constituentCache && now - this.constituentCache.ts < CONSTITUENT_CACHE_MS) {
      return this.constituentCache.data;
    }
    const data = await this.fetchConstituentsFn(now);
    this.constituentCache = { data, ts: now };
    return data;
  }

  private composite(cons: LiveBtcProxyConstituents, now: number): number | null {
    const vals: number[] = [];
    for (const key of PRIMARY_KEYS) {
      const q = cons[key];
      if (isFreshQuote(q, now, this.exchangeStaleMs)) vals.push(q.price);
    }
    if (vals.length === 0) return null;
    return vals.reduce((s, v) => s + v, 0) / vals.length;
  }

  async snapshot(): Promise<LiveBtcProxy> {
    const now = this.now();
    const aligned = this.getKalshiAlignedFn(now, this.kalshiStaleMs);
    const cons = await this.constituents(now);

    if (aligned && aligned.price > 0 && now - aligned.ts < this.kalshiStaleMs) {
      this.lastGood = aligned;
      const price = round2(aligned.price);
      const avg60s = round2(this.pushAvg(price, now));
      return {
        price,
        source: "kalshi-aligned",
        ts: aligned.ts,
        stale: false,
        avg60s,
        avg60sNote: AVG60S_NOTE,
        constituents: cons,
      };
    }

    const comp = this.composite(cons, now);
    if (comp != null) {
      const price = round2(comp);
      const avg60s = round2(this.pushAvg(price, now));
      return {
        price,
        source: "exchange-composite",
        ts: now,
        stale: false,
        avg60s,
        avg60sNote: AVG60S_NOTE,
        constituents: cons,
      };
    }

    const fallbackPrice = this.lastGood?.price && this.lastGood.price > 0
      ? this.lastGood.price
      : BTC_FLOOR_FALLBACK;
    const price = round2(fallbackPrice);
    const avg60s = round2(this.pushAvg(price, now));
    return {
      price,
      source: "fallback",
      ts: this.lastGood?.ts ?? now,
      stale: true,
      avg60s,
      avg60sNote: AVG60S_NOTE,
      constituents: cons,
    };
  }
}

const productionEngine = new LiveBtcProxyEngine();

async function ensureWsBound(): Promise<void> {
  if (_wsGetter) return;
  const { kalshiWS } = await import("./kalshi-ws.js");
  _wsGetter = () => kalshiWS.getLatest();
}

/** Director + /btc/ticker entry. Same hierarchy the Trade tab uses. */
export async function getLiveBtcProxy(): Promise<LiveBtcProxy> {
  await ensureWsBound();
  return productionEngine.snapshot();
}

export function createLiveBtcProxy(deps: LiveBtcProxyDeps = {}): LiveBtcProxyEngine {
  return new LiveBtcProxyEngine(deps);
}

/**
 * Optional director hook: BasisTracker.tick({ brtiProxy }) already accepts a
 * number. Pass getLiveBtcProxy().price. NOT called from TradingBot.evaluate
 * this turn (locked / giant edit).
 */
export async function liveProxyPriceForBasis(): Promise<number> {
  const snap = await getLiveBtcProxy();
  return snap.price;
}

/** Exact GET /btc/ticker JSON shape (proxy + legacy settlement fields). */
export interface BtcTickerJson extends LiveBtcProxy {
  /** Book quote time when kalshi-aligned (same as ts); null for composite/fallback. */
  quoteTs: number | null;
  lastFloorStrike: number | null;
  lastSettleResult: "yes" | "no" | null;
  lastSettleTicker: string | null;
}

export function toBtcTickerJson(
  proxy: LiveBtcProxy,
  lastSettle?: { floorStrike?: number; result?: "yes" | "no"; ticker?: string } | null,
): BtcTickerJson {
  return {
    price: proxy.price,
    source: proxy.source,
    ts: proxy.ts,
    // Honesty: UI ages BRTI on quoteTs; kalshi-aligned ts is already book quoteTs.
    quoteTs: proxy.source === "kalshi-aligned" ? proxy.ts : null,
    stale: proxy.stale,
    avg60s: proxy.avg60s,
    avg60sNote: proxy.avg60sNote,
    constituents: proxy.constituents,
    lastFloorStrike: lastSettle?.floorStrike ?? null,
    lastSettleResult: lastSettle?.result ?? null,
    lastSettleTicker: lastSettle?.ticker ?? null,
  };
}
