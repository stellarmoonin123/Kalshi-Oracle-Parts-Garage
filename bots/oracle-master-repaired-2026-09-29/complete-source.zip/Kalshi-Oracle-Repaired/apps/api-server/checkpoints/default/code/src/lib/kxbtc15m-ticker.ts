/**
 * KXBTC15M ticker arithmetic (pure; no WS import). Moved out of kalshi-ws.ts in
 * R3 so organs (regime trace) can apply the D10 close_time switch without
 * importing the socket client. kalshi-ws re-exports these.
 */
const D10_MON = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
export function kxbtc15mTickerForCloseMs(closeMs: number, series = "KXBTC15M"): string | null {
  if (!Number.isFinite(closeMs)) return null;
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York", hour12: false,
    year: "2-digit", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
  }).formatToParts(new Date(closeMs));
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  const hh = get("hour") === "24" ? "00" : get("hour");
  const mon = D10_MON[Number(get("month")) - 1];
  if (!mon || !hh) return null;
  const mm = get("minute");
  return `${series}-${get("year")}${mon}${get("day")}${hh}${mm}-${mm}`;
}

export function nextKxbtc15mTicker(activeCloseTimeIso: string): string | null {
  const closeMs = Date.parse(activeCloseTimeIso);
  if (!Number.isFinite(closeMs)) return null;
  return kxbtc15mTickerForCloseMs(closeMs + 15 * 60_000);
}

const QUARTER_MS = 15 * 60_000;

/** Ticker of the 15m contract whose window contains nowMs (close = next quarter boundary). */
export function currentKxbtc15mTickerAt(nowMs: number): string | null {
  if (!Number.isFinite(nowMs)) return null;
  return kxbtc15mTickerForCloseMs(Math.floor(nowMs / QUARTER_MS) * QUARTER_MS + QUARTER_MS);
}

const MONTH: Record<string, number> = {
  JAN: 1, FEB: 2, MAR: 3, APR: 4, MAY: 5, JUN: 6,
  JUL: 7, AUG: 8, SEP: 9, OCT: 10, NOV: 11, DEC: 12,
};

/**
 * D11 — contract CLOSE time (UTC ISO) for a KXBTC15M ticker. The ticker's
 * hhmm is the ET wall-clock close. Prefer Kalshi's own UTC `close_time`
 * (market object / row) when given. Parsing ET text is only a fallback and
 * returns null in the DST fall-back hour, where both EDT and EST round-trip
 * (e.g. Nov 1 2026 01:xx ET) — ambiguous, so never guess.
 */
export function kxbtc15mCloseUtcIso(
  ticker: string | null | undefined,
  closeTimeUtc?: string | Date | null,
): string | null {
  if (closeTimeUtc != null) {
    const ms = closeTimeUtc instanceof Date ? closeTimeUtc.getTime() : Date.parse(String(closeTimeUtc));
    if (Number.isFinite(ms)) return new Date(ms).toISOString();
  }
  if (!ticker) return null;
  const m = /^KXBTC15M-(\d{2})([A-Z]{3})(\d{2})(\d{2})(\d{2})/i.exec(ticker.trim());
  if (!m) return null;
  const year = 2000 + Number(m[1]);
  const month = MONTH[m[2]!.toUpperCase()];
  const day = Number(m[3]);
  const hour = Number(m[4]);
  const minute = Number(m[5]);
  if (!month || !Number.isFinite(year) || !Number.isFinite(day)) return null;
  const hits: number[] = [];
  for (const off of [4, 5]) {
    const utc = Date.UTC(year, month - 1, day, hour + off, minute, 0);
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: "America/New_York",
      hour12: false,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    }).formatToParts(new Date(utc));
    const get = (t: string) => parts.find((p) => p.type === t)?.value;
    let h = Number(get("hour"));
    if (h === 24) h = 0;
    if (
      Number(get("year")) === year &&
      Number(get("month")) === month &&
      Number(get("day")) === day &&
      h === hour &&
      Number(get("minute")) === minute
    ) {
      hits.push(utc);
    }
  }
  if (hits.length !== 1) return null; // 0 = invalid, 2 = DST-ambiguous
  return new Date(hits[0]!).toISOString();
}
