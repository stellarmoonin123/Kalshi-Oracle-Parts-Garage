/**
 * intra-scalp-replay.test.ts
 *
 * Shadow intra-contract scalps. Does not import trading-bot.ts.
 * LIVE_APPLY stays false. VELOCITY_MOMENTUM is never a fill strategyId.
 * Ticket velocity = dAsk/dt or dMid/dt on the Kalshi side, not BTC $/min.
 */
import assert from "node:assert/strict";
import test from "node:test";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { paperEarlyExitCreditCents, paperFillCostCents } from "./settlement-helpers.js";
import { HARD_RISK_LIMITS, EV_FLOOR } from "./admission.js";
import {
  INTRA_ASK_MAX_CENTS,
  INTRA_ASK_MIN_CENTS,
  INTRA_BAR_RISK_PCT,
  INTRA_MIN_EV_CENTS,
  INTRA_PERSIST_MS,
  INTRA_SCALP_BANKROLL_START_CENTS,
  LIVE_APPLY_ENABLED,
  TICKET_VEL_LOOKBACK_MS,
  TICKET_VEL_MIN_MOVE_CENTS,
  bothAsksInBand,
  decideIntraEntry,
  isIntraAskBand,
  replayBar,
  ticketVelocity,
  type TickQuote,
} from "./intra-scalp-replay.js";
import { updatePersistState, type PersistState } from "./tick-replay-backtest.js";

const SRC_DIR = path.dirname(fileURLToPath(import.meta.url));
const SRC = fs.readFileSync(path.join(SRC_DIR, "intra-scalp-replay.ts"), "utf8");

function tick(p: Partial<TickQuote> & { ts: number }): TickQuote {
  return {
    ticker: p.ticker ?? "KXBTC15M-TEST",
    ts: p.ts,
    yesAsk: p.yesAsk ?? 90,
    noAsk: p.noAsk ?? 12,
    yesBid: p.yesBid ?? Math.max(0, (p.yesAsk ?? 90) - 1),
    noBid: p.noBid ?? Math.max(0, (p.noAsk ?? 12) - 1),
    floor: p.floor ?? 65_000,
    projectedSettlement: p.projectedSettlement === undefined ? 65_200 : p.projectedSettlement,
    secsRemaining: p.secsRemaining ?? 400,
  };
}

/** Ramp YES ask from `fromAsk` to `toAsk` over `n` 1s ticks, path above floor. */
function rampYes(opts: { t0: number; n: number; fromAsk: number; toAsk: number; secs0?: number; bidOffset?: number }): TickQuote[] {
  const out: TickQuote[] = [];
  for (let i = 0; i < opts.n; i++) {
    const frac = opts.n === 1 ? 1 : i / (opts.n - 1);
    const ask = Math.round(opts.fromAsk + (opts.toAsk - opts.fromAsk) * frac);
    const bidOff = opts.bidOffset ?? 1;
    out.push(tick({
      ts: opts.t0 + i * 1_000,
      yesAsk: ask,
      yesBid: Math.max(0, ask - bidOff),
      noAsk: Math.max(1, 100 - ask),
      noBid: Math.max(0, 100 - ask - 1),
      secsRemaining: (opts.secs0 ?? 500) - i,
      projectedSettlement: 65_200,
    }));
  }
  return out;
}

test("LIVE_APPLY false; floors pinned; forbidden strategyIds never assigned", () => {
  assert.equal(LIVE_APPLY_ENABLED, false);
  assert.equal(INTRA_MIN_EV_CENTS, 3);
  assert.equal(EV_FLOOR, 3, "must not cut the 3¢ EV floor");
  assert.equal(INTRA_BAR_RISK_PCT, 0.09);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09, "must not cut 9%");
  assert.equal(HARD_RISK_LIMITS.maxDailyLossPct, 0.18, "must not cut 18%");
  assert.equal(INTRA_PERSIST_MS, 15_000);
  assert.equal(INTRA_ASK_MIN_CENTS, 7);
  assert.equal(INTRA_ASK_MAX_CENTS, 55);
  assert.equal(INTRA_SCALP_BANKROLL_START_CENTS, 31_300);
  assert.equal(TICKET_VEL_LOOKBACK_MS, 8_000);
  assert.equal(TICKET_VEL_MIN_MOVE_CENTS, 2);
  for (const bad of [
    "SETTLEMENT_PREDICTION", "LATE_ENTRY", "LATE_ENTRY_ANCHOR",
    "TOP_REVERSAL", "BOTTOM_REVERSAL", "BOLLINGER", "VELOCITY_MOMENTUM",
  ]) {
    assert.equal(SRC.includes(`strategyId: "${bad}"`), false, `must not take ${bad}`);
  }
  assert.match(SRC, /LIVE_APPLY_ENABLED = false/);
  assert.equal(/ENABLE_STRATEGY\s*[:=(]/.test(SRC), false, "must not invoke ENABLE_STRATEGY");
  assert.equal(SRC.includes("paperMode: false"), false);
  assert.match(SRC, /minVelocity/, "spec must mention minVelocity lock");
});

test("synthetic bar: buy YES 20, sell 40, fee-net positive (velocity-confirmed)", () => {
  // Ask ramps 18 → 20 over 8s so dAsk is +2 (moving, not still). Fill at 20.
  const ramp = rampYes({ t0: 0, n: 9, fromAsk: 18, toAsk: 20, secs0: 500 });
  const exitTicks: TickQuote[] = [
    tick({ ts: 9_000, yesAsk: 41, yesBid: 40, noAsk: 60, noBid: 59, secsRemaining: 491, projectedSettlement: 65_200 }),
    tick({ ts: 10_000, yesAsk: 41, yesBid: 40, noAsk: 60, noBid: 59, secsRemaining: 490, projectedSettlement: 65_200 }),
  ];
  const ticks = [...ramp, ...exitTicks];
  const vel = replayBar({ ticks, settled: "YES", policy: "velocityIntra" });
  assert.ok(vel.fills.length >= 1, "velocity book must fill a rising 18→20 YES");
  const f = vel.fills[0]!;
  assert.equal(f.strategyId, "INTRA_SCALP");
  assert.equal(f.side, "yes");
  assert.equal(f.fillPriceCents, 20);
  assert.equal(f.exit, "sell_green");
  assert.equal(f.exitBidCents, 40);
  const cost = paperFillCostCents(1, 20);
  const credit = paperEarlyExitCreditCents(1, 40);
  assert.equal(f.fillCostCents, cost);
  assert.equal(f.feeNetPnlCents, credit - cost);
  assert.ok(f.feeNetPnlCents > 0, "buy 20 sell 40 must be fee-net positive");
  assert.ok(f.ticketVelocity && (f.ticketVelocity.dAskCents >= 2 || f.ticketVelocity.dMidCents >= 2));
  assert.equal(vel.maxOpen, 1);
});

test("still 20¢ ask is skip on velocity book and a fill on still-cheap (A vs B)", () => {
  const still: TickQuote[] = [];
  for (let i = 0; i < 20; i++) {
    still.push(tick({
      ts: i * 1_000,
      yesAsk: 20, yesBid: 19, noAsk: 81, noBid: 80,
      secsRemaining: 500 - i,
      projectedSettlement: 65_200,
    }));
  }
  const v = ticketVelocity({ side: "yes", now: still[16]!, history: still.slice(0, 17) });
  assert.ok(v);
  assert.equal(v.inBuyDirection, false, "unchanged 20¢ is not ticket velocity");
  assert.equal(v.dAskCents, 0);

  const vel = replayBar({ ticks: still, settled: "YES", policy: "velocityIntra" });
  assert.equal(vel.fills.length, 0, "still 20¢ must skip the velocity book");

  const cheap = replayBar({ ticks: still, settled: "YES", policy: "stillCheap" });
  assert.ok(cheap.fills.length >= 1, "still-cheap cell A may take a still 20¢ (counterfactual)");
  assert.equal(cheap.fills[0]!.strategyId, "STILL_CHEAP");
  assert.equal(cheap.fills[0]!.fillPriceCents, 20);
  assert.equal(cheap.fills[0]!.side, "yes");
});

test("cannot open NO while YES is open; never both-open", () => {
  const ramp = rampYes({ t0: 0, n: 9, fromAsk: 18, toAsk: 20, secs0: 500 });
  // YES is open (bid stays ~19, not +20 green). Path flips to NO and NO ask ramps.
  const overlap: TickQuote[] = [];
  for (let i = 0; i < 12; i++) {
    const ask = 16 + Math.min(4, i); // NO 16→20
    overlap.push(tick({
      ts: 9_000 + i * 1_000,
      yesAsk: 21, yesBid: 19, // held YES, not 20¢ green
      noAsk: ask,
      noBid: ask - 1,
      secsRemaining: 480 - i,
      projectedSettlement: 64_700, // below floor → NO path / lag-against YES
    }));
  }
  const ticks = [...ramp, ...overlap];
  const vel = replayBar({ ticks, settled: "NO", policy: "velocityIntra" });
  assert.equal(vel.maxOpen, 1, "never two contracts open");
  const yesOpenTs = vel.fills.find(f => f.side === "yes")?.fillTs;
  const noDuringYes = vel.fills.filter(f => f.side === "no" && yesOpenTs != null && f.fillTs < (vel.fills.find(x => x.side === "yes")?.exitTs ?? 0));
  assert.equal(noDuringYes.length, 0, "must not open NO while YES is open");
  assert.ok(vel.fills.every(f => f.side === "yes"), "main intra book does not flip to NO (flip is a separate cell)");

  const both = tick({ ts: 1, yesAsk: 20, noAsk: 20, yesBid: 19, noBid: 19, projectedSettlement: 65_200, secsRemaining: 400 });
  assert.equal(bothAsksInBand(both), true);
  assert.equal(isIntraAskBand(20), true);
  let persist: PersistState = { side: null, sinceTs: 0 };
  persist = updatePersistState(persist, both);
  const whileOpen = decideIntraEntry({
    policy: "velocityIntra",
    tick: both,
    persist,
    history: [both],
    open: true,
    fillsThisBar: 1,
    firstSide: "yes",
    remainingBudgetCents: 10_000,
  });
  assert.equal(whileOpen, null, "already-in-trade must skip the other side");
});

test("9% bar budget blocks a third entry", () => {
  // 500¢ × 9% = 45¢. Each YES 20¢ fill costs 21¢. Two fills spend 42¢; third needs 21¢.
  const startBankrollCents = 500;
  assert.equal(Math.floor(startBankrollCents * INTRA_BAR_RISK_PCT), 45);

  function scalpCycle(t0: number): TickQuote[] {
    const ramp = rampYes({ t0, n: 9, fromAsk: 18, toAsk: 20, secs0: 500 });
    const sell = tick({
      ts: t0 + 9_000,
      yesAsk: 41, yesBid: 40, noAsk: 60, noBid: 59,
      secsRemaining: 400,
      projectedSettlement: 65_200,
    });
    // 9s of still 16¢ so the next lookback does not include the 41¢ print.
    const still: TickQuote[] = [];
    for (let i = 0; i < 9; i++) {
      still.push(tick({
        ts: t0 + 10_000 + i * 1_000,
        yesAsk: 16, yesBid: 15, noAsk: 85, noBid: 84,
        secsRemaining: 380 - i,
        projectedSettlement: 65_200,
      }));
    }
    return [...ramp, sell, ...still];
  }

  const ticks = [
    ...scalpCycle(0),
    ...scalpCycle(30_000),
    ...scalpCycle(60_000),
  ];
  const vel = replayBar({ ticks, settled: "YES", policy: "velocityIntra", startBankrollCents });
  assert.equal(vel.barBudgetCents, 45);
  assert.ok(vel.fills.length <= 2, `9% budget must not allow a third 20¢ fill, got ${vel.fills.length}`);
  assert.equal(vel.fills.length, 2, "first two 20¢ scalps fit in 45¢");
  assert.equal(vel.blockedThirdByBudget, true);
  assert.ok(vel.spentBudgetCents <= 45);
  const thirdCost = paperFillCostCents(1, 20);
  assert.ok(vel.barBudgetCents - vel.spentBudgetCents < thirdCost);
  assert.ok(vel.fills.every(f => f.strategyId === "INTRA_SCALP"));
});

test("settlement-only holds to 100 (no scalp, no flip) on the same velocity entry", () => {
  const ramp = rampYes({ t0: 0, n: 9, fromAsk: 18, toAsk: 20, secs0: 500 });
  const rest: TickQuote[] = [
    tick({ ts: 9_000, yesAsk: 41, yesBid: 40, secsRemaining: 491, projectedSettlement: 65_200 }),
    tick({ ts: 90_000, yesAsk: 100, yesBid: 99, secsRemaining: 0, projectedSettlement: 65_400 }),
  ];
  const ticks = [...ramp, ...rest];
  const hold = replayBar({ ticks, settled: "YES", policy: "settlementOnly" });
  assert.equal(hold.fills.length, 1);
  assert.equal(hold.fills[0]!.strategyId, "SETTLEMENT_ONLY");
  assert.equal(hold.fills[0]!.exit, "settlement");
  assert.equal(hold.fills[0]!.fillPriceCents, 20);
  assert.equal(hold.fills[0]!.won, true);
  const scalp = replayBar({ ticks, settled: "YES", policy: "velocityIntra" });
  assert.equal(scalp.fills[0]!.exit, "sell_green");
  assert.notEqual(hold.fills[0]!.exit, "sell_green");
});

test("alwaysSkip is 0 fills / 0 pnl", () => {
  const ramp = rampYes({ t0: 0, n: 9, fromAsk: 18, toAsk: 20 });
  const skip = replayBar({ ticks: ramp, settled: "YES", policy: "alwaysSkip" });
  assert.equal(skip.fills.length, 0);
  assert.equal(skip.feeNetPnlCents, 0);
});
