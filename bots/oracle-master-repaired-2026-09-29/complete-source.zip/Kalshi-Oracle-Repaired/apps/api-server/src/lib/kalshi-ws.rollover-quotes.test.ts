/** R3 final — quotes for a D10-adopted contract before it appears in the open list. */
import assert from "node:assert/strict";
import test from "node:test";
import { kalshiWS, fetchActiveMarketByTicker, BY_TICKER_QUOTE_MIN_MS } from "./kalshi-ws.js";

const internals = kalshiWS as unknown as {
  active: { ticker: string; floorStrike: number; closeTime: string };
  latest: any; pollRestPrices: () => Promise<void>; refreshMarket: () => Promise<void>;
  _polling: boolean; _pollingStartedAt: number; _rolloverMissKickAt: number; _byTickerQuoteAt: number;
};
const T = "KXBTC15M-26SEP250345-45";
const closeTime = new Date(Date.now() + 14 * 60_000).toISOString();
const byTickerMarket = { ticker: T, status: "active", close_time: closeTime, floor_strike: 84036.19, yes_bid_dollars: "0.49", yes_ask_dollars: "0.51", no_bid_dollars: "0.49", no_ask_dollars: "0.50" };

test("open list lagging → exact by-ticker read supplies quotes (throttled to 1/s)", async () => {
  const saved = { active: internals.active, latest: internals.latest, polling: internals._polling, refresh: internals.refreshMarket, fetch: globalThis.fetch, bt: internals._byTickerQuoteAt };
  const urls: string[] = [];
  let refreshCalls = 0;
  try {
    internals.active = { ticker: T, floorStrike: 84036.19, closeTime };
    internals.latest = null;
    internals._polling = false; internals._pollingStartedAt = 0; internals._rolloverMissKickAt = 0; internals._byTickerQuoteAt = 0;
    internals.refreshMarket = (async () => { refreshCalls++; }) as any;
    globalThis.fetch = (async (url: string) => {
      urls.push(String(url));
      if (String(url).includes("status=open")) return { ok: true, json: async () => ({ markets: [{ ...byTickerMarket, ticker: "KXBTC15M-26SEP250330-30", status: "closed" }] }) };
      return { ok: true, json: async () => ({ market: byTickerMarket }) };
    }) as any;
    await internals.pollRestPrices();
    assert.equal(internals.latest?.ticker, T);
    assert.equal(internals.latest?.yesAsk, 51);
    assert.equal(internals.latest?.noAsk, 50);
    assert.equal(refreshCalls, 0, "no rollover-miss kick when by-ticker read succeeded");
    assert.ok(urls.some((u) => u.endsWith(`/markets/${T}`)));
    assert.equal(urls.filter((u) => u.includes("status=open")).length, 0, "R4: quotes come from by-ticker, not the stale open list");
    const n = urls.length;
    await internals.pollRestPrices();
    assert.equal(urls.filter((u) => u.endsWith(`/markets/${T}`)).length, 1, `second poll within ${BY_TICKER_QUOTE_MIN_MS}ms skips by-ticker read`);
    // R4 — and never falls back to the stale open list in between (no fetch at all).
    assert.equal(urls.length, n);
    assert.equal(internals.latest?.yesAsk, 51);
  } finally {
    globalThis.fetch = saved.fetch; internals.refreshMarket = saved.refresh; internals.active = saved.active;
    internals.latest = saved.latest; internals._polling = saved.polling; internals._byTickerQuoteAt = saved.bt;
  }
});

test("R4: stale open list is never used when the by-ticker read succeeds", async () => {
  const saved = { active: internals.active, latest: internals.latest, polling: internals._polling, fetch: globalThis.fetch, bt: internals._byTickerQuoteAt, ws: (internals as any)._lastWsMessageTs };
  try {
    internals.active = { ticker: T, floorStrike: 84036.19, closeTime };
    internals.latest = null;
    internals._polling = false; internals._pollingStartedAt = 0; internals._byTickerQuoteAt = 0;
    (internals as any)._lastWsMessageTs = 0;
    globalThis.fetch = (async (url: string) => {
      if (String(url).includes("status=open")) return { ok: true, json: async () => ({ markets: [{ ...byTickerMarket, yes_bid_dollars: "0.6600", yes_ask_dollars: "0.6700", no_bid_dollars: "0.3300", no_ask_dollars: "0.3400" }] }) };
      return { ok: true, json: async () => ({ market: { ...byTickerMarket, yes_bid_dollars: "0.8100", yes_ask_dollars: "0.8200", no_bid_dollars: "0.1800", no_ask_dollars: "0.1900" } }) };
    }) as any;
    await internals.pollRestPrices();
    assert.equal(internals.latest?.yesAsk, 82, "live by-ticker 81/82, not stale list 66/67");
    assert.equal(internals.latest?.noAsk, 19);
  } finally {
    globalThis.fetch = saved.fetch; internals.active = saved.active; internals.latest = saved.latest;
    internals._polling = saved.polling; internals._byTickerQuoteAt = saved.bt; (internals as any)._lastWsMessageTs = saved.ws;
  }
});

test("fetchActiveMarketByTicker: exact ticker + active only", async () => {
  const f = (m: unknown) => (async () => ({ ok: true, json: async () => ({ market: m }) })) as any;
  assert.equal((await fetchActiveMarketByTicker(T, f(byTickerMarket)))?.ticker, T);
  assert.equal(await fetchActiveMarketByTicker(T, f({ ...byTickerMarket, status: "initialized" })), null);
  assert.equal(await fetchActiveMarketByTicker(T, f({ ...byTickerMarket, status: "closed" })), null);
  assert.equal(await fetchActiveMarketByTicker(T, f({ ...byTickerMarket, ticker: "KXBTC15M-OTHER" })), null);
  assert.equal(await fetchActiveMarketByTicker(T, (async () => ({ ok: false })) as any), null);
  assert.equal(await fetchActiveMarketByTicker(T, (async () => { throw new Error("net"); }) as any), null);
});
