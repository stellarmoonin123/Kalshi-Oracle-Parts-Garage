/**
 * Hostile sensors+UI lift — 2026-09-11
 * CLOSE ε T · true BRTI pin · brtiOf · basisLeadUsd · unresolved→ORPHAN
 * Locks: paperMode / frozenCc; no EV/Kelly/door cuts; bounce API only.
 */
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  THEO_EPS_MINUTES,
  stampEntryTheoFromBrti,
} from "./brti-theo-sanity.js";
import { direction_w2 } from "./organs/direction-w2.js";
import { buildLockSideTags } from "./organs/lock-side-context.js";
import {
  buildTradeStory,
  collapsedStoryFields,
  coerceTradeStory,
} from "./trade-story.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const LSC = fs.readFileSync(path.join(HERE, "organs/lock-side-context.ts"), "utf8");
const W2 = fs.readFileSync(path.join(HERE, "organs/direction-w2.ts"), "utf8");
const BASIS = fs.readFileSync(path.join(HERE, "basis-tracker.ts"), "utf8");
const BOT = fs.readFileSync(path.join(HERE, "trading-bot.ts"), "utf8");
const HELPER = fs.readFileSync(path.join(HERE, "brti-theo-sanity.ts"), "utf8");

const NOW = 1_800_000_000_000;

test("1) CLOSE exitTheo: minsLeft=0 stamps via ε T when BRTI live", () => {
  assert.equal(THEO_EPS_MINUTES, 1 / 60);
  assert.match(HELPER, /minsLeft > 0 \? minsLeft : THEO_EPS_MINUTES/);
  const r = stampEntryTheoFromBrti({
    brtiUsd: 80_000,
    floorStrike: 80_000,
    vol: 0.5,
    minsLeft: 0,
    side: "yes",
  });
  assert.notEqual(r.reason, "inputs_incomplete");
  assert.equal(r.reason, "ok");
  assert.ok(r.entryTheoCents != null);
  assert.ok(BOT.includes("minsLeftTheo"), "host includes (hang-safe)");
  assert.ok(BOT.includes("ε T") || BOT.includes("0 →"), "exitTheo epsilon stamp host");
});

test("2) True BRTI pin: brtiDefined≠true → pin_reachable=false; desk_pin separate", () => {
  const noBrti = direction_w2({
    mtfSign: "long",
    lockSide: "yes",
    haSide: "yes",
    yesAsk: 31,
    noAsk: 69,
    spot: 65_100,
    floorStrike: 65_000,
    brtiDefined: false,
    brtiPx: null,
    lagProven: true,
    lagSide: "yes",
    secsRemaining: 180,
    nowMs: NOW,
    remainingVol: 500,
    venue2Live: false,
  });
  assert.equal(noBrti.log.pin_reachable, false);
  assert.equal(noBrti.log.desk_pin, true);
  assert.notEqual(noBrti.log.lockSide?.pin.state, "PIN");

  const truePin = direction_w2({
    mtfSign: "long",
    lockSide: "yes",
    haSide: "yes",
    yesAsk: 31,
    noAsk: 69,
    spot: 65_100,
    floorStrike: 65_000,
    brtiDefined: true,
    brtiPx: 65_100,
    lagProven: true,
    lagSide: "yes",
    secsRemaining: 180,
    nowMs: NOW,
    remainingVol: 500,
    venue2Live: false,
  });
  assert.equal(truePin.log.pin_reachable, true);
  assert.equal(truePin.log.lockSide?.pin.state, "PIN");
  assert.match(W2, /no spot fallback into pin_reachable|True BRTI pin only/);
});

test("3) brtiOf / lock-side-context: defined iff brtiDefined===true (no || true)", () => {
  assert.equal(/brtiDefined === true \|\| true/.test(LSC), false, "legacy || true must be deleted");
  assert.match(LSC, /obs\.brtiDefined !== true/);
  // px present but flag omitted → undefined BRTI (no invent)
  const tags = buildLockSideTags({
    brtiPx: 65_100,
    // brtiDefined omitted
    strike: 65_000,
    remainingVol: 500,
    secsRemaining: 180,
  });
  assert.equal(tags.pin.state, null, "omitted brtiDefined must not invent PIN from px");
  assert.equal(tags.brtiSign, null);

  const defined = buildLockSideTags({
    brtiPx: 65_100,
    brtiDefined: true,
    strike: 65_000,
    remainingVol: 500,
    secsRemaining: 180,
  });
  assert.equal(defined.pin.state, "PIN");
});

test("4) basisLeadUsd operator alias (status/obs); lag math keeps estimatedFairBRTI", () => {
  assert.match(BASIS, /basisLeadUsd/);
  assert.match(BASIS, /s\.basisLeadUsd = s\.estimatedFairBRTI/);
  assert.ok(BOT.includes("basisLeadUsd:"), "host includes (hang-safe)");
  // Lag money path still on estimatedFairBRTI
  assert.ok(BOT.includes("projectSettlementPrice") && BOT.includes("estimatedFairBRTI"), "lag proj host");
});

test("5) unresolved outcome → ORPHAN (not SKIP_N/A); fee-net honesty wire", () => {
  const coll = collapsedStoryFields({
    side: "yes",
    outcome: "unresolved",
    pnlCents: null as any,
  });
  assert.equal(coll.result, "ORPHAN");
  assert.equal(coll.settlePhrase, "orphan");
  assert.match(coll.line, /ORPHAN · orphan/);
  assert.doesNotMatch(coll.line, /SKIP_N\/A/);

  const story = buildTradeStory({
    side: "no",
    outcome: "unresolved",
    fillOrigin: "bot",
    strategyId: "CONFLUENCE_CASCADE",
    pnlCents: null,
  });
  assert.ok(story);
  assert.equal(story!.result, "ORPHAN");

  assert.equal(
    coerceTradeStory({ result: "SKIP_N/A", whatHappened: "unresolved close", side: "YES" } as any)?.result,
    "ORPHAN",
  );

  const traderStory = fs.readFileSync(
    path.join(HERE, "../../../kalshi-trader/src/lib/trade-story.ts"),
    "utf8",
  );
  assert.match(traderStory, /o === "unresolved"\) return "ORPHAN"/);

  const botUi = fs.readFileSync(
    path.join(HERE, "../../../kalshi-trader/src/pages/bot.tsx"),
    "utf8",
  );
  assert.match(botUi, /data-feenet-pnl="true"/);
  assert.match(botUi, /P&L \(fee-net\):/);
  assert.match(botUi, /cash Δ/);
});
