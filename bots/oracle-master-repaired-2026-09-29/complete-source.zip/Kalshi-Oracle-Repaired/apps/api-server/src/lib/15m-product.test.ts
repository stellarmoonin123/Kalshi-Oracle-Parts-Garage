/**
 * 15m product completeness (2026-08-27 score lift).
 *
 * KXBTCD / KXBTCH / KXBTCPERP tickers must not enter the 15m evaluate path
 * even when contractDurationMins is missing or hardcoded to 15.
 * backgroundPreTrade must never placeOrder.
 *
 * paperMode stays true. autoMode false on disk. No EV/Kelly/9%/15% cuts.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "path";
import { fileURLToPath } from "node:url";
import {
  seriesDurationFromTicker,
  isKxbct15mTicker,
  isKXBTC15M,
  is15mDeskEvaluateAllowed,
  durationForObservation,
  hourlyOrPerpEvaluateAllowed,
  resolveProductDuration,
  productDurationFromMinsLabel,
} from "./15m-product.js";
import {
  durationBucket,
  isStrategyAllowedForDuration,
  evaluateAllStrategies,
  getStrategy,
  type StrategyObservation,
} from "./strategy-library.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT_SRC = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const PRODUCTION_CONFIG = path.resolve(DIR, "../../.bot-config.json");

function baseObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65_100,
    floorStrike: 65_000,
    velocityDolPerMin: 80,
    threeMinVelocity: 70,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.2,
    massAboveFloor: 55,
    secsRemaining: 8 * 60,
    contractDurationMins: 15,
    ...overrides,
  };
}

test("seriesDurationFromTicker: 15m / hourly / perp / unknown", () => {
  assert.equal(seriesDurationFromTicker("KXBTC15M-26AUG271615-15"), "15M");
  assert.equal(seriesDurationFromTicker("kxbtc15m-26aug271615-15"), "15M");
  assert.equal(seriesDurationFromTicker("KXBTCD-26AUG2714"), "1H");
  assert.equal(seriesDurationFromTicker("KXBTCH-26AUG0114"), "1H");
  assert.equal(seriesDurationFromTicker("KXBTCPERP"), "PERP");
  assert.equal(seriesDurationFromTicker("BTC-PERP-FOO"), "PERP");
  assert.equal(seriesDurationFromTicker("KXBTC-26AUG2714"), null);
  assert.equal(seriesDurationFromTicker(""), null);
  assert.equal(seriesDurationFromTicker(null), null);
  assert.equal(seriesDurationFromTicker(undefined), null);
});

test("isKxbct15mTicker / isKXBTC15M alias", () => {
  assert.equal(isKxbct15mTicker("KXBTC15M-26AUG271400-00"), true);
  assert.equal(isKXBTC15M("KXBTC15M-26AUG271400-00"), true);
  assert.equal(isKxbct15mTicker("KXBTCD-26AUG2714-00"), false);
  assert.equal(isKxbct15mTicker("KXBTCPERP"), false);
  assert.equal(isKxbct15mTicker("KXBTC-26AUG2714-00"), false);
  // KXBTC15M must not match as hourly: "KXBTCD" is not a substring of "KXBTC15M"
  assert.equal("KXBTC15M".includes("KXBTCD"), false);
});

test("is15mDeskEvaluateAllowed: refuse hourly/perp/unknown; allow 15m and missing ticker", () => {
  assert.deepEqual(is15mDeskEvaluateAllowed({ ticker: "KXBTC15M-26AUG271615-15" }), {
    ok: true,
    reason: "KXBTC15M",
  });
  assert.equal(is15mDeskEvaluateAllowed({ ticker: "KXBTCD-26AUG2714" }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({ ticker: "KXBTCD-26AUG2714" }).reason, "HOURLY_TICKER_ON_15M_DESK");
  assert.equal(is15mDeskEvaluateAllowed({ ticker: "KXBTCPERP" }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({ ticker: "KXBTCPERP" }).reason, "PERP_TICKER_ON_15M_DESK");
  assert.equal(is15mDeskEvaluateAllowed({ ticker: "KXBTC-OLD" }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({ ticker: "KXBTC-OLD" }).reason, "UNKNOWN_SERIES_ON_15M_DESK");
  assert.deepEqual(is15mDeskEvaluateAllowed({}), { ok: true, reason: "LEGACY_NO_TICKER" });
  assert.deepEqual(is15mDeskEvaluateAllowed({ ticker: null }), { ok: true, reason: "LEGACY_NO_TICKER" });
});

test("durationBucket: ticker strings are never silently 15M", () => {
  assert.equal(durationBucket("KXBTCD"), "1H");
  assert.equal(durationBucket("KXBTCD-26AUG2714"), "1H");
  assert.equal(durationBucket("KXBTCH-26AUG0114"), "1H");
  assert.equal(durationBucket("KXBTCPERP"), "PERP");
  assert.equal(durationBucket("KXBTC15M-26AUG271615-15"), "15M");
});

test("durationForObservation: ticker wins over hardcoded 15 minutes", () => {
  assert.equal(durationForObservation({ ticker: "KXBTCD-26AUG2714", contractDurationMins: 15 }), "1H");
  assert.equal(durationForObservation({ ticker: "KXBTCPERP", contractDurationMins: 15 }), "PERP");
  assert.equal(durationForObservation({ ticker: "KXBTC15M-26AUG271615-15", contractDurationMins: 60 }), "15M");
  assert.equal(durationForObservation({ contractDurationMins: 15 }), 15);
  assert.equal(durationForObservation({}), 15);
});

test("15m-only CHEAP_SIDE is not allowed on a KXBTCD ticker even if minutes=15", () => {
  const dur = durationForObservation({ ticker: "KXBTCD-26AUG2714", contractDurationMins: 15 });
  assert.equal(dur, "1H");
  assert.equal(isStrategyAllowedForDuration("CHEAP_SIDE_15M", dur), false);
  // CONFLUENCE / BASIS_LAG are horizon-agnostic in the library. The 15m DESK
  // still refuses the ticker in evaluateEntry / evaluateStrategiesForBot.
  assert.equal(isStrategyAllowedForDuration("CONFLUENCE_CASCADE", dur), true);
  assert.equal(isStrategyAllowedForDuration("BASIS_LAG_EDGE", dur), true);
});

test("ticker series wins: KXBTCD is 1H (hourly path still eligible); PERP is not 1H-only", () => {
  const hourly = durationForObservation({ ticker: "KXBTCD-26AUG2714", contractDurationMins: 15 });
  assert.equal(hourly, "1H");
  assert.equal(isStrategyAllowedForDuration("OTM_BREAKOUT_EXPANSION", hourly), true,
    "hourly path must still be able to evaluate 1H-only when flags are on");
  assert.equal(isStrategyAllowedForDuration("CHEAP_SIDE_15M", hourly), false);
  const perp = durationForObservation({ ticker: "KXBTCPERP", contractDurationMins: 15 });
  assert.equal(perp, "PERP");
  assert.equal(isStrategyAllowedForDuration("OTM_BREAKOUT_EXPANSION", perp), false);
  const otm1h = getStrategy("OTM_BREAKOUT_EXPANSION");
  assert.ok(otm1h);
  let calls = 0;
  const original = otm1h!.evaluate;
  otm1h!.evaluate = (obs) => { calls++; return original.call(otm1h, obs); };
  try {
    evaluateAllStrategies(baseObs({ ticker: "KXBTCPERP", contractDurationMins: 15 }));
    assert.equal(calls, 0, "perp ticker must not invoke 1H-only evaluate");
  } finally {
    otm1h!.evaluate = original;
  }
});

test("15m CHEAP_SIDE evaluate() is never invoked on a KXBTCD ticker", () => {
  const cheap = getStrategy("CHEAP_SIDE_15M");
  assert.ok(cheap);
  let calls = 0;
  const original = cheap!.evaluate;
  cheap!.evaluate = (obs) => { calls++; return original.call(cheap, obs); };
  try {
    evaluateAllStrategies(baseObs({
      ticker: "KXBTCD-26AUG2714",
      contractDurationMins: 15,
    }));
    assert.equal(calls, 0, "hourly ticker must not invoke CHEAP_SIDE_15M");
    evaluateAllStrategies(baseObs({
      ticker: "KXBTC15M-26AUG271615-15",
      contractDurationMins: 15,
    }));
    // May or may not fire given the stub obs — we only require it was *eligible* to be called.
    // Don't assert calls>0 (gates may stay out). Eligibility is the duration allowlist test above.
  } finally {
    cheap!.evaluate = original;
  }
});

test("evaluateEntry source-text refuses non-15m tickers; hourly wrapper still no-ops when flag off", () => {
  assert.match(
    BOT_SRC,
    /is15mDeskEvaluateAllowed/,
    "evaluateEntry / 15m bot path must call is15mDeskEvaluateAllowed",
  );
  assert.match(
    BOT_SRC,
    /NOT_15M_PRODUCT/,
    "15m evaluateEntry must skip with NOT_15M_PRODUCT on hourly/perp tickers",
  );
  assert.match(
    BOT_SRC,
    /if \(!this\.config\.enable1HContracts\) return;/,
    "evaluateHourlyTick must no-op at the wrapper top when the 1H flag is off",
  );
});

test("backgroundPreTrade never placeOrder", () => {
  const start = BOT_SRC.indexOf("private async backgroundPreTrade()");
  assert.ok(start >= 0, "backgroundPreTrade must exist");
  const next = BOT_SRC.indexOf("\n  private ", start + 10);
  const body = next > start ? BOT_SRC.slice(start, next) : BOT_SRC.slice(start, start + 8000);
  assert.equal(/placeOrder\s*\(/.test(body), false, "backgroundPreTrade body must not call placeOrder");
  assert.match(body, /runPreTradeSim/, "backgroundPreTrade still warms the sim cache only");
});

test("production config stays 15m paper: hourly/perp flags off", { skip: !fs.existsSync(PRODUCTION_CONFIG) && "runtime .bot-config.json absent (gitignored; fresh clone/CI) — paper lock covered by hard-locks.unify.test.ts" }, () => {
  const cfg = JSON.parse(fs.readFileSync(PRODUCTION_CONFIG, "utf8")) as Record<string, unknown>;
  assert.equal(cfg.paperMode, true);
  assert.equal(cfg.autoMode, false, "disk doctrine: autoMode false (Adapt dimmer only)");
  assert.equal(cfg.enable1HContracts, false);
  assert.equal(cfg.enable1HLive, false);
  assert.equal(cfg.paperStartingBalanceCents, 31300);
});

test("hourly/perp evaluate cannot fire while flags off", () => {
  assert.equal(hourlyOrPerpEvaluateAllowed({ series: "1H", enable1HContracts: false }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({ series: "1H", enable1HContracts: false }).reason, "HOURLY_CONTRACTS_FLAG_OFF");
  assert.equal(hourlyOrPerpEvaluateAllowed({ ticker: "KXBTCD-26AUG2714", enable1HContracts: false }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({ series: "PERP" }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({ ticker: "KXBTCPERP" }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({ ticker: "KXBTCPERP" }).reason, "PERP_EVALUATE_FLAGS_OFF");
  assert.equal(hourlyOrPerpEvaluateAllowed({ series: "1H", enable1HContracts: false, enable1HLive: true }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({ series: "1H", enable1HContracts: true }).ok, true);
  assert.equal(hourlyOrPerpEvaluateAllowed({ series: "15M" }).ok, true);
  assert.equal(hourlyOrPerpEvaluateAllowed({ ticker: "KXBTC15M-26AUG271615-15" }).ok, true);
});

test("Market kalshi.tsx never auto-swaps 15M onto hourly", () => {
  const kalshi = fs.readFileSync(path.resolve(DIR, "../../../kalshi-trader/src/pages/kalshi.tsx"), "utf8");
  assert.match(kalshi, /if \(market !== '1H'\) return/);
  assert.equal(kalshi.includes("market === '15M' ? '1H'"), false, "must not auto-fallback 15M to 1H");
});

test("is15mDeskEvaluateAllowed still refuses KXBTCD/PERP when hourly flags are on", () => {
  assert.equal(is15mDeskEvaluateAllowed({
    ticker: "KXBTCD-26AUG2714", enable1HContracts: true, enable1HLive: true,
  }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({
    ticker: "KXBTCD-26AUG2714", enable1HContracts: true, enable1HLive: true,
  }).reason, "HOURLY_TICKER_ON_15M_DESK");
  assert.equal(is15mDeskEvaluateAllowed({
    ticker: "KXBTCPERP", enable1HContracts: true, enable1HLive: true,
  }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({
    ticker: "KXBTCPERP", enable1HContracts: true,
  }).reason, "PERP_TICKER_ON_15M_DESK");
  assert.equal(hourlyOrPerpEvaluateAllowed({
    ticker: "KXBTCD-26AUG2714", enable1HContracts: true,
  }).ok, true, "hourly path would be allowed — 15m desk must still refuse");
});

test("is15mDeskEvaluateAllowed consults hourlyOrPerpEvaluateAllowed; evaluateHourlyTick wires it", () => {
  const productSrc = fs.readFileSync(path.join(DIR, "15m-product.ts"), "utf8");
  const start = productSrc.indexOf("export function is15mDeskEvaluateAllowed");
  const hopFn = productSrc.indexOf("export function hourlyOrPerpEvaluateAllowed");
  const body = productSrc.slice(start, hopFn > start ? hopFn : start + 1200);
  assert.match(body, /hourlyOrPerpEvaluateAllowed\(/, "15m desk gate must call the named flag gate");
  assert.match(BOT_SRC, /hourlyOrPerpEvaluateAllowed/);
  const hourlyStart = BOT_SRC.indexOf("private async evaluateHourlyTick()");
  assert.ok(hourlyStart >= 0);
  const hourlyBody = BOT_SRC.slice(hourlyStart, hourlyStart + 900);
  assert.match(hourlyBody, /hourlyOrPerpEvaluateAllowed/);
  assert.match(hourlyBody, /if \(!this\.config\.enable1HContracts\) return;/);
});

test("resolveProductDuration: ticker wins over hostile series/minutes", () => {
  assert.equal(resolveProductDuration({ series: "15M", ticker: "KXBTCD-26AUG2714", contractDurationMins: 15 }), "1H");
  assert.equal(resolveProductDuration({ series: "15M", ticker: "KXBTCPERP", contractDurationMins: 15 }), "PERP");
  assert.equal(resolveProductDuration({ series: "1H", ticker: "KXBTC15M-26AUG271615-15" }), "15M");
  assert.equal(resolveProductDuration({ series: "1H" }), "1H");
  assert.equal(productDurationFromMinsLabel(60), "1H");
  assert.equal(productDurationFromMinsLabel(0), "PERP");
  assert.equal(productDurationFromMinsLabel(15), "15M");
});

test("hourly/perp evaluate cannot fire while flags off — ticker wins, live flag is not evaluate, PERP never", () => {
  assert.equal(hourlyOrPerpEvaluateAllowed({
    series: "15M", ticker: "KXBTCD-26AUG2714", enable1HContracts: false, enable1HLive: true,
  }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({
    series: "15M", ticker: "KXBTCD-26AUG2714", enable1HContracts: false, enable1HLive: true,
  }).reason, "HOURLY_CONTRACTS_FLAG_OFF");
  assert.equal(hourlyOrPerpEvaluateAllowed({
    series: "1H", ticker: "KXBTCPERP", enable1HContracts: true, enable1HLive: true,
  }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({
    series: "PERP", enable1HContracts: true, enable1HLive: true,
  }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({
    series: "1H", enable1HContracts: false, enable1HLive: true,
  }).ok, false, "enable1HLive must not unlock hourly evaluate");
  assert.equal(hourlyOrPerpEvaluateAllowed({
    contractDurationMins: 60, enable1HContracts: false,
  }).ok, false);
  assert.equal(hourlyOrPerpEvaluateAllowed({
    contractDurationMins: 0, enable1HContracts: true,
  }).ok, false);
});

test("is15mDeskEvaluateAllowed refuses explicit hourly/perp minutes even with no ticker", () => {
  assert.equal(is15mDeskEvaluateAllowed({ contractDurationMins: 60 }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({ contractDurationMins: 60 }).reason, "HOURLY_TICKER_ON_15M_DESK");
  assert.equal(is15mDeskEvaluateAllowed({ contractDurationMins: "PERP" }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({ contractDurationMins: 0 }).ok, false);
  assert.equal(is15mDeskEvaluateAllowed({}).ok, true);
  assert.equal(is15mDeskEvaluateAllowed({}).reason, "LEGACY_NO_TICKER");
});
