#!/usr/bin/env tsx
/**
 * GO — BACKTEST LAB v5 + CONTINUOUS POLICY REGRESSION (2026-08-22): developer/
 * CI entry point for one full regression pass — runs LEAN vs LEGACY, saves a
 * PolicySnapshot, compares against the prior LEAN baseline (PASS/WARN), and
 * writes a markdown+JSON report under docs/policy-regression/. This is the
 * "explicit command" trigger referenced in regression-runner.ts's rate-limit
 * rules (alongside the scheduled ≤1x/6h cron and policy-relevant commits).
 *
 * Never writes to live bot config — see regression-runner.ts's module doc.
 *
 * Usage: pnpm run runPolicyRegression [lookbackDays]
 */
import { runPolicyRegression } from "../src/lib/backtest-lab-v5/regression-runner.js";

async function main() {
  const lookbackDays = process.argv[2] ? Number(process.argv[2]) : undefined;
  const result = await runPolicyRegression("explicit-command", { lookbackDays });

  console.log(`\n=== Policy Regression: ${result.outcome} ===`);
  for (const r of result.reasons) console.log(`- ${r}`);
  console.log(`\nSnapshot: ${result.snapshotId}`);
  console.log(`Report:   ${result.reportPath}`);
  console.log(`Git SHA:  ${result.gitSha ?? "n/a"}`);

  process.exit(result.outcome === 'WARN' ? 1 : 0); // non-zero exit on WARN so CI can flag it, still never touches live config
}

main().catch(err => {
  console.error("[runPolicyRegression] failed:", err);
  process.exit(1);
});
