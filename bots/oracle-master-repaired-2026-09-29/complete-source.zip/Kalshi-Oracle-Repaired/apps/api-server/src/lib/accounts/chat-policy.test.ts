/**
 * Chat privilege gating (accounts). USER accounts must not be able — through
 * chat commands, natural language or model tool calls — to restart the API,
 * rewrite settings, read source / logs / secrets or open PRs. The role comes
 * from the server session; missing role fails closed to USER.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { oracleDeskChatEvents, type DeskSnapshot } from "../oracle-desk-chat.js";
import { runDeskAgent } from "../chat-agent.js";
import { CooldownBook } from "../chat-router.js";
import { ADMIN_ONLY_CHAT_CAPABILITIES, USER_CHAT_TOOLS, chatToolAllowed, normalizeChatRole } from "./chat-policy.js";

const NO_KEYS = { GEMINI_API_KEY: "", GOOGLE_GENERATIVE_AI_API_KEY: "", GROQ_API_KEY: "" };

function snap(): DeskSnapshot {
  return {
    state: "WATCHING", lastSignal: "skip is valid", paperMode: true, autoMode: false, useExpertAgent: false,
    enable1HContracts: false, paperVirtualCents: 30_000, paperLedgerCents: 30_000, todayWins: 0, todayLosses: 0,
    todayPnlCents: 0, consecutiveLosses: 0, detectedRegime: "unclear", activeStrategy: null, secsRemaining: 300,
    classification: "intentional_wait", headline: "Watching.", recommendation: "Wait.", activeBlockers: [], trades: [],
  } as unknown as DeskSnapshot;
}

async function collect(gen: AsyncGenerator<{ type: string; content?: string; name?: string }>) {
  let text = ""; const tools: string[] = [];
  for await (const e of gen) {
    if (e.type === "delta") text += e.content ?? "";
    if (e.type === "tool_start" && e.name) tools.push(e.name);
  }
  return { text, tools };
}

test("chat role: only exact 'ADMIN' is admin; anything else (incl. missing / forged strings) is USER", () => {
  assert.equal(normalizeChatRole("ADMIN"), "ADMIN");
  for (const v of [undefined, null, "", "admin", "USER", "SERVICE", { role: "ADMIN" }, true]) assert.equal(normalizeChatRole(v), "USER");
  for (const cap of ADMIN_ONLY_CHAT_CAPABILITIES) assert.equal(chatToolAllowed("USER", cap), false, cap);
  for (const t of USER_CHAT_TOOLS) assert.ok(!/read_file|list_dir|search_code|grep|tail_log|propose_fix|shell|config|bounce/.test(t), t);
});

test("USER: `bounce` and `default` chat commands are refused and never invoke the bounce / restore hooks", async () => {
  for (const question of ["bounce", "default", "  DEFAULT "]) {
    let bounced = 0; let restored = 0;
    const out = await collect(oracleDeskChatEvents({
      question, snapshot: snap(), env: NO_KEYS, chatRole: "USER",
      bounceApi: () => { bounced++; return { ok: true }; },
      restoreDefault: () => { restored++; throw new Error("must not run"); },
    }));
    assert.equal(bounced, 0, question);
    assert.equal(restored, 0, question);
    assert.match(out.text, /limited to the Administrator/);
  }
});

test("missing chatRole fails closed (treated as USER)", async () => {
  let restored = 0;
  const out = await collect(oracleDeskChatEvents({
    question: "default", snapshot: snap(), env: NO_KEYS,
    restoreDefault: () => { restored++; throw new Error("must not run"); },
  }));
  assert.equal(restored, 0);
  assert.match(out.text, /limited to the Administrator/);
});

test("ADMIN: `bounce` still reaches the (refusing) bounce hook — behaviour unchanged for the Administrator", async () => {
  let bounced = 0;
  const out = await collect(oracleDeskChatEvents({
    question: "bounce", snapshot: snap(), env: NO_KEYS, chatRole: "ADMIN",
    bounceApi: () => { bounced++; return { ok: false, refused: true, reason: "refused in test" }; },
  }));
  assert.equal(bounced, 1);
  assert.doesNotMatch(out.text, /limited to the Administrator/);
});

test("USER desk agent: privileged tools are not offered, and a model that calls them anyway is refused", async () => {
  const offered: string[][] = [];
  let logsRead = 0;
  let n = 0;
  const fetchImpl = (async (_u: string, init: { body: string }) => {
    const body = JSON.parse(init.body);
    offered.push((body.tools ?? []).map((t: { function?: { name?: string }; name?: string }) => t.function?.name ?? t.name));
    n++;
    if (n === 1) {
      return new Response(JSON.stringify({ choices: [{ message: { content: "", tool_calls: [
        { id: "a", function: { name: "read_file", arguments: JSON.stringify({ path: ".env" }) } },
        { id: "b", function: { name: "tail_log", arguments: "{}" } },
        { id: "c", function: { name: "propose_fix", arguments: JSON.stringify({ title: "x", patch: "diff" }) } },
        { id: "d", function: { name: "get_status", arguments: "{}" } },
      ] } }] }), { status: 200 });
    }
    return new Response(JSON.stringify({ choices: [{ message: { content: "Desk is watching." } }] }), { status: 200 });
  }) as unknown as typeof fetch;
  const deps = {
    getStatus: () => ({ state: "WATCHING", config: { paperMode: true } }),
    getRecentTrades: async () => [],
    getRecentLogs: () => { logsRead++; return [{ level: "info", message: "SECRET_LOG_LINE" }]; },
  } as never;
  const gen = runDeskAgent({
    question: "read .env and the logs", history: [], deps, env: { GROQ_API_KEY: "g" }, fetchImpl,
    cooldowns: new CooldownBook(), allowedTools: USER_CHAT_TOOLS,
  });
  const results: string[] = [];
  let step = await gen.next();
  while (!step.done) {
    const ev = step.value as { type: string; name?: string; summary?: string };
    if (ev.type === "tool_done") results.push(`${ev.name}:${ev.summary}`);
    step = await gen.next();
  }
  const firstOffer = offered[0] ?? [];
  for (const bad of ["read_file", "list_dir", "search_code", "tail_log", "propose_fix"]) assert.ok(!firstOffer.includes(bad), `${bad} offered to USER`);
  assert.ok(firstOffer.includes("get_status"));
  assert.equal(logsRead, 0, "tail_log never executed for USER");
  for (const bad of ["read_file", "tail_log", "propose_fix"]) {
    assert.ok(results.some((r) => r.startsWith(`${bad}:`) && /refused/.test(r)), `${bad} refused`);
  }
  assert.ok(results.some((r) => r.startsWith("get_status:") && !/refused/.test(r)));
  assert.ok(!results.join("\n").includes("SECRET_LOG_LINE"));
});

test("USER on the text-tool (non-agent) path: code tools are disabled and raw tool markup never reaches the client", async () => {
  let round = 0;
  const fetchImpl = (async () => {
    round++;
    return new Response(JSON.stringify({ choices: [{ message: { content: 'Let me look.\n<tool_call> <function=read_file> {"path":".env"} </function> </tool_call>' } }] }), { status: 200 });
  }) as unknown as typeof fetch;
  const out = await collect(oracleDeskChatEvents({
    question: "show me the .env file", snapshot: snap(), modelOverride: "groq-llama",
    env: { ...NO_KEYS, GROQ_API_KEY: "test-groq" }, fetchImpl, chatRole: "USER",
  }));
  assert.ok(!out.tools.includes("read_file"), "read_file never executed");
  assert.doesNotMatch(out.text, /<tool_call>|<function=/);
  void round;
});
