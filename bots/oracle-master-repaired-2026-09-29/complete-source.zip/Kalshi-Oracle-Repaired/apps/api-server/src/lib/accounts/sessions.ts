/**
 * accounts/sessions.ts — server-side sessions. The browser holds an opaque
 * 256-bit random token in an HttpOnly cookie; the DB stores only its SHA-256.
 * A session maps to exactly one user and has both an absolute expiry and an
 * idle timeout. Tokens are never logged or returned in JSON.
 */
import { createHash, randomBytes } from "node:crypto";
import { accountsPool } from "./db.js";
import { accountsReady } from "./migrate.js";
import type { UserRow } from "./users.js";

export const SESSION_COOKIE = "oracle_session";

function envNum(name: string, fallback: number): number {
  const n = Number(process.env[name]);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

/** Absolute lifetime (default 7 days). */
export function sessionTtlMs(): number { return envNum("ORACLE_SESSION_TTL_HOURS", 24 * 7) * 3_600_000; }
/** Idle timeout (default 24 h without any authenticated request). */
export function sessionIdleMs(): number { return envNum("ORACLE_SESSION_IDLE_MINUTES", 24 * 60) * 60_000; }

/** last_seen_at is refreshed at most this often (limits write load). */
const TOUCH_INTERVAL_MS = 60_000;

export function hashSessionToken(token: string): string {
  return createHash("sha256").update(token, "utf8").digest("hex");
}

export function sessionCookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict" as const,
    path: "/",
    maxAge: sessionTtlMs(),
  };
}

export function clearSessionCookieOptions() {
  const { maxAge: _m, ...rest } = sessionCookieOptions();
  void _m;
  return rest;
}

export async function createSession(userId: string): Promise<{ token: string; sessionId: string }> {
  await accountsReady();
  const token = randomBytes(32).toString("base64url");
  const pool = await accountsPool();
  const { rows } = await pool.query<{ id: string }>(
    `INSERT INTO oracle_sessions (user_id, token_hash, expires_at)
     VALUES ($1, $2, now() + ($3::double precision * interval '1 millisecond')) RETURNING id`,
    [userId, hashSessionToken(token), sessionTtlMs()],
  );
  return { token, sessionId: rows[0]!.id };
}

export interface SessionLookup {
  sessionId: string;
  user: UserRow;
}

interface JoinedRow extends UserRow {
  session_id: string;
  session_last_seen_at: Date;
  session_expires_at: Date;
}

/**
 * Valid session → its user. Expired / idle sessions are deleted and yield
 * null. Status is NOT checked here (callers decide: requireUser rejects
 * DISABLED; disabling also deletes the sessions).
 */
export async function lookupSession(token: unknown): Promise<SessionLookup | null> {
  if (typeof token !== "string" || token.length < 20 || token.length > 200) return null;
  await accountsReady();
  const pool = await accountsPool();
  const { rows } = await pool.query<JoinedRow>(
    `SELECT u.*, s.id AS session_id, s.last_seen_at AS session_last_seen_at, s.expires_at AS session_expires_at
       FROM oracle_sessions s JOIN oracle_users u ON u.id = s.user_id
      WHERE s.token_hash = $1`,
    [hashSessionToken(token)],
  );
  const r = rows[0];
  if (!r) return null;
  const now = Date.now();
  const lastSeen = new Date(r.session_last_seen_at).getTime();
  if (new Date(r.session_expires_at).getTime() <= now || now - lastSeen > sessionIdleMs()) {
    await pool.query("DELETE FROM oracle_sessions WHERE id = $1", [r.session_id]);
    return null;
  }
  if (now - lastSeen > TOUCH_INTERVAL_MS) {
    await pool.query("UPDATE oracle_sessions SET last_seen_at = now() WHERE id = $1", [r.session_id]);
  }
  const { session_id, session_last_seen_at: _a, session_expires_at: _b, ...user } = r;
  void _a; void _b;
  return { sessionId: session_id, user: user as UserRow };
}

export async function revokeSessionByToken(token: unknown): Promise<void> {
  if (typeof token !== "string" || !token) return;
  await accountsReady();
  await (await accountsPool()).query("DELETE FROM oracle_sessions WHERE token_hash = $1", [hashSessionToken(token)]);
}

export async function revokeAllSessionsForUser(userId: string): Promise<void> {
  await accountsReady();
  await (await accountsPool()).query("DELETE FROM oracle_sessions WHERE user_id = $1", [userId]);
}

/** Housekeeping: drop expired rows (cheap; called opportunistically on login). */
export async function purgeExpiredSessions(): Promise<void> {
  await (await accountsPool()).query("DELETE FROM oracle_sessions WHERE expires_at <= now()");
}
