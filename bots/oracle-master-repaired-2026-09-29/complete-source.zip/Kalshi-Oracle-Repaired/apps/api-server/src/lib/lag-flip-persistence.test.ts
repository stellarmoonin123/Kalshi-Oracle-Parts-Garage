/**
 * LAG_FLIP_EXIT persistence + min-hold (overnight score-lift 2026-08-27).
 *
 * Paper tape tonight: LATE_ENTRY YES 5x 53¢ LAG_FLIP_EXIT in ~3s, then candle
 * settled YES 100 (−37¢). Do not disable lag-flip. Do not cut EV.
 * Require BOTH 20s since fill AND enough confirming samples that 500ms ticks
 * cannot satisfy the persistence gate in <~8s.
 */
import "./strategy-learner-test-isolation.js";
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  shouldLagFlipExit,
  LAG_FLIP_MIN_HOLD_MS,
  LAG_FLIP_MIN_SAMPLES,
  LAG_FLIP_CONSECUTIVE_BOTH_AGAINST,
} from "./lag-flip.js";
import { tradingBot } from "./trading-bot.js";
import { recordOutcome, getAllStats } from "./strategy-learner.js";
import { classifyExitClass } from "./settlement-helpers.js";

tradingBot.stop();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const botSource = fs.readFileSync(path.join(__dirname, "trading-bot.ts"), "utf8");

test("LAG_FLIP floors: 20s min hold, samples high enough that 500ms ticks cannot fire in <~8s", () => {
  assert.equal(LAG_FLIP_MIN_HOLD_MS, 20_000);
  assert.ok(LAG_FLIP_MIN_SAMPLES >= 8, "must be well above the old 3-tick (~1.5s) gate");
  assert.ok(
    LAG_FLIP_MIN_SAMPLES * 500 >= 8_000,
    `${LAG_FLIP_MIN_SAMPLES} samples at 500ms idle = ${LAG_FLIP_MIN_SAMPLES * 500}ms, need ≥8s`,
  );
});

test("a lag flip at t=3s does not exit even with many confirming samples", () => {
  assert.equal(
    shouldLagFlipExit({ samplesAgainst: 100, msSinceFill: 3_000 }),
    false,
    "3s paper-tape leak must be killed by the min-hold regardless of sample count",
  );
  assert.equal(
    shouldLagFlipExit({ samplesAgainst: LAG_FLIP_MIN_SAMPLES, msSinceFill: LAG_FLIP_MIN_HOLD_MS - 1 }),
    false,
  );
});

test("a sustained flip after 20s + enough samples does exit", () => {
  assert.equal(
    shouldLagFlipExit({ samplesAgainst: LAG_FLIP_MIN_SAMPLES, msSinceFill: LAG_FLIP_MIN_HOLD_MS }),
    true,
  );
  assert.equal(
    shouldLagFlipExit({ samplesAgainst: LAG_FLIP_MIN_SAMPLES, msSinceFill: 20_000 }),
    true,
  );
});

test("20s elapsed with only 3 confirming samples does not exit (old gate is dead)", () => {
  assert.equal(
    shouldLagFlipExit({ samplesAgainst: 3, msSinceFill: 20_000 }),
    false,
  );
  assert.equal(
    shouldLagFlipExit({ samplesAgainst: LAG_FLIP_MIN_SAMPLES - 1, msSinceFill: 20_000 }),
    false,
  );
});

test("checkLagFlip still fail-opens on missing/stale lag (isLagAgainstSide, not against)", () => {
  const start = botSource.indexOf("private isLagAgainstSide(");
  assert.ok(start >= 0);
  const body = botSource.slice(start, start + 900);
  assert.ok(body.includes("basisTracker.isFairValueStale()"));
  assert.ok(body.includes("return false"));
  assert.match(body, /Missing\/stale lag data always returns false/);
  const flipStart = botSource.indexOf("private async checkLagFlip(");
  const flip = botSource.slice(flipStart, flipStart + 2200);
  assert.ok(flip.includes("shouldLagFlipExit"));
  assert.ok(flip.includes("consecutiveBothAgainst"));
  assert.ok(flip.includes("lagFlipBothAgainstSecStreak"));
  assert.ok(!/basisFlipAgainstTicks < 3/.test(flip));
  // Persistence samples live in tickOpenThesisPersistence (lead+BRTI both-against).
  const tickStart = botSource.indexOf("private tickOpenThesisPersistence(");
  const tick = botSource.slice(tickStart, tickStart + 1600);
  assert.ok(tick.includes("this.isLagAgainstSide("));
  assert.ok(tick.includes("leadAgainstSide"));
  assert.ok(tick.includes("nextLagFlipBothAgainstStreak"));
});

test("risk_exit LAG_FLIP_EXIT with negative PnL does not increment strategy WR", () => {
  const id = `LAG_FLIP_WR_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  recordOutcome(id, true, 40, 0.70, 15, `${id}:seed`, "strategy");
  const before = getAllStats().find(r => r.strategyId === id)!;
  assert.equal(classifyExitClass("LAG_FLIP_EXIT"), "risk_exit");
  recordOutcome(id, false, -80, 0.70, 15, `${id}:lag`, classifyExitClass("LAG_FLIP_EXIT"));
  const after = getAllStats().find(r => r.strategyId === id)!;
  assert.equal(after.trades, before.trades, "LAG_FLIP_EXIT must not increment trades");
  assert.equal(after.losses, before.losses);
  assert.equal(after.winRate, before.winRate);
  assert.equal(after.learningWeight, before.learningWeight);
});

test("PATH_RIDE #725: 3 consecutive both-against + lagProven + 20s exits; unproven HOLDs", () => {
  assert.equal(LAG_FLIP_CONSECUTIVE_BOTH_AGAINST, 3);
  assert.equal(
    shouldLagFlipExit({ consecutiveBothAgainst: 3, msSinceFill: 20_000, lagProven: true }),
    true,
  );
  assert.equal(
    shouldLagFlipExit({ consecutiveBothAgainst: 3, msSinceFill: 20_000, lagProven: false }),
    false,
    "unproven must HOLD",
  );
  assert.equal(
    shouldLagFlipExit({ consecutiveBothAgainst: 1, msSinceFill: 31_000, lagProven: true }),
    false,
    "1-tick twitch must not exit",
  );
  assert.equal(
    shouldLagFlipExit({ consecutiveBothAgainst: 3, msSinceFill: 3_000, lagProven: true }),
    false,
    "still need ≥20s hold",
  );
});
