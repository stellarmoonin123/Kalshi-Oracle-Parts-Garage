import assert from "node:assert/strict";
import test from "node:test";
import { shouldForceReconnectOnSilence } from "./kalshi-ws.js";

/**
 * GO EXECUTION INTEGRITY BATCH — A5 (2026-08-16) regression coverage.
 *
 * BUG (pre-fix): the 24/7 heartbeat judged WS silence off `this.latest.ts`,
 * a timestamp the REST backstop poll (pollRestPrices, every 1-3s) ALSO
 * overwrote with a fresh Date.now() regardless of whether the WS itself was
 * still delivering messages. A WebSocket connection that stays
 * `readyState === OPEN` with no error/close event but has simply stopped
 * pushing data (a silent hang — NAT timeout, carrier-grade firewall,
 * exchange-side silent drop) would never trip the reconnect, because the
 * healthy REST poll kept `latest.ts` looking perfectly fresh underneath it.
 *
 * Fix: silence is now judged off `_lastWsMessageTs`, a clock advanced ONLY
 * by real WS messages (see kalshi-ws.ts `handleMessage`). These tests cover
 * the pure decision function extracted from the heartbeat's setInterval body.
 */

test("A5: WS silent for >12s (real socket clock) triggers a forced reconnect", () => {
  const now = 1_000_000_000;
  const lastWsMessageTs = now - 13_000;
  assert.equal(shouldForceReconnectOnSilence(lastWsMessageTs, now), true);
});

test("A5: WS message received within the last 12s does not trigger a reconnect", () => {
  const now = 1_000_000_000;
  const lastWsMessageTs = now - 10_000;
  assert.equal(shouldForceReconnectOnSilence(lastWsMessageTs, now), false);
});

test("A5: exactly at the 12s boundary is not yet silence (strict >)", () => {
  const now = 1_000_000_000;
  const lastWsMessageTs = now - 12_000;
  assert.equal(shouldForceReconnectOnSilence(lastWsMessageTs, now), false);
});

test("A5: never having received a WS message yet (null) does not force-reconnect from this check", () => {
  const now = 1_000_000_000;
  assert.equal(shouldForceReconnectOnSilence(null, now), false);
});

test("A5: a REST-only refreshed timestamp must never be passed in as lastWsMessageTs — this function has no way to distinguish sources, so the discipline lives at the one call site (handleMessage is the only writer of _lastWsMessageTs). Documented via the 90s-silence case still firing even while REST polling (simulated by the caller) would have kept latest.ts fresh.", () => {
  const now = 1_000_000_000;
  // Simulates: WS died 5 minutes ago (_lastWsMessageTs frozen), but a
  // REST-sourced `latest.ts` would have looked fresh (e.g. now - 1000) the
  // whole time. The fix must still fire off the real WS clock.
  const lastWsMessageTs = now - 5 * 60_000;
  const wouldBeMaskedLatestTs = now - 1_000; // what latest.ts would show if it were (wrongly) used
  assert.notEqual(lastWsMessageTs, wouldBeMaskedLatestTs);
  assert.equal(shouldForceReconnectOnSilence(lastWsMessageTs, now), true);
});
