/**
 * market-state.ts — P3: MARKETSTATE + FAMILY POLICY (ADAPTIVE TACTICS)
 *
 * PROBLEM: fixed $/min velocity gates and fixed-cents/fixed-% distance gates
 * were tuned for one tape speed. On a quiet day 24$/min is a real move; on a
 * violent day it's noise. This module computes ONE shared, tape-speed-
 * normalized snapshot per tick — MarketState — so every strategy family,
 * BotStatus, and (in a later phase) ARIA read the SAME numbers instead of
 * each re-deriving their own ad-hoc scale.
 *
 * This module is pure/computational: it does not fetch data, hold its own
 * history, or maintain a bot-lifetime singleton. trading-bot.ts owns the
 * actual velocity/price history (velocityHistory ring buffer, velocityEma)
 * and calls computeMarketState() once per tick per evaluation path (15m and
 * 1h), passing in what it already tracks. This keeps the module trivially
 * unit-testable and keeps "one owner of live state" (trading-bot.ts) intact.
 *
 * Explicitly OUT of scope for this module (P3 locks, do not touch here):
 *   - EV/PATH/RICH/9%/SEV1 floors — untouched, this module never feeds EV/Kelly.
 *   - Regime engine internals (regime-engine.ts) — reused via getRegime(),
 *     never replaced or reimplemented.
 *   - ARIA guide actions / desk API / LiquidityPolicy — later phases.
 *   - confidence/signalQuality as a probability — MarketState fields are
 *     scale/z-score inputs to FAMILY POLICY gates only, never a `p` for
 *     EV/Kelly.
 */

import { getRegime, type RegimeId } from './regime-engine.js';
import { getCurrentSessionMode, type SessionMode } from './market-intelligence.js';
import { computeVolumeScore } from './volume-risk.js';
import type { StrategyObservation } from './strategy-library.js';

// ── Tunable constants (documented in the P3 attestation) ───────────────────
// velScale floor/cap: even a dead-quiet tape is treated as at least this many
// $/min of "normal" noise (avoids a near-zero denominator turning tiny real
// moves into absurd z-scores); even a violent tape is capped so one outlier
// spike can't blow the scale out to where every strategy's gate goes silent.
export const VEL_SCALE_FLOOR_DOL_PER_MIN = 12;
export const VEL_SCALE_CAP_DOL_PER_MIN   = 120;

// rangeScale floor: a proxy $ range/ATR value below which we don't trust the
// tape enough to divide by it (same rationale as the velocity floor above).
export const RANGE_SCALE_FLOOR_DOL = 15;

// EMA smoothing constant for zVel's velocity input (κ in the P3 spec). Mid of
// the spec's suggested 0.30-0.40 band — smooths tick noise while still
// tracking a genuine velocity regime change within a handful of ticks.
export const VELOCITY_EMA_ALPHA = 0.30;

// Blend weights for the multi-horizon velScale median (must sum to 1.0).
const VEL_SCALE_WEIGHT_30M    = 0.50;
const VEL_SCALE_WEIGHT_2H     = 0.30;
const VEL_SCALE_WEIGHT_SESSION = 0.20;

// Minimum distinct 10s-sampled points in the 30m window before velScale is
// considered trustworthy (below this, stale=true — fail-closed, no synthetic
// calm value is invented). ~3 minutes of samples at the existing 10s cadence.
const MIN_SAMPLES_FOR_FRESH = 18;

export interface VelocitySample {
  t: number; // epoch ms
  v: number; // signed $/min at that sample
}

export interface MarketState {
  /** Robust multi-horizon $/min scale for "normal" velocity right now. Floored/capped. */
  velScale:   number;
  /** Signed EMA(v1) / max(velScale, ε) — how many "velScale units" fast the tape is moving, signed. */
  zVel:       number;
  /** Robust $ range/ATR-based scale, floored. Used for distance-from-strike checks in range units. */
  rangeScale: number;
  /** Existing 0-1 volume-risk score (volume-risk.ts computeVolumeScore().V), passed through unchanged. */
  volScale:   number;
  /** Existing sticky/hysteresis regime id — reused as-is, never recomputed here. */
  regime:     RegimeId;
  /** Existing Hunt/Harvest session mode — reused as-is. */
  session:    SessionMode;
  /** secsRemaining / periodSecs, clamped to [0,1]. 1 = full period left, 0 = at settlement. */
  tau:        number;
  /**
   * True when there isn't enough velocity history yet to trust velScale/zVel
   * (e.g. just after startup). Fail-closed: callers must NOT invent a
   * synthetic "calm" scale when stale — family-policy gates fall back to
   * their pre-P3 fixed thresholds instead of trusting a thin sample.
   */
  stale:      boolean;
}

function median(xs: number[]): number {
  if (xs.length === 0) return 0;
  const s = [...xs].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 === 1 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

function clamp(x: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, x));
}

/**
 * Robust multi-horizon velScale from a caller-owned velocity history ring
 * buffer (10s-sampled |v|, per trading-bot.ts's existing velocityHistory).
 * Blends 30m/2h/session medians of |v| so a short violent spike doesn't
 * dominate, and a long quiet stretch doesn't over-shrink the scale either.
 * "Session" here is approximated as the full retained history (trading-bot.ts
 * retains several hours) rather than a calendar Hunt/Harvest boundary — see
 * P3 attestation for this documented choice.
 */
export function computeVelScale(history: readonly VelocitySample[], now: number = Date.now()): { velScale: number; stale: boolean } {
  const abs30m = history.filter(p => p.t >= now - 30 * 60_000).map(p => Math.abs(p.v));
  const abs2h  = history.filter(p => p.t >= now - 120 * 60_000).map(p => Math.abs(p.v));
  const absAll = history.map(p => Math.abs(p.v));

  const stale = abs30m.length < MIN_SAMPLES_FOR_FRESH;

  // Graceful degradation: an empty longer window falls back to the shorter
  // one rather than contributing a phantom 0 to the blend.
  const m30      = median(abs30m);
  const m2h      = median(abs2h.length > 0 ? abs2h : abs30m);
  const mSession = median(absAll.length > 0 ? absAll : abs30m);

  const blended = VEL_SCALE_WEIGHT_30M * m30 + VEL_SCALE_WEIGHT_2H * m2h + VEL_SCALE_WEIGHT_SESSION * mSession;
  const velScale = clamp(blended, VEL_SCALE_FLOOR_DOL_PER_MIN, VEL_SCALE_CAP_DOL_PER_MIN);
  return { velScale, stale };
}

/** Pure EMA step for the zVel input. Caller (trading-bot.ts) owns the persisted `prevEma` across ticks. */
export function updateVelocityEma(prevEma: number | null, v1: number, alpha: number = VELOCITY_EMA_ALPHA): number {
  if (prevEma === null || !Number.isFinite(prevEma)) return v1;
  return alpha * v1 + (1 - alpha) * prevEma;
}

/** Signed z-score of the EMA-smoothed velocity against the current velScale. */
export function computeZVel(velocityEma: number, velScale: number): number {
  return velocityEma / Math.max(velScale, 1e-6);
}

/**
 * Robust $ range/ATR proxy. Reuses the existing atrPct enrichment (% of
 * price) already computed by market-intelligence.ts — converts it to a $
 * value scaled to currentPrice so distance-from-strike checks (which are $
 * deltas) can be expressed in "range units" via distanceInRangeUnits().
 * Falls back to a conservative 0.15% assumption when atrPct hasn't warmed up
 * yet (matches volume-risk.ts's own neutral-atrPct convention).
 */
export function computeRangeScale(atrPct: number | undefined, currentPrice: number): number {
  const pct = atrPct ?? 0.15;
  const dollars = (pct / 100) * currentPrice;
  return Math.max(dollars, RANGE_SCALE_FLOOR_DOL);
}

export function computeTau(secsRemaining: number, periodSecs: number): number {
  if (periodSecs <= 0) return 0;
  return clamp(secsRemaining / periodSecs, 0, 1);
}

export interface ComputeMarketStateInput {
  velocityHistory: readonly VelocitySample[];
  velocityEma:     number | null;
  obs:             StrategyObservation;
  periodSecs:      number;
  now?:            number;
}

/** Assembles the full per-tick MarketState from caller-owned inputs. */
export function computeMarketState(input: ComputeMarketStateInput): MarketState {
  const { velocityHistory, velocityEma, obs, periodSecs } = input;
  const now = input.now ?? Date.now();

  const { velScale, stale } = computeVelScale(velocityHistory, now);
  const zVel = computeZVel(velocityEma ?? obs.velocityDolPerMin, velScale);
  const rangeScale = computeRangeScale(obs.atrPct, obs.currentPrice);
  const volScale = computeVolumeScore(obs).V;

  return {
    velScale,
    zVel,
    rangeScale,
    volScale,
    regime: getRegime(),
    session: getCurrentSessionMode(),
    tau: computeTau(obs.secsRemaining, periodSecs),
    stale,
  };
}
