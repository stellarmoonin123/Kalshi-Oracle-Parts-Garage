/**
 * accounts/middleware.ts — central authentication / authorisation for /api.
 *
 * Default-deny: `accountsApiGate` is mounted on /api BEFORE the router, so
 * every route requires a valid session unless it is on the tiny explicit
 * PUBLIC allowlist. Identity and role come ONLY from the server-side session
 * row (never from client-supplied userId / role / isAdmin). There is no
 * loopback, proxy-header or frontend bypass.
 *
 * Non-session principals (both constant-time compared):
 *   - in-process SELF calls (desk-lock.ts per-process random token, never
 *     leaves process memory) → INTERNAL, treated like ADMIN;
 *   - ORACLE_SERVICE_TOKEN (OFF unless set, ≥32 chars) → SERVICE, read-only
 *     (GET/HEAD) on non-admin routes, for local scripts such as ops/recon.
 */
import { createHash, timingSafeEqual } from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import { isDeskInternalRequest } from "../desk-lock.js";
import { lookupSession, SESSION_COOKIE } from "./sessions.js";
import { toPublicUser, type PublicUser, type Role, type UserRow } from "./users.js";

export type AuthContext =
  | { kind: "user"; user: UserRow; sessionId: string }
  | { kind: "internal" }
  | { kind: "service" };

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      oracleAuth?: AuthContext;
    }
  }
}

export const AUTH_REQUIRED = { error: "Authentication required", authRequired: true } as const;
export const ADMIN_REQUIRED = { error: "Administrator access required", adminRequired: true } as const;
export const PASSWORD_CHANGE_REQUIRED = { error: "You must change your temporary password before continuing.", mustChangePassword: true } as const;

// ── Route policy (paths are relative to the /api mount) ─────────────────────

/** Reachable with no session at all. Keep tiny. */
const PUBLIC_ROUTES: ReadonlyArray<[method: string, path: string]> = [
  ["GET", "/healthz"],          // Fly health check (no secrets; see health.ts)
  ["GET", "/public/status"],
  ["POST", "/auth/login"],
  ["POST", "/auth/logout"],     // idempotent; clears cookie
  ["GET", "/auth/me"],          // answers {authenticated:false} without a session
];

/** While mustChangePassword is set, ONLY these are reachable. */
const MUST_CHANGE_ALLOWED: ReadonlyArray<[string, string]> = [
  ["GET", "/auth/me"],
  ["POST", "/auth/change-password"],
  ["POST", "/auth/logout"],
];

/** State-changing requests an ordinary USER may make (own chat + own account). */
const USER_WRITE_ALLOW: ReadonlyArray<RegExp> = [
  /^\/auth\/change-password$/,
  /^\/account\/profile$/,
  /^\/chat$/,                                   // read-only snapshot LLM
  /^\/chat\/conversations$/,
  /^\/chat\/conversations\/[^/]+$/,
  /^\/chat\/conversations\/[^/]+\/messages$/,
  /^\/agent\/chat$/,                            // role-gated inside (chat-policy.ts)
  /^\/analyst$/,                                // pure report composer, no side effects
];

/** Reads that expose credentials status, raw logs, money flows or ops tooling. */
const ADMIN_READ: ReadonlyArray<RegExp> = [
  /^\/admin(\/|$)/,
  /^\/kalshi\/(config|balance|orders)$/,
  /^\/bot\/logs$/,
  /^\/bot\/cash-flow$/,
  /^\/bot\/organ-debug$/,
  /^\/tasks(\/|$)/,
  /^\/self-healing(\/|$)/,
  /^\/diagnostics(\/|$)/,
  /^\/research-memory(\/|$)/,
];

const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

function normPath(p: string): string {
  const s = p.replace(/\/+$/, "");
  return s === "" ? "/" : s;
}

function matchPair(list: ReadonlyArray<[string, string]>, method: string, path: string): boolean {
  const m = method === "HEAD" ? "GET" : method;
  return list.some(([lm, lp]) => lm === m && lp === path);
}

export function isPublicRoute(method: string, path: string): boolean {
  return matchPair(PUBLIC_ROUTES, method.toUpperCase(), normPath(path));
}

/** True when `method path` needs role ADMIN (everything that writes, unless allow-listed). */
export function routeRequiresAdmin(method: string, path: string): boolean {
  const m = method.toUpperCase();
  const p = normPath(path);
  if (ADMIN_READ.some((re) => re.test(p))) return true;
  if (SAFE_METHODS.has(m)) return false;
  return !USER_WRITE_ALLOW.some((re) => re.test(p));
}

// ── CSRF (SameSite=Strict cookie + Fetch-Metadata / Origin check) ────────────

function trustedOrigins(): Set<string> {
  const out = new Set<string>();
  const add = (raw: string | undefined) => {
    for (const part of (raw ?? "").split(",")) {
      const v = part.trim().replace(/\/$/, "");
      if (!v) continue;
      out.add(v.startsWith("http://") || v.startsWith("https://") ? v : `https://${v}`);
    }
  };
  add(process.env.CORS_ORIGIN);
  add(process.env.PUBLIC_URL);
  add(process.env.ORACLE_TRUSTED_ORIGINS);
  if (process.env.FLY_APP_NAME) out.add(`https://${process.env.FLY_APP_NAME}.fly.dev`);
  return out;
}

function originMatchesHost(origin: string, req: Request): boolean {
  let host: string;
  try { host = new URL(origin).host.toLowerCase(); } catch { return false; }
  const candidates = [req.get("host"), req.get("x-forwarded-host")]
    .flatMap((h) => (h ?? "").split(","))
    .map((h) => h.trim().toLowerCase())
    .filter(Boolean);
  return candidates.includes(host);
}

/**
 * Returns a reason string when an unsafe request looks cross-site, else null.
 * Browsers always attach Sec-Fetch-Site and/or Origin to cross-site POSTs;
 * non-browser clients (curl, scripts) send neither and cannot ride a
 * victim's cookie, so they are not a CSRF vector.
 */
export function csrfRejection(req: Request): string | null {
  if (SAFE_METHODS.has(req.method.toUpperCase())) return null;
  const origin = req.get("origin");
  const trusted = origin && origin !== "null" && trustedOrigins().has(origin.replace(/\/$/, ""));
  const site = req.get("sec-fetch-site")?.toLowerCase();
  if (site && site !== "same-origin" && site !== "none" && !trusted) return "cross-site request blocked";
  if (origin) {
    if (origin === "null") return "opaque origin blocked";
    if (!trusted && !originMatchesHost(origin, req) && site !== "same-origin") return "origin mismatch";
  }
  return null;
}

export function csrfGuard(req: Request, res: Response, next: NextFunction): void {
  const why = csrfRejection(req);
  if (why) {
    res.status(403).json({ error: "Request blocked (cross-site).", csrf: true });
    return;
  }
  next();
}

// ── Service token (OFF by default) ──────────────────────────────────────────

const sha = (s: string) => createHash("sha256").update(s, "utf8").digest();

function isServiceTokenRequest(req: Request): boolean {
  const configured = (process.env.ORACLE_SERVICE_TOKEN ?? "").trim();
  if (configured.length < 32) return false;
  const bearer = /^Bearer\s+(\S+)\s*$/i.exec(req.get("authorization") ?? "")?.[1];
  if (!bearer) return false;
  return timingSafeEqual(sha(bearer), sha(configured));
}

// ── Session resolution ──────────────────────────────────────────────────────

/** Resolve the principal for this request (does not reject). */
export async function resolveAuth(req: Request): Promise<AuthContext | null> {
  if (req.oracleAuth) return req.oracleAuth;
  if (isDeskInternalRequest(req)) return (req.oracleAuth = { kind: "internal" });
  const token = (req as Request & { cookies?: Record<string, string> }).cookies?.[SESSION_COOKIE];
  if (token) {
    const found = await lookupSession(token);
    if (found && found.user.status === "ACTIVE") {
      return (req.oracleAuth = { kind: "user", user: found.user, sessionId: found.sessionId });
    }
  }
  if (isServiceTokenRequest(req)) return (req.oracleAuth = { kind: "service" });
  return null;
}

export function authRole(ctx: AuthContext | null | undefined): Role | "SERVICE" | null {
  if (!ctx) return null;
  if (ctx.kind === "internal") return "ADMIN";
  if (ctx.kind === "service") return "SERVICE";
  return ctx.user.role;
}

/** The authenticated human user, if any. */
export function currentUser(req: Request): UserRow | null {
  return req.oracleAuth?.kind === "user" ? req.oracleAuth.user : null;
}

export function currentPublicUser(req: Request): PublicUser | null {
  const u = currentUser(req);
  return u ? toPublicUser(u) : null;
}

/** Owner id for per-user data; null for non-human principals. */
export function currentUserId(req: Request): string | null {
  return currentUser(req)?.id ?? null;
}

function sendAuthError(res: Response, err: unknown): void {
  // Fail closed: a DB/lookup failure is "not authenticated", never "allowed".
  void err;
  res.status(401).json(AUTH_REQUIRED);
}

/** requireUser: valid session, user exists, ACTIVE — else 401. */
export async function requireUser(req: Request, res: Response, next: NextFunction): Promise<void> {
  let ctx: AuthContext | null;
  try { ctx = await resolveAuth(req); } catch (err) { sendAuthError(res, err); return; }
  if (!ctx) { res.status(401).json(AUTH_REQUIRED); return; }
  if (ctx.kind === "user" && ctx.user.must_change_password && !matchPair(MUST_CHANGE_ALLOWED, req.method.toUpperCase(), normPath(req.path))) {
    res.status(403).json(PASSWORD_CHANGE_REQUIRED);
    return;
  }
  next();
}

/** requireAdmin: requireUser, then role === ADMIN — else 403. */
export async function requireAdmin(req: Request, res: Response, next: NextFunction): Promise<void> {
  await requireUser(req, res, () => {
    if (authRole(req.oracleAuth) !== "ADMIN") { res.status(403).json(ADMIN_REQUIRED); return; }
    next();
  });
}

/** Human-session-only guard (profile / password routes). */
export async function requireSessionUser(req: Request, res: Response, next: NextFunction): Promise<void> {
  await requireUser(req, res, () => {
    if (req.oracleAuth?.kind !== "user") { res.status(401).json(AUTH_REQUIRED); return; }
    next();
  });
}

/**
 * Mounted on /api before the router: OPTIONS → CSRF → public allowlist →
 * requireUser → role policy (admin-only reads + all non-allow-listed writes).
 */
export async function accountsApiGate(req: Request, res: Response, next: NextFunction): Promise<void> {
  const method = req.method.toUpperCase();
  if (method === "OPTIONS") { next(); return; }
  if (csrfRejection(req)) { res.status(403).json({ error: "Request blocked (cross-site).", csrf: true }); return; }
  if (isPublicRoute(method, req.path)) {
    // Resolve (never reject) so public handlers such as /auth/me can see the session.
    try { await resolveAuth(req); } catch { /* treated as anonymous */ }
    next();
    return;
  }
  await requireUser(req, res, () => {
    const role = authRole(req.oracleAuth);
    if (role === "SERVICE") {
      if (!SAFE_METHODS.has(method) || routeRequiresAdmin(method, req.path)) { res.status(403).json(ADMIN_REQUIRED); return; }
      next();
      return;
    }
    if (routeRequiresAdmin(method, req.path) && role !== "ADMIN") { res.status(403).json(ADMIN_REQUIRED); return; }
    next();
  });
}
