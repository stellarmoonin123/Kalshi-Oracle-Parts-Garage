/**
 * automode-adapter.isolate.ts — UNCHANGED Adapt organ at isolate time
 * (skip LAG_STALE / LAG_AGAINST / DEAD globally; echoOperatorFloors copy).
 * Compare-only. Live module is the rewrite: FRESH lag disagree skip,
 * CONFLUENCE_CASCADE exempt, DEAD sizes down instead of starving CC.
 */
export const LEARNING_WEIGHT_MIN = 0.72;
export const LEARNING_WEIGHT_MAX = 1.18;

export const COMPOSER_GATE_KEYS = [
  "minConfidence",
  "minVelocity",
  "minProbEdge",
  "stopLossCents",
  "profitTakeCents",
  "tradeWindowMinMin",
  "tradeWindowMaxMin",
  "maxContractsPerTrade",
  "kellyFraction",
  "useKellyFraction",
  "useKellySizing",
  "maxRiskPctPerTrade",
  "minEV",
  "paperMode",
  "disabledStrategies",
] as const;

export type TapeLieReason =
  | "LAG_STALE"
  | "LAG_AGAINST"
  | "DEAD_TAPE"
  | "CHAOS";

export type TapeLieInputs = {
  lagStale?: boolean;
  lagAgreesWithSide?: boolean | null;
  volumeBucket?: string;
  chaosMode?: boolean;
};

export type AdaptationInputs = {
  autoMode: boolean;
  tape: TapeLieInputs;
  drawdownPct: number;
  drawdownGuardPct?: number;
  learningWeight?: number;
  fromBotFill?: boolean;
};

export type AdaptationResult = {
  skip: boolean;
  skipReasons: TapeLieReason[];
  sizeMult: number;
  learningWeight: number;
  summary: string;
};

const SIZE_MULT_FLOOR = 0.5;
const DD_EXTRA_ONSET_PCT = 8;
const DD_EXTRA_FLOOR = 0.7;
const LOW_VOL_SIZE_MULT = 0.85;

export function clampLearningWeightIsolate(weight: number): number {
  if (!Number.isFinite(weight)) return 1;
  return Math.min(LEARNING_WEIGHT_MAX, Math.max(LEARNING_WEIGHT_MIN, weight));
}

export function applyBotFillLearningIsolate(
  weight: number | undefined,
  fromBotFill: boolean,
): number {
  if (!fromBotFill) return 1;
  return clampLearningWeightIsolate(weight ?? 1);
}

export function drawdownSizeMultIsolate(drawdownPct: number, guardPct = 20): number {
  if (!Number.isFinite(drawdownPct) || drawdownPct <= 0) return 1;
  const guard = Number.isFinite(guardPct) && guardPct > DD_EXTRA_ONSET_PCT
    ? guardPct
    : 20;
  if (drawdownPct <= DD_EXTRA_ONSET_PCT) return 1;
  if (drawdownPct >= guard) return DD_EXTRA_FLOOR;
  const t = (drawdownPct - DD_EXTRA_ONSET_PCT) / (guard - DD_EXTRA_ONSET_PCT);
  return 1 - t * (1 - DD_EXTRA_FLOOR);
}

export function tapeLieReasonsIsolate(tape: TapeLieInputs): TapeLieReason[] {
  const reasons: TapeLieReason[] = [];
  if (tape.lagStale === true) reasons.push("LAG_STALE");
  if (tape.lagAgreesWithSide === false) reasons.push("LAG_AGAINST");
  if (tape.volumeBucket === "DEAD") reasons.push("DEAD_TAPE");
  if (tape.chaosMode === true) reasons.push("CHAOS");
  return reasons;
}

export const TAPE_LIE_SIT_ON_HANDS_ISOLATE: readonly TapeLieReason[] = ["LAG_STALE", "LAG_AGAINST", "DEAD_TAPE"];

export function tapeLieBlocksTickIsolate(reasons: readonly TapeLieReason[]): boolean {
  return reasons.some((r) => r !== "CHAOS");
}

function volumeSizeMult(bucket: string | undefined): number {
  if (bucket === "LOW") return LOW_VOL_SIZE_MULT;
  return 1;
}

function clampSizeMult(mult: number): number {
  if (!Number.isFinite(mult)) return 1;
  return Math.min(1, Math.max(SIZE_MULT_FLOOR, mult));
}

/** Isolate-time computeAdaptation: global DEAD/STALE skip (starves CC). */
export function computeAdaptationIsolate(inputs: AdaptationInputs): AdaptationResult {
  if (!inputs.autoMode) {
    return {
      skip: false,
      skipReasons: [],
      sizeMult: 1,
      learningWeight: 1,
      summary: "autoMode off — no adaptation",
    };
  }

  const skipReasons = tapeLieReasonsIsolate(inputs.tape);
  const sizeMult = clampSizeMult(
    Math.min(
      drawdownSizeMultIsolate(inputs.drawdownPct, inputs.drawdownGuardPct),
      volumeSizeMult(inputs.tape.volumeBucket),
    ),
  );
  const learningWeight = applyBotFillLearningIsolate(
    inputs.learningWeight,
    inputs.fromBotFill === true,
  );

  const blocking = skipReasons.filter((r) => r !== "CHAOS");
  const bits: string[] = [];
  if (blocking.length) bits.push(`skip ${blocking.join("+")}`);
  if (skipReasons.includes("CHAOS")) bits.push("chaos observed (not sit-on-hands)");
  if (sizeMult < 1) bits.push(`size ${sizeMult.toFixed(2)}x`);
  if (learningWeight !== 1) bits.push(`learn ${learningWeight.toFixed(2)}x (BOT fills)`);
  const summary = bits.length
    ? `adapter: ${bits.join(" · ")}`
    : "adapter: tape honest, no DD haircut, no BOT-fill learn yet";

  return {
    skip: tapeLieBlocksTickIsolate(skipReasons),
    skipReasons,
    sizeMult,
    learningWeight,
    summary,
  };
}

export function echoOperatorFloorsIsolate<T extends Record<string, unknown>>(config: T): {
  minConfidence: unknown;
  minVelocity: unknown;
  maxContractsPerTrade: unknown;
  stopLossCents: unknown;
  profitTakeCents: unknown;
  tradeWindowMinMin: unknown;
  tradeWindowMaxMin: unknown;
  minProbEdge: unknown;
} {
  return {
    minConfidence: config.minConfidence,
    minVelocity: config.minVelocity,
    maxContractsPerTrade: config.maxContractsPerTrade,
    stopLossCents: config.stopLossCents,
    profitTakeCents: config.profitTakeCents,
    tradeWindowMinMin: config.tradeWindowMinMin,
    tradeWindowMaxMin: config.tradeWindowMaxMin,
    minProbEdge: config.minProbEdge,
  };
}
