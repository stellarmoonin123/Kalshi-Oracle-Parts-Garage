/**
 * oracle-v2-doctrine — fold KALSHI ORACLE v2 DESK OS into Oracle Mind (max capability).
 *
 * Deterministic. No LLM. Never replaces decideFrozenCcEntry / PATH_RIDE / tick.
 * Proposal soft kelly_mult=0.20 only; live Kelly cap stays 0.60.
 *
 * Fee SoT: lib/fees/kalshi-fee.ts — taker≈0.07*P*(1-P) ceil. No rewrite unless bug.
 * Priority: fee-net wrong-side reduction + calibrated ABSTAIN over more trading.
 *
 * No import from brain-center (avoids cycle). Structural types only.
 */

export const ORACLE_V2_DOCTRINE_LOADED = "ORACLE_V2_DOCTRINE_LOADED" as const;
export const ORACLE_V2_FEE_MODEL_NOTE =
  "taker≈0.07*P*(1-P) ceil_cent (align kalshi-fee.ts; settlement fee=0)" as const;
/** Soft Kelly for chat/proposal ORACLE_JSON only — never cuts live Kelly≤0.60. */
export const ORACLE_V2_PROPOSAL_KELLY_MULT = 0.2 as const;
/** Ordinary 15m thin min edge (cents) for RISK FAIL — hard floor still EV≥3¢. */
export const ORACLE_V2_MIN_EDGE_ORDINARY_CENTS = 7 as const;
/** Default slip when depth unknown (thin) — cents. */
export const ORACLE_V2_SLIP_THIN_CENTS = 2 as const;
/** Mirror of MIND_FLOOR_LOCKS — must stay equal (tested). */
export const ORACLE_V2_FLOOR_MIRROR = {
  evFloorCents: 3,
  kellyCap: 0.6,
  askMinCents: 20,
  askMaxCents: 55,
} as const;

export type OracleV2SeatId = "FORECASTER" | "ADVERSARY" | "MICRO" | "RISK";

export type OracleV2Seat = {
  id: OracleV2SeatId;
  vote: string;
  weight: number;
  lines: string[];
};

export type OracleV2GateId =
  | "G_RULE"
  | "G_SOURCE"
  | "G_BOOK"
  | "G_TIME"
  | "G_LIQ"
  | "G_MANDATE"
  | "G_STATE"
  | "G_CAPS";

export type OracleV2Gate = {
  id: OracleV2GateId;
  pass: boolean;
  note: string;
};

export type OracleV2Action =
  | "ABSTAIN"
  | "BUY_YES"
  | "BUY_NO"
  | "HOLD"
  | "REDUCE"
  | "EXIT"
  | "SKIP";

export type OracleV2Block = {
  action: OracleV2Action;
  /** Post-update p (after mid shrink). */
  p_yes: number | null;
  /** Independent forecast BEFORE mid (L3). */
  p_ind: number | null;
  /**
   * Honesty stamp: where p_ind came from.
   * ask_conditioned = derived from winRateAtPrice / ask (NOT epistemically independent of mid).
   * caller = caller supplied pInd; null = no p.
   */
  pIndSource: "caller" | "ask_conditioned" | "none";
  /** Reference / base rate when known. */
  p0: number | null;
  /** Mid used as evidence only after p_ind (null if unknown). */
  mid_yes: number | null;
  band80: [number | null, number | null];
  yes_edge_net: number | null;
  no_edge_net: number | null;
  /** Edge on proposed side after fee+slip (cents). */
  edge_net_cents: number | null;
  min_edge_cents: number;
  seats: OracleV2Seat[];
  gates: OracleV2Gate[];
  gates_failed: OracleV2GateId[];
  risk_pass: boolean;
  /** True when RISK hard-vetoed a would-be TAKE. */
  risk_veto: boolean;
  risk_veto_reasons: string[];
  missing_inputs: string[];
  invalidate_if: string[];
  do_not_do: string[];
  cluster_id: string | null;
  overconfidence_tax: number;
  fee_model_note: typeof ORACLE_V2_FEE_MODEL_NOTE;
  kelly_mult_proposal: typeof ORACLE_V2_PROPOSAL_KELLY_MULT;
  kelly_cap_live: typeof ORACLE_V2_FLOOR_MIRROR.kellyCap;
  decisionKind: string;
  schema: "kalshi_oracle_v2";
};

export type OracleV2CouncilSlice = {
  advocates: Array<{
    id: "bull" | "bear" | "skip";
    vote: string;
    weight: number;
    reasons: string[];
  }>;
  resolved: string;
  dissent: { note: string } | null;
};

export type OracleV2PhdSlice = {
  calibration: { n: number; reliable: boolean; ece: number; skipLean?: number };
  optionValueSkip: { preferSkip: boolean; score: number; reasons?: string[] };
  uncertainty: { coversBoth: boolean; lo?: number | null; hi?: number | null };
  causalNote?: string;
} | null;

export type OracleV2SettleSlice = {
  pick: "yes" | "no" | "skip";
  factors: { inputsPresent: boolean };
  scoreYes?: number | null;
  scoreNo?: number | null;
  reasons?: string[];
  penalties?: string[];
} | null;

export type BuildOracleV2Input = {
  decisionKind: string;
  council: OracleV2CouncilSlice;
  phd: OracleV2PhdSlice;
  settleSideScore: OracleV2SettleSlice;
  /** Live winRateAtPrice (ask-conditioned) of the SIDE taken (NO side → P(NO)). */
  pWin: number | null;
  /** Caller-supplied independent p before mid (L3). If null, pWin is used and stamped ask_conditioned. */
  pInd?: number | null;
  /** Base rate / reference class. Default 0.50 when unknown. */
  p0?: number | null;
  /** Book mid YES (0–1). If null, inferred from askCents. */
  midYes?: number | null;
  evCents: number | null;
  side: "yes" | "no" | null;
  soleDecision: string;
  paperMode: boolean;
  stale: boolean;
  sizeZero: boolean;
  /** Ask of the SIDE taken (converted to YES terms internally for edge math). */
  askCents: number | null;
  secsRemaining: number | null;
  confidenceBand: "low" | "mid" | "high";
  curiosityCodes?: readonly string[] | null;
  /** Thin book / depth unknown. Default true when not proven liquid. */
  thinBook?: boolean | null;
  /** Narrative / single-source → stronger overconfidence tax. */
  narrative?: boolean | null;
  /** Series / ladder cluster — default KXBTC15M for this desk. */
  clusterId?: string | null;
  /** Slip cents override; default thin=2¢. */
  slipCents?: number | null;
};

function clamp01(x: number): number {
  if (!Number.isFinite(x)) return 0.5;
  return Math.min(1, Math.max(0, x));
}

function round4(n: number): number {
  return Math.round(n * 10000) / 10000;
}

function round3(n: number): number {
  return Math.round(n * 1000) / 1000;
}

/** Taker fee cents per contract at ask (C=1), matching kalshi-fee quadratic+ceil. */
export function oracleV2TakerFeeCentsPerContract(askCents: number): number {
  const P = askCents / 100;
  if (!(P > 0) || !(P < 1)) return 0;
  const rawCents = 0.07 * P * (1 - P) * 100;
  return Math.ceil(rawCents - 1e-9);
}

/**
 * L3: form p_ind before mid; then shrink toward mid.
 * Overconfidence tax pulls (p_ind − p0) toward p0 when narrative/thin/unreliable.
 */
export function applyIndependentPAndTax(input: {
  pWin: number | null;
  pInd: number | null | undefined;
  p0: number | null | undefined;
  midYes: number | null | undefined;
  askCents: number | null;
  narrative: boolean;
  thinBook: boolean;
  calibReliable: boolean | null;
  coversBoth: boolean;
  confidenceBand: "low" | "mid" | "high";
}): {
  p0: number;
  p_ind: number | null;
  p_yes: number | null;
  mid_yes: number | null;
  overconfidence_tax: number;
  band80: [number | null, number | null];
  pIndSource: "caller" | "ask_conditioned" | "none";
} {
  const p0 = typeof input.p0 === "number" && Number.isFinite(input.p0) ? clamp01(input.p0) : 0.5;
  const mid =
    typeof input.midYes === "number" && Number.isFinite(input.midYes)
      ? clamp01(input.midYes)
      : typeof input.askCents === "number"
        ? clamp01(input.askCents / 100)
        : null;

  // Honesty: caller-supplied pInd is "caller"; pWin@ask is ask_conditioned (NOT
  // epistemically independent of mid — do not overclaim independence).
  let pIndSource: "caller" | "ask_conditioned" | "none" = "none";
  let pInd: number | null = null;
  if (typeof input.pInd === "number" && Number.isFinite(input.pInd)) {
    pInd = clamp01(input.pInd);
    pIndSource = "caller";
  } else if (typeof input.pWin === "number" && Number.isFinite(input.pWin)) {
    // Procedural L3 still forms a pre-shrink number from pWin, but label ask_conditioned.
    pInd = clamp01(input.pWin);
    pIndSource = "ask_conditioned";
  }

  let tax = 0;
  if (input.narrative) tax += 0.4;
  if (input.thinBook) tax += 0.25;
  if (input.calibReliable === false) tax += 0.3;
  if (input.coversBoth) tax += 0.2;
  if (input.confidenceBand === "low") tax += 0.15;
  tax = Math.min(0.7, tax);

  if (pInd != null && tax > 0) {
    pInd = round4(pInd - tax * (pInd - p0));
  }

  // Shrink toward mid AFTER independent forecast (liquid → more shrink)
  let pYes: number | null = pInd;
  if (pInd != null && mid != null) {
    const shrink = input.thinBook ? 0.15 : 0.35;
    pYes = round4(pInd + shrink * (mid - pInd));
  } else if (typeof input.pWin === "number" && Number.isFinite(input.pWin)) {
    pYes = clamp01(input.pWin);
  }

  let half =
    input.confidenceBand === "high" ? 0.08 : input.confidenceBand === "mid" ? 0.12 : 0.18;
  half += tax * 0.12;
  if (input.coversBoth) half = Math.max(half, 0.22);
  const band80: [number | null, number | null] =
    pYes == null
      ? [null, null]
      : [round3(Math.max(0, pYes - half)), round3(Math.min(1, pYes + half))];

  return {
    p0,
    p_ind: pInd,
    p_yes: pYes,
    mid_yes: mid,
    overconfidence_tax: round3(tax),
    band80,
    pIndSource,
  };
}

function netEdgeCents(input: {
  pYes: number | null;
  askCents: number | null;
  side: "yes" | "no" | null;
  slipCents: number;
  evCents: number | null;
}): { yes: number | null; no: number | null; edge_net_cents: number | null } {
  const slip = input.slipCents;
  if (typeof input.askCents === "number" && input.pYes != null) {
    const fee = oracleV2TakerFeeCentsPerContract(input.askCents);
    const yesCost = input.askCents + fee + slip; // cents
    const yesEdge = input.pYes * 100 - yesCost;
    const noAsk = 100 - input.askCents; // approx when only yes ask known
    const noFee = oracleV2TakerFeeCentsPerContract(noAsk);
    const noCost = noAsk + noFee + slip;
    const noEdge = (1 - input.pYes) * 100 - noCost;
    const sideEdge =
      input.side === "no" ? noEdge : input.side === "yes" ? yesEdge : Math.max(yesEdge, noEdge);
    return {
      yes: round4(yesEdge / 100),
      no: round4(noEdge / 100),
      edge_net_cents: round3(sideEdge),
    };
  }
  // Fall back to sole EV cents when ask/p incomplete
  if (typeof input.evCents === "number" && Number.isFinite(input.evCents)) {
    const e = input.evCents;
    return {
      yes: input.side === "yes" || input.side == null ? round4(e / 100) : null,
      no: input.side === "no" ? round4(e / 100) : null,
      edge_net_cents: e,
    };
  }
  return { yes: null, no: null, edge_net_cents: null };
}

function buildGates(input: BuildOracleV2Input): OracleV2Gate[] {
  const thin = input.thinBook !== false; // default thin when unknown
  const bookOk =
    typeof input.askCents === "number" &&
    input.askCents >= ORACLE_V2_FLOOR_MIRROR.askMinCents &&
    input.askCents <= ORACLE_V2_FLOOR_MIRROR.askMaxCents &&
    !input.stale;
  const timeOk =
    input.secsRemaining == null ||
    (typeof input.secsRemaining === "number" && input.secsRemaining >= 60);
  const stateOk = !input.sizeZero && input.soleDecision !== "HALT";
  const capsOk = input.paperMode === true;
  // G_LIQ: fail-closed on stale; thin alone raises min_edge (not an auto fail)
  const liqPass = !input.stale;

  return [
    { id: "G_RULE", pass: true, note: "desk 15m rules known" },
    { id: "G_SOURCE", pass: true, note: "settlement index path present" },
    {
      id: "G_BOOK",
      pass: bookOk,
      note: bookOk
        ? `ask=${input.askCents}¢ fresh`
        : input.stale
          ? "stale book"
          : `ask out of band or missing (${input.askCents ?? "n/a"})`,
    },
    {
      id: "G_TIME",
      pass: timeOk,
      note: timeOk ? `tte=${input.secsRemaining ?? "n/a"}s` : "too late for thesis",
    },
    {
      id: "G_LIQ",
      pass: liqPass,
      note: liqPass
        ? thin
          ? "thin assumed — raised min_edge"
          : "freshness ok"
        : "stale/thin — ABSTAIN",
    },
    {
      id: "G_MANDATE",
      pass: capsOk,
      note: capsOk ? "paper mandate" : "paperMode false — refuse",
    },
    {
      id: "G_STATE",
      pass: stateOk,
      note: stateOk ? "state open" : "size0 / halt",
    },
    {
      id: "G_CAPS",
      pass: capsOk,
      note: capsOk ? "paper caps" : "caps unknown / live refuse",
    },
  ];
}

function collectMissing(input: BuildOracleV2Input): string[] {
  const missing: string[] = [];
  if (input.pWin == null && input.pInd == null) missing.push("p_yes");
  if (input.askCents == null) missing.push("ask");
  if (input.secsRemaining == null) missing.push("time_remaining");
  if (
    input.evCents == null &&
    (input.decisionKind === "TAKE_YES" || input.decisionKind === "TAKE_NO")
  ) {
    missing.push("ev_cents");
  }
  if (input.thinBook !== false && input.thinBook !== true) {
    // unknown depth
    missing.push("book_depth");
  }
  for (const c of input.curiosityCodes ?? []) {
    if (c === "LAG_UNPROVEN") missing.push("lag_proven");
    if (c === "DEPTH_UNKNOWN") missing.push("book_depth");
    if (c === "EPISODES_EMPTY") missing.push("fee_net_history");
  }
  return [...new Set(missing)];
}

function buildInvalidateAndDoNot(input: {
  decisionKind: string;
  side: "yes" | "no" | null;
  ccHints: string[];
  coversBoth: boolean;
  ovPrefer: boolean;
}): { invalidate_if: string[]; do_not_do: string[] } {
  const invalidate_if: string[] = [];
  const do_not_do: string[] = [
    "Do not invent fills or balances",
    "Do not cut Kelly cap 0.60 or EV floor 3¢",
    "Do not place orders from chat — propose only",
  ];
  if (input.side === "yes" || input.decisionKind === "TAKE_YES") {
    invalidate_if.push("BTC velocity flips red vs YES thesis");
    invalidate_if.push("ask exits 20–55¢ band");
  } else if (input.side === "no" || input.decisionKind === "TAKE_NO") {
    invalidate_if.push("BTC velocity flips green vs NO thesis");
    invalidate_if.push("ask exits 20–55¢ band");
  } else {
    invalidate_if.push("new Class-A settlement fact arrives");
  }
  if (input.coversBoth) {
    invalidate_if.push("side band no longer covers both");
    do_not_do.push("Do not TAKE while band80 covers both sides");
  }
  if (input.ovPrefer) {
    do_not_do.push("Do not TAKE while option-value of SKIP dominates");
  }
  for (const h of input.ccHints.slice(0, 2)) invalidate_if.push(h);
  return { invalidate_if: invalidate_if.slice(0, 5), do_not_do: do_not_do.slice(0, 6) };
}

function mapSeats(input: {
  council: OracleV2CouncilSlice;
  phd: OracleV2PhdSlice;
  settle: OracleV2SettleSlice;
  riskPass: boolean;
  riskVetoReasons: string[];
  p_ind: number | null;
  p_yes: number | null;
  edge_net_cents: number | null;
  min_edge: number;
  overconfidence_tax: number;
  thinBook: boolean;
}): OracleV2Seat[] {
  const byId = (id: "bull" | "bear" | "skip") =>
    input.council.advocates.find((a) => a.id === id) ?? null;
  const bull = byId("bull");
  const bear = byId("bear");
  const skip = byId("skip");
  const phd = input.phd;
  const settle = input.settle;

  const phdLines: string[] = [];
  if (phd) {
    phdLines.push(
      `ECE n=${phd.calibration.n} reliable=${phd.calibration.reliable} ece=${phd.calibration.ece}`,
    );
    if (phd.optionValueSkip.preferSkip) {
      phdLines.push(
        `OV-SKIP score=${phd.optionValueSkip.score}${(phd.optionValueSkip.reasons ?? []).slice(0, 1).map((r) => ` (${r})`).join("")}`,
      );
    }
    if (phd.uncertainty.coversBoth) phdLines.push("band coversBoth → ABSTAIN lean");
    if (phd.causalNote) phdLines.push(phd.causalNote.slice(0, 80));
  }
  const settleLines: string[] = [];
  if (settle?.factors.inputsPresent) {
    settleLines.push(
      `settle-side pick=${settle.pick} y=${settle.scoreYes ?? "n/a"} n=${settle.scoreNo ?? "n/a"}`,
    );
    for (const r of [...(settle.penalties ?? []), ...(settle.reasons ?? [])].slice(0, 2)) {
      settleLines.push(r);
    }
  }

  const forecaster: OracleV2Seat = {
    id: "FORECASTER",
    vote: bull?.vote ?? "HOLD",
    weight: bull?.weight ?? 0,
    lines: [
      ...(input.p_ind != null ? [`p_ind=${input.p_ind}`] : []),
      ...(input.p_yes != null ? [`p_yes=${input.p_yes}`] : []),
      ...(bull?.reasons ?? []).slice(0, 2),
      ...settleLines.slice(0, 1),
      ...phdLines.slice(0, 2),
    ].slice(0, 6),
  };
  const adversary: OracleV2Seat = {
    id: "ADVERSARY",
    vote: bear?.vote ?? "HOLD",
    weight: bear?.weight ?? 0,
    lines: [
      ...(bear?.reasons ?? []).slice(0, 3),
      ...(skip?.reasons ?? []).slice(0, 2),
      ...(phd?.uncertainty.coversBoth ? ["coversBoth — other side live"] : []),
      ...settleLines.filter((l) => /skip|penalty|conflict/i.test(l)).slice(0, 1),
    ].slice(0, 6),
  };
  const micro: OracleV2Seat = {
    id: "MICRO",
    vote: skip?.vote === "SKIP" || skip?.vote === "SIT" ? skip.vote : "SIT",
    weight: skip?.weight ?? 0,
    lines: [
      ORACLE_V2_FEE_MODEL_NOTE,
      `edge_net=${input.edge_net_cents ?? "n/a"}¢ min_edge=${input.min_edge}¢ thin=${input.thinBook}`,
      `overconfidence_tax=${input.overconfidence_tax}`,
      `floors EV≥${ORACLE_V2_FLOOR_MIRROR.evFloorCents}¢ ask ${ORACLE_V2_FLOOR_MIRROR.askMinCents}–${ORACLE_V2_FLOOR_MIRROR.askMaxCents}`,
      ...(skip?.reasons ?? []).slice(0, 2),
    ].slice(0, 6),
  };
  const risk: OracleV2Seat = {
    id: "RISK",
    vote: input.riskPass ? "PASS" : "FAIL",
    weight: Math.max(skip?.weight ?? 0.3, 0.35),
    lines: [
      input.riskPass
        ? "PASS — gates clear, edge≥hurdle, OV not dominating"
        : `FAIL — ${input.riskVetoReasons.slice(0, 2).join("; ") || "default ABSTAIN"}`,
      `proposal kelly_mult=${ORACLE_V2_PROPOSAL_KELLY_MULT} live Kelly≤${ORACLE_V2_FLOOR_MIRROR.kellyCap}`,
      ...(input.council.dissent ? [`dissent: ${input.council.dissent.note}`] : []),
      ...phdLines.filter((l) => /OV-SKIP|coversBoth|reliable=false/.test(l)).slice(0, 2),
    ].slice(0, 6),
  };
  return [forecaster, adversary, micro, risk];
}

/**
 * Deterministic ORACLE v2 stamp — max capability fold.
 * Never places orders. Never calls LLM.
 */
export function buildOracleV2Block(input: BuildOracleV2Input): OracleV2Block {
  const thinBook = input.thinBook !== false; // unknown → thin
  const narrative = input.narrative === true;
  const slip =
    typeof input.slipCents === "number" && Number.isFinite(input.slipCents)
      ? input.slipCents
      : thinBook
        ? ORACLE_V2_SLIP_THIN_CENTS
        : 1;
  const min_edge =
    thinBook || narrative
      ? ORACLE_V2_MIN_EDGE_ORDINARY_CENTS
      : ORACLE_V2_FLOOR_MIRROR.evFloorCents;

  const gates = buildGates(input);
  const gates_failed = gates.filter((g) => !g.pass).map((g) => g.id);
  const missing_inputs = collectMissing(input);

  const coversBoth = input.phd?.uncertainty.coversBoth === true;
  const ovPrefer = input.phd?.optionValueSkip.preferSkip === true;
  const ovScore = input.phd?.optionValueSkip.score ?? 0;
  const calibReliable = input.phd ? input.phd.calibration.reliable : null;
  const settleSkip =
    input.settleSideScore?.factors.inputsPresent === true &&
    input.settleSideScore.pick === "skip";

  // D1: askCents / pWin / pInd are in terms of the SIDE taken (the desk's
  // winRateAtPrice is the win prob of that side at that side's ask). The p/mid
  // math and netEdgeCents work in YES terms, so convert NO → YES here
  // (was: a NO@34 p=0.52 was priced as YES@34 → NO edge vs 66¢ → −18¢ veto).
  const isNoSide = input.side === "no";
  const toYesP = (p: number | null | undefined): number | null | undefined =>
    typeof p === "number" && Number.isFinite(p) ? (isNoSide ? 1 - p : p) : p;
  const yesAskCents =
    typeof input.askCents === "number" && Number.isFinite(input.askCents)
      ? (isNoSide ? 100 - input.askCents : input.askCents)
      : null;
  const pPack = applyIndependentPAndTax({
    pWin: (toYesP(input.pWin) ?? null) as number | null,
    pInd: toYesP(input.pInd),
    p0: input.p0,
    midYes: input.midYes,
    askCents: yesAskCents,
    narrative,
    thinBook,
    calibReliable,
    coversBoth,
    confidenceBand: input.confidenceBand,
  });

  // If band80 covers 0.5 both ways strongly, treat as coversBoth
  const bandCoversBoth =
    coversBoth ||
    (pPack.band80[0] != null &&
      pPack.band80[1] != null &&
      pPack.band80[0] < 0.5 &&
      pPack.band80[1] > 0.5 &&
      pPack.overconfidence_tax >= 0.25);

  const edges = netEdgeCents({
    pYes: pPack.p_yes,
    askCents: yesAskCents,
    side: input.side,
    slipCents: slip,
    evCents: input.evCents,
  });

  // RISK hard-veto reasons
  const risk_veto_reasons: string[] = [];
  if (gates_failed.length > 0) {
    risk_veto_reasons.push(`gates_failed=${gates_failed.join(",")}`);
  }
  if (missing_inputs.includes("ask") || missing_inputs.includes("p_yes")) {
    risk_veto_reasons.push(`MISSING_INPUTS=${missing_inputs.join(",")}`);
  }
  if (thinBook && input.thinBook === true) {
    risk_veto_reasons.push("thin book");
  }
  if (
    edges.edge_net_cents != null &&
    edges.edge_net_cents < min_edge &&
    (input.decisionKind === "TAKE_YES" || input.decisionKind === "TAKE_NO")
  ) {
    risk_veto_reasons.push(`edge_net ${edges.edge_net_cents}¢ < min_edge ${min_edge}¢`);
  }
  // Hard floor: never propose below EV 3¢ when we have a number
  if (
    edges.edge_net_cents != null &&
    edges.edge_net_cents < ORACLE_V2_FLOOR_MIRROR.evFloorCents &&
    (input.decisionKind === "TAKE_YES" || input.decisionKind === "TAKE_NO")
  ) {
    risk_veto_reasons.push(
      `edge_net ${edges.edge_net_cents}¢ < hard EV floor ${ORACLE_V2_FLOOR_MIRROR.evFloorCents}¢`,
    );
  }
  if (ovPrefer || (ovScore >= 0.25 && input.decisionKind.startsWith("TAKE"))) {
    risk_veto_reasons.push(`OV-SKIP score=${ovScore} — waiting ≥ taking`);
  }
  if (bandCoversBoth) risk_veto_reasons.push("band80 covers both sides");
  if (calibReliable === false) risk_veto_reasons.push("calibration unreliable");
  if (settleSkip) risk_veto_reasons.push("settle-side SKIP");
  if (!input.paperMode) risk_veto_reasons.push("paperMode false");

  const wantTake =
    input.decisionKind === "TAKE_YES" || input.decisionKind === "TAKE_NO";
  const risk_veto = wantTake && risk_veto_reasons.length > 0;
  const risk_pass = wantTake && risk_veto_reasons.length === 0;

  let action: OracleV2Action;
  if (input.decisionKind === "HOLD") action = "HOLD";
  else if (input.decisionKind === "EXIT") action = "EXIT";
  else if (risk_pass && input.decisionKind === "TAKE_YES") action = "BUY_YES";
  else if (risk_pass && input.decisionKind === "TAKE_NO") action = "BUY_NO";
  else action = "ABSTAIN"; // default ABSTAIN — calibrated skip over more trading

  const seats = mapSeats({
    council: input.council,
    phd: input.phd,
    settle: input.settleSideScore,
    riskPass: risk_pass,
    riskVetoReasons: risk_veto_reasons,
    p_ind: pPack.p_ind,
    p_yes: pPack.p_yes,
    edge_net_cents: edges.edge_net_cents,
    min_edge,
    overconfidence_tax: pPack.overconfidence_tax,
    thinBook,
  });

  const { invalidate_if, do_not_do } = buildInvalidateAndDoNot({
    decisionKind: input.decisionKind,
    side: input.side,
    ccHints: risk_veto_reasons.filter((r) => /vel|CC_/i.test(r)).slice(0, 2),
    coversBoth: bandCoversBoth,
    ovPrefer,
  });

  const cluster_id = input.clusterId ?? "KXBTC15M";

  const decisionKind =
    action === "ABSTAIN"
      ? input.decisionKind === "HOLD" || input.decisionKind === "EXIT"
        ? input.decisionKind
        : "ABSTAIN"
      : input.decisionKind;

  return {
    action,
    p_yes: pPack.p_yes,
    p_ind: pPack.p_ind,
    pIndSource: pPack.pIndSource,
    p0: pPack.p0,
    mid_yes: pPack.mid_yes,
    band80: pPack.band80,
    yes_edge_net: edges.yes,
    no_edge_net: edges.no,
    edge_net_cents: edges.edge_net_cents,
    min_edge_cents: min_edge,
    seats,
    gates,
    gates_failed,
    risk_pass: action === "BUY_YES" || action === "BUY_NO",
    risk_veto,
    risk_veto_reasons,
    missing_inputs,
    invalidate_if,
    do_not_do,
    cluster_id,
    overconfidence_tax: pPack.overconfidence_tax,
    fee_model_note: ORACLE_V2_FEE_MODEL_NOTE,
    kelly_mult_proposal: ORACLE_V2_PROPOSAL_KELLY_MULT,
    kelly_cap_live: ORACLE_V2_FLOOR_MIRROR.kellyCap,
    decisionKind,
    schema: "kalshi_oracle_v2",
  };
}

/** Condensed OS for chat TICKET/RESEARCH system prompt. */
export function oracleV2ChatDoctrineCondensed(): string {
  return [
    "══ ORACLE_V2 DESK OS (proposal/research — NOT tick execution) ══",
    "Confirm: ORACLE_READY. You propose; code/human disposes. Never invent fills, balances, or live books not in snapshot.",
    "Default action ABSTAIN. Skip is a completed job. Voice: numeric, terse, skeptical.",
    "L3: form p_ind BEFORE mid; then shrink. pIndSource stamps ask_conditioned when from pWin@ask (not independent). Overconfidence tax on narrative/thin. band80 covers both → ABSTAIN.",
    "Hard laws: title≠rules; edge net of fees+slip; no full Kelly — proposal kelly_mult=0.20 (live Kelly≤0.60 untouched).",
    "Fees: taker≈ceil(0.07*P*(1-P)) per kalshi-fee.ts. Settlement fee=0. min_edge ordinary 7¢ thin 15m (hard EV≥3¢).",
    "Four seats: FORECASTER / ADVERSARY / MICRO / RISK. RISK hard-vetoes TAKE on gates_failed, MISSING_INPUTS, thin book, edge<hurdle, OV-SKIP.",
    "Compose settle-side + PhD ECE/OV into seats. invalidate_if + do_not_do required. cluster_id=KXBTC15M for this desk.",
    "Tick path is LLM-free (decideFrozenCcEntry / PATH_RIDE / autopilot). Do not claim you placed an order.",
    "Floors held: EV≥3¢ · Kelly≤0.60 · 9% · ask 20–55 · reserve 15% · paperMode true.",
  ].join("\n");
}
