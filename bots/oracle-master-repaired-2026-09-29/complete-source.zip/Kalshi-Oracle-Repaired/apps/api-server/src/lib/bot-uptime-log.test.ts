/**
 * bot-uptime-log.test.ts
 *
 * Transition logging, gap-on-boot, and 24h/7d summarize.
 * Uses a temp jsonl path — never touches data/bot-uptime.jsonl.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  createBotUptimeLog,
  isBotArmed,
  lastArmedFromSegments,
  summarizeUptime,
} from "./bot-uptime-log.js";

function tmpFile(): string {
  return path.join(
    os.tmpdir(),
    `bot-uptime-test-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}.jsonl`,
  );
}

function cleanup(filePath: string) {
  try { fs.unlinkSync(filePath); } catch { /* ok */ }
}

function ctx(partial: Partial<{ state: string; enabled: boolean; paperMode: boolean; reason: string; ts: number; pid: number }> = {}) {
  return {
    state: partial.state ?? "WATCHING",
    enabled: partial.enabled ?? true,
    paperMode: partial.paperMode ?? true,
    reason: partial.reason,
    ts: partial.ts,
    pid: partial.pid ?? 4242,
  };
}

test("isBotArmed: ON only when enabled + WATCHING/IN_TRADE", () => {
  assert.equal(isBotArmed(true, "WATCHING"), true);
  assert.equal(isBotArmed(true, "IN_TRADE"), true);
  assert.equal(isBotArmed(true, "IDLE"), false);
  assert.equal(isBotArmed(true, "STOPPED"), false);
  assert.equal(isBotArmed(true, "SUSPENDED"), false);
  assert.equal(isBotArmed(false, "WATCHING"), false);
});

test("recordTransition logs on→off and is idempotent", () => {
  const filePath = tmpFile();
  try {
    const log = createBotUptimeLog(filePath);
    const t0 = 1_700_000_000_000;
    const on = log.recordTransition(ctx({ ts: t0, reason: "start" }));
    assert.ok(on);
    assert.equal(on!.event, "on");
    assert.equal(on!.reason, "start");
    assert.equal(on!.paperMode, true);
    assert.equal(on!.pid, 4242);

    // Same armed state → no second line
    assert.equal(log.recordTransition(ctx({ ts: t0 + 1000, state: "IN_TRADE" })), null);

    const off = log.recordTransition(ctx({
      ts: t0 + 5000,
      enabled: false,
      state: "STOPPED",
      reason: "user stop",
    }));
    assert.ok(off);
    assert.equal(off!.event, "off");
    assert.equal(off!.reason, "user stop");

    assert.equal(log.recordTransition(ctx({
      ts: t0 + 6000,
      enabled: false,
      state: "STOPPED",
    })), null);

    const all = log.readAll();
    assert.equal(all.length, 2);
    assert.equal(lastArmedFromSegments(all), false);
  } finally {
    cleanup(filePath);
  }
});

test("gap-on-boot closes open ON then process_start", () => {
  const filePath = tmpFile();
  try {
    const log = createBotUptimeLog(filePath);
    const t0 = 1_700_000_200_000;
    log.recordTransition(ctx({ ts: t0 }));
    const boot = log.onProcessBoot(ctx({
      ts: t0 + 30_000,
      enabled: false,
      state: "IDLE",
    }));
    assert.equal(boot.length, 2);
    assert.equal(boot[0]!.event, "gap");
    assert.equal(boot[0]!.reason, "crash gap");
    assert.equal(boot[1]!.event, "process_start");
    assert.equal(boot[1]!.reason, "process start");
    assert.equal(lastArmedFromSegments(log.readAll()), false);
  } finally {
    cleanup(filePath);
  }
});

test("clean process_stop does not invent a gap on next boot", () => {
  const filePath = tmpFile();
  try {
    const log = createBotUptimeLog(filePath);
    const t0 = 1_700_000_300_000;
    log.recordTransition(ctx({ ts: t0 }));
    log.onProcessStop(ctx({
      ts: t0 + 10_000,
      enabled: true,
      state: "WATCHING",
      reason: "SIGTERM",
    }));
    const all = log.readAll();
    assert.equal(all.some(s => s.event === "off"), true);
    assert.equal(all.some(s => s.event === "process_stop"), true);
    assert.equal(lastArmedFromSegments(all), false);

    const boot = log.onProcessBoot(ctx({
      ts: t0 + 20_000,
      enabled: false,
      state: "IDLE",
    }));
    assert.equal(boot.length, 1);
    assert.equal(boot[0]!.event, "process_start");
  } finally {
    cleanup(filePath);
  }
});

test("summarize last 24h / 7d totals onMs and offMs", () => {
  const filePath = tmpFile();
  try {
    const log = createBotUptimeLog(filePath);
    const now = 1_700_010_000_000;
    const day = 24 * 60 * 60 * 1000;
    // ON for 2 hours, then OFF for rest of window
    log.recordTransition(ctx({ ts: now - 3 * 60 * 60 * 1000, reason: "start" }));
    log.recordTransition(ctx({
      ts: now - 1 * 60 * 60 * 1000,
      enabled: false,
      state: "STOPPED",
      reason: "user stop",
    }));

    const s24 = summarizeUptime(log.readAll(), day, now, false);
    assert.equal(s24.onMs, 2 * 60 * 60 * 1000);
    assert.equal(s24.offMs, day - 2 * 60 * 60 * 1000);
    assert.ok(s24.segments.length >= 2);

    const s7 = log.summarize(7 * day, now);
    // After off, lastArmed is false — summarize uses that
    assert.equal(s7.onMs, 2 * 60 * 60 * 1000);
    assert.equal(s7.offMs, 7 * day - 2 * 60 * 60 * 1000);
  } finally {
    cleanup(filePath);
  }
});

test("maybeHeartbeat fires at most once per hour while ON", () => {
  const filePath = tmpFile();
  try {
    const log = createBotUptimeLog(filePath);
    const t0 = 1_700_000_400_000;
    log.recordTransition(ctx({ ts: t0 }));
    const hb1 = log.maybeHeartbeat(ctx({ ts: t0 + 1000 }));
    assert.ok(hb1);
    assert.equal(hb1!.event, "heartbeat");
    assert.equal(log.maybeHeartbeat(ctx({ ts: t0 + 30 * 60 * 1000 })), null);
    const hb2 = log.maybeHeartbeat(ctx({ ts: t0 + 61 * 60 * 1000 }));
    assert.ok(hb2);
  } finally {
    cleanup(filePath);
  }
});

test("getSnapshot redacts nothing secret and reports current + windows", () => {
  const filePath = tmpFile();
  try {
    const log = createBotUptimeLog(filePath);
    const t0 = 1_700_000_500_000;
    log.recordTransition(ctx({ ts: t0, reason: "start" }));
    const snap = log.getSnapshot(ctx({ state: "WATCHING", enabled: true, paperMode: true }), 10);
    assert.equal(snap.current.on, true);
    assert.equal(snap.current.paperMode, true);
    assert.equal(snap.current.sinceTs, t0);
    assert.ok(snap.recent.length >= 1);
    assert.equal(typeof snap.last24h.onMs, "number");
    assert.equal(typeof snap.last7d.offMs, "number");
    // No secret-looking keys
    const blob = JSON.stringify(snap);
    assert.equal(/privateKey|apiKey|secret|password/i.test(blob), false);
  } finally {
    cleanup(filePath);
  }
});

test("wiring: trading-bot + index call bot-uptime-log (source contract)", () => {
  const dir = path.dirname(new URL(import.meta.url).pathname);
  const bot = fs.readFileSync(path.join(dir, "trading-bot.ts"), "utf8");
  const index = fs.readFileSync(path.join(dir, "..", "index.ts"), "utf8");
  const routes = fs.readFileSync(path.join(dir, "..", "routes", "bot.ts"), "utf8");
  assert.match(bot, /bot-uptime-log/);
  assert.match(bot, /recordTransition/);
  assert.match(bot, /onProcessBoot/);
  assert.match(index, /bot-uptime-log/);
  assert.match(index, /onProcessStop/);
  assert.match(routes, /\/bot\/uptime/);
});
