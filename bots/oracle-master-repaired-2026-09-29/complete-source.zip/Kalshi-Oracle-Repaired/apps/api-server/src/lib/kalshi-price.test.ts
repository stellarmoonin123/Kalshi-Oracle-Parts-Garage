import assert from "node:assert/strict";
import test from "node:test";
import { fetchKalshiSettlements, getCurrentBtcPriceFromKalshi, inferBtcPrice, kalshiTickQuoteAgeMs, resetSettlementCacheForTests } from "./kalshi-price.js";
import { BTC_FLOOR_FALLBACK } from "./constants.js";

// ── Fake Kalshi /markets pagination ─────────────────────────────────────────
//
// Builds `total` settled markets, newest-first (as Kalshi returns them), and
// serves them page-by-page via a `cursor` query param, mimicking the real API.

function fakeMarket(i: number, resultOverride?: string) {
  // i=0 is the most recent settlement; ts descends as i grows.
  const ts = 1_800_000_000 - i * 900; // 900s = 15min apart
  return {
    ticker: `KXBTC15M-FAKE-${i}`,
    floor_strike: 60000 + i,
    result: resultOverride ?? "yes",
    settle_time: new Date(ts * 1000).toISOString(),
    open_time: new Date((ts - 900) * 1000).toISOString(),
  };
}

function installFakeKalshi(total: number, pageSize: number, brokenIndices: Set<number> = new Set()) {
  const all = Array.from({ length: total }, (_, i) => fakeMarket(i, brokenIndices.has(i) ? "" : undefined));
  const original = globalThis.fetch;
  globalThis.fetch = (async (url: string | URL) => {
    const u = new URL(String(url));
    const cursor = u.searchParams.get("cursor");
    const start = cursor ? Number(cursor) : 0;
    const page = all.slice(start, start + pageSize);
    const nextStart = start + pageSize;
    const nextCursor = nextStart < all.length ? String(nextStart) : undefined;
    return {
      ok: true,
      status: 200,
      json: async () => ({ cursor: nextCursor, markets: page }),
    } as Response;
  }) as typeof fetch;
  return () => { globalThis.fetch = original; };
}

test("fetchKalshiSettlements returns the MOST RECENT rows, not the oldest page slice", async () => {
  resetSettlementCacheForTests();
  const restore = installFakeKalshi(1000, 1000);
  try {
    // 2026-08-04 bug: a small `limit` against a big cached page used to slice
    // from the front (oldest) of an oldest→newest array, serving days-stale
    // data to every short chart timeframe. It must now return the tail.
    const rows = await fetchKalshiSettlements(10, "KXBTC15M", true);
    assert.equal(rows.length, 10);
    // fakeMarket(0) is the most recent; sorted oldest→newest the last entry
    // must be fakeMarket(0)'s floor strike (60000), not fakeMarket(990)'s.
    assert.equal(rows[rows.length - 1].floorStrike, 60000);
    assert.equal(rows[0].floorStrike, 60009);
  } finally {
    restore();
  }
});

test("fetchKalshiSettlements paginates through `cursor` when one page isn't enough", async () => {
  resetSettlementCacheForTests();
  const restore = installFakeKalshi(3500, 1000);
  try {
    const rows = await fetchKalshiSettlements(2688, "KXBTC15M", true);
    // Must have paged far enough to satisfy the request, not been capped at
    // a single 1000-row page (the pre-fix behavior for any interval needing
    // more than one page, e.g. 4h/12H/1D charts).
    assert.ok(rows.length >= 2688, `expected >= 2688 rows, got ${rows.length}`);
    assert.equal(rows[rows.length - 1].floorStrike, 60000); // still the most recent
  } finally {
    restore();
  }
});

test("fetchKalshiSettlements stops paginating once real history runs out (raw, not filtered, page size)", async () => {
  resetSettlementCacheForTests();
  // Only 1500 real markets exist; requesting more must not hang or error.
  const restore = installFakeKalshi(1500, 1000);
  try {
    const rows = await fetchKalshiSettlements(10_000, "KXBTC15M", true);
    assert.equal(rows.length, 1500);
  } finally {
    restore();
  }
});

test("a handful of unresolved markets on a page must not falsely trigger early exhaustion", async () => {
  resetSettlementCacheForTests();
  // Page 1 has 1000 raw markets but 5 lack a valid yes/no result — the
  // *filtered* count (995) is below page size even though real history
  // continues on page 2. Exhaustion must key off the raw count.
  const broken = new Set([10, 20, 30, 40, 50]);
  const restore = installFakeKalshi(2500, 1000, broken);
  try {
    const rows = await fetchKalshiSettlements(2000, "KXBTC15M", true);
    assert.ok(rows.length >= 1990, `expected pagination to continue past page 1, got ${rows.length} rows`);
  } finally {
    restore();
  }
});


test("kalshiTickQuoteAgeMs / getCurrentBtcPriceFromKalshi key off quoteTs not heartbeat ts", () => {
  const now = Date.now();
  const staleBook = {
    ts: now, // heartbeat just refreshed message time
    quoteTs: now - 60_000, // real book is a minute old
    floorStrike: 80_000,
    yesBid: 40, yesAsk: 42, noBid: 58, noAsk: 60,
    yesPrice: 41, noPrice: 59,
    lastPrice: 41, volume: 1, openInterest: 1,
    ticker: "T", closeTime: new Date(now + 600_000).toISOString(),
    source: "ws" as const,
  };
  assert.ok(kalshiTickQuoteAgeMs(staleBook, now) >= 60_000);
  // Fresh ts must NOT make BRTI inference look live when quoteTs is stale.
  const px = getCurrentBtcPriceFromKalshi(() => staleBook as never, 30_000);
  assert.equal(px, BTC_FLOOR_FALLBACK);

  const freshBook = { ...staleBook, quoteTs: now - 1_000 };
  assert.ok(kalshiTickQuoteAgeMs(freshBook, now) < 30_000);
  const live = getCurrentBtcPriceFromKalshi(() => freshBook as never, 30_000);
  assert.ok(live > 0 && live !== BTC_FLOOR_FALLBACK);
});


test("inferBtcPrice one-sided book does not halve mid (Krypt _mid_up)", () => {
  const now = Date.now();
  const base = {
    ts: now, quoteTs: now,
    floorStrike: 80_000,
    noBid: 0, noAsk: 0, noPrice: 0,
    lastPrice: 0, volume: 1, openInterest: 1,
    ticker: "T", closeTime: new Date(now + 600_000).toISOString(),
    source: "ws" as const,
  };
  const both = inferBtcPrice({ ...base, yesBid: 40, yesAsk: 44, yesPrice: 42 } as never);
  const bidOnly = inferBtcPrice({ ...base, yesBid: 42, yesAsk: 0, yesPrice: 42 } as never);
  const halved = inferBtcPrice({ ...base, yesBid: 21, yesAsk: 0, yesPrice: 21 } as never);
  // Bid-only at 42¢ should track both-sides mid~42, NOT the (42+0)/2=21 path.
  assert.ok(Math.abs(bidOnly - both) < Math.abs(halved - both),
    `bid-only should stay near both-sides mid; both=${both} bidOnly=${bidOnly} halved=${halved}`);
});
