/**
 * Convert an incident's persisted timestamps to the API duration value.
 *
 * A recoveredAt written by a clock that is behind the clock that wrote
 * startedAt must not expose a negative duration to health consumers.
 */
export function getIncidentDurationSecs(
  startedAt: Date,
  recoveredAt: Date | null,
): number | null {
  if (recoveredAt === null) return null;

  const durationMs = recoveredAt.getTime() - startedAt.getTime();
  return Math.max(0, Math.round(durationMs / 1000));
}