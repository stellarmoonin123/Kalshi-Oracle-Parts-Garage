/**
 * What may run on the main 15m evaluate tick.
 * PAPER_SCALP / leftover modules stay on disk. This file is the only
 * permission for those engines to run inside evaluateStrategiesForBot.
 * Not a new edge model. Does not import trading-bot.
 */
import {
  ALL_STRATEGY_IDS,
  FROZEN_CC_STRATEGY_ID,
  unionFrozenEvaluateDisabled,
} from "./frozen-cc.js";
import { isPaperReleaseStrategyAllowed } from "./paper-release-policy.js";

/** Library ids frozen-cc does not list — they still sit in STRATEGIES. */
export const LEFTOVER_EVALUATE_EXTRA_IDS = [
  "PAPER_SCALP",
  "TICKET_WAVE",
  "HA_FLIP",
  "NO_CROSS",
] as const;

export function leftoverMayEvaluateOnMain15m(cfg: {
  frozenCcMode?: boolean;
  paperMode?: boolean;
}): boolean {
  if (cfg.frozenCcMode === true) return false;
  if (cfg.paperMode === true) return false;
  return true;
}

export function unionMain15mEvaluateDisabled(
  incoming: Iterable<string> = [],
  cfg: { frozenCcMode?: boolean; paperMode?: boolean },
): string[] {
  const set = new Set<string>([...incoming]);
  if (cfg.frozenCcMode === true) {
    for (const id of unionFrozenEvaluateDisabled()) set.add(id);
  }
  if (!leftoverMayEvaluateOnMain15m(cfg)) {
    for (const id of ALL_STRATEGY_IDS) {
      if (id !== FROZEN_CC_STRATEGY_ID && !isPaperReleaseStrategyAllowed(id)) set.add(id);
    }
    for (const id of LEFTOVER_EVALUATE_EXTRA_IDS) set.add(id);
  }
  return [...set];
}

/**
 * Main-tick PAPER_SCALP. Module / decidePaperScalp stay.
 * Paper and frozen CC never call it. Live still requires fee-net > skip.
 */
export function paperScalpRunsOnMain15mEvaluate(cfg: {
  frozenCcMode?: boolean;
  paperMode?: boolean;
  feeNetBeatsSkip?: boolean;
}): boolean {
  if (cfg.frozenCcMode === true) return false;
  if (cfg.paperMode === true) return false;
  return cfg.feeNetBeatsSkip === true;
}

export function paperScalpOffMainEvaluateReason(cfg: {
  frozenCcMode?: boolean;
  paperMode?: boolean;
  feeNetBeatsSkip?: boolean;
}): "frozen_cc_no_scalp" | "fee_net_does_not_beat_skip" | null {
  if (paperScalpRunsOnMain15mEvaluate(cfg)) return null;
  if (cfg.frozenCcMode === true) return "frozen_cc_no_scalp";
  return "fee_net_does_not_beat_skip";
}

/** Paper/frozen never add-to-position. Live leftover only when both false. */
export function paperDeskAddToPositionMayRun(cfg: {
  paperMode?: boolean;
  frozenCcMode?: boolean;
}): boolean {
  if (cfg.paperMode === true || cfg.frozenCcMode === true) return false;
  return true;
}
