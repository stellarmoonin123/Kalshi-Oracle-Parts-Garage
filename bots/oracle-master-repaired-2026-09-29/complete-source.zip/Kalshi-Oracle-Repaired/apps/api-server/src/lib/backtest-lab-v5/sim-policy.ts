/**
 * backtest-lab-v5/sim-policy.ts
 *
 * GO — BACKTEST LAB v5 + CONTINUOUS POLICY REGRESSION (2026-08-22), PART I-B.
 *
 * A `SimPolicy` is a fully self-contained, serializable description of "how
 * admit decisions are made" — the knobs the causal engine (causal-sim.ts)
 * needs to replay a policy against real historical candles. It intentionally
 * does NOT read live BotConfig/DB state: every field the pipeline needs is
 * right here, so a `SimPolicy` can be snapshotted, diffed, and re-run
 * byte-for-byte later (see policy-snapshot.ts).
 *
 * Two presets are provided:
 *   - POLICY_LEAN   — mirrors the CURRENT live policy after Steps 1-5 of the
 *                      "GO — LEAN ADMIT" reship (task #469).
 *   - POLICY_LEGACY — mirrors the policy's state *before* those steps (the
 *                      "pre-LEAN spirit": hard 2-strategy consensus, no
 *                      specialist packs, condition-adapter suppression
 *                      actually applied live, and the 4 strategy flags off).
 *
 * Values below are cited against the exact commits that changed them so a
 * future reader can verify LEGACY still means what it says even after more
 * live policy steps ship. Re-verify these citations before reusing this file
 * for a "vNext vs LEAN" comparison — LEAN should always track CURRENT live,
 * LEGACY should stay pinned to this historical baseline unless a new
 * "pre-LEAN" reference point is explicitly requested.
 */

export type ConsensusMode = 'solo' | 'require2';
export type PackMode = 'off' | 'enforce';

export interface SimPolicyFlags {
  /** Gates BOTH TOP_REVERSAL and BOTTOM_REVERSAL (trading-bot.ts's single
   *  topReversalEnabled/bottomReversalEnabled pair, always toggled together
   *  by the Step 2 commit). */
  topBottom:      boolean;
  /** Gates BOLLINGER_BAND (bollingerBandStrategyEnabled). */
  bollinger:      boolean;
  /** Gates SETTLEMENT_PREDICTION (settlementConsensusVoteEnabled). */
  settlementVote: boolean;
}

export interface SimPolicy {
  id:    string;
  label: string;

  /** Confidence floor (0-100 scale, matches BotConfig.minConfidence). */
  minConfidence: number;
  /** Velocity floor in $/min absolute (matches BotConfig.minVelocity). */
  minVelocity:   number;

  /** 'solo' = current live rule (pre-trade-sim.ts checkStrategyConsensus,
   *  `agreeing >= 1`, GO LEAN ADMIT Item D, 2026-08-22).
   *  'require2' = pre-LEAN rule (`agreeing >= 2` hard block, the A3
   *  execution-integrity fix Item D reversed). Both replay through the SAME
   *  real `checkStrategyConsensus()` via its `requireMode` parameter — see
   *  that function's doc comment for why this is a safe additive param. */
  consensusMode: ConsensusMode;

  /** 'enforce' = specialistPacksMode live value (post-2026-08-18): the
   *  active pack's eligible-strategy allowlist is the ONLY admission gate
   *  for which strategies may fire this tick.
   *  'off' = no pack filtering at all — every enabled/non-quarantined
   *  strategy is eligible regardless of regime/volume (pre-pack-rollout
   *  behavior). */
  packMode: PackMode;

  /** Ceiling this policy asserts for a pack's confBump. NOTE (documented
   *  simplification): the actual per-pack confBump VALUES always come from
   *  specialist-packs.ts's live SPECIALIST_PACKS table, which is already
   *  clamped to <= 1 for every pack (Step 4, commit adca1b8, 2026-08-22).
   *  This field is not currently used to re-scale those values — it exists
   *  so a future policy variant (e.g. "LEAN with pre-Step-4 bumps") can be
   *  added without a schema change, and so LEGACY's packConfBumpMax
   *  documents what the bumps WERE before Step 4 (3-4) even though it has
   *  zero live effect while packMode='off'. */
  packConfBumpMax: number;

  /** true = condition-adapter's per-regime `suppressStrategies` list is
   *  MERGED into the live disabled-strategy set (pre-Step-3 / "pre-LEAN
   *  spirit" behavior — the suppression was a real veto).
   *  false = current live behavior (Step 3, commit 7ac31de, 2026-08-22):
   *  suppression is computed and logged (`would_suppress`) but never
   *  applied — packs are the sole eligibility allowlist. */
  conditionSuppressLive: boolean;

  flags: SimPolicyFlags;

  /** Extra FLAT fee cents added ON TOP of the real Kalshi taker fee
   *  (kalshiFeeCents, computed dynamically per trade — this is not a
   *  replacement for it). 0 = pure real-fee model. Used by the sensitivity
   *  harness to test a "fees went up" scenario without touching the
   *  underlying live fee formula. */
  feeCents: number;

  /** Extra FLAT slippage cents charged per trade, on top of the real fee.
   *  Defaults to KALSHI_EXPECTED_SLIPPAGE_CENTS (1.5c) — the same baseline
   *  live's computeTradeEV() uses when no real-time spread/velocity context
   *  is available. */
  slipCents: number;
}

export const POLICY_LEAN: SimPolicy = {
  id:    'LEAN',
  label: 'LEAN (current live policy, post Steps 1-5, 2026-08-22)',
  minConfidence: 55,        // persisted .bot-config.json (Step 5A, 2026-08-22)
  minVelocity:   24,        // unchanged since before this reship
  consensusMode: 'solo',    // pre-trade-sim.ts: agreeing >= 1 (Step 1 / Item D)
  packMode:      'enforce', // specialistPacksMode live default
  packConfBumpMax: 1,       // Step 4 clamp (adca1b8)
  conditionSuppressLive: false, // Step 3 disarm (7ac31de) — would_suppress only
  flags: { topBottom: true, bollinger: true, settlementVote: true }, // Step 2 (5163503)
  feeCents:  0,
  slipCents: 1.5,
};

export const POLICY_LEGACY: SimPolicy = {
  id:    'LEGACY',
  label: 'LEGACY (pre-LEAN spirit — policy state before task #469 reship)',
  minConfidence: 65,        // BotConfig default before the Step 5A persisted-config change
  minVelocity:   24,        // unchanged
  consensusMode: 'require2', // pre-Step-1: A3 execution-integrity fix, agreeing >= 2 hard block
  packMode:      'off',      // before specialist packs went live (2026-08-18)
  packConfBumpMax: 4,        // pre-Step-4 bump ceiling (SQUEEZE/LOW_VOL/TRANSITION were 3-4); unused while packMode='off'
  conditionSuppressLive: true, // pre-Step-3: suppressStrategies was a real veto
  flags: { topBottom: false, bollinger: false, settlementVote: false }, // pre-Step-2 defaults
  feeCents:  0,
  slipCents: 1.5,
};

export function clonePolicy(p: SimPolicy): SimPolicy {
  return { ...p, flags: { ...p.flags } };
}
