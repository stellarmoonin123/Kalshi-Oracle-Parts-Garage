/**
 * Leftover live Kalshi unfilled cancel + one re-quote.
 * Paper fills never arm this. Does not ENABLE, cut EV/Kelly/9%, or flip paperMode.
 */
import { db, botTrades } from "@workspace/db";
import { eq } from "drizzle-orm";
import { KALSHI_API_DOMAIN, kalshiEventsOrderPath, kalshiOrderStatusPath, kalshiTakerFeeCents, getEntryPriceBand } from "./constants.js";
import { fetchWithRetry } from "./fetch-retry.js";
import { kalshiWS } from "./kalshi-ws.js";
import { kalshiAuthHeadersAsync } from "./kalshi-auth.js";
import { canReusePreTradeAdmissionForRequote, getPreTradeEntryPath } from "./pre-trade-sim.js";
import { buildExitReasonText } from "./trade-narrative.js";

type EntryOrderStatusSnapshot = {
  filled: number;
  status: string;
  avgPriceCents: number | null;
};

export const LEFTOVER_LIVE_UNFILLED_FUNNEL_LOADED = true as const;

export const FROZEN_LIVE_UNFILLED_MARKERS = [
  "unfilled after 12 s",
  "Re-quoting",
  "cancelUnfilledOrder ran on its own",
] as const;

export type LeftoverLiveUnfilledHelpers = {
  resolveEntryFillOutcome: (filledCount: number, requestedContracts: number) => {
    action: "unfilled" | "partial" | "full";
    filled: number;
    remainingContracts: number;
  };
  getSecsRemaining: () => number;
  MAX_CHASE: number;
  SWEEP_PREMIUM: number;
};

export async function leftoverLiveUnfilledFunnel(
  this: any,
  args: { orderId: string; dbId: number | null } & LeftoverLiveUnfilledHelpers,
): Promise<void> {
  const { orderId, dbId, resolveEntryFillOutcome, getSecsRemaining, MAX_CHASE, SWEEP_PREMIUM } = args;
    // 8 s window: Kalshi's thin order book sometimes takes several seconds for a
    // counter-party to arrive. 5 s was too short and was cancelling orders that
    // would have filled at 6–7 s. 8 s still exits well before the next tick.
    await new Promise(r => setTimeout(r, 12_000));

    // Trade may have already settled, been cancelled, or moved on — skip.
    if (!this.openTrade || this.openTrade.orderId !== orderId) return;

    try {
      // GET order status: V2 events path returns 404 for GET; use legacy path (still valid).
      // Bounded retry on network-level failure only (dropped packet, DNS blip) —
      // a definitive HTTP response (any status) is never retried here.
      const statusPath = kalshiOrderStatusPath(orderId);
      const sr = await fetchWithRetry(`${KALSHI_API_DOMAIN}${statusPath}`, {
        headers: { ...await kalshiAuthHeadersAsync("GET", statusPath), Accept: "application/json" },
      });
      if (!sr.ok) return; // can't confirm — leave trade open

      const statusData  = (await sr.json()) as { order?: { filled_count?: number; status?: string; avg_price?: number } };
      const filled      = statusData.order?.filled_count ?? 0;
      const orderStatus = (statusData.order?.status ?? "").toLowerCase();
      const requestedContracts = this.openTrade?.contracts ?? 0;

      if (filled > 0 || orderStatus === "executed") {
        // Order filled — but check if the fill price makes sense.
        // Kalshi can fill a limit order at ANY price ≤ our limit, so if the
        // market moved sharply after our evaluation the fill could be far below
        // minEntryPrice (e.g. 1¢ when we expected 30¢).  That means we're in
        // a position the pre-order guard would have blocked — exit immediately.
        let snapshot: EntryOrderStatusSnapshot = {
          filled,
          status: orderStatus,
          avgPriceCents: statusData.order?.avg_price != null
            ? Math.round(statusData.order.avg_price * 100)
            : null,
        };

        // Task #156: reconcile openTrade.contracts down to the ACTUAL filled
        // count when Kalshi only partially filled the order. Every downstream
        // consumer of
        // openTrade.contracts — P&L totals, fee calc just below, and the
        // eventual close-order size — was still using the original requested
        // size, silently pricing/closing phantom contracts that were never
        // actually opened.
        // Kalshi's terminal "executed" status is authoritative even while
        // filled_count lags behind. Treat it as the entire requested order;
        // otherwise a 5-contract execution briefly reporting count=2 could
        // leave three live contracts untracked.
        let fillDecision = resolveEntryFillOutcome(
          snapshot.status === "executed" ? requestedContracts : snapshot.filled,
          requestedContracts,
        );
        if (fillDecision.action === "partial") {
          const reconciledSnapshot = await this.cancelPartialEntryRemainder(orderId, snapshot, requestedContracts);
          if (!reconciledSnapshot) return; // preserve requested size until Kalshi confirms final exposure
          snapshot = reconciledSnapshot;
          fillDecision = resolveEntryFillOutcome(
            snapshot.status === "executed" ? requestedContracts : snapshot.filled,
            requestedContracts,
          );
        }
        const actualFilled = fillDecision.filled;
        const isFullFill = fillDecision.action === "full";
        const fillCents = snapshot.avgPriceCents;
        if (this.openTrade && fillDecision.action === "partial") {
          this.log("warn",
            `⚠️ Partial fill on ${orderId}: requested ${requestedContracts}, filled ${actualFilled}, ` +
            `remainder ${fillDecision.remainingContracts} ` +
            `(status=${snapshot.status || "unknown"}). Reconciled position size to actual fill.`
          );
          this.openTrade.contracts = actualFilled;
        }

        // Track the fill. Price slippage is recorded only for a complete fill:
        // avg_price on a partial order describes only the contracts filled so
        // far, not the requested order as a whole. This keeps the session and
        // persisted slippage metrics from presenting an incomplete order as a
        // fully-filled sample.
        // Capture the strategy before any later state transition can clear the
        // open trade, so the session breakdown remains correctly attributed.
        const fillStrategyId = this.openTrade?.strategyId ?? null;
        const expectedFillPriceCents = this.openTrade?.entryPriceCents ?? null;
        const slippage = isFullFill && fillCents !== null && expectedFillPriceCents !== null
          ? fillCents - expectedFillPriceCents
          : null;
        this.recordSessionOrderFilled(fillStrategyId, slippage);
        if (this.openTrade) {
          // Fix (Task #154/#155 investigation): this used to be gated on
          // `fillCents !== null`, so whenever Kalshi's status response omitted
          // avg_price (observed in production — logged fills showing "(?¢)")
          // the ENTIRE persistence write was skipped, silently dropping
          // filledAt/contractsFilled/feeCents too — not just the price/slippage
          // fields that legitimately depend on knowing the price. Verified
          // against prod DB: 0/211 bot_trades rows had filled_at set despite
          // 150 resolved win/loss trades. Now: always persist that a fill
          // happened; only the price-dependent fields are conditional.
          this.log("info",
            `📋 Fill confirmed: ${fillCents !== null ? `${fillCents}¢` : 'price unknown'} ` +
            `(expected ${this.openTrade.entryPriceCents}¢` +
            `${slippage !== null
              ? `, slippage ${slippage >= 0 ? '+' : ''}${slippage}¢`
              : (isFullFill ? ', slippage unavailable' : ', partial fill — slippage not recorded')}) — session: ` +
            `${this.sessionFillStats.filled}/${this.sessionFillStats.placed} filled`
          );
          // Persist the confirmed fill so the position survives a restart.
          // Complete fills also retain price/slippage analytics; partial
          // fills retain their actual price and size, but deliberately leave
          // slippage null until there is a complete order-level sample.
          // feeCents uses the reconciled count (= filled, capped at requested)
          // so a partial fill is never billed for contracts it never got.
          if (dbId != null) {
            const feePriceCents = fillCents ?? this.openTrade.entryPriceCents;
            db.update(botTrades)
              .set({
                filledAt: new Date(),
                contractsFilled: actualFilled,
                feeCents: kalshiTakerFeeCents(feePriceCents, actualFilled),
                ...(fillCents !== null
                  ? { fillPriceCents: fillCents, ...(slippage !== null ? { slippageCents: slippage } : {}) }
                  : {}),
              })
              .where(eq(botTrades.id, dbId))
              .catch((e: unknown) => this.log("warn", `DB write failed for fill ${dbId}: ${e}`));
          }
        }

        // Judge the fill against the band ACTUALLY enforced when this order
        // was placed (trade.entryBandMin), not a value recomputed now — the
        // standard band's effective min/max can drift tick-to-tick under
        // ARIA/adaptive-condition control, and an OTM strategy filling at
        // e.g. 15¢ is a perfectly normal fill within its own sweet spot, not
        // a bad fill (Task #368 review).
        const expectedMinCents = this.openTrade?.entryBandMin ?? this.config.minEntryPrice;
        if (fillCents !== null && fillCents < expectedMinCents && this.openTrade) {
          this.log("warn",
            `🚨 Fill price ${fillCents}¢ is below expected minimum ${expectedMinCents}¢ for ` +
            `${this.openTrade.strategyId} — market moved after evaluation. Exiting bad fill immediately.`
          );
          await this.exitEarly("BAD_FILL_PRICE", fillCents);
        }
        return; // filled (good or force-exited above)
      }

      // Order is still resting unfilled — cancel via V2 events endpoint.
      // Only clear bot state if cancel succeeds; leave trade open if cancel fails
      // to avoid unmanaged live exposure (bot would think no position is open).
      const cancelPath = kalshiEventsOrderPath(orderId);
      let cancelOk = false;
      try {
        const cr = await fetch(`${KALSHI_API_DOMAIN}${cancelPath}`, {
          method:  "DELETE",
          headers: { ...await kalshiAuthHeadersAsync("DELETE", cancelPath), Accept: "application/json" },
          signal:  AbortSignal.timeout(4_000),
        });
        let repollNeeded = false;
        if (cr.ok) {
          // A 2xx cancel is NOT proof that nothing filled: contracts can fill
          // between the status GET above and this DELETE, and Kalshi returns
          // the (partially) executed order in the cancel body. Treating every
          // 2xx as "clean cancel" cleared openTrade and re-quoted a new order
          // on top of live contracts. Inspect the body; re-poll on any fill.
          const cancelBody = (await cr.json().catch(() => null)) as
            | { order?: { filled_count?: number; status?: string } }
            | null;
          const cancelFilled = cancelBody?.order?.filled_count ?? 0;
          const cancelStatus = (cancelBody?.order?.status ?? "").toLowerCase();
          if (cancelFilled > 0 || cancelStatus === "executed") {
            this.log("warn",
              `Entry order ${orderId} — cancel returned OK but reports ${cancelFilled} filled (status=${cancelStatus || "?"}). Re-polling to reconcile the fill…`
            );
            repollNeeded = true;
          } else {
            cancelOk = true;
          }
        } else if (cr.status === 404) {
          // 404 on cancel means the order no longer exists on Kalshi — it was
          // either already filled or auto-cancelled by the exchange (e.g. GTC
          // expired, market closed). Re-poll the order status to determine which.
          this.log("info",
            `Entry order ${orderId} — cancel returned 404 (order already consumed). Re-polling to confirm fill…`
          );
          repollNeeded = true;
        }
        if (repollNeeded) {
          try {
            const repollPath = kalshiOrderStatusPath(orderId);
            const rp = await fetchWithRetry(`${KALSHI_API_DOMAIN}${repollPath}`, {
              headers: { ...await kalshiAuthHeadersAsync("GET", repollPath), Accept: "application/json" },
            });
            if (rp.ok) {
              const rpData = (await rp.json()) as { order?: { filled_count?: number; status?: string; avg_price?: number } };
              const rpFilled = rpData.order?.filled_count ?? 0;
              const rpStatus = (rpData.order?.status ?? "").toLowerCase();
              // "executed" means FILLED even when filled_count lags/omits.
              // Treating it as unfilled cleared bot state and re-quoted a new
              // order → duplicate live positions (observed 3 fills in one period).
              if (rpFilled > 0 || rpStatus === "executed") {
                // Confirmed filled — leave trade open and track the fill
                let snapshot: EntryOrderStatusSnapshot = {
                  filled: rpFilled,
                  status: rpStatus,
                  avgPriceCents: rpData.order?.avg_price != null
                    ? Math.round(rpData.order.avg_price * 100)
                    : null,
                };
                const fillStrategyId = this.openTrade?.strategyId ?? null;
                const expectedFillPriceCents = this.openTrade?.entryPriceCents ?? null;
                const requestedContracts = this.openTrade?.contracts ?? 0;
                let fillDecision = resolveEntryFillOutcome(
                  snapshot.status === "executed" ? requestedContracts : snapshot.filled,
                  requestedContracts,
                );
                if (fillDecision.action === "partial") {
                  const reconciledSnapshot = await this.cancelPartialEntryRemainder(orderId, snapshot, requestedContracts);
                  if (!reconciledSnapshot) return; // preserve requested size until Kalshi confirms final exposure
                  snapshot = reconciledSnapshot;
                  fillDecision = resolveEntryFillOutcome(
                    snapshot.status === "executed" ? requestedContracts : snapshot.filled,
                    requestedContracts,
                  );
                }
                const actualFilled = fillDecision.filled;
                const isFullFill = fillDecision.action === "full";
                const fillCents = snapshot.avgPriceCents;
                const slippage = isFullFill && fillCents !== null && expectedFillPriceCents !== null
                  ? fillCents - expectedFillPriceCents
                  : null;
                if (this.openTrade && fillDecision.action === "partial") {
                  this.log("warn",
                    `⚠️ Partial fill on ${orderId} (via repoll): requested ${requestedContracts}, ` +
                    `filled ${actualFilled}, remainder ${fillDecision.remainingContracts} ` +
                    `(status=${snapshot.status || "unknown"}). Reconciled position size to actual fill.`
                  );
                  this.openTrade.contracts = actualFilled;
                }
                this.recordSessionOrderFilled(fillStrategyId, slippage);
                this.log("info",
                  `✅ Order ${orderId} confirmed ${isFullFill ? "fully" : "partially"} filled via repoll ` +
                  `(${actualFilled}/${requestedContracts} @ ${fillCents ?? '?'}¢). Leaving trade open.`
                );
                // This branch previously recorded NOTHING beyond the log line —
                // not even the in-memory sessionFillStats slippage counter — so
                // every 404-then-repoll fill (a real, observed path; see the
                // "executed" status note above) silently dropped out of both
                // slippage tracking and the persisted record (Task #354 follow-up).
                // Fix (Task #154/#155 investigation): also stopped gating the
                // whole persistence write on fillCents !== null — Kalshi's
                // repoll response frequently omits avg_price (this is exactly
                // the "confirmed filled via repoll (?¢)" log line), which used
                // to mean filledAt/contractsFilled never got persisted for this
                // path at all. Always persist that a fill happened; the
                // price-dependent fields stay conditional on fillCents.
                if (this.openTrade) {
                  if (dbId != null) {
                    const feePriceCents = fillCents ?? this.openTrade.entryPriceCents;
                    db.update(botTrades)
                      .set({
                        filledAt: new Date(),
                        contractsFilled: actualFilled,
                        feeCents: kalshiTakerFeeCents(feePriceCents, actualFilled),
                        ...(fillCents !== null
                          ? { fillPriceCents: fillCents, ...(slippage !== null ? { slippageCents: slippage } : {}) }
                          : {}),
                      })
                      .where(eq(botTrades.id, dbId))
                      .catch((e: unknown) => this.log("warn", `DB write failed for repoll fill ${dbId}: ${e}`));
                  }
                }
                return;
              } else {
                // Auto-cancelled by Kalshi (e.g. GTC expired, market halted)
                this.log("warn",
                  `Order ${orderId} was auto-cancelled by Kalshi (status: ${rpData.order?.status ?? 'unknown'}). Treating as unfilled.`
                );
                cancelOk = true; // treat as a clean cancel — clear bot state
              }
            } else {
              // Can't confirm — leave trade open to avoid unmanaged exposure
              this.log("warn",
                `⚠️ Repoll for ${orderId} returned ${rp.status}. Cannot confirm fill — leaving trade open.`
              );
            }
          } catch (repollErr) {
            this.log("warn",
              `⚠️ Repoll for ${orderId} errored: ${(repollErr as Error).message}. Leaving trade open.`
            );
          }
        } else if (!cr.ok) {
          const errText = await cr.text().catch(() => "");
          this.log("warn",
            `⚠️ Entry order ${orderId} unfilled but cancel failed (${cr.status}): ${errText.slice(0, 120)}. ` +
            `Leaving trade open to avoid unmanaged exposure.`
          );
        }
      } catch (cancelErr) {
        this.log("warn",
          `⚠️ Entry order ${orderId} unfilled but cancel request errored: ${(cancelErr as Error).message}. ` +
          `Leaving trade open to avoid unmanaged exposure.`
        );
      }

      if (!cancelOk) return; // keep trade open — cancel wasn't confirmed

      // Task #345: this whole block mutates core bot state (openTrade, state,
      // tradedThisPeriod) and can end by placing a brand-new re-quote order —
      // exactly the kind of state transition the main tick loop's mutex exists
      // to serialize. Before this fix, cancelUnfilledOrder ran on its own
      // 12s setTimeout completely outside tick()'s tickRunning guard, so an
      // in-flight tick could read openTrade/state mid-mutation (e.g. see
      // state="WATCHING" with openTrade already nulled) or, worse, decide to
      // open its own new entry in the same window the re-quote below places
      // one — a real path to duplicate/overlapping live positions. Wait for
      // any in-flight tick to finish, then hold the same mutex for the
      // duration of this critical section so the two can never interleave.
      while (this.tickRunning) await new Promise(r => setTimeout(r, 50));
      this.tickRunning = true;
      try {
        const cancelledStrategyId = this.openTrade?.strategyId ?? null;
        this.recordSessionOrderCancelled(cancelledStrategyId);
        this.log("warn",
          `⚠️ Entry order ${orderId} unfilled after 12 s — cancelled. ` +
          `Spread may have moved. No position open. ` +
          `Session unfill rate: ${this.sessionFillStats.cancelled}/${this.sessionFillStats.placed} orders missed.`
        );

        this.setOpenTrade(null);
        this.settlementHoldActive = false;
        this.strikeCrossTicks     = 0;
        this.holdModeHardFloorTicks = 0;
        // Task #427 audit (Step 6): thesisVelocityAgainstTicks/basisFlipAgainstTicks
        // are the persistence counters for THESIS_BREAK_EXIT rule 1 and LAG_FLIP_EXIT
        // respectively — same dangling-counter class as strikeCrossTicks above, just
        // added later (2026-08-14) and missed when that fix landed. Without this, a
        // counter left at 1-2 ticks from this cancelled order could carry into the
        // next same-side trade and satisfy the ≥3-tick persistence gate within a
        // tick or two of opening, instead of requiring genuine fresh confirmation.
        this.thesisVelocityAgainstTicks = 0;
        this.basisFlipAgainstTicks      = 0;
        this.lagFlipBothAgainstSecStreak = 0;
        this.lagFlipLastSampleSec = -1;
        // P5 ARIA GUARDIAN: same dangling-state class as the counters above —
        // a stale tighten multiplier or rate-limit timestamp from a cancelled
        // order must not carry into the next trade.
        this.lastAriaGuardianEvalTs     = null;
        this.ariaGuardianTighten        = null;
        // Same dangling-counter class as above: a stale vol-buffer streak from
        // this cancelled order's entry evaluation must not carry into the next
        // entry attempt and get it one tick closer to the ">1" hard-block.
        this.sharedGateStaleStreak      = 0;
        this.state            = "WATCHING"; // stay WATCHING not IDLE — bot is still active this period
        this.tradedThisPeriod = true;       // keep true so we don't immediately re-enter

        if (dbId != null) {
          await db.update(botTrades)
            .set({
              outcome: "cancelled", cancelledAt: new Date(), cancelReason: "UNFILLED_TIMEOUT",
              contractsFilled: 0, exitReasonText: buildExitReasonText("UNFILLED_TIMEOUT", {}),
            })
            .where(eq(botTrades.id, dbId))
            .catch((e: unknown) => this.log("warn", `DB write failed for cancelled order ${dbId}: ${e}`));
        }

        // ── Re-quote once if price hasn't run away ──────────────────────────
        // Consume the stored context (clear first so a second cancel can't loop).
        const rq = this.requeueContext;
        this.requeueContext = null;

        if (rq) {
          const freshTick = kalshiWS.getLatest();
          const freshAgeMs = freshTick ? Date.now() - freshTick.ts : Infinity;

          if (freshTick && freshAgeMs < 4_000) {
            const currentAsk = rq.side === "yes" ? freshTick.yesAsk : freshTick.noAsk;
            const chase      = currentAsk - rq.originalAsk;

            if (MAX_CHASE > 0 && chase <= MAX_CHASE) {
              // Price moved within the chase limit — re-quote once at current ask + sweep.
              // Guard: MAX_CHASE > 0 required so that a 0-chase ceiling (re-quoting disabled)
              // does NOT trigger this branch even when chase === 0 (price didn't move).
              // chase <= 0 with MAX_CHASE = 0 was causing an infinite 8-second cancel loop.
              // Cap the re-quote at the ORIGINAL strategy's own band ceiling (as
              // actually enforced at order time), not the blanket standard
              // maxEntryPrice — an OTM re-quote must stay inside its own
              // tighter sweet spot (Task #368 review).
              const reQuoteMax = rq.params.entryBandMax ?? getEntryPriceBand(rq.params.strategyId ?? '').max;
              if (currentAsk > reQuoteMax) {
                // The ask has already moved past the strategy's own ceiling —
                // Math.min(reQuoteMax, currentAsk + premium) would submit a
                // limit BELOW the current ask, guaranteeing another unfilled
                // cancel/re-quote loop instead of a real order. Skip cleanly.
                this.log("info",
                  `⏭ Re-quote skipped — ask ${currentAsk}¢ already past band ceiling ${reQuoteMax}¢ for ${rq.params.strategyId}. Waiting next period.`
                );
              } else {
                const reAsk = Math.min(reQuoteMax, currentAsk + SWEEP_PREMIUM);
                this.log("info",
                  `🔄 Re-quoting ${rq.side.toUpperCase()} @ ${reAsk}¢ ` +
                  `(original ${rq.originalAsk}¢, chased +${chase}¢)`
                );
                const reQuotePath = getPreTradeEntryPath(reAsk);
                const originalPath = getPreTradeEntryPath(rq.params.entryPrice);
                if (!canReusePreTradeAdmissionForRequote(
                  rq.params.entryPrice,
                  reAsk,
                  rq.params.verdict,
                )) {
                  this.log("info",
                    `⏭ Re-quote skipped — ${originalPath}→${reQuotePath} ` +
                    `(${rq.params.entryPrice}¢→${reAsk}¢); price-sensitive path requires a fresh full admission`
                  );
                  return;
                }
                this.tradedThisPeriod = false; // allow re-entry
                // decisionAskCents is reset to the freshly-read currentAsk (not
                // spread from rq.params, which still carries the ORIGINAL
                // decision-time ask) — a re-quote already re-reads the live
                // book immediately above, so the freshness gate must judge it
                // against that fresh read, not the pre-chase ask it exists to
                // chase past.
                await this.placeOrder({
                  ...rq.params,
                  entryPrice: reAsk,
                  requoteCount: (rq.params.requoteCount ?? 0) + 1,
                  decisionAskCents: currentAsk,
                  // Refresh the clock for 15m re-quotes; hourly carries its own closeTimeMs.
                  secs: rq.params.contractDurationMins === 60 ? rq.params.secs : getSecsRemaining(),
                });
              }
            } else {
              this.log("info",
                `⏭ Re-quote skipped — ${MAX_CHASE === 0 ? 're-quoting disabled (MAX_CHASE=0)' : `ask moved +${chase}¢ (limit ${MAX_CHASE}¢)`}. Waiting next period.`
              );
            }
          }
        }
      } finally {
        this.tickRunning = false;
      }
    } catch (err) {
      this.log("warn", `⚠️ Fill-check for ${orderId} failed: ${(err as Error).message}`);
    }
}
