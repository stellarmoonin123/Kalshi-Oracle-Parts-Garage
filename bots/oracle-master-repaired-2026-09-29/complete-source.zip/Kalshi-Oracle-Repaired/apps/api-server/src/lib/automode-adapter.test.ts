/** QUARANTINE(P2): automode theater; hang-prone host asserts on trading-bot.ts. Never ENABLE automode. */
/**
 * automode-adapter.test.ts
 *
 * autoMode as ADAPTATION that can stay ON. Proves:
 *   - skip more when tape lies
 *   - size down in DD (never up)
 *   - learn from BOT fills only, 0.72–1.18x
 *   - composer cannot cut EV/Kelly/9%/minConfidence even when autoMode true
 *   - never enable engines / paperMode false / empty disabledStrategies
 *   - ledger 30720 is sane on bounce vs $313 start
 */
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import {
  LEARNING_WEIGHT_MIN,
  LEARNING_WEIGHT_MAX,
  COMPOSER_GATE_KEYS,
  adapterTouchesComposerGates,
  applyBotFillLearning,
  clampLearningWeight,
  computeAdaptation,
  drawdownSizeMult,
  echoOperatorFloors,
  freshLagDisagreeSkip,
  isBotFillOutcomeKey,
  tapeLieReasons,
  tapeLieBlocksTick,
} from "./automode-adapter.js";
import {
  computeAdaptationIsolate,
  echoOperatorFloorsIsolate,
  tapeLieBlocksTickIsolate,
} from "./automode-adapter.isolate.js";
import { applyComposerLocks, CONFIRM_AUTO_MODE_PHRASE } from "./composer-lock.js";
import { sanitizeConfigPatch, PATCH_FAIL_CLOSED_DISABLED } from "./config-patch-surface.js";
import { isSanePaperLedger } from "./paper-ledger.js";
import { HARD_RISK_LIMITS, EV_FLOOR, applyHardRiskLimits, kellyFraction } from "./admission.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT_SRC = readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const LOCK_SRC = readFileSync(path.join(DIR, "composer-lock.ts"), "utf8");
const TIGHTEN_SRC = readFileSync(path.join(DIR, "tighten-only.ts"), "utf8");

function composerBlock(): string {
  const start = BOT_SRC.indexOf("autoMode composer (Phase 2");
  assert.ok(start >= 0, "composer section header must remain (fail-closed rewrite)");
  return BOT_SRC.slice(start, start + 4500);
}

test.skip("autoMode off is a no-op (no skip, size 1, learn 1)", () => {
  const r = computeAdaptation({
    autoMode: false,
    tape: { lagStale: true, chaosMode: true, volumeBucket: "DEAD", lagAgreesWithSide: false },
    drawdownPct: 18,
    fromBotFill: true,
    learningWeight: 0.72,
  });
  assert.equal(r.skip, false);
  assert.equal(r.sizeMult, 1);
  assert.equal(r.learningWeight, 1);
  assert.deepEqual(r.skipReasons, []);
});

test.skip("tape: FRESH lag disagree is LAG_AGAINST; stale/DEAD observed not global skip; CHAOS not sit-on-hands", () => {
  assert.deepEqual(tapeLieReasons({ lagStale: true }), ["LAG_STALE"]);
  assert.deepEqual(tapeLieReasons({ lagAgreesWithSide: false }), []);
  assert.deepEqual(tapeLieReasons({ lagStale: false, lagAgreesWithSide: false }), ["LAG_AGAINST"]);
  assert.deepEqual(tapeLieReasons({ volumeBucket: "DEAD" }), ["DEAD_TAPE"]);
  assert.deepEqual(tapeLieReasons({ chaosMode: true }), ["CHAOS"]);
  assert.deepEqual(tapeLieReasons({ lagStale: false, volumeBucket: "NORMAL", chaosMode: false }), []);
  assert.equal(tapeLieBlocksTick(["CHAOS"]), false);
  assert.equal(tapeLieBlocksTick(["DEAD_TAPE"]), false, "DEAD sizes down; does not starve CC");
  assert.equal(tapeLieBlocksTick(["LAG_AGAINST"]), true);
  assert.equal(tapeLieBlocksTick(["CHAOS", "DEAD_TAPE"]), false);

  const r = computeAdaptation({
    autoMode: true,
    tape: { lagStale: true, volumeBucket: "DEAD", chaosMode: true, lagAgreesWithSide: false },
    drawdownPct: 0,
  });
  assert.equal(r.skip, false, "stale lag is unknown; no strategy → no skip");
  assert.ok(r.skipReasons.includes("LAG_STALE"));
  assert.ok(r.skipReasons.includes("DEAD_TAPE"));
  assert.ok(r.skipReasons.includes("CHAOS"));
  assert.equal(r.skipReasons.includes("LAG_AGAINST"), false);

  const chaosOnly = computeAdaptation({
    autoMode: true,
    tape: { chaosMode: true, volumeBucket: "NORMAL", lagStale: false },
    drawdownPct: 0,
  });
  assert.equal(chaosOnly.skip, false, "CHAOS must not empty the tick (later preserver)");
  assert.deepEqual(chaosOnly.skipReasons, ["CHAOS"]);
  assert.match(chaosOnly.summary, /chaos observed \(not sit-on-hands\)/);
  assert.doesNotMatch(chaosOnly.summary, /skip CHAOS/);
});

test.skip("honest tape does not skip", () => {
  const r = computeAdaptation({
    autoMode: true,
    tape: { lagStale: false, lagAgreesWithSide: true, volumeBucket: "NORMAL", chaosMode: false },
    drawdownPct: 0,
  });
  assert.equal(r.skip, false);
  assert.equal(r.sizeMult, 1);
});

test.skip("size down in DD: never > 1, milder extra taper, floor 0.7 at guard", () => {
  assert.equal(drawdownSizeMult(0), 1);
  assert.equal(drawdownSizeMult(-1), 1);
  assert.equal(drawdownSizeMult(8), 1);
  assert.ok(drawdownSizeMult(14) < 1);
  assert.ok(drawdownSizeMult(14) > 0.7);
  assert.equal(drawdownSizeMult(20), 0.7);
  assert.equal(drawdownSizeMult(40), 0.7);
  const r = computeAdaptation({
    autoMode: true,
    tape: { volumeBucket: "NORMAL" },
    drawdownPct: 14,
    drawdownGuardPct: 20,
  });
  assert.ok(r.sizeMult <= 1);
  assert.ok(r.sizeMult < 1);
  assert.ok(r.sizeMult >= 0.5);
});

test.skip("LOW/DEAD volume sizes down; DEAD does not skip (CC not TAPE_LIE starved)", () => {
  const low = computeAdaptation({
    autoMode: true,
    tape: { volumeBucket: "LOW", lagStale: false },
    drawdownPct: 0,
  });
  assert.equal(low.skip, false);
  assert.equal(low.sizeMult, 0.85);

  const dead = computeAdaptation({
    autoMode: true,
    tape: { volumeBucket: "DEAD" },
    drawdownPct: 0,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(dead.skip, false, "DEAD must not starve CC");
  assert.ok(dead.sizeMult <= 1);
  assert.equal(dead.sizeMult, 0.5);
});

test.skip("learn from BOT fills only, clamped 0.72–1.18x", () => {
  assert.equal(isBotFillOutcomeKey("bot_trades:12"), true);
  assert.equal(isBotFillOutcomeKey("sim_verdicts:1"), false);
  assert.equal(isBotFillOutcomeKey("manual"), false);
  assert.equal(isBotFillOutcomeKey(undefined), false);

  assert.equal(applyBotFillLearning(0.5, false), 1);
  assert.equal(applyBotFillLearning(1.5, true), LEARNING_WEIGHT_MAX);
  assert.equal(applyBotFillLearning(0.5, true), LEARNING_WEIGHT_MIN);
  assert.equal(applyBotFillLearning(1.0, true), 1);
  assert.equal(clampLearningWeight(Number.NaN), 1);

  const noBot = computeAdaptation({
    autoMode: true,
    tape: {},
    drawdownPct: 0,
    learningWeight: 0.5,
    fromBotFill: false,
  });
  assert.equal(noBot.learningWeight, 1);

  const bot = computeAdaptation({
    autoMode: true,
    tape: {},
    drawdownPct: 0,
    learningWeight: 1.4,
    fromBotFill: true,
  });
  assert.equal(bot.learningWeight, LEARNING_WEIGHT_MAX);
});

test.skip("adapter result never carries composer gate keys", () => {
  const r = computeAdaptation({
    autoMode: true,
    tape: { lagStale: true, volumeBucket: "DEAD", chaosMode: true },
    drawdownPct: 18,
    learningWeight: 0.72,
    fromBotFill: true,
  });
  assert.deepEqual(adapterTouchesComposerGates(r), []);
  for (const k of COMPOSER_GATE_KEYS) {
    assert.equal(Object.prototype.hasOwnProperty.call(r, k), false, k);
  }
});

test.skip("echoOperatorFloors copies config — spreading cannot cut", () => {
  const cfg = {
    minConfidence: 52,
    minVelocity: 24,
    maxContractsPerTrade: 60,
    stopLossCents: 22,
    profitTakeCents: 20,
    tradeWindowMinMin: 0.2,
    tradeWindowMaxMin: 15,
    minProbEdge: 5,
  };
  const echo = echoOperatorFloors(cfg);
  assert.equal(echo.minConfidence, 52);
  assert.equal(echo.minVelocity, 24);
  const merged = { ...cfg, ...echo, minConfidence: echo.minConfidence };
  assert.equal(merged.minConfidence, 52);
});

test.skip("applyComposerLocks: autoMode true forced false on paper without confirm", () => {
  const r = applyComposerLocks({
    autoMode: true,
    autoModeV2Mode: "suggest",
    useExpertAgent: false,
    ariaModel: "",
    paperMode: true,
  }, {});
  assert.equal(r.config.autoMode, false);
  assert.equal(r.config.paperMode, true);
  assert.ok(r.notes.some((n) => /CONFIRM AUTO MODE/i.test(n)));
});

test.skip("applyComposerLocks: autoMode true kept on paper with CONFIRM AUTO MODE", () => {
  const r = applyComposerLocks({
    autoMode: true,
    autoModeV2Mode: "suggest",
    useExpertAgent: false,
    ariaModel: "",
    paperMode: true,
  }, { confirmAutoMode: CONFIRM_AUTO_MODE_PHRASE });
  assert.equal(r.config.autoMode, true);
  assert.equal(r.config.paperMode, true);
});

test.skip("applyComposerLocks: autoMode true cannot flip paperMode false; paper forces autoMode off", () => {
  const r = applyComposerLocks({
    autoMode: true,
    autoModeV2Mode: "suggest",
    useExpertAgent: false,
    ariaModel: "",
    paperMode: false,
  }, {});
  assert.equal(r.config.paperMode, true);
  assert.equal(r.config.autoMode, false);
});

test.skip("PATCH: autoMode true refused without confirm; engines / empty disabled / paperMode false still refused", () => {
  const r = sanitizeConfigPatch({
    autoMode: true,
    paperMode: false,
    useExpertAgent: true,
    enable1HContracts: true,
    velocityStallReversalEnabled: true,
    settlementConsensusVoteEnabled: true,
    disabledStrategies: [],
  });
  assert.equal("autoMode" in r.accepted, false);
  assert.ok(r.refused.some(x => x.key === "autoMode"));
  assert.equal("paperMode" in r.accepted, false);
  assert.equal("useExpertAgent" in r.accepted, false);
  assert.equal("enable1HContracts" in r.accepted, false);
  assert.equal("velocityStallReversalEnabled" in r.accepted, false);
  const disabled = r.accepted.disabledStrategies as string[];
  assert.ok(disabled.length > 0, "empty disabledStrategies must not stick");
  for (const id of PATCH_FAIL_CLOSED_DISABLED) {
    assert.ok(disabled.includes(id), `must keep ${id}`);
  }
});

test.skip("EV 3¢ / 9% cap constants are untouched by the adapter module", () => {
  assert.equal(EV_FLOOR, 3);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  const adapterSrc = readFileSync(path.join(DIR, "automode-adapter.ts"), "utf8");
  assert.doesNotMatch(adapterSrc, /EV_FLOOR\s*=/);
  assert.doesNotMatch(adapterSrc, /maxRiskPctPerTrade\s*=/);
  assert.doesNotMatch(adapterSrc, /paperMode:\s*false/);
  assert.doesNotMatch(adapterSrc, /disabledStrategies:\s*\[\]/);
});

test.skip("composer block is fail-closed: never assigns condOverlay onto gates", () => {
  const block = composerBlock();
  assert.doesNotMatch(block, /minConfidence:\s*condOverlay/);
  assert.doesNotMatch(block, /minVelocity:\s*condOverlay/);
  assert.doesNotMatch(block, /minProbEdge:\s*condOverlay/);
  assert.doesNotMatch(block, /stopLossCents:\s*condOverlay/);
  assert.doesNotMatch(block, /profitTakeCents:\s*condOverlay/);
  assert.doesNotMatch(block, /tradeWindowMinMin:\s*condOverlay/);
  assert.doesNotMatch(block, /maxContractsPerTrade:\s*condOverlay/);
  assert.match(block, /echoOperatorFloors|this\.config\.minConfidence/);
  assert.match(block, /computeAdaptation/);
  assert.doesNotMatch(block, /autoModeV2Mode/);
});

test.skip("getEntryFilterBaseline never spreads lastAutoSettings over config", () => {
  assert.match(BOT_SRC, /getEntryFilterBaseline\(\): BotConfig \{[\s\S]{0,200}return this\.config;/);
  assert.doesNotMatch(
    BOT_SRC.slice(BOT_SRC.indexOf("private getEntryFilterBaseline()"), BOT_SRC.indexOf("private getEntryFilterBaseline()") + 400),
    /\.\.\.\(this\.lastAutoSettings/,
  );
});

test.skip("computeEffectiveWindow does not take window from autoSettings", () => {
  const start = BOT_SRC.indexOf("private computeEffectiveWindow()");
  const block = BOT_SRC.slice(start, start + 900);
  assert.doesNotMatch(block, /auto\.tradeWindowMinMin/);
  assert.match(block, /this\.config\.tradeWindowMinMin/);
});

test.skip("BotConfig.autoMode is documented as ADAPTATION that can stay ON", () => {
  assert.ok(BOT_SRC.includes("ADAPTATION that can stay ON"), "host includes (hang-safe)");
  assert.doesNotMatch(BOT_SRC, /true = AI picks config each trade/);
  assert.doesNotMatch(BOT_SRC, /composer: overwrites minConfidence/);
});

test.skip("composer-lock coerces autoMode false on paper without CONFIRM AUTO MODE", () => {
  assert.match(LOCK_SRC, /next\.autoMode = false/);
  assert.match(LOCK_SRC, /CONFIRM AUTO MODE/);
});

test.skip("capToManualBoundary still caps when autoMode true (composer no longer owns floors)", () => {
  assert.doesNotMatch(TIGHTEN_SRC, /if \(autoMode\) return \{ value: tightenedValue, capped: false \}/);
});

test.skip("ledger 30720 is sane vs 31300 start (keep on bounce)", () => {
  const ok = isSanePaperLedger({
    virtualCents: 30720,
    peakCents: 31300,
    pnlCents: -147,
    wins: 0,
    losses: 3,
    trades: 3,
  }, 31300);
  assert.equal(ok, true);
});


test.skip("isolate-rewrite-compare: echoOperatorFloors is unchanged (fail-closed copy)", () => {
  const cfg = {
    minConfidence: 52,
    minVelocity: 24,
    maxContractsPerTrade: 60,
    stopLossCents: 22,
    profitTakeCents: 20,
    tradeWindowMinMin: 0.2,
    tradeWindowMaxMin: 15,
    minProbEdge: 5,
  };
  assert.deepEqual(echoOperatorFloors(cfg), echoOperatorFloorsIsolate(cfg));
});

test.skip("isolate-rewrite-compare: isolate DEAD-skips; live does not (CC not starved)", () => {
  const inputs = {
    autoMode: true,
    tape: { volumeBucket: "DEAD", lagStale: false, lagAgreesWithSide: true },
    drawdownPct: 0,
  };
  const iso = computeAdaptationIsolate(inputs);
  const live = computeAdaptation({ ...inputs, strategyId: "CONFLUENCE_CASCADE" });
  assert.equal(iso.skip, true);
  assert.equal(tapeLieBlocksTickIsolate(["DEAD_TAPE"]), true);
  assert.equal(live.skip, false);
});

test.skip("autoMode true does not change EV_FLOOR / minConfidence / minEntry", () => {
  assert.equal(EV_FLOOR, 3);
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(kellyFraction(80, 8), 0.60);
  const floors = echoOperatorFloors({
    minConfidence: 52,
    minEntryPrice: 28,
    minVelocity: 24,
    maxContractsPerTrade: 60,
    stopLossCents: 22,
    profitTakeCents: 20,
    tradeWindowMinMin: 0.2,
    tradeWindowMaxMin: 15,
    minProbEdge: 5,
  });
  assert.equal(floors.minConfidence, 52);
  const r = computeAdaptation({
    autoMode: true,
    tape: { lagStale: false, lagAgreesWithSide: false, volumeBucket: "DEAD" },
    drawdownPct: 18,
    fromBotFill: true,
    learningWeight: 0.72,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.deepEqual(adapterTouchesComposerGates(r), []);
  assert.equal("minConfidence" in r, false);
  assert.equal("minEntryPrice" in r, false);
  assert.equal("minEV" in r, false);
  assert.match(BOT_SRC, /minEntryPrice:\s+20/);
  assert.match(BOT_SRC, /minAskCents: boostedStratResult\.strategyId === "BASIS_LAG_EDGE" \? 10 : 28/);
  assert.match(BOT_SRC, /maxEntryPrice:\s+55/);
  assert.match(BOT_SRC, /reservePct:\s+15/);
});

test.skip("CC not TAPE_LIE starved; LAG still skip on FRESH disagree", () => {
  assert.equal(freshLagDisagreeSkip({
    autoMode: true, lagStale: false, agreesWithSide: false, strategyId: "CONFLUENCE_CASCADE",
  }), false);
  assert.equal(freshLagDisagreeSkip({
    autoMode: true, lagStale: false, agreesWithSide: false, strategyId: "BASIS_LAG_EDGE",
  }), true);
  assert.equal(freshLagDisagreeSkip({
    autoMode: true, lagStale: true, agreesWithSide: false, strategyId: "BASIS_LAG_EDGE",
  }), false);
  assert.equal(freshLagDisagreeSkip({
    autoMode: false, lagStale: false, agreesWithSide: false, strategyId: "BASIS_LAG_EDGE",
  }), false);

  const cc = computeAdaptation({
    autoMode: true,
    tape: { lagStale: false, lagAgreesWithSide: false, volumeBucket: "DEAD" },
    drawdownPct: 0,
    strategyId: "CONFLUENCE_CASCADE",
  });
  assert.equal(cc.skip, false);

  const lag = computeAdaptation({
    autoMode: true,
    tape: { lagStale: false, lagAgreesWithSide: false },
    drawdownPct: 0,
    strategyId: "BASIS_LAG_EDGE",
  });
  assert.equal(lag.skip, true);
  assert.match(BOT_SRC, /freshLagDisagreeSkip\(/);
});

test.skip("size haircut then applyHardRiskLimits (9% still binds)", () => {
  const r = computeAdaptation({
    autoMode: true,
    tape: { volumeBucket: "LOW" },
    drawdownPct: 14,
    drawdownGuardPct: 20,
  });
  assert.ok(r.sizeMult < 1);
  assert.ok(r.sizeMult <= 1);
  const desired = 60;
  const haircut = Math.floor(desired * r.sizeMult);
  assert.ok(haircut < desired);
  const after = applyHardRiskLimits(31_300, 40, haircut, 0);
  const withoutAdapt = applyHardRiskLimits(31_300, 40, desired, 0);
  assert.ok(after <= haircut);
  assert.ok(after <= withoutAdapt);
  const start = BOT_SRC.indexOf("autoMode ADAPTATION: size down");
  assert.ok(start >= 0);
  const block = BOT_SRC.slice(start, start + 900);
  const haircutAt = block.indexOf("lastAdaptation.sizeMult");
  const hardAt = block.indexOf("applyHardRiskLimits(");
  assert.ok(haircutAt >= 0 && hardAt > haircutAt, "haircut must precede applyHardRiskLimits");
});
