/**
 * money-maker-path-gate.isolate.ts — UNCHANGED PATH_GATE skip overlay from
 * evaluateEntry at isolate time: GRAY/unclear only, CC/LAG only.
 * Compare-only. Does not know velocity conflict, GRAY waterfall, or
 * hour-of-week histN P10 leftover.
 */
export function moneyMakerIgnoresPathGateSkipIsolate(opts: {
  strategyId: string | null | undefined;
  path: string;
  reason: string;
}): boolean {
  const moneyMakerPath =
    opts.strategyId === "CONFLUENCE_CASCADE"
    || opts.strategyId === "BASIS_LAG_EDGE";
  return moneyMakerPath
    && opts.path === "GRAY"
    && opts.reason === 'Regime "unclear" not allowed on GRAY path';
}
