/**
 * Leftover mayRun doors — paperMode true must fail-closed (CORRECT, not incomplete).
 * Never ENABLE. Does not cut EV/Kelly floors.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { leftoverLiveOrderMayRun } from "./leftover-live-order.js";
import { leftoverHourlyEvaluateMayRun } from "./leftover-hourly-evaluate.js";
import { leftoverAddEvaluateMayRun } from "./leftover-add-evaluate.js";
import { leftoverLiveSettlementMayRun } from "./leftover-live-settlement.js";
import { leftoverLiveUnfilledMayRun } from "./leftover-live-unfilled.js";
import { leftoverLiveFillStatusMayRun } from "./leftover-live-fill-status.js";
import { leftoverPackObserveMayRun } from "./leftover-pack-observe.js";
import {
  frozenSixGateIsOnlyEvaluatePath,
  leftover15mEvaluateMayRun,
} from "./frozen-six-gate-evaluate.js";

const paper = { paperMode: true as const, frozenCcMode: false as const };
const paperFrozen = { paperMode: true as const, frozenCcMode: true as const };
const liveOpen = { paperMode: false as const, frozenCcMode: false as const };

test("leftover mayRun: paper denies live-order / hourly / add / settlement / unfilled / fill-status / pack", () => {
  assert.equal(leftoverLiveOrderMayRun(paper), false);
  assert.equal(leftoverHourlyEvaluateMayRun(paper), false);
  assert.equal(leftoverAddEvaluateMayRun(paper), false);
  assert.equal(leftoverLiveSettlementMayRun(paper), false);
  assert.equal(leftoverLiveUnfilledMayRun(paper), false);
  assert.equal(leftoverLiveFillStatusMayRun(paper), false);
  assert.equal(leftoverPackObserveMayRun(paper), false);
});

test("leftover mayRun: frozenCc denies leftover15m; six-gate is only path", () => {
  assert.equal(frozenSixGateIsOnlyEvaluatePath({ frozenCcMode: true }), true);
  assert.equal(leftover15mEvaluateMayRun({ frozenCcMode: true }), false);
  assert.equal(leftover15mEvaluateMayRun(paperFrozen), false);
  assert.equal(leftoverLiveOrderMayRun(paperFrozen), false);
});

test("leftover mayRun: paperMode alone denies leftover15m (paper desk frozen-CC / paper-release only)", () => {
  assert.equal(leftover15mEvaluateMayRun(paper), false);
  assert.equal(leftover15mEvaluateMayRun({ paperMode: true, frozenCcMode: false }), false);
});

test("leftover mayRun: live+unfrozen may open live doors (not an ENABLE — host still gated)", () => {
  assert.equal(leftoverLiveOrderMayRun(liveOpen), true);
  assert.equal(leftover15mEvaluateMayRun(liveOpen), true);
  assert.equal(leftover15mEvaluateMayRun({ frozenCcMode: false }), true);
});
