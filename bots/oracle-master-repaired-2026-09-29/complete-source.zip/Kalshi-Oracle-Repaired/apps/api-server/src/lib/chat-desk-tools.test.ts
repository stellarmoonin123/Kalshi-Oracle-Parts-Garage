import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { runDeskTool, DESK_TOOL_SPECS } from "./chat-desk-tools.js";
import { resolveDeskRoot } from "./chat-code-edit.js";
import { runDeskAgent } from "./chat-agent.js";
import { CooldownBook } from "./chat-router.js";

const status = { state: "WATCHING", config: { paperMode: true, frozenCcMode: true }, paperVirtualBalanceCents: 30604, paperPnlCents: -696, entryFunnel: { counts: { TAKE_SIGNAL: 3 } }, lastSignal: "x" };
const deps = { getStatus: () => status, getRecentTrades: async () => [{ id: 72, ticker: "T", side: "yes", contracts: 18, entryPriceCents: 37, outcome: "loss", pnlCents: -696 }], getRecentLogs: () => [{ level: "info", message: "hello world" }, { level: "warn", message: "⛔ MIND_HEAVE_BIND" }] };

test("tool surface is read-only (plus propose_fix); no config/trade/restart tools", () => {
  const names = DESK_TOOL_SPECS.map((t) => t.name);
  for (const bad of ["update_config", "toggle_strategy", "force_exit_trade", "run_shell", "write_file", "apply_patch", "control_bot", "bounce_api"]) assert.ok(!names.includes(bad), bad);
  assert.ok(names.includes("propose_fix"));
});

test("desk tools return compact facts; unknown tool refused; output truncated", async () => {
  const s = JSON.parse(await runDeskTool("get_status", {}, deps));
  assert.equal(s.paperBalance$, "306.04");
  assert.equal(s.paperMode, true);
  assert.match(await runDeskTool("get_entry_funnel", {}, deps), /TAKE_SIGNAL/);
  assert.match(await runDeskTool("get_recent_trades", { n: 3 }, deps), /-696/);
  assert.match(await runDeskTool("tail_log", { grep: "heave" }, deps), /MIND_HEAVE_BIND/);
  assert.match(await runDeskTool("update_config", {}, deps), /refused/);
  const big = { ...deps, getStatus: () => ({ ...status, lastSignal: "y".repeat(10_000), entryFunnel: { counts: Object.fromEntries(Array.from({ length: 500 }, (_, i) => [`k${i}`, i])) } }) };
  assert.ok((await runDeskTool("get_entry_funnel", {}, big)).length < 2_600);
});

test("desk root resolves from the bundled dist path (Fly) instead of '/'", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "deskroot-"));
  fs.writeFileSync(path.join(root, "pnpm-workspace.yaml"), "");
  fs.mkdirSync(path.join(root, "apps/api-server/dist"), { recursive: true });
  assert.equal(resolveDeskRoot({}, [path.join(root, "apps/api-server/dist")]), root);
  assert.equal(resolveDeskRoot({ CHAT_DESK_ROOT: "/x/y" }, [root]), "/x/y");
});

test("agent: native tool call → tool runs server-side → final prose; meta names the model", async () => {
  let n = 0;
  const fetchImpl = (async (_url: string, init: any) => {
    const body = JSON.parse(init.body);
    n++;
    if (n === 1) return new Response(JSON.stringify({ choices: [{ message: { content: "", tool_calls: [{ id: "c1", function: { name: "get_status", arguments: "{}" } }] } }] }), { status: 200 });
    const toolMsg = body.messages.find((m: any) => m.role === "tool");
    assert.ok(toolMsg && /306\.04/.test(toolMsg.content), "tool result fed back");
    return new Response(JSON.stringify({ choices: [{ message: { content: "Balance is $306.04 in paper." } }] }), { status: 200 });
  }) as unknown as typeof fetch;
  const gen = runDeskAgent({ question: "balance?", history: [], deps, env: { GROQ_API_KEY: "g" }, fetchImpl, cooldowns: new CooldownBook() });
  const events: any[] = [];
  let step = await gen.next();
  while (!step.done) { events.push(step.value); step = await gen.next(); }
  assert.equal(step.value.failed, false);
  assert.match(step.value.text, /306\.04/);
  assert.ok(events.some((e) => e.type === "tool_start" && e.name === "get_status"));
  assert.equal(events.find((e) => e.type === "meta").model, "openai/gpt-oss-120b");
});

test("agent: every provider down → failed=true with a specific message", async () => {
  const fetchImpl = (async () => new Response("nope", { status: 503 })) as unknown as typeof fetch;
  const gen = runDeskAgent({ question: "hi", history: [], deps, env: { GROQ_API_KEY: "g" }, fetchImpl, cooldowns: new CooldownBook(), sleepImpl: async () => {} });
  let step = await gen.next();
  while (!step.done) step = await gen.next();
  assert.equal(step.value.failed, true);
  assert.match(step.value.text, /overloaded/);
});
