/**
 * 2026-09-24 regression: Fly desk sat "WS degraded — entries paused" from
 * ~18:05 ET until a machine restart. Root cause: the 4s silence heartbeat
 * judged a CLOSED socket as "silent" (its _lastWsMessageTs froze at the dead
 * socket's last message) and force-reconnected every 4s, killing each connect
 * attempt (auth + REST lookup + handshake > 4s on Fly) and resetting backoff.
 * Also the watchdog reported "ok" (tick age via REST) while /healthz said
 * degraded. These tests pin the fixed decision functions.
 */
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
  shouldForceReconnectOnSilence,
  shouldTearDownForForceReconnect,
  withTimeout,
  WS_SILENCE_THRESHOLD_MS,
  WS_HEARTBEAT_INTERVAL_MS,
  WS_HANDSHAKE_TIMEOUT_MS,
  WS_FORCE_RECONNECT_GRACE_MS,
  nextWsReconnectBackoffMs,
  MAX_BACKOFF_MS,
} from "./kalshi-ws.js";
import { wsHealthVerdict } from "./kalshi-ws-health.js";

test("closed/connecting socket is never 'silent' (no heartbeat thrash)", () => {
  const now = 10_000_000;
  const deadSocketLastMsg = now - 60 * 60_000; // an hour ago
  assert.equal(shouldForceReconnectOnSilence(deadSocketLastMsg, now, WS_SILENCE_THRESHOLD_MS, false), false);
  // open + silent still reconnects (A5 behaviour kept)
  assert.equal(shouldForceReconnectOnSilence(deadSocketLastMsg, now, WS_SILENCE_THRESHOLD_MS, true), true);
});

test("simulation: 6s connect attempts complete under the new heartbeat, never under the old one", () => {
  const CONNECT_MS = 6_000; // auth + REST lookup + handshake on a slow day
  function simulate(useSocketState: boolean): boolean {
    let t = 0;
    const lastMsg = -3_600_000; // dead socket
    let attemptStart = 0;
    let open = false;
    while (t < 5 * 60_000) {
      t += WS_HEARTBEAT_INTERVAL_MS;
      if (!open && t - attemptStart >= CONNECT_MS) { open = true; break; }
      const fire = shouldForceReconnectOnSilence(lastMsg, t, WS_SILENCE_THRESHOLD_MS, useSocketState ? open : true);
      if (fire) attemptStart = t; // old code: terminate + restart the attempt
    }
    return open;
  }
  assert.equal(simulate(false), false, "old behaviour livelocks (documents the bug)");
  assert.equal(simulate(true), true, "fixed behaviour connects");
});

test("forceReconnect never tears down a young in-flight attempt; stale ones are replaced", () => {
  const now = 1_000_000;
  assert.equal(shouldTearDownForForceReconnect({ socketState: "connecting", connectInFlightSinceMs: now - 3_000, nowMs: now }), false);
  assert.equal(shouldTearDownForForceReconnect({ socketState: "connecting", connectInFlightSinceMs: now - WS_FORCE_RECONNECT_GRACE_MS - 1, nowMs: now }), true);
  assert.equal(shouldTearDownForForceReconnect({ socketState: "closed", connectInFlightSinceMs: null, nowMs: now }), true);
  assert.equal(shouldTearDownForForceReconnect({ socketState: "open", connectInFlightSinceMs: null, nowMs: now }), true);
});

test("backoff is bounded and handshake has a timeout", () => {
  let b = 0;
  for (let i = 0; i < 20; i++) b = nextWsReconnectBackoffMs(b);
  assert.equal(b, MAX_BACKOFF_MS);
  assert.ok(WS_HANDSHAKE_TIMEOUT_MS > 0 && WS_HANDSHAKE_TIMEOUT_MS <= 15_000);
  const src = fs.readFileSync(new URL("./kalshi-ws.ts", import.meta.url), "utf8");
  assert.match(src, /new WebSocket\(WS_URL, \{ headers, handshakeTimeout: WS_HANDSHAKE_TIMEOUT_MS \}\)/);
  assert.match(src, /withTimeout\(this\.fetchActiveMarket\(\)/, "REST market lookup inside connect is time-bounded");
  assert.match(src, /_reconnectSupervisor = setInterval/, "supervisor reschedules a lost reconnect");
});

test("withTimeout rejects hung promises", async () => {
  await assert.rejects(withTimeout(new Promise(() => {}), 20, "hang"), /hang timed out/);
  assert.equal(await withTimeout(Promise.resolve(7), 50, "ok"), 7);
});

test("health verdict: watchdog and /healthz agree; REST-fresh ticks do not make a closed WS 'ok'", () => {
  const now = 5_000_000;
  const closed = wsHealthVerdict({ socket: "closed", degraded: true, lastWsMessageTs: now - 9_000_000, lastOpenAt: null, nowMs: now });
  assert.equal(closed.connected, false);
  assert.equal(closed.status, "degraded");
  const early = wsHealthVerdict({ socket: "closed", degraded: false, lastWsMessageTs: now - 20_000, lastOpenAt: null, nowMs: now });
  assert.equal(early.connected, false, "not degraded yet but NOT connected (was: connected=!degraded)");
  const ok = wsHealthVerdict({ socket: "open", degraded: false, lastWsMessageTs: now - 500, lastOpenAt: now - 60_000, nowMs: now });
  assert.deepEqual([ok.connected, ok.status], [true, "ok"]);
  const silent = wsHealthVerdict({ socket: "open", degraded: false, lastWsMessageTs: now - 120_000, lastOpenAt: now - 600_000, nowMs: now });
  assert.equal(silent.status, "healing");
});

test("watchdog + health route both consume wsHealthVerdict", () => {
  const wd = fs.readFileSync(new URL("./watchdog.ts", import.meta.url), "utf8");
  const hz = fs.readFileSync(new URL("../routes/health.ts", import.meta.url), "utf8");
  assert.match(wd, /wsHealthVerdict\(/);
  assert.match(hz, /wsHealthVerdict\(/);
  assert.match(hz, /connected:\s+wsVerdict\.connected/);
  assert.doesNotMatch(hz, /connected:\s+!wsDegraded/);
});
