/**
 * shadow-calibration — break the heave/calibration deadlock without loosening it.
 *
 * Deadlock: captain HEAVE (MIND_HEAVE_BIND) blocks entries while calibration
 * is unreliable (n < 30 or ECE > 0.08); calibration rows only came from
 * settled trades; no trades → n stays 0 forever.
 *
 * Fix (data source widens, rule unchanged): when a take reaches placeOrder and
 * the captain/mind BLOCKS it, record a SHADOW entry {ticker, side, p, ask, ts,
 * source:"shadow"}. When that 15m market settles, resolve hit = (side ===
 * Kalshi result) and append it to the SAME mind calibration ledger
 * (mind-calibration.jsonl on the volume) tagged source:"shadow".
 * computeCalibration's reliability rule (n ≥ 30 AND ECE ≤ 0.08) is untouched.
 *
 * Shadow rows NEVER create positions, never touch balance, never count as
 * trades — this module has no access to the paper book at all.
 * Dedupe: one shadow per market+side per window.
 * Pure state + JSONL (mind-calibration-shadow.jsonl). No network. No LLM.
 */
import { existsSync, mkdirSync, appendFileSync, readFileSync } from "node:fs";
import path from "node:path";
import { deskDataPath } from "../desk-data-dir.js";
import { recordCalibrationObs, type CalibrationObs } from "./mind-calibration.js";

export const SHADOW_CALIBRATION_LOADED = "SHADOW_CALIBRATION_LOADED" as const;
/** Wait this long after close before asking for the result. */
export const SHADOW_SETTLE_GRACE_MS = 60_000;
/** Pending entries older than this are expired (never resolved → never counted). */
export const SHADOW_MAX_PENDING_MS = 6 * 60 * 60_000;
const RESOLVED_KEYS_MAX = 2048;

export type ShadowEntry = {
  key: string;
  ticker: string;
  side: "yes" | "no";
  /** Predicted win probability of the side taken (same p real fills log). */
  p: number;
  askCents: number;
  atMs: number;
  windowKey: string;
  /** Market close (ms) when known; resolver waits until close + grace. */
  closeMs: number | null;
  strategyId: string | null;
  blockStamp: string | null;
  blockReason: string | null;
  /** Real L2 depth stamp the brain saw at the block (observability only). */
  depth?: {
    depthKnown: boolean;
    thinBook: boolean | null;
    depthAtAsk: number | null;
    thinThreshold: number | null;
    ageMs: number | null;
  } | null;
  source: "shadow";
  /**
   * PR #14: calibration source of the resolved obs. "fill" = an EARLY-EXIT
   * paper fill (sold before settle, so no official settle at close) parked
   * here only to be scored against the market's real settlement. Absent →
   * "shadow". Never a position/balance change — scoring only.
   */
  calibSource?: "shadow" | "fill";
};

export type ShadowRow =
  | ({ type: "pending" } & ShadowEntry)
  | {
      type: "resolved";
      key: string;
      ticker: string;
      side: "yes" | "no";
      p: number;
      askCents: number;
      atMs: number;
      settledSide: "yes" | "no";
      hit: boolean;
      resolvedAtMs: number;
      source: "shadow";
    }
  | { type: "expired"; key: string; ticker: string; atMs: number; expiredAtMs: number; source: "shadow" };

export type ShadowState = {
  pending: Map<string, ShadowEntry>;
  resolvedKeys: Set<string>;
  resolved: number;
  hits: number;
  expired: number;
  deduped: number;
};

export function newShadowState(): ShadowState {
  return { pending: new Map(), resolvedKeys: new Set(), resolved: 0, hits: 0, expired: 0, deduped: 0 };
}

let state: ShadowState = newShadowState();

export function resetShadowCalibrationForTests(): void {
  state = newShadowState();
}
export function getShadowState(): ShadowState {
  return state;
}

export function defaultShadowPath(): string {
  return deskDataPath("mind-calibration-shadow.jsonl");
}

function inTest(): boolean {
  return process.env.NODE_TEST_CONTEXT != null
    || (typeof process.env.BOT_CONFIG_PATH === "string" && process.env.BOT_CONFIG_PATH.includes("/tmp"));
}

function appendRow(row: ShadowRow, filePath: string): void {
  try {
    const dir = path.dirname(filePath);
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    appendFileSync(filePath, `${JSON.stringify(row)}\n`, "utf8");
  } catch {
    /* never block the tick */
  }
}

export type ShadowOpts = {
  state?: ShadowState;
  /** Persist shadow rows (default: on outside tests). */
  persist?: boolean;
  shadowFilePath?: string;
  /** Calibration ring/file override (tests). */
  calibRing?: CalibrationObs[];
  calibFilePath?: string;
  nowMs?: number;
};

export function shadowKey(ticker: string, side: "yes" | "no", windowKey: string): string {
  return `${ticker}|${side}|${windowKey}`;
}

/** Record a blocked take as a shadow entry. Returns null reason on dedupe/invalid. */
export function recordShadowTake(
  input: {
    ticker: string | null | undefined;
    side: "yes" | "no" | null | undefined;
    p: number | null | undefined;
    askCents: number | null | undefined;
    windowKey?: string | null;
    closeMs?: number | null;
    strategyId?: string | null;
    blockStamp?: string | null;
    blockReason?: string | null;
    depth?: ShadowEntry["depth"];
  },
  opts: ShadowOpts = {},
): { recorded: boolean; reason: string; entry: ShadowEntry | null } {
  const st = opts.state ?? state;
  const nowMs = opts.nowMs ?? Date.now();
  const ticker = typeof input.ticker === "string" ? input.ticker.trim() : "";
  const side = input.side === "yes" || input.side === "no" ? input.side : null;
  const p = input.p;
  const ask = input.askCents;
  if (!ticker) return { recorded: false, reason: "no_ticker", entry: null };
  if (!side) return { recorded: false, reason: "no_side", entry: null };
  if (typeof p !== "number" || !Number.isFinite(p) || p < 0 || p > 1) {
    return { recorded: false, reason: "invalid_p", entry: null };
  }
  if (typeof ask !== "number" || !Number.isFinite(ask) || ask <= 0 || ask >= 100) {
    return { recorded: false, reason: "invalid_ask", entry: null };
  }
  // A 15m ticker is already one window; windowKey guards reused tickers.
  const windowKey = (input.windowKey && String(input.windowKey)) || ticker;
  const key = shadowKey(ticker, side, windowKey);
  if (st.pending.has(key) || st.resolvedKeys.has(key)) {
    st.deduped += 1;
    return { recorded: false, reason: "dedupe", entry: null };
  }
  const entry: ShadowEntry = {
    key,
    ticker,
    side,
    p,
    askCents: ask,
    atMs: nowMs,
    windowKey,
    closeMs: typeof input.closeMs === "number" && Number.isFinite(input.closeMs) ? input.closeMs : null,
    strategyId: input.strategyId ?? null,
    blockStamp: input.blockStamp ?? null,
    blockReason: input.blockReason ? String(input.blockReason).slice(0, 240) : null,
    depth: input.depth
      ? {
          depthKnown: input.depth.depthKnown === true,
          thinBook: input.depth.thinBook ?? null,
          depthAtAsk: input.depth.depthAtAsk ?? null,
          thinThreshold: input.depth.thinThreshold ?? null,
          ageMs: input.depth.ageMs ?? null,
        }
      : null,
    source: "shadow",
  };
  st.pending.set(key, entry);
  if (opts.persist === true || (opts.persist !== false && !inTest())) {
    appendRow({ type: "pending", ...entry }, opts.shadowFilePath ?? defaultShadowPath());
  }
  return { recorded: true, reason: "recorded", entry };
}

/**
 * PR #14 — include early-exit fills in calibration. A paper fill that exited
 * before settlement has no official settle at close (causal.sideCorrect null),
 * so it never calibrated. Park it as a pending entry (calibSource:"fill") so
 * the existing sweep scores p against the settled outcome of the SAME side.
 * Key suffix "|fill" keeps it from colliding with a shadow of the same side.
 */
export function recordEarlyExitFillForCalibration(
  input: {
    ticker: string | null | undefined;
    side: "yes" | "no" | null | undefined;
    p: number | null | undefined;
    askCents: number | null | undefined;
    /** Entry (decision) time — the gate sampler keeps the earliest per window. */
    entryAtMs: number;
    closeMs?: number | null;
    strategyId?: string | null;
    exitReason?: string | null;
  },
  opts: ShadowOpts = {},
): { recorded: boolean; reason: string; entry: ShadowEntry | null } {
  const st = opts.state ?? state;
  const ticker = typeof input.ticker === "string" ? input.ticker.trim() : "";
  const side = input.side === "yes" || input.side === "no" ? input.side : null;
  const p = input.p;
  const ask = input.askCents;
  if (!ticker) return { recorded: false, reason: "no_ticker", entry: null };
  if (!side) return { recorded: false, reason: "no_side", entry: null };
  if (typeof p !== "number" || !Number.isFinite(p) || p < 0 || p > 1) {
    return { recorded: false, reason: "invalid_p", entry: null };
  }
  if (typeof ask !== "number" || !Number.isFinite(ask) || ask <= 0 || ask >= 100) {
    return { recorded: false, reason: "invalid_ask", entry: null };
  }
  const windowKey = `${ticker}|fill`;
  const key = shadowKey(ticker, side, windowKey);
  if (st.pending.has(key) || st.resolvedKeys.has(key)) {
    st.deduped += 1;
    return { recorded: false, reason: "dedupe", entry: null };
  }
  const entry: ShadowEntry = {
    key,
    ticker,
    side,
    p,
    askCents: ask,
    atMs: Number.isFinite(input.entryAtMs) ? input.entryAtMs : (opts.nowMs ?? Date.now()),
    windowKey,
    closeMs: typeof input.closeMs === "number" && Number.isFinite(input.closeMs) ? input.closeMs : null,
    strategyId: input.strategyId ?? null,
    blockStamp: "EARLY_EXIT_FILL",
    blockReason: input.exitReason ? String(input.exitReason).slice(0, 240) : null,
    depth: null,
    source: "shadow",
    calibSource: "fill",
  };
  st.pending.set(key, entry);
  if (opts.persist === true || (opts.persist !== false && !inTest())) {
    appendRow({ type: "pending", ...entry }, opts.shadowFilePath ?? defaultShadowPath());
  }
  return { recorded: true, reason: "recorded", entry };
}

/** Distinct tickers whose pending shadows are past close + grace (resolver work list). */
export function shadowTickersDue(
  nowMs: number = Date.now(),
  st: ShadowState = state,
  graceMs: number = SHADOW_SETTLE_GRACE_MS,
): string[] {
  const out = new Set<string>();
  for (const e of st.pending.values()) {
    if (e.closeMs == null || e.closeMs + graceMs <= nowMs) out.add(e.ticker);
  }
  return [...out];
}

function markResolvedKey(st: ShadowState, key: string): void {
  st.resolvedKeys.add(key);
  if (st.resolvedKeys.size > RESOLVED_KEYS_MAX) {
    const first = st.resolvedKeys.values().next().value;
    if (first != null) st.resolvedKeys.delete(first);
  }
}

/**
 * Market settled → resolve every pending shadow on it into the mind
 * calibration ledger (source:"shadow"). Returns the calibration obs added.
 */
export function resolveShadowMarket(
  ticker: string,
  settledSide: "yes" | "no" | string | null | undefined,
  opts: ShadowOpts = {},
): CalibrationObs[] {
  const st = opts.state ?? state;
  if (settledSide !== "yes" && settledSide !== "no") return [];
  const nowMs = opts.nowMs ?? Date.now();
  const persist = opts.persist === true || (opts.persist !== false && !inTest());
  const out: CalibrationObs[] = [];
  for (const [key, e] of [...st.pending.entries()]) {
    if (e.ticker !== ticker) continue;
    const hit = e.side === settledSide;
    const obs = recordCalibrationObs(
      { p: e.p, hit, askCents: e.askCents, side: e.side, atMs: e.atMs, source: e.calibSource === "fill" ? "fill" : "shadow", ticker: e.ticker },
      opts.calibRing,
      opts.calibRing
        ? { persist: opts.calibFilePath != null && persist, filePath: opts.calibFilePath }
        : { persist, filePath: opts.calibFilePath },
    );
    out.push(obs);
    st.pending.delete(key);
    markResolvedKey(st, key);
    st.resolved += 1;
    if (hit) st.hits += 1;
    if (persist) {
      appendRow(
        {
          type: "resolved", key, ticker: e.ticker, side: e.side, p: e.p, askCents: e.askCents,
          atMs: e.atMs, settledSide, hit, resolvedAtMs: nowMs, source: "shadow",
        },
        opts.shadowFilePath ?? defaultShadowPath(),
      );
    }
  }
  return out;
}

/** Drop pendings never resolved within SHADOW_MAX_PENDING_MS (never counted). */
export function expireStaleShadows(opts: ShadowOpts & { maxPendingMs?: number } = {}): number {
  const st = opts.state ?? state;
  const nowMs = opts.nowMs ?? Date.now();
  const maxMs = opts.maxPendingMs ?? SHADOW_MAX_PENDING_MS;
  const persist = opts.persist === true || (opts.persist !== false && !inTest());
  let n = 0;
  for (const [key, e] of [...st.pending.entries()]) {
    if (nowMs - e.atMs <= maxMs) continue;
    st.pending.delete(key);
    markResolvedKey(st, key);
    st.expired += 1;
    n += 1;
    if (persist) {
      appendRow(
        { type: "expired", key, ticker: e.ticker, atMs: e.atMs, expiredAtMs: nowMs, source: "shadow" },
        opts.shadowFilePath ?? defaultShadowPath(),
      );
    }
  }
  return n;
}

/** Replay the shadow JSONL (restart): pending minus resolved/expired. */
export function loadShadowFromDisk(filePath?: string, st?: ShadowState): number {
  const target = st ?? newShadowState();
  try {
    const file = filePath ?? defaultShadowPath();
    if (!existsSync(file)) {
      if (!st) state = target;
      return 0;
    }
    for (const line of readFileSync(file, "utf8").split("\n")) {
      if (!line.trim()) continue;
      try {
        const row = JSON.parse(line) as ShadowRow;
        if (row?.type === "pending" && typeof row.key === "string") {
          if (!target.resolvedKeys.has(row.key)) target.pending.set(row.key, { ...row, source: "shadow" } as ShadowEntry);
        } else if (row?.type === "resolved" && typeof row.key === "string") {
          target.pending.delete(row.key);
          markResolvedKey(target, row.key);
          target.resolved += 1;
          if (row.hit === true) target.hits += 1;
        } else if (row?.type === "expired" && typeof row.key === "string") {
          target.pending.delete(row.key);
          markResolvedKey(target, row.key);
          target.expired += 1;
        }
      } catch {
        /* skip bad row */
      }
    }
  } catch {
    /* ignore */
  }
  if (!st) state = target;
  return target.pending.size;
}

export function shadowStats(st: ShadowState = state): {
  pending: number;
  resolved: number;
  hits: number;
  expired: number;
  deduped: number;
} {
  return { pending: st.pending.size, resolved: st.resolved, hits: st.hits, expired: st.expired, deduped: st.deduped };
}

if (!inTest()) {
  try {
    loadShadowFromDisk();
  } catch {
    /* ignore */
  }
}
