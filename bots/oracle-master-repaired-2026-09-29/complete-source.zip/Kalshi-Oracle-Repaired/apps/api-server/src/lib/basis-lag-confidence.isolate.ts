/**
 * basis-lag-confidence.isolate.ts — UNCHANGED LAG confidence assignment
 * from basis-lag-edge.ts at isolate time (conf = clamp(p + boosts, 0.52, 0.80)).
 * Compare-only. p stays basisLagWinRate in the live module.
 */
function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

export function basisLagConfidenceIsolate(opts: {
  pWin: number;
  edgePts: number;
  minEdgePts: number;
  rollingBasis?: number;
  basisShort?: number;
  isLong: boolean;
}): number {
  let conf = opts.pWin;
  conf += clamp((opts.edgePts - opts.minEdgePts) / 100, 0, 0.12);
  if (opts.rollingBasis !== undefined && Math.abs(opts.rollingBasis) > 5) conf += 0.03;
  if (opts.basisShort !== undefined && Math.sign(opts.basisShort) === (opts.isLong ? 1 : -1)) conf += 0.02;
  return clamp(conf, 0.52, 0.80);
}
