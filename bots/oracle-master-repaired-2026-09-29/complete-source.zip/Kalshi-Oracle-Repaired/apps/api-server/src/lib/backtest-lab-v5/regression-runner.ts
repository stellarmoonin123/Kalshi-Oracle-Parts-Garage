/**
 * backtest-lab-v5/regression-runner.ts
 *
 * GO — BACKTEST LAB v5 + CONTINUOUS POLICY REGRESSION (2026-08-22), PART II.
 *
 * Orchestrates one LEAN-vs-LEGACY comparison run: fetch real candles → run
 * both policies → pool sequential OOS folds → verdict → sensitivity sweep →
 * poison-test self-check → save a PolicySnapshot → compare against the prior
 * LEAN baseline snapshot (WARN/PASS) → write a report artifact to disk.
 *
 * HARD CONTRACT (Part III explicit scope limit): nothing in this file writes
 * to `.bot-config.json`, calls any BotConfig setter, or otherwise touches
 * live trading behavior. It only reads real market data and writes its own
 * lab-only DB rows (policy_snapshots) and report files under
 * `artifacts/api-server/docs/policy-regression/`.
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fetchRealCandles } from '../market-candles.js';
import { kalshiNetWinCents, kalshiNetCostCents } from '../constants.js';
import { groupIntoPeriods, runPolicyOverPeriods, poisonSeriesAfter, buildDecisionObservation, decideAtPoint } from './causal-sim.js';
import type { SimTrade } from './causal-sim.js';
import { POLICY_LEAN, POLICY_LEGACY, clonePolicy } from './sim-policy.js';
import type { SimPolicy } from './sim-policy.js';
import { pooledOosMetrics, decideVerdict } from './validation.js';
import type { PolicyMetrics, VerdictResult, SensitivityRow } from './validation.js';
import { saveSnapshot, getLatestSnapshot } from './policy-snapshot.js';
import { WRONG_KIT_FORMULA_SUMMARY } from './wrong-kit.js';

const REPORT_DIR = path.join(process.cwd(), 'docs', 'policy-regression');
const DEFAULT_INTERVAL_MINS = 5 as const;
const DEFAULT_LOOKBACK_DAYS = 10; // ~2880 5-min candles — bounded so a cron run stays well under the 6h cadence
const RUN_TIME_BUDGET_MS = 90_000; // fail soft (skip remaining sensitivity rows) rather than run unbounded in a cron job

/** Files whose changes indicate the LIVE admit policy itself moved, and
 *  therefore that a fresh regression run is worth triggering. Kept as an
 *  explicit allowlist (not "any commit") so unrelated UI/docs changes never
 *  trigger a run. */
export const POLICY_RELEVANT_PATHS = [
  'artifacts/api-server/src/lib/specialist-packs.ts',
  'artifacts/api-server/src/lib/pre-trade-sim.ts',
  'artifacts/api-server/src/lib/condition-adapter.ts',
  'artifacts/api-server/src/lib/strategy-library.ts',
  'artifacts/api-server/src/lib/trading-bot.ts',
];

export function getCurrentGitSha(): string | null {
  try {
    return execSync('git rev-parse --short HEAD', { encoding: 'utf8' }).trim();
  } catch {
    return null; // no git repo / not available — snapshot still saves, gitSha just null
  }
}

/** True when any commit since `sinceSha` (exclusive) touched a
 *  policy-relevant path. `sinceSha` null (no prior snapshot yet) => true
 *  (always worth an initial baseline run). Fails OPEN to `false` on any git
 *  error (missing repo, detached env) — the explicit-command and scheduled
 *  ≤1x/6h triggers still cover the case where this signal is unavailable. */
export function hasPolicyRelevantCommitsSince(sinceSha: string | null): boolean {
  if (!sinceSha) return true;
  try {
    const range = `${sinceSha}..HEAD`;
    const files = execSync(`git diff --name-only ${range} -- ${POLICY_RELEVANT_PATHS.map(p => `'${p}'`).join(' ')}`, { encoding: 'utf8' }).trim();
    return files.length > 0;
  } catch {
    return false;
  }
}

// ── Poison test ────────────────────────────────────────────────────────────────

export interface PoisonTestResult {
  passed: boolean;
  periodsChecked: number;
  mismatches: Array<{ periodStartMs: number; minuteMark: 5 | 10; real: unknown; poisoned: unknown }>;
}

/**
 * For every period/minuteMark decision point, rebuilds the decision once
 * against the real candle series and once against a series whose POST-
 * decision candles have been scrambled (poisonSeriesAfter), and asserts the
 * two decisions are identical (same admit/skip, side, strategyId,
 * confidence, entryPriceCents). A single mismatch means a decision is
 * secretly reading future data — a hard correctness failure, not a warning.
 */
export function runPoisonTest(candles: Awaited<ReturnType<typeof fetchRealCandles>>['candles'], policy: SimPolicy): PoisonTestResult {
  const periods = groupIntoPeriods(candles);
  const mismatches: PoisonTestResult['mismatches'] = [];
  let checked = 0;

  for (const period of periods) {
    for (const minuteMark of [5, 10] as const) {
      const cutoffIndex = minuteMark === 5 ? period.startIndex : period.startIndex + 1;
      const poisoned = poisonSeriesAfter(candles, cutoffIndex);

      const realObs     = buildDecisionObservation(candles, period, minuteMark);
      const poisonedObs = buildDecisionObservation(poisoned, period, minuteMark);
      const realDecision     = decideAtPoint(realObs, policy);
      const poisonedDecision = decideAtPoint(poisonedObs, policy);
      checked++;

      const realKey     = JSON.stringify({ a: realDecision.admitted, s: realDecision.strategyId, d: realDecision.side, c: realDecision.confidence, e: realDecision.entryPriceCents });
      const poisonedKey = JSON.stringify({ a: poisonedDecision.admitted, s: poisonedDecision.strategyId, d: poisonedDecision.side, c: poisonedDecision.confidence, e: poisonedDecision.entryPriceCents });
      if (realKey !== poisonedKey) {
        mismatches.push({ periodStartMs: period.periodStartMs, minuteMark, real: realDecision, poisoned: poisonedDecision });
      }
    }
  }
  return { passed: mismatches.length === 0, periodsChecked: checked, mismatches };
}

// ── Full LEAN vs LEGACY comparison ──────────────────────────────────────────────

export interface LeanVsLegacyReport {
  fetchedAt:   string;
  lookbackDays: number;
  candleCount: number;
  source:      string;
  lean:   { metrics: PolicyMetrics; trades: SimTrade[] };
  legacy: { metrics: PolicyMetrics; trades: SimTrade[] };
  verdict: VerdictResult;
  sensitivity: SensitivityRow[];
  poisonTest: PoisonTestResult;
  limitations: string[];
}

export const LIMITATIONS = [
  'fairDistFromFloorPct/estimatedFairBRTI are never populated — no historical dual-feed basis series exists; the 11 fair-price-aware strategies fall back to raw distFromFloorPct, as in every other backtest in this codebase.',
  "classifyRegimeFromBuffer never emits 'squeeze' or 'fakeout' — those regimes (and the SQUEEZE pack) are structurally unreachable here, a known gap shared with historical-backtester.ts's pack backtest.",
  'Sizing is fixed at 1 contract per admitted trade — this measures per-trade fee-net economics and admit-rate behavior, not a full Kelly/position-sizing model (deliberately out of scope, see Part III).',
  "A SimPolicy's packConfBumpMax is documentation-only: enforced confBump values always come from specialist-packs.ts's live table (already clamped <= 1 post Step 4).",
  'ARIA (the LLM risk agent) is not modeled — this lab measures the mechanical admit pipeline only, upstream of any live ARIA veto/sizing overlay.',
  'Kalshi order-book depth/fill-probability is not modeled — entryPriceCents is a simulated ask (see historical-backtester.ts buildSimObs quote model), not a guaranteed fill.',
];

export async function runLeanVsLegacy(opts: {
  lookbackDays?: number;
  feeCentsBump?: number;   // sensitivity: extra fee cents applied to BOTH policies
  m5Only?: boolean;        // sensitivity: restrict decisions to minute-5 only
} = {}): Promise<LeanVsLegacyReport> {
  const lookbackDays = opts.lookbackDays ?? DEFAULT_LOOKBACK_DAYS;
  const count = Math.round((lookbackDays * 24 * 60) / DEFAULT_INTERVAL_MINS);
  const startMs = Date.now() - lookbackDays * 24 * 60 * 60 * 1000;

  const { candles, source } = await fetchRealCandles(startMs, count, DEFAULT_INTERVAL_MINS);
  const periods = groupIntoPeriods(candles);

  const leanPolicy   = applySensitivity(POLICY_LEAN, opts);
  const legacyPolicy = applySensitivity(POLICY_LEGACY, opts);

  const runOne = (policy: SimPolicy) => {
    const { trades } = runPolicyOverPeriods(candles, periods, policy);
    const metrics = pooledOosMetrics(trades);
    return { metrics, trades };
  };

  const lean   = runOne(leanPolicy);
  const legacy = runOne(legacyPolicy);
  const verdict = decideVerdict(lean.metrics, legacy.metrics);

  const sensitivity = runSensitivitySweep(candles, periods, opts);
  const poisonTest = runPoisonTest(candles.slice(0, Math.min(candles.length, 300)), leanPolicy); // bounded sample — poison test is O(periods) decision rebuilds, not worth running over the full lookback window every call

  return {
    fetchedAt: new Date().toISOString(),
    lookbackDays,
    candleCount: candles.length,
    source,
    lean, legacy, verdict, sensitivity, poisonTest,
    limitations: LIMITATIONS,
  };
}

function applySensitivity(policy: SimPolicy, opts: { feeCentsBump?: number }): SimPolicy {
  if (!opts.feeCentsBump) return policy;
  return { ...clonePolicy(policy), feeCents: policy.feeCents + opts.feeCentsBump };
}

function runSensitivitySweep(
  candles: Awaited<ReturnType<typeof fetchRealCandles>>['candles'],
  periods: ReturnType<typeof groupIntoPeriods>,
  baseOpts: { feeCentsBump?: number; m5Only?: boolean },
): SensitivityRow[] {
  const deadline = Date.now() + RUN_TIME_BUDGET_MS;
  const scenarios: Array<{ label: string; feeCents: number; m5Only: boolean }> = [
    { label: 'base',            feeCents: 0, m5Only: false },
    { label: 'fee+2c',          feeCents: 2, m5Only: false },
    { label: 'fee-1c',          feeCents: -1, m5Only: false },
    { label: 'm5-only',         feeCents: 0, m5Only: true },
  ];
  const rows: SensitivityRow[] = [];
  for (const scenario of scenarios) {
    if (Date.now() > deadline) {
      console.warn(`[policy-regression] sensitivity sweep hit its time budget — skipping remaining scenarios after "${scenario.label}"`);
      break;
    }
    const lean   = { ...clonePolicy(POLICY_LEAN),   feeCents: POLICY_LEAN.feeCents + scenario.feeCents };
    const legacy = { ...clonePolicy(POLICY_LEGACY), feeCents: POLICY_LEGACY.feeCents + scenario.feeCents };
    const runOne = (policy: SimPolicy) => {
      const usablePeriods = scenario.m5Only ? periods : periods; // minuteMark restriction applied inside runPolicyOverPeriods via a m5Only-aware wrapper below
      const { trades } = scenario.m5Only
        ? runPolicyOverPeriodsM5Only(candles, usablePeriods, policy)
        : runPolicyOverPeriods(candles, usablePeriods, policy);
      return pooledOosMetrics(trades);
    };
    const leanMetrics   = runOne(lean);
    const legacyMetrics = runOne(legacy);
    rows.push({ label: scenario.label, lean: leanMetrics, legacy: legacyMetrics, verdict: decideVerdict(leanMetrics, legacyMetrics) });
  }
  return rows;
}

/** m5-only variant of runPolicyOverPeriods: never falls through to a
 *  minute-10 decision, for the "does the m10 leg matter" sensitivity check. */
function runPolicyOverPeriodsM5Only(
  candles: Awaited<ReturnType<typeof fetchRealCandles>>['candles'],
  periods: ReturnType<typeof groupIntoPeriods>,
  policy: SimPolicy,
): { trades: SimTrade[] } {
  const trades: SimTrade[] = [];
  for (const period of periods) {
    const obs = buildDecisionObservation(candles, period, 5);
    const decision = decideAtPoint(obs, policy);
    decision.periodStartMs = period.periodStartMs;
    decision.minuteMark = 5;
    if (decision.admitted && decision.side && decision.entryPriceCents != null) {
      const settleAboveFloor = period.settlementClose > period.floorStrike;
      const won = (decision.side === 'YES') === settleAboveFloor;
      const extraFriction = policy.feeCents + policy.slipCents;
      const entryPriceCents = decision.entryPriceCents;
      const pnlCents = won
        ? kalshiNetWinCents(entryPriceCents) - extraFriction
        : -kalshiNetCostCents(entryPriceCents) - extraFriction;
      trades.push({ ...decision, won, pnlCents });
    }
  }
  return { trades };
}

// ── Continuous regression: snapshot + baseline compare + report ────────────────

export type RegressionOutcome = 'PASS' | 'WARN' | 'BASELINE_ESTABLISHED';

export interface RegressionReport {
  outcome: RegressionOutcome;
  reasons: string[];
  gitSha:  string | null;
  snapshotId: string;
  reportPath: string;
  comparison: LeanVsLegacyReport;
}

/** Runs one full regression pass, saves a LEAN snapshot, compares its OOS
 *  fee-net against the previous LEAN baseline snapshot, and writes a report
 *  file. Never writes to live bot config — see this file's module doc. */
export async function runPolicyRegression(triggerReason: string, opts: Parameters<typeof runLeanVsLegacy>[0] = {}): Promise<RegressionReport> {
  const gitSha = getCurrentGitSha();
  const comparison = await runLeanVsLegacy(opts);
  const snapshotId = `LEAN@${comparison.fetchedAt}`;

  const priorLeanSnapshot = await getLatestSnapshot('LEAN');
  await saveSnapshot({
    snapshotId, gitSha, policy: POLICY_LEAN,
    oosMetrics: comparison.lean.metrics, verdict: comparison.verdict.verdict,
    note: `trigger: ${triggerReason}`,
  });

  const reasons: string[] = [];
  let outcome: RegressionOutcome;
  if (!priorLeanSnapshot || !priorLeanSnapshot.oosMetrics) {
    outcome = 'BASELINE_ESTABLISHED';
    reasons.push('No prior LEAN snapshot with OOS metrics found — this run establishes the baseline.');
  } else {
    const prevFeeNet = priorLeanSnapshot.oosMetrics.feeNetPnlCents;
    const currFeeNet = comparison.lean.metrics.feeNetPnlCents;
    const prevWrongKit = priorLeanSnapshot.oosMetrics.wrongKitRate;
    const currWrongKit = comparison.lean.metrics.wrongKitRate;
    const feeNetDrop = prevFeeNet - currFeeNet;
    const warnings: string[] = [];
    // Noise floor: reuse the same bootstrap-CI-derived per-trade tolerance
    // decideVerdict() uses, scaled by trade count, so this gate isn't
    // tripped by ordinary sample-to-sample variance.
    const ciWidth = comparison.lean.metrics.bootstrap.p95 - comparison.lean.metrics.bootstrap.p5;
    const noiseToleranceCents = Math.max(1, ciWidth * 100) * Math.max(1, comparison.lean.metrics.trades);
    if (feeNetDrop > noiseToleranceCents) {
      warnings.push(`LEAN OOS fee-net dropped ${feeNetDrop.toFixed(0)}c vs baseline (${prevFeeNet.toFixed(0)}c -> ${currFeeNet.toFixed(0)}c), beyond the ~${noiseToleranceCents.toFixed(0)}c noise band.`);
    }
    if (currWrongKit - prevWrongKit > 0.10) {
      warnings.push(`wrong_kit_rate jumped ${(prevWrongKit * 100).toFixed(1)}% -> ${(currWrongKit * 100).toFixed(1)}%.`);
    }
    if (warnings.length > 0) {
      outcome = 'WARN';
      reasons.push(...warnings);
    } else {
      outcome = 'PASS';
      reasons.push(`LEAN OOS fee-net ${currFeeNet.toFixed(0)}c vs baseline ${prevFeeNet.toFixed(0)}c — no regression beyond noise.`);
    }
  }

  const reportPath = writeReportFile({ outcome, reasons, gitSha, snapshotId, comparison, triggerReason });
  return { outcome, reasons, gitSha, snapshotId, reportPath, comparison };
}

function writeReportFile(args: {
  outcome: RegressionOutcome; reasons: string[]; gitSha: string | null; snapshotId: string;
  comparison: LeanVsLegacyReport; triggerReason: string;
}): string {
  fs.mkdirSync(REPORT_DIR, { recursive: true });
  const fileStamp = args.comparison.fetchedAt.replace(/[:.]/g, '-');
  const jsonPath = path.join(REPORT_DIR, `${fileStamp}.json`);
  const mdPath   = path.join(REPORT_DIR, `${fileStamp}.md`);

  fs.writeFileSync(jsonPath, JSON.stringify(args, null, 2));

  const c = args.comparison;
  const md = [
    `# Policy Regression Report`,
    ``,
    `- Trigger: ${args.triggerReason}`,
    `- Git SHA: ${args.gitSha ?? 'n/a'}`,
    `- Snapshot: ${args.snapshotId}`,
    `- Outcome: **${args.outcome}**`,
    `- Fetched: ${c.fetchedAt} (${c.lookbackDays}d, ${c.candleCount} candles, source=${c.source})`,
    ``,
    `## Reasons`,
    ...args.reasons.map(r => `- ${r}`),
    ``,
    `## LEAN vs LEGACY (pooled sequential OOS)`,
    ``,
    `| Policy | Trades | Win Rate | Fee-Net (c) | Max DD | PF | Wrong-Kit |`,
    `|---|---|---|---|---|---|---|`,
    `| LEAN | ${c.lean.metrics.trades} | ${(c.lean.metrics.winRate * 100).toFixed(1)}% | ${c.lean.metrics.feeNetPnlCents.toFixed(0)} | ${(c.lean.metrics.maxDrawdown * 100).toFixed(1)}% | ${c.lean.metrics.profitFactor.toFixed(2)} | ${(c.lean.metrics.wrongKitRate * 100).toFixed(1)}% |`,
    `| LEGACY | ${c.legacy.metrics.trades} | ${(c.legacy.metrics.winRate * 100).toFixed(1)}% | ${c.legacy.metrics.feeNetPnlCents.toFixed(0)} | ${(c.legacy.metrics.maxDrawdown * 100).toFixed(1)}% | ${c.legacy.metrics.profitFactor.toFixed(2)} | ${(c.legacy.metrics.wrongKitRate * 100).toFixed(1)}% |`,
    ``,
    `**Verdict: ${c.verdict.verdict}** — ${c.verdict.reason}`,
    ``,
    `_${WRONG_KIT_FORMULA_SUMMARY}_`,
    ``,
    `## Poison test`,
    `${c.poisonTest.passed ? 'PASSED' : 'FAILED'} — ${c.poisonTest.periodsChecked} decision points checked, ${c.poisonTest.mismatches.length} mismatches.`,
    ``,
    `## Sensitivity`,
    ``,
    `| Scenario | LEAN verdict | LEGACY fee-net | LEAN fee-net |`,
    `|---|---|---|---|`,
    ...c.sensitivity.map(r => `| ${r.label} | ${r.verdict.verdict} | ${r.legacy.feeNetPnlCents.toFixed(0)}c | ${r.lean.feeNetPnlCents.toFixed(0)}c |`),
    ``,
    `## Limitations`,
    ...c.limitations.map(l => `- ${l}`),
    ``,
    `_This report never modifies live trading config. It is a research artifact only._`,
  ].join('\n');
  fs.writeFileSync(mdPath, md);
  return mdPath;
}
