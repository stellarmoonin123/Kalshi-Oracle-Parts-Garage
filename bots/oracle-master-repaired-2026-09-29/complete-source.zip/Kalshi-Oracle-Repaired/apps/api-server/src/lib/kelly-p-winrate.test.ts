/**
 * Kelly p = winRateAtPrice (same p PATH_GATE / evaluateEntryEVGate used).
 * Wilson/uMult shrink f* or size only — never replacement p. No 0.50 floor on p.
 *
 * Does NOT import trading-bot.ts (node:test isolation).
 *
 * LOCKS: EV 3¢ / OTM 5¢ / PATH MULTIPLIER 7¢ / 9% / 18% / Kelly 0.60.
 * paper stays paper. Never ENABLE_STRATEGY.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import test from "node:test";
import assert from "node:assert/strict";
import {
  EV_FLOOR,
  OTM_EV_FLOOR,
  HARD_RISK_LIMITS,
  evaluateEntryEVGate,
  computeContracts,
  computeKellyEdge,
  kellyPayoutRatio,
  kellyFraction,
  applyHardRiskLimits,
} from "./admission.js";
import { PATH_CONFIGS, computeTradeEV } from "./trade-path.js";
import { ENTRY_PRICE_BANDS, kalshiNetCostCents, kalshiNetWinCents } from "./constants.js";
import { PAPER_SCALP_CONTRACTS, PAPER_SCALP_STRATEGY_ID } from "./paper-scalp.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const BOT = readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");
const ADM = readFileSync(path.join(DIR, "admission.ts"), "utf8");

test("EV floors unchanged: 3 / 5 / 7", () => {
  assert.equal(EV_FLOOR, 3);
  assert.equal(OTM_EV_FLOOR, 5);
  assert.equal(PATH_CONFIGS.MULTIPLIER.minEVCents, 7);
  assert.equal(PATH_CONFIGS.HIGH_PROB.minEVCents, 3);
  assert.equal(PATH_CONFIGS.GRAY.minEVCents, 3);
  assert.ok(PATH_CONFIGS.HIGH_PROB.minEVCents >= EV_FLOOR);
  assert.ok(PATH_CONFIGS.GRAY.minEVCents >= EV_FLOOR);
  assert.ok(PATH_CONFIGS.MULTIPLIER.minEVCents >= PATH_CONFIGS.GRAY.minEVCents);
  assert.match(ADM, /export const EV_FLOOR\s*=\s*3/);
  assert.match(ADM, /export const OTM_EV_FLOOR\s*=\s*5/);
});

test("9% still binds; 18% day halt zeros; Kelly frac 0.60 cap", () => {
  assert.equal(HARD_RISK_LIMITS.maxRiskPctPerTrade, 0.09);
  assert.equal(HARD_RISK_LIMITS.maxDailyLossPct, 0.18);
  assert.equal(kellyFraction(80, 8), 0.60);
  assert.equal(kellyFraction(99, 99), 0.60);
  const bankroll = 31_300;
  const entry = 53;
  const cost = Math.ceil(kalshiNetCostCents(entry));
  const maxByPct = Math.floor((bankroll * 0.09) / cost);
  const sized = applyHardRiskLimits(bankroll, entry, 10_000, 0);
  assert.equal(sized, maxByPct);
  assert.ok(sized * cost <= bankroll * 0.09 + 1e-9);
  assert.equal(applyHardRiskLimits(bankroll, entry, 10_000, -(bankroll * 0.18)), 0);
});

test("Kelly p equals winRateAtPrice used at EV gate for a fixture", () => {
  const ask = 53;
  const winRateAtPrice = 0.72; // same number PATH_GATE / evaluateEntryEVGate use
  const wilsonPaperPrior = 0.55; // computePSizeForKelly n=0 — must NOT be Kelly p

  const gate = evaluateEntryEVGate({
    entryPriceCents: ask,
    strategyWinRate: winRateAtPrice,
    calibratedWinRate: 0.97, // mass swap — ignored
    strategyId: "BASIS_LAG_EDGE",
    secsRemaining: 400,
    velocityDolPerMin: 80,
    spreadCents: 2,
  });
  assert.equal(gate.modelEstimatedProb, winRateAtPrice);
  assert.equal(gate.minEVCents, EV_FLOOR);

  const b = kellyPayoutRatio(ask);
  assert.equal(b, Math.min(4.5, kalshiNetWinCents(ask) / kalshiNetCostCents(ask)));
  const fStarGate = computeKellyEdge(gate.modelEstimatedProb, b);
  const fStarWilson = computeKellyEdge(wilsonPaperPrior, b);
  assert.ok(fStarGate > 0);
  assert.notEqual(fStarGate, fStarWilson);

  const sized = computeContracts({
    pWin: winRateAtPrice,
    pSizeClamped: wilsonPaperPrior,
    entryPriceCents: ask,
    confidence: 80,
    edge: 8,
    balanceCents: 31_300,
    maxContracts: 999,
    uMult: 1,
  });
  const expectedFromGateP = Math.min(
    999,
    Math.floor(fStarGate * 0.60 * 31_300 / Math.ceil(kalshiNetCostCents(ask))),
  );
  assert.equal(sized.contracts, expectedFromGateP);

  const sizedWilson = computeContracts({
    pSizeClamped: wilsonPaperPrior,
    entryPriceCents: ask,
    confidence: 80,
    edge: 8,
    balanceCents: 31_300,
    maxContracts: 999,
    uMult: 1,
  });
  assert.notEqual(sized.contracts, sizedWilson.contracts);
});

test("PAPER_SCALP size still 1; ENTRY_PRICE_BANDS 7–55; MULTIPLIER 7¢ untouched and now hits PAPER_SCALP", () => {
  assert.equal(PAPER_SCALP_CONTRACTS, 1);
  assert.equal(PAPER_SCALP_STRATEGY_ID, "PAPER_SCALP");
  assert.deepEqual(ENTRY_PRICE_BANDS.PAPER_SCALP, { min: 7, max: 55 });
  assert.equal(PATH_CONFIGS.MULTIPLIER.minEVCents, 7);

  // 25¢ MULTIPLIER-class ask: wr 0.34 clears EV_FLOOR 3¢ with live slip but
  // fails the settlement MULTIPLIER 7¢ class. Paper = live: PAPER_SCALP must
  // also fail this fixture at PATH 7¢ (no paper-only 3¢ escape).
  const ask = 25;
  const wr = 0.34;
  const live = { secsRemaining: 400, velocityDolPerMin: 40, spreadCents: 2 };
  const scalpEV = computeTradeEV({
    entryPriceCents: ask, winRate: wr, minEVCents: EV_FLOOR, ...live,
  });
  const multiplierEV = computeTradeEV({
    entryPriceCents: ask, winRate: wr, minEVCents: PATH_CONFIGS.MULTIPLIER.minEVCents, ...live,
  });
  assert.equal(scalpEV.passes, true, `3¢ floor still 3: netEV=${scalpEV.netEV.toFixed(2)}`);
  assert.ok(scalpEV.netEV >= EV_FLOOR);
  assert.equal(multiplierEV.passes, false, "MULTIPLIER 7¢ class must still reject this fixture");
  assert.ok(multiplierEV.netEV < 7);

  // includes — never assert.match full trading-bot.ts (600KB TAP hang).
  assert.ok(BOT.includes('strategyId === "PAPER_SCALP"'));
  assert.equal(BOT.includes("PATH hard filters / MULTIPLIER 7¢ skipped"), false);
  assert.ok(BOT.includes("evaluatePathDecision"));
  assert.ok(BOT.includes("PAPER_SCALP_SIZE_1") || /contracts:\s*1/.test(BOT));
  assert.ok(BOT.includes('!isOTMPlay && strategyId !== "PAPER_SCALP"'));
  assert.ok(/paperMode:\s*true/.test(BOT));
  assert.ok(/autoMode:\s*false/.test(BOT));
});

test("uMult shrinks size; Wilson p is not Kelly p (source-text)", () => {
  assert.ok(ADM.includes("pWin?: number") || ADM.includes("pWin?"));
  assert.ok(ADM.includes("opts.pWin"));
  assert.ok(BOT.includes('const p = (typeof strategyWinRate === "number"'));
  assert.ok(BOT.includes('pWin: (typeof strategyWinRate === "number"'));
});

test("hard-risk 0 calls skip(SIZING_ZERO); pWinAtPrice never uses expectedWinRate", () => {
  // includes — avoid assert.match hang on 600KB bot.
  assert.ok(BOT.includes('skip("SIZING_ZERO"'));
  assert.ok(BOT.includes("hard risk limits sized to 0"));
  // pWinFromCurve / void _expectedWinRate live in admission.ts (ADM), not trading-bot.
  assert.ok(ADM.includes("void _expectedWinRate"));
  assert.ok(ADM.includes("return pWinFromCurve(winRateAtPrice, entryPriceCents, minutesLeft)"));
  assert.equal(BOT.includes("const p = expectedWinRate;"), false);
  assert.ok(BOT.includes("pWinAtPriceRejectingThinLearner"));
});

test("Kelly-zero stays 0 — never rounded up to 1", () => {
  // 53¢: break-even p ≈ 0.567. p=0.50 → f* < 0 → contracts 0.
  const zero = computeContracts({
    pWin: 0.50,
    pSizeClamped: 0.55,
    entryPriceCents: 53,
    confidence: 80,
    edge: 8,
    balanceCents: 31_300,
    maxContracts: 999,
    uMult: 1,
  });
  assert.equal(zero.contracts, 0);
  assert.equal(zero.limiter, "KELLY_EDGE_NONPOSITIVE");
});


test("p>1 / bad b / uMult>1 cannot oversize past Kelly 0.60 bankroll cap", () => {
  const bal = 31_300;
  const entry = 40;
  const capped = computeContracts({
    pWin: 1.2, // invalid — must clamp to 1.0
    pSizeClamped: 0.50,
    entryPriceCents: entry,
    confidence: 80,
    edge: 8,
    balanceCents: bal,
    maxContracts: 9999,
    uMult: 1,
  });
  const atOne = computeContracts({
    pWin: 1.0,
    pSizeClamped: 0.50,
    entryPriceCents: entry,
    confidence: 80,
    edge: 8,
    balanceCents: bal,
    maxContracts: 9999,
    uMult: 1,
  });
  assert.equal(capped.contracts, atOne.contracts);
  assert.ok(capped.contracts >= 0);

  const boosted = computeContracts({
    pWin: 0.58,
    pSizeClamped: 0.58,
    entryPriceCents: entry,
    confidence: 80,
    edge: 8,
    balanceCents: bal,
    maxContracts: 9999,
    uMult: 2.5, // must shrink-only clamp to 1
    volumeSizeMult: 3,
    guardrail: 2,
  });
  const base = computeContracts({
    pWin: 0.58,
    pSizeClamped: 0.58,
    entryPriceCents: entry,
    confidence: 80,
    edge: 8,
    balanceCents: bal,
    maxContracts: 9999,
    uMult: 1,
  });
  assert.equal(boosted.contracts, base.contracts);

  // entry ≥100 → b=0 → no size (never Inf / sign-flip oversize)
  const rich = computeContracts({
    pWin: 0.90,
    pSizeClamped: 0.90,
    entryPriceCents: 101,
    confidence: 80,
    edge: 8,
    balanceCents: bal,
    maxContracts: 9999,
    uMult: 1,
  });
  assert.equal(rich.contracts, 0);
  assert.equal(rich.limiter, "KELLY_EDGE_NONPOSITIVE");
  assert.equal(kellyPayoutRatio(101), 0);
  assert.equal(computeKellyEdge(0.9, 0), 0);
  assert.equal(EV_FLOOR, 3);
  assert.equal(kellyFraction(99, 99), 0.60);
});
