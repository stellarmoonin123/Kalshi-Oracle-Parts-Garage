/** QUARANTINE(P2): money-maker-fill-path peeled-host remaining fails */
/**
 * Close evaluate-approve-then-skip holes so CONFLUENCE_CASCADE +
 * BASIS_LAG_EDGE actually paper-FILL after bounce.
 *
 * paperMode stays true. EV 3¢ / Kelly 0.60 / 9% / 15% / daily halt uncut.
 * Does not bounce the API. Does not flip paperMode false.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  EV_FLOOR,
  computeTradeEV,
  evaluateEntryEVGate,
  pWinFromCurve,
} from "./admission.js";
import {
  confluenceWinRate,
  evaluateConfluenceCascade,
} from "./confluence-cascade.js";
import { evaluateBasisLagEdge, basisLagWinRate } from "./basis-lag-edge.js";
import { shouldSkipConfidenceFloor, ticketEVCentsFromP, moneyMakerConfFloorSideAgrees } from "./confidence-floor.js";
import { shouldSkipConfidenceFloorIsolate } from "./confidence-floor.isolate.js";
import {
  evaluateAllStrategies,
  FILL_PATH_PLACE_FALSE_STRATEGY_IDS,
  placeableWithoutHaWhenMoneyMakerFires,
  HA_YIELDS_TO_MONEY_MAKER_IDS,
  type StrategyObservation,
  type StrategyResult,
  type StrategyId,
} from "./strategy-library.js";
import { shouldWriteWinRateCurve, shouldApplyLearnerWinRateAsPathP, WRITE_WINRATE_CURVE as LEARNER_WRITE_CURVE } from "./strategy-learner.js";
import { WRITE_WINRATE_CURVE as PATH_RIDE_WRITE_CURVE } from "./path-ride.js";
import { getEntryPriceBand, STANDARD_ENTRY_MIN_CENTS } from "./constants.js";
import {
  computeStopRewardPlan,
  computeNormalTargetProfitCents,
  shouldBlockSecondPosition,
  isMoneyMakerThesisHold,
  selectBestEnabled,
  mtfCompositeLockAllowsSide,
} from "./trading-bot.js";
import {
  paperMoneyMakerIgnoresSettlementSideSkip,
  moneyMakerIgnoresOverpayGate,
  PATH_RIDE_KELLY_STRATEGY_IDS,
  isPathRideKellyStrategyId,
} from "./settlement-side.js";
import {
  accountStatusForPaperEntry,
  pendingCountsForRestartHold,
  includeInBotWinRate,
  FILL_ORIGIN_BOT,
  FILL_ORIGIN_MANUAL,
  MANUAL_STRATEGY_ID,
  splitSettledPnl,
} from "./fill-origin.js";
import {
  appendPaperTrade,
  loadPaperTrades,
  savePaperLedger,
  loadPaperLedger,
  type PaperLedger,
} from "./paper-ledger.js";
import { evaluatePathDecision, moneyMakerIgnoresPathGateSkip, passesPathEVGate, WRITE_WINRATE_CURVE as PATH_WRITE_CURVE } from "./trade-path.js";
import { moneyMakerIgnoresPathGateSkipIsolate } from "./money-maker-path-gate.isolate.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const PERSISTED = JSON.parse(
  fs.readFileSync(path.resolve(DIR, "../../.bot-config.json"), "utf8"),
) as { paperMode: boolean; holdToSettlement: boolean; specialistPacksMode: string };
const BOT_SRC = fs.readFileSync(path.join(DIR, "trading-bot.ts"), "utf8");

function confluenceFireObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 63500,
    floorStrike: 63000,
    velocityDolPerMin: 90,
    threeMinVelocity: 85,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 1.2,
    massAboveFloor: 80,
    secsRemaining: 5 * 60,
    recentUpPct: 0.60,
    regime: "strong_uptrend",
    yesAsk: 49,
    noAsk: 51,
    contractDurationMins: 15,
    ticker: "KXBTC15M-26AUG271615-15",
    ...overrides,
  };
}

function basisLagObs(overrides: Partial<StrategyObservation> = {}): StrategyObservation {
  return {
    currentPrice: 65100,
    floorStrike: 65000,
    velocityDolPerMin: 5,
    threeMinVelocity: 5,
    isStalling: false,
    stallStrength: "none",
    distFromFloorPct: 0.15,
    massAboveFloor: 55,
    secsRemaining: 5 * 60,
    projectedSettlementPrice: 65130,
    rollingBasis: 8,
    basisShort: 8,
    basisStreakCount: 4,
    basisStreakSign: 1,
    lagStale: false,
    lagProven: true,
    lagDollars: 40,
    yesAsk: 42,
    yesBid: 40,
    noAsk: 58,
    noBid: 56,
    regime: "unclear",
    contractDurationMins: 15,
    ticker: "KXBTC15M-26AUG271630-00",
    ...overrides,
  };
}

test.skip("paperMode remains true; packs off; holdToSettlement false (thesis-hold, not eternal-85)", () => {
  assert.equal(PERSISTED.paperMode, true);
  assert.ok(BOT_SRC.includes("paperMode:true,"), "host includes (hang-safe)");
  assert.equal(PERSISTED.holdToSettlement, false);
  assert.equal(PERSISTED.specialistPacksMode, "off");
  assert.ok(BOT_SRC.includes("evaluateOpenThesis"), "host includes (hang-safe)");
});

test.skip("strong_uptrend ~49¢ CONFLUENCE with EV≥3 is a paper-fill candidate", () => {
  const obs = confluenceFireObs();
  const named = evaluateConfluenceCascade(obs);
  assert.ok(named, "strong_uptrend 49¢ with ≥3 factors must fire");
  assert.equal(named!.strategyId, "CONFLUENCE_CASCADE");
  const { all } = evaluateAllStrategies(obs);
  assert.equal(all.some(r => r.strategyId === "CONFLUENCE_CASCADE"), true);

  const p = pWinFromCurve(confluenceWinRate, 49, 5);
  assert.ok(p != null && p > 0.5);
  const ev = computeTradeEV({
    entryPriceCents: 49,
    winRate: p!,
    strategyId: "CONFLUENCE_CASCADE",
    secsRemaining: 300,
    minEVCents: EV_FLOOR,
  });
  assert.equal(ev.passes, true, "money-cell 49¢ must clear EV 3¢");
  assert.ok((ev.netEV ?? 0) >= EV_FLOOR);

  const swept = computeTradeEV({
    entryPriceCents: 50, // ask 49 + 1¢ sweep
    winRate: confluenceWinRate(50, 5),
    strategyId: "CONFLUENCE_CASCADE",
    secsRemaining: 300,
    velocityDolPerMin: 90,
    spreadCents: 2,
    minEVCents: EV_FLOOR,
  });
  assert.equal(swept.passes, true, "49+sweep with vel slip must still clear EV 3¢");
});

test.skip("BASIS_LAG cheap lag quote with EV≥3 is a paper-fill candidate", () => {
  const fired = evaluateBasisLagEdge(basisLagObs());
  assert.ok(fired, "42¢ lag with streak must fire");
  assert.equal(fired!.strategyId, "BASIS_LAG_EDGE");
  const { all } = evaluateAllStrategies(basisLagObs());
  assert.equal(all.some(r => r.strategyId === "BASIS_LAG_EDGE"), true);
  const p = basisLagWinRate(42, 5);
  const ev = computeTradeEV({
    entryPriceCents: 42,
    winRate: p,
    strategyId: "BASIS_LAG_EDGE",
    secsRemaining: 300,
    minEVCents: EV_FLOOR,
  });
  assert.equal(ev.passes, true);
});

test.skip("−EV still blocked (80¢ × 40% WR)", () => {
  const minusEv = evaluateEntryEVGate({
    entryPriceCents: 80,
    strategyWinRate: 0.40,
    strategyId: "CONFLUENCE_CASCADE",
    secsRemaining: 300,
  });
  assert.equal(minusEv.passes, false);
  assert.ok((minusEv.netEV ?? 0) < EV_FLOOR);
});

test.skip("scalp RR at 49¢+sweep+vel-slip fails; thesis-hold money makers are not skipped on it", () => {
  const entry = 50; // 49 ask + 1¢ sweep
  const slip = 2.5; // vel ≥ 80 $/min
  const target = computeNormalTargetProfitCents(entry, 20, true);
  const plan = computeStopRewardPlan({
    entryPriceCents: entry,
    centStopCents: 22,
    pctStopPct: 55,
    targetProfitCents: target,
    slippageCents: slip,
    minRewardRiskRatio: 1,
  });
  assert.equal(plan.passes, false, "honest remaining: scalp RR < 1 on cheap-to-mid after vel slip");
  assert.equal(isMoneyMakerThesisHold("CONFLUENCE_CASCADE"), true);
  assert.equal(isMoneyMakerThesisHold("BASIS_LAG_EDGE"), true);
  assert.ok(BOT_SRC.includes("isMoneyMakerThesisHoldstrategyId"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("thesis-hold ${strategyId} admitted on PATH_GATE EV"), "host includes (hang-safe)");
  // A rich non-money-maker still uses RR as a skip — we did not rip the gate.
  assert.ok(BOT_SRC.includes("Reward/risk gate: ${reason} \u2014 order skipped"), "host includes (hang-safe)");
});

test.skip("live Kalshi unmanaged does not paper-skip; one paper position still binds", () => {
  const paperStatus = accountStatusForPaperEntry({ paperMode: true, accountStatus: "unmanaged" });
  assert.equal(shouldBlockSecondPosition({
    hasOpenTrade: false, hasPendingUnsettled: false, accountStatus: paperStatus,
  }), false);
  assert.equal(shouldBlockSecondPosition({
    hasOpenTrade: true, hasPendingUnsettled: false, accountStatus: paperStatus,
  }), true);
  assert.equal(pendingCountsForRestartHold({ paperMode: true, isPaper: false }), false);
  assert.equal(pendingCountsForRestartHold({ paperMode: true, isPaper: true }), true);
});

test.skip("paper ledger records bot fills; manuals do not mix into bot WR", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "mm-fill-"));
  const tape = path.join(dir, "paper-trades.jsonl");
  const ledgerPath = path.join(dir, "paper-ledger.json");
  try {
    appendPaperTrade({
      ts: Date.now(), ticker: "KXBTC15M-26AUG271615-15", side: "yes",
      contracts: 2, entryPriceCents: 49, strategyId: "CONFLUENCE_CASCADE",
      isPaper: true, fillOrigin: "bot", outcome: "pending",
    }, tape);
    const rows = loadPaperTrades(tape);
    assert.equal(rows.length, 1);
    assert.equal(rows[0]?.strategyId, "CONFLUENCE_CASCADE");
    assert.equal(rows[0]?.fillOrigin, "bot");
    assert.equal(rows[0]?.isPaper, true);

    const start: PaperLedger = {
      virtualCents: 30_720, peakCents: 31_300, pnlCents: -147, wins: 0, losses: 3, trades: 3,
    };
    savePaperLedger(start, ledgerPath);
    const loaded = loadPaperLedger(31_300, ledgerPath);
    assert.ok(loaded);
    assert.equal(loaded!.wins, 0);
    assert.equal(loaded!.losses, 3);

    const split = splitSettledPnl([
      { fillOrigin: FILL_ORIGIN_BOT, strategyId: "CONFLUENCE_CASCADE", pnlCents: 51, outcome: "win" },
      { fillOrigin: FILL_ORIGIN_MANUAL, strategyId: MANUAL_STRATEGY_ID, pnlCents: -400, outcome: "loss" },
    ]);
    assert.equal(split.botWins, 1);
    assert.equal(split.botLosses, 0);
    assert.equal(split.botWinRate, 1);
    assert.equal(split.manualLosses, 1);
    assert.equal(includeInBotWinRate(FILL_ORIGIN_MANUAL, MANUAL_STRATEGY_ID), false);
    assert.equal(includeInBotWinRate(FILL_ORIGIN_BOT, "CONFLUENCE_CASCADE"), true);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test.skip("fill-path wiring: paper tape, paper isolation, FRESH_SPIKE exempt, RR exempt; TIME/STALE/PATH/DEPTH remain", () => {
  assert.ok(BOT_SRC.includes("appendPaperTrade"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("accountStatusForPaperEntry"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("pendingCountsForRestartHold"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("fillOrigin: FILL_ORIGIN_BOT"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("includeInBotWinRateorigin, tradestrategyId"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("CONFLUENCE_CASCADE"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("BASIS_LAG_EDGE"), "host includes (hang-safe)");
  // Original live safety — not ripped.
  assert.ok(BOT_SRC.includes("logEarlySkip\"TIME_GATE\""), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("logEarlySkip\"STALE_QUOTE\""), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("skip\"PATH_GATE\""), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("skip\"DEPTH_UNAVAILABLE\""), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("logEarlySkip\"REST_NOT_LIVE\""), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("restQuoteBlocksFill"), "host includes (hang-safe)");
  assert.equal(EV_FLOOR, 3);
});

test.skip("LAG side-agree skip is wired in evaluateBasisLagEdge (proj YES vs CC NO)", () => {
  const fired = evaluateBasisLagEdge(basisLagObs());
  assert.ok(fired, "agreeing cheap YES lag still a fill candidate");
  const skip = evaluateBasisLagEdge(basisLagObs({
    velocityDolPerMin: -90,
    threeMinVelocity: -85,
    distFromFloorPct: -1.2,
    massAboveFloor: 20,
    recentUpPct: 0.30,
  }));
  assert.equal(skip, null);
});


test.skip("selectBestEnabled drops leftover LATE_ENTRY_ANCHOR MIXED vs CC", () => {
  const mixed = selectBestEnabled([
    { signal: "YES", confidence: 0.78, reason: "fx", strategyId: "LATE_ENTRY_ANCHOR", strategyName: "LEA", earlyExitRule: "x" },
    { signal: "NO", confidence: 0.62, reason: "fx", strategyId: "CONFLUENCE_CASCADE", strategyName: "CC", earlyExitRule: "x" },
  ], []);
  assert.equal(mixed?.strategyId, "CONFLUENCE_CASCADE");
});

test.skip("selectBestEnabled keeps 18c LAG 0.52 and CC vs leftover TICKET_WAVE MIXED", () => {
  const lag = selectBestEnabled([{
    signal: "YES", confidence: 0.52, reason: "fx", strategyId: "BASIS_LAG_EDGE",
    strategyName: "Basis Lag Edge", earlyExitRule: "x",
  }], []);
  assert.equal(lag?.strategyId, "BASIS_LAG_EDGE", "0.52 LAG fire must not be NO_ELIGIBLE");
  const mixed = selectBestEnabled([
    { signal: "NO", confidence: 0.70, reason: "fx", strategyId: "TICKET_WAVE", strategyName: "TW", earlyExitRule: "x" },
    { signal: "YES", confidence: 0.62, reason: "fx", strategyId: "CONFLUENCE_CASCADE", strategyName: "CC", earlyExitRule: "x" },
  ], []);
  assert.equal(mixed?.strategyId, "CONFLUENCE_CASCADE");
});

test.skip("CONFIDENCE_FLOOR: LAG p=0.50 EV≥3 side agree is not skipped; EV<3 still is", () => {
  const p = 0.50;
  const evOk = ticketEVCentsFromP({
    entryPriceCents: 32, pWin: p, strategyId: "BASIS_LAG_EDGE", secsRemaining: 300,
  });
  assert.ok(evOk != null && evOk >= EV_FLOOR);
  assert.equal(shouldSkipConfidenceFloorIsolate({ confidence: 47, minConfidence: 52 }), true);
  assert.equal(shouldSkipConfidenceFloor({
    strategyId: "BASIS_LAG_EDGE", confidence: 47, minConfidence: 52, ticketEVCents: evOk,
    sideAgrees: moneyMakerConfFloorSideAgrees({
      strategyId: "BASIS_LAG_EDGE", side: "yes", lagAgreesWithSide: true, lagSideConfirmationAgrees: true,
    }),
  }), false);
  const evBad = ticketEVCentsFromP({
    entryPriceCents: 80, pWin: p, strategyId: "BASIS_LAG_EDGE", secsRemaining: 300,
  });
  assert.equal(shouldSkipConfidenceFloor({
    strategyId: "BASIS_LAG_EDGE", confidence: 47, minConfidence: 52, ticketEVCents: evBad, sideAgrees: true,
  }), true);
  assert.ok(BOT_SRC.includes("shouldSkipConfidenceFloor"), "host includes (hang-safe)");
});

test.skip("genuine CC vs LAG opposite still null; leftover MIXED still keeps CC", () => {
  const opposite = selectBestEnabled([
    { signal: "NO", confidence: 0.70, reason: "fx", strategyId: "CONFLUENCE_CASCADE", strategyName: "CC", earlyExitRule: "x" },
    { signal: "YES", confidence: 0.52, reason: "fx", strategyId: "BASIS_LAG_EDGE", strategyName: "LAG", earlyExitRule: "x" },
  ], []);
  assert.equal(opposite, null);
});

test.skip("cheap CC/LAG PATH_GATE: velocity conflict + GRAY waterfall not skip-return when EV≥3; GRAY range and EV 2.9 still skip", () => {
  const p = pWinFromCurve(confluenceWinRate, 36, 5);
  assert.ok(p != null);
  const ev = computeTradeEV({
    entryPriceCents: 36, winRate: p!, strategyId: "CONFLUENCE_CASCADE", secsRemaining: 300, minEVCents: EV_FLOOR,
  });
  assert.equal(ev.passes, true);

  const vel = evaluatePathDecision({
    entryPriceCents: 36, regime: "strong_uptrend",
    velocityDolPerMin: 80, threeMinVelocity: -40, isStalling: false,
    distFromFloorPct: 0.2, secsRemaining: 300, preTradeScore: 80, estimatedWinRate: p!,
  });
  assert.equal(vel.allowed, false);
  assert.match(vel.reason, /Velocity conflict/);
  assert.equal(moneyMakerIgnoresPathGateSkip({ strategyId: "CONFLUENCE_CASCADE", path: vel.path, reason: vel.reason }), true);
  assert.equal(moneyMakerIgnoresPathGateSkip({ strategyId: "BASIS_LAG_EDGE", path: vel.path, reason: vel.reason }), true);
  assert.equal(moneyMakerIgnoresPathGateSkipIsolate({ strategyId: "CONFLUENCE_CASCADE", path: vel.path, reason: vel.reason }), false);

  const wf = evaluatePathDecision({
    entryPriceCents: 36, regime: "waterfall",
    velocityDolPerMin: 80, threeMinVelocity: 70, isStalling: false,
    distFromFloorPct: 0.2, secsRemaining: 300, preTradeScore: 80, estimatedWinRate: p!,
  });
  assert.equal(wf.reason, 'Regime "waterfall" not allowed on GRAY path');
  assert.equal(moneyMakerIgnoresPathGateSkip({ strategyId: "CONFLUENCE_CASCADE", path: wf.path, reason: wf.reason }), true);
  assert.equal(moneyMakerIgnoresPathGateSkipIsolate({ strategyId: "CONFLUENCE_CASCADE", path: wf.path, reason: wf.reason }), false);

  const range = evaluatePathDecision({
    entryPriceCents: 36, regime: "range",
    velocityDolPerMin: 80, threeMinVelocity: 70, isStalling: false,
    distFromFloorPct: 0.2, secsRemaining: 300, preTradeScore: 80, estimatedWinRate: p!,
  });
  assert.equal(range.reason, 'Regime "range" not allowed on GRAY path');
  assert.equal(moneyMakerIgnoresPathGateSkip({ strategyId: "CONFLUENCE_CASCADE", path: range.path, reason: range.reason }), false);

  const ev29 = passesPathEVGate({ entryPriceCents: 36, estimatedWinRate: 0.40, secsRemaining: 300 });
  assert.equal(ev29.passes, false);
  assert.equal(moneyMakerIgnoresPathGateSkip({ strategyId: "CONFLUENCE_CASCADE", path: "GRAY", reason: ev29.reason ?? "" }), false);

  const minus = evaluateEntryEVGate({
    entryPriceCents: 36, strategyWinRate: 0.40, strategyId: "CONFLUENCE_CASCADE", secsRemaining: 300,
  });
  assert.equal(minus.passes, false);

  assert.equal(moneyMakerIgnoresPathGateSkip({ strategyId: "HA_RIVER", path: "GRAY", reason: vel.reason }), false);
  assert.equal(pWinFromCurve(undefined, 36, 5), null, "missing winRateAtPrice fail-closed (no 0.65)");
  assert.ok(BOT_SRC.includes("p=winRateAtPrice missing for Kelly \u2014 skip not 065"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("moneyMakerIgnoresPathGateSkip"), "host includes (hang-safe)");
  assert.equal(PERSISTED.paperMode, true);
  assert.equal(EV_FLOOR, 3);
});

test.skip("goose veto: LATE_ENTRY_ANCHOR cannot be selectBestEnabled winner; CC/LAG still can", () => {
  const lateOnly = selectBestEnabled([{
    signal: "YES", confidence: 0.90, reason: "fx", strategyId: "LATE_ENTRY_ANCHOR",
    strategyName: "Late", earlyExitRule: "x",
  }], []);
  assert.equal(lateOnly, null, "LATE cannot place even at 0.90 with empty disabled");

  const lateOutranksCc = selectBestEnabled([
    { signal: "YES", confidence: 0.90, reason: "fx", strategyId: "LATE_ENTRY_ANCHOR", strategyName: "Late", earlyExitRule: "x" },
    { signal: "YES", confidence: 0.62, reason: "fx", strategyId: "CONFLUENCE_CASCADE", strategyName: "CC", earlyExitRule: "x" },
  ], []);
  assert.equal(lateOutranksCc?.strategyId, "CONFLUENCE_CASCADE");
  assert.notEqual(lateOutranksCc?.strategyId, "LATE_ENTRY_ANCHOR");

  const lag = selectBestEnabled([{
    signal: "YES", confidence: 0.52, reason: "fx", strategyId: "BASIS_LAG_EDGE",
    strategyName: "LAG", earlyExitRule: "x",
  }], []);
  assert.equal(lag?.strategyId, "BASIS_LAG_EDGE");

  const cc = selectBestEnabled([{
    signal: "YES", confidence: 0.62, reason: "fx", strategyId: "CONFLUENCE_CASCADE",
    strategyName: "CC", earlyExitRule: "x",
  }], []);
  assert.equal(cc?.strategyId, "CONFLUENCE_CASCADE");

  assert.equal(FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has("LATE_ENTRY_ANCHOR"), true);
  assert.equal(FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has("FLOOR_DISTANCE"), true);
  assert.equal(FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has("TICKET_WAVE"), true);
  assert.equal(FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has("LATE_MOMENTUM_CONTINUATION"), true);
  assert.equal(FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has("CONFLUENCE_CASCADE"), false);
  assert.equal(FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has("BASIS_LAG_EDGE"), false);
  assert.ok(BOT_SRC.includes("FILL_PATH_PLACE_FALSE_STRATEGY_IDS"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("boostedRaw"), "host includes (hang-safe)");
  assert.doesNotMatch(BOT_SRC, /limiter: "SIZE_RESCUE_MIN1"/);
  assert.equal(PERSISTED.paperMode, true);
  assert.equal(EV_FLOOR, 3);
});

test.skip("fill-path remake: HTF_STRUCTURE CC/LAG ignore paper=live; OVERPAY 42 ignore; 70 skip; MTF LAG YES mtf-2 keep", () => {
  for (const id of ["CONFLUENCE_CASCADE", "BASIS_LAG_EDGE"] as const) {
    assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, id, "HTF_STRUCTURE"), true, id);
    assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(false, id, "HTF_STRUCTURE"), true, `live ${id}`);
  }
  assert.equal(moneyMakerIgnoresOverpayGate("CONFLUENCE_CASCADE", 42), true);
  assert.equal(moneyMakerIgnoresOverpayGate("CONFLUENCE_CASCADE", 70), false);
  assert.equal(mtfCompositeLockAllowsSide("yes", -2, 0, 0), false);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "BASIS_LAG_EDGE", "MTF_FILTER"), false);
  assert.ok(BOT_SRC.includes("moneyMakerIgnoresOverpayGate"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("paperMoneyMakerIgnoresSettlementSideSkip"), "host includes (hang-safe)");
  assert.equal(PERSISTED.paperMode, true);
  assert.equal(EV_FLOOR, 3);
});

test.skip("proof: CC+HA_RIVER → CC; LAG+HA → LAG; HA only → HA", () => {
  const fx = (strategyId: StrategyId, signal: "YES" | "NO", confidence: number): StrategyResult => ({
    signal, confidence, reason: "fx", strategyId, strategyName: strategyId, earlyExitRule: "x",
  });
  assert.equal(selectBestEnabled([fx("HA_RIVER", "YES", 0.88), fx("CONFLUENCE_CASCADE", "YES", 0.62)], [])?.strategyId, "CONFLUENCE_CASCADE");
  assert.equal(selectBestEnabled([fx("HA_RIVER", "YES", 0.88), fx("BASIS_LAG_EDGE", "YES", 0.52)], [])?.strategyId, "BASIS_LAG_EDGE");
  // HA_RIVER alone is leftover fail-closed (never ENABLE) - null, not a solo take.
  assert.equal(selectBestEnabled([fx("HA_RIVER", "YES", 0.70)], []), null);
  assert.equal(selectBestEnabled([fx("HA_FLIP", "YES", 0.80), fx("CONFLUENCE_CASCADE", "YES", 0.62)], [])?.strategyId, "CONFLUENCE_CASCADE");
  for (const leftover of ["HA_FLIP", "TICKET_WAVE", "NO_CROSS"] as const) {
    assert.equal(HA_YIELDS_TO_MONEY_MAKER_IDS.has(leftover), true, leftover);
    assert.equal(selectBestEnabled([fx(leftover, "NO", 0.90), fx("CONFLUENCE_CASCADE", "YES", 0.62)], [])?.strategyId, "CONFLUENCE_CASCADE", leftover);
    assert.equal(selectBestEnabled([fx(leftover, "YES", 0.90), fx("BASIS_LAG_EDGE", "YES", 0.52)], [])?.strategyId, "BASIS_LAG_EDGE", leftover);
  }
  const ranked = placeableWithoutHaWhenMoneyMakerFires([
    fx("HA_RIVER", "YES", 0.88),
    fx("CONFLUENCE_CASCADE", "YES", 0.62),
  ]);
  assert.equal(ranked[0]?.strategyId, "CONFLUENCE_CASCADE");
});

test.skip("KEEP: MTF_FILTER original, ENTRY_PRICE_BAND 20/20, OVERPAY 36-52, quote_stale, LATE fail-closed; no WRITE_WINRATE_CURVE from paper n=10", () => {
  assert.equal(mtfCompositeLockAllowsSide("yes", -2, 0, 0), false);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "BASIS_LAG_EDGE", "MTF_FILTER"), false);
  assert.doesNotMatch(BOT_SRC, /ignoreMtfFilter|moneyMakerIgnoresMtfFilter/);
  assert.equal(STANDARD_ENTRY_MIN_CENTS, 20);
  assert.equal(getEntryPriceBand("CONFLUENCE_CASCADE").min, 20);
  assert.equal(getEntryPriceBand("BASIS_LAG_EDGE").min, 20);
  assert.equal(moneyMakerIgnoresOverpayGate("CONFLUENCE_CASCADE", 42), true);
  assert.equal(moneyMakerIgnoresOverpayGate("CONFLUENCE_CASCADE", 35), false);
  assert.equal(moneyMakerIgnoresOverpayGate("CONFLUENCE_CASCADE", 53), false);
  assert.equal(paperMoneyMakerIgnoresSettlementSideSkip(true, "CONFLUENCE_CASCADE", "quote_stale"), false);
  assert.equal(FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has("LATE_ENTRY_ANCHOR"), true);
  assert.equal(selectBestEnabled([{
    signal: "YES", confidence: 0.90, reason: "fx", strategyId: "LATE_ENTRY_ANCHOR",
    strategyName: "Late", earlyExitRule: "x",
  }], []), null);
  for (const leftover of ["FLOOR_DISTANCE", "TICKET_WAVE", "LATE_MOMENTUM_CONTINUATION"] as const) {
    assert.equal(FILL_PATH_PLACE_FALSE_STRATEGY_IDS.has(leftover), true, leftover);
    assert.equal(selectBestEnabled([{
      signal: "YES", confidence: 0.90, reason: "fx", strategyId: leftover,
      strategyName: leftover, earlyExitRule: "x",
    }], []), null, leftover);
  }

  assert.deepEqual([...PATH_RIDE_KELLY_STRATEGY_IDS], ["CONFLUENCE_CASCADE", "BASIS_LAG_EDGE", "HA_RIVER"]);
  assert.equal(isPathRideKellyStrategyId("HA_FLIP"), false);
  assert.equal(isPathRideKellyStrategyId("TICKET_WAVE"), false);
  assert.equal(isPathRideKellyStrategyId("NO_CROSS"), false);
  assert.ok(BOT_SRC.includes("pWin: confFloorP, netEVcents: confFloorEV"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("Real paper path: persist the p/EV skip passed from evaluate"), "host includes (hang-safe)");
  assert.doesNotMatch(BOT_SRC, /const curveP = moneyMakerSkip/);
  assert.equal(getEntryPriceBand("CONFLUENCE_CASCADE").max, 55);
  assert.equal(LEARNER_WRITE_CURVE, false);
  assert.equal(PATH_WRITE_CURVE, false);
  assert.equal(PATH_RIDE_WRITE_CURVE, false);
  assert.equal(shouldWriteWinRateCurve({ n: 10, isPaper: true }), false);
  assert.equal(shouldWriteWinRateCurve({ n: 19, isPaper: false }), false);
  assert.equal(shouldApplyLearnerWinRateAsPathP({ n: 5, isPaper: true, realBotSettlesN: 5 }), false);
  assert.equal(shouldApplyLearnerWinRateAsPathP({ n: 7, isPaper: true, realBotSettlesN: 7 }), false);
  const learnerSrc = fs.readFileSync(path.join(DIR, "strategy-learner.ts"), "utf8");
  const pathSrc = fs.readFileSync(path.join(DIR, "trade-path.ts"), "utf8");
  const pathRideSrc = fs.readFileSync(path.join(DIR, "path-ride.ts"), "utf8");
  assert.doesNotMatch(learnerSrc, /winRateAtPrice\s*=/);
  assert.doesNotMatch(pathSrc, /winRateAtPrice\s*=/);
  assert.doesNotMatch(pathRideSrc, /winRateAtPrice\s*=/);
  assert.equal(PERSISTED.paperMode, true);
  assert.equal(EV_FLOOR, 3);
});

test.skip("HA_FLIP/TICKET_WAVE/NO_CROSS yield to CC/LAG like HA_RIVER; analog live-path wired", () => {
  const fx = (strategyId: StrategyId, signal: "YES" | "NO", confidence: number): StrategyResult => ({
    signal, confidence, reason: "fx", strategyId, strategyName: strategyId, earlyExitRule: "x",
  });
  assert.equal(selectBestEnabled([fx("HA_FLIP", "YES", 0.88), fx("BASIS_LAG_EDGE", "YES", 0.52)], [])?.strategyId, "BASIS_LAG_EDGE");
  assert.equal(selectBestEnabled([fx("TICKET_WAVE", "NO", 0.80), fx("CONFLUENCE_CASCADE", "YES", 0.62)], [])?.strategyId, "CONFLUENCE_CASCADE");
  assert.equal(selectBestEnabled([fx("NO_CROSS", "NO", 0.80), fx("BASIS_LAG_EDGE", "YES", 0.52)], [])?.strategyId, "BASIS_LAG_EDGE");
  // HA_FLIP is hard-no-fill leftover — alone it must not win select/place.
  assert.equal(selectBestEnabled([fx("HA_FLIP", "YES", 0.70)], [])?.strategyId, undefined);
  assert.equal(placeableWithoutHaWhenMoneyMakerFires([
    fx("TICKET_WAVE", "YES", 0.80),
    fx("CONFLUENCE_CASCADE", "YES", 0.62),
  ])[0]?.strategyId, "CONFLUENCE_CASCADE");
  assert.ok(BOT_SRC.includes("liveOrigLagStreakOnObs"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("pWin: blendedWR"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("skipMtfFilter"), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("skip\"PATH_GATE\""), "host includes (hang-safe)");
  assert.ok(BOT_SRC.includes("skip\"MTF_FILTER\""), "host includes (hang-safe)");
  assert.equal(EV_FLOOR, 3);
  assert.equal(PERSISTED.paperMode, true);
});
