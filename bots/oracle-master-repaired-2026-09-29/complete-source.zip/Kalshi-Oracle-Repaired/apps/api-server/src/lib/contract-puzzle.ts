/**
 * contract-puzzle.ts
 *
 * Every KXBTC15M close is one puzzle: TAKE vs SKIP vs would-have-taken.
 * Includes skips the bot did not take. Shadow only.
 *
 * LOCKS
 *   liveApplyEnabled = false. paperMode stays true. Never ENABLE.
 *   Never cut EV / Kelly / 9% / 18%. Skip puzzles do NOT update
 *   bot-fill learningWeight (0.72–1.18x stays on actual fills).
 *   Teach path: jsonl → stats → shadow-learn / strategy-proposals OBSERVE
 *   → fee-net replay → bot only after human + proof.
 *
 * One row per ticker close. Quiet — no per-bar user ping.
 */
import fs from "node:fs";
import path from "node:path";
import { isKxbct15mTicker } from "./15m-product.js";
import { kalshiFeeCents, kalshiNetCostCents, kalshiNetWinCents } from "./constants.js";
import {
  computeEarlyExit,
  htfAlignedCheap,
  loadTapeQuotes,
  type HtfTapeSummary,
  type LagClass as TapeLagClass,
  type PuzzleEarlyExit,
  UNKNOWN_HTF_SUMMARY,
} from "./tick-tape-labels.js";
import { researchDir, researchPath } from "./desk-data-dir.js";

export const LIVE_APPLY_ENABLED = false as const;
export const PAPER_MODE = true as const;
/** 9% cap — used as f in G. Never cut. */
export const PUZZLE_KELLY_F = 0.09;
export const CHEAP_ASK_MIN = 7;
export const CHEAP_ASK_MAX = 22;
export const PERSIST_CHEAP_MIN = 19;
export const PERSIST_CHEAP_MAX = 22;
export const STILL_MID_MIN = 40;
export const STILL_MID_MAX = 65;
export const LOTTERY_ASK_MAX = 12;
export const LOTTERY_LAST_SECS = 150;
export const MOVING_ASK_MAX = 55;
export const MID_WINDOW_SECS_MIN = 120;
export const MID_WINDOW_SECS_MAX = 720;

export type PuzzleSide = "YES" | "NO";
export type PuzzleAction = "TAKE" | "SKIP";
export type TicketMotion = "still" | "moving" | "unknown";
export type LagClass = TapeLagClass;
export type PathClass = "MULTIPLIER" | "GRAY" | "HIGH_PROB" | "unknown";
export type { HtfTapeSummary, PuzzleEarlyExit };
export type AskBand =
  | "lottery_7_12"
  | "cheap_7_18"
  | "persist_cheap_19_22"
  | "mid_40_65"
  | "rich_gt65"
  | "other";
/** Feature cells we score as take-candidates (a row may belong to several). */
export type TakeCellId = "persist-cheap" | "lag-agree" | "moving-ticket" | "htf-aligned-cheap" | "cheap-early-exit";

export interface PuzzleFeatures {
  ticketMotion: TicketMotion;
  lagClass: LagClass;
  lagSeconds: number | null;
  lagDollars: number | null;
  pathClass: PathClass;
  askBand: AskBand;
  minutesLeft: number | null;
  secsRemaining: number | null;
  regime: string | null;
  htfStructure: HtfTapeSummary;
  /** 0–1. Null if unknown sample. Sibling of lag + HTF; not a take cell. */
  streakSaturation: number | null;
  takeCells: TakeCellId[];
}

export interface PuzzleCounterfactual {
  skipFeeNetCents: 0;
  /** Hold-to-settle fee-net of the take (actual) or would-have-taken cheap/ATM. */
  takeFeeNetCents: number | null;
  takeAskCents: number | null;
  takeSide: PuzzleSide | null;
  takeContracts: 1;
  quotesKnown: boolean;
  feeCents: number | null;
}

export interface PuzzleLabels {
  /** Chosen / would-have-taken side matched settlement. */
  sideCorrect: boolean | null;
  /** Alias of sideCorrect — settlement-side accuracy is not required for +EV. */
  settleSideCorrect: boolean | null;
  /** Skip (0) beat take fee-net (hold-to-settle). */
  skipCorrect: boolean | null;
  /** Hold-to-settle fee-net beat skip (0). Not the only +EV path. */
  takeCorrect: boolean | null;
  /** Early-exit at MFE beat skip (0). Cheap sold green can WIN with wrong settle side. */
  earlyExitCorrect: boolean | null;
}

export interface PuzzleTake {
  strategyId: string | null;
  side: PuzzleSide;
  askCents: number;
}

export interface PuzzleSkip {
  reasonCodes: string[];
  lastSignal: string | null;
}

export interface ContractPuzzle {
  kind: "contract_puzzle";
  ticker: string;
  floor: number | null;
  settled: PuzzleSide;
  botAction: PuzzleAction;
  take: PuzzleTake | null;
  skip: PuzzleSkip | null;
  counterfactual: PuzzleCounterfactual;
  features: PuzzleFeatures;
  earlyExit: PuzzleEarlyExit;
  labels: PuzzleLabels;
  liveApplyEnabled: false;
  paperMode: true;
  ts: string;
  periodOpenTs: string | null;
}

export interface PuzzleSkipMemory {
  ticker: string;
  side: "yes" | "no" | string;
  strategyId: string | null;
  rejectionCode: string;
  entryPriceCents: number | null;
  secsRemaining: number | null;
  ts: number;
  lastSignal?: string | null;
  floor?: number | null;
  lagClass?: LagClass | null;
  lagSeconds?: number | null;
  lagDollars?: number | null;
  ticketMotion?: TicketMotion | null;
  regime?: string | null;
  yesAsk?: number | null;
  noAsk?: number | null;
  htfStructure?: HtfTapeSummary | null;
  streakSaturation?: number | null;
}

export interface PuzzleTakeMemory {
  ticker: string;
  side: PuzzleSide;
  strategyId: string | null;
  askCents: number;
  secsRemaining: number | null;
  ts: number;
  lastSignal?: string | null;
  floor?: number | null;
  lagClass?: LagClass | null;
  lagSeconds?: number | null;
  lagDollars?: number | null;
  ticketMotion?: TicketMotion | null;
  regime?: string | null;
  htfStructure?: HtfTapeSummary | null;
  streakSaturation?: number | null;
}

export interface PuzzleQuotes {
  yesAsk?: number | null;
  noAsk?: number | null;
  minCheapAsk?: { side: PuzzleSide; price: number; secsRemaining?: number | null } | null;
}

export interface RecordPuzzleInput {
  ticker: string;
  settled: PuzzleSide;
  floor?: number | null;
  periodOpenTs?: Date | string | null;
  quotes?: PuzzleQuotes | null;
  regime?: string | null;
  /** Optional tick quotes for MFE / early-exit. Loaded from disk if omitted. */
  tapeQuotes?: { ts: number; yesAsk?: number | null; noAsk?: number | null; yesBid?: number | null; noBid?: number | null }[] | null;
}

function researchRoot(): string {
  return researchDir();
}

export function puzzleJsonlPath(): string {
  return process.env.CONTRACT_PUZZLE_PATH
    ?? path.join(researchRoot(), "contract-puzzles.jsonl");
}

function tapePath(): string {
  return process.env.SKIP_SETTLEMENT_TAPE_PATH
    ?? path.join(researchRoot(), "shadow-tape.jsonl");
}

const skipsByTicker = new Map<string, PuzzleSkipMemory[]>();
const takeByTicker = new Map<string, PuzzleTakeMemory>();
const recordedTickers = new Set<string>();

export function resetPuzzleForTests(): void {
  skipsByTicker.clear();
  takeByTicker.clear();
  recordedTickers.clear();
}

export function isPuzzleTicker(ticker: string | null | undefined): boolean {
  return isKxbct15mTicker(ticker);
}

export function normalizePuzzleSide(side: string | null | undefined): PuzzleSide | null {
  if (!side) return null;
  const s = side.toLowerCase();
  if (s === "yes") return "YES";
  if (s === "no") return "NO";
  return null;
}

export function classifyPathClass(askCents: number | null | undefined): PathClass {
  if (typeof askCents !== "number" || !Number.isFinite(askCents)) return "unknown";
  if (askCents <= 30) return "MULTIPLIER";
  if (askCents <= 44) return "GRAY";
  return "HIGH_PROB";
}

export function classifyAskBand(
  askCents: number | null | undefined,
  secsRemaining: number | null | undefined,
): AskBand {
  if (typeof askCents !== "number" || !Number.isFinite(askCents)) return "other";
  const secs = typeof secsRemaining === "number" && Number.isFinite(secsRemaining) ? secsRemaining : null;
  if (askCents >= CHEAP_ASK_MIN && askCents <= LOTTERY_ASK_MAX && secs != null && secs <= LOTTERY_LAST_SECS) {
    return "lottery_7_12";
  }
  if (askCents >= PERSIST_CHEAP_MIN && askCents <= PERSIST_CHEAP_MAX) return "persist_cheap_19_22";
  if (askCents >= CHEAP_ASK_MIN && askCents < PERSIST_CHEAP_MIN) return "cheap_7_18";
  if (askCents > PERSIST_CHEAP_MAX && askCents <= CHEAP_ASK_MAX) return "cheap_7_18";
  if (askCents >= STILL_MID_MIN && askCents <= STILL_MID_MAX) return "mid_40_65";
  if (askCents > 65) return "rich_gt65";
  return "other";
}

export function canonReasonCode(code: string | null | undefined): string | null {
  if (!code) return null;
  const u = code.toUpperCase().replace(/[^A-Z0-9]+/g, "_").replace(/^_|_$/g, "");
  if (!u) return null;
  if (u.includes("STILL_MID") || u.includes("STILLMID") || u === "STILL") return "STILL_MID";
  if (u.includes("LAG_STALE") || u === "LAGSTALE") return "LAG_STALE";
  if (u.includes("LAG_AGAINST") || u.includes("LAG_DISAGREE") || u.includes("LAG_DISAGREES")) return "LAG_AGAINST";
  if (u.includes("LAG_AGREE")) return "LAG_AGREE";
  if (u.includes("EV_FAIL") || u === "EV_FLOOR" || u === "EV_PRE_CHECK" || u === "OTM_EV_NO_EDGE" || u === "OTM_EV_FLOOR") {
    return "EV_FAIL";
  }
  if (u.includes("PATH_GATE")) return "PATH_GATE";
  if (u.includes("LOTTERY")) return "LOTTERY";
  if (u.includes("TIME_GATE") || u === "OUTSIDE_WINDOW") return "TIME_GATE";
  if (u.includes("FRESH_SPIKE")) return "FRESH_SPIKE";
  if (u.includes("MTF")) return "MTF_FILTER";
  if (u.includes("NO_ELIGIBLE")) return "NO_ELIGIBLE_STRATEGY";
  if (u.includes("STALE_QUOTE")) return "STALE_QUOTE";
  if (u.includes("PRICE_BUFFER")) return "PRICE_BUFFER_WARMUP";
  if (u.includes("SETTLEMENT_SIDE")) return "SETTLEMENT_SIDE";
  if (u.includes("STREAK_SAT")) return "STREAK_SATURATION";
  if (u.includes("HTF_STRUCTURE")) return "HTF_STRUCTURE";
  return u;
}

export function inferLagClass(
  codes: string[],
  explicit?: LagClass | null,
): LagClass {
  if (explicit && explicit !== "unknown") return explicit;
  if (codes.includes("LAG_STALE")) return "stale";
  if (codes.includes("LAG_AGAINST")) return "against";
  if (codes.includes("LAG_AGREE")) return "agree";
  return "unknown";
}

export function inferTicketMotion(
  codes: string[],
  askBand: AskBand,
  explicit?: TicketMotion | null,
): TicketMotion {
  if (explicit && explicit !== "unknown") return explicit;
  if (codes.includes("STILL_MID")) return "still";
  if (codes.includes("FRESH_SPIKE")) return "moving";
  if (askBand === "mid_40_65" && codes.includes("PATH_GATE")) return "still";
  return "unknown";
}

export function classifyTakeCells(opts: {
  askCents: number | null;
  secsRemaining: number | null;
  askBand: AskBand;
  lagClass: LagClass;
  ticketMotion: TicketMotion;
  takeSide?: PuzzleSide | string | null;
  htfStructure?: HtfTapeSummary | null;
}): TakeCellId[] {
  const cells: TakeCellId[] = [];
  const ask = opts.askCents;
  const secs = opts.secsRemaining;
  const midWindow = secs != null && secs >= MID_WINDOW_SECS_MIN && secs <= MID_WINDOW_SECS_MAX;
  const notLottery = opts.askBand !== "lottery_7_12";
  if (
    notLottery
    && typeof ask === "number"
    && ask >= PERSIST_CHEAP_MIN
    && ask <= PERSIST_CHEAP_MAX
    && (midWindow || secs == null)
  ) {
    cells.push("persist-cheap");
  }
  if (opts.lagClass === "agree") cells.push("lag-agree");
  if (
    opts.ticketMotion === "moving"
    && typeof ask === "number"
    && ask >= CHEAP_ASK_MIN
    && ask <= MOVING_ASK_MAX
  ) {
    cells.push("moving-ticket");
  }
  if (htfAlignedCheap({
    askCents: ask,
    takeSide: normalizePuzzleSide(opts.takeSide ?? null),
    biasFor15m: opts.htfStructure?.biasFor15m ?? "UNKNOWN",
    cheapMin: CHEAP_ASK_MIN,
    cheapMax: CHEAP_ASK_MAX,
  })) {
    cells.push("htf-aligned-cheap");
  }
  // Snapshot 7–22 in window. Live 15s persist is the replay cell, not this label.
  if (
    notLottery
    && typeof ask === "number"
    && ask >= CHEAP_ASK_MIN
    && ask <= CHEAP_ASK_MAX
    && (midWindow || secs == null)
  ) {
    cells.push("cheap-early-exit");
  }
  return cells;
}

/**
 * Hold-to-settlement fee-net for 1 contract. No invented slippage.
 * Win: (100 - ask) - fee. Loss: -ask - fee. Skip: 0.
 */
export function holdToSettleFeeNetCents(
  askCents: number | null | undefined,
  side: PuzzleSide | string | null | undefined,
  settled: PuzzleSide,
): number | null {
  if (typeof askCents !== "number" || !Number.isFinite(askCents)) return null;
  if (askCents <= 0 || askCents >= 100) return null;
  const n = normalizePuzzleSide(typeof side === "string" ? side : side);
  if (!n) return null;
  const fee = kalshiFeeCents(askCents);
  const won = n === settled;
  return won ? (100 - askCents) - fee : -askCents - fee;
}

export function puzzleLabels(
  takeFeeNetCents: number | null,
  takeSide: PuzzleSide | null,
  settled: PuzzleSide,
  earlyExitPnLCents?: number | null,
): PuzzleLabels {
  const sideCorrect = takeSide == null ? null : takeSide === settled;
  const earlyExitCorrect = earlyExitPnLCents == null ? null : earlyExitPnLCents > 0;
  if (takeFeeNetCents == null) {
    return { sideCorrect, settleSideCorrect: sideCorrect, skipCorrect: null, takeCorrect: null, earlyExitCorrect };
  }
  return {
    sideCorrect,
    settleSideCorrect: sideCorrect,
    skipCorrect: 0 > takeFeeNetCents,
    takeCorrect: takeFeeNetCents > 0,
    earlyExitCorrect,
  };
}

/** Kelly-style log growth of one hold-to-settle binary. f = 0.09, never cut. */
export function logGrowthNats(askCents: number, won: boolean, f = PUZZLE_KELLY_F): number | null {
  const stake = kalshiNetCostCents(askCents);
  if (!(stake > 0) || !Number.isFinite(stake)) return null;
  const x = won ? kalshiNetWinCents(askCents) / stake : -1;
  const r = 1 + f * x;
  if (!(r > 0) || !Number.isFinite(r)) return Number.NEGATIVE_INFINITY;
  return Math.log(r);
}

export function logGrowthFromFeeNet(askCents: number, feeNetCents: number, f = PUZZLE_KELLY_F): number | null {
  const stake = kalshiNetCostCents(askCents);
  if (!(stake > 0) || !Number.isFinite(stake)) return null;
  const x = feeNetCents / stake;
  const r = 1 + f * x;
  if (!(r > 0) || !Number.isFinite(r)) return Number.NEGATIVE_INFINITY;
  return Math.log(r);
}

function validAsk(cents: number | null | undefined): cents is number {
  return typeof cents === "number" && Number.isFinite(cents) && cents > 0 && cents < 100;
}

function finiteSat(n: number | null | undefined): number | null {
  return typeof n === "number" && Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : null;
}

export function pickWouldTake(
  skips: PuzzleSkipMemory[],
  quotes?: PuzzleQuotes | null,
): { side: PuzzleSide; askCents: number; secsRemaining: number | null } | null {
  if (quotes?.minCheapAsk && validAsk(quotes.minCheapAsk.price)) {
    return {
      side: quotes.minCheapAsk.side,
      askCents: quotes.minCheapAsk.price,
      secsRemaining: quotes.minCheapAsk.secsRemaining ?? null,
    };
  }
  const y = quotes?.yesAsk;
  const n = quotes?.noAsk;
  const cheapY = validAsk(y) && y >= CHEAP_ASK_MIN && y <= CHEAP_ASK_MAX;
  const cheapN = validAsk(n) && n >= CHEAP_ASK_MIN && n <= CHEAP_ASK_MAX;
  if (cheapY && cheapN) return y! <= n! ? { side: "YES", askCents: y!, secsRemaining: null } : { side: "NO", askCents: n!, secsRemaining: null };
  if (cheapY) return { side: "YES", askCents: y!, secsRemaining: null };
  if (cheapN) return { side: "NO", askCents: n!, secsRemaining: null };
  if (validAsk(y) && validAsk(n)) {
    return y! <= n! ? { side: "YES", askCents: y!, secsRemaining: null } : { side: "NO", askCents: n!, secsRemaining: null };
  }
  if (validAsk(y)) return { side: "YES", askCents: y, secsRemaining: null };
  if (validAsk(n)) return { side: "NO", askCents: n, secsRemaining: null };

  const priced = skips
    .map(s => ({ side: normalizePuzzleSide(s.side), ask: s.entryPriceCents, secs: s.secsRemaining ?? null }))
    .filter((s): s is { side: PuzzleSide; ask: number; secs: number | null } => s.side != null && validAsk(s.ask));
  if (priced.length === 0) return null;
  const cheap = priced.filter(s => s.ask >= CHEAP_ASK_MIN && s.ask <= CHEAP_ASK_MAX);
  const pool = cheap.length > 0 ? cheap : priced;
  pool.sort((a, b) => a.ask - b.ask);
  return { side: pool[0]!.side, askCents: pool[0]!.ask, secsRemaining: pool[0]!.secs };
}

function uniqueCodes(skips: PuzzleSkipMemory[]): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const s of skips) {
    const c = canonReasonCode(s.rejectionCode);
    if (c && !seen.has(c)) {
      seen.add(c);
      out.push(c);
    }
  }
  return out;
}

function lastOf<T>(arr: T[]): T | undefined {
  return arr.length > 0 ? arr[arr.length - 1] : undefined;
}

export function rememberPuzzleSkip(skip: PuzzleSkipMemory): void {
  try {
    if (!isPuzzleTicker(skip.ticker)) return;
    const list = skipsByTicker.get(skip.ticker) ?? [];
    list.push(skip);
    if (list.length > 400) list.splice(0, list.length - 400);
    skipsByTicker.set(skip.ticker, list);
  } catch {
    // Observational only.
  }
}

export function rememberPuzzleTake(take: PuzzleTakeMemory): void {
  try {
    if (!isPuzzleTicker(take.ticker)) return;
    const side = normalizePuzzleSide(take.side) ?? take.side;
    if (side !== "YES" && side !== "NO") return;
    if (!validAsk(take.askCents)) return;
    takeByTicker.set(take.ticker, { ...take, side });
  } catch {
    // Observational only — never abort placeOrder.
  }
}

export function peekPuzzleSkips(ticker: string): PuzzleSkipMemory[] {
  return skipsByTicker.get(ticker) ?? [];
}

export function peekPuzzleTake(ticker: string): PuzzleTakeMemory | undefined {
  return takeByTicker.get(ticker);
}

function featuresFor(
  askCents: number | null,
  secsRemaining: number | null,
  codes: string[],
  lagExplicit: LagClass | null | undefined,
  motionExplicit: TicketMotion | null | undefined,
  regime: string | null | undefined,
  extra?: {
    lagSeconds?: number | null;
    lagDollars?: number | null;
    htfStructure?: HtfTapeSummary | null;
    takeSide?: PuzzleSide | null;
    streakSaturation?: number | null;
  },
): PuzzleFeatures {
  const askBand = classifyAskBand(askCents, secsRemaining);
  const lagClass = inferLagClass(codes, lagExplicit);
  const ticketMotion = inferTicketMotion(codes, askBand, motionExplicit);
  const minutesLeft = secsRemaining != null && Number.isFinite(secsRemaining)
    ? Math.round((secsRemaining / 60) * 10) / 10
    : null;
  const htfStructure = extra?.htfStructure && extra.htfStructure.biasFor15m
    ? extra.htfStructure
    : { ...UNKNOWN_HTF_SUMMARY };
  return {
    ticketMotion,
    lagClass,
    lagSeconds: extra?.lagSeconds ?? null,
    lagDollars: extra?.lagDollars ?? null,
    pathClass: classifyPathClass(askCents),
    askBand,
    minutesLeft,
    secsRemaining: secsRemaining ?? null,
    regime: regime ?? null,
    htfStructure,
    streakSaturation: finiteSat(extra?.streakSaturation),
    takeCells: classifyTakeCells({
      askCents, secsRemaining, askBand, lagClass, ticketMotion,
      takeSide: extra?.takeSide ?? null,
      htfStructure,
    }),
  };
}

export function buildContractPuzzle(input: RecordPuzzleInput): ContractPuzzle | null {
  if (!isPuzzleTicker(input.ticker)) return null;
  if (input.settled !== "YES" && input.settled !== "NO") return null;

  const skips = skipsByTicker.get(input.ticker) ?? [];
  const takeMem = takeByTicker.get(input.ticker);
  const codes = uniqueCodes(skips);
  const lastSkip = lastOf(skips);
  const lastSignal = takeMem?.lastSignal ?? lastSkip?.lastSignal ?? lastSkip?.rejectionCode ?? null;
  const regime = input.regime ?? takeMem?.regime ?? lastSkip?.regime ?? null;
  const floor = input.floor ?? takeMem?.floor ?? lastSkip?.floor ?? null;

  let botAction: PuzzleAction = "SKIP";
  let take: PuzzleTake | null = null;
  let cfSide: PuzzleSide | null = null;
  let cfAsk: number | null = null;
  let cfSecs: number | null = null;

  if (takeMem) {
    botAction = "TAKE";
    take = { strategyId: takeMem.strategyId, side: takeMem.side, askCents: takeMem.askCents };
    cfSide = takeMem.side;
    cfAsk = takeMem.askCents;
    cfSecs = takeMem.secsRemaining ?? null;
  } else {
    const would = pickWouldTake(skips, input.quotes ?? null);
    if (would) {
      cfSide = would.side;
      cfAsk = would.askCents;
      cfSecs = would.secsRemaining;
    }
  }

  const takeFeeNetCents = holdToSettleFeeNetCents(cfAsk, cfSide, input.settled);
  const feeCents = validAsk(cfAsk) ? kalshiFeeCents(cfAsk) : null;
  const secs = cfSecs ?? lastSkip?.secsRemaining ?? null;
  const htfStructure = takeMem?.htfStructure ?? lastSkip?.htfStructure ?? null;
  const features = featuresFor(
    cfAsk,
    secs,
    codes,
    takeMem?.lagClass ?? lastSkip?.lagClass,
    takeMem?.ticketMotion ?? lastSkip?.ticketMotion,
    regime,
    {
      lagSeconds: takeMem?.lagSeconds ?? lastSkip?.lagSeconds ?? null,
      lagDollars: takeMem?.lagDollars ?? lastSkip?.lagDollars ?? null,
      htfStructure,
      takeSide: cfSide,
      streakSaturation: takeMem?.streakSaturation ?? lastSkip?.streakSaturation ?? null,
    },
  );

  const tapeQuotes = input.tapeQuotes ?? loadTapeQuotes(input.ticker);
  const entryTs = takeMem?.ts ?? lastSkip?.ts ?? null;
  const earlyExit = computeEarlyExit({
    entryAsk: cfAsk,
    takeSide: cfSide,
    settled: input.settled,
    entryTs,
    quotes: tapeQuotes,
  });

  const periodOpenTs = input.periodOpenTs
    ? (input.periodOpenTs instanceof Date ? input.periodOpenTs.toISOString() : String(input.periodOpenTs))
    : null;

  return {
    kind: "contract_puzzle",
    ticker: input.ticker,
    floor: typeof floor === "number" && Number.isFinite(floor) ? floor : null,
    settled: input.settled,
    botAction,
    take,
    skip: botAction === "SKIP" || codes.length > 0
      ? { reasonCodes: codes, lastSignal }
      : null,
    counterfactual: {
      skipFeeNetCents: 0,
      takeFeeNetCents,
      takeAskCents: cfAsk,
      takeSide: cfSide,
      takeContracts: 1,
      quotesKnown: takeFeeNetCents != null,
      feeCents,
    },
    features,
    earlyExit,
    labels: puzzleLabels(takeFeeNetCents, cfSide, input.settled, earlyExit.earlyExitPnLAtMfeCents),
    liveApplyEnabled: false,
    paperMode: true,
    ts: new Date().toISOString(),
    periodOpenTs,
  };
}

function appendJsonl(file: string, row: object): void {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.appendFileSync(file, JSON.stringify(row) + "\n");
  } catch (err) {
    console.warn("[contract-puzzle] append failed:", file, (err as Error).message);
  }
}

/**
 * Record one puzzle for a settled KXBTC15M ticker. Idempotent per ticker.
 * Quiet — no user ping. Never throws into the settlement path.
 */
export function recordPuzzleOnSettlement(input: RecordPuzzleInput): ContractPuzzle | null {
  try {
    if (!isPuzzleTicker(input.ticker)) return null;
    if (recordedTickers.has(input.ticker)) return null;
    const row = buildContractPuzzle(input);
    if (!row) return null;
    recordedTickers.add(input.ticker);
    appendJsonl(puzzleJsonlPath(), row);
    try {
      appendJsonl(tapePath(), row);
    } catch {
      // Dedicated jsonl is the source of truth.
    }
    return row;
  } catch (err) {
    console.warn("[contract-puzzle] record failed:", (err as Error).message);
    return null;
  }
}

export function puzzleAlreadyRecorded(ticker: string): boolean {
  return recordedTickers.has(ticker);
}

export function markPuzzleRecordedForTests(ticker: string): void {
  recordedTickers.add(ticker);
}

export function readPuzzleJsonl(file?: string): ContractPuzzle[] {
  const p = file ?? puzzleJsonlPath();
  try {
    if (!fs.existsSync(p)) return [];
    return fs.readFileSync(p, "utf8").trim().split("\n").filter(Boolean).map(l => JSON.parse(l) as ContractPuzzle);
  } catch {
    return [];
  }
}
