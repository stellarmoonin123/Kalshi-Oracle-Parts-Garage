import { installFatalProcessHandlers } from "./lib/fatal-process.js";
import app from "./app";
import { logger } from "./lib/logger";
import { kalshiWS } from "./lib/kalshi-ws.js";
import { coinbaseBtcLead } from "./lib/coinbase-btc-lead.js";
import { incidentStore } from "./lib/incident-store.js";
import { watchdog } from "./lib/watchdog.js";
import { warnOnIncompatibleEnvPrivateKey } from "./lib/startup-key-guard.js";
import { startModelUpdater } from "./lib/model-updater.js";
import { mtfAnalyzer } from "./lib/mtf-analyzer.js";
import { candlePatternAnalyzer } from "./lib/candlestick-patterns.js";
import { startMarketLearning } from "./lib/market-learning.js";
import { settlementPredictor } from "./lib/settlement-predictor.js";
import { predictionLearner } from "./lib/prediction-learner.js";
import { reconcileAgainstTradeLog } from "./lib/strategy-learner.js";
import { db, botTrades } from "@workspace/db";
import { sql } from "drizzle-orm";
import { hydrateStrategyPerformanceCache, refreshAllStrategyPerformance } from "./lib/strategy-performance.js";
import { refreshRegimeEVStats } from "./lib/regime-ev-stats.js";
import { loadAriaLessons } from "./lib/aria-lessons-store.js";
import { adaptFromRecentVerdicts } from "./lib/online-adapter.js";
import { warmVolumeRiskCache } from "./lib/volume-risk.js";
import { getAllStrategyMeta } from "./lib/strategy-library.js";
import { makeGuarded } from "./lib/async-guard.js";
import { recoverStuckDiagnoses } from "./lib/self-healing.js";
import { perpsMarketData } from "./lib/perps/market-data.js";
import { tradingBot } from "./lib/trading-bot.js";
import { FROZEN_CC_RULESET_VERSION, runningGitSha } from "./lib/frozen-cc.js";
import { botUptimeLog } from "./lib/bot-uptime-log.js";
import { pruneOldDiagnosticRuns } from "./lib/system-diagnostics.js";
import { runAutopilotCycle } from "./lib/autopilot-monitor.js";
import { startShadowLearnerScheduler } from "./lib/shadow-learner.js";
import { startOrganDebugScheduler } from "./lib/organ-debug/index.js";
import { runPolicyRegression, hasPolicyRelevantCommitsSince, getCurrentGitSha } from "./lib/backtest-lab-v5/regression-runner.js";
import { getLatestSnapshot } from "./lib/backtest-lab-v5/policy-snapshot.js";
import cron from "node-cron";
import { runAccountsMigration } from "./lib/accounts/migrate.js";
import { bootstrapAdminFromEnv } from "./lib/accounts/bootstrap.js";
import { archiveOldTickFiles } from "./lib/tick-archive.js";
import { ticksDir as researchTicksArchiveDir } from "./lib/tick-tape-labels.js";

// Fatal errors leave process state unknown. Exit synchronously for supervisor recovery.
installFatalProcessHandlers();

// ── Graceful shutdown ────────────────────────────────────────────────────────
// Root-cause fix: a live position open at the moment of a restart (deploy,
// crash-loop respawn, or a routine dev-verification restart) previously had
// no shutdown handling at all — Node's default SIGTERM/SIGINT behavior is to
// terminate immediately, so the position rode blind to settlement with every
// active risk control (stop-loss, thesis-break, trailing stop, ARIA gated
// exit) disabled for as long as the process was down. A DB audit found this
// ("STARTUP_RECOVERY" exit reason) behind roughly half of recent losing
// trades. supervisor.mjs gives the child ~10s after forwarding the signal
// before it force-exits, so this budgets 8s for one best-effort close
// attempt (tradingBot.attemptGracefulShutdownClose is itself internally
// try/caught and never throws) and always exits 0 afterward — if the attempt
// doesn't finish in time, the position simply holds to settlement exactly as
// it always has; this can only improve on that baseline, never regress it.
//
// 2026-08-14 follow-up: a DB audit found this had NEVER once succeeded
// (0 of 77 restart-during-open-trade events) — the original 2.5s budget was
// too short for a real Kalshi order round-trip, which can legitimately need
// up to ~8-9s worst case (exitEarly's own two-attempt retry-with-wider-sweep
// logic, each attempt with a 4s request timeout). Widened to 8s to "fit"
// that estimate.
//
// 2026-08-16 follow-up: STILL 0 real-world successes after the 8s widening
// (0 of 5 new restart-during-open-trade events since the prior fix landed).
// Root cause: the "~8-9s worst case" was an estimate of exitEarly()'s own
// retry loop, but its structural FLOOR is already 8.0s the moment a retry
// fires (2 attempts x AbortSignal.timeout(4_000), back-to-back, before any
// DB write) — an 8.0s race deadline has zero margin over an 8.0s floor, so
// it loses (or ties, which still means process.exit(0) fires before the
// trailing recordSettlement() DB write completes) on essentially every
// retried exit. Widened again with real headroom instead of an exact match.
//
// 2026-08-22 follow-up: a DB audit found this had STILL never once
// succeeded (0 of 82 restart-during-open-trade events), even past the 10.5s
// widening above — because widening the outer deadline was never going to
// be enough on its own. The real floor was worse than the 8.0s estimate:
// exitEarly()'s pre-exit Kalshi position check alone can take up to 8s (2
// retries x 4s timeout) BEFORE the order-placement/poll loop even starts,
// and for a stop-type reason (which SHUTDOWN_GRACEFUL_CLOSE is) that loop
// itself retries once more on rejection — a realistic worst case well past
// 15s, no matter how generous this deadline is. The actual fix is in
// exitEarly() itself: SHUTDOWN_GRACEFUL_CLOSE now forces a single attempt
// (no retry — there's no next tick to retry on during shutdown anyway) and
// uses tightened timeouts on the position pre-check and fill poll, both of
// which fail open/unconfirmed rather than incorrectly, bringing the
// realistic worst case down to roughly 9-9.5s. This deadline is widened
// slightly further (10.5s → 12s) purely as headroom on top of that fix, not
// as the fix itself — do not "solve" a future recurrence by widening this
// number again without first re-checking exitEarly()'s actual attempt cost.
let shuttingDown = false;
function gracefulShutdown(signal: string) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.warn({ signal }, "[shutdown] Signal received — attempting graceful position close before exit");
  try {
    botUptimeLog.onProcessStop({
      state: tradingBot.state,
      enabled: tradingBot.config.enabled === true,
      paperMode: tradingBot.config.paperMode === true,
      reason: signal,
    });
  } catch (err) {
    logger.warn({ err }, "[shutdown] uptime process_stop log failed");
  }
  const deadline = new Promise<void>(resolve => setTimeout(resolve, 12_000));
  Promise.race([tradingBot.attemptGracefulShutdownClose(), deadline])
    .catch(err => logger.warn({ err }, "[shutdown] Graceful close attempt threw unexpectedly"))
    .finally(() => process.exit(0));
}
process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT",  () => gracefulShutdown("SIGINT"));

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// Initialise incident store BEFORE binding the server so any restored open
// incidents from a previous session are in memory before the first health
// request arrives.
await incidentStore.init();
logger.info("Incident store initialised");

// Recover any self-healing diagnoses left stuck mid-flight by a crash of a
// prior process instance (e.g. supervisor.mjs respawn) — see self-healing.ts.
void recoverStuckDiagnoses().catch(err => logger.warn({ err }, "[self-healing] startup recovery failed"));

// 2026-08-17: a unit-test process (strategy-performance.live-only.test.ts)
// that got killed mid-run (e.g. a workflow restart landing between its
// inserts and its own t.after(cleanup)) once left disposable test fixture
// rows — ticker='TEST-TICKER', a 'ZZZ_TEST%' strategyId — sitting in the
// LIVE bot_trades table. Nothing downstream filters test fixtures out
// (getRecentTrades/getTradeCount return every row unfiltered), so those 5
// fake trades rendered directly in the mobile Live Trades feed as if they
// were real. Tests write directly to the same DB as production (no isolated
// test schema), so a killed test process is the one failure mode no
// per-test cleanup can guard against. This sweep is the startup-recovery
// backstop: it runs before anything reads bot_trades, so a crash-interrupted
// test run is invisible by the time the app can show or count it. A real
// Kalshi ticker can never equal the literal 'TEST-TICKER', and no real
// strategyId is ever 'ZZZ_TEST%' — both patterns are exclusively test
// fixtures, so this can only ever delete disposable rows.
try {
  const swept = await db.delete(botTrades)
    .where(sql`${botTrades.ticker} = 'TEST-TICKER' or ${botTrades.strategyId} like 'ZZZ_TEST%'`)
    .returning({ id: botTrades.id });
  if (swept.length > 0) {
    logger.warn({ count: swept.length, ids: swept.map(r => r.id) },
      "[startup-sweep] removed orphaned test-fixture rows from bot_trades (a prior test run was likely interrupted before its own cleanup ran)");
  }
} catch (err) {
  logger.warn({ err }, "[startup-sweep] test-fixture cleanup failed (non-fatal) — continuing boot");
}

// Hydrate the DB-backed strategy-performance cache BEFORE the tick loop can
// run — the live gate (isStrategyEnabledSync / getDbDisabledStrategies) reads
// this cache synchronously and must not silently default every strategy to
// "enabled" for an extended startup window.
await hydrateStrategyPerformanceCache();

// GO — VOLUME AS RISK SCALAR (2026-08-18): pre-load learned volume-bucket
// multipliers so the live sizing path doesn't run its first post-restart
// tick cold (all-1.0). Read-only warmup — failure just means it starts at
// 1.0 for this process lifetime and self-heals on the next learn write.
await warmVolumeRiskCache();

// Boot gate fix (strategy-perf-quarantine review, 2026-08-17): the live gate
// (isStrategyEnabledSync) now fails CLOSED — every strategy blocked — until
// this live-only recompute completes at least once. This used to fire
// un-awaited inside the app.listen() callback below, so the server could
// start accepting live trades on cache rows restored verbatim from disk
// (potentially still reflecting stale pooled paper+live history) for a
// window after boot. Awaiting it here, before listen(), closes that window;
// a failure here leaves every strategy disabled until the periodic sweep
// (started after listen()) succeeds — never silently "default to enabled".
try {
  await refreshAllStrategyPerformance(getAllStrategyMeta().map(s => s.id));
} catch (err) {
  logger.error({ err }, "[strategy-performance] boot-time live-only recompute failed — all strategies remain DISABLED (fail-closed) until the next successful sweep");
}

// Hydrate the empirical strategyId×regime EV stats cache (regime-ev-stats.ts)
// before the tick loop can run — scoreStrategyEV reads it synchronously.
await refreshRegimeEVStats().catch(err =>
  logger.warn({ err }, "[regime-ev-stats] initial hydration failed — adjustments default to 0 until next sweep"));

// Hydrate ARIA's persistent lessons cache before its loop starts, so the
// very first cycle's prompt already includes everything learned in prior
// sessions rather than starting blank until the next successful write.
await loadAriaLessons();

// ── PKCS#1 guard — check env-var key format at startup ────────────────────
// A PKCS#1 key in the env secret will cause a cryptic RSA error on the first
// signing attempt. Detect it early and log a prominent warning so operators
// can fix it before live trading starts.
warnOnIncompatibleEnvPrivateKey((message) => logger.warn(message));

// ── Multi-user accounts: idempotent schema/legacy-chat migration + optional
// first-ADMIN bootstrap from ORACLE_ADMIN_* env. Never touches trading state.
// On failure the API stays default-deny (every protected route answers 401).
try {
  const boot = await bootstrapAdminFromEnv();
  const mig = await runAccountsMigration();
  logger.info({
    adminBootstrap: boot.created ? { created: true, username: boot.username } : boot,
    chatBackupCreated: mig.backupCreated,
    legacyConversationsAssigned: mig.legacyAssigned,
    unownedConversations: mig.unownedRemaining,
  }, "[accounts] ready");
  if (mig.unownedRemaining > 0) {
    logger.warn("[accounts] no ADMIN yet — legacy conversations stay hidden until the first ADMIN is bootstrapped");
  }
} catch (err) {
  logger.error({ err: (err as Error)?.message }, "[accounts] migration/bootstrap failed — sign-in unavailable, API stays locked");
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Process honesty: which code is actually running, and in which mode.
  logger.info({
    gitSha: runningGitSha(),
    frozenCcMode: tradingBot.config.frozenCcMode === true,
    paperMode: tradingBot.config.paperMode,
    ruleset: tradingBot.config.frozenCcMode === true ? FROZEN_CC_RULESET_VERSION : "legacy",
    askDoor: tradingBot.config.frozenCcMode === true ? "20-55" : "legacy",
  }, "Build identity");

  kalshiWS.start();
  logger.info("Kalshi WebSocket manager started");

  coinbaseBtcLead.start();
  logger.info("Coinbase BTC-USD public lead started (declared lag lead=coinbase; Binance 451 here)");

  // Start MTF analyzer at server boot (not just when the bot starts) so the
  // multi-timeframe bias signal is ready before the first trade evaluation.
  mtfAnalyzer.start();
  logger.info("MTF analyzer started");

  // Candlestick pattern analyzer (Sakata Goho / Homma) — real 1m OHLC polled
  // every 60s, feeds the SAKATA_CANDLE_PATTERN strategy's obs.candlePattern.
  candlePatternAnalyzer.start();
  logger.info("Candlestick pattern analyzer started");

  // Market-wide learning (Plane R) — studies every 15m KXBTC contract's
  // settlement, not just ones the bot trades. See market-learning.ts.
  startMarketLearning();
  logger.info("Market-wide learning started — recording + base-rate cache refresh");

  watchdog.start();
  logger.info("Watchdog started");

  // BTC Perpetual Futures market data — fully independent of the binary
  // 15-min/1H tick loop above. Read-only polling only; see lib/perps/README.md.
  perpsMarketData.start();
  logger.info("Perps (BTC perpetual futures) market data polling started");

  startModelUpdater();
  logger.info("Model updater started — daily probe scheduled at 06:00 ET");

  // Profit Doctrine Phase 7 — Shadow Learner. Read-only, propose-only; own
  // 15-minute timer, fully decoupled from the trading tick. See
  // lib/shadow-learner.ts's header for the full non-negotiable list of what
  // it must never write.
  startShadowLearnerScheduler();
  logger.info("Shadow learner started — read-only proposals every 15m, autoMode stays false");

  settlementPredictor.start();
  logger.info("Settlement predictor started — AI settlement call every 90s");

  // Periodic full strategy-performance sweep (every 15 min) — catches
  // performance decay even during a quiet market with no fresh settlements.
  // Event-driven refresh (onTradeSettled) still fires immediately per trade;
  // this is just the backstop.
  const guardedPerfSweep = makeGuarded(
    async () => refreshAllStrategyPerformance(getAllStrategyMeta().map(s => s.id)),
    (err) => logger.warn({ err }, "[strategy-performance] periodic sweep failed"),
  );
  setInterval(guardedPerfSweep, 15 * 60 * 1000);
  guardedPerfSweep().catch(() => {}); // prime the cache once at boot, don't block listen()

  // Periodic empirical regime×strategy EV stats sweep — same 15 min cadence
  // as the strategy-performance sweep above. Also refreshed event-driven on
  // every settlement (see onTradeSettledForPerformance call site).
  const guardedRegimeEVSweep = makeGuarded(
    refreshRegimeEVStats,
    (err) => logger.warn({ err }, "[regime-ev-stats] periodic sweep failed"),
  );
  setInterval(guardedRegimeEVSweep, 15 * 60 * 1000);

  // Online adapter — slow, sample-gated confMultiplier/sizeMultiplier
  // adaptation from sim_verdicts hit-rate. Hourly, matching model-updater.ts's
  // scheduling pattern. Never touches the `enabled` flag (see online-adapter.ts).
  cron.schedule("0 * * * *", () => {
    adaptFromRecentVerdicts().catch(err => logger.warn({ err }, "[online-adapter] hourly run failed"));
  });
  logger.info("Online adapter scheduled — hourly confidence/size multiplier sweep");

  // Diagnostics history prune only. The Replit-shaped hourly sweep that
  // spawned the full test suite as a child process is not part of this remake.
  cron.schedule("30 3 * * *", () => {
    pruneOldDiagnosticRuns().catch(err => logger.warn({ err }, "[system-diagnostics] prune failed"));
  });

  // Ops 2026-09-26: gzip research/ticks files older than 7 days into
  // ticks/archive/ (no deletion; readers fall back to the archive). Bounds
  // ~43 MB/day of raw tick tape on the 3 GB desk volume.
  const runTickArchive = () => {
    try {
      const r = archiveOldTickFiles({ dir: researchTicksArchiveDir() });
      if (r.archived || r.errors) logger.info(r, "[tick-archive] archived old tick files");
    } catch (err) {
      logger.warn({ err }, "[tick-archive] run failed");
    }
  };
  cron.schedule("45 3 * * *", runTickArchive);
  setTimeout(runTickArchive, 10 * 60 * 1000);

  // GO — AUTOPILOT MONITOR (read-only + alerts, no silent mutations): hourly
  // health-check report (mode/regime/packs/skips/orders/anomalies/fee-net),
  // persisted to a rolling snapshot + logged ALERTs. Offset 20 min past the
  // hour to avoid piling onto the :00/:10 sweeps above. See
  // autopilot-monitor.ts's header for the exact scope contract (never
  // touches EV floors/packs/strategy enables/size caps).
  cron.schedule("20 * * * *", () => {
    runAutopilotCycle().catch(err => logger.warn({ err }, "[autopilot-monitor] scheduled cycle failed"));
  });
  logger.info("Autopilot monitor scheduled — hourly read-only health report + alerts (no mutations)");

  // GO — BACKTEST LAB v5 + CONTINUOUS POLICY REGRESSION (2026-08-22): scheduled
  // trigger, rate-limited to at most once per 6h by only firing on the :00
  // hour when (hour % 6 === 0), AND only when a policy-relevant file changed
  // since the last saved LEAN snapshot (see POLICY_RELEVANT_PATHS). Never
  // writes to live bot config — see regression-runner.ts's module doc for the
  // hard contract. A missing git repo/history fails this check closed
  // (no trigger), not open.
  cron.schedule("0 */6 * * *", () => {
    (async () => {
      const priorLean = await getLatestSnapshot('LEAN');
      const sinceSha = priorLean?.gitSha ?? null;
      if (!hasPolicyRelevantCommitsSince(sinceSha)) {
        logger.info("[policy-regression] scheduled 6h check: no policy-relevant commits since last snapshot — skipping run");
        return;
      }
      const result = await runPolicyRegression(`scheduled-6h (sha ${getCurrentGitSha() ?? 'n/a'})`);
      logger.info({ outcome: result.outcome, reasons: result.reasons, reportPath: result.reportPath }, "[policy-regression] scheduled run complete");
      if (result.outcome === 'WARN') {
        logger.warn({ reasons: result.reasons }, "[policy-regression] WARN — LEAN policy regressed vs its prior baseline (report-only, live config untouched)");
      }
    })().catch(err => logger.warn({ err }, "[policy-regression] scheduled run failed"));
  });
  logger.info("Policy regression scheduled — every 6h, gated on policy-relevant commits since the last LEAN snapshot");

  // GO — ORGAN SYSTEM DEBUG: organ-by-organ money-path diagnose (boot + every 6h).
  // Floors-safe only — never cuts EV/Kelly, never paperMode false, never ENABLE,
  // never auto-bounce. See lib/organ-debug/ and docs/organ-system-debug.md.
  startOrganDebugScheduler();

  // Recovery sweep: resolve any predictions/verdicts left pending by a restart
  // across a period boundary, using recorded btc_periods settlements.
  predictionLearner.resolvePendingFromRecordedPeriods()
    .catch(err => logger.warn({ err }, "Prediction startup sweep failed"));

  // Reconcile the strategy-learning JSON store against bot_trades (the
  // source of truth). The two are separate write paths and can drift —
  // any learning record with trades > 0 but zero matching settled rows in
  // bot_trades is unverifiable and gets reset to neutral so it stops
  // silently steering live strategy confidence. See strategy-learner.ts.
  (async () => {
    try {
      const rows = await db
        .select({ strategyId: botTrades.strategyId, count: sql<number>`count(*)::int` })
        .from(botTrades)
        .where(sql`${botTrades.strategyId} is not null and ${botTrades.outcome} in ('win', 'loss')`)
        .groupBy(botTrades.strategyId);
      const dbCounts: Record<string, number> = {};
      for (const r of rows) {
        if (r.strategyId) dbCounts[r.strategyId] = r.count;
      }
      const results = reconcileAgainstTradeLog(dbCounts);
      const reset = results.filter(r => r.action === "reset");
      const flagged = results.filter(r => r.action === "flagged");
      if (reset.length > 0) {
        logger.warn({ reset }, `[strategy-learner] Reset ${reset.length} phantom learning record(s) with no DB-backed trades`);
      }
      if (flagged.length > 0) {
        logger.info({ flagged }, `[strategy-learner] ${flagged.length} record(s) have more store trades than DB rows (likely legacy pre-tracking trades) — left untouched`);
      }
    } catch (err) {
      logger.warn({ err }, "[strategy-learner] Startup reconciliation against bot_trades failed");
    }
  })();
});
