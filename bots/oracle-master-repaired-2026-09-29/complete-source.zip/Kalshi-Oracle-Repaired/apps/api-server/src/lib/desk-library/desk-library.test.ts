/** QUARANTINE(P2): desk-library research theater */
/**
 * desk-library.test.ts
 *
 * Shadow 15m desk. Does not import TradingBot.evaluate.
 * LIVE_APPLY stays false. Never ENABLE_STRATEGY. Never CHANGE_EV_FLOOR.
 * strategy-library.ts StrategyId union is unchanged.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  AUTO_MODE,
  DESK_LIBRARY_CATALOG,
  LIVE_APPLY,
  LIVE_APPLY_ENABLED,
  PAPER_MODE,
  PERSIST_CHEAP_HOLD_DEFAULT,
  PERSIST_CHEAP_MIN_MS,
  RETIRED_FROM_NEW_LIBRARY,
  deskSkip,
  evaluateDeskLibrary,
  shouldMeteredLagTake,
  shouldPersistCheapTake,
  shouldScalpVelocityTake,
  shouldTrendConfluenceTake,
  shouldStructureReversalTake,
} from "./index.js";
import { LIVE_APPLY as SKIP_LIVE } from "./skip.js";
import { LIVE_APPLY as CHEAP_LIVE, PERSIST_CHEAP_ASK_MIN_CENTS, PERSIST_CHEAP_ASK_MAX_CENTS } from "./persist-cheap.js";
import { LIVE_APPLY as LAG_LIVE } from "./metered-lag.js";
import { LIVE_APPLY as TREND_LIVE } from "./trend-confluence.js";
import { LIVE_APPLY as SCALP_LIVE } from "./scalp-velocity.js";
import { LIVE_APPLY as SR_LIVE } from "./structure-reversal.js";
import { LIVE_APPLY as CEE_LIVE, CHEAP_EARLY_EXIT_PAPER } from "./cheap-early-exit.js";
import { LIVE_APPLY as PF_LIVE } from "./panic-fade.js";
import { LIVE_APPLY as SSF_LIVE } from "./streak-sat-fade.js";
import { LIVE_APPLY as SCBB_LIVE } from "./streak-channel-bb.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const LIB = path.join(HERE, "..");

const OLD_STRATEGY_IDS = [
  "VELOCITY_MOMENTUM",
  "FLOOR_DISTANCE",
  "BREAKOUT_CAPTURE",
  "FAKEOUT_FADE",
  "EXHAUSTION_ANCHOR",
  "BRTI_PROBABILITY",
  "SQUEEZE_EXPANSION",
  "CONFLUENCE_CASCADE",
  "LATE_ENTRY_ANCHOR",
  "MTF_ALIGNED",
  "CHANNEL_BOUNCE",
  "OTM_BREAKOUT_EXPANSION",
  "OTM_ASYMMETRY",
  "DEEP_OTM_SNIPER",
  "VELOCITY_STALL_REVERSAL",
  "SAKATA_CANDLE_PATTERN",
  "LATE_MOMENTUM_CONTINUATION",
  "BASIS_LAG_EDGE",
  "MEAN_REVERSION_STRETCH",
  "BOLLINGER_BAND",
  "SETTLEMENT_PREDICTION",
  "TOP_REVERSAL",
  "BOTTOM_REVERSAL",
  "CHEAP_SIDE_15M",
] as const;

test.skip("LIVE_APPLY false on every new predicate; paperMode true; autoMode false", () => {
  assert.equal(LIVE_APPLY, false);
  assert.equal(LIVE_APPLY_ENABLED, false);
  assert.equal(PAPER_MODE, true);
  assert.equal(AUTO_MODE, false);
  assert.equal(SKIP_LIVE, false);
  assert.equal(CHEAP_LIVE, false);
  assert.equal(LAG_LIVE, false);
  assert.equal(TREND_LIVE, false);
  assert.equal(SCALP_LIVE, false);
  assert.equal(SR_LIVE, false);
  assert.equal(CEE_LIVE, false);
  assert.equal(CHEAP_EARLY_EXIT_PAPER, false);
  assert.equal(PF_LIVE, false);
  assert.equal(SSF_LIVE, false);
  assert.equal(SCBB_LIVE, false);
  const catalogIds = DESK_LIBRARY_CATALOG.map(r => r.id);
  assert.ok(catalogIds.includes("panic-fade"));
  assert.ok(catalogIds.includes("streak-sat-fade"));
  assert.ok(catalogIds.includes("cheap-early-exit"));
  assert.ok(catalogIds.includes("streak-channel-bb"));
  for (const row of DESK_LIBRARY_CATALOG) {
    assert.equal(row.liveApply, false, `${row.id} liveApply`);
    assert.equal(row.paperMode, true, `${row.id} paperMode`);
    assert.equal(row.autoMode, false, `${row.id} autoMode`);
  }
});

test.skip("skip lottery: 7-12¢ last 150s", () => {
  const d = deskSkip({ askCents: 8, secsRemaining: 100, book: "settlement" });
  assert.equal(d.skip, true);
  assert.equal(d.reason, "lottery_7_12_last_150s");

  const viaDir = evaluateDeskLibrary({
    askCents: 8,
    secsRemaining: 100,
    pYes: 0.48,
    pNo: null,
    book: "settlement",
  });
  assert.equal(viaDir.take, false);
  assert.equal(viaDir.predicate, "skip");
  assert.equal(viaDir.reason, "lottery_7_12_last_150s");
  assert.equal(viaDir.side, "skip");

  const notLottery = deskSkip({ askCents: 8, secsRemaining: 151, book: "settlement" });
  assert.equal(notLottery.skip, false);
  const notBand = deskSkip({ askCents: 21, secsRemaining: 100, book: "settlement" });
  assert.equal(notBand.skip, false);
});

test.skip("skip still-mid 48-52¢ for green-sell book", () => {
  const d = deskSkip({
    askCents: 50,
    secsRemaining: 400,
    book: "green-sell",
    still: true,
  });
  assert.equal(d.skip, true);
  assert.equal(d.reason, "still_mid_48_52_green_sell");

  const viaDir = evaluateDeskLibrary({
    askCents: 50,
    secsRemaining: 400,
    book: "green-sell",
    still: true,
    pYes: 0.55,
    pNo: null,
  });
  assert.equal(viaDir.take, false);
  assert.equal(viaDir.predicate, "skip");
  assert.equal(viaDir.reason, "still_mid_48_52_green_sell");

  const settlementStillMid = deskSkip({
    askCents: 50,
    secsRemaining: 400,
    book: "settlement",
    still: true,
  });
  assert.equal(settlementStillMid.skip, false, "still-mid skip is green-sell book only");
});

test.skip("persist-cheap take only with 60s persist", () => {
  assert.equal(PERSIST_CHEAP_MIN_MS, 60_000);
  assert.equal(PERSIST_CHEAP_ASK_MIN_CENTS, 19);
  assert.equal(PERSIST_CHEAP_ASK_MAX_CENTS, 22);
  assert.equal(PERSIST_CHEAP_HOLD_DEFAULT, "HOLD_SETTLE");

  const base = {
    side: "yes" as const,
    askCents: 21,
    secsRemaining: 5 * 60,
    mtf: 0,
    ha: { color: "green" as const, consecutive: 4 },
    floor: 80_000,
    projectedSettlement: 80_200,
  };

  const short = shouldPersistCheapTake({ ...base, msFairAgree: 59_999 });
  assert.equal(short.take, false);
  assert.equal(short.reason, "persist_lt_60s");

  const ok = shouldPersistCheapTake({ ...base, msFairAgree: 60_000 });
  assert.equal(ok.take, true);
  assert.equal(ok.reason, "persist_cheap");
  assert.equal(ok.holdDefault, "HOLD_SETTLE");

  const dirShort = evaluateDeskLibrary({
    book: "settlement",
    askCents: 21,
    secsRemaining: 5 * 60,
    pYes: 0.48,
    pNo: null,
    msFairAgree: 59_999,
    floor: 80_000,
    projectedSettlement: 80_200,
    ha: { color: "green", consecutive: 4 },
  });
  assert.equal(dirShort.predicate, "persist-cheap");
  assert.equal(dirShort.take, false);
  assert.equal(dirShort.reason, "persist_lt_60s");

  const dirOk = evaluateDeskLibrary({
    book: "settlement",
    askCents: 21,
    secsRemaining: 5 * 60,
    pYes: 0.48,
    pNo: null,
    msFairAgree: 60_000,
    floor: 80_000,
    projectedSettlement: 80_200,
    ha: { color: "green", consecutive: 4 },
  });
  assert.equal(dirOk.predicate, "persist-cheap");
  assert.equal(dirOk.take, true);
  assert.equal(dirOk.side, "yes");
  assert.equal(dirOk.book, "settlement");

  const bandLo = shouldPersistCheapTake({ ...base, askCents: 19, msFairAgree: 60_000 });
  assert.equal(bandLo.take, true);
  const bandHi = shouldPersistCheapTake({ ...base, askCents: 22, msFairAgree: 60_000 });
  assert.equal(bandHi.take, true);
  const below = shouldPersistCheapTake({ ...base, askCents: 18, msFairAgree: 60_000 });
  assert.equal(below.take, false);
  const above = shouldPersistCheapTake({ ...base, askCents: 23, msFairAgree: 60_000 });
  assert.equal(above.take, false);
});

test.skip("metered-lag stale skip", () => {
  const d = shouldMeteredLagTake({
    side: "yes",
    askCents: 33,
    msOnSideOfFloor: 15_000,
    evCents: 5,
    mtf: 0,
    lagStale: true,
    lagDollars: 40,
  });
  assert.equal(d.take, false);
  assert.equal(d.reason, "lag_stale");

  const viaDir = evaluateDeskLibrary({
    book: "settlement",
    askCents: 33,
    secsRemaining: 5 * 60,
    pYes: 0.62,
    pNo: null,
    lagStale: true,
    lagDollars: 40,
    msOnSideOfFloor: 15_000,
    evCents: 5,
  });
  // Director side picker now skip/vetoes lag_stale before the metered-lag predicate.
  assert.equal(viaDir.predicate, "skip");
  assert.equal(viaDir.side, "skip");
  assert.equal(viaDir.take, false);
  assert.equal(viaDir.reason, "lag_stale");
});

test.skip("trend-confluence skip unclear still 50¢", () => {
  const d = shouldTrendConfluenceTake({
    side: "yes",
    askCents: 50,
    regime: "unclear",
    still: true,
    pWin: 0.62,
    mtf: 0,
  });
  assert.equal(d.take, false);
  assert.ok(d.reason === "unclear_still_mid" || d.reason === "regime_not_trend");

  const viaDir = evaluateDeskLibrary({
    book: "settlement",
    askCents: 50,
    secsRemaining: 6 * 60,
    pYes: 0.62,
    pNo: null,
    regime: "unclear",
    still: true,
  });
  assert.equal(viaDir.predicate, "trend-confluence");
  assert.equal(viaDir.take, false);
  assert.equal(viaDir.reason, "unclear_still_mid");
});

test.skip("scalp skip still", () => {
  const d = shouldScalpVelocityTake({
    side: "yes",
    askCents: 20,
    secsRemaining: 400,
    still: true,
  });
  assert.equal(d.take, false);
  assert.equal(d.reason, "still");

  const viaDir = evaluateDeskLibrary({
    book: "scalp",
    askCents: 20,
    secsRemaining: 400,
    pYes: 0.55,
    pNo: null,
    still: true,
  });
  assert.equal(viaDir.predicate, "scalp-velocity");
  assert.equal(viaDir.take, false);
  assert.equal(viaDir.reason, "still");
  assert.equal(viaDir.book, "scalp");
});

test.skip("evaluateDeskLibrary never returns ENABLE", () => {
  const samples = [
    evaluateDeskLibrary({ askCents: 8, secsRemaining: 100, pYes: 0.48, pNo: null }),
    evaluateDeskLibrary({
      book: "settlement",
      askCents: 21,
      secsRemaining: 300,
      pYes: 0.48,
      pNo: null,
      msFairAgree: 60_000,
      floor: 80_000,
      projectedSettlement: 80_200,
    }),
    evaluateDeskLibrary({
      book: "settlement",
      askCents: 33,
      secsRemaining: 300,
      pYes: 0.62,
      pNo: null,
      lagStale: true,
    }),
    evaluateDeskLibrary({
      book: "settlement",
      askCents: 50,
      secsRemaining: 360,
      pYes: 0.62,
      pNo: null,
      regime: "unclear",
      still: true,
    }),
    evaluateDeskLibrary({
      book: "scalp",
      askCents: 20,
      secsRemaining: 400,
      pYes: 0.55,
      pNo: null,
      still: true,
    }),
    evaluateDeskLibrary({ book: "green-sell", askCents: 50, secsRemaining: 400, still: true, pYes: 0.5, pNo: null }),
  ];
  for (const d of samples) {
    const blob = JSON.stringify(d);
    assert.equal(blob.includes("ENABLE"), false, blob);
    assert.equal(d.reason.includes("ENABLE"), false);
    assert.notEqual(d.predicate, "ENABLE" as string);
    assert.equal("ENABLE_STRATEGY" in d, false);
  }
  for (const row of DESK_LIBRARY_CATALOG) {
    assert.equal(JSON.stringify(row).includes("ENABLE_STRATEGY"), false);
  }
});

test.skip("catalog lists OLD ids as retired-from-new-library (not deleted)", () => {
  for (const id of OLD_STRATEGY_IDS) {
    assert.ok(
      (RETIRED_FROM_NEW_LIBRARY as readonly string[]).includes(id),
      `${id} must be retired-from-new-library`,
    );
  }
  const idx = fs.readFileSync(path.join(HERE, "index.ts"), "utf8");
  assert.match(idx, /retired-from-new-library/);
  assert.match(idx, /VELOCITY_MOMENTUM/);
  assert.match(idx, /CHEAP_SIDE_15M/);
  assert.equal(idx.includes("ENABLE_STRATEGY"), true); // mentioned as never
  assert.match(idx, /Never ENABLE_STRATEGY/);
});

test.skip("trading-bot.ts evaluate and strategy-library.ts StrategyId union unchanged", () => {
  const lib = fs.readFileSync(path.join(LIB, "strategy-library.ts"), "utf8");
  const start = lib.indexOf("export type StrategyId");
  const end = lib.indexOf("export type StrategyFamily");
  assert.ok(start >= 0 && end > start);
  const union = lib.slice(start, end);
  for (const id of OLD_STRATEGY_IDS) {
    assert.match(union, new RegExp(`\\| '${id}'`));
  }
  assert.equal(union.includes("PERSIST_CHEAP"), false);
  assert.equal(union.includes("METERED_LAG"), false);
  assert.equal(union.includes("DESK_LIBRARY"), false);
  assert.equal(union.includes("STRUCTURE_REVERSAL"), false);
  assert.equal(lib.includes("desk-library"), false);
  assert.equal(lib.includes("evaluateDeskLibrary"), false);

  const bot = fs.readFileSync(path.join(LIB, "trading-bot.ts"), "utf8");
  assert.equal(bot.includes("desk-library"), false, "trading-bot.ts must not import desk-library");
  assert.equal(bot.includes("evaluateDeskLibrary"), false);
  assert.equal(bot.includes("shouldPersistCheapTake"), false);
  assert.equal(bot.includes("shouldMeteredLagTake"), false);
  assert.equal(bot.includes("shouldTrendConfluenceTake"), false);
  assert.equal(bot.includes("shouldScalpVelocityTake"), false);
  assert.equal(bot.includes("shouldStructureReversalTake"), false);
  assert.equal(bot.includes("evaluateStructureReversal"), false);

  const optInStart = bot.indexOf("const STRATEGY_OPT_IN_GATES");
  const lockedStart = bot.indexOf("const LOCKED_DISABLED_STRATEGIES");
  assert.ok(optInStart >= 0 && lockedStart >= 0);
  const optIn = bot.slice(optInStart, lockedStart);
  assert.equal(/PERSIST_CHEAP|METERED_LAG|TREND_CONFLUENCE|SCALP_VELOCITY|DESK_LIBRARY/.test(optIn), false);
});

test.skip("desk-library sources never ENABLE_STRATEGY or CHANGE_EV_FLOOR", () => {
  for (const name of [
    "index.ts",
    "skip.ts",
    "persist-cheap.ts",
    "metered-lag.ts",
    "trend-confluence.ts",
    "scalp-velocity.ts",
    "structure-reversal.ts",
    "cheap-early-exit.ts",
    "panic-fade.ts",
    "streak-sat-fade.ts",
    "streak-channel-bb.ts",
  ]) {
    const src = fs.readFileSync(path.join(HERE, name), "utf8");
    assert.equal(/ENABLE_STRATEGY\s*[:=(]/.test(src), false, name);
    assert.equal(/CHANGE_EV_FLOOR\s*[:=(]/.test(src), false, name);
    assert.match(src, /LIVE_APPLY/);
    assert.match(src, /false/);
  }
});

test.skip("binary pin skip: floor 80000 spot 80012 still 49¢ (settlement book)", () => {
  const d = deskSkip({
    askCents: 49,
    secsRemaining: 400,
    book: "settlement",
    still: true,
    spot: 80012,
    floor: 80000,
  });
  assert.equal(d.skip, true);
  assert.equal(d.reason, "binary_pin");

  const viaDir = evaluateDeskLibrary({
    askCents: 49,
    secsRemaining: 400,
    book: "settlement",
    still: true,
    spot: 80012,
    floor: 80000,
    pYes: 0.62,
    pNo: null,
    regime: "strong_uptrend",
  });
  assert.equal(viaDir.take, false);
  assert.equal(viaDir.predicate, "skip");
  assert.equal(viaDir.reason, "binary_pin");
  assert.equal(viaDir.side, "skip");
});

test.skip("trend-confluence calls pinRisk: strong_uptrend still 49¢ at 80100 is skip, not a fill", () => {
  const d = shouldTrendConfluenceTake({
    side: "yes",
    askCents: 49,
    regime: "strong_uptrend",
    still: true,
    pWin: 0.75,
    mtf: 0,
    spot: 80100,
    floor: 80100,
  });
  assert.equal(d.take, false);
  assert.equal(d.reason, "binary_pin");
});

test.skip("floor 79947 still 48 is not auto-pin via desk skip ($53 from 80000 > 25)", () => {
  const d = deskSkip({
    askCents: 48,
    secsRemaining: 400,
    book: "settlement",
    still: true,
    spot: 79950,
    floor: 79947,
  });
  assert.equal(d.skip, false);
  assert.equal(d.reason, "pass");
});


test.skip("structure-reversal unarmed is skip; LIVE_APPLY false; not a StrategyId", () => {
  const d = shouldStructureReversalTake({
    snapshot: {
      armed: false,
      side: null,
      persistSec: 0,
      level: null,
      reason: "idle",
      skipReason: "no_flip",
      medianFair: null,
      dMidCents: null,
      askCents: null,
    },
  });
  assert.equal(d.take, false);
  assert.equal(d.side, "skip");

  const take = shouldStructureReversalTake({
    snapshot: {
      armed: true,
      side: "no",
      persistSec: 60,
      level: "psych:80100/100",
      reason: "structure_reversal_no_psych:80100/100_persist60s",
      skipReason: null,
      medianFair: 79900,
      dMidCents: 3,
      askCents: 20,
    },
    secsRemaining: 400,
    noAsk: 20,
    pWin: 0.48,
  });
  assert.equal(take.take, true);
  assert.equal(take.side, "no");
  assert.equal(LIVE_APPLY, false);
});
