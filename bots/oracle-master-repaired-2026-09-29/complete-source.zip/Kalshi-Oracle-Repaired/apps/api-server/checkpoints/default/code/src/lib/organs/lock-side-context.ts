/**
 * LOCKSIDE_CONTEXT — human pipeline tags + W2 V5–V10 context vetoes.
 * Oracle is sole editor. Isolate-rewrite-compare (not a TradingBot rewrite).
 *
 * lockSide(obs) → { side: 'yes'|'no'|'skip', tags, why }
 * Settlement side = sign(BRTI vs THIS window's locked strike). Not Coinbase last.
 * Volume / delta / location / pattern NEVER elect YES/NO.
 *
 * Missing sensors stay null. Never invent lagProven / holdToSettlement / live strike.
 * No ENABLE leftovers/OTM/PAPER_SCALP. No EXIT rewrite. Floors untouched.
 */
import {
  ALIGNED_ASK_MIN_CENTS,
  ALIGNED_ASK_MAX_CENTS,
  LAST_60S_BRTI_AVG_SKIP,
  STILL_MID_UNCLEAR_SKIP,
  inLast60sBrti,
  inStillMidCoinFlip,
  stillMidUnclearBlocksEntry,
  inStrategyAskBand,
  mtfSignToSide,
  type AlignedMtfSign,
} from "../aligned-take-gate.js";
import { remainingVolDollars } from "../path-ride.js";
import {
  analogCompleted15mSide,
  bookBothWings50,
  type Analog15mBar,
} from "./direction-lock.js";

export const LOCKSIDE_CONTEXT_LOADED = true as const;
export const LOCKSIDE_CONTEXT_NOT_LOADED = "[LOCKSIDE_CONTEXT] not loaded";

export function formatLockSideLoadedLog(): string {
  return LOCKSIDE_CONTEXT_LOADED
    ? "[LOCKSIDE_CONTEXT] loaded"
    : LOCKSIDE_CONTEXT_NOT_LOADED;
}

export const AT_SR_PCT = 0.0012; // 0.12%
export const SQUEEZE_WIDTH_FRAC = 0.55;
export const VOL_RISING_MULT = 1.25;
export const VOL_DRY_MULT = 0.70;
export const PIN_FLOOR_DOLLARS = 120;
export const PIN_REACH_K = 0.8;
export const CLEAR_FLOOR_DOLLARS = 180;
export const CLEAR_REACH_K = 1.25;

export type LockSideSide = "yes" | "no";
export type LockSideResult = "yes" | "no" | "skip";
export type VolState = "RISING" | "DRY" | "FLAT" | null;
export type DeltaSign = "BUY" | "SELL" | "MIX";
export type LocBucket = "LOW" | "MID" | "HIGH" | null;
export type PatternKind = "SQUEEZE" | "TRIANGLE" | "NONE" | null;
export type PinState = "PIN" | "CLEAR" | null;

export type OhlcBar = {
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number | null;
  t?: number;
  ts?: number;
  time?: number;
  openTime?: number;
};

export type LockSidePin = {
  gap: number | null;
  reach: number | null;
  state: PinState;
};

export type LockSideTags = {
  htfRange: { low: number; high: number } | null;
  ltfRange: { low: number; high: number; loc: number | null; locBucket: LocBucket } | null;
  sr: { atS: boolean | null; atR: boolean | null; r: number | null; s: number | null };
  channel: { intact: boolean | null; broken: boolean | null; slopeUp: boolean | null; breakSide: "up" | "down" | null };
  volState: VolState;
  deltaSign: DeltaSign;
  pattern: PatternKind;
  pin: LockSidePin;
  mtf: LockSideSide | null;
  ha: LockSideSide | null;
  analog: LockSideSide | null;
  brtiSign: LockSideSide | null;
  lagProven: boolean | null;
  result: "PASS" | "SKIP" | null;
  why: string | null;
};

export type LockSideObs = {
  /** Last N 4h bars (forming may be included — dropped as incomplete). */
  ohlc4h?: OhlcBar[] | null;
  /** Last N 15m bars. */
  ohlc15m?: OhlcBar[] | null;
  analog15mBars?: Analog15mBar[] | null;
  brtiPx?: number | null;
  /** Must be ===true for BRTI pin/sign; omit/false → undefined (no spot invent). */
  brtiDefined?: boolean;
  /** THIS window's locked strike — caller passes; never invent. */
  strike?: number | null;
  floorStrike?: number | null;
  secsRemaining?: number;
  ohlc1m?: { open: number; high: number; low: number; close: number }[] | null;
  /** σ√t dollars when already on desk (remainingVolDollars). */
  remainingVol?: number | null;
  /** Explicit σ_1m (ATR dollars). reach = σ_1m * sqrt(secs/60). */
  sigma1m?: number | null;
  volumes15m?: Array<number | null | undefined> | null;
  deltaSign?: DeltaSign | null;
  mtfSign?: AlignedMtfSign;
  haSide?: LockSideSide | null;
  analogSide?: LockSideSide | null;
  lagProven?: boolean | null;
  lagSide?: LockSideSide | null;
  yesAsk?: number | null;
  noAsk?: number | null;
  nowMs?: number;
  /** When false, do not drop last bar as forming. Default true for live series. */
  formingLast?: boolean;
  strategyId?: string | null;
};

export type LockSideOut = {
  side: LockSideResult;
  tags: LockSideTags;
  why: string | null;
};

const EMPTY_PIN: LockSidePin = { gap: null, reach: null, state: null };

function emptyTags(partial: Partial<LockSideTags> = {}): LockSideTags {
  return {
    htfRange: null,
    ltfRange: null,
    sr: { atS: null, atR: null, r: null, s: null },
    channel: { intact: null, broken: null, slopeUp: null, breakSide: null },
    volState: null,
    deltaSign: "MIX",
    pattern: null,
    pin: { ...EMPTY_PIN },
    mtf: null,
    ha: null,
    analog: null,
    brtiSign: null,
    lagProven: null,
    result: null,
    why: null,
    ...partial,
  };
}

function barOpenMs(b: OhlcBar): number | null {
  const n = b.t ?? b.ts ?? b.time ?? b.openTime;
  if (typeof n !== "number" || !Number.isFinite(n)) return null;
  return n > 1e12 ? n : n * 1000;
}

/** Last `n` COMPLETED bars. Forming ignored. */
export function completedBars(
  bars: OhlcBar[] | null | undefined,
  opts: { n?: number; periodMs?: number; nowMs?: number; formingLast?: boolean } = {},
): OhlcBar[] {
  if (!bars || bars.length === 0) return [];
  const n = opts.n ?? 12;
  const formingLast = opts.formingLast !== false;
  const nowMs = opts.nowMs;
  const periodMs = opts.periodMs;
  let completed: OhlcBar[];
  const stamped = bars.map(b => ({ b, openMs: barOpenMs(b) }));
  const allStamped = stamped.every(x => x.openMs != null) && typeof periodMs === "number" && periodMs > 0
    && typeof nowMs === "number" && Number.isFinite(nowMs);
  if (allStamped) {
    completed = stamped
      .filter(x => (x.openMs as number) + (periodMs as number) <= (nowMs as number))
      .map(x => x.b);
  } else if (formingLast && bars.length > 1) {
    completed = bars.slice(0, -1);
  } else {
    completed = bars.slice();
  }
  return completed.slice(-n);
}

export function rangeOf(bars: OhlcBar[]): { low: number; high: number } | null {
  if (!bars.length) return null;
  let low = Infinity;
  let high = -Infinity;
  for (const b of bars) {
    if (!(b.low > 0) || !(b.high > 0)) continue;
    if (b.low < low) low = b.low;
    if (b.high > high) high = b.high;
  }
  if (!(low < Infinity) || !(high > -Infinity) || !(high >= low)) return null;
  return { low, high };
}

function nearPct(a: number, b: number, pct = AT_SR_PCT): boolean {
  if (!(a > 0) || !(b > 0)) return false;
  return Math.abs(a - b) / b <= pct;
}

/** Local swing highs/lows on completed bars (need both neighbors). */
export function swingLevels(
  bars: OhlcBar[],
  kind: "high" | "low",
): number[] {
  const out: number[] = [];
  if (bars.length < 3) return out;
  for (let i = 1; i < bars.length - 1; i++) {
    const prev = bars[i - 1]!;
    const cur = bars[i]!;
    const next = bars[i + 1]!;
    if (kind === "high") {
      if (cur.high > prev.high && cur.high > next.high && cur.high > 0) out.push(cur.high);
    } else {
      if (cur.low < prev.low && cur.low < next.low && cur.low > 0) out.push(cur.low);
    }
  }
  return out;
}

/** Count touches (≥2) of a level across bar extremes within 0.12%. */
export function touchCount(bars: OhlcBar[], level: number, kind: "high" | "low"): number {
  let n = 0;
  for (const b of bars) {
    const px = kind === "high" ? b.high : b.low;
    if (nearPct(px, level)) n++;
  }
  return n;
}

export function buildSR(opts: {
  htf: OhlcBar[];
  ltf: OhlcBar[];
  brti: number | null;
}): { r: number | null; s: number | null; atR: boolean | null; atS: boolean | null } {
  const htfRange = rangeOf(opts.htf);
  if (!htfRange) return { r: null, s: null, atR: null, atS: null };
  const swingH = swingLevels(opts.ltf, "high").filter(lvl => touchCount(opts.ltf, lvl, "high") >= 2);
  const swingL = swingLevels(opts.ltf, "low").filter(lvl => touchCount(opts.ltf, lvl, "low") >= 2);
  // R = HTF high + 15m swing highs touched ≥2; S = HTF low + 15m swing lows ≥2.
  const rLevels = [htfRange.high, ...swingH];
  const sLevels = [htfRange.low, ...swingL];
  // Prefer HTF extrema as primary R/S tags; swing levels still count for atR/atS.
  const r = htfRange.high;
  const s = htfRange.low;
  const brti = opts.brti;
  if (typeof brti !== "number" || !(brti > 0)) {
    return { r, s, atR: null, atS: null };
  }
  const atR = rLevels.some(lvl => nearPct(brti, lvl));
  const atS = sLevels.some(lvl => nearPct(brti, lvl));
  return { r, s, atR, atS };
}

export function locBucketOf(loc: number | null): LocBucket {
  if (loc == null || !Number.isFinite(loc)) return null;
  if (loc <= 0.25) return "LOW";
  if (loc >= 0.75) return "HIGH";
  return "MID";
}

export function buildLoc(
  brti: number | null,
  ltfRange: { low: number; high: number } | null,
): { loc: number | null; locBucket: LocBucket } {
  if (!ltfRange || typeof brti !== "number" || !(brti > 0)) {
    return { loc: null, locBucket: null };
  }
  const width = Math.max(ltfRange.high - ltfRange.low, 1);
  const loc = (brti - ltfRange.low) / width;
  return { loc, locBucket: locBucketOf(loc) };
}

/**
 * Channel from ≥2 completed touches each side. Update on bar close only
 * (caller passes completed bars). Intact = last close inside; broken =
 * last close outside and next bar does not reclaim (need ≥2 closes after).
 */
export function buildChannel(ltf: OhlcBar[]): {
  intact: boolean | null;
  broken: boolean | null;
  slopeUp: boolean | null;
  breakSide: "up" | "down" | null;
  upper: number | null;
  lower: number | null;
  width: number | null;
  upperSlope: number | null;
  lowerSlope: number | null;
} {
  const nullCh = {
    intact: null, broken: null, slopeUp: null, breakSide: null as "up" | "down" | null,
    upper: null, lower: null, width: null, upperSlope: null, lowerSlope: null,
  };
  if (ltf.length < 6) return nullCh;

  // Fit channel on bars excluding the last 2 (break + confirm). Update on close only.
  const fitEnd = ltf.length - 2;
  const fit = ltf.slice(0, fitEnd);
  if (fit.length < 4) return nullCh;

  const upTouches: { i: number; px: number }[] = [];
  const loTouches: { i: number; px: number }[] = [];
  for (let i = 1; i < fit.length - 1; i++) {
    const prev = fit[i - 1]!;
    const cur = fit[i]!;
    const next = fit[i + 1]!;
    if (cur.high >= prev.high && cur.high >= next.high) upTouches.push({ i, px: cur.high });
    if (cur.low <= prev.low && cur.low <= next.low) loTouches.push({ i, px: cur.low });
  }
  if (upTouches.length < 2 || loTouches.length < 2) return nullCh;

  const u0 = upTouches[upTouches.length - 2]!;
  const u1 = upTouches[upTouches.length - 1]!;
  const l0 = loTouches[loTouches.length - 2]!;
  const l1 = loTouches[loTouches.length - 1]!;
  const du = Math.max(1, u1.i - u0.i);
  const dl = Math.max(1, l1.i - l0.i);
  const upperSlope = (u1.px - u0.px) / du;
  const lowerSlope = (l1.px - l0.px) / dl;

  const bandAt = (i: number) => ({
    upper: u1.px + upperSlope * (i - u1.i),
    lower: l1.px + lowerSlope * (i - l1.i),
  });

  const lastI = ltf.length - 1;
  const { upper, lower } = bandAt(lastI);
  if (!(upper > lower)) return nullCh;
  const width = upper - lower;
  const mid0 = (u0.px + l0.px) / 2;
  const mid1 = (u1.px + l1.px) / 2;
  const slopeUp = mid1 > mid0;

  const last = ltf[lastI]!;
  const prev = ltf[lastI - 1]!;
  const prevBand = bandAt(lastI - 1);
  const lastOutUp = last.close > upper;
  const lastOutDn = last.close < lower;
  const prevOutUp = prev.close > prevBand.upper;
  const prevOutDn = prev.close < prevBand.lower;
  // Broken = close outside AND next bar does not reclaim (both outside same side).
  let broken = false;
  let breakSide: "up" | "down" | null = null;
  if (prevOutUp && lastOutUp) { broken = true; breakSide = "up"; }
  else if (prevOutDn && lastOutDn) { broken = true; breakSide = "down"; }

  const inside = last.close >= lower && last.close <= upper;

  return {
    intact: inside && !broken,
    broken,
    slopeUp,
    breakSide,
    upper,
    lower,
    width,
    upperSlope,
    lowerSlope,
  };
}

export function volStateOf(
  vols: Array<number | null | undefined> | null | undefined,
): VolState {
  if (!vols || vols.length < 20) return null;
  const clean = vols.filter((v): v is number => typeof v === "number" && Number.isFinite(v) && v >= 0);
  if (clean.length < 20) return null;
  const last20 = clean.slice(-20);
  const sorted = [...last20].sort((a, b) => a - b);
  const med = sorted[Math.floor(sorted.length / 2)]!;
  if (!(med > 0)) return null;
  const last3 = clean.slice(-3);
  if (last3.length < 3) return null;
  const last3Med = [...last3].sort((a, b) => a - b)[1]!;
  if (last3Med > VOL_RISING_MULT * med) return "RISING";
  if (last3Med < VOL_DRY_MULT * med) return "DRY";
  return "FLAT";
}

export function patternOf(
  ltf: OhlcBar[],
  channel: ReturnType<typeof buildChannel>,
): PatternKind {
  if (ltf.length < 4) return null;
  const widths: number[] = [];
  for (const b of ltf) {
    const w = b.high - b.low;
    if (Number.isFinite(w) && w >= 0) widths.push(w);
  }
  if (widths.length < 4) return "NONE";
  const last12 = widths.slice(-12);
  const sorted = [...last12].sort((a, b) => a - b);
  const med = sorted[Math.floor(sorted.length / 2)]!;
  const cur = last12[last12.length - 1]!;
  if (med > 0 && cur < SQUEEZE_WIDTH_FRAC * med) return "SQUEEZE";

  // TRIANGLE: both channel slopes converging + width shrinking ≥3 bars
  if (
    channel.upperSlope != null && channel.lowerSlope != null
    && channel.upperSlope < 0 && channel.lowerSlope > 0
  ) {
    const recent = widths.slice(-4);
    if (recent.length >= 4) {
      let shrinking = true;
      for (let i = 1; i < recent.length; i++) {
        if (!(recent[i]! < recent[i - 1]!)) { shrinking = false; break; }
      }
      if (shrinking) return "TRIANGLE";
    }
  }
  return "NONE";
}

/**
 * PIN / CLEAR vs strike. Reuse remainingVolDollars / 1m OHLC — do not invent σ.
 * Missing σ or BRTI/strike → state null (unknown ≠ V5 skip).
 */
export function computePinClear(opts: {
  brti?: number | null;
  strike?: number | null;
  secsRemaining?: number;
  remainingVol?: number | null;
  sigma1m?: number | null;
  ohlc1m?: LockSideObs["ohlc1m"];
}): LockSidePin {
  const brti = opts.brti;
  const strike = opts.strike;
  if (typeof brti !== "number" || !(brti > 0) || typeof strike !== "number" || !(strike > 0)) {
    return { ...EMPTY_PIN };
  }
  const gap = brti - strike;
  const secs = typeof opts.secsRemaining === "number" && Number.isFinite(opts.secsRemaining)
    ? Math.max(0, opts.secsRemaining)
    : null;

  let reach: number | null = null;
  if (typeof opts.remainingVol === "number" && opts.remainingVol > 0) {
    // Desk remainingVolDollars is already σ_1m * sqrt(minsLeft).
    reach = opts.remainingVol;
  } else if (typeof opts.sigma1m === "number" && opts.sigma1m > 0 && secs != null) {
    reach = opts.sigma1m * Math.sqrt(Math.max(1 / 60, secs / 60));
  } else if (opts.ohlc1m && secs != null) {
    reach = remainingVolDollars(opts.ohlc1m, secs);
  }
  if (reach == null || !(reach > 0)) {
    return { gap, reach: null, state: null };
  }
  const abs = Math.abs(gap);
  if (abs < Math.max(PIN_FLOOR_DOLLARS, PIN_REACH_K * reach)) {
    return { gap, reach, state: "PIN" };
  }
  if (abs >= Math.max(CLEAR_FLOOR_DOLLARS, CLEAR_REACH_K * reach)) {
    return { gap, reach, state: "CLEAR" };
  }
  return { gap, reach, state: null };
}

function brtiOf(obs: LockSideObs): { defined: boolean; px: number | null } {
  // Hostile: defined iff brtiDefined===true. Bare px / omitted flag ≠ BRTI
  // (delete legacy `|| true` that always forced defined when px present).
  if (obs.brtiDefined !== true) return { defined: false, px: null };
  const px = obs.brtiPx;
  if (typeof px !== "number" || !Number.isFinite(px) || !(px > 0)) {
    return { defined: false, px: null };
  }
  return { defined: true, px };
}

function strikeOf(obs: LockSideObs): number | null {
  const s = obs.strike ?? obs.floorStrike;
  return typeof s === "number" && Number.isFinite(s) && s > 0 ? s : null;
}

function signVsStrike(px: number, strike: number): LockSideSide | null {
  if (!(px > 0) || !(strike > 0)) return null;
  if (px > strike) return "yes";
  if (px < strike) return "no";
  return null; // exact = no lean
}

function askOf(obs: LockSideObs, side: LockSideSide): number | null {
  const ask = side === "yes" ? obs.yesAsk : obs.noAsk;
  return typeof ask === "number" && Number.isFinite(ask) ? ask : null;
}

/** Volumes from bars or explicit array. */
function volumesFrom(obs: LockSideObs, ltf: OhlcBar[]): Array<number | null | undefined> | null {
  if (obs.volumes15m && obs.volumes15m.length > 0) return obs.volumes15m;
  const fromBars = ltf.map(b => b.volume);
  if (fromBars.some(v => typeof v === "number" && Number.isFinite(v))) return fromBars;
  return null;
}

/**
 * Build all lockSide.* tags. Missing sensors stay null. Never invent.
 */
export function buildLockSideTags(obs: LockSideObs): LockSideTags {
  const nowMs = typeof obs.nowMs === "number" && Number.isFinite(obs.nowMs) ? obs.nowMs : Date.now();
  const htf = completedBars(obs.ohlc4h, { n: 12, periodMs: 4 * 60 * 60_000, nowMs, formingLast: obs.formingLast });
  const ltf = completedBars(obs.ohlc15m ?? (obs.analog15mBars as OhlcBar[] | null | undefined), {
    n: 12, periodMs: 15 * 60_000, nowMs, formingLast: obs.formingLast,
  });
  const htfRange = rangeOf(htf);
  const ltfRangeRaw = rangeOf(ltf);
  const brti = brtiOf(obs);
  const strike = strikeOf(obs);
  const sr = buildSR({ htf, ltf, brti: brti.px });
  const loc = buildLoc(brti.px, ltfRangeRaw);
  const channel = buildChannel(ltf);
  const vols = volumesFrom(obs, ltf);
  const volState = volStateOf(vols);
  const deltaSign: DeltaSign =
    obs.deltaSign === "BUY" || obs.deltaSign === "SELL" || obs.deltaSign === "MIX"
      ? obs.deltaSign
      : "MIX";
  const pattern = patternOf(ltf, channel);
  const pin = computePinClear({
    brti: brti.px,
    strike,
    secsRemaining: obs.secsRemaining,
    remainingVol: obs.remainingVol,
    sigma1m: obs.sigma1m,
    ohlc1m: obs.ohlc1m,
  });
  const mtf = mtfSignToSide(obs.mtfSign);
  const ha = obs.haSide === "yes" || obs.haSide === "no" ? obs.haSide : null;
  let analog: LockSideSide | null =
    obs.analogSide === "yes" || obs.analogSide === "no" ? obs.analogSide : null;
  if (analog == null && (obs.analog15mBars || obs.ohlc15m)) {
    analog = analogCompleted15mSide(
      (obs.analog15mBars ?? obs.ohlc15m) as Analog15mBar[],
      nowMs,
    );
  }
  const brtiSign =
    brti.defined && brti.px != null && strike != null
      ? signVsStrike(brti.px, strike)
      : null;
  const lagProven = typeof obs.lagProven === "boolean" ? obs.lagProven : null;

  return emptyTags({
    htfRange,
    ltfRange: ltfRangeRaw
      ? { low: ltfRangeRaw.low, high: ltfRangeRaw.high, loc: loc.loc, locBucket: loc.locBucket }
      : null,
    sr: { atS: sr.atS, atR: sr.atR, r: sr.r, s: sr.s },
    channel: {
      intact: channel.intact,
      broken: channel.broken,
      slopeUp: channel.slopeUp,
      breakSide: channel.breakSide,
    },
    volState,
    deltaSign,
    pattern,
    pin,
    mtf,
    ha,
    analog,
    brtiSign,
    lagProven,
  });
}

export const LOCKSIDE_SKIP = {
  MTF_NULL: "mtf_sign_null",
  ANALOG: "analog_disagree",
  HA: "ha_disagree",
  BRTI: "brti_disagree",
  LAG: "lag_disagree",
  LAG_UNPROVEN: "lag_unproven",
  PIN: "pin_reachable",
  CHANNEL_FADE: "channel_break_fade",
  AT_R_RISING_BUY_NO: "at_r_rising_buy_no",
  AT_S_RISING_SELL_YES: "at_s_rising_sell_yes",
  AT_R_DRY_FADE_NOT_NO: "at_r_dry_fade_not_no",
  AT_S_DRY_FADE_NOT_YES: "at_s_dry_fade_not_yes",
  ASK: "ask_out_of_band",
  STILL_MID: STILL_MID_UNCLEAR_SKIP,
  LAST_60S: LAST_60S_BRTI_AVG_SKIP,
  BOOK_50: "book_50_50",
  PATTERN_NOT_CLEAR: "pattern_not_clear",
  MID_MIX_PIN: "mid_mix_pin",
} as const;

/**
 * Human pipeline decision. sideCandidate ← MTF. Vol/delta/loc/pattern never elect.
 * Missing sensor ≠ fail except analog/MTF as specified.
 */
export function lockSide(obs: LockSideObs): LockSideOut {
  const tags = buildLockSideTags(obs);
  const sideCandidate = tags.mtf;

  const finish = (side: LockSideResult, why: string | null): LockSideOut => {
    const result = side === "skip" ? "SKIP" : "PASS";
    tags.result = result;
    tags.why = why;
    return { side, tags, why };
  };

  if (!sideCandidate) return finish("skip", LOCKSIDE_SKIP.MTF_NULL);
  if (inLast60sBrti(obs.secsRemaining)) return finish("skip", LOCKSIDE_SKIP.LAST_60S);

  // V1 analog defined AND ≠ sideCandidate → SKIP (forming = undefined → no skip)
  if (tags.analog != null && tags.analog !== sideCandidate) {
    return finish("skip", LOCKSIDE_SKIP.ANALOG);
  }
  // V2 HA defined AND ≠ → TAG only (demoted off fill power; cannot block TAKE)
  let haTag: string | null = null;
  if (tags.ha != null && tags.ha !== sideCandidate) {
    haTag = LOCKSIDE_SKIP.HA;
  }
  // V3 BRTI defined AND not PIN AND sign ≠ sideCandidate → SKIP
  if (
    tags.brtiSign != null
    && tags.pin.state !== "PIN"
    && tags.brtiSign !== sideCandidate
  ) {
    return finish("skip", LOCKSIDE_SKIP.BRTI);
  }
  // V4 lagProven==true AND lag ≠ → SKIP; false → do not skip CC
  if (tags.lagProven === true) {
    const lag = obs.lagSide === "yes" || obs.lagSide === "no" ? obs.lagSide : null;
    if (lag != null && lag !== sideCandidate) return finish("skip", LOCKSIDE_SKIP.LAG);
  } else if (obs.strategyId === "BASIS_LAG_EDGE") {
    return finish("skip", LOCKSIDE_SKIP.LAG_UNPROVEN);
  }

  // V5 PIN == true → TAG only (demoted off fill power; last-60s already SKIP)
  if (tags.pin.state === "PIN") {
    haTag = haTag ?? LOCKSIDE_SKIP.PIN;
  }

  // Soft-context tags (fill-power demote). Vol/delta/loc/pattern NEVER elect
  // YES/NO and must NOT hard-SKIP CC/LAG gold cells. PATTERN_NOT_CLEAR previously
  // only fired when pin.state==null (unknown) — illegal unknown≠fail starve.
  // CHANNEL_FADE / at-R/at-S stay as tags for story; floors (ask/still-mid/
  // last-60s/analog/brti/lag/book) remain hard below.
  if (
    (tags.pattern === "SQUEEZE" || tags.pattern === "TRIANGLE")
    && tags.pin.state !== "CLEAR"
    && tags.pin.state !== "PIN" // PIN tagged above; unknown pin + squeeze → tag only
  ) {
    haTag = haTag ?? LOCKSIDE_SKIP.PATTERN_NOT_CLEAR;
  }

  // V6 channel.broken AND fade of the break → TAG only
  if (tags.channel.broken === true) {
    const fade =
      (tags.channel.breakSide === "up" && sideCandidate === "no")
      || (tags.channel.breakSide === "down" && sideCandidate === "yes");
    if (fade) haTag = haTag ?? LOCKSIDE_SKIP.CHANNEL_FADE;
  }

  // V7 at R + RISING + BUY + sideCandidate==NO → TAG only
  if (
    tags.sr.atR === true
    && tags.volState === "RISING"
    && tags.deltaSign === "BUY"
    && sideCandidate === "no"
  ) {
    haTag = haTag ?? LOCKSIDE_SKIP.AT_R_RISING_BUY_NO;
  }
  // V8 at S + RISING + SELL + sideCandidate==YES → TAG only
  if (
    tags.sr.atS === true
    && tags.volState === "RISING"
    && tags.deltaSign === "SELL"
    && sideCandidate === "yes"
  ) {
    haTag = haTag ?? LOCKSIDE_SKIP.AT_S_RISING_SELL_YES;
  }
  // V9 at R + DRY + SELL + intact → fade preferred NO (tag if not)
  if (
    tags.sr.atR === true
    && tags.volState === "DRY"
    && tags.deltaSign === "SELL"
    && tags.channel.intact === true
    && sideCandidate !== "no"
  ) {
    haTag = haTag ?? LOCKSIDE_SKIP.AT_R_DRY_FADE_NOT_NO;
  }
  // V10 at S + DRY + BUY + intact → fade preferred YES (tag if not)
  if (
    tags.sr.atS === true
    && tags.volState === "DRY"
    && tags.deltaSign === "BUY"
    && tags.channel.intact === true
    && sideCandidate !== "yes"
  ) {
    haTag = haTag ?? LOCKSIDE_SKIP.AT_S_DRY_FADE_NOT_YES;
  }

  // V11/V12: name still-mid BEFORE desk-door ask_out (inDeskAskBand excludes 48–52).
  // Side-aware door: YES 20–55 / NO 20–55 — never OR wings.
  const ask = askOf(obs, sideCandidate);
  const stratForBand =
    obs.strategyId === "BASIS_LAG_EDGE" || obs.strategyId === "CONFLUENCE_CASCADE"
      ? obs.strategyId
      : (tags.lagProven === true ? "BASIS_LAG_EDGE" : "CONFLUENCE_CASCADE");
  const sideForBand = sideCandidate === "yes" || sideCandidate === "no" ? sideCandidate : null;
  if (stillMidUnclearBlocksEntry({ ask, lagProven: tags.lagProven, strategyId: obs.strategyId })) {
    return finish("skip", LOCKSIDE_SKIP.STILL_MID);
  }
  if (bookBothWings50(obs.yesAsk, obs.noAsk)) return finish("skip", LOCKSIDE_SKIP.BOOK_50);
  if (ask == null || !inStrategyAskBand(ask, stratForBand, sideForBand)) {
    return finish("skip", LOCKSIDE_SKIP.ASK);
  }

  // Mid-range + MIX + PIN: tag only (PIN demoted off fill power; last-60s stays).
  if (
    tags.ltfRange?.locBucket === "MID"
    && tags.deltaSign === "MIX"
    && tags.pin.state === "PIN"
  ) {
    haTag = haTag ?? LOCKSIDE_SKIP.MID_MIX_PIN;
  }

  // PASS with optional soft tags (ha/pin/pattern/channel/at-R/S — cannot block fill)
  return finish(sideCandidate, haTag);
}

/**
 * Soft-context tags for W2. Never hard-skip: pattern / channel-fade / at-R/at-S
 * are fill-power demotes (vol/delta/loc/pattern must not starve CC/LAG gold).
 * Mutates tags.why when a soft tag applies and why is empty. Floors stay in
 * direction_w2 / lockSide (ask, still-mid, last-60s, analog, brti, lag, book).
 */
export function applyLockSideContextVetoes(opts: {
  sideCandidate: LockSideSide;
  tags: LockSideTags;
}): { skip: true; reason: string } | { skip: false; tag?: string | null } {
  const { sideCandidate, tags } = opts;
  let tag: string | null = null;
  // PIN demoted off fill power (tag-only in direction_w2 / lockSide).
  if (
    (tags.pattern === "SQUEEZE" || tags.pattern === "TRIANGLE")
    && tags.pin.state !== "CLEAR"
    && tags.pin.state !== "PIN" // PIN soft-tagged by caller; do not double-label
  ) {
    tag = LOCKSIDE_SKIP.PATTERN_NOT_CLEAR;
  }
  if (tags.channel.broken === true) {
    const fade =
      (tags.channel.breakSide === "up" && sideCandidate === "no")
      || (tags.channel.breakSide === "down" && sideCandidate === "yes");
    if (fade) tag = tag ?? LOCKSIDE_SKIP.CHANNEL_FADE;
  }
  if (
    tags.sr.atR === true
    && tags.volState === "RISING"
    && tags.deltaSign === "BUY"
    && sideCandidate === "no"
  ) {
    tag = tag ?? LOCKSIDE_SKIP.AT_R_RISING_BUY_NO;
  }
  if (
    tags.sr.atS === true
    && tags.volState === "RISING"
    && tags.deltaSign === "SELL"
    && sideCandidate === "yes"
  ) {
    tag = tag ?? LOCKSIDE_SKIP.AT_S_RISING_SELL_YES;
  }
  if (
    tags.sr.atR === true
    && tags.volState === "DRY"
    && tags.deltaSign === "SELL"
    && tags.channel.intact === true
    && sideCandidate !== "no"
  ) {
    tag = tag ?? LOCKSIDE_SKIP.AT_R_DRY_FADE_NOT_NO;
  }
  if (
    tags.sr.atS === true
    && tags.volState === "DRY"
    && tags.deltaSign === "BUY"
    && tags.channel.intact === true
    && sideCandidate !== "yes"
  ) {
    tag = tag ?? LOCKSIDE_SKIP.AT_S_DRY_FADE_NOT_YES;
  }
  if (tag != null && tags.why == null) tags.why = tag;
  return { skip: false, tag };
}

/** Story / log projection — never invent. */
export function lockSideTagsForStamp(
  tags: LockSideTags | null | undefined,
  fee?: { feeCents?: number | null; breakevenWR?: number | null } | null,
): Record<string, unknown> {
  const feeCents = fee?.feeCents ?? null;
  const breakevenWR = fee?.breakevenWR ?? null;
  if (!tags) {
    return {
      htfRange: null, ltfRange: null, sr: null, channel: null,
      volState: null, deltaSign: null, pattern: null, pin: null,
      mtf: null, ha: null, analog: null, brtiSign: null,
      lagProven: null, result: null, why: null,
      feeCents, breakevenWR,
    };
  }
  return {
    htfRange: tags.htfRange,
    ltfRange: tags.ltfRange,
    sr: tags.sr,
    channel: {
      intact: tags.channel.intact,
      broken: tags.channel.broken,
      slopeUp: tags.channel.slopeUp,
    },
    volState: tags.volState,
    deltaSign: tags.deltaSign,
    pattern: tags.pattern,
    pin: {
      gap: tags.pin.gap,
      reach: tags.pin.reach,
      state: tags.pin.state,
    },
    mtf: tags.mtf,
    ha: tags.ha,
    analog: tags.analog,
    brtiSign: tags.brtiSign,
    lagProven: tags.lagProven,
    result: tags.result,
    why: tags.why,
    feeCents,
    breakevenWR,
  };
}
