#!/usr/bin/env node
/**
 * Refresh checkpoints/default from the current src files + a live-config snapshot.
 * Usage (from apps/api-server): node scripts/refresh-default-checkpoint.mjs <live-config.json> [gitBase]
 * The live config JSON is the bot's config object (e.g. /api/bot/status .config).
 * paperMode is forced true; secret-looking keys are dropped. Never reads the ledger or .env.
 */
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const [, , liveCfgPath, gitBase = null] = process.argv;
const root = process.cwd();
const src = fs.readFileSync(path.join(root, "src/lib/default-settings.ts"), "utf8");
const frozenAt = /DEFAULT_SETTINGS_FROZEN_AT = "([^"]+)"/.exec(src)[1];
const listBlock = /DEFAULT_CODE_CHECKPOINT_FILES = \[([\s\S]*?)\] as const/.exec(src)[1];
const files = [...listBlock.matchAll(/"(src\/[^"]+)"/g)].map((m) => m[1]);
const out = path.join(root, "checkpoints/default");
fs.rmSync(path.join(out, "code"), { recursive: true, force: true });
const sha = (buf) => crypto.createHash("sha256").update(buf).digest("hex");
const perFile = {};
for (const rel of files) {
  const buf = fs.readFileSync(path.join(root, rel));
  fs.mkdirSync(path.dirname(path.join(out, "code", rel)), { recursive: true });
  fs.writeFileSync(path.join(out, "code", rel), buf);
  perFile[rel] = sha(buf);
}
if (liveCfgPath) {
  const live = JSON.parse(fs.readFileSync(liveCfgPath, "utf8"));
  const cfg = live.config && typeof live.config === "object" ? live.config : live;
  const SECRET = /(secret|token|password|apikey|api_key|privatekey|pem|passcode|credential)/i;
  const snap = {};
  for (const k of Object.keys(cfg).sort()) if (!SECRET.test(k)) snap[k] = cfg[k];
  snap.paperMode = true;
  fs.writeFileSync(path.join(out, "default-settings-snapshot.json"), JSON.stringify(snap, null, 2) + "\n");
}
const snapSha = sha(fs.readFileSync(path.join(out, "default-settings-snapshot.json")));
export function aggregate(perFileMap, snapshotSha) {
  const lines = Object.keys(perFileMap).sort().map((k) => `${k}\0${perFileMap[k]}\n`).join("");
  return crypto.createHash("sha256").update(lines + snapshotSha).digest("hex");
}
const manifest = { frozenAt, gitBase, fileCount: files.length, files: perFile, snapshotSha256: snapSha, hash: aggregate(perFile, snapSha) };
fs.writeFileSync(path.join(out, "MANIFEST.json"), JSON.stringify(manifest, null, 2) + "\n");
console.log(JSON.stringify({ frozenAt, fileCount: files.length, hash: manifest.hash }));
