/**
 * family-policy.test.ts — P3: MARKETSTATE + FAMILY POLICY (ADAPTIVE TACTICS).
 *
 * Pure-function tests for family-policy.ts. No DB, no live bot, no network.
 */
import test from "node:test";
import assert from "node:assert/strict";
import {
  opposeBar, distanceInRangeUnits, opposesAnchor, passesAnchorDistance,
  passesMomentumZVel, passesBreakoutZVel, passesMeanReversionDistance,
  meanReversionStillExpanding, isLagFamilyExemptFromMinVelocity,
  getFamilyPolicy, FAMILY_POLICY_CONSTANTS,
} from "./family-policy.js";

test("opposeBar: never below OPP_FLOOR even on a dead-quiet tape", () => {
  assert.equal(opposeBar(1), FAMILY_POLICY_CONSTANTS.OPP_FLOOR);
});

test("opposeBar: scales up with k_opp*velScale on a fast tape", () => {
  const bar = opposeBar(200);
  assert.equal(bar, FAMILY_POLICY_CONSTANTS.K_OPP * 200);
  assert.ok(bar > FAMILY_POLICY_CONSTANTS.OPP_FLOOR);
});

test("distanceInRangeUnits: symmetric and always non-negative", () => {
  assert.equal(distanceInRangeUnits(80100, 80000, 50), 2);
  assert.equal(distanceInRangeUnits(79900, 80000, 50), 2);
});

test("distanceInRangeUnits: guards against a zero/near-zero rangeScale", () => {
  const d = distanceInRangeUnits(80100, 80000, 0);
  assert.ok(Number.isFinite(d));
  assert.ok(d > 0);
});

test("opposesAnchor: only true when velocity opposes the anchor direction AND clears the tape-scaled bar", () => {
  // dist>0 (long anchor, directionSign=1): opposing velocity is negative and > opposeBar magnitude
  assert.equal(opposesAnchor(-40, 1, 12), true);   // |−40| > opposeBar(12)=35
  assert.equal(opposesAnchor(-20, 1, 12), false);  // below the bar — not a real opposition yet
  assert.equal(opposesAnchor(40, 1, 12), false);   // same direction — not opposing at all
});

test("passesAnchorDistance / passesMeanReversionDistance: mean-reversion bar is stricter than anchor's", () => {
  assert.ok(FAMILY_POLICY_CONSTANTS.D_MR > FAMILY_POLICY_CONSTANTS.D_ANCHOR);
  assert.equal(passesAnchorDistance(1.0), true);
  assert.equal(passesMeanReversionDistance(1.0), false); // passes anchor's bar but not the stricter MR one
  assert.equal(passesMeanReversionDistance(1.4), true);
});

test("passesMomentumZVel / passesBreakoutZVel: breakout requires more conviction than momentum", () => {
  assert.ok(FAMILY_POLICY_CONSTANTS.ZMIN_BREAKOUT > FAMILY_POLICY_CONSTANTS.ZMIN_MOMENTUM);
  assert.equal(passesMomentumZVel(0.75), true);
  assert.equal(passesBreakoutZVel(0.75), false); // clears momentum's bar but not breakout's stricter one
  assert.equal(passesBreakoutZVel(0.90), true);
  // sign-agnostic — a strong move in either direction should pass
  assert.equal(passesMomentumZVel(-0.80), true);
});

test("meanReversionStillExpanding: only true when zVel agrees with the pre-reversal sign and clears the bar", () => {
  assert.equal(meanReversionStillExpanding(0.80, 1), true);
  assert.equal(meanReversionStillExpanding(0.80, -1), false); // wrong sign — reversal thesis intact
  assert.equal(meanReversionStillExpanding(0.30, 1), false);  // too weak to call it "still expanding"
});

test("isLagFamilyExemptFromMinVelocity: true for lag-family strategies, never for any other strategy", () => {
  assert.equal(isLagFamilyExemptFromMinVelocity("BASIS_LAG_EDGE"), true);
  assert.equal(isLagFamilyExemptFromMinVelocity("CHEAP_SIDE_15M"), true);
  assert.equal(isLagFamilyExemptFromMinVelocity("VELOCITY_MOMENTUM"), false);
  assert.equal(isLagFamilyExemptFromMinVelocity("SETTLEMENT_PREDICTION"), false);
});

test("getFamilyPolicy: every P2-eligible strategy this module claims to cover has exactly one family", () => {
  const covered = [
    "BASIS_LAG_EDGE", "CHEAP_SIDE_15M", "LATE_ENTRY_ANCHOR", "FLOOR_DISTANCE", "EXHAUSTION_ANCHOR",
    "VELOCITY_MOMENTUM", "LATE_MOMENTUM_CONTINUATION", "BREAKOUT_CAPTURE", "SQUEEZE_EXPANSION",
    "CHANNEL_BOUNCE", "MEAN_REVERSION_STRETCH", "TOP_REVERSAL", "BOTTOM_REVERSAL",
    "FAKEOUT_FADE", "BOLLINGER_BAND", "CONFLUENCE_CASCADE", "SETTLEMENT_PREDICTION",
    "CHEAP_EARLY_EXIT", "PANIC_FADE", "STREAK_SAT_FADE",
  ] as const;
  for (const id of covered) {
    assert.ok(getFamilyPolicy(id) !== undefined, `${id} should have a family assigned`);
  }
});
