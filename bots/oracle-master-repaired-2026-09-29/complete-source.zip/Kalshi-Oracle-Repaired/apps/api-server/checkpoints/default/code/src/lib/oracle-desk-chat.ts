/**
 * oracle-desk-chat.ts
 *
 * Chat pane brain. Completions: Groq qwen/qwen3.8-27b when a Groq key is set
 * (preferred free Chat), else Gemini Flash (AI Studio), else desk snapshot.
 * Not OpenRouter. Not trading evaluate.
 *
 * Code tools (Gemini path only): read_file, list_dir, grep/search (read-only).
 * apply_patch / write_file / run_tests / bounce_api are REFUSED at runtime
 * (control-security): chat can inspect and propose diffs as text only. Full .ts/.tsx/.md/.json source,
 * not comment-only. HARD REJECT (no write, no spawn) for paperMode false,
 * EV/Kelly/9%/reserve/halt cuts, ENABLE SEV1/OTM/SP/PAPER_SCALP/hourly/perps/
 * SETTLEMENT_LAG/persist-mid/cheap-persist/panic fade, .env/keys/pem.
 * ARIA stays OFF.
 *
 * Control mutating tools (update_config, toggle_strategy, force_exit_trade,
 * apply-backtest-config, spawn_subagent, control_bot, reset_paper_sim,
 * run_shell) must never run from this completion path.
 */

import { labeledCanonicalAndModel } from "./kalshi-settle-label.js";
import { fillPathPWin } from "./organs/probability.js";
import { canonicalLagProjectedSettlement } from "./basis-lag-edge.js";
import { buildTradeDiagnostic } from "./trade-diagnostic.js";
import { loadPaperLedger } from "./paper-ledger.js";
import type { BotStatus } from "./trading-bot-types.js";
import {
  completeChatFreeLlm,
  geminiKeyPresent,
  groqKeyPresent,
  stripRawToolCallMarkup,
  containsRawToolCallMarkup,
  type EnvLike,
} from "./chat-free-llm.js";
import {
  isDefaultChatCommand,
  restoreDefaultSettings,
  type RestoreDefaultResult,
} from "./default-settings.js";
import {
  isBounceChatCommand,
  runChatCodeTool,
  scheduleDeskApiBounce,
} from "./chat-code-edit.js";
import { oracleV2ChatDoctrineCondensed } from "./organs/oracle-v2-doctrine.js";
import { runDeskAgent } from "./chat-agent.js";
import type { DeskToolDeps } from "./chat-desk-tools.js";
import {
  normalizeChatRole,
  USER_CHAT_TOOLS,
  USER_CHAT_REFUSAL,
  type ChatRole,
} from "./accounts/chat-policy.js";

export const ORACLE_MODEL = {
  id: "oracle",
  label: "Oracle",
  provider: "desk",
  tag: "this desk",
  free: true,
  available: true,
} as const;

export const GEMINI_FLASH_MODEL = {
  id: "gemini-flash",
  label: "Gemini Flash",
  provider: "google",
  tag: "free",
  free: true,
  available: true,
} as const;

export const GROQ_LLAMA_CHAT_MODEL = {
  id: "groq-llama",
  label: "Groq GPT-OSS 120B",
  provider: "groq",
  tag: "free",
  free: true,
  available: true,
} as const;

export type ChatModelId = "oracle" | "groq-llama" | "gemini-flash";

export const ORACLE_MODELS_RESPONSE = [ORACLE_MODEL];

export function chatModelsCatalog(env: EnvLike = process.env) {
  const list: Array<{
    id: string;
    label: string;
    provider: string;
    tag: string;
    free: boolean;
    available: boolean;
  }> = [{ ...ORACLE_MODEL }];
  // Groq first in picker when keyed (preferred free Chat).
  if (groqKeyPresent(env)) list.push({ ...GROQ_LLAMA_CHAT_MODEL });
  if (geminiKeyPresent(env)) list.push({ ...GEMINI_FLASH_MODEL });
  return list;
}

/** Default Chat picker: groq-llama when Groq key, else gemini-flash, else oracle. */
export function defaultChatModel(env: EnvLike = process.env): ChatModelId {
  if (groqKeyPresent(env)) return "groq-llama";
  if (geminiKeyPresent(env)) return "gemini-flash";
  return "oracle";
}

/**
 * Honor oracle / groq-llama / gemini-flash when valid.
 * Ignore OpenRouter/Claude/auto slugs.
 */
export function resolveChatModel(override?: string | null, env: EnvLike = process.env): ChatModelId {
  const o = (override ?? "").trim();
  if (o === "oracle") return "oracle";
  if (o === "groq-llama" && groqKeyPresent(env)) return "groq-llama";
  if (o === "groq-llama") return defaultChatModel(env);
  if (o === "gemini-flash" && geminiKeyPresent(env)) return "gemini-flash";
  if (o === "gemini-flash") return defaultChatModel(env);
  return defaultChatModel(env);
}

export function shouldAttemptFreeLlm(model: ChatModelId, env: EnvLike = process.env): boolean {
  if (model === "groq-llama") return groqKeyPresent(env);
  if (model === "gemini-flash") return geminiKeyPresent(env) || groqKeyPresent(env);
  // Explicit Oracle while a free LLM key exists → snapshot only (no rented model).
  if (groqKeyPresent(env) || geminiKeyPresent(env)) return false;
  return false;
}

export const MUTATING_CHAT_TOOLS = [
  "update_config",
  "toggle_strategy",
  "force_exit_trade",
  "apply-backtest-config",
  "spawn_subagent",
  "control_bot",
  "reset_paper_sim",
  "run_backtest",
  "run_shell",
] as const;

export interface DeskTrade {
  side: string;
  contracts: number;
  entryPriceCents: number;
  outcome: string;
  pnlCents: number | null;
  signal: string;
  createdAt: string;
}

export interface DeskSnapshot {
  state: string;
  lastSignal: string;
  paperMode: boolean;
  autoMode: boolean;
  useExpertAgent: boolean;
  enable1HContracts: boolean;
  paperVirtualCents: number;
  paperLedgerCents: number | null;
  todayWins: number;
  todayLosses: number;
  todayPnlCents: number;
  consecutiveLosses: number;
  detectedRegime: string | null;
  activeStrategy: string | null;
  secsRemaining: number;
  classification: string;
  headline: string;
  recommendation: string;
  activeBlockers: string[];
  trades: DeskTrade[];
  /** basisState.projectedSettlementPrice — labeled, not silently swapped with the model. */
  basisProj: number | null;
  /** lastSettlementPrediction.predictedSettle */
  modelProj: number | null;
  projLine: string;
  /** P0 pack — log only. Not a fill allowlist. */
  packId?: string | null;
  packSkipReason?: string | null;
  skipReason?: string | null;
  /** Ticket p = fill-path winRateAtPrice. Never binary P(YES), never a side pick. */
  ticketP?: number | null;
  /** Fail-closed: missing basis → lag stale. Display only. */
  lagStale?: boolean;
  regimeRtLine?: string | null;
}

export interface GatherDeps {
  getStatus: () => BotStatus;
  getRecentTrades: (limit: number) => Promise<unknown>;
}

function num(v: unknown, fallback = 0): number {
  return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}

function str(v: unknown, fallback = ""): string {
  return typeof v === "string" ? v : fallback;
}

function dollars(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

function asTradeRows(raw: unknown): DeskTrade[] {
  if (!Array.isArray(raw)) return [];
  return raw.slice(0, 15).map((row) => {
    const r = (row ?? {}) as Record<string, unknown>;
    const created = r.createdAt instanceof Date
      ? r.createdAt.toISOString()
      : str(r.createdAt, "");
    return {
      side: str(r.side, "?"),
      contracts: num(r.contracts, 0),
      entryPriceCents: num(r.entryPriceCents, 0),
      outcome: str(r.outcome, "pending"),
      pnlCents: r.pnlCents == null ? null : num(r.pnlCents, 0),
      signal: str(r.signal, ""),
      createdAt: created,
    };
  });
}

export async function gatherOracleDeskSnapshot(deps: GatherDeps): Promise<DeskSnapshot> {
  const status = deps.getStatus();
  const cfg = status.config as BotStatus["config"];
  let trades: DeskTrade[] = [];
  try {
    const raw = await Promise.race([
      deps.getRecentTrades(15),
      new Promise<unknown>((resolve) => setTimeout(() => resolve([]), 400)),
    ]);
    trades = asTradeRows(raw);
  } catch {
    trades = [];
  }
  const diagnostic = buildTradeDiagnostic(status);
  const startCents = num(cfg.paperStartingBalanceCents, 31_300);
  let paperLedgerCents: number | null = null;
  try {
    const ledger = loadPaperLedger(startCents);
    if (ledger) paperLedgerCents = ledger.virtualCents;
  } catch {
    paperLedgerCents = null;
  }
  const canon = canonicalLagProjectedSettlement({
    liveProj: status.lastObservation?.projectedSettlementPrice ?? status.canonicalLagProj,
    snapshotProj: status.basisState?.projectedSettlementPrice,
    floor: status.floorStrike,
  });
  const modelProj = status.lastSettlementPrediction?.predictedSettle ?? null;
  // Always labeled canonical vs model — never a silent pick, never lastModelProb as p.
  const proj = labeledCanonicalAndModel(canon, modelProj);
  const rt = status.regimeRt;
  const regimeRtLine = rt
    ? `R_t ${rt.vol}/${rt.shape}/${rt.cycleMicro}/${rt.cycleHtf} conf=${rt.confidence.toFixed(2)} lagUsed=${rt.lagUsed}`
    : null;
  return {
    state: str(status.state, "UNKNOWN"),
    lastSignal: str(status.lastSignal, ""),
    paperMode: cfg.paperMode !== false,
    autoMode: cfg.autoMode === true,
    useExpertAgent: cfg.useExpertAgent === true,
    enable1HContracts: cfg.enable1HContracts === true,
    paperVirtualCents: num(status.paperVirtualBalanceCents, startCents),
    paperLedgerCents,
    todayWins: num(status.todayWins, 0),
    todayLosses: num(status.todayLosses, 0),
    todayPnlCents: num(status.todayPnlCents, 0),
    consecutiveLosses: num(status.consecutiveLosses, 0),
    detectedRegime: status.detectedRegime ?? null,
    activeStrategy: status.activeStrategy ?? null,
    secsRemaining: num(status.secsRemaining, 0),
    classification: diagnostic.classification,
    headline: diagnostic.headline,
    recommendation: diagnostic.recommendation,
    activeBlockers: diagnostic.activeBlockers,
    trades,
    basisProj: proj.basis,
    modelProj: proj.model,
    projLine: proj.line,
    packId: status.regimePack?.packId ?? null,
    packSkipReason: status.regimePack?.skipReason ?? null,
    skipReason: status.regimePack?.skipReason ?? null,
    ticketP: fillPathPWin(status.liveModelProb) ?? fillPathPWin(status.lastModelProb) ?? null,
    lagStale: status.basisState?.lagStale ?? status.lastObservation?.lagStale ?? true,
    regimeRtLine,
  };
}

const CONTROL_MUTATE = /\b(force.?exit|apply.{0,24}backtest|spawn.?subagent|toggle_strategy|update_config|run_shell|reset_paper_sim|control_bot|agent_directive|agent_config|agent_entry|agent_exit|HALT_ENTRIES|RESUME_ENTRIES|SKIP_NEXT|SIT_UNTIL)\b/i;
const IDLE_Q = /\b(why.*(not|isn'?t|no).*(trad|enter|fill)|waiting|idle|quiet|skip|blocked|diagnos|gate.?by.?gate|readiness|should i trade)\b/i;
const STATUS_Q = /\b(status|balance|ledger|pnl|p&l|paper|open trade|position|how much)\b/i;
const FORBIDDEN_LOOSEN = /\b(lower (the )?(ev|floor)|cut (the )?ev|enable (confluence|dead|sakata|brti|mtf_aligned|velocity_stall)|paperMode\s*false|turn on (aria|expert)|autoMode\s*true)\b/i;

function locksLine(s: DeskSnapshot): string {
  const cash = s.paperLedgerCents ?? s.paperVirtualCents;
  const mode = s.paperMode ? `PAPER ${dollars(cash)}` : "LIVE (desk lock is paper)";
  const h1 = s.enable1HContracts ? "1h ON (unexpected)" : "15m-only";
  const aria = s.useExpertAgent ? "ARIA ON (unexpected)" : "ARIA OFF";
  const composer = s.autoMode ? "composer ON (unexpected)" : "composer OFF";
  return `${mode} · ${s.state} · ${h1} · ${composer} · ${aria}`;
}

function doctrineLine(): string {
  return [
    "EV floors frozen (3¢ / 5¢ OTM). p = winRateAtPrice, not confidence. Skip is valid. Still-mid 40–65¢ confluence in unclear does not fire. Do not cut EV or enable dead engines.",
    "ORACLE_V2: proposal/research OS loaded (ORACLE_READY). Default ABSTAIN. Never invent fills. Tick stays LLM-free. Proposal kelly_mult=0.20; live Kelly≤0.60.",
  ].join(" ");
}

function tradeLines(s: DeskSnapshot): string {
  if (s.trades.length === 0) return "No recent bot trades in snapshot.";
  return s.trades.slice(0, 8).map((t) => {
    const pnl = t.pnlCents == null ? "" : ` ${t.pnlCents > 0 ? "+" : ""}${t.pnlCents}¢`;
    return `${t.side.toUpperCase()} ${t.contracts}× @${t.entryPriceCents}¢ → ${t.outcome}${pnl} [${t.signal}]`;
  }).join("\n");
}

function diagnosisBody(s: DeskSnapshot): string {
  const blockers = s.activeBlockers.length > 0
    ? s.activeBlockers.map((b) => `- ${b}`).join("\n")
    : "- No hard blockers. This is a wait, not a bug.";
  const last = s.lastSignal ? `Last signal: ${s.lastSignal}` : "Last signal: (none recorded)";
  const regime = s.detectedRegime ?? "unclassified";
  const strat = s.activeStrategy ?? "none firing";
  return [
    `Classification: ${s.classification}`,
    s.headline,
    `Recommendation: ${s.recommendation}`,
    last,
    `Regime: ${regime} · strategy: ${strat} · ${Math.floor(s.secsRemaining / 60)}m ${s.secsRemaining % 60}s left · today ${s.todayWins}W/${s.todayLosses}L · consecLosses=${s.consecutiveLosses}`,
    s.projLine,
    s.regimeRtLine ? s.regimeRtLine : "R_t n/a",
    `ticket p=${s.ticketP == null ? "n/a" : s.ticketP.toFixed(3)} · lag stale=${s.lagStale !== false ? "true" : "false"}`,
    `Pack ${s.packId ?? "n/a"} (log-only, not a fill gate)${s.skipReason ?? s.packSkipReason ? ` · skipReason ${s.skipReason ?? s.packSkipReason}` : ""}`,
    "Blockers:",
    blockers,
  ].join("\n");
}

const GROK_BOT_REDIRECT =
  "Strategy/code lives in the Grok Bot Oracle chat; this pane is the desk brain without a rented model.";

export function answerOracleDesk(question: string, snapshot: DeskSnapshot): string {
  const q = question.trim() || "(empty)";

  if (FORBIDDEN_LOOSEN.test(q)) {
    return [
      "Oracle · no.",
      locksLine(snapshot),
      doctrineLine(),
      "I will not cut EV floors, enable dead engines, flip paperMode false, or turn ARIA/composer on. Skip is a valid outcome.",
      GROK_BOT_REDIRECT,
    ].join("\n");
  }

  if (CONTROL_MUTATE.test(q)) {
    return [
      "Oracle · desk pane will not run control mutating tools.",
      locksLine(snapshot),
      "For halt / resume / approve / FORCE EXIT / agent directives — use the in-app Chat page (/chat → POST /api/agent/chat) which owns the agent control plane tools.",
      "I can inspect desk source (read_file / list_dir / grep) and propose diffs as text for review. The desk brain never writes files, runs tests or restarts processes at runtime. I will not spawn subagents, apply backtests, toggle engines, force_exit, or run a general shell.",
    ].join("\n");
  }

  if (IDLE_Q.test(q) || /why/i.test(q)) {
    return [
      "Oracle · desk diagnosis",
      locksLine(snapshot),
      doctrineLine(),
      "",
      diagnosisBody(snapshot),
    ].join("\n");
  }

  if (STATUS_Q.test(q)) {
    const cash = snapshot.paperLedgerCents ?? snapshot.paperVirtualCents;
    const ledgerNote = snapshot.paperLedgerCents != null
      ? `Paper ledger ${dollars(snapshot.paperLedgerCents)} (virtual ${dollars(snapshot.paperVirtualCents)}).`
      : `Paper virtual ${dollars(cash)}.`;
    return [
      "Oracle · snapshot",
      locksLine(snapshot),
      ledgerNote,
      `Today ${snapshot.todayWins}W/${snapshot.todayLosses}L  P&L ${snapshot.todayPnlCents >= 0 ? "+" : ""}${(snapshot.todayPnlCents / 100).toFixed(2)}`,
      diagnosisBody(snapshot),
      "",
      "Recent trades:",
      tradeLines(snapshot),
      "",
      doctrineLine(),
    ].join("\n");
  }

  if (/\b(ticket|research|oracle_ready|oracle v2|abstain|propose)\b/i.test(q)) {
    return [
      "Oracle · ORACLE_READY (proposal/research)",
      locksLine(snapshot),
      doctrineLine(),
      "",
      oracleV2ChatDoctrineCondensed(),
      "",
      diagnosisBody(snapshot),
    ].join("\n");
  }

  return [
    "Oracle · desk brain (no rented model).",
    locksLine(snapshot),
    diagnosisBody(snapshot),
    "",
    doctrineLine(),
    "Code inspection: read_file, list_dir, grep when Gemini Flash is on — read/propose-only (no runtime writes, tests or bounce). Type default to restore frozen settings. ARIA stays off.",
  ].join("\n");
}

export function chunkForSse(text: string, wordsPerChunk = 8): string[] {
  const parts = text.split(/(\s+)/);
  const chunks: string[] = [];
  let buf = "";
  let words = 0;
  for (const part of parts) {
    buf += part;
    if (/\S/.test(part)) words += 1;
    if (words >= wordsPerChunk) {
      chunks.push(buf);
      buf = "";
      words = 0;
    }
  }
  if (buf) chunks.push(buf);
  return chunks.length > 0 ? chunks : [text];
}

export interface OracleDeskChatOpts {
  question: string;
  snapshot: DeskSnapshot;
  modelOverride?: string | null;
  env?: EnvLike;
  fetchImpl?: typeof fetch;
  deskRoot?: string;
  /** Full Chat thread so Gemini/Groq can talk, not one-shot auto replies. */
  messages?: { role: string; content: string }[];
  /** Chat `default` restore. Skip Gemini. Never paperMode false. */
  restoreDefault?: () => RestoreDefaultResult;
  bounceApi?: () => { ok: boolean; refused?: boolean; reason?: string; summary?: string };
  /** R2 — live desk tool deps. When present the round-2 agent (routing +
   *  native tools + propose_fix) answers instead of the legacy loop. */
  deskTools?: DeskToolDeps;
  /**
   * Server-side role of the authenticated account (accounts/chat-policy.ts).
   * Missing → "USER" (fail closed). Only "ADMIN" may bounce the API, restore
   * default settings, read source / logs or propose PRs from chat.
   */
  chatRole?: ChatRole;
}

export type OracleSseEvent =
  | { type: "tool_start"; name: string; label: string }
  | { type: "tool_done"; name: string; summary: string }
  | { type: "delta"; content: string }
  | { type: "meta"; model: string | null; provider: string | null; fallback: boolean; error?: string }
  | { type: "done" };

/** Chat tools that would mutate files/processes; always refused at runtime. */
export const RUNTIME_REFUSED_CHAT_TOOLS = new Set(["write_file", "apply_patch", "run_tests", "bounce_api"]);

/** Replace any false success claim after a refused mutating tool call. */
export function honestAfterRefusedMutation(answer: string, refused: string[]): string {
  const names = [...new Set(refused)].join(", ");
  const note = `${names} refused — desk chat is read/propose-only; no file was written and nothing was run.`;
  const claimsSuccess = /\b(wrote|written|applied|patched|saved|created|updated|ran tests|bounced|restarted)\b/i.test(answer);
  if (!answer || claimsSuccess) return note;
  return `${note}\n\n${answer}`;
}

/** Last agent routing meta (model/provider/attempts) — surfaced for ops/tests. */
export let lastAgentMeta: unknown = null;

export async function* oracleDeskChatEvents(opts: OracleDeskChatOpts): AsyncGenerator<OracleSseEvent> {
  const env = opts.env ?? process.env;
  const model = resolveChatModel(opts.modelOverride, env);
  const s = opts.snapshot;
  const cash = s.paperLedgerCents ?? s.paperVirtualCents;
  const role = normalizeChatRole(opts.chatRole);

  // Privileged chat commands are ADMIN-only (server-side role, never the prompt).
  if (role !== "ADMIN" && (isBounceChatCommand(opts.question) || isDefaultChatCommand(opts.question))) {
    yield { type: "tool_start", name: "permission_check", label: "Checking account permissions…" };
    yield { type: "tool_done", name: "permission_check", summary: "Administrator only" };
    for (const chunk of chunkForSse(USER_CHAT_REFUSAL)) yield { type: "delta", content: chunk };
    yield { type: "done" };
    return;
  }

  if (isBounceChatCommand(opts.question)) {
    yield { type: "tool_start", name: "bounce_api", label: "Bouncing API (:8080 only)…" };
    const bounced = (opts.bounceApi ?? scheduleDeskApiBounce)();
    yield {
      type: "tool_done",
      name: "bounce_api",
      summary: bounced.ok
        ? "API bounce scheduled — Vite/tunnel untouched"
        : ("refused" in bounced && bounced.refused
          ? (bounced.reason ?? "bounce failed")
          : "bounce failed"),
    };
    const msg = bounced.ok
      ? "API bounce scheduled. Only api-server on :8080 restarts. Vite :5173 and cloudflared stay up. paperMode stays paper. Floors unchanged. Watch /tmp/api-server-bounce.log."
      : `Could not bounce API (${"reason" in bounced ? bounced.reason : "unknown"}). Vite/tunnel left alone.`;
    for (const chunk of chunkForSse(msg)) {
      yield { type: "delta", content: chunk };
    }
    yield { type: "done" };
    return;
  }

  if (isDefaultChatCommand(opts.question)) {
    yield { type: "tool_start", name: "restore_default_settings", label: "Restoring frozen SETTINGS…" };
    let restored: RestoreDefaultResult;
    try {
      restored = (opts.restoreDefault ?? restoreDefaultSettings)();
    } catch {
      restored = {
        ok: false,
        reason: "restore threw",
        confirmation: "Could not restore default settings. Config and ledger left as-is. paperMode stays paper.",
        snapshotPath: "",
        configPath: "",
        codeFilesRestored: [],
        bounceRequired: false,
      };
    }
    yield {
      type: "tool_done",
      name: "restore_default_settings",
      summary: restored.ok ? "paperMode true · EV/Kelly unchanged" : restored.reason,
    };
    for (const chunk of chunkForSse(restored.confirmation)) {
      yield { type: "delta", content: chunk };
    }
    yield { type: "done" };
    return;
  }

  const q = opts.question.trim() || "(empty)";
  const localRefuse = FORBIDDEN_LOOSEN.test(q) || CONTROL_MUTATE.test(q);
  const tryLlm = !localRefuse && shouldAttemptFreeLlm(model, env);

  // Snapshot auto-tools only when we are NOT going to Gemini — otherwise the
  // tab looks like a canned diagnosis instead of a chatbot.
  if (!tryLlm) {
    yield { type: "tool_start", name: "get_full_status", label: "Reading live desk…" };
    yield {
      type: "tool_done",
      name: "get_full_status",
      summary: `${s.paperMode ? "Paper" : "Live"} ${dollars(cash)} · ${s.state}`,
    };
    yield { type: "tool_start", name: "diagnose_trade_readiness", label: "Diagnosing why idle…" };
    yield {
      type: "tool_done",
      name: "diagnose_trade_readiness",
      summary: s.classification,
    };
  }

  let answer = "";
  if (tryLlm && opts.deskTools) {
    try {
      const gen = runDeskAgent({
        question: opts.question,
        history: Array.isArray(opts.messages) ? opts.messages : [],
        deps: { ...opts.deskTools, userMessage: opts.question },
        env: env as Record<string, string | undefined>,
        fetchImpl: opts.fetchImpl,
        // USER accounts: read-only desk facts only (no source, logs or PRs).
        allowedTools: role === "ADMIN" ? undefined : USER_CHAT_TOOLS,
      });
      let step = await gen.next();
      while (!step.done) {
        const ev = step.value;
        if (ev.type === "tool_start" || ev.type === "tool_done") yield ev;
        else if (ev.type === "meta") {
          lastAgentMeta = ev;
          // Surface which free model answered (and whether a fallback happened) — never keys.
          const failedBefore = (ev.attempts ?? []).some((x) => x.outcome !== "ok");
          yield { type: "meta", model: ev.model, provider: ev.provider, fallback: failedBefore, ...(ev.error ? { error: ev.error } : {}) };
        }
        step = await gen.next();
      }
      answer = step.value.failed
        ? `${step.value.text}\n\n${answerOracleDesk(opts.question, s)}`
        : step.value.text;
    } catch {
      answer = `Chat agent error (not a model failure) — desk snapshot below.\n\n${answerOracleDesk(opts.question, s)}`;
    }
  } else if (tryLlm) {
    try {
      const llm = await completeChatFreeLlm({
        question: opts.question,
        snapshot: s,
        env,
        fetchImpl: opts.fetchImpl,
        // Groq + Gemini both get tools. Groq may emit XML tool text — parse+execute+strip.
        preferGroq: model !== "gemini-flash",
        messages: opts.messages,
        // Code tools (read_file / list_dir / grep) are ADMIN-only.
        toolsEnabled: role === "ADMIN",
        runTool: (name, args) => role === "ADMIN"
          ? runChatCodeTool(name, args, { userMessage: opts.question, deskRoot: opts.deskRoot })
          : { ok: false, refused: true, reason: USER_CHAT_REFUSAL },
      });
      const refusedMutations: string[] = [];
      if (llm?.toolEvents) {
        for (const te of llm.toolEvents) {
          if (te.type === "tool_done" && RUNTIME_REFUSED_CHAT_TOOLS.has(te.name)) refusedMutations.push(te.name);
          yield te;
        }
      }
      if (llm?.text) answer = llm.text;
      // Honesty: runtime writes/tests/bounces are always refused. If the model
      // claims it wrote or applied something anyway, replace the claim.
      if (refusedMutations.length > 0) {
        answer = honestAfterRefusedMutation(answer, refusedMutations);
      }
    } catch {
      // fail-closed: snapshot answer, never throw a raw 500 from Chat
    }
  }
  if (!answer) answer = answerOracleDesk(opts.question, s);
  // Stellar lock: never stream raw tool XML or HTTP dumps to Chat UX.
  if (containsRawToolCallMarkup(answer)) {
    answer = stripRawToolCallMarkup(answer)
      || "Desk tools ran server-side. Locks still hold (paper, EV floors, ARIA off).";
  }

  for (const chunk of chunkForSse(answer)) {
    yield { type: "delta", content: chunk };
  }
  yield { type: "done" };
}
