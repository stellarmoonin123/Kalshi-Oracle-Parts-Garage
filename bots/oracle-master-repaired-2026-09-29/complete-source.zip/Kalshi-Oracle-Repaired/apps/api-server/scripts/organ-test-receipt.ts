/**
 * R3 — regenerate src/lib/organ-debug/organ-test-receipt.json.
 * Runs every money-path organ's unit tests and binds the result to a sha256 of
 * that organ's source files. Run after changing any organ source:
 *   pnpm --filter @workspace/api-server organ-receipt
 * Exits non-zero if any organ's tests fail (receipt is still written, honestly).
 */
import { writeFileSync } from "node:fs";
import path from "node:path";
import { MONEY_PATH_ORGANS } from "../src/lib/organ-debug/registry.js";
import { runOrganTestsForReceipt } from "./organ-test-runner.js";
import { LIB_ROOT } from "../src/lib/organ-debug/hard-locks.js";
import { hashOrganSources, ORGAN_TEST_RECEIPT_FILE, type OrganTestReceipt } from "../src/lib/organ-debug/test-receipt.js";

const organs: OrganTestReceipt["organs"] = [];
let bad = 0;
for (const entry of MONEY_PATH_ORGANS) {
  const sha = hashOrganSources(entry.sourcePaths, LIB_ROOT);
  const unitTests = await runOrganTestsForReceipt(entry);
  if (!(unitTests.ok === true && unitTests.passed > 0)) bad++;
  console.log(`${entry.id}: ran=${unitTests.ran} ok=${unitTests.ok} pass=${unitTests.passed} fail=${unitTests.failed}`);
  organs.push({ organId: entry.id, sourceSha256: sha ?? "missing-source", unitTests });
}
const receipt: OrganTestReceipt = {
  schemaVersion: 1,
  generatedAt: new Date().toISOString(),
  generator: "scripts/organ-test-receipt.ts",
  organs,
};
writeFileSync(path.join(LIB_ROOT, ORGAN_TEST_RECEIPT_FILE), JSON.stringify(receipt, null, 2) + "\n");
console.log(`receipt written: ${organs.length} organs, ${bad} not passing`);
process.exit(bad ? 1 : 0);
