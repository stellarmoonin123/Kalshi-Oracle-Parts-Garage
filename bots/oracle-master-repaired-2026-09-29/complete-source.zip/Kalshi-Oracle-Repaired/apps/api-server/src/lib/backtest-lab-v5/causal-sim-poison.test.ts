import assert from "node:assert/strict";
import test from "node:test";
import { runPoisonTest } from "./regression-runner.js";
import { POLICY_LEAN } from "./sim-policy.js";
import type { RealCandle } from "../market-candles.js";

/**
 * GO — BACKTEST LAB v5 (2026-08-22): the causal-safety proof.
 *
 * Builds a deterministic synthetic 5-min candle series (no network — this
 * must run fast and offline in CI) and asserts that every minute-5/minute-10
 * decision computed against the REAL series is byte-identical to the same
 * decision computed against a series whose POST-decision candles have been
 * scrambled. A single mismatch would mean a "causal" decision is secretly
 * reading future data.
 */
function buildSyntheticCandles(n: number): RealCandle[] {
  // Deterministic pseudo-random walk (LCG) — no Math.random dependency, so
  // this test is reproducible independent of the module's own seeded-RNG
  // plumbing (which only governs buildSimObs's simulated quotes, not this
  // input series).
  let seed = 42;
  const rnd = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return seed / 0x7fffffff;
  };
  const candles: RealCandle[] = [];
  let price = 65000;
  const startTime = 1_700_000_000; // arbitrary fixed unix seconds, aligned to a 5-min boundary
  for (let i = 0; i < n; i++) {
    const open = price;
    const drift = (rnd() - 0.5) * 120;
    const close = open + drift;
    const high = Math.max(open, close) + rnd() * 20;
    const low = Math.min(open, close) - rnd() * 20;
    const volume = 50 + rnd() * 100;
    candles.push({ time: startTime + i * 300, open, high, low, close, volume });
    price = close;
  }
  return candles;
}

test("BACKTEST LAB v5 poison test: decisions never depend on post-decision candles", () => {
  const candles = buildSyntheticCandles(300); // 100 periods worth
  const result = runPoisonTest(candles, POLICY_LEAN);
  assert.ok(result.periodsChecked > 0, "the synthetic series must produce at least one checkable decision point");
  assert.deepEqual(result.mismatches, [], `expected zero causal-safety mismatches, got: ${JSON.stringify(result.mismatches).slice(0, 500)}`);
  assert.equal(result.passed, true);
});
