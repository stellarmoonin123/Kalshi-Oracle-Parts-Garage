/**
 * cc-velocity-gate — CONFLUENCE_CASCADE velocity-against (#725).
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import {
  CC_VEL_AGAINST_ABS_DOL_PER_MIN,
  ccVelocityAgainstGate,
} from "./cc-velocity-gate.js";

test("cc-velocity-gate: floor 40 $/min; missing vel does not block", () => {
  assert.equal(CC_VEL_AGAINST_ABS_DOL_PER_MIN, 40);
  assert.deepEqual(
    ccVelocityAgainstGate({ strategyId: "CONFLUENCE_CASCADE", side: "no", velocityDolPerMin: null }),
    { block: false },
  );
  assert.deepEqual(
    ccVelocityAgainstGate({ strategyId: "BASIS_LAG_EDGE", side: "no", velocityDolPerMin: 99 }),
    { block: false },
  );
});

test("cc-velocity-gate: blocks NO into strong green / YES into strong red", () => {
  const no = ccVelocityAgainstGate({
    strategyId: "CONFLUENCE_CASCADE",
    side: "no",
    velocityDolPerMin: 56,
  });
  assert.equal(no.block, true);
  if (no.block) {
    assert.equal(no.reason, "CC_VEL_AGAINST_NO");
    assert.equal(no.size, 0);
  }

  const yes = ccVelocityAgainstGate({
    strategyId: "CONFLUENCE_CASCADE",
    side: "yes",
    velocityDolPerMin: -56,
  });
  assert.equal(yes.block, true);
  if (yes.block) assert.equal(yes.reason, "CC_VEL_AGAINST_YES");

  assert.deepEqual(
    ccVelocityAgainstGate({
      strategyId: "CONFLUENCE_CASCADE",
      side: "no",
      velocityDolPerMin: 10,
    }),
    { block: false },
  );
});
