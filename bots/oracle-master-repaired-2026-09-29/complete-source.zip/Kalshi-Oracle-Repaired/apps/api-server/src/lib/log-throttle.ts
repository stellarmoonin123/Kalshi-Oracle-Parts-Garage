/**
 * D14 — per-key log throttle. The first line for a key is emitted; repeats
 * inside `windowMs` are counted and suppressed; the next emit after the window
 * carries "(+N suppressed)". Keys should be ticker+reason with volatile numbers
 * stripped (see `throttleKey`). Pure/in-memory; never affects trading.
 */
export class LogThrottle {
  private last = new Map<string, { atMs: number; suppressed: number }>();
  constructor(private readonly windowMs = 60_000, private readonly maxKeys = 500) {}

  /** Returns the message to emit (with suppressed count) or null to suppress. */
  gate(key: string, message: string, nowMs = Date.now()): string | null {
    const prev = this.last.get(key);
    if (prev && nowMs - prev.atMs < this.windowMs) {
      prev.suppressed += 1;
      return null;
    }
    const suppressed = prev?.suppressed ?? 0;
    this.last.set(key, { atMs: nowMs, suppressed: 0 });
    if (this.last.size > this.maxKeys) {
      for (const [k, v] of this.last) {
        if (nowMs - v.atMs > this.windowMs * 10) this.last.delete(k);
      }
    }
    return suppressed > 0 ? `${message} (+${suppressed} suppressed in last ${Math.round(this.windowMs / 1000)}s)` : message;
  }
}

/** Stable key: ticker kept verbatim; reason parts have digits stripped so
 *  "edge −18.11¢" and "edge −17.9¢" collapse. */
export function throttleKey(ticker: string | null | undefined, ...parts: Array<string | null | undefined>): string {
  return [String(ticker ?? ""), ...parts.map((p) => String(p ?? "").replace(/[-−+]?\d+(\.\d+)?/g, "#"))].join("|");
}

/**
 * D3 — since-boot entry funnel counters (TAKE signals vs Mind/brain blocks by
 * reason). Exposed on bot status so blocks are countable even when the log and
 * trace rows are throttled.
 */
export class EntryFunnelCounter {
  readonly sinceMs = Date.now();
  private counts = new Map<string, number>();
  bump(key: string, n = 1): void {
    this.counts.set(key, (this.counts.get(key) ?? 0) + n);
  }
  snapshot(): { sinceMs: number; counts: Record<string, number> } {
    return { sinceMs: this.sinceMs, counts: Object.fromEntries([...this.counts.entries()].sort((a, b) => b[1] - a[1])) };
  }
}

/** Coarse block-reason bucket for counters: stamp + reason with numbers stripped, capped. */
export function blockReasonBucket(stamp: string, reason: string): string {
  const r = String(reason ?? "").replace(/[-−+]?\d+(\.\d+)?/g, "#").replace(/\s+/g, " ").trim().slice(0, 80);
  return `${stamp}:${r}`;
}
