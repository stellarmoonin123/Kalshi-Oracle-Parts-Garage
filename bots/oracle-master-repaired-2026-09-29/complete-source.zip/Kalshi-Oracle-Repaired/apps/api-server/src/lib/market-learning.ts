/**
 * market-learning.ts — Plane R (research/observational) market-wide study.
 *
 * Continuously records a feature snapshot of the CURRENT 15m KXBTC contract
 * every tick, for every contract Kalshi lists — independent of whether the
 * bot is enabled, in paper/live mode, or holding a position. This is
 * deliberately broader than bot_trades (trade-scoped) or meta-labeling.ts
 * (decision-evaluation-scoped): the goal is a full census of contracts, so
 * base rates aren't biased toward whatever the bot happened to trade.
 *
 * 1s shadow sampler (2026-08-26): independentSnapshotTick runs every 1s and
 * records an in-memory quote sample for EVERY active KXBTC15M contract
 * (taken or skipped). Samples flush to research/ticks/*.jsonl every ~5s and
 * on rollover. SQL market_observations stay coarse (~15s or a meaningful
 * quote change) so the DB does not melt. Contract-close labels land in
 * research/contract-labels.jsonl; aggregate shadow counts in
 * research/shadow-learn.json. NONE of that path is allowed to change live
 * gates, EV, autoMode, paperMode, or LIVE_APPLY_ENABLED (stays false).
 *
 * Rows start "pending" (settledDirection null) and are resolved by
 * period-recorder.ts the instant a period's outcome is known.
 *
 * ── Plane R → Plane L crossing ──────────────────────────────────────────
 * `getMarketBaseRateAdjustment()` is the ONE function in this file allowed
 * to influence a live decision. Per the user's explicit written policy
 * (see .agents/memory/research-memory-plane-r-foundation.md, P1-P6) and the
 * explicit "implement that into live trade decisions" authorization given
 * 2026-08-23, this crossing is real but deliberately bounded:
 *   - returns 0 (no-op) below MIN_SAMPLE_SIZE — an empty/thin table must
 *     never fabricate a confident-looking adjustment.
 *   - magnitude capped at ±MAX_ADJUSTMENT (small, confidence-space, additive
 *     — same shape as the existing psych-level discount / signal-stack
 *     bonus, not a new gate and not a floor change).
 *   - never touches quarantine, EV floors, PATH_GATE, Kelly/maxContracts,
 *     or autoMode. Consumers apply it once, log it, and clamp the result.
 *   - LIVE_APPLY_ENABLED starts false: the recorder/resolver run
 *     immediately (there's no reason to delay collecting data), but the
 *     live confidence nudge stays in shadow-log-only mode until there is
 *     enough resolved history for MIN_SAMPLE_SIZE to mean something. Flip
 *     via bot config once `getMarketLearningReadiness()` reports ready.
 */

import { db, marketObservations } from "@workspace/db";
import { and, eq, gte, inArray, isNotNull, sql } from "drizzle-orm";
import { mtfAnalyzer, type MTFSummary } from "./mtf-analyzer";
import { basisTracker, type BasisState } from "./basis-tracker";
import { computeLiveHtfStructure } from "./mtf-structure.js";
import { stampFromLive, stampTickLag, type HtfTapeSummary, type LagClass } from "./tick-tape-labels.js";
import { ingestChart1sTick } from "./tape-1s-candles.js";
import { candlePatternAnalyzer, type CandlePatternSignal } from "./candlestick-patterns";
import { kalshiWS } from "./kalshi-ws.js";
import { inferBtcPrice } from "./kalshi-price.js";
import {
  trackDisplacement,
  computeSpreadCents,
  proxyVolumeScore,
  currentSessionLabel,
  maybeLogShadowDecision,
  resolveMarketLearningV2ForPeriod,
  startMarketLearningV2,
} from "./market-learning-v2.js";
import {
  computeLiveVolumeScore,
  maybeLogShadowDecisionV4,
  startMarketLearningV4,
} from "./market-learning-v4.js";
import { startModelPromotionEvaluator } from "./model-promotion.js";
import { resolveSkipsForTicker, resolveSkipsForPeriod } from "./skip-settlement-resolver.js";
import fs from "node:fs";
import path from "node:path";
import { kalshiSettleFromTruth } from "./kalshi-settle-label.js";
import { researchDir } from "./desk-data-dir.js";
// NOTE: deliberately NOT importing from period-recorder.ts here — that module
// imports resolveMarketObservationsForPeriod from this file, and a two-way
// import between them caused the unit-test process to hang on exit (some
// side effect of the cycle keeping an open handle alive). This tiny UTC
// 15-min boundary calc is duplicated from period-recorder.ts's
// currentPeriodStart() on purpose to keep this a one-way dependency.
function currentPeriodOpenTs(): Date {
  const ms = Date.now();
  return new Date(ms - (ms % (15 * 60 * 1000)));
}

const SNAPSHOT_THROTTLE_MS = 15_000; // coarse SQL cadence — 1s samples go to the in-memory ring / jsonl, not Postgres
const SNAPSHOT_QUOTE_CHANGE_MIN_MS = 5_000; // min gap for a "meaningful quote change" extra SQL row
const SNAPSHOT_QUOTE_CHANGE_CENTS = 2;
const MIN_SAMPLE_SIZE = 150;         // per bucket, before getMarketBaseRateAdjustment() returns anything but 0
const MAX_ADJUSTMENT = 0.03;         // ±3 confidence points, hard cap

/** Cheap-side band used only for shadow labels / stats. Not a live gate. */
export const CHEAP_ASK_MIN_CENTS = 7;
export const CHEAP_ASK_MAX_CENTS = 22;

const SAMPLE_INTERVAL_MS = 1_000;
const TICK_FLUSH_MS = 5_000;
const RING_CAP = 1_200; // ~20 min at 1 Hz; a 15m contract is ~900 samples
const RESEARCH_ROOT = researchDir();

/** Feature-flag gate for the Plane R → Plane L crossing. Off by default — see file header. */
export let LIVE_APPLY_ENABLED = false;
export function setMarketLearningLiveApply(enabled: boolean) {
  LIVE_APPLY_ENABLED = enabled;
  console.info(`[market-learning] Live-apply ${enabled ? "ENABLED — market base rates now nudge entry confidence" : "disabled — shadow-log only"}`);
}

let lastSnapshotAt = new Map<string, number>(); // ticker -> ms
let lastSnapshotQuote = new Map<string, { yesAsk: number | null; noAsk: number | null }>();

export function isCheapAsk(cents: number | null | undefined): boolean {
  return typeof cents === "number" && cents >= CHEAP_ASK_MIN_CENTS && cents <= CHEAP_ASK_MAX_CENTS;
}

export function pickCheapAsk(
  yesAsk: number | null | undefined,
  noAsk: number | null | undefined,
): { side: "YES" | "NO"; price: number } | null {
  const y = isCheapAsk(yesAsk);
  const n = isCheapAsk(noAsk);
  if (!y && !n) return null;
  if (y && n) {
    return (yesAsk! <= noAsk!)
      ? { side: "YES", price: yesAsk! }
      : { side: "NO", price: noAsk! };
  }
  if (y) return { side: "YES", price: yesAsk! };
  return { side: "NO", price: noAsk! };
}

export function tickJsonlFilename(tsMs: number, ticker: string): string {
  const ymd = new Date(tsMs).toISOString().slice(0, 10).replace(/-/g, "");
  const safe = ticker.replace(/[^A-Za-z0-9._-]+/g, "_");
  return `${ymd}-${safe}.jsonl`;
}

export function cheapSettledITM(
  cheapSide: "YES" | "NO" | null | undefined,
  settled: "YES" | "NO" | null | undefined,
): boolean | null {
  if (!cheapSide || !settled) return null;
  return cheapSide === settled;
}

function isDbSnapshotDue(
  ticker: string,
  yesAsk: number | null | undefined,
  noAsk: number | null | undefined,
): boolean {
  const now = Date.now();
  const last = lastSnapshotAt.get(ticker) ?? 0;
  if (last === 0) return true;
  const elapsed = now - last;
  if (elapsed >= SNAPSHOT_THROTTLE_MS) return true;
  if (elapsed < SNAPSHOT_QUOTE_CHANGE_MIN_MS) return false;
  const prev = lastSnapshotQuote.get(ticker);
  if (!prev) return true;
  const dy = Math.abs((yesAsk ?? 0) - (prev.yesAsk ?? 0));
  const dn = Math.abs((noAsk ?? 0) - (prev.noAsk ?? 0));
  return dy >= SNAPSHOT_QUOTE_CHANGE_CENTS || dn >= SNAPSHOT_QUOTE_CHANGE_CENTS;
}

export interface MarketSnapshotInput {
  ticker: string;
  periodOpenTs: Date;
  secsRemaining: number;
  floorStrike: number;
  fairPrice: number | null;
  mtf: MTFSummary | null;
  basis: BasisState | null;
  candlePattern: CandlePatternSignal | null;
  yesAskCents: number | null;
  noAskCents: number | null;
  // ── v4.1 additions (GO — MARKET-LEARNING v4.1, 2026-08-24) ────────────────
  // All optional/additive — existing callers that omit them still work.
  yesBidCents?: number | null;
  noBidCents?: number | null;
  /** Live price buffer + velocity for the REAL computeVolumeScore() (see
   *  market-learning-v4.ts's computeLiveVolumeScore). trading-bot.ts's tick
   *  supplies this (it already maintains `this.prices`/`this.currentVelocity`);
   *  this file's own independent driver below has no such buffer and omits
   *  it, so those rows simply get a null volumeScoreLive (excluded from the
   *  v4.1 model's training set, same as any other row missing a required
   *  feature — see market-learning-v4.ts's featureRowFrom). */
  liveVolumeInputs?: { prices: { price: number; ts: number }[]; velocityDolPerMin: number } | null;
}

/**
 * Records one snapshot row, throttled to SNAPSHOT_THROTTLE_MS per ticker.
 * Fire-and-forget: never awaited into the tick loop, swallows its own
 * errors (matches persistBasisSample's convention — a research write must
 * never be able to slow or break the live tick).
 */
export function recordMarketObservation(input: MarketSnapshotInput): void {
  const now = Date.now();
  if (!isDbSnapshotDue(input.ticker, input.yesAskCents, input.noAskCents)) return;
  lastSnapshotAt.set(input.ticker, now);
  lastSnapshotQuote.set(input.ticker, { yesAsk: input.yesAskCents ?? null, noAsk: input.noAskCents ?? null });

  const distFromFloorPct = input.fairPrice != null && input.floorStrike > 0
    ? ((input.fairPrice - input.floorStrike) / input.floorStrike) * 100
    : null;

  // ── Feature Store v2 additions (GO — MARKET-LEARNING v2, 2026-08-24) ──────
  // Computed here (not passed in via MarketSnapshotInput) so both callers
  // (trading-bot.ts's live tick, and this file's own independent driver
  // below) get them for free with no call-site changes.
  const leadExchangeDelta = input.basis?.shortBasis ?? null;
  const displacement      = trackDisplacement(input.ticker, input.periodOpenTs.getTime(), input.fairPrice);
  // v4.1: real bid-ask spread when bid data is present (yesAsk - yesBid),
  // falling back to v2's overround proxy (yesAsk+noAsk-100) only when bid
  // data isn't available (e.g. a caller that hasn't been updated yet).
  const spreadCents = input.yesBidCents != null && input.yesAskCents != null
    ? input.yesAskCents - input.yesBidCents
    : computeSpreadCents(input.yesAskCents, input.noAskCents);
  const volumeScore  = proxyVolumeScore(computeSpreadCents(input.yesAskCents, input.noAskCents)); // v2 proxy — untouched, kept for backward comparison
  const sessionLabel = currentSessionLabel();

  // v4.1 live-parity volumeScore (v3 gap-fix, see market-learning-v4.ts) —
  // only computed when the caller supplied a live price buffer; both real
  // callers (trading-bot.ts's tick, and this file's own independent driver
  // below) do.
  const volumeScoreLive = input.liveVolumeInputs
    ? computeLiveVolumeScore({
        prices: input.liveVolumeInputs.prices,
        velocityDolPerMin: input.liveVolumeInputs.velocityDolPerMin,
        yesAskCents: input.yesAskCents,
        yesBidCents: input.yesBidCents ?? null,
      })
    : null;

  // Shadow EV policy (log-only, never places an order) — one decision per
  // ticker+period, deduped internally. Fire-and-forget.
  //
  // 2026-08-25 race fix: v4's update below targets the SAME shadow_decisions
  // row this v2 insert creates (unique on ticker+periodOpenTs). Both calls
  // used to be fired independently (`void fnA(); void fnB();`) with no
  // ordering between them — on the FIRST observation of a new period, v4's
  // `await db.update(...)` could reach Postgres before v2's
  // `await getLearningState()` + `await db.insert(...)` had committed the
  // row, so the UPDATE's WHERE clause matched zero rows and silently
  // dropped that period's earliest (most information-rich) v4 fields,
  // excluding it from the v4.1 training set. Chaining v4 after v2 resolves
  // guarantees the row exists (freshly inserted or already present from an
  // earlier throttled call this period) before the update runs, while
  // keeping recordMarketObservation itself synchronous/non-blocking.
  void (async () => {
    await maybeLogShadowDecision({
      ticker:            input.ticker,
      periodOpenTs:      input.periodOpenTs,
      secsRemaining:     input.secsRemaining,
      yesAskCents:       input.yesAskCents,
      noAskCents:        input.noAskCents,
      leadExchangeDelta,
      distFromFloorPct,
      spreadCents,
    });

    // v4.1 shadow decision — updates the SAME row v2's insert above just
    // created/found (unique on ticker+periodOpenTs), adding pUpV4/evYes/evNo/
    // actionV4 alongside v2's original fields.
    await maybeLogShadowDecisionV4({
      ticker:            input.ticker,
      periodOpenTs:      input.periodOpenTs,
      secsRemaining:     input.secsRemaining,
      yesAskCents:       input.yesAskCents,
      noAskCents:        input.noAskCents,
      basisValue:        input.basis?.rollingBasis ?? null,
      basisStreakSign:   input.basis?.basisStreakSign ?? null,
      basisStreakLen:    input.basis?.basisStreakCount ?? null,
      leadExchangeDelta,
      distFromFloorPct,
      spreadCents,
      volumeScoreLive,
      sessionLabel,
    });
  })();

  void db.insert(marketObservations).values({
    ticker:              input.ticker,
    periodOpenTs:        input.periodOpenTs,
    secsRemaining:       Math.round(input.secsRemaining),
    floorStrike:         input.floorStrike,
    fairPrice:           input.fairPrice,
    distFromFloorPct,
    mtfScore:            input.mtf?.score ?? null,
    mtfBias:             input.mtf?.bias ?? null,
    mtf1m:               input.mtf?.m1?.bias ?? null,
    mtf5m:               input.mtf?.m5?.bias ?? null,
    mtf15m:              input.mtf?.m15?.bias ?? null,
    mtf1h:               input.mtf?.h1?.bias ?? null,
    basisValue:          input.basis?.rollingBasis ?? null,
    basisStreakSign:     input.basis?.basisStreakSign ?? null,
    basisStreakLen:      input.basis?.basisStreakCount ?? null,
    velocityPerMin:      null, // set by caller via a follow-up patch if needed; kept optional to avoid a hard dependency here
    candlePattern:       input.candlePattern?.pattern ?? null,
    candlePatternSignal: input.candlePattern?.signal ?? null,
    yesAskCents:         input.yesAskCents,
    noAskCents:          input.noAskCents,
    leadExchangeDelta,
    displacement,
    spreadCents,
    volumeScore,
    sessionLabel,
  }).catch(err => console.warn("[market-learning] snapshot insert failed:", (err as Error).message));
}

/**
 * Resolves every pending snapshot for one settled period. Called by
 * period-recorder.ts right after it writes the btc_periods row (or
 * determines direction-only settlement) — same trigger point, no separate
 * poll loop needed since period-recorder already owns "a period just
 * settled".
 */
export async function resolveMarketObservationsForPeriod(
  periodOpenTs: Date,
  direction: "up" | "down",
  settledPrice: number | null,
  floorStrike?: number | null,
  officialKalshi?: "YES" | "NO" | null,
): Promise<void> {
  try {
    const res = await db.update(marketObservations)
      .set({ settledDirection: direction, settledPrice, resolvedAt: new Date() })
      .where(and(
        eq(marketObservations.periodOpenTs, periodOpenTs),
        sql`${marketObservations.settledDirection} is null`,
      ));
    // drizzle-orm's pg update doesn't return a count by default without .returning();
    // resolvedAt/settledDirection being null is the real "did it work" signal on next query, not logged per-call to avoid noise.
    void res;

    // Market-learning v2: backfill fee-net labels on this period's rows and
    // resolve this period's shadow_decisions. Same trigger point, no
    // separate poll loop — see market-learning-v2.ts's own header.
    void resolveMarketLearningV2ForPeriod(periodOpenTs, direction, settledPrice);

    // Shadow 1s sampler: attach official Kalshi YES/NO (BTC close vs floor,
    // or Kalshi result). Period "up"/"down" is NOT YES/NO.
    const settledSide = kalshiSettleFromTruth({
      officialKalshi,
      btcClose: settledPrice,
      floorStrike,
    });
    if (settledSide) applyOfficialSettlement(periodOpenTs, settledSide, settledPrice);
    // Skip rows (bot_trade_skips) never used to get a settlement label — CONFLUENCE
    // / BASIS_LAG / CHEAP_SIDE sat-outs were unlabeled. Stamp ITM/OTM here, still
    // shadow-only. Extra tickers from the in-memory 1s acc are passed via
    // applyOfficialSettlement; this period-level call catches skips whose ticker
    // we remembered even if the 1s acc was already flushed.
    try {
      if (settledSide) resolveSkipsForPeriod(periodOpenTs, settledSide);
    } catch (err) {
      console.warn("[market-learning] skip-settlement resolve failed:", (err as Error).message);
    }
  } catch (err) {
    console.warn("[market-learning] resolution failed for period", periodOpenTs.toISOString(), (err as Error).message);
  }
}

export interface MarketBaseRateBucket {
  mtfBiasBucket: "bull" | "bear" | "neutral"; // collapsed from strong_bull/bull -> bull, etc.
  basisAligned: boolean; // basisStreakSign agrees with the direction being evaluated
}

interface BaseRateRow {
  n: number;
  upRate: number;
}

// evaluateAllStrategies() runs on the hot 500ms tick path and must stay
// fully synchronous (it has ~15 call sites, including tests/backtester —
// making it async would ripple far beyond this feature). So base rates are
// refreshed on a slow background timer into an in-memory cache, and the
// live consumer (getMarketBaseRateAdjustmentSync) only ever reads that
// cache — never issues a DB call itself.
const baseRateCache = new Map<string, BaseRateRow>();
const BASE_RATE_REFRESH_MS = 5 * 60_000;
let refreshTimer: NodeJS.Timeout | null = null;

const BUCKETS: MarketBaseRateBucket[] = [
  { mtfBiasBucket: "bull", basisAligned: true }, { mtfBiasBucket: "bull", basisAligned: false },
  { mtfBiasBucket: "bear", basisAligned: true }, { mtfBiasBucket: "bear", basisAligned: false },
  { mtfBiasBucket: "neutral", basisAligned: true }, { mtfBiasBucket: "neutral", basisAligned: false },
];

function bucketKey(bucket: MarketBaseRateBucket): string {
  return `${bucket.mtfBiasBucket}:${bucket.basisAligned}`;
}

async function refreshOneBucket(bucket: MarketBaseRateBucket): Promise<void> {
  const biasValues = bucket.mtfBiasBucket === "bull"
    ? ["bull", "strong_bull"]
    : bucket.mtfBiasBucket === "bear"
      ? ["bear", "strong_bear"]
      : ["neutral"];

  const rows = await db.select({
    direction: marketObservations.settledDirection,
  })
    .from(marketObservations)
    .where(and(
      isNotNull(marketObservations.settledDirection),
      inArray(marketObservations.mtfBias, biasValues),
      bucket.basisAligned
        ? sql`${marketObservations.basisStreakSign} * (CASE WHEN ${marketObservations.mtfBias} LIKE 'bull%' THEN 1 ELSE -1 END) > 0`
        : sql`TRUE`,
    ));

  const n = rows.length;
  const upCount = rows.filter(r => r.direction === "up").length;
  baseRateCache.set(bucketKey(bucket), { n, upRate: n > 0 ? upCount / n : 0.5 });
}

async function refreshAllBuckets(): Promise<void> {
  for (const b of BUCKETS) {
    await refreshOneBucket(b).catch(err => console.warn("[market-learning] base-rate refresh failed for", bucketKey(b), (err as Error).message));
  }
}

// ── Independent snapshot driver ──────────────────────────────────────────────
// trading-bot.ts's tick() also calls recordMarketObservation() while the bot
// is running (WATCHING/IN_TRADE), but tick() never fires at all when the bot
// is disabled/idle — and the whole point of this feature is to study every
// contract Kalshi lists, not just ones the bot happened to be running for.
// So this file drives its own snapshot on an independent timer too, exactly
// like mtfAnalyzer/candlePatternAnalyzer already do. recordMarketObservation's
// per-ticker throttle map is shared, so whichever caller (bot tick or this
// timer) fires first in a given coarse window just wins — no duplicate SQL.
//
// 1s path: in-memory ring + jsonl. SQL path: still coarse (15s / quote change).
// This is NOT trading-bot.ts's backgroundPreTrade 1s cache — that is entry
// latency only and must not be used as the learner.
let snapshotTimer: NodeJS.Timeout | null = null;
let flushTimer: NodeJS.Timeout | null = null;
let snapshotInFlight = false;

interface TickSample {
  ticker: string;
  ts: number;
  yesAsk: number | null;
  noAsk: number | null;
  yesBid: number | null;
  noBid: number | null;
  floor: number;
  projectedSettlement: number | null;
  secsRemaining: number;
  /** Coinbase last-trade. Null if the exchange print is missing. */
  coinbasePx: number | null;
  /** Kalshi-implied BTC (brtiProxy / inferBtcPrice). Null if missing. */
  kalshiImpliedPx: number | null;
  lagClassYes: LagClass;
  lagClassNo: LagClass;
  lagSeconds: number | null;
  lagDollars: number | null;
  lagCorr: number | null;
  lagStale: boolean;
  htf: HtfTapeSummary;
  streakSaturation: number | null;
}

interface QuoteSnap {
  ts: number;
  yesAsk: number | null;
  noAsk: number | null;
  yesBid: number | null;
  noBid: number | null;
}

interface ContractAcc {
  ticker: string;
  floor: number;
  periodOpenTs: number;
  sampleCount: number;
  firstQuote: QuoteSnap | null;
  lastQuote: QuoteSnap | null;
  midQuote: QuoteSnap | null;
  midDist: number;
  minCheapAsk: { side: "YES" | "NO"; price: number; ts: number } | null;
  cheapSideExisted: boolean;
  cheapFirstAppearedSecsToExpiry: number | null;
  settled: "YES" | "NO" | null;
  labeled: boolean;
  countedObserved: boolean;
  countedResolved: boolean;
}

interface ShadowLearnStats {
  contractsObserved: number;
  contractsWithCheapSide: number;
  resolved: number;
  cheapSideSettledITM: number;
  cheapSideSettledOTM: number;
  updatedAt: string | null;
  liveApplyEnabled: false;
  note: string;
}

const SHADOW_STATS_NOTE = "shadow-only observational stats; never applied to live gates";

function emptyShadowStats(): ShadowLearnStats {
  return {
    contractsObserved: 0,
    contractsWithCheapSide: 0,
    resolved: 0,
    cheapSideSettledITM: 0,
    cheapSideSettledOTM: 0,
    updatedAt: null,
    liveApplyEnabled: false,
    note: SHADOW_STATS_NOTE,
  };
}

let activeContract: ContractAcc | null = null;
const pendingByPeriod = new Map<number, ContractAcc>();
let pendingJsonl: { file: string; line: string }[] = [];
let shadowStats: ShadowLearnStats = emptyShadowStats();
const ringByTicker = new Map<string, TickSample[]>();

function researchPath(...parts: string[]): string {
  return path.join(RESEARCH_ROOT, ...parts);
}

function quoteOf(s: TickSample): QuoteSnap {
  return { ts: s.ts, yesAsk: s.yesAsk, noAsk: s.noAsk, yesBid: s.yesBid, noBid: s.noBid };
}

function newContractAcc(ticker: string, floor: number, periodOpenTs: number): ContractAcc {
  return {
    ticker,
    floor,
    periodOpenTs,
    sampleCount: 0,
    firstQuote: null,
    lastQuote: null,
    midQuote: null,
    midDist: Infinity,
    minCheapAsk: null,
    cheapSideExisted: false,
    cheapFirstAppearedSecsToExpiry: null,
    settled: null,
    labeled: false,
    countedObserved: false,
    countedResolved: false,
  };
}

function ingestSample(acc: ContractAcc, s: TickSample): void {
  acc.sampleCount += 1;
  const q = quoteOf(s);
  if (!acc.firstQuote) acc.firstQuote = q;
  acc.lastQuote = q;
  const dist = Math.abs(s.secsRemaining - 450);
  if (dist < acc.midDist) {
    acc.midQuote = q;
    acc.midDist = dist;
  }
  const cheap = pickCheapAsk(s.yesAsk, s.noAsk);
  if (cheap) {
    if (!acc.cheapSideExisted) {
      acc.cheapSideExisted = true;
      acc.cheapFirstAppearedSecsToExpiry = s.secsRemaining;
    }
    if (!acc.minCheapAsk || cheap.price < acc.minCheapAsk.price) {
      acc.minCheapAsk = { side: cheap.side, price: cheap.price, ts: s.ts };
    }
  }
  let ring = ringByTicker.get(s.ticker);
  if (!ring) {
    ring = [];
    ringByTicker.set(s.ticker, ring);
  }
  ring.push(s);
  if (ring.length > RING_CAP) ring.splice(0, ring.length - RING_CAP);
  ingestChart1sTick(s);
}

function enqueueTickJsonl(s: TickSample): void {
  pendingJsonl.push({
    file: researchPath("ticks", tickJsonlFilename(s.ts, s.ticker)),
    line: JSON.stringify(s),
  });
}

/** One settlement marker on the 1s tape so ticks/*.jsonl join to the official YES/NO. */
function enqueueTickSettlement(ticker: string, settled: "YES" | "NO", tsMs: number): void {
  pendingJsonl.push({
    file: researchPath("ticks", tickJsonlFilename(tsMs, ticker)),
    line: JSON.stringify({ event: "settlement", ticker, settled, ts: tsMs, liveApplyEnabled: false }),
  });
}

export function flushPendingTicks(): void {
  if (pendingJsonl.length === 0) return;
  const batch = pendingJsonl;
  pendingJsonl = [];
  const byFile = new Map<string, string[]>();
  for (const row of batch) {
    const list = byFile.get(row.file);
    if (list) list.push(row.line);
    else byFile.set(row.file, [row.line]);
  }
  try {
    fs.mkdirSync(researchPath("ticks"), { recursive: true });
  } catch (err) {
    console.warn("[market-learning] mkdir ticks failed:", (err as Error).message);
    pendingJsonl = batch.concat(pendingJsonl);
    return;
  }
  for (const [file, lines] of byFile) {
    try {
      fs.appendFileSync(file, lines.join("\n") + "\n");
    } catch (err) {
      console.warn("[market-learning] tick jsonl append failed:", file, (err as Error).message);
      pendingJsonl = lines.map(line => ({ file, line })).concat(pendingJsonl);
    }
  }
}

function loadShadowStats(): void {
  try {
    const raw = fs.readFileSync(researchPath("shadow-learn.json"), "utf8");
    const parsed = JSON.parse(raw) as Partial<ShadowLearnStats>;
    shadowStats = {
      ...emptyShadowStats(),
      contractsObserved: Number(parsed.contractsObserved) || 0,
      contractsWithCheapSide: Number(parsed.contractsWithCheapSide) || 0,
      resolved: Number(parsed.resolved) || 0,
      cheapSideSettledITM: Number(parsed.cheapSideSettledITM) || 0,
      cheapSideSettledOTM: Number(parsed.cheapSideSettledOTM) || 0,
    };
  } catch {
    shadowStats = emptyShadowStats();
  }
}

function persistShadowStats(): void {
  shadowStats.liveApplyEnabled = false;
  shadowStats.note = SHADOW_STATS_NOTE;
  shadowStats.updatedAt = new Date().toISOString();
  try {
    fs.mkdirSync(RESEARCH_ROOT, { recursive: true });
    fs.writeFileSync(researchPath("shadow-learn.json"), JSON.stringify(shadowStats, null, 2) + "\n");
  } catch (err) {
    console.warn("[market-learning] shadow-learn.json write failed:", (err as Error).message);
  }
}

function countContract(acc: ContractAcc): void {
  if (!acc.countedObserved) {
    acc.countedObserved = true;
    shadowStats.contractsObserved += 1;
    if (acc.cheapSideExisted) shadowStats.contractsWithCheapSide += 1;
  }
  if (acc.settled && !acc.countedResolved) {
    acc.countedResolved = true;
    shadowStats.resolved += 1;
    if (acc.cheapSideExisted) {
      const itm = cheapSettledITM(acc.minCheapAsk?.side ?? null, acc.settled);
      if (itm === true) shadowStats.cheapSideSettledITM += 1;
      else if (itm === false) shadowStats.cheapSideSettledOTM += 1;
    }
  }
  persistShadowStats();
}

function writeContractLabel(acc: ContractAcc): void {
  const row = {
    ts: new Date().toISOString(),
    ticker: acc.ticker,
    floor: acc.floor,
    periodOpenTs: new Date(acc.periodOpenTs).toISOString(),
    settled: acc.settled,
    sampleCount: acc.sampleCount,
    minCheapAsk: acc.minCheapAsk,
    cheapSideExisted: acc.cheapSideExisted,
    cheapFirstAppearedSecsToExpiry: acc.cheapFirstAppearedSecsToExpiry,
    firstQuote: acc.firstQuote,
    lastQuote: acc.lastQuote,
    midQuote: acc.midQuote,
    liveApplyEnabled: false,
  };
  try {
    fs.mkdirSync(RESEARCH_ROOT, { recursive: true });
    fs.appendFileSync(researchPath("contract-labels.jsonl"), JSON.stringify(row) + "\n");
    acc.labeled = true;
  } catch (err) {
    console.warn("[market-learning] contract-labels.jsonl append failed:", (err as Error).message);
  }
  countContract(acc);
}

function inferSettledFromNextFloor(prevFloor: number, nextFloor: number): "YES" | "NO" | null {
  if (!(prevFloor > 0) || !(nextFloor > 0)) return null;
  return nextFloor >= prevFloor ? "YES" : "NO";
}

function finalizeContract(acc: ContractAcc, nextFloor: number | null): void {
  flushPendingTicks();
  if (!acc.settled && nextFloor != null) {
    acc.settled = inferSettledFromNextFloor(acc.floor, nextFloor);
  }
  if (!acc.labeled) writeContractLabel(acc);
  else countContract(acc);
  pendingByPeriod.set(acc.periodOpenTs, acc);
  ringByTicker.delete(acc.ticker);
}

function applyOfficialSettlement(
  periodOpenTs: Date,
  settled: "YES" | "NO",
  _settledPrice: number | null,
): void {
  const key = periodOpenTs.getTime();
  let acc = pendingByPeriod.get(key);
  if (!acc && activeContract && activeContract.periodOpenTs === key) {
    acc = activeContract;
  }
  if (!acc) return;
  const wasNull = acc.settled == null;
  acc.settled = settled;
  if (!acc.labeled) {
    writeContractLabel(acc);
  } else if (wasNull) {
    // Already wrote a close-time line with settled=null — append one
    // resolution line so jsonl stays append-only.
    writeContractLabel(acc);
  } else {
    countContract(acc);
  }
  // Wire the official settlement onto the 1s tick tape + stamp skip ITM/OTM.
  // Shadow-only; never flips LIVE_APPLY_ENABLED.
  enqueueTickSettlement(acc.ticker, settled, Date.now());
  flushPendingTicks();
  try {
    resolveSkipsForTicker(acc.ticker, settled, { periodOpenTs: new Date(acc.periodOpenTs) });
  } catch (err) {
    console.warn("[market-learning] skip-settlement on ticker close failed:", (err as Error).message);
  }
}

function sampleOneSecond(): void {
  try {
    const tick = kalshiWS.getLatest();
    if (!tick?.ticker || !tick.floorStrike) return;

    if (activeContract && tick.ticker !== activeContract.ticker) {
      const prev = activeContract;
      activeContract = null;
      finalizeContract(prev, tick.floorStrike);
    }

    if (!activeContract) {
      const periodOpenTs = currentPeriodOpenTs();
      activeContract = newContractAcc(tick.ticker, tick.floorStrike, periodOpenTs.getTime());
    }

    const now = Date.now();
    const secsRemaining = 900 - (now - activeContract.periodOpenTs) / 1000;
    const basis = basisTracker.getState();
    const projected = basis.projectedSettlementPrice ?? null;
    const mtfScore = mtfAnalyzer.getSummary()?.score ?? null;
    const kalshiImplied = (typeof basis.brtiProxy === "number" && basis.brtiProxy > 0)
      ? basis.brtiProxy
      : inferBtcPrice(tick);
    const coinbasePx = (typeof basis.exchangePrice === "number" && basis.exchangePrice > 0)
      ? basis.exchangePrice
      : null;
    const lagStamp = stampTickLag({
      coinbasePx,
      kalshiImpliedPx: kalshiImplied,
      lag: {
        lagSeconds: basis.lagSeconds,
        lagDollars: basis.lagDollars,
        lagCorr: basis.lagCorr,
        lagStale: basis.lagStale,
        lagReason: basis.lagReason,
      },
    });
    const htfSpot = (typeof kalshiImplied === "number" && kalshiImplied > 0)
      ? kalshiImplied
      : (typeof coinbasePx === "number" && coinbasePx > 0 ? coinbasePx : null);
    const stamp = stampFromLive({
      lag: {
        lagSeconds: lagStamp.lagSeconds,
        lagDollars: lagStamp.lagDollars,
        lagCorr: lagStamp.lagCorr,
        lagStale: lagStamp.lagStale,
        lagReason: basis.lagReason,
      },
      // Missing Coinbase/Kalshi px → UNKNOWN HTF. Never floorStrike or 0 as spot.
      htf: htfSpot != null ? computeLiveHtfStructure(htfSpot, now) : null,
      mtfScore,
    });
    const sample: TickSample = {
      ticker: tick.ticker,
      ts: now,
      yesAsk: tick.yesAsk ?? null,
      noAsk: tick.noAsk ?? null,
      yesBid: tick.yesBid ?? null,
      noBid: tick.noBid ?? null,
      floor: tick.floorStrike,
      projectedSettlement: projected,
      secsRemaining,
      coinbasePx: lagStamp.coinbasePx,
      kalshiImpliedPx: lagStamp.kalshiImpliedPx,
      lagClassYes: stamp.lagClassYes,
      lagClassNo: stamp.lagClassNo,
      lagSeconds: lagStamp.lagSeconds,
      lagDollars: lagStamp.lagDollars,
      lagCorr: lagStamp.lagCorr,
      lagStale: lagStamp.lagStale,
      htf: stamp.htf,
      streakSaturation: stamp.streakSaturation,
    };
    ingestSample(activeContract, sample);
    enqueueTickJsonl(sample);

    if (isDbSnapshotDue(tick.ticker, tick.yesAsk ?? null, tick.noAsk ?? null)) {
      void coarseDbSnapshotTick();
    }
  } catch (err) {
    console.warn("[market-learning] 1s sample failed:", (err as Error).message);
  }
}

async function coarseDbSnapshotTick(): Promise<void> {
  if (snapshotInFlight) return;
  snapshotInFlight = true;
  try {
    const tick = kalshiWS.getLatest();
    if (!tick?.ticker || !tick.floorStrike) return;

    const periodOpenTs = activeContract
      ? new Date(activeContract.periodOpenTs)
      : currentPeriodOpenTs();
    const secsRemaining = 900 - (Date.now() - periodOpenTs.getTime()) / 1000;

    const fairPrice = inferBtcPrice(tick);
    const basis = await basisTracker.tick({
      brtiProxy: fairPrice,
      floorStrike: tick.floorStrike,
      velocityPerMin: 0, // independent driver has no bot-side velocity calc; descriptive field only, not used by getMarketBaseRateAdjustmentSync
      secsRemaining,
    }).catch(() => null);

    recordMarketObservation({
      ticker: tick.ticker,
      periodOpenTs,
      secsRemaining,
      floorStrike: tick.floorStrike,
      fairPrice,
      mtf: mtfAnalyzer.getSummaryRaw(),
      basis,
      candlePattern: candlePatternAnalyzer.getLatest(),
      yesAskCents: tick.yesAsk ?? null,
      noAskCents: tick.noAsk ?? null,
      yesBidCents: tick.yesBid ?? null,
      noBidCents: tick.noBid ?? null,
      liveVolumeInputs: null,
    });
  } catch (err) {
    console.warn("[market-learning] independent snapshot tick failed:", (err as Error).message);
  } finally {
    snapshotInFlight = false;
  }
}

/** Kept as a named alias so logs / grep still find the original entry point. */
async function independentSnapshotTick(): Promise<void> {
  sampleOneSecond();
}

/** Starts the background base-rate cache refresh + independent snapshot driver. Called once at server boot, mirrors mtfAnalyzer.start()/candlePatternAnalyzer's own lifecycle pattern. */
export function startMarketLearning(): void {
  if (refreshTimer) return;
  if (LIVE_APPLY_ENABLED) {
    // Hard invariant: this sampler is shadow-only. Never auto-enable live apply.
    console.warn("[market-learning] LIVE_APPLY_ENABLED was true at start — forcing false (shadow only)");
    LIVE_APPLY_ENABLED = false;
  }
  loadShadowStats();
  persistShadowStats();
  void refreshAllBuckets();
  refreshTimer = setInterval(() => void refreshAllBuckets(), BASE_RATE_REFRESH_MS);
  snapshotTimer = setInterval(() => void independentSnapshotTick(), SAMPLE_INTERVAL_MS);
  flushTimer = setInterval(() => flushPendingTicks(), TICK_FLUSH_MS);
  void independentSnapshotTick();
  startMarketLearningV2();
  startMarketLearningV4();
  startModelPromotionEvaluator();
  console.info("[market-learning] Started — 1s shadow sampler (jsonl) + coarse 15s SQL snapshots; LIVE_APPLY_ENABLED=false; base-rate cache refreshes every 5m");
}

/**
 * Sync, hot-path-safe lookup — reads the in-memory cache only, never hits
 * the DB. Returns a small, bounded confidence delta (can be negative) for
 * a strategy result whose `signal` direction agrees or disagrees with the
 * market-wide empirical base rate for this condition bucket. Returns 0
 * when there isn't enough resolved history yet (MIN_SAMPLE_SIZE), the
 * cache hasn't warmed up, or LIVE_APPLY_ENABLED is false (shadow mode).
 */
export function getMarketBaseRateAdjustmentSync(
  bucket: MarketBaseRateBucket,
  signal: "YES" | "NO",
): { delta: number; sampleSize: number; baseRate: number } {
  const row = baseRateCache.get(bucketKey(bucket));
  if (!row || row.n < MIN_SAMPLE_SIZE) return { delta: 0, sampleSize: row?.n ?? 0, baseRate: row?.upRate ?? 0.5 };

  // Empirical up-rate vs. a neutral 50% prior, scaled down hard and capped —
  // this is a nudge toward historical reality, never a large swing.
  const edge = signal === "YES" ? (row.upRate - 0.5) : (0.5 - row.upRate);
  const delta = Math.max(-MAX_ADJUSTMENT, Math.min(MAX_ADJUSTMENT, edge * 0.3));
  return { delta: LIVE_APPLY_ENABLED ? delta : 0, sampleSize: row.n, baseRate: row.upRate };
}

/** Derives the coarse mtfBiasBucket used both when writing snapshots (via the string bias) and reading them back (via the numeric score already in StrategyObservation) — keeps the two sides consistent without threading the string through every call site. */
export function mtfScoreToBucket(mtfScore: number | undefined): "bull" | "bear" | "neutral" {
  if ((mtfScore ?? 0) >= 1) return "bull";
  if ((mtfScore ?? 0) <= -1) return "bear";
  return "neutral";
}

/** How much resolved history exists overall — used by /api/healthz and the dashboard to show "N contracts studied so far". */
export async function getMarketLearningReadiness(): Promise<{ totalObserved: number; totalResolved: number; readyForLiveApply: boolean }> {
  const [totalRow] = await db.select({ n: sql<number>`count(*)` }).from(marketObservations);
  const [resolvedRow] = await db.select({ n: sql<number>`count(*)` }).from(marketObservations).where(isNotNull(marketObservations.settledDirection));
  const totalObserved = Number(totalRow?.n ?? 0);
  const totalResolved = Number(resolvedRow?.n ?? 0);
  return { totalObserved, totalResolved, readyForLiveApply: totalResolved >= MIN_SAMPLE_SIZE * 4 };
}
