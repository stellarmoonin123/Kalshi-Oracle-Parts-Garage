/**
 * async-guard.ts
 *
 * makeGuarded(fn) — wraps an async function with an in-flight mutex so a
 * timer-driven loop can never overlap itself when one invocation runs slow.
 * While a call is in flight, subsequent calls return immediately (skipped).
 *
 * Every async setInterval body in this server must use this pattern (or an
 * equivalent per-timer flag): a slow network/DB call must never stack with
 * the next interval fire. See the Aug 2026 latency audit.
 */
export function makeGuarded(fn: () => Promise<void>, onError?: (err: Error) => void): () => Promise<void> {
  let running = false;
  return async () => {
    if (running) return;   // previous invocation still in flight — skip, don't stack
    running = true;
    try {
      await fn();
    } catch (err) {
      onError?.(err as Error);
    } finally {
      running = false;
    }
  };
}
